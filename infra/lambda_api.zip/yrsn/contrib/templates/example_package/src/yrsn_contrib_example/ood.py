"""Example custom OOD detector."""

from typing import Any, List, Optional, Union
import numpy as np


class ExampleOODDetector:
    """
    Example out-of-distribution detector.

    OOD detectors compute omega (ω) - the reliability score.
    High omega means in-distribution (trust the model).
    Low omega means out-of-distribution (fall back to prior).

    Example:
        from yrsn_tools import YRSN
        from yrsn_contrib_example import ExampleOODDetector

        detector = ExampleOODDetector()
        detector.fit(training_features)

        omega = detector.score(test_features)
        y = YRSN(content, omega=omega)
    """

    def __init__(
        self,
        threshold: float = 0.5,
        n_components: int = 10,
    ):
        """
        Initialize the detector.

        Args:
            threshold: OOD threshold (below = out-of-distribution)
            n_components: Number of components for internal model
        """
        self.threshold = threshold
        self.n_components = n_components
        self._fitted = False
        self._mean = None
        self._std = None

    def fit(self, X: Union[np.ndarray, List]) -> "ExampleOODDetector":
        """
        Fit the detector on in-distribution training data.

        Args:
            X: Training features (n_samples, n_features)

        Returns:
            self for chaining
        """
        X = np.asarray(X)
        self._mean = np.mean(X, axis=0)
        self._std = np.std(X, axis=0) + 1e-8  # Avoid division by zero
        self._fitted = True
        return self

    def score(self, X: Union[np.ndarray, List, Any]) -> float:
        """
        Compute OOD score (omega).

        Args:
            X: Input features

        Returns:
            omega in [0, 1] where:
            - 1.0 = definitely in-distribution
            - 0.0 = definitely out-of-distribution
        """
        if not self._fitted:
            # Not fitted, return moderate confidence
            return 0.5

        X = np.asarray(X)
        if X.ndim == 1:
            X = X.reshape(1, -1)

        # Simple z-score based OOD detection
        z_scores = np.abs((X - self._mean) / self._std)
        max_z = np.max(z_scores)

        # Convert to omega (higher z = lower omega)
        # z=0 -> omega=1, z=3 -> omega~0.05
        omega = np.exp(-max_z / 2)
        return float(np.clip(omega, 0.0, 1.0))

    def score_batch(self, X: Union[np.ndarray, List]) -> np.ndarray:
        """
        Score a batch of inputs.

        Args:
            X: Batch of features (n_samples, n_features)

        Returns:
            Array of omega scores
        """
        X = np.asarray(X)
        return np.array([self.score(x) for x in X])

    def is_ood(self, X: Any) -> bool:
        """
        Check if input is out-of-distribution.

        Args:
            X: Input features

        Returns:
            True if OOD (omega < threshold)
        """
        return self.score(X) < self.threshold

    def __repr__(self) -> str:
        status = "fitted" if self._fitted else "not fitted"
        return f"ExampleOODDetector(threshold={self.threshold}, {status})"
