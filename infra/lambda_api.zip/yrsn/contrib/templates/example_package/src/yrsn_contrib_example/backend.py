"""Example custom YRSN backend."""

from typing import Tuple


class ExampleBackend:
    """
    Example YRSN decomposition backend.

    Backends provide the R/S/N decomposition algorithm.
    They are plugged into the YRSN class via the `backend` parameter.

    Example:
        from yrsn_tools import YRSN
        from yrsn.contrib import discover

        discover()  # Load extensions

        y = YRSN("content", backend="example")
        print(y.R, y.S, y.N)
    """

    # Required: unique name for this backend
    name = "example"

    def __init__(self, bias_r: float = 0.6, **config):
        """
        Initialize the backend.

        Args:
            bias_r: Base relevance bias (0-1)
            **config: Additional configuration
        """
        self.bias_r = bias_r
        self.config = config

    def decompose(
        self,
        content: str,
        query: str = "",
        **kwargs
    ) -> Tuple[float, float, float]:
        """
        Decompose content into R, S, N components.

        This is the core method that YRSN calls.

        Args:
            content: The content to analyze
            query: Optional query for relevance scoring
            **kwargs: Additional parameters

        Returns:
            Tuple of (R, S, N) where R + S + N = 1.0
            - R: Relevant content ratio
            - S: Superfluous content ratio
            - N: Noise ratio
        """
        # Example: Simple heuristic based on content length and query match
        content_len = len(content)
        query_len = len(query) if query else 0

        # Base relevance from bias
        r = self.bias_r

        # Adjust based on query presence
        if query and query.lower() in content.lower():
            r = min(r + 0.2, 0.95)

        # Shorter content tends to be more focused
        if content_len < 100:
            s = 0.1
        elif content_len < 500:
            s = 0.2
        else:
            s = 0.3

        # Noise is the remainder
        n = max(0.05, 1.0 - r - s)

        # Normalize to sum to 1.0
        total = r + s + n
        return (r / total, s / total, n / total)

    def __repr__(self) -> str:
        return f"ExampleBackend(bias_r={self.bias_r})"
