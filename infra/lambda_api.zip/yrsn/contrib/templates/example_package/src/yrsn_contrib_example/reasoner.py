"""Example custom reasoner."""

from typing import Any, Dict, Optional


class ExampleReasoner:
    """
    Example reasoner showing the expected interface.

    Reasoners process inputs and produce reasoning outputs.
    They can be used standalone or composed with YRSN quality.

    Example:
        reasoner = ExampleReasoner(temperature=0.7)
        result = reasoner("What is 2+2?")
        print(result)  # {'answer': '4', 'confidence': 0.95}
    """

    def __init__(
        self,
        temperature: float = 1.0,
        max_steps: int = 10,
        config: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize the reasoner.

        Args:
            temperature: Sampling temperature (lower = more deterministic)
            max_steps: Maximum reasoning steps
            config: Additional configuration
        """
        self.temperature = temperature
        self.max_steps = max_steps
        self.config = config or {}

    def __call__(self, input_data: Any, **kwargs) -> Dict[str, Any]:
        """
        Process input and return reasoning output.

        Args:
            input_data: The input to reason about
            **kwargs: Additional parameters (e.g., context, constraints)

        Returns:
            Dict with reasoning results
        """
        # Example implementation - replace with your logic
        return {
            "input": str(input_data)[:100],
            "output": "Example reasoning output",
            "steps": 1,
            "confidence": 0.85,
            "metadata": {
                "temperature": self.temperature,
                "reasoner": "ExampleReasoner",
            }
        }

    def forward(self, x: Any, **kwargs) -> Dict[str, Any]:
        """PyTorch-style interface (alias for __call__)."""
        return self(x, **kwargs)

    def reason(self, query: str, context: str = "") -> Dict[str, Any]:
        """
        Reason about a query with optional context.

        Args:
            query: The question or task
            context: Supporting context

        Returns:
            Reasoning result
        """
        return self({"query": query, "context": context})
