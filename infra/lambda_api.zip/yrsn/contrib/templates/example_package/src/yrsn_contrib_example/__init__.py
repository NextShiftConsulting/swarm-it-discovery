"""
YRSN-Tools Contrib Example

Example extension package showing how to create:
- Custom reasoners
- Custom backends
- Custom OOD detectors

Install with: pip install -e .
"""

from .reasoner import ExampleReasoner
from .backend import ExampleBackend
from .ood import ExampleOODDetector

__version__ = "0.1.0"

__all__ = [
    "ExampleReasoner",
    "ExampleBackend",
    "ExampleOODDetector",
]
