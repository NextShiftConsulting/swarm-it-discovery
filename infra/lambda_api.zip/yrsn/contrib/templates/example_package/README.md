# YRSN-Tools Contrib Example

Example extension package for yrsn-tools demonstrating the contrib system.

## Installation

```bash
pip install -e .
```

## Usage

```python
from yrsn_tools.contrib import discover, list_extensions

# See available extensions
print(list_extensions())

# Load all extensions
discover()

# Use the example reasoner
from yrsn_tools.reasoners import ExampleReasoner
reasoner = ExampleReasoner()
result = reasoner("What is 2+2?")

# Use the example backend
from yrsn_tools import YRSN
y = YRSN("some content", backend="example")
print(y.R, y.S, y.N)

# Use the example OOD detector
from yrsn_contrib_example import ExampleOODDetector
detector = ExampleOODDetector()
```

## Creating Your Own

Copy this package and modify:
1. Rename `yrsn_contrib_example` to `yrsn_contrib_yourname`
2. Update `pyproject.toml` with your package name and entry points
3. Implement your components
4. Publish to PyPI!
