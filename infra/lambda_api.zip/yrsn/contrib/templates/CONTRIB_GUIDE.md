# Creating YRSN-Tools Contrib Packages

This guide shows how to create community extensions for yrsn-tools using Python entry points.

## Quick Start

```bash
# Create your package
mkdir yrsn-tools-contrib-myext
cd yrsn-tools-contrib-myext

# Copy the template
cp -r path/to/yrsn_tools/contrib/templates/example_package/* .

# Install in development mode
pip install -e .

# Your extension is now available!
python -c "from yrsn_tools.contrib import list_extensions; print(list_extensions())"
```

## Package Structure

```
yrsn-tools-contrib-myext/
├── pyproject.toml          # Entry points defined here
├── src/
│   └── yrsn_contrib_myext/
│       ├── __init__.py     # Export your components
│       ├── reasoner.py     # Custom reasoner
│       └── backend.py      # Custom backend
└── tests/
    └── test_myext.py
```

## Entry Point Groups

Register your components in `pyproject.toml`:

```toml
[project.entry-points."yrsn_tools.reasoners"]
MyReasoner = "yrsn_contrib_myext:MyReasoner"

[project.entry-points."yrsn_tools.backends"]
my_backend = "yrsn_contrib_myext:MyBackend"

[project.entry-points."yrsn_tools.combiners"]
MyCombiner = "yrsn_contrib_myext:MyCombiner"

[project.entry-points."yrsn_tools.ood"]
MyDetector = "yrsn_contrib_myext:MyOODDetector"

[project.entry-points."yrsn_tools.strategies"]
MyStrategy = "yrsn_contrib_myext:MyStrategy"

[project.entry-points."yrsn_tools.memory"]
MyMemory = "yrsn_contrib_myext:MyMemorySystem"

[project.entry-points."yrsn_tools.tools"]
my_tool = "yrsn_contrib_myext:my_tool_function"
```

## Creating a Custom Reasoner

```python
# src/yrsn_contrib_myext/reasoner.py

class MyReasoner:
    """Custom reasoner for my domain."""

    def __init__(self, config=None):
        self.config = config or {}

    def __call__(self, input_data, **kwargs):
        """
        Process input and return reasoning output.

        Args:
            input_data: The input to reason about
            **kwargs: Additional parameters

        Returns:
            Reasoning output (format depends on your use case)
        """
        # Your reasoning logic here
        return {"result": "processed", "confidence": 0.95}

    def forward(self, x):
        """Alternative interface for PyTorch-style models."""
        return self(x)
```

## Creating a Custom Backend

Backends provide different R/S/N decomposition algorithms:

```python
# src/yrsn_contrib_myext/backend.py

from typing import Protocol, Tuple

class MyBackend:
    """Custom YRSN decomposition backend."""

    name = "my_backend"

    def __init__(self, **config):
        self.config = config

    def decompose(
        self,
        content: str,
        query: str = "",
        **kwargs
    ) -> Tuple[float, float, float]:
        """
        Decompose content into R, S, N components.

        Args:
            content: The content to analyze
            query: Optional query for relevance
            **kwargs: Additional parameters

        Returns:
            Tuple of (R, S, N) where R + S + N = 1.0
        """
        # Your decomposition logic here
        r = 0.7  # Relevant
        s = 0.2  # Superfluous
        n = 0.1  # Noise

        # Ensure they sum to 1.0
        total = r + s + n
        return (r/total, s/total, n/total)
```

## Creating a Custom OOD Detector

OOD detectors compute omega (reliability):

```python
# src/yrsn_contrib_myext/ood.py

import numpy as np

class MyOODDetector:
    """Custom out-of-distribution detector."""

    def __init__(self, threshold=0.5):
        self.threshold = threshold
        self._fitted = False

    def fit(self, X_train):
        """Fit the detector on training data."""
        # Your fitting logic
        self._fitted = True
        return self

    def score(self, X) -> float:
        """
        Compute OOD score (omega).

        Args:
            X: Input features

        Returns:
            omega in [0, 1] where:
            - 1.0 = definitely in-distribution (trust the model)
            - 0.0 = definitely out-of-distribution (fall back to prior)
        """
        # Your OOD scoring logic
        return 0.85

    def is_ood(self, X) -> bool:
        """Check if input is out-of-distribution."""
        return self.score(X) < self.threshold
```

## Using Your Extension

Once installed, users can:

```python
# Option 1: Auto-discover all extensions
from yrsn_tools.contrib import discover
discover()

from yrsn_tools.reasoners import MyReasoner
from yrsn_tools import YRSN

reasoner = MyReasoner()
y = YRSN(content, backend="my_backend")

# Option 2: Load specific extension
from yrsn_tools.contrib import get_extension
MyReasoner = get_extension('reasoners', 'MyReasoner')

# Option 3: Direct import (if you know the package)
from yrsn_contrib_myext import MyReasoner
```

## Best Practices

1. **Naming**: Use `yrsn-tools-contrib-*` for package names
2. **Namespace**: Use `yrsn_contrib_*` for Python modules
3. **Dependencies**: Keep yrsn-tools as the only required dependency
4. **Testing**: Include tests that work without GPU/special hardware
5. **Documentation**: Document your components with docstrings
6. **Versioning**: Follow semantic versioning

## Publishing

```bash
# Build
python -m build

# Upload to PyPI
twine upload dist/*
```

Users can then install with:
```bash
pip install yrsn-tools-contrib-myext
```
