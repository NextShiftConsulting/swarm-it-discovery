"""
YRSN Contrib - Community extension system via entry points.

Allows third-party packages to register components with yrsn-tools.

=============================================================================
FOR EXTENSION AUTHORS
=============================================================================

To create a contrib package, add entry points to your pyproject.toml:

    [project.entry-points."yrsn_tools.reasoners"]
    MyReasoner = "my_package.reasoners:MyReasoner"

    [project.entry-points."yrsn_tools.backends"]
    my_backend = "my_package.backends:MyBackend"

    [project.entry-points."yrsn_tools.ood"]
    MyDetector = "my_package.ood:MyOODDetector"

Available entry point groups:
    - yrsn_tools.reasoners  → Custom reasoning models
    - yrsn_tools.combiners  → Custom combiners/routers
    - yrsn_tools.backends   → Custom YRSN decomposition backends
    - yrsn_tools.ood        → Custom OOD detectors
    - yrsn_tools.strategies → Custom context strategies
    - yrsn_tools.memory     → Custom memory systems
    - yrsn_tools.tools      → Custom pre-built tools

=============================================================================
FOR USERS
=============================================================================

    from yrsn.contrib import discover, list_extensions

    # See what's installed
    extensions = list_extensions()
    print(extensions)
    # {'reasoners': ['AudioReasoner', 'VideoReasoner'],
    #  'backends': ['faiss_backend'], ...}

    # Load all extensions into their respective modules
    discover()

    # Now use them
    from yrsn.reasoners import AudioReasoner  # From contrib!

=============================================================================
EXAMPLE CONTRIB PACKAGE
=============================================================================

Create a package `yrsn-tools-contrib-audio`:

    # pyproject.toml
    [project]
    name = "yrsn-tools-contrib-audio"
    version = "0.1.0"
    dependencies = ["yrsn-tools>=0.1.0"]

    [project.entry-points."yrsn_tools.reasoners"]
    AudioReasoner = "yrsn_contrib_audio:AudioReasoner"

    [project.entry-points."yrsn_tools.backends"]
    audio = "yrsn_contrib_audio:AudioBackend"

    # src/yrsn_contrib_audio/__init__.py
    from .reasoner import AudioReasoner
    from .backend import AudioBackend

Users install with: pip install yrsn-tools-contrib-audio
"""

from __future__ import annotations

import logging
import sys
from typing import Any, Callable, Dict, List, Optional, Type

logger = logging.getLogger(__name__)

# =============================================================================
# Entry Point Groups
# =============================================================================

ENTRY_POINT_GROUPS = {
    "reasoners": "yrsn_tools.reasoners",
    "combiners": "yrsn_tools.combiners",
    "backends": "yrsn_tools.backends",
    "ood": "yrsn_tools.ood",
    "strategies": "yrsn_tools.strategies",
    "memory": "yrsn_tools.memory",
    "filtering": "yrsn_tools.filtering",
    "hardware": "yrsn_tools.hardware",
    "tools": "yrsn_tools.tools",
}

# =============================================================================
# Registry
# =============================================================================

# Global registry of discovered extensions
_registry: Dict[str, Dict[str, Any]] = {group: {} for group in ENTRY_POINT_GROUPS}
_discovered = False


def _get_entry_points(group: str) -> list:
    """Get entry points for a group, handling Python version differences."""
    try:
        # Python 3.10+
        from importlib.metadata import entry_points
        eps = entry_points(group=group)
        return list(eps)
    except TypeError:
        # Python 3.9 and earlier
        from importlib.metadata import entry_points
        eps = entry_points()
        return list(eps.get(group, []))


def discover(
    groups: Optional[List[str]] = None,
    auto_register: bool = True,
    verbose: bool = False,
) -> Dict[str, Dict[str, Any]]:
    """
    Discover and load all contrib extensions via entry points.

    Args:
        groups: Specific groups to discover (None = all)
        auto_register: If True, register into yrsn_tools modules
        verbose: If True, log discovery progress

    Returns:
        Dict mapping group names to discovered extensions

    Example:
        >>> extensions = discover()
        >>> extensions['reasoners']
        {'AudioReasoner': <class 'yrsn_contrib_audio.AudioReasoner'>}
    """
    global _discovered, _registry

    if groups is None:
        groups = list(ENTRY_POINT_GROUPS.keys())

    discovered = {}

    for group_name in groups:
        if group_name not in ENTRY_POINT_GROUPS:
            logger.warning(f"Unknown group: {group_name}")
            continue

        ep_group = ENTRY_POINT_GROUPS[group_name]
        discovered[group_name] = {}

        for ep in _get_entry_points(ep_group):
            try:
                # Load the extension
                ext = ep.load()
                name = ep.name

                # Store in registry
                _registry[group_name][name] = ext
                discovered[group_name][name] = ext

                if verbose:
                    logger.info(f"Discovered {group_name}.{name} from {ep.value}")

                # Auto-register into yrsn_tools module
                if auto_register:
                    _register_extension(group_name, name, ext)

            except Exception as e:
                logger.warning(f"Failed to load {ep.name} from {ep_group}: {e}")

    _discovered = True
    return discovered


def _register_extension(group_name: str, name: str, ext: Any) -> None:
    """Register an extension into its yrsn_tools module."""
    module_name = f"yrsn_tools.{group_name}"

    if module_name in sys.modules:
        module = sys.modules[module_name]
        if not hasattr(module, name):
            setattr(module, name, ext)
            # Also add to __all__ if it exists
            if hasattr(module, "__all__") and name not in module.__all__:
                module.__all__.append(name)


def list_extensions(groups: Optional[List[str]] = None) -> Dict[str, List[str]]:
    """
    List all available extensions without loading them.

    Args:
        groups: Specific groups to list (None = all)

    Returns:
        Dict mapping group names to list of extension names

    Example:
        >>> list_extensions()
        {'reasoners': ['AudioReasoner'], 'backends': ['faiss']}
    """
    if groups is None:
        groups = list(ENTRY_POINT_GROUPS.keys())

    result = {}
    for group_name in groups:
        if group_name not in ENTRY_POINT_GROUPS:
            continue

        ep_group = ENTRY_POINT_GROUPS[group_name]
        result[group_name] = [ep.name for ep in _get_entry_points(ep_group)]

    return result


def get_extension(group: str, name: str) -> Optional[Any]:
    """
    Get a specific extension by group and name.

    Args:
        group: Extension group (e.g., 'reasoners', 'backends')
        name: Extension name

    Returns:
        The extension class/function, or None if not found

    Example:
        >>> AudioReasoner = get_extension('reasoners', 'AudioReasoner')
    """
    # First check registry
    if group in _registry and name in _registry[group]:
        return _registry[group][name]

    # Try to discover it
    if group in ENTRY_POINT_GROUPS:
        ep_group = ENTRY_POINT_GROUPS[group]
        for ep in _get_entry_points(ep_group):
            if ep.name == name:
                try:
                    ext = ep.load()
                    _registry[group][name] = ext
                    return ext
                except Exception as e:
                    logger.warning(f"Failed to load {name}: {e}")
                    return None

    return None


def register(
    group: str,
    name: Optional[str] = None,
) -> Callable[[Type], Type]:
    """
    Decorator to manually register an extension.

    Use this for extensions defined in the same codebase,
    not via entry points.

    Args:
        group: Extension group
        name: Extension name (defaults to class name)

    Example:
        @register('reasoners')
        class MyCustomReasoner:
            pass

        @register('backends', name='my_backend')
        class MyBackend:
            pass
    """
    def decorator(cls: Type) -> Type:
        ext_name = name or cls.__name__
        _registry[group][ext_name] = cls
        _register_extension(group, ext_name, cls)
        return cls
    return decorator


def registered(group: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    """
    Get all registered extensions.

    Args:
        group: Specific group (None = all)

    Returns:
        Registry dict
    """
    if group:
        return {group: _registry.get(group, {})}
    return _registry.copy()


def clear_registry(group: Optional[str] = None) -> None:
    """Clear the extension registry (mainly for testing)."""
    global _discovered
    if group:
        _registry[group] = {}
    else:
        for g in _registry:
            _registry[g] = {}
        _discovered = False


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Discovery
    "discover",
    "list_extensions",
    "get_extension",
    # Registration
    "register",
    "registered",
    "clear_registry",
    # Constants
    "ENTRY_POINT_GROUPS",
]
