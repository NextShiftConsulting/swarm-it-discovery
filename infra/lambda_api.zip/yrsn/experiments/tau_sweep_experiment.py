"""
Tau Sweep Experiment - Empirically discover the α→τ relationship.

This experiment tests the theoretical temperature-quality duality by:
1. Binning data by quality α (from Cleanlab or similar)
2. Running tasks at fixed temperatures τ
3. Finding optimal τ* for each α bucket
4. Plotting to reveal: Linear? Or Phase Transition?

The Boltzmann Hypothesis:
    P(x) ∝ exp(-E(x)/τ)

    If true, we expect:
    - Low α (hard) → needs high τ (exploration)
    - High α (easy) → works with low τ (exploitation)

    The SHAPE of this curve tells us the physics:
    - Linear: τ* = a/α + b (simple inverse)
    - Hockey stick: Phase transition at critical α

Usage:
    from yrsn.experiments.tau_sweep_experiment import TauSweepExperiment

    exp = TauSweepExperiment()
    results = exp.run_sweep(data, quality_scores)
    exp.plot_results(results)
    exp.analyze_curve_shape(results)

Author: YRSN Framework (Rudy Martin)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional, Callable
import numpy as np
from collections import defaultdict


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class SweepResult:
    """Result of a single (α, τ) experiment."""
    alpha_bucket: str           # e.g., "0.8-0.9"
    alpha_mean: float           # Mean α in bucket
    tau: float                  # Temperature used
    success_rate: float         # Accuracy / success rate
    num_samples: int            # Number of samples in bucket
    mean_confidence: float      # Mean prediction confidence
    solve_time: float = 0.0     # Time to solve (if applicable)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OptimalTau:
    """Optimal temperature for a quality bucket."""
    alpha_bucket: str
    alpha_mean: float
    optimal_tau: float
    max_success_rate: float
    all_results: List[SweepResult]


@dataclass
class ExperimentResults:
    """Complete experiment results."""
    sweep_results: List[SweepResult]
    optimal_taus: List[OptimalTau]
    alpha_buckets: List[str]
    tau_values: List[float]
    curve_type: str = "unknown"  # "linear", "nonlinear", "phase_transition"
    phase_transition_alpha: Optional[float] = None


# =============================================================================
# TAU SWEEP EXPERIMENT
# =============================================================================

class TauSweepExperiment:
    """
    Runs the temperature sweep experiment to discover α→τ relationship.

    Protocol:
    1. Bin data by quality α
    2. For each bucket, run at multiple fixed τ values
    3. Find optimal τ* per bucket
    4. Analyze the curve shape
    """

    # Default quality buckets
    DEFAULT_ALPHA_BUCKETS = [
        (0.0, 0.2, "very_low"),
        (0.2, 0.4, "low"),
        (0.4, 0.6, "medium"),
        (0.6, 0.8, "high"),
        (0.8, 1.0, "very_high"),
    ]

    # Default temperature values to test
    DEFAULT_TAU_VALUES = [0.1, 0.3, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0]

    def __init__(
        self,
        alpha_buckets: Optional[List[Tuple[float, float, str]]] = None,
        tau_values: Optional[List[float]] = None,
        task_runner: Optional[Callable] = None,
    ):
        """
        Initialize experiment.

        Parameters
        ----------
        alpha_buckets : list of (min, max, name) tuples
            Quality buckets
        tau_values : list of floats
            Temperature values to test
        task_runner : callable
            Function that runs task and returns success (bool)
            Signature: task_runner(sample, tau) -> (success, confidence)
        """
        self.alpha_buckets = alpha_buckets or self.DEFAULT_ALPHA_BUCKETS
        self.tau_values = tau_values or self.DEFAULT_TAU_VALUES
        self.task_runner = task_runner or self._default_task_runner

    def _default_task_runner(
        self,
        sample: Any,
        tau: float
    ) -> Tuple[bool, float]:
        """
        Default task runner (simulates based on α and τ).

        In practice, replace with actual model/solver.

        The simulation models:
        - High α + low τ → high success (easy, greedy works)
        - Low α + low τ → low success (hard, greedy fails)
        - Low α + high τ → moderate success (hard, but exploring)
        """
        alpha = sample.get("alpha", 0.5) if isinstance(sample, dict) else 0.5

        # Simulate success probability
        # P(success) = α * exp(-(1-α)/τ)
        # This gives:
        # - High α, any τ → high P
        # - Low α, low τ → very low P
        # - Low α, high τ → moderate P

        base_prob = alpha
        exploration_bonus = 1 - np.exp(-(1 - alpha) / max(0.1, tau))

        prob = base_prob + (1 - base_prob) * exploration_bonus * 0.5
        prob = np.clip(prob, 0, 1)

        success = np.random.random() < prob
        confidence = prob

        return success, confidence

    def bin_data(
        self,
        samples: List[Any],
        quality_scores: List[float]
    ) -> Dict[str, List[Tuple[Any, float]]]:
        """
        Bin samples by quality score.

        Returns dict: bucket_name -> list of (sample, alpha)
        """
        binned = defaultdict(list)

        for sample, alpha in zip(samples, quality_scores):
            for min_a, max_a, name in self.alpha_buckets:
                if min_a <= alpha < max_a or (max_a == 1.0 and alpha == 1.0):
                    binned[name].append((sample, alpha))
                    break

        return dict(binned)

    def run_sweep(
        self,
        samples: List[Any],
        quality_scores: List[float],
        n_trials: int = 10,
        verbose: bool = True
    ) -> ExperimentResults:
        """
        Run the full tau sweep experiment.

        Parameters
        ----------
        samples : list
            Data samples
        quality_scores : list
            Quality score (α) for each sample
        n_trials : int
            Number of trials per (bucket, tau) pair
        verbose : bool
            Print progress

        Returns
        -------
        ExperimentResults
            Complete results with optimal τ per bucket
        """
        # Bin data
        binned = self.bin_data(samples, quality_scores)

        if verbose:
            print(f"Binned {len(samples)} samples into {len(binned)} buckets:")
            for name, items in binned.items():
                print(f"  {name}: {len(items)} samples")

        sweep_results = []

        # Run sweep for each bucket
        for bucket_name, bucket_samples in binned.items():
            if not bucket_samples:
                continue

            alpha_mean = np.mean([a for _, a in bucket_samples])

            if verbose:
                print(f"\nSweeping bucket '{bucket_name}' (ᾱ={alpha_mean:.2f})...")

            for tau in self.tau_values:
                successes = []
                confidences = []

                # Run multiple trials
                for _ in range(n_trials):
                    for sample, alpha in bucket_samples:
                        # Add alpha to sample for task runner
                        if isinstance(sample, dict):
                            sample["alpha"] = alpha
                        else:
                            sample = {"data": sample, "alpha": alpha}

                        success, conf = self.task_runner(sample, tau)
                        successes.append(success)
                        confidences.append(conf)

                result = SweepResult(
                    alpha_bucket=bucket_name,
                    alpha_mean=alpha_mean,
                    tau=tau,
                    success_rate=np.mean(successes),
                    num_samples=len(bucket_samples),
                    mean_confidence=np.mean(confidences),
                )
                sweep_results.append(result)

                if verbose:
                    print(f"  τ={tau:.1f}: success={result.success_rate:.2%}")

        # Find optimal τ for each bucket
        optimal_taus = self._find_optimal_taus(sweep_results)

        # Analyze curve shape
        curve_type, phase_alpha = self._analyze_curve(optimal_taus)

        return ExperimentResults(
            sweep_results=sweep_results,
            optimal_taus=optimal_taus,
            alpha_buckets=[name for _, _, name in self.alpha_buckets],
            tau_values=self.tau_values,
            curve_type=curve_type,
            phase_transition_alpha=phase_alpha,
        )

    def _find_optimal_taus(
        self,
        results: List[SweepResult]
    ) -> List[OptimalTau]:
        """Find optimal τ for each alpha bucket."""
        # Group by bucket
        by_bucket = defaultdict(list)
        for r in results:
            by_bucket[r.alpha_bucket].append(r)

        optimal = []
        for bucket, bucket_results in by_bucket.items():
            # Find τ with highest success rate
            best = max(bucket_results, key=lambda r: r.success_rate)

            optimal.append(OptimalTau(
                alpha_bucket=bucket,
                alpha_mean=best.alpha_mean,
                optimal_tau=best.tau,
                max_success_rate=best.success_rate,
                all_results=bucket_results,
            ))

        # Sort by alpha
        optimal.sort(key=lambda o: o.alpha_mean)
        return optimal

    def _analyze_curve(
        self,
        optimal_taus: List[OptimalTau]
    ) -> Tuple[str, Optional[float]]:
        """
        Analyze the shape of the α→τ* curve.

        Returns (curve_type, phase_transition_alpha)
        """
        if len(optimal_taus) < 3:
            return "insufficient_data", None

        alphas = np.array([o.alpha_mean for o in optimal_taus])
        taus = np.array([o.optimal_tau for o in optimal_taus])

        # Fit linear model: τ = a/α + b (inverse relationship)
        # Or equivalently: τ = m*α + c
        try:
            # Linear fit
            linear_coeffs = np.polyfit(alphas, taus, 1)
            linear_pred = np.polyval(linear_coeffs, alphas)
            linear_r2 = 1 - np.sum((taus - linear_pred)**2) / np.sum((taus - np.mean(taus))**2)

            # Inverse fit: τ = a/α + b
            # Fit: τ = a * (1/α) + b
            inv_alphas = 1 / np.clip(alphas, 0.1, 1.0)
            inv_coeffs = np.polyfit(inv_alphas, taus, 1)
            inv_pred = np.polyval(inv_coeffs, inv_alphas)
            inv_r2 = 1 - np.sum((taus - inv_pred)**2) / np.sum((taus - np.mean(taus))**2)

            # Check for phase transition (sudden jump)
            tau_diffs = np.diff(taus)
            alpha_diffs = np.diff(alphas)
            gradients = tau_diffs / np.clip(np.abs(alpha_diffs), 0.01, 1)

            max_gradient_idx = np.argmax(np.abs(gradients))
            max_gradient = np.abs(gradients[max_gradient_idx])
            mean_gradient = np.mean(np.abs(gradients))

            # Phase transition if max gradient >> mean gradient
            if max_gradient > 3 * mean_gradient:
                phase_alpha = alphas[max_gradient_idx + 1]
                return "phase_transition", float(phase_alpha)

            # Compare fits
            if inv_r2 > linear_r2 + 0.1:
                return "nonlinear_inverse", None
            elif linear_r2 > 0.8:
                return "linear", None
            else:
                return "nonlinear", None

        except Exception:
            return "analysis_failed", None

    def plot_results(
        self,
        results: ExperimentResults,
        save_path: Optional[str] = None
    ) -> None:
        """
        Plot the experiment results.

        Creates two plots:
        1. Heatmap: Success rate for each (α, τ) pair
        2. Curve: Optimal τ* vs α
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            print("matplotlib not available. Printing text results instead.")
            self._print_results(results)
            return

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # === Plot 1: Heatmap ===
        ax1 = axes[0]

        # Build heatmap matrix
        buckets = sorted(set(r.alpha_bucket for r in results.sweep_results))
        taus = sorted(set(r.tau for r in results.sweep_results))

        matrix = np.zeros((len(buckets), len(taus)))
        bucket_to_idx = {b: i for i, b in enumerate(buckets)}
        tau_to_idx = {t: i for i, t in enumerate(taus)}

        for r in results.sweep_results:
            i = bucket_to_idx[r.alpha_bucket]
            j = tau_to_idx[r.tau]
            matrix[i, j] = r.success_rate

        im = ax1.imshow(matrix, aspect='auto', cmap='RdYlGn', vmin=0, vmax=1)
        ax1.set_xticks(range(len(taus)))
        ax1.set_xticklabels([f"{t:.1f}" for t in taus])
        ax1.set_yticks(range(len(buckets)))
        ax1.set_yticklabels(buckets)
        ax1.set_xlabel("Temperature (τ)")
        ax1.set_ylabel("Quality Bucket (α)")
        ax1.set_title("Success Rate by (α, τ)")
        plt.colorbar(im, ax=ax1, label="Success Rate")

        # Mark optimal τ per bucket
        for opt in results.optimal_taus:
            if opt.alpha_bucket in bucket_to_idx and opt.optimal_tau in tau_to_idx:
                i = bucket_to_idx[opt.alpha_bucket]
                j = tau_to_idx[opt.optimal_tau]
                ax1.plot(j, i, 'k*', markersize=15, markeredgecolor='white')

        # === Plot 2: Optimal τ curve ===
        ax2 = axes[1]

        alphas = [o.alpha_mean for o in results.optimal_taus]
        opt_taus = [o.optimal_tau for o in results.optimal_taus]

        ax2.plot(alphas, opt_taus, 'bo-', markersize=10, linewidth=2, label="Optimal τ*")
        ax2.fill_between(alphas, opt_taus, alpha=0.3)

        # Add phase transition line if detected
        if results.phase_transition_alpha is not None:
            ax2.axvline(results.phase_transition_alpha, color='r', linestyle='--',
                       label=f"Phase transition (α={results.phase_transition_alpha:.2f})")

        ax2.set_xlabel("Quality (α)")
        ax2.set_ylabel("Optimal Temperature (τ*)")
        ax2.set_title(f"α → τ* Curve\n(Type: {results.curve_type})")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"Saved plot to {save_path}")
        else:
            plt.show()

    def _print_results(self, results: ExperimentResults) -> None:
        """Print results as text table."""
        print("\n" + "="*60)
        print("TAU SWEEP EXPERIMENT RESULTS")
        print("="*60)

        print(f"\nCurve Type: {results.curve_type}")
        if results.phase_transition_alpha:
            print(f"Phase Transition at α = {results.phase_transition_alpha:.2f}")

        print("\nOptimal τ per Quality Bucket:")
        print("-"*50)
        print(f"{'Bucket':<15} {'ᾱ':<8} {'τ*':<8} {'Success':<10}")
        print("-"*50)

        for opt in results.optimal_taus:
            print(f"{opt.alpha_bucket:<15} {opt.alpha_mean:<8.2f} "
                  f"{opt.optimal_tau:<8.1f} {opt.max_success_rate:<10.2%}")

    def quick_phase_test(
        self,
        hard_samples: List[Any],
        task_runner: Optional[Callable] = None,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        Quick "dirty" test for phase transition.

        Takes hard inputs (low α) and tests:
        - Low τ (0.1) → should fail
        - High τ (5.0) → should solve

        If switching point is sudden → phase transition evidence.
        """
        runner = task_runner or self.task_runner

        test_taus = [0.1, 0.3, 0.5, 1.0, 2.0, 3.0, 5.0]
        results = {}

        if verbose:
            print("Quick Phase Transition Test")
            print("="*40)

        for tau in test_taus:
            successes = []
            for sample in hard_samples:
                if isinstance(sample, dict):
                    sample["alpha"] = 0.2  # Force low alpha
                else:
                    sample = {"data": sample, "alpha": 0.2}

                success, _ = runner(sample, tau)
                successes.append(success)

            rate = np.mean(successes)
            results[tau] = rate

            if verbose:
                bar = "█" * int(rate * 20)
                print(f"τ={tau:<4.1f}: {rate:>6.1%} {bar}")

        # Find switching point
        rates = list(results.values())
        taus = list(results.keys())

        diffs = np.diff(rates)
        max_jump_idx = np.argmax(diffs)
        max_jump = diffs[max_jump_idx]

        switch_tau = taus[max_jump_idx + 1]

        if verbose:
            print("-"*40)
            if max_jump > 0.2:
                print(f"⚡ PHASE TRANSITION detected at τ ≈ {switch_tau}")
                print(f"   Jump magnitude: {max_jump:.1%}")
            else:
                print(f"📈 Gradual improvement (no sharp transition)")

        return {
            "results": results,
            "switch_tau": switch_tau,
            "max_jump": max_jump,
            "is_phase_transition": max_jump > 0.2,
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def run_experiment_from_cleanlab(
    dataframe,
    label_column: str = "label",
    quality_column: str = "label_quality",
    task_runner: Optional[Callable] = None,
    verbose: bool = True
) -> ExperimentResults:
    """
    Run tau sweep using Cleanlab quality scores from a DataFrame.

    Parameters
    ----------
    dataframe : pd.DataFrame
        Data with quality scores
    label_column : str
        Column with labels
    quality_column : str
        Column with quality scores (α)
    task_runner : callable
        Task function
    verbose : bool
        Print progress

    Returns
    -------
    ExperimentResults
    """
    samples = dataframe.to_dict('records')
    quality_scores = dataframe[quality_column].tolist()

    exp = TauSweepExperiment(task_runner=task_runner)
    return exp.run_sweep(samples, quality_scores, verbose=verbose)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("Tau Sweep Experiment - Demo")
    print("="*50)

    # Generate synthetic data
    np.random.seed(42)
    n_samples = 100

    # Quality scores from different "buckets"
    quality_scores = np.concatenate([
        np.random.uniform(0.1, 0.3, 20),   # Hard samples
        np.random.uniform(0.4, 0.6, 30),   # Medium samples
        np.random.uniform(0.7, 0.9, 50),   # Easy samples
    ])

    samples = [{"id": i, "alpha": q} for i, q in enumerate(quality_scores)]

    # Run experiment
    exp = TauSweepExperiment()
    results = exp.run_sweep(samples, quality_scores.tolist(), n_trials=5)

    # Print results
    exp._print_results(results)

    # Quick phase test
    print("\n")
    hard_samples = [s for s, q in zip(samples, quality_scores) if q < 0.3]
    exp.quick_phase_test(hard_samples)
