"""
YRSN-Enhanced Quantum Neural Network for Sudoku

This module implements a hybrid classical-quantum model that combines:
1. YRSN classical preprocessing (instruction boosting, entity registry, bit-slicing)
2. Variational Quantum Circuit (VQC) for reasoning
3. Classical post-processing heads

Architecture:
    YRSN Encoder (Classical) → Feature Compression → VQC → Output Heads

Quantum Frameworks Supported:
- PennyLane (default, runs locally)
- AWS Braket (via PennyLane-Braket plugin)

Requirements:
    pip install pennylane pennylane-lightning  # Local simulator
    pip install amazon-braket-pennylane-plugin  # Optional: AWS Braket

Why This Matters for YRSN:
- Proves Y=R+S+N signal decomposition is architecture-agnostic
- Works on recurrent (CTM/HRM), attention (Transformer), AND quantum (VQC)
- Same YRSN preprocessing benefits any computational substrate

Limitations (2025):
- Quantum advantage only theoretical for this task size
- Real QPUs are noisy; simulators are deterministic
- Best for 4x4 Sudoku (8-16 qubits); 9x9 would need 81+ qubits
"""

from typing import Tuple, Optional, List
from dataclasses import dataclass
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

# PennyLane imports (optional - graceful fallback)
try:
    import pennylane as qml
    from pennylane import numpy as pnp
    HAS_PENNYLANE = True
except ImportError:
    HAS_PENNYLANE = False
    qml = None
    pnp = None


@dataclass
class QuantumConfig:
    """Configuration for quantum circuit"""
    n_qubits: int = 8           # Number of qubits
    n_layers: int = 4           # Variational circuit depth
    device_type: str = "default.qubit"  # PennyLane device
    shots: Optional[int] = None  # None = exact simulation, int = sampling


class YRSNQuantumEncoder(nn.Module):
    """
    Classical encoder that compresses YRSN context to qubit-sized features.

    This is the key YRSN contribution: structured preprocessing that preserves
    R (truth) signal before passing to quantum circuit.

    Architecture:
        Full YRSN Encoding (384 dim) → Projection → n_qubits features → [0, π] normalization

    Encoder Protocol:
        The encoder must implement an `encode()` method that returns a dict with
        'combined_encoding' key containing a torch.Tensor of shape [seq_len, context_dim].

        Example from yrsn-sudoku:
            from yrsn_sudoku.encoders import IntegratedRulesAndConstraintsEncoder
            encoder = IntegratedRulesAndConstraintsEncoder(context_dim=64)
            quantum_encoder = YRSNQuantumEncoder(encoder=encoder, context_dim=64)
    """

    def __init__(
        self,
        encoder: Optional[nn.Module] = None,
        n_qubits: int = 8,
        context_dim: int = 64,
    ):
        super().__init__()
        self.n_qubits = n_qubits
        self.context_dim = context_dim

        # Store encoder (provided by application layer, e.g., yrsn-sudoku)
        # If None, forward() will raise an error when called
        self.yrsn_encoder = encoder

        # Project from context_dim to n_qubits
        # This compression must preserve R signal (most important features)
        self.projection = nn.Sequential(
            nn.Linear(context_dim, context_dim // 2),
            nn.LayerNorm(context_dim // 2),
            nn.GELU(),
            nn.Linear(context_dim // 2, n_qubits),
        )

        # Initialize projection to preserve variance
        self._init_weights()

    def _init_weights(self):
        for module in self.projection.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int,
        task_description: str = "Find the next logical deduction",
    ) -> torch.Tensor:
        """
        Encode puzzle to qubit-sized features.

        Requires an encoder to be provided at construction time.
        Install yrsn-sudoku for the IntegratedRulesAndConstraintsEncoder.

        Returns:
            features: [n_qubits] tensor normalized to [0, π] for angle embedding
        """
        if self.yrsn_encoder is None:
            raise RuntimeError(
                "YRSNQuantumEncoder.forward() requires an encoder. "
                "Install yrsn-sudoku and provide encoder at construction:\n"
                "  from yrsn_sudoku.encoders import IntegratedRulesAndConstraintsEncoder\n"
                "  encoder = IntegratedRulesAndConstraintsEncoder(context_dim=64)\n"
                "  quantum_encoder = YRSNQuantumEncoder(encoder=encoder, context_dim=64)"
            )
        # Full YRSN encoding (with boosting)
        encoding_dict = self.yrsn_encoder.encode(
            rules_text=rules_text,
            visual_elements_str=visual_elements_str,
            board_state=board_state,
            rows=rows,
            cols=cols,
            task_description=task_description,
        )

        # Extract combined encoding tensor
        # Shape: [seq_len, context_dim] or [context_dim]
        context = encoding_dict['combined_encoding']

        # Pool to single vector (mean over sequence if needed)
        if context.dim() > 1:
            pooled = context.mean(dim=0)  # [context_dim]
        else:
            pooled = context

        # Project to n_qubits
        features = self.projection(pooled)  # [n_qubits]

        # Normalize to [0, π] for angle embedding
        features = torch.sigmoid(features) * math.pi

        return features


def create_quantum_circuit(n_qubits: int, n_layers: int, device_type: str = "default.qubit"):
    """
    Create a variational quantum circuit for classification.

    Circuit structure:
    1. AngleEmbedding: Encode YRSN features as rotation angles
    2. StronglyEntanglingLayers: Variational ansatz with entanglement
    3. Measurements: Pauli-Z expectation values

    Returns:
        qnode: PennyLane QNode for the circuit
        weight_shape: Shape of trainable weights
    """
    if not HAS_PENNYLANE:
        raise ImportError(
            "PennyLane required for quantum models. "
            "Install with: pip install pennylane pennylane-lightning"
        )

    # Create device
    dev = qml.device(device_type, wires=n_qubits)

    # Weight shape for StronglyEntanglingLayers
    weight_shape = qml.StronglyEntanglingLayers.shape(n_layers=n_layers, n_wires=n_qubits)

    @qml.qnode(dev, interface="torch", diff_method="backprop")
    def circuit(features: torch.Tensor, weights: torch.Tensor) -> List[torch.Tensor]:
        """
        Variational quantum classifier circuit.

        Args:
            features: [n_qubits] YRSN-encoded features (angles in [0, π])
            weights: [n_layers, n_qubits, 3] trainable rotation angles

        Returns:
            List of Pauli-Z expectation values for each qubit
        """
        # 1. Encode YRSN features into quantum state
        # AngleEmbedding applies RY rotations
        qml.AngleEmbedding(features, wires=range(n_qubits), rotation='Y')

        # 2. Variational layers (trainable)
        # StronglyEntanglingLayers: Rz-Ry-Rz rotations + CNOT entanglement
        qml.StronglyEntanglingLayers(weights, wires=range(n_qubits))

        # 3. Measure all qubits
        return [qml.expval(qml.PauliZ(i)) for i in range(n_qubits)]

    return circuit, weight_shape


class QuantumLayer(nn.Module):
    """
    PyTorch-compatible quantum layer.

    Wraps PennyLane QNode as a torch.nn.Module for seamless integration.
    """

    def __init__(self, n_qubits: int, n_layers: int, device_type: str = "default.qubit"):
        super().__init__()
        self.n_qubits = n_qubits
        self.n_layers = n_layers

        # Create circuit
        self.circuit, weight_shape = create_quantum_circuit(n_qubits, n_layers, device_type)

        # Trainable weights
        self.weights = nn.Parameter(
            torch.randn(weight_shape) * 0.1  # Small init for stability
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through quantum circuit.

        Args:
            features: [n_qubits] or [batch, n_qubits] features

        Returns:
            outputs: [n_qubits] or [batch, n_qubits] measurement results
        """
        # Handle batched input
        if features.dim() == 1:
            # Single sample
            outputs = self.circuit(features, self.weights)
            return torch.stack(outputs)
        else:
            # Batched - process each sample
            batch_outputs = []
            for i in range(features.shape[0]):
                outputs = self.circuit(features[i], self.weights)
                batch_outputs.append(torch.stack(outputs))
            return torch.stack(batch_outputs)


class YRSNQuantumSudoku(nn.Module):
    """
    Complete YRSN-Enhanced Quantum Model for Sudoku.

    Architecture:
        Input (rules, board, task)
            ↓
        YRSN Encoder (classical) - instruction boost, entity registry
            ↓  [n_qubits features]
        Variational Quantum Circuit - angle embedding + entangling layers
            ↓  [n_qubits measurements]
        Output Heads (classical) - position + digit prediction

    This proves YRSN's Y=R+S+N principle works for quantum circuits:
    - Without YRSN: quantum circuit learns noise/structure (S+N)
    - With YRSN: quantum circuit learns truth (R)
    """

    def __init__(
        self,
        puzzle_size: str = "4x4",
        n_qubits: int = 8,
        n_layers: int = 4,
        context_dim: int = 64,
        instruction_boost: float = 3.73,
        task_boost: float = 3.73,
        device_type: str = "default.qubit",
    ):
        super().__init__()

        # Parse puzzle size
        if puzzle_size == "4x4":
            self.rows, self.cols = 4, 4
            self.num_positions = 16
            self.num_digits = 4
        elif puzzle_size == "6x6":
            self.rows, self.cols = 6, 6
            self.num_positions = 36
            self.num_digits = 6
        elif puzzle_size == "9x9":
            self.rows, self.cols = 9, 9
            self.num_positions = 81
            self.num_digits = 9
        else:
            raise ValueError(f"Unsupported puzzle size: {puzzle_size}")

        self.puzzle_size = puzzle_size
        self.n_qubits = n_qubits
        self.n_layers = n_layers

        # YRSN classical encoder
        self.yrsn_encoder = YRSNQuantumEncoder(
            n_qubits=n_qubits,
            context_dim=context_dim,
            instruction_boost=instruction_boost,
            task_boost=task_boost,
        )

        # Quantum layer
        if HAS_PENNYLANE:
            self.quantum_layer = QuantumLayer(n_qubits, n_layers, device_type)
        else:
            # Fallback: classical simulation of quantum behavior
            print("Warning: PennyLane not installed. Using classical fallback.")
            self.quantum_layer = nn.Sequential(
                nn.Linear(n_qubits, n_qubits * 2),
                nn.Tanh(),  # Simulate bounded quantum output [-1, 1]
                nn.Linear(n_qubits * 2, n_qubits),
                nn.Tanh(),
            )

        # Classical output heads
        self.position_head = nn.Sequential(
            nn.Linear(n_qubits, n_qubits * 2),
            nn.GELU(),
            nn.Linear(n_qubits * 2, self.num_positions),
        )

        self.digit_head = nn.Sequential(
            nn.Linear(n_qubits, n_qubits * 2),
            nn.GELU(),
            nn.Linear(n_qubits * 2, self.num_digits),
        )

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        task_description: str = "Find the next logical deduction",
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass: puzzle → YRSN → quantum → prediction

        Args:
            rules_text: Sudoku rules (will be boosted)
            visual_elements_str: Visual constraints JSON
            board_state: Current board state
            task_description: Task description (will be boosted)

        Returns:
            position_logits: [num_positions] position prediction
            digit_logits: [num_digits] digit prediction
        """
        # 1. YRSN encoding (classical preprocessing)
        features = self.yrsn_encoder(
            rules_text=rules_text,
            visual_elements_str=visual_elements_str,
            board_state=board_state,
            rows=self.rows,
            cols=self.cols,
            task_description=task_description,
        )

        # 2. Quantum processing
        quantum_out = self.quantum_layer(features)  # [n_qubits] in [-1, 1]

        # Ensure float32 (PennyLane may return float64)
        quantum_out = quantum_out.float()

        # 3. Classical output heads
        position_logits = self.position_head(quantum_out)
        digit_logits = self.digit_head(quantum_out)

        # Add batch dimension if needed
        if position_logits.dim() == 1:
            position_logits = position_logits.unsqueeze(0)
            digit_logits = digit_logits.unsqueeze(0)

        return position_logits, digit_logits

    def count_parameters(self) -> dict:
        """Count parameters by component"""
        classical_params = sum(
            p.numel() for n, p in self.named_parameters()
            if 'quantum_layer.weights' not in n
        )

        quantum_params = 0
        if hasattr(self.quantum_layer, 'weights'):
            quantum_params = self.quantum_layer.weights.numel()

        return {
            'classical': classical_params,
            'quantum': quantum_params,
            'total': classical_params + quantum_params,
        }


class VanillaQuantumSudoku(nn.Module):
    """
    Vanilla Quantum Model WITHOUT YRSN enhancements.

    Used as baseline to show YRSN helps quantum circuits too.

    Key differences from YRSNQuantumSudoku:
    - No instruction boosting (rules treated equally)
    - No entity registry (no keyword emphasis)
    - Simple embedding (no structured YRSN encoding)
    """

    def __init__(
        self,
        puzzle_size: str = "4x4",
        n_qubits: int = 8,
        n_layers: int = 4,
        device_type: str = "default.qubit",
    ):
        super().__init__()

        # Parse puzzle size
        if puzzle_size == "4x4":
            self.rows, self.cols = 4, 4
            self.num_positions = 16
            self.num_digits = 4
        elif puzzle_size == "6x6":
            self.rows, self.cols = 6, 6
            self.num_positions = 36
            self.num_digits = 6
        else:
            raise ValueError(f"Vanilla quantum only supports 4x4, 6x6")

        self.puzzle_size = puzzle_size
        self.n_qubits = n_qubits

        # Simple board encoder (NO YRSN)
        # Just encode board state directly
        self.board_encoder = nn.Sequential(
            nn.Linear(self.num_positions * 10, 64),  # One-hot digits
            nn.GELU(),
            nn.Linear(64, n_qubits),
        )

        # Quantum layer
        if HAS_PENNYLANE:
            self.quantum_layer = QuantumLayer(n_qubits, n_layers, device_type)
        else:
            self.quantum_layer = nn.Sequential(
                nn.Linear(n_qubits, n_qubits * 2),
                nn.Tanh(),
                nn.Linear(n_qubits * 2, n_qubits),
                nn.Tanh(),
            )

        # Output heads
        self.position_head = nn.Linear(n_qubits, self.num_positions)
        self.digit_head = nn.Linear(n_qubits, self.num_digits)

    def _encode_board(self, board_state: str) -> torch.Tensor:
        """Simple one-hot board encoding (no YRSN)"""
        # Parse board state
        cells = []
        for char in board_state:
            if char == '.':
                cells.append(0)
            elif char.isdigit():
                cells.append(int(char))

        # Pad/truncate to expected size
        while len(cells) < self.num_positions:
            cells.append(0)
        cells = cells[:self.num_positions]

        # One-hot encode (0-9 for each cell)
        one_hot = torch.zeros(self.num_positions, 10, dtype=torch.float32)
        for i, val in enumerate(cells):
            one_hot[i, val] = 1.0

        return one_hot.flatten()  # [num_positions * 10]

    def forward(
        self,
        rules_text: str,  # IGNORED in vanilla
        visual_elements_str: str,  # IGNORED in vanilla
        board_state: str,
        task_description: str = "",  # IGNORED in vanilla
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass WITHOUT YRSN enhancements.

        Note: rules_text and task_description are ignored!
        This is the problem YRSN solves.
        """
        # Simple board encoding (no boosting, no entity registry)
        board_encoded = self._encode_board(board_state)

        # Project to qubits
        features = self.board_encoder(board_encoded)
        features = torch.sigmoid(features) * math.pi  # [0, π]

        # Quantum processing
        quantum_out = self.quantum_layer(features)

        # Ensure float32 (PennyLane may return float64)
        quantum_out = quantum_out.float()

        # Output
        position_logits = self.position_head(quantum_out).unsqueeze(0)
        digit_logits = self.digit_head(quantum_out).unsqueeze(0)

        return position_logits, digit_logits


def check_pennylane_installation():
    """Check if PennyLane is properly installed"""
    if not HAS_PENNYLANE:
        print("=" * 60)
        print("PennyLane not installed!")
        print()
        print("To use quantum models, install PennyLane:")
        print("  pip install pennylane pennylane-lightning")
        print()
        print("For AWS Braket support:")
        print("  pip install amazon-braket-pennylane-plugin")
        print("=" * 60)
        return False

    # Test basic functionality
    try:
        dev = qml.device("default.qubit", wires=2)

        @qml.qnode(dev)
        def test_circuit():
            qml.Hadamard(wires=0)
            qml.CNOT(wires=[0, 1])
            return qml.expval(qml.PauliZ(0))

        result = test_circuit()
        print(f"PennyLane OK: test circuit returned {result:.4f}")
        return True
    except Exception as e:
        print(f"PennyLane error: {e}")
        return False


if __name__ == "__main__":
    # Quick test
    print("Testing YRSN Quantum Models")
    print("=" * 60)

    # Check PennyLane
    has_pennylane = check_pennylane_installation()

    if has_pennylane:
        # Test YRSN-enhanced quantum model
        print("\nTesting YRSNQuantumSudoku (4x4)...")
        model = YRSNQuantumSudoku(
            puzzle_size="4x4",
            n_qubits=8,
            n_layers=4,
        )

        params = model.count_parameters()
        print(f"Parameters: {params}")

        # Test forward pass
        pos, dig = model(
            rules_text="Normal 4x4 sudoku rules apply",
            visual_elements_str="[]",
            board_state="1.3..2...4...",
            task_description="Find the next logical deduction",
        )

        print(f"Position logits shape: {pos.shape}")
        print(f"Digit logits shape: {dig.shape}")
        print(f"Predicted position: {pos.argmax(dim=1).item()}")
        print(f"Predicted digit: {dig.argmax(dim=1).item() + 1}")

        print("\nYRSN Quantum model OK!")
    else:
        print("\nSkipping quantum tests (PennyLane not installed)")
        print("Classical fallback will be used in training.")
