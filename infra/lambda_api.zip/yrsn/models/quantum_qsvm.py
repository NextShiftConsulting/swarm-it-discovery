"""
YRSN-Enhanced Quantum Support Vector Machine (QSVM) for Sudoku

Implements QSVM using quantum kernels with YRSN preprocessing.

Architecture:
    Input (rules, board, task)
        ↓
    YRSN Encoder (classical) - instruction boost, entity registry
        ↓  [n_qubits features]
    Quantum Kernel - maps to quantum feature space
        ↓  [kernel matrix]
    Classical SVM - classification
        ↓
    Position + Digit prediction

This demonstrates YRSN works with kernel-based quantum ML, not just variational circuits.

References:
    - Havlíček et al. (2019): "Supervised learning with quantum-enhanced feature spaces"
    - Schuld & Killoran (2019): "Quantum machine learning in feature Hilbert spaces"
"""

from typing import Tuple, Optional, List
import numpy as np
import torch
import torch.nn as nn

# PennyLane imports (optional - graceful fallback)
try:
    import pennylane as qml
    HAS_PENNYLANE = True
except ImportError:
    HAS_PENNYLANE = False
    qml = None

# scikit-learn for SVM
try:
    from sklearn.svm import SVC
    from sklearn.multioutput import MultiOutputClassifier
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    SVC = None
    MultiOutputClassifier = None

# Import YRSN quantum kernel
try:
    from yrsn.quantum.kernels import YRSNQuantumKernel, create_yrsn_quantum_kernel
    HAS_QUANTUM_KERNELS = True
except ImportError:
    HAS_QUANTUM_KERNELS = False


class YRSNQSVM:
    """
    Quantum Support Vector Machine with YRSN preprocessing.
    
    This combines:
    1. YRSN classical preprocessing (instruction boosting, entity registry)
    2. Quantum kernel computation (maps to quantum feature space)
    3. Classical SVM (kernel-based classification)
    
    Key advantage over VQC:
    - No barren plateaus (different optimization landscape)
    - Theoretical foundation (kernel methods well-understood)
    - Can use any kernel-based ML method (SVM, KRR, etc.)
    """
    
    def __init__(
        self,
        puzzle_size: str = "4x4",
        n_qubits: int = 8,
        feature_map_type: str = "angle",
        kernel_reps: int = 2,
        svm_C: float = 1.0,
        context_dim: int = 64,
        instruction_boost: float = 3.73,
        task_boost: float = 3.73,
    ):
        """
        Initialize YRSN QSVM.
        
        Args:
            puzzle_size: "4x4", "6x6", or "9x9"
            n_qubits: Number of qubits for quantum kernel
            feature_map_type: "angle" (simpler) or "zz" (more expressive)
            kernel_reps: Repetitions for ZZ feature map
            svm_C: SVM regularization parameter
            context_dim: YRSN encoder dimension
            instruction_boost: YRSN instruction boost factor
            task_boost: YRSN task boost factor
        """
        if not HAS_PENNYLANE:
            raise ImportError(
                "PennyLane required for QSVM. Install with: pip install pennylane pennylane-lightning"
            )
        if not HAS_SKLEARN:
            raise ImportError(
                "scikit-learn required for QSVM. Install with: pip install scikit-learn"
            )
        if not HAS_QUANTUM_KERNELS:
            raise ImportError(
                "Quantum kernels module required. Ensure yrsn_context.quantum.kernels is available."
            )
        
        # Parse puzzle size
        if puzzle_size == "4x4":
            self.rows, self.cols = 4, 4
            self.num_positions = 16
            self.num_digits = 4
        elif puzzle_size == "6x6":
            self.rows, self.cols = 6, 6
            self.num_positions = 36
            self.num_digits = 6
        elif puzzle_size == "9x9":
            self.rows, self.cols = 9, 9
            self.num_positions = 81
            self.num_digits = 9
        else:
            raise ValueError(f"Unsupported puzzle size: {puzzle_size}")
        
        self.puzzle_size = puzzle_size
        self.n_qubits = n_qubits
        
        # YRSN encoder (same as VQC version)
        from yrsn.models.quantum import YRSNQuantumEncoder
        
        self.yrsn_encoder = YRSNQuantumEncoder(
            n_qubits=n_qubits,
            context_dim=context_dim,
            instruction_boost=instruction_boost,
            task_boost=task_boost,
        )
        
        # Quantum kernel
        self.quantum_kernel = create_yrsn_quantum_kernel(
            n_qubits=n_qubits,
            feature_map_type=feature_map_type,
            reps=kernel_reps,
        )
        
        # SVM classifiers (one for position, one for digit)
        self.position_svm = SVC(kernel='precomputed', C=svm_C, probability=True)
        self.digit_svm = SVC(kernel='precomputed', C=svm_C, probability=True)
        
        # Training data cache
        self.X_train_encoded = None
        self.K_train = None
        self.is_fitted = False
    
    def encode_puzzle(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        task_description: str = "Find the next logical deduction",
    ) -> np.ndarray:
        """
        Encode puzzle using YRSN preprocessing.
        
        Returns:
            Encoded features as numpy array [n_qubits]
        """
        with torch.no_grad():
            features = self.yrsn_encoder(
                rules_text=rules_text,
                visual_elements_str=visual_elements_str,
                board_state=board_state,
                rows=self.rows,
                cols=self.cols,
                task_description=task_description,
            )
        
        # Convert to numpy
        if isinstance(features, torch.Tensor):
            features = features.detach().cpu().numpy().flatten()
        
        return features
    
    def fit(
        self,
        puzzles: List[dict],
        verbose: bool = False,
    ):
        """
        Train QSVM on puzzles.
        
        Args:
            puzzles: List of puzzle dicts with keys:
                - 'initial_board': board state string
                - 'rules': rules text
                - 'visual_elements': visual elements JSON string
                - 'solution': solution string (for labels)
            verbose: Print progress
        """
        if verbose:
            print(f"Training YRSN QSVM on {len(puzzles)} puzzles...")
        
        # Encode all puzzles with YRSN
        if verbose:
            print("  Encoding puzzles with YRSN...")
        
        X_encoded = []
        y_position = []
        y_digit = []
        
        for i, puzzle in enumerate(puzzles):
            if verbose and (i + 1) % 10 == 0:
                print(f"    Encoded {i + 1}/{len(puzzles)}")
            
            # Encode puzzle
            features = self.encode_puzzle(
                rules_text=puzzle.get('rules', ''),
                visual_elements_str=puzzle.get('visual_elements', '[]'),
                board_state=puzzle.get('initial_board', ''),
            )
            X_encoded.append(features)
            
            # Extract labels (first move from solution)
            solution = puzzle.get('solution', '')
            if solution:
                # Find first empty cell in initial board
                initial = puzzle.get('initial_board', '')
                for j, char in enumerate(initial):
                    if char == '.' or char == '0':
                        # Get digit from solution
                        digit = int(solution[j]) if j < len(solution) and solution[j].isdigit() else 1
                        y_position.append(j)
                        y_digit.append(digit - 1)  # 0-indexed
                        break
                else:
                    # No empty cells, use defaults
                    y_position.append(0)
                    y_digit.append(0)
            else:
                y_position.append(0)
                y_digit.append(0)
        
        self.X_train_encoded = X_encoded
        
        # Compute quantum kernel matrix
        if verbose:
            print("  Computing quantum kernel matrix...")
        
        self.K_train = self.quantum_kernel.compute_kernel_matrix(X_encoded, verbose=verbose)
        
        # Train SVMs
        if verbose:
            print("  Training position SVM...")
        self.position_svm.fit(self.K_train, y_position)
        
        if verbose:
            print("  Training digit SVM...")
        self.digit_svm.fit(self.K_train, y_digit)
        
        self.is_fitted = True
        
        if verbose:
            print("  Training complete!")
    
    def predict(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        task_description: str = "Find the next logical deduction",
    ) -> Tuple[int, int, float]:
        """
        Predict next cell placement.
        
        Args:
            rules_text: Sudoku rules
            visual_elements_str: Visual constraints JSON
            board_state: Current board state
            task_description: Task description
        
        Returns:
            (position, digit, confidence)
            - position: 0-indexed cell position
            - digit: digit value (1-9 for 9x9, etc.)
            - confidence: prediction confidence (0-1)
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction. Call fit() first.")
        
        # Encode puzzle
        x_test = self.encode_puzzle(
            rules_text=rules_text,
            visual_elements_str=visual_elements_str,
            board_state=board_state,
            task_description=task_description,
        )
        
        # Compute kernel between test and all training samples
        K_test = np.zeros((1, len(self.X_train_encoded)))
        for j, x_train in enumerate(self.X_train_encoded):
            K_test[0, j] = self.quantum_kernel.kernel(x_test, x_train)
        
        # Predict position
        pos_pred = self.position_svm.predict(K_test)[0]
        pos_probs = self.position_svm.predict_proba(K_test)[0]
        pos_conf = pos_probs[pos_pred] if pos_pred < len(pos_probs) else 0.5
        
        # Predict digit
        dig_pred = self.digit_svm.predict(K_test)[0]
        dig_probs = self.digit_svm.predict_proba(K_test)[0]
        dig_conf = dig_probs[dig_pred] if dig_pred < len(dig_probs) else 0.5
        
        # Mask to empty cells
        empty_mask = np.zeros(self.num_positions)
        for i, char in enumerate(board_state[:self.num_positions]):
            if char == '.' or char == '0':
                empty_mask[i] = 1.0
        
        # Adjust position if predicted filled cell
        if empty_mask[pos_pred] == 0:
            # Find first empty cell
            empty_indices = np.where(empty_mask == 1.0)[0]
            if len(empty_indices) > 0:
                pos_pred = empty_indices[0]
            else:
                pos_pred = 0
        
        # Convert digit from 0-indexed to 1-indexed
        digit = dig_pred + 1
        
        # Combined confidence
        confidence = (pos_conf * dig_conf) ** 0.5
        
        return int(pos_pred), int(digit), float(confidence)


class VanillaQSVM:
    """
    Vanilla QSVM WITHOUT YRSN preprocessing.
    
    Baseline to show YRSN helps quantum kernels too.
    Uses simple board encoding (no rules, no YRSN).
    """
    
    def __init__(
        self,
        puzzle_size: str = "4x4",
        n_qubits: int = 8,
        feature_map_type: str = "angle",
        svm_C: float = 1.0,
    ):
        """Initialize vanilla QSVM (no YRSN)."""
        if not HAS_PENNYLANE or not HAS_SKLEARN or not HAS_QUANTUM_KERNELS:
            raise ImportError("PennyLane, scikit-learn, and quantum kernels required")
        
        # Parse puzzle size
        if puzzle_size == "4x4":
            self.num_positions = 16
            self.num_digits = 4
        elif puzzle_size == "6x6":
            self.num_positions = 36
            self.num_digits = 6
        else:
            raise ValueError(f"Vanilla QSVM only supports 4x4, 6x6")
        
        self.puzzle_size = puzzle_size
        self.n_qubits = n_qubits
        
        # Simple board encoder (NO YRSN)
        self.board_encoder = nn.Sequential(
            nn.Linear(self.num_positions * 10, 64),
            nn.GELU(),
            nn.Linear(64, n_qubits),
        )
        
        # Quantum kernel
        self.quantum_kernel = create_yrsn_quantum_kernel(
            n_qubits=n_qubits,
            feature_map_type=feature_map_type,
        )
        
        # SVMs
        self.position_svm = SVC(kernel='precomputed', C=svm_C, probability=True)
        self.digit_svm = SVC(kernel='precomputed', C=svm_C, probability=True)
        
        self.X_train_encoded = None
        self.K_train = None
        self.is_fitted = False
    
    def _encode_board(self, board_state: str) -> np.ndarray:
        """Simple board encoding (no YRSN, no rules)."""
        # One-hot encode board
        cells = []
        for char in board_state[:self.num_positions]:
            if char == '.':
                cells.append(0)
            elif char.isdigit():
                cells.append(int(char))
            else:
                cells.append(0)
        
        # Pad/truncate
        while len(cells) < self.num_positions:
            cells.append(0)
        cells = cells[:self.num_positions]
        
        # One-hot encode (0-9 for each cell)
        one_hot = np.zeros((self.num_positions, 10))
        for i, val in enumerate(cells):
            one_hot[i, val] = 1.0
        
        # Encode with simple MLP
        board_tensor = torch.tensor(one_hot.flatten(), dtype=torch.float32)
        with torch.no_grad():
            encoded = self.board_encoder(board_tensor)
            encoded = torch.sigmoid(encoded) * np.pi  # [0, π]
        
        return encoded.detach().cpu().numpy()
    
    def fit(self, puzzles: List[dict], verbose: bool = False):
        """Train vanilla QSVM (no YRSN)."""
        if verbose:
            print(f"Training Vanilla QSVM on {len(puzzles)} puzzles...")
        
        X_encoded = []
        y_position = []
        y_digit = []
        
        for puzzle in puzzles:
            # Simple board encoding (ignore rules!)
            features = self._encode_board(puzzle.get('initial_board', ''))
            X_encoded.append(features)
            
            # Extract labels (same as YRSN version)
            solution = puzzle.get('solution', '')
            initial = puzzle.get('initial_board', '')
            for j, char in enumerate(initial):
                if char == '.' or char == '0':
                    digit = int(solution[j]) if j < len(solution) and solution[j].isdigit() else 1
                    y_position.append(j)
                    y_digit.append(digit - 1)
                    break
            else:
                y_position.append(0)
                y_digit.append(0)
        
        self.X_train_encoded = X_encoded
        
        # Compute kernel matrix
        if verbose:
            print("  Computing quantum kernel matrix...")
        self.K_train = self.quantum_kernel.compute_kernel_matrix(X_encoded, verbose=verbose)
        
        # Train SVMs
        self.position_svm.fit(self.K_train, y_position)
        self.digit_svm.fit(self.K_train, y_digit)
        
        self.is_fitted = True
    
    def predict(
        self,
        rules_text: str,  # IGNORED
        visual_elements_str: str,  # IGNORED
        board_state: str,
        task_description: str = "",  # IGNORED
    ) -> Tuple[int, int, float]:
        """Predict (ignores rules and task - this is what YRSN solves)."""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction.")
        
        # Simple encoding (no YRSN, no rules)
        x_test = self._encode_board(board_state)
        
        # Compute kernel
        K_test = np.zeros((1, len(self.X_train_encoded)))
        for j, x_train in enumerate(self.X_train_encoded):
            K_test[0, j] = self.quantum_kernel.kernel(x_test, x_train)
        
        # Predict
        pos_pred = self.position_svm.predict(K_test)[0]
        pos_probs = self.position_svm.predict_proba(K_test)[0]
        pos_conf = pos_probs[pos_pred] if pos_pred < len(pos_probs) else 0.5
        
        dig_pred = self.digit_svm.predict(K_test)[0]
        dig_probs = self.digit_svm.predict_proba(K_test)[0]
        dig_conf = dig_probs[dig_pred] if dig_pred < len(dig_probs) else 0.5
        
        # Mask to empty cells
        empty_mask = np.zeros(self.num_positions)
        for i, char in enumerate(board_state[:self.num_positions]):
            if char == '.' or char == '0':
                empty_mask[i] = 1.0
        
        if empty_mask[pos_pred] == 0:
            empty_indices = np.where(empty_mask == 1.0)[0]
            pos_pred = empty_indices[0] if len(empty_indices) > 0 else 0
        
        digit = dig_pred + 1
        confidence = (pos_conf * dig_conf) ** 0.5
        
        return int(pos_pred), int(digit), float(confidence)


# Export
__all__ = [
    "YRSNQSVM",
    "VanillaQSVM",
]

