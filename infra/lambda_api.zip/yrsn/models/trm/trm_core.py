"""
TRM Core - Thinking Recurrence Machine

This is the generic TRM architecture, domain-agnostic.

Architecture:
    For each recursion step t:
        z_{t+1} = f_z(x, y_t, z_t)    # reasoning latent update
        y_{t+1} = f_y(y_t, z_{t+1})   # state update

    Run this T times.

Loss Heads:
    - Attached to specific intermediate activations
    - Different weights at different training phases
    - NOT separate systems, just different supervision signals

Phase → Loss Schedule:
    Phase 1: L_rule + L_constraint on z_early
    Phase 2: L_breakin + L_sparse on z_mid
    Phase 3: L_move + L_yrsn on y_mid
    Phase 4: L_final + L_halt on y_T, z_T

Based on Samsung TRM (Less is More, arXiv:2510.04871).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum, auto


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class TRMConfig:
    """Configuration for TRM."""
    hidden_size: int = 256
    num_steps: int = 5
    num_positions: int = 81          # Generic: number of positions (cells for Sudoku)
    num_values: int = 9              # Generic: number of output values per position
    vocab_size: int = 10000
    num_heads: int = 8
    dropout: float = 0.1
    intermediate_size: int = 512

    # For backwards compatibility
    @property
    def num_cells(self) -> int:
        return self.num_positions

    @property
    def num_digits(self) -> int:
        return self.num_values


class TrainingPhase(Enum):
    """Training phases - just loss weight schedules."""
    PHASE_1 = 1  # z_early supervision
    PHASE_2 = 2  # z_mid supervision
    PHASE_3 = 3  # y_mid supervision
    PHASE_4 = 4  # y_T, z_T supervision


# =============================================================================
# Core TRM Computation
# =============================================================================

class ReasoningUpdate(nn.Module):
    """
    f_z: reasoning latent update

    z_{t+1} = f_z(x, y_t, z_t)

    This learns to:
    - Encode constraint structure (phase 1)
    - Find leverage points (phase 2)
    """

    def __init__(self, config: TRMConfig):
        super().__init__()
        self.config = config
        H = config.hidden_size

        # Cross-attention to input x
        self.cross_attn = nn.MultiheadAttention(
            H, config.num_heads, dropout=config.dropout, batch_first=True
        )

        # Self-attention over z
        self.self_attn = nn.MultiheadAttention(
            H, config.num_heads, dropout=config.dropout, batch_first=True
        )

        # Gated update from y
        self.y_gate = nn.Sequential(
            nn.Linear(H * 2, H),
            nn.Sigmoid()
        )
        self.y_proj = nn.Linear(H, H)

        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(H, config.intermediate_size),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.intermediate_size, H),
            nn.Dropout(config.dropout),
        )

        self.norm1 = nn.LayerNorm(H)
        self.norm2 = nn.LayerNorm(H)
        self.norm3 = nn.LayerNorm(H)
        self.norm4 = nn.LayerNorm(H)

    def forward(
        self,
        x: torch.Tensor,     # [B, L, H] encoded input
        y: torch.Tensor,     # [B, C, H] current state
        z: torch.Tensor,     # [B, S, H] current reasoning latent
    ) -> torch.Tensor:
        """
        Update reasoning latent.

        Returns:
            z_new: [B, S, H] updated reasoning latent
        """
        # Self-attention over z
        z_norm = self.norm1(z)
        z_self, _ = self.self_attn(z_norm, z_norm, z_norm)
        z = z + z_self

        # Cross-attention to input
        z_norm = self.norm2(z)
        z_cross, _ = self.cross_attn(z_norm, x, x)
        z = z + z_cross

        # Gated update from state y
        y_pooled = y.mean(dim=1, keepdim=True).expand(-1, z.shape[1], -1)
        gate = self.y_gate(torch.cat([z, y_pooled], dim=-1))
        z = z + gate * self.y_proj(y_pooled)

        # FFN
        z_norm = self.norm3(z)
        z = z + self.ffn(z_norm)

        return self.norm4(z)


class StateUpdate(nn.Module):
    """
    f_y: state update

    y_{t+1} = f_y(y_t, z_{t+1})

    This learns to:
    - Score moves (phase 3)
    - Refine final state (phase 4)
    """

    def __init__(self, config: TRMConfig):
        super().__init__()
        self.config = config
        H = config.hidden_size

        # Attention from z to y
        self.cross_attn = nn.MultiheadAttention(
            H, config.num_heads, dropout=config.dropout, batch_first=True
        )

        # Self-attention over y (positions)
        self.self_attn = nn.MultiheadAttention(
            H, config.num_heads, dropout=config.dropout, batch_first=True
        )

        # FFN for state refinement
        self.ffn = nn.Sequential(
            nn.Linear(H, config.intermediate_size),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.intermediate_size, H),
            nn.Dropout(config.dropout),
        )

        self.norm1 = nn.LayerNorm(H)
        self.norm2 = nn.LayerNorm(H)
        self.norm3 = nn.LayerNorm(H)

    def forward(
        self,
        y: torch.Tensor,     # [B, C, H] current state
        z: torch.Tensor,     # [B, S, H] reasoning latent
    ) -> torch.Tensor:
        """
        Update state.

        Returns:
            y_new: [B, C, H] updated state
        """
        # Cross-attention from reasoning
        y_norm = self.norm1(y)
        y_cross, _ = self.cross_attn(y_norm, z, z)
        y = y + y_cross

        # Self-attention over positions
        y_norm = self.norm2(y)
        y_self, _ = self.self_attn(y_norm, y_norm, y_norm)
        y = y + y_self

        # FFN
        y_norm = self.norm3(y)
        y = y + self.ffn(y_norm)

        return y


# Alias for backwards compatibility
BoardUpdate = StateUpdate


# =============================================================================
# Generic Loss Heads - Just Linear Probes on Activations
# =============================================================================

class RuleHead(nn.Module):
    """L_rule: classify which rules are present. Attached to z_early."""

    def __init__(self, hidden_size: int, num_rules: int = 15):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, num_rules)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """z: [B, S, H] -> [B, num_rules]"""
        return self.head(z.mean(dim=1))


class ConstraintHead(nn.Module):
    """L_constraint: reconstruct constraint parameters. Attached to z_early."""

    def __init__(self, hidden_size: int, output_dim: int = 64):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, output_dim)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """z: [B, S, H] -> [B, output_dim]"""
        return self.head(z.mean(dim=1))


class BreakInHead(nn.Module):
    """L_breakin: score likely first-move positions. Attached to z_mid."""

    def __init__(self, hidden_size: int, num_positions: int = 81):
        super().__init__()
        self.num_positions = num_positions
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 1)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """z: [B, S, H] -> [B, num_positions]"""
        if z.shape[1] != self.num_positions:
            z = z.mean(dim=1, keepdim=True).expand(-1, self.num_positions, -1)
        return self.head(z).squeeze(-1)


class SparseHead(nn.Module):
    """L_sparse: predict sparse constraint sets. Attached to z_mid."""

    def __init__(self, hidden_size: int, max_constraints: int = 50):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, max_constraints)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """z: [B, S, H] -> [B, max_constraints]"""
        return self.head(z.mean(dim=1))


class MoveHead(nn.Module):
    """L_move: score candidate moves. Attached to y_mid."""

    def __init__(self, hidden_size: int, num_positions: int = 81, num_values: int = 9):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, num_values)
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """y: [B, C, H] -> [B, C, num_values]"""
        return self.head(y)


class YRSNHead(nn.Module):
    """L_yrsn: reliability tagging (R/S/N). Attached to y_mid."""

    def __init__(self, hidden_size: int, num_positions: int = 81):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 3)  # R, S, N
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """y: [B, C, H] -> [B, C, 3]"""
        return self.head(y)


class FinalHead(nn.Module):
    """L_final: full solution prediction. Attached to y_T."""

    def __init__(self, hidden_size: int, num_positions: int = 81, num_values: int = 9):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, num_values)
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """y: [B, C, H] -> [B, C, num_values]"""
        return self.head(y)


class HaltHead(nn.Module):
    """L_halt: decide when recursion converges. Attached to z_T."""

    def __init__(self, hidden_size: int):
        super().__init__()
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """z: [B, S, H] -> [B, 1]"""
        return self.head(z.mean(dim=1))


# =============================================================================
# Full TRM with Loss Heads
# =============================================================================

@dataclass
class TRMOutput:
    """Output container with all intermediate activations for loss computation."""
    # Final outputs
    y_final: torch.Tensor          # [B, C, H] final state
    z_final: torch.Tensor          # [B, S, H] final reasoning latent

    # Intermediate activations (for auxiliary losses)
    z_early: torch.Tensor          # z at step 0-1
    z_mid: torch.Tensor            # z at step T//2
    y_mid: torch.Tensor            # y at step T//2

    # All step outputs (optional)
    z_steps: Optional[List[torch.Tensor]] = None
    y_steps: Optional[List[torch.Tensor]] = None


class TRM(nn.Module):
    """
    Thinking Recurrence Machine - Generic Architecture

    One model. One recursion. Different loss heads on different activations.

    Usage:
        model = TRM(config)
        output = model(x, state_init)

        # Compute losses based on training phase
        loss = compute_phase_loss(output, targets, phase=2)
    """

    def __init__(self, config: Optional[TRMConfig] = None):
        super().__init__()
        self.config = config or TRMConfig()
        H = self.config.hidden_size
        C = self.config.num_positions

        # Input encoder
        self.text_embed = nn.Embedding(self.config.vocab_size, H)
        self.value_embed = nn.Embedding(self.config.num_values + 1, H)  # +1 for empty
        self.pos_embed = nn.Embedding(C, H)

        # Initial states
        self.z_init = nn.Parameter(torch.randn(1, C, H) * 0.02)

        # Core TRM blocks (shared across steps)
        self.f_z = ReasoningUpdate(self.config)
        self.f_y = StateUpdate(self.config)

        # Loss heads - attached to specific activations
        # Phase 1: z_early
        self.rule_head = RuleHead(H)
        self.constraint_head = ConstraintHead(H)

        # Phase 2: z_mid
        self.breakin_head = BreakInHead(H, C)
        self.sparse_head = SparseHead(H)

        # Phase 3: y_mid
        self.move_head = MoveHead(H, C, self.config.num_values)
        self.yrsn_head = YRSNHead(H, C)

        # Phase 4: y_T, z_T
        self.final_head = FinalHead(H, C, self.config.num_values)
        self.halt_head = HaltHead(H)

    def encode_input(
        self,
        rule_tokens: torch.Tensor,    # [B, L]
        state: torch.Tensor,          # [B, C]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Encode input to get x and y_0."""
        B = state.shape[0]
        C = self.config.num_positions
        device = state.device

        # Encode rules
        x = self.text_embed(rule_tokens)  # [B, L, H]

        # Encode initial state
        positions = torch.arange(C, device=device).unsqueeze(0).expand(B, -1)
        y = self.value_embed(state) + self.pos_embed(positions)  # [B, C, H]

        return x, y

    def forward(
        self,
        rule_tokens: torch.Tensor,
        state: torch.Tensor,
        return_all_steps: bool = False,
    ) -> TRMOutput:
        """
        Forward pass through TRM.

        Returns TRMOutput with all activations needed for loss computation.
        """
        B = state.shape[0]
        T = self.config.num_steps

        # Encode input
        x, y = self.encode_input(rule_tokens, state)

        # Initialize z
        z = self.z_init.expand(B, -1, -1).clone()

        # Storage for intermediate activations
        z_steps = [] if return_all_steps else None
        y_steps = [] if return_all_steps else None
        z_early = None
        z_mid = None
        y_mid = None

        # Run TRM recursion
        for t in range(T):
            # Update reasoning latent
            z = self.f_z(x, y, z)

            # Update state
            y = self.f_y(y, z)

            # Store intermediate activations
            if return_all_steps:
                z_steps.append(z)
                y_steps.append(y)

            # Capture specific activations for loss heads
            if t == 0:
                z_early = z.clone()
            if t == T // 2:
                z_mid = z.clone()
                y_mid = y.clone()

        # Handle edge cases for short sequences
        if z_early is None:
            z_early = z
        if z_mid is None:
            z_mid = z
        if y_mid is None:
            y_mid = y

        return TRMOutput(
            y_final=y,
            z_final=z,
            z_early=z_early,
            z_mid=z_mid,
            y_mid=y_mid,
            z_steps=z_steps,
            y_steps=y_steps,
        )

    def compute_head_outputs(
        self,
        output: TRMOutput,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute all loss head outputs from TRM activations.

        Returns dict of head_name -> predictions
        """
        return {
            # Phase 1 heads (z_early)
            'rule_logits': self.rule_head(output.z_early),
            'constraint_pred': self.constraint_head(output.z_early),

            # Phase 2 heads (z_mid)
            'breakin_scores': self.breakin_head(output.z_mid),
            'sparse_scores': self.sparse_head(output.z_mid),

            # Phase 3 heads (y_mid)
            'move_logits': self.move_head(output.y_mid),
            'yrsn_logits': self.yrsn_head(output.y_mid),

            # Phase 4 heads (y_T, z_T)
            'final_logits': self.final_head(output.y_final),
            'halt_prob': self.halt_head(output.z_final),
        }


# =============================================================================
# Loss Computation with Phase Scheduling
# =============================================================================

@dataclass
class LossWeights:
    """Loss weights for each phase."""
    # Phase 1
    rule: float = 0.0
    constraint: float = 0.0

    # Phase 2
    breakin: float = 0.0
    sparse: float = 0.0

    # Phase 3
    move: float = 0.0
    yrsn: float = 0.0

    # Phase 4
    final: float = 0.0
    halt: float = 0.0


def get_phase_weights(phase: int, epoch_in_phase: float = 1.0) -> LossWeights:
    """
    Get loss weights for a training phase.

    Args:
        phase: 1-4
        epoch_in_phase: 0-1 progress within phase (for smooth transitions)
    """
    weights = LossWeights()

    # Cumulative: later phases keep earlier losses (with reduced weight)
    if phase >= 1:
        weights.rule = 1.0
        weights.constraint = 0.5

    if phase >= 2:
        weights.breakin = 1.0
        weights.sparse = 0.5
        # Reduce phase 1 weights
        weights.rule = 0.5
        weights.constraint = 0.25

    if phase >= 3:
        weights.move = 1.5
        weights.yrsn = 1.0
        # Further reduce earlier weights
        weights.breakin = 0.5
        weights.sparse = 0.25

    if phase >= 4:
        weights.final = 2.0
        weights.halt = 0.5
        # Keep move/yrsn at reasonable levels
        weights.move = 1.0
        weights.yrsn = 0.5

    return weights


def compute_loss(
    head_outputs: Dict[str, torch.Tensor],
    targets: Dict[str, torch.Tensor],
    weights: LossWeights,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Compute weighted loss from head outputs.

    Args:
        head_outputs: from TRM.compute_head_outputs()
        targets: ground truth labels
        weights: from get_phase_weights()

    Returns:
        total_loss, component_losses dict
    """
    losses = {}
    total = torch.tensor(0.0, device=next(iter(head_outputs.values())).device)

    # Phase 1 losses
    if weights.rule > 0 and 'rule_labels' in targets:
        rule_loss = F.cross_entropy(
            head_outputs['rule_logits'],
            targets['rule_labels']
        )
        losses['rule'] = rule_loss
        total = total + weights.rule * rule_loss

    if weights.constraint > 0 and 'constraint_vec' in targets:
        const_loss = F.mse_loss(
            head_outputs['constraint_pred'],
            targets['constraint_vec']
        )
        losses['constraint'] = const_loss
        total = total + weights.constraint * const_loss

    # Phase 2 losses
    if weights.breakin > 0 and 'breakin_positions' in targets:
        breakin_loss = F.binary_cross_entropy_with_logits(
            head_outputs['breakin_scores'],
            targets['breakin_positions'].float()
        )
        losses['breakin'] = breakin_loss
        total = total + weights.breakin * breakin_loss

    if weights.sparse > 0 and 'sparse_labels' in targets:
        sparse_loss = F.binary_cross_entropy_with_logits(
            head_outputs['sparse_scores'],
            targets['sparse_labels'].float()
        )
        losses['sparse'] = sparse_loss
        total = total + weights.sparse * sparse_loss

    # Phase 3 losses
    if weights.move > 0 and 'move_labels' in targets:
        move_loss = F.cross_entropy(
            head_outputs['move_logits'].view(-1, head_outputs['move_logits'].shape[-1]),
            targets['move_labels'].view(-1),
            ignore_index=-1
        )
        losses['move'] = move_loss
        total = total + weights.move * move_loss

    if weights.yrsn > 0 and 'yrsn_labels' in targets:
        yrsn_loss = F.cross_entropy(
            head_outputs['yrsn_logits'].view(-1, 3),
            targets['yrsn_labels'].view(-1),
            ignore_index=-1
        )
        losses['yrsn'] = yrsn_loss
        total = total + weights.yrsn * yrsn_loss

    # Phase 4 losses
    if weights.final > 0 and 'solution' in targets:
        final_loss = F.cross_entropy(
            head_outputs['final_logits'].view(-1, head_outputs['final_logits'].shape[-1]),
            targets['solution'].view(-1)
        )
        losses['final'] = final_loss
        total = total + weights.final * final_loss

    if weights.halt > 0 and 'should_halt' in targets:
        halt_loss = F.binary_cross_entropy(
            head_outputs['halt_prob'].squeeze(-1),
            targets['should_halt'].float()
        )
        losses['halt'] = halt_loss
        total = total + weights.halt * halt_loss

    return total, losses


# =============================================================================
# Training Scheduler
# =============================================================================

class PhaseScheduler:
    """
    Manages training phase transitions.

    This is just loss weight scheduling - nothing more.
    """

    def __init__(
        self,
        phase1_epochs: int = 10,
        phase2_epochs: int = 15,
        phase3_epochs: int = 20,
        phase4_epochs: int = 25,
    ):
        self.phase_epochs = [phase1_epochs, phase2_epochs, phase3_epochs, phase4_epochs]
        self.boundaries = []
        cumulative = 0
        for epochs in self.phase_epochs:
            self.boundaries.append((cumulative, cumulative + epochs))
            cumulative += epochs
        self.total_epochs = cumulative

    def get_phase(self, epoch: int) -> Tuple[int, float]:
        """
        Get current phase and progress within phase.

        Returns:
            (phase_number 1-4, progress 0-1)
        """
        for i, (start, end) in enumerate(self.boundaries):
            if start <= epoch < end:
                progress = (epoch - start) / (end - start)
                return i + 1, progress
        return 4, 1.0  # Past all phases

    def get_weights(self, epoch: int) -> LossWeights:
        """Get loss weights for epoch."""
        phase, progress = self.get_phase(epoch)
        return get_phase_weights(phase, progress)

    def __repr__(self) -> str:
        phases = ', '.join(f'P{i+1}:{e}' for i, e in enumerate(self.phase_epochs))
        return f'PhaseScheduler({phases}, total={self.total_epochs})'


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config
    'TRMConfig',
    'TrainingPhase',

    # Core model
    'TRM',
    'TRMOutput',
    'ReasoningUpdate',
    'StateUpdate',
    'BoardUpdate',  # Alias

    # Loss heads
    'RuleHead',
    'ConstraintHead',
    'BreakInHead',
    'SparseHead',
    'MoveHead',
    'YRSNHead',
    'FinalHead',
    'HaltHead',

    # Loss computation
    'LossWeights',
    'get_phase_weights',
    'compute_loss',

    # Scheduler
    'PhaseScheduler',
]
