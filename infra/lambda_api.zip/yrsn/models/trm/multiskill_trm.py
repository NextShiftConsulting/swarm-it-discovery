"""
MultiSkill TRM - Learning N Capabilities with Iterative Reasoning

This implements the full N≈12-15 skill architecture for constraint reasoning.

Architecture:
    TRMCore: z_{t+1} = f_z(x, y_t, z_t), y_{t+1} = f_y(y_t, z_{t+1})
    ReasoningHeads: 12-15 capability heads attached to z/y at early/mid/late steps
    MultiSkillTRM: Top-level wrapper

Capabilities (15 skills):
    Foundation:
        1. Rule encoding (constraint types)
        2. Constraint parameters (sums, orderings)
        3. Constraint type classification

    Sparse Set Detection:
        4. Sparse entity importance
        5. Sparse constraint importance

    Local Reasoning:
        6. Break-in detection (leverage points)
        7. Move scoring
        8. YRSN reliability tagging

    Global Reasoning:
        9. Final solution synthesis
        10. Halting / convergence
        11. Conflict detection & repair

    Meta / Transfer:
        12. Strategy classification
        13. Domain invariance
        14. Reasoning trace reconstruction

Based on research into:
    - Samsung TRM (Less is More, arXiv:2510.04871)
    - CSP backdoor literature
    - Multi-task learning with auxiliary losses
    - Process supervision
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum, auto


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class MultiSkillTRMConfig:
    """Configuration for MultiSkill TRM."""
    # Dimensions
    input_dim: int = 512          # Raw input embedding
    x_dim: int = 256              # Encoded context
    y_dim: int = 256              # Solution state
    z_dim: int = 256              # Reasoning latent
    hidden_dim: int = 512         # MLP hidden

    # TRM parameters
    num_steps: int = 8            # Recursion depth

    # Task-specific (can be overridden for different domains)
    num_positions: int = 81       # Number of positions (cells for Sudoku)
    num_values: int = 9           # Values per position (digits for Sudoku)
    num_rule_types: int = 15      # Constraint types (killer, thermo, etc.)
    num_constraint_types: int = 10  # Multi-label constraint types
    num_domains: int = 10         # Domain types
    num_strategies: int = 20      # Strategy types
    num_yrsn_classes: int = 3     # R, S, N

    # Head configuration
    trace_hidden_dim: int = 256
    max_constraints: int = 50     # Max constraints to track

    @property
    def final_state_dim(self) -> int:
        """Output dimension = positions × values."""
        return self.num_positions * self.num_values


class Capability(Enum):
    """Enumeration of all learnable capabilities."""
    # Foundation
    RULE_ENCODING = auto()
    CONSTRAINT_PARAMS = auto()
    CONSTRAINT_TYPES = auto()

    # Sparse Set
    SPARSE_ENTITIES = auto()
    SPARSE_CONSTRAINTS = auto()

    # Local Reasoning
    BREAKIN = auto()
    MOVE_SCORING = auto()
    YRSN = auto()

    # Global Reasoning
    FINAL_SOLUTION = auto()
    HALTING = auto()
    CONFLICT = auto()
    REPAIR = auto()

    # Meta
    STRATEGY = auto()
    DOMAIN = auto()
    TRACE = auto()


# =============================================================================
# TRM Core: f_z and f_y
# =============================================================================

class TRMCore(nn.Module):
    """
    Tiny Recursive Model core.

    z_{t+1} = f_z(x, y_t, z_t)    # Reasoning update
    y_{t+1} = f_y(y_t, z_{t+1})   # Solution update

    This is intentionally modular - can swap f_z/f_y implementations.
    """

    def __init__(
        self,
        x_dim: int,
        y_dim: int,
        z_dim: int,
        hidden_dim: int,
        num_steps: int = 8,
    ):
        super().__init__()
        self.num_steps = num_steps
        self.x_dim = x_dim
        self.y_dim = y_dim
        self.z_dim = z_dim

        # f_z: reasoning latent update
        self.f_z = nn.Sequential(
            nn.Linear(x_dim + y_dim + z_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, z_dim),
        )

        # f_y: solution state update
        self.f_y = nn.Sequential(
            nn.Linear(y_dim + z_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, y_dim),
        )

    def forward(
        self,
        x: torch.Tensor,    # (B, x_dim)
        y0: torch.Tensor,   # (B, y_dim)
        z0: torch.Tensor,   # (B, z_dim)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Run TRM recursion.

        Returns:
            y_all: (T+1, B, y_dim) including y0
            z_all: (T+1, B, z_dim) including z0
        """
        y_t = y0
        z_t = z0

        y_all = [y_t]
        z_all = [z_t]

        for _ in range(self.num_steps):
            # Reasoning update: z_{t+1} = f_z(x, y_t, z_t)
            z_input = torch.cat([x, y_t, z_t], dim=-1)
            z_t = self.f_z(z_input)

            # Solution update: y_{t+1} = f_y(y_t, z_{t+1})
            y_input = torch.cat([y_t, z_t], dim=-1)
            y_t = self.f_y(y_input)

            z_all.append(z_t)
            y_all.append(y_t)

        y_all = torch.stack(y_all, dim=0)  # (T+1, B, y_dim)
        z_all = torch.stack(z_all, dim=0)  # (T+1, B, z_dim)

        return y_all, z_all


# =============================================================================
# Reasoning Heads (N ≈ 12-15 capabilities)
# =============================================================================

class ReasoningHeads(nn.Module):
    """
    All N capabilities as separate heads attached to z/y at different time steps.

    Attachment points:
        z_early (step 0): Foundation heads
        z_mid (step T//2): Local reasoning heads
        z_last (step T): Global reasoning heads
        y_mid, y_last: Solution-focused heads
    """

    def __init__(self, config: MultiSkillTRMConfig):
        super().__init__()
        self.config = config
        z_dim = config.z_dim
        y_dim = config.y_dim

        # =====================================================================
        # Foundation Heads (attached to z_early)
        # =====================================================================

        # 1. Rule encoding: classify which constraint types are present
        self.rule_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_rule_types),
        )

        # 2. Constraint parameters: reconstruct constraint values (sums, etc.)
        self.constraint_param_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, 32),  # 32-dim parameter vector
        )

        # 3. Constraint type classification
        self.ctype_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_constraint_types),
        )

        # =====================================================================
        # Sparse Set Detection Heads (attached to z_mid)
        # =====================================================================

        # 4. Sparse entity importance (which positions matter most)
        self.sparse_entity_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_positions),
        )

        # 5. Sparse constraint importance (which constraints matter most)
        self.sparse_constraint_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.max_constraints),
        )

        # =====================================================================
        # Local Reasoning Heads (attached to z_mid, y_mid)
        # =====================================================================

        # 6. Break-in detection: score positions as potential starting points
        self.breakin_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_positions),
        )

        # 7. Move scoring: score each (position, value) pair
        self.move_head = nn.Sequential(
            nn.Linear(y_dim, y_dim),
            nn.GELU(),
            nn.Linear(y_dim, config.final_state_dim),
        )

        # 8. YRSN reliability: classify moves as R/S/N
        self.yrsn_head = nn.Sequential(
            nn.Linear(y_dim, y_dim // 2),
            nn.GELU(),
            nn.Linear(y_dim // 2, config.num_yrsn_classes),
        )

        # =====================================================================
        # Global Reasoning Heads (attached to z_last, y_last)
        # =====================================================================

        # 9. Final solution synthesis
        self.final_head = nn.Sequential(
            nn.Linear(y_dim, y_dim),
            nn.GELU(),
            nn.Linear(y_dim, config.final_state_dim),
        )

        # 10. Halting: predict convergence at each step
        self.halt_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 4),
            nn.GELU(),
            nn.Linear(z_dim // 4, 1),
        )

        # 11. Conflict detection
        self.conflict_head = nn.Sequential(
            nn.Linear(z_dim + y_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, 1),  # Binary: conflict exists?
        )

        # 12. Repair suggestion: which region to revisit
        self.repair_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, 27),  # Configurable number of regions
        )

        # =====================================================================
        # Meta / Transfer Heads
        # =====================================================================

        # 13. Strategy classification: which solving strategy is active
        self.strategy_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_strategies),
        )

        # 14. Domain classification: which puzzle type
        self.domain_head = nn.Sequential(
            nn.Linear(z_dim, z_dim // 2),
            nn.GELU(),
            nn.Linear(z_dim // 2, config.num_domains),
        )

        # 15. Reasoning trace: per-step next-action prediction
        self.trace_action_head = nn.Sequential(
            nn.Linear(z_dim, z_dim),
            nn.GELU(),
            nn.Linear(z_dim, config.final_state_dim),
        )

    def forward(
        self,
        y_all: torch.Tensor,  # (T+1, B, y_dim)
        z_all: torch.Tensor,  # (T+1, B, z_dim)
    ) -> Dict[str, torch.Tensor]:
        """
        Apply all heads to appropriate time steps.

        Returns dict with all head outputs.
        """
        T_plus_1, B, _ = z_all.shape
        T = T_plus_1 - 1

        # Extract key time points
        z_early = z_all[0]              # Foundation
        z_mid = z_all[T // 2]           # Local reasoning
        z_last = z_all[-1]              # Global reasoning

        y_mid = y_all[T // 2]
        y_last = y_all[-1]

        # ---------------------------------------------------------------------
        # Foundation (z_early)
        # ---------------------------------------------------------------------
        rule_logits = self.rule_head(z_early)
        constraint_params = self.constraint_param_head(z_early)
        ctype_logits = self.ctype_head(z_early)

        # ---------------------------------------------------------------------
        # Sparse Set (z_mid)
        # ---------------------------------------------------------------------
        sparse_entity_scores = self.sparse_entity_head(z_mid)
        sparse_constraint_scores = self.sparse_constraint_head(z_mid)

        # ---------------------------------------------------------------------
        # Local Reasoning (z_mid, y_mid)
        # ---------------------------------------------------------------------
        breakin_scores = self.breakin_head(z_mid)
        move_logits = self.move_head(y_mid)
        yrsn_logits = self.yrsn_head(y_mid)

        # ---------------------------------------------------------------------
        # Global Reasoning (z_last, y_last)
        # ---------------------------------------------------------------------
        final_logits = self.final_head(y_last)

        # Halting at all steps
        halt_logits_all = self.halt_head(z_all)  # (T+1, B, 1)

        # Conflict and repair
        conflict_input = torch.cat([z_last, y_last], dim=-1)
        conflict_logits = self.conflict_head(conflict_input)
        repair_logits = self.repair_head(z_last)

        # ---------------------------------------------------------------------
        # Meta / Transfer
        # ---------------------------------------------------------------------
        strategy_logits = self.strategy_head(z_mid)
        domain_logits = self.domain_head(z_early)

        # Trace: per-step next-action prediction
        trace_logits_all = self.trace_action_head(z_all)

        return {
            # Foundation
            "rule_logits": rule_logits,
            "constraint_params": constraint_params,
            "ctype_logits": ctype_logits,

            # Sparse Set
            "sparse_entity_scores": sparse_entity_scores,
            "sparse_constraint_scores": sparse_constraint_scores,

            # Local Reasoning
            "breakin_scores": breakin_scores,
            "move_logits": move_logits,
            "yrsn_logits": yrsn_logits,

            # Global Reasoning
            "final_logits": final_logits,
            "halt_logits_all": halt_logits_all,
            "conflict_logits": conflict_logits,
            "repair_logits": repair_logits,

            # Meta
            "strategy_logits": strategy_logits,
            "domain_logits": domain_logits,
            "trace_logits_all": trace_logits_all,
        }


# =============================================================================
# MultiSkill TRM - Top Level Model
# =============================================================================

class MultiSkillTRM(nn.Module):
    """
    Full MultiSkill TRM model.

    1. Encodes raw input to context x
    2. Initializes y0, z0
    3. Runs TRMCore for T steps
    4. Applies all ReasoningHeads

    Loss computation is separate (MultiSkillLoss class).
    """

    def __init__(self, config: Optional[MultiSkillTRMConfig] = None):
        super().__init__()
        self.config = config or MultiSkillTRMConfig()

        # Input encoder
        self.input_encoder = nn.Sequential(
            nn.Linear(self.config.input_dim, self.config.x_dim),
            nn.LayerNorm(self.config.x_dim),
            nn.GELU(),
        )

        # Initial state generators
        self.init_y = nn.Sequential(
            nn.Linear(self.config.x_dim, self.config.y_dim),
            nn.LayerNorm(self.config.y_dim),
        )
        self.init_z = nn.Sequential(
            nn.Linear(self.config.x_dim, self.config.z_dim),
            nn.LayerNorm(self.config.z_dim),
        )

        # TRM core
        self.core = TRMCore(
            x_dim=self.config.x_dim,
            y_dim=self.config.y_dim,
            z_dim=self.config.z_dim,
            hidden_dim=self.config.hidden_dim,
            num_steps=self.config.num_steps,
        )

        # Reasoning heads
        self.heads = ReasoningHeads(self.config)

    def forward(
        self,
        x_raw: torch.Tensor,
        y0: Optional[torch.Tensor] = None,
        z0: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        """
        Forward pass.

        Args:
            x_raw: (B, input_dim) raw puzzle encoding
            y0: Optional initial solution state
            z0: Optional initial reasoning latent

        Returns:
            Dict with x, y_all, z_all, and all head outputs
        """
        # Encode input
        x = self.input_encoder(x_raw)

        # Initialize states
        if y0 is None:
            y0 = self.init_y(x)
        if z0 is None:
            z0 = self.init_z(x)

        # Run TRM recursion
        y_all, z_all = self.core(x, y0, z0)

        # Apply heads
        head_outputs = self.heads(y_all, z_all)

        return {
            "x": x,
            "y_all": y_all,
            "z_all": z_all,
            **head_outputs,
        }

    def get_final_solution(self, outputs: Dict[str, Any]) -> torch.Tensor:
        """Extract predicted solution from outputs."""
        num_positions = self.config.num_positions
        num_values = self.config.num_values
        return outputs["final_logits"].view(-1, num_positions, num_values).argmax(dim=-1)


# =============================================================================
# Loss Functions for Each Capability
# =============================================================================

class MultiSkillLoss(nn.Module):
    """
    Computes weighted loss for all capabilities.

    Each capability has its own loss function and weight.
    Weights can be adjusted by phase scheduler.
    """

    def __init__(self):
        super().__init__()
        self.ce = nn.CrossEntropyLoss(reduction='mean')
        self.bce = nn.BCEWithLogitsLoss(reduction='mean')
        self.mse = nn.MSELoss(reduction='mean')

    def forward(
        self,
        outputs: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        weights: Dict[str, float],
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Compute weighted multi-skill loss.

        Args:
            outputs: From MultiSkillTRM forward
            targets: Ground truth labels for each capability
            weights: Loss weight per capability

        Returns:
            total_loss, component_losses dict
        """
        losses = {}
        total = torch.tensor(0.0, device=outputs["final_logits"].device)

        # Foundation losses
        if "rule_labels" in targets and weights.get("rule", 0) > 0:
            loss = self.ce(outputs["rule_logits"], targets["rule_labels"])
            losses["L_rule"] = loss
            total = total + weights["rule"] * loss

        if "constraint_params" in targets and weights.get("constraint", 0) > 0:
            loss = self.mse(outputs["constraint_params"], targets["constraint_params"])
            losses["L_constraint"] = loss
            total = total + weights["constraint"] * loss

        if "ctype_labels" in targets and weights.get("ctype", 0) > 0:
            loss = self.bce(outputs["ctype_logits"], targets["ctype_labels"].float())
            losses["L_ctype"] = loss
            total = total + weights["ctype"] * loss

        # Sparse set losses
        if "sparse_entity_labels" in targets and weights.get("sparse_entity", 0) > 0:
            loss = self.bce(outputs["sparse_entity_scores"], targets["sparse_entity_labels"].float())
            losses["L_sparse_entity"] = loss
            total = total + weights["sparse_entity"] * loss

        if "sparse_constraint_labels" in targets and weights.get("sparse_constraint", 0) > 0:
            loss = self.bce(outputs["sparse_constraint_scores"], targets["sparse_constraint_labels"].float())
            losses["L_sparse_constraint"] = loss
            total = total + weights["sparse_constraint"] * loss

        # Local reasoning losses
        if "breakin_labels" in targets and weights.get("breakin", 0) > 0:
            loss = self.bce(outputs["breakin_scores"], targets["breakin_labels"].float())
            losses["L_breakin"] = loss
            total = total + weights["breakin"] * loss

        if "move_labels" in targets and weights.get("move", 0) > 0:
            loss = self.ce(outputs["move_logits"], targets["move_labels"])
            losses["L_move"] = loss
            total = total + weights["move"] * loss

        if "yrsn_labels" in targets and weights.get("yrsn", 0) > 0:
            loss = self.ce(outputs["yrsn_logits"], targets["yrsn_labels"])
            losses["L_yrsn"] = loss
            total = total + weights["yrsn"] * loss

        # Global reasoning losses
        if "solution" in targets and weights.get("final", 0) > 0:
            num_values = outputs["final_logits"].shape[-1] // outputs.get("num_positions", 81)
            if num_values == 0:
                num_values = 9  # Default
            loss = self.ce(
                outputs["final_logits"].view(-1, num_values),
                targets["solution"].view(-1)
            )
            losses["L_final"] = loss
            total = total + weights["final"] * loss

        if "halt_labels" in targets and weights.get("halt", 0) > 0:
            halt_logit_final = outputs["halt_logits_all"][-1].squeeze(-1)
            loss = self.bce(halt_logit_final, targets["halt_labels"].float())
            losses["L_halt"] = loss
            total = total + weights["halt"] * loss

        if "conflict_labels" in targets and weights.get("conflict", 0) > 0:
            loss = self.bce(outputs["conflict_logits"].squeeze(-1), targets["conflict_labels"].float())
            losses["L_conflict"] = loss
            total = total + weights["conflict"] * loss

        if "repair_labels" in targets and weights.get("repair", 0) > 0:
            loss = self.ce(outputs["repair_logits"], targets["repair_labels"])
            losses["L_repair"] = loss
            total = total + weights["repair"] * loss

        # Meta losses
        if "strategy_labels" in targets and weights.get("strategy", 0) > 0:
            loss = self.ce(outputs["strategy_logits"], targets["strategy_labels"])
            losses["L_strategy"] = loss
            total = total + weights["strategy"] * loss

        if "domain_labels" in targets and weights.get("domain", 0) > 0:
            loss = self.ce(outputs["domain_logits"], targets["domain_labels"])
            losses["L_domain"] = loss
            total = total + weights["domain"] * loss

        if "trace_labels" in targets and weights.get("trace", 0) > 0:
            trace_logits = outputs["trace_logits_all"]
            trace_labels = targets["trace_labels"]
            trace_mask = targets.get("trace_mask", torch.ones_like(trace_labels, dtype=torch.float))

            T_plus_1, B, num_classes = trace_logits.shape

            logits_flat = trace_logits.permute(1, 0, 2).reshape(-1, num_classes)
            labels_flat = trace_labels.reshape(-1)
            mask_flat = trace_mask.reshape(-1)

            labels_clamped = labels_flat.clamp(0, num_classes - 1)

            per_elem_loss = F.cross_entropy(
                logits_flat, labels_clamped, reduction='none'
            )

            masked_loss = per_elem_loss * mask_flat
            if mask_flat.sum() > 0:
                loss = masked_loss.sum() / mask_flat.sum()
            else:
                loss = masked_loss.sum()

            losses["L_trace"] = loss
            total = total + weights["trace"] * loss

        return total, losses


# =============================================================================
# Phase Scheduler for Loss Weights
# =============================================================================

@dataclass
class PhaseWeights:
    """Loss weights for a training phase."""
    # Foundation
    rule: float = 0.0
    constraint: float = 0.0
    ctype: float = 0.0

    # Sparse
    sparse_entity: float = 0.0
    sparse_constraint: float = 0.0

    # Local
    breakin: float = 0.0
    move: float = 0.0
    yrsn: float = 0.0

    # Global
    final: float = 0.0
    halt: float = 0.0
    conflict: float = 0.0
    repair: float = 0.0

    # Meta
    strategy: float = 0.0
    domain: float = 0.0
    trace: float = 0.0

    def to_dict(self) -> Dict[str, float]:
        return {
            "rule": self.rule,
            "constraint": self.constraint,
            "ctype": self.ctype,
            "sparse_entity": self.sparse_entity,
            "sparse_constraint": self.sparse_constraint,
            "breakin": self.breakin,
            "move": self.move,
            "yrsn": self.yrsn,
            "final": self.final,
            "halt": self.halt,
            "conflict": self.conflict,
            "repair": self.repair,
            "strategy": self.strategy,
            "domain": self.domain,
            "trace": self.trace,
        }


# Default phase configurations
PHASE_1_WEIGHTS = PhaseWeights(
    rule=1.0, constraint=0.5, ctype=0.5,  # Foundation focus
)

PHASE_2_WEIGHTS = PhaseWeights(
    rule=0.5, constraint=0.25, ctype=0.25,
    sparse_entity=1.0, sparse_constraint=0.5,
    breakin=1.0,
)

PHASE_3_WEIGHTS = PhaseWeights(
    rule=0.25, constraint=0.1, ctype=0.1,
    sparse_entity=0.5, sparse_constraint=0.25,
    breakin=0.5,
    move=1.5, yrsn=1.0,
)

PHASE_4_WEIGHTS = PhaseWeights(
    rule=0.1, constraint=0.1, ctype=0.1,
    sparse_entity=0.25, sparse_constraint=0.1,
    breakin=0.25,
    move=1.0, yrsn=0.5,
    final=2.0, halt=0.5, conflict=0.3, repair=0.3,
    strategy=0.5, domain=0.25, trace=0.25,
)


class MultiSkillPhaseScheduler:
    """Phase scheduler for multi-skill training."""

    def __init__(
        self,
        phase1_epochs: int = 10,
        phase2_epochs: int = 15,
        phase3_epochs: int = 20,
        phase4_epochs: int = 25,
    ):
        self.phase_configs = [
            (phase1_epochs, PHASE_1_WEIGHTS),
            (phase2_epochs, PHASE_2_WEIGHTS),
            (phase3_epochs, PHASE_3_WEIGHTS),
            (phase4_epochs, PHASE_4_WEIGHTS),
        ]

        self.boundaries = []
        cumulative = 0
        for epochs, _ in self.phase_configs:
            self.boundaries.append((cumulative, cumulative + epochs))
            cumulative += epochs
        self.total_epochs = cumulative

    def get_phase(self, epoch: int) -> int:
        """Get phase number (1-4) for epoch."""
        for i, (start, end) in enumerate(self.boundaries):
            if start <= epoch < end:
                return i + 1
        return 4

    def get_weights(self, epoch: int) -> Dict[str, float]:
        """Get loss weights for epoch."""
        phase = self.get_phase(epoch)
        _, weights = self.phase_configs[phase - 1]
        return weights.to_dict()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config
    "MultiSkillTRMConfig",
    "Capability",

    # Core
    "TRMCore",
    "ReasoningHeads",
    "MultiSkillTRM",

    # Loss
    "MultiSkillLoss",
    "PhaseWeights",
    "MultiSkillPhaseScheduler",

    # Phase configs
    "PHASE_1_WEIGHTS",
    "PHASE_2_WEIGHTS",
    "PHASE_3_WEIGHTS",
    "PHASE_4_WEIGHTS",
]
