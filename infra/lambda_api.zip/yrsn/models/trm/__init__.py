"""
TRM - Thinking Recurrence Machine

Generic architecture for iterative reasoning over constraint problems.

Core Architecture:
    For each recursion step t:
        z_{t+1} = f_z(x, y_t, z_t)    # reasoning latent update
        y_{t+1} = f_y(y_t, z_{t+1})   # state update

Based on Samsung TRM (Less is More, arXiv:2510.04871).
"""

from .trm_core import (
    # Config
    TRMConfig,
    TrainingPhase,

    # Core model
    TRM,
    TRMOutput,
    ReasoningUpdate,
    StateUpdate,
    BoardUpdate,  # Alias for backwards compatibility

    # Loss heads
    RuleHead,
    ConstraintHead,
    BreakInHead,
    SparseHead,
    MoveHead,
    YRSNHead,
    FinalHead,
    HaltHead,

    # Loss computation
    LossWeights,
    get_phase_weights,
    compute_loss,

    # Scheduler
    PhaseScheduler,
)

from .multiskill_trm import (
    # Config
    MultiSkillTRMConfig,
    Capability,

    # Core
    TRMCore,
    ReasoningHeads,
    MultiSkillTRM,

    # Loss
    MultiSkillLoss,
    PhaseWeights,
    MultiSkillPhaseScheduler,

    # Phase configs
    PHASE_1_WEIGHTS,
    PHASE_2_WEIGHTS,
    PHASE_3_WEIGHTS,
    PHASE_4_WEIGHTS,
)

__all__ = [
    # trm_core
    'TRMConfig',
    'TrainingPhase',
    'TRM',
    'TRMOutput',
    'ReasoningUpdate',
    'StateUpdate',
    'BoardUpdate',
    'RuleHead',
    'ConstraintHead',
    'BreakInHead',
    'SparseHead',
    'MoveHead',
    'YRSNHead',
    'FinalHead',
    'HaltHead',
    'LossWeights',
    'get_phase_weights',
    'compute_loss',
    'PhaseScheduler',

    # multiskill_trm
    'MultiSkillTRMConfig',
    'Capability',
    'TRMCore',
    'ReasoningHeads',
    'MultiSkillTRM',
    'MultiSkillLoss',
    'PhaseWeights',
    'MultiSkillPhaseScheduler',
    'PHASE_1_WEIGHTS',
    'PHASE_2_WEIGHTS',
    'PHASE_3_WEIGHTS',
    'PHASE_4_WEIGHTS',
]
