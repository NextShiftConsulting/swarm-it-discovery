"""
HRMV: Hierarchical Reasoning Model - Vanilla (Baseline without YRSN techniques)

================================================================================
REUSABLE ARCHITECTURE - Parameterized for Multiple Applications
================================================================================

HRMV is a domain-agnostic hierarchical reasoning architecture. While developed
using Sudoku as a proving ground, it is fully parameterized for reuse:

    - num_positions: Number of positions to predict (e.g., 81 for 9x9, 36 for 6x6)
    - num_classes: Number of output classes (e.g., 9 for Sudoku digits, N for other domains)
    - max_seq_len: Maximum sequence length (adjustable per application)
    - output_vocab_size: Vocabulary size for token prediction

Example applications beyond Sudoku:
    - Constraint satisfaction problems (scheduling, resource allocation)
    - Grid-based reasoning (crosswords, logic puzzles)
    - Sequential decision making with hierarchical structure

================================================================================

This is a CLEAN implementation of Wang et al.'s HRM architecture (arXiv:2506.21734)
WITHOUT using YRSN-specific techniques.

Purpose: Ablation baseline to measure YRSN contribution.

What HRMV KEEPS from original HRM:
- Two-level hierarchy (H-module / L-module)
- SwiGLU activation
- Post-norm architecture
- Truncated normal initialization
- RMS normalization
- Input injection mechanism

What HRMV does NOT use (YRSN techniques excluded):
- NO YRSN rules encoder (uses simple learned embeddings)
- NO SigLIP multimodal fusion
- NO instruction/task boosting
- NO pre-trained sentence transformers
- NO quantum kernels

Application-specific components (provided by application layer):
- Encoder: Application provides encoder via constructor or uses SimpleVariantEncoder
- Input format: Application defines rules_text, visual_elements format
"""

from typing import Tuple, Optional, List, Dict, Any
from dataclasses import dataclass
import math
import re

import torch
import torch.nn.functional as F
from torch import nn

# Import shared utilities from _common
from ._common import (
    trunc_normal_init_, rms_norm, SwiGLU, RotaryPositionEmbedding,
    compute_yrsn_monitoring_metrics, __version__ as _common_version
)

# Import StitchingLayer for learned geometric alignment (ABL-08)
from .hrm import StitchingLayer

__version__ = "0.5.0"


# ============================================================================
# Core HRM Components (using shared _common utilities)
# ============================================================================

@dataclass
class HRMVState:
    """State carried between HRMV forward passes"""
    z_H: torch.Tensor  # High-level state [batch, seq_len, hidden_size]
    z_L: torch.Tensor  # Low-level state [batch, seq_len, hidden_size]


# Note: trunc_normal_init_, rms_norm, SwiGLU, RotaryPositionEmbedding
# are imported from ._common


class HRMAttention(nn.Module):
    """Multi-head attention using PyTorch's scaled_dot_product_attention (SDPA).

    SDPA is 2-4x faster than manual attention and automatically uses:
    - Flash Attention (if available on GPU)
    - Memory-efficient attention
    - Math fallback on CPU

    Now supports optional RoPE (Rotary Position Embedding) for position-aware attention.
    """

    def __init__(self, hidden_size: int, num_heads: int, causal: bool = False,
                 use_rope: bool = False, max_seq_len: int = 128):
        super().__init__()
        assert hidden_size % num_heads == 0

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.causal = causal
        self.use_rope = use_rope

        # RoPE for position encoding (optional, off by default for backward compat)
        if use_rope:
            self.rope = RotaryPositionEmbedding(self.head_dim, max_seq_len)

        init_std = 1.0 / math.sqrt(hidden_size)

        self.qkv_proj = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        self.out_proj = nn.Linear(hidden_size, hidden_size, bias=False)

        with torch.no_grad():
            trunc_normal_init_(self.qkv_proj.weight, std=init_std)
            trunc_normal_init_(self.out_proj.weight, std=init_std / math.sqrt(num_heads))

    def forward(
        self,
        x: torch.Tensor,
        return_attention_weights: bool = False
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Forward pass with optional attention weight extraction.

        Args:
            x: Input tensor [batch, seq_len, hidden_size]
            return_attention_weights: If True, compute and return attention weights
                                     (slower, uses manual attention instead of SDPA)

        Returns:
            If return_attention_weights=False: (output, None)
            If return_attention_weights=True: (output, attention_weights)
                where attention_weights is [batch, num_heads, seq_len, seq_len]
        """
        batch_size, seq_len, _ = x.shape

        qkv = self.qkv_proj(x)
        qkv = qkv.reshape(batch_size, seq_len, 3, self.num_heads, self.head_dim)

        # Apply RoPE BEFORE transpose if enabled (like HRM reference)
        if self.use_rope:
            q = qkv[:, :, 0]  # [batch, seq_len, num_heads, head_dim]
            k = qkv[:, :, 1]
            v = qkv[:, :, 2]
            q = self.rope(q)
            k = self.rope(k)
            # Transpose to [batch, num_heads, seq_len, head_dim]
            q = q.transpose(1, 2)
            k = k.transpose(1, 2)
            v = v.transpose(1, 2)
        else:
            qkv = qkv.permute(2, 0, 3, 1, 4)  # [3, batch, num_heads, seq_len, head_dim]
            q, k, v = qkv[0], qkv[1], qkv[2]

        attn_weights = None

        if return_attention_weights:
            # Manual attention to get weights (slower but needed for visualization)
            scale = 1.0 / math.sqrt(self.head_dim)
            attn_scores = torch.matmul(q, k.transpose(-2, -1)) * scale

            if self.causal:
                causal_mask = torch.triu(
                    torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool),
                    diagonal=1
                )
                attn_scores = attn_scores.masked_fill(causal_mask, float('-inf'))

            attn_weights = F.softmax(attn_scores, dim=-1)
            attn_output = torch.matmul(attn_weights, v)
        else:
            # Use PyTorch's SDPA - automatically picks Flash/Memory-efficient/Math backend
            # This is 2-4x faster than manual matmul + softmax + matmul
            attn_output = F.scaled_dot_product_attention(
                q, k, v,
                attn_mask=None,
                dropout_p=0.0,
                is_causal=self.causal
            )

        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(batch_size, seq_len, self.hidden_size)
        return self.out_proj(attn_output), attn_weights


class HRMBlock(nn.Module):
    """Single HRM transformer block with post-norm (from original HRM)"""

    def __init__(self, hidden_size: int, num_heads: int, expansion: float = 4.0,
                 rms_norm_eps: float = 1e-5, causal: bool = False,
                 use_rope: bool = False, max_seq_len: int = 128):
        super().__init__()
        self.self_attn = HRMAttention(hidden_size, num_heads, causal, use_rope, max_seq_len)
        self.mlp = SwiGLU(hidden_size, expansion)
        self.norm_eps = rms_norm_eps

    def forward(
        self,
        x: torch.Tensor,
        return_attention_weights: bool = False
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Forward with optional attention weight extraction.

        Returns:
            (output, attention_weights) where attention_weights is None unless requested
        """
        attn_out, attn_weights = self.self_attn(x, return_attention_weights)
        x = rms_norm(x + attn_out, eps=self.norm_eps)
        x = rms_norm(x + self.mlp(x), eps=self.norm_eps)
        return x, attn_weights


class HRMReasoningModule(nn.Module):
    """Stack of HRM blocks forming one reasoning level (from original HRM).

    Now supports ACT (Adaptive Computation Time) for learned early halting.
    """

    def __init__(self, num_layers: int, hidden_size: int, num_heads: int,
                 expansion: float = 4.0, rms_norm_eps: float = 1e-5,
                 use_rope: bool = False, max_seq_len: int = 128,
                 use_act: bool = False):
        super().__init__()
        self.layers = nn.ModuleList([
            HRMBlock(hidden_size, num_heads, expansion, rms_norm_eps,
                     use_rope=use_rope, max_seq_len=max_seq_len)
            for _ in range(num_layers)
        ])

        # ACT halting head (Q-values for continue vs halt)
        self.use_act = use_act
        if use_act:
            self.q_act_head = nn.Linear(hidden_size, 2)
            nn.init.zeros_(self.q_act_head.weight)
            nn.init.zeros_(self.q_act_head.bias)

    def forward(
        self,
        hidden_states: torch.Tensor,
        input_injection: torch.Tensor,
        return_attention_weights: bool = False
    ):
        """
        Args:
            hidden_states: Current state [batch, seq_len, hidden_size]
            input_injection: Input to inject (add) [batch, seq_len, hidden_size]
            return_attention_weights: If True, collect attention weights from all layers

        Returns:
            x: Updated hidden states [batch, seq_len, hidden_size]
            q_act_halt: Halt Q-value [batch] (if use_act)
            q_act_continue: Continue Q-value [batch] (if use_act)
            attention_weights: List of attention weights per layer (if return_attention_weights)
        """
        x = hidden_states + input_injection

        all_attn_weights = [] if return_attention_weights else None

        for layer in self.layers:
            x, attn_weights = layer(x, return_attention_weights)
            if return_attention_weights and attn_weights is not None:
                all_attn_weights.append(attn_weights)

        # ACT: Compute Q-values from CLS token (first position)
        if self.use_act:
            q_act_logits = self.q_act_head(x[:, 0])
            q_act_halt = q_act_logits[:, 0]
            q_act_continue = q_act_logits[:, 1]
            if return_attention_weights:
                return x, q_act_halt, q_act_continue, all_attn_weights
            return x, q_act_halt, q_act_continue

        if return_attention_weights:
            return x, all_attn_weights

        return x


# ============================================================================
# Simple Input Encoder (NO YRSN techniques)
# ============================================================================

class SimpleVariantEncoder(nn.Module):
    """
    Simple encoder for variant Sudoku WITHOUT YRSN techniques.

    Uses:
    - Learned word embeddings (NOT pre-trained sentence transformers)
    - Simple bag-of-words for rules
    - One-hot board encoding
    - Sparse visual element features
    """

    def __init__(self, hidden_size: int = 256, vocab_size: int = 10000, max_seq_len: int = 256):
        super().__init__()

        self.hidden_size = hidden_size
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len

        # Simple learned word embeddings (NOT pre-trained)
        self.word_embeddings = nn.Embedding(vocab_size, hidden_size)

        # Board state embedding (0-9 for digits, 10 for empty)
        self.cell_embeddings = nn.Embedding(11, hidden_size)

        # Visual element type embedding (simple categorical)
        self.visual_type_embeddings = nn.Embedding(20, hidden_size)  # 20 visual types

        # Positional encoding
        self.pos_encoding = self._create_sinusoidal_pos_encoding(max_seq_len, hidden_size)

        # Projection to combine all inputs
        self.input_proj = nn.Linear(hidden_size * 3, hidden_size)

        # Simple vocabulary (built on first use)
        self._vocab: Dict[str, int] = {}
        self._vocab_built = False

    def _create_sinusoidal_pos_encoding(self, max_len: int, d_model: int) -> torch.Tensor:
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return nn.Parameter(pe, requires_grad=False)

    def _tokenize(self, text: str) -> List[int]:
        """Simple whitespace tokenization with vocabulary building"""
        # Simple preprocessing
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        words = text.split()

        tokens = []
        for word in words[:self.max_seq_len]:
            if word not in self._vocab:
                if len(self._vocab) < self.vocab_size - 1:
                    self._vocab[word] = len(self._vocab) + 1  # 0 reserved for padding
            tokens.append(self._vocab.get(word, 0))

        return tokens

    def _parse_board(self, board_state: str, rows: int, cols: int, device: torch.device = None) -> torch.Tensor:
        """Parse board state to cell indices.

        Args:
            board_state: Board state string (. for empty, digits for filled)
            rows: Number of rows
            cols: Number of columns
            device: Target device (if None, creates on CPU)
        """
        cells = []
        for char in board_state:
            if char == '.':
                cells.append(10)  # Empty
            elif char.isdigit():
                cells.append(int(char))
            # Skip other characters

        # Pad/truncate to expected size
        expected = rows * cols
        if len(cells) < expected:
            cells.extend([10] * (expected - len(cells)))
        elif len(cells) > expected:
            cells = cells[:expected]

        return torch.tensor(cells, dtype=torch.long, device=device)

    def _parse_visual_elements(self, visual_str: str, num_cells: int, rows: int = 9, cols: int = 9, device: torch.device = None) -> torch.Tensor:
        """Parse visual elements to sparse features per cell.

        Args:
            visual_str: JSON string of visual elements
            num_cells: Total cells in grid (rows * cols)
            rows: Number of rows in grid (default 9)
            cols: Number of columns in grid (default 9)
            device: Target device (if None, creates on CPU)
        """
        visual_types = torch.zeros(num_cells, dtype=torch.long, device=device)

        # Map visual type names to indices (handle plural forms!)
        type_map = {
            'cage': 1, 'killer': 1, 'cages': 1,
            'line': 2, 'thermo': 2, 'thermometer': 2, 'lines': 2,
            'arrow': 3, 'arrows': 3,
            'kropki': 4, 'dot': 4,
            'xv': 5, 'v': 5, 'x': 5,
            'inequality': 6,
            'diagonal': 7, 'diagonal arrow': 7,
            'overlay': 8, 'overlays': 8,
            'underlay': 9, 'underlays': 9,
        }

        visual_lower = visual_str.lower()
        for type_name, type_idx in type_map.items():
            if type_name in visual_lower:
                cell_refs = re.findall(r'r(\d+)c(\d+)', visual_lower)
                for row_str, col_str in cell_refs:
                    row = int(row_str) - 1
                    col = int(col_str) - 1
                    # FIX: Use actual grid dimensions, not hardcoded 9
                    cell_idx = row * cols + col
                    if 0 <= cell_idx < num_cells:
                        visual_types[cell_idx] = type_idx

        return visual_types

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int
    ) -> torch.Tensor:
        """
        Encode variant Sudoku puzzle without YRSN techniques.

        Returns:
            context: [num_cells, hidden_size] tensor
        """
        num_cells = rows * cols
        device = self.word_embeddings.weight.device

        # 1. Encode rules with simple bag-of-words
        tokens = self._tokenize(rules_text)
        if len(tokens) == 0:
            tokens = [0]  # Padding token
        token_tensor = torch.tensor(tokens, dtype=torch.long, device=device)
        word_embeds = self.word_embeddings(token_tensor)  # [num_tokens, hidden]
        rules_embed = word_embeds.mean(dim=0)  # Simple mean pooling [hidden]
        rules_per_cell = rules_embed.unsqueeze(0).expand(num_cells, -1)  # [num_cells, hidden]

        # 2. Encode board state (create directly on device to avoid copy)
        board_indices = self._parse_board(board_state, rows, cols, device=device)
        board_embed = self.cell_embeddings(board_indices)  # [num_cells, hidden]

        # 3. Encode visual elements (simple sparse features, create directly on device)
        visual_indices = self._parse_visual_elements(visual_elements_str, num_cells, rows, cols, device=device)
        visual_embed = self.visual_type_embeddings(visual_indices)  # [num_cells, hidden]

        # 4. Combine all inputs
        combined = torch.cat([rules_per_cell, board_embed, visual_embed], dim=-1)  # [num_cells, hidden*3]
        context = self.input_proj(combined)  # [num_cells, hidden]

        # 5. Add positional encoding
        pos_enc = self.pos_encoding[:num_cells].to(device)
        context = context + pos_enc

        return context

    def encode_batch(
        self,
        rules_texts: List[str],
        visual_elements_strs: List[str],
        board_states: List[str],
        rows: int,
        cols: int
    ) -> torch.Tensor:
        """
        Batch encode multiple samples with SAME grid size.

        This is ~8x faster than calling forward() per sample because:
        - Single tensor allocation for batch
        - Batched embedding lookups
        - Better memory locality

        Args:
            rules_texts: List of rules strings
            visual_elements_strs: List of visual elements JSON strings
            board_states: List of board state strings
            rows: Grid rows (must be same for all samples!)
            cols: Grid cols (must be same for all samples!)

        Returns:
            contexts: [batch_size, num_cells, hidden_size]
        """
        batch_size = len(rules_texts)
        num_cells = rows * cols
        device = self.word_embeddings.weight.device

        # Pre-allocate tensors for batch
        all_rules_embeds = []
        all_board_indices = []
        all_visual_indices = []

        for i in range(batch_size):
            # 1. Tokenize and embed rules
            tokens = self._tokenize(rules_texts[i])
            if len(tokens) == 0:
                tokens = [0]
            token_tensor = torch.tensor(tokens, dtype=torch.long, device=device)
            word_embeds = self.word_embeddings(token_tensor)
            rules_embed = word_embeds.mean(dim=0)  # [hidden]
            all_rules_embeds.append(rules_embed)

            # 2. Parse board state (create directly on device)
            board_indices = self._parse_board(board_states[i], rows, cols, device=device)
            all_board_indices.append(board_indices)

            # 3. Parse visual elements (create directly on device)
            visual_indices = self._parse_visual_elements(visual_elements_strs[i], num_cells, rows, cols, device=device)
            all_visual_indices.append(visual_indices)

        # Stack into batched tensors (already on device, no .to() needed)
        rules_embeds = torch.stack(all_rules_embeds)  # [batch, hidden]
        rules_per_cell = rules_embeds.unsqueeze(1).expand(-1, num_cells, -1)  # [batch, num_cells, hidden]

        board_indices = torch.stack(all_board_indices)  # [batch, num_cells] - already on device
        board_embeds = self.cell_embeddings(board_indices)  # [batch, num_cells, hidden]

        visual_indices = torch.stack(all_visual_indices)  # [batch, num_cells] - already on device
        visual_embeds = self.visual_type_embeddings(visual_indices)  # [batch, num_cells, hidden]

        # Combine all inputs
        combined = torch.cat([rules_per_cell, board_embeds, visual_embeds], dim=-1)  # [batch, num_cells, hidden*3]
        contexts = self.input_proj(combined)  # [batch, num_cells, hidden]

        # Add positional encoding
        pos_enc = self.pos_encoding[:num_cells].to(device).unsqueeze(0)  # [1, num_cells, hidden]
        contexts = contexts + pos_enc

        return contexts


# ============================================================================
# HRMV: Complete Model
# ============================================================================

class HRMV(nn.Module):
    """
    HRM for Variant Sudoku (Baseline without YRSN techniques)

    This model uses the ORIGINAL HRM architecture from Wang et al. (2506.21734)
    with minimal adaptations for variant Sudoku input format.

    NO YRSN techniques:
    - NO pre-trained embeddings
    - NO instruction boosting
    - NO SigLIP visual encoding
    - NO task-specific enhancements

    However, YRSN monitoring can be enabled for passive observation of collapse
    metrics without affecting model behavior. This allows comparing R/S/N metrics
    across all model variants.

    Args:
        hidden_size: Hidden dimension (default 256, same as original HRM)
        num_heads: Number of attention heads
        H_layers: Number of H-level (high) layers
        L_layers: Number of L-level (low) layers
        H_cycles: Number of H-level iterations
        L_cycles: Number of L-level iterations per H-cycle
        expansion: MLP expansion ratio
        output_vocab_size: Output vocabulary size for token prediction
        use_rope: Enable Rotary Position Embedding
        max_seq_len: Maximum sequence length for RoPE
        use_act: Enable ACT (Adaptive Computation Time) for learned early halting
        use_yrsn_monitoring: Enable passive YRSN collapse monitoring (default False)
        num_positions: Number of positions to predict (default 81, adjustable per application)
        num_classes: Number of output classes per position (default 9, adjustable)
        encoder: Optional custom encoder module. If None, uses SimpleVariantEncoder.
                 For production, provide application-specific encoder from yrsn-sudoku
                 or other application package.
    """

    def __init__(
        self,
        hidden_size: int = 256,
        num_heads: int = 8,
        H_layers: int = 4,
        L_layers: int = 4,
        H_cycles: int = 3,
        L_cycles: int = 5,
        expansion: float = 4.0,
        output_vocab_size: int = 10,
        rms_norm_eps: float = 1e-5,
        use_rope: bool = False,
        max_seq_len: int = 128,
        use_act: bool = False,
        use_yrsn_monitoring: bool = False,
        use_learned_stitching: bool = False,  # ABL-08: learned geometric alignment
        # Parameterized for reuse across applications
        num_positions: int = 81,   # Grid positions (e.g., 81 for 9x9, 36 for 6x6)
        num_classes: int = 9,      # Output classes (e.g., 9 digits, or N for other domains)
        encoder: Optional[nn.Module] = None,  # Optional custom encoder
    ):
        super().__init__()

        self.hidden_size = hidden_size
        self.H_cycles = H_cycles
        self.L_cycles = L_cycles
        self.output_vocab_size = output_vocab_size
        self.use_rope = use_rope
        self.use_act = use_act
        self.use_learned_stitching = use_learned_stitching
        self.num_positions = num_positions
        self.num_classes = num_classes

        # Encoder: use provided encoder or default SimpleVariantEncoder
        if encoder is not None:
            self.encoder = encoder
        else:
            self.encoder = SimpleVariantEncoder(hidden_size=hidden_size)

        # Original HRM reasoning modules (now with optional RoPE and ACT)
        self.H_level = HRMReasoningModule(
            H_layers, hidden_size, num_heads, expansion, rms_norm_eps,
            use_rope=use_rope, max_seq_len=max_seq_len, use_act=use_act
        )
        self.L_level = HRMReasoningModule(
            L_layers, hidden_size, num_heads, expansion, rms_norm_eps,
            use_rope=use_rope, max_seq_len=max_seq_len, use_act=use_act
        )

        # Learned stitching layers (ABL-08: geometric alignment at interface)
        # Rationale: Additive stitching (z_H + context) assumes compatible geometries.
        # Learned stitching handles geometry mismatch via concat + affine transform.
        if use_learned_stitching:
            self.stitch_H_to_L = StitchingLayer(hidden_size, num_inputs=2)  # z_H + context
            self.stitch_L_to_H = StitchingLayer(hidden_size, num_inputs=1)  # z_L only (identity-like)

        # Learnable initial states
        self.H_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))
        self.L_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))

        # Output head for all positions
        self.lm_head = nn.Linear(hidden_size, output_vocab_size)

        # Parameterized heads for position/class prediction (reusable across applications)
        self.position_head = nn.Linear(hidden_size, num_positions)
        self.digit_head = nn.Linear(hidden_size, num_classes)

        # Initialize output heads
        init_std = 1.0 / math.sqrt(hidden_size)
        with torch.no_grad():
            trunc_normal_init_(self.lm_head.weight, std=init_std)
            self.lm_head.bias.zero_()
            trunc_normal_init_(self.position_head.weight, std=init_std)
            self.position_head.bias.zero_()
            trunc_normal_init_(self.digit_head.weight, std=init_std)
            self.digit_head.bias.zero_()

        # YRSN monitoring (passive observation, does NOT affect model behavior)
        self.use_yrsn_monitoring = use_yrsn_monitoring
        if use_yrsn_monitoring:
            from yrsn.models.hrm import YRSNProjectionHeads
            self.H_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False  # Derive from model weights
            )
            self.L_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False
            )
            self._projections_initialized = False

    def _initialize_projections(self, device: torch.device):
        """Initialize projection heads from model weights (lazy initialization)."""
        if self.use_yrsn_monitoring and not self._projections_initialized:
            self.H_projection_heads.derive_from_model(self, device)
            self.L_projection_heads.derive_from_model(self, device)
            self._projections_initialized = True

    def initial_state(self, batch_size: int, seq_len: int, device: torch.device) -> HRMVState:
        """Create initial state for HRMV"""
        z_H = self.H_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1).clone()
        z_L = self.L_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1).clone()
        return HRMVState(z_H=z_H, z_L=z_L)

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int,
        state: Optional[HRMVState] = None,
        return_all_positions: bool = False,
        return_yrsn_metrics: bool = False
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMVState, Optional[Dict[str, Any]]]:
        """
        Forward pass with hierarchical reasoning.

        Args:
            rules_text: Puzzle rules as text
            visual_elements_str: Visual elements as JSON string
            board_state: Board state as string (. for empty, digits for filled)
            rows: Number of rows
            cols: Number of columns
            state: Previous state (optional)
            return_all_positions: If True, return logits for all positions
            return_yrsn_metrics: If True and use_yrsn_monitoring=True, return YRSN metrics

        Returns:
            position_logits or all_logits: Prediction logits
            digit_logits or all_logits: Digit logits
            new_state: Updated state
            yrsn_metrics: YRSN metrics dict if monitoring enabled and requested, else None
        """
        # Encode input (simple encoder, NO YRSN)
        context = self.encoder(rules_text, visual_elements_str, board_state, rows, cols)

        # Add batch dimension
        if context.dim() == 2:
            context = context.unsqueeze(0)

        batch_size, seq_len, _ = context.shape
        device = context.device

        # Initialize state if needed
        if state is None:
            state = self.initial_state(batch_size, seq_len, device)

        z_H = state.z_H
        z_L = state.z_L

        # Hierarchical reasoning (original HRM algorithm)
        # ACT Q-values are computed but not used for early stopping in forward pass
        # (early stopping would be done in inference with dynamic halting)
        for h_step in range(self.H_cycles):
            for l_step in range(self.L_cycles):
                # L-level update: fast, detailed
                # ABL-08: Use learned stitching if enabled for geometric alignment
                if self.use_learned_stitching:
                    l_input = self.stitch_H_to_L(z_H, context)
                else:
                    l_input = z_H + context  # Original additive stitching
                l_result = self.L_level(z_L, l_input)
                z_L = l_result[0] if self.use_act else l_result

            # H-level update: slow, abstract
            if self.use_learned_stitching:
                h_input = self.stitch_L_to_H(z_L)
            else:
                h_input = z_L  # Original (no stitching needed, direct pass)
            h_result = self.H_level(z_H, h_input)
            z_H = h_result[0] if self.use_act else h_result

        # Create new state
        new_state = HRMVState(z_H=z_H.detach(), z_L=z_L.detach())

        # Compute YRSN metrics if requested and monitoring is enabled
        yrsn_metrics = None
        if return_yrsn_metrics and self.use_yrsn_monitoring:
            # Lazy initialization of projection heads
            if not self._projections_initialized:
                self._initialize_projections(device)

            # Use shared utility to compute metrics (avoids code drift)
            yrsn_metrics = compute_yrsn_monitoring_metrics(
                self.H_projection_heads, self.L_projection_heads, z_H, z_L
            )

        if return_all_positions:
            all_logits = self.lm_head(z_H)  # [batch, seq_len, vocab_size]
            return all_logits, all_logits, new_state, yrsn_metrics
        else:
            # Legacy mode: use pooled representation
            output_repr = z_H.mean(dim=1)  # [batch, hidden_size]
            position_logits = self.position_head(output_repr)
            digit_logits = self.digit_head(output_repr)
            return position_logits, digit_logits, new_state, yrsn_metrics

    def forward_batch(
        self,
        contexts: torch.Tensor,
        state: Optional[HRMVState] = None,
        H_cycles: Optional[int] = None,
        L_cycles: Optional[int] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMVState]:
        """
        Batch forward pass with pre-encoded contexts.

        Args:
            contexts: Pre-encoded contexts [batch, seq_len, hidden_size]
            state: Previous state (optional)
            H_cycles: Override H-level iterations (for faster training)
            L_cycles: Override L-level iterations (for faster training)

        Returns:
            position_logits: [batch, 81]
            digit_logits: [batch, 9]
            new_state: Updated state
        """
        batch_size, seq_len, _ = contexts.shape
        device = contexts.device

        # Use overrides or defaults
        h_iters = H_cycles if H_cycles is not None else self.H_cycles
        l_iters = L_cycles if L_cycles is not None else self.L_cycles

        if state is None:
            state = self.initial_state(batch_size, seq_len, device)

        z_H = state.z_H
        z_L = state.z_L

        # Hierarchical reasoning (with optional reduced iterations for training)
        for h_step in range(h_iters):
            for l_step in range(l_iters):
                l_result = self.L_level(z_L, z_H + contexts)
                z_L = l_result[0] if self.use_act else l_result
            h_result = self.H_level(z_H, z_L)
            z_H = h_result[0] if self.use_act else h_result

        new_state = HRMVState(z_H=z_H.detach(), z_L=z_L.detach())

        output_repr = z_H.mean(dim=1)
        position_logits = self.position_head(output_repr)
        digit_logits = self.digit_head(output_repr)

        return position_logits, digit_logits, new_state

    def forward_batch_from_strings(
        self,
        rules_texts: List[str],
        visual_elements_strs: List[str],
        board_states: List[str],
        rows: int,
        cols: int,
        state: Optional[HRMVState] = None,
        H_cycles: Optional[int] = None,
        L_cycles: Optional[int] = None
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMVState]:
        """
        Complete batched forward: encode + reason.

        For training, use this instead of per-sample forward() calls.
        Requires all samples to have SAME grid size.

        Args:
            rules_texts: List of rules strings [batch_size]
            visual_elements_strs: List of visual JSON strings [batch_size]
            board_states: List of board state strings [batch_size]
            rows: Grid rows (same for all!)
            cols: Grid cols (same for all!)
            state: Optional previous state
            H_cycles: Override H-level iterations (for faster training)
            L_cycles: Override L-level iterations (for faster training)

        Returns:
            position_logits: [batch_size, 81]
            digit_logits: [batch_size, 9]
            new_state: Updated state
        """
        # Batch encode
        contexts = self.encoder.encode_batch(
            rules_texts, visual_elements_strs, board_states, rows, cols
        )
        # Batch forward (with optional iteration override for training speed)
        return self.forward_batch(contexts, state, H_cycles=H_cycles, L_cycles=L_cycles)


def count_parameters(model: nn.Module) -> int:
    """Count trainable parameters"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# ============================================================================
# Model Comparison Helper
# ============================================================================

def compare_hrmv_vs_yrsn():
    """Print comparison between HRMV and YRSN-Enhanced HRM"""
    print("=" * 70)
    print("HRMV vs YRSN-Enhanced HRM Comparison")
    print("=" * 70)
    print()
    print("HRMV (Baseline):")
    print("  - Original HRM architecture (Wang et al. 2506.21734)")
    print("  - Simple learned word embeddings")
    print("  - One-hot board encoding")
    print("  - Sparse visual element features")
    print("  - NO pre-trained models")
    print("  - NO instruction boosting")
    print("  - NO SigLIP visual encoding")
    print()
    print("YRSN-Enhanced HRM:")
    print("  - Same HRM architecture")
    print("  - Pre-trained sentence transformer (all-MiniLM-L6-v2)")
    print("  - Rich board state encoding")
    print("  - SigLIP multimodal visual encoding")
    print("  - Instruction boosting (3.73x)")
    print("  - Task-specific encoding")
    print()

    # Create models and compare
    hrmv = HRMV(hidden_size=256)
    print(f"HRMV Parameters: {count_parameters(hrmv):,}")

    try:
        from yrsn.models.hrm import YRSNEnhancedHRM
        yrsn_hrm = YRSNEnhancedHRM(hidden_size=256)
        print(f"YRSN-HRM Parameters: {count_parameters(yrsn_hrm):,}")
    except ImportError:
        print("YRSN-HRM: (import failed)")

    print("=" * 70)


if __name__ == "__main__":
    compare_hrmv_vs_yrsn()

    # Quick test
    print("\nQuick HRMV test:")
    model = HRMV(hidden_size=64, H_layers=2, L_layers=2, H_cycles=2, L_cycles=3)
    print(f"  Parameters: {count_parameters(model):,}")

    pos_logits, digit_logits, state, _ = model(
        rules_text="Normal sudoku rules. Digits on a V sum to 5.",
        visual_elements_str='[{"type": "cage", "cells": ["r1c1", "r1c2"], "value": 5}]',
        board_state="." * 81,
        rows=9,
        cols=9
    )

    print(f"  Position logits shape: {pos_logits.shape}")
    print(f"  Digit logits shape: {digit_logits.shape}")
    print("  HRMV working correctly!")
