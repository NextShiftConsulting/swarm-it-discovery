"""
Bloom-Level Neural Heads

Each Bloom level has dedicated neural network heads that:
1. Take the appropriate latent state as input
2. Produce level-specific predictions
3. Enable level-specific losses

Architecture:
    REMEMBER heads: Rule classifier, Constraint reconstructor
    ANALYZE heads: Break-in position scorer, Critical region detector
    EVALUATE heads: Move scorer, Signal classifier
    CREATE heads: Final output predictor, Halting predictor

These heads attach to different parts of the TRM:
    - reasoning_latent (z_t): REMEMBER, ANALYZE
    - solution_state (y_t): EVALUATE, CREATE

This module is domain-agnostic. All domain-specific values (num_positions,
num_values, etc.) are passed via configuration.
"""

from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .levels import BloomLevel, BLOOM_HIERARCHY


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class BloomHeadsConfig:
    """Configuration for Bloom heads - domain-agnostic."""
    hidden_size: int = 256

    # Problem structure (set per domain)
    num_positions: int = 81       # e.g., 81 for 9x9 Sudoku
    num_values: int = 9           # e.g., 9 digits for Sudoku
    num_regions: int = 27         # e.g., 9 rows + 9 cols + 9 boxes

    # Rule/constraint configuration
    num_rule_types: int = 10      # Number of constraint type categories
    max_constraints: int = 20     # Max constraints per problem

    # Signal classification (R/S/N or custom)
    num_signal_classes: int = 3   # Default: Relevant/Superfluous/Noise

    # Solution path
    max_path_length: int = 81     # Max moves in solution path


# =============================================================================
# Base Head Class
# =============================================================================

class BloomHead(nn.Module):
    """Base class for all Bloom-level heads."""

    def __init__(self, level: BloomLevel, config: BloomHeadsConfig):
        super().__init__()
        self.level = level
        self.config = config
        self.hidden_size = config.hidden_size
        self.spec = BLOOM_HIERARCHY[level]

    def get_level_name(self) -> str:
        return self.spec.name


# =============================================================================
# Level 1: REMEMBER Heads
# =============================================================================

class RuleClassifierHead(nn.Module):
    """
    Classifies which variant rules are active in a problem.

    Input: reasoning_latent z_t [batch, hidden]
    Output: rule_logits [batch, num_rule_types]

    Domain-agnostic: number of rule types is configurable.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_rules = config.num_rule_types

        self.classifier = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(config.hidden_size // 2, self.num_rules)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z: reasoning latent [batch, hidden] or [batch, seq, hidden]

        Returns:
            rule_logits: [batch, num_rules] multi-label logits
        """
        if z.dim() == 3:
            # Pool sequence dimension
            z = z.mean(dim=1)

        return self.classifier(z)


class ConstraintReconstructionHead(nn.Module):
    """
    Reconstructs constraint parameters from latent state.

    Input: reasoning_latent z_t [batch, hidden]
    Output: constraint parameters (types, values, positions involved)

    This verifies the model "understands" the constraints, not just classifies them.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.config = config

        # Predict number of constraints
        self.count_head = nn.Linear(config.hidden_size, config.max_constraints + 1)

        # Predict constraint type per slot
        self.type_head = nn.Linear(config.hidden_size, config.num_rule_types)

        # Predict constraint values (domain-specific, e.g., sum values for killer cages)
        # Use a reasonable max value range
        self.value_head = nn.Linear(config.hidden_size, 64)

        # Predict position involvement (which positions in each constraint)
        self.position_head = nn.Linear(config.hidden_size, config.num_positions)

    def forward(
        self,
        z: torch.Tensor,
        return_all: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            z: reasoning latent [batch, hidden]
            return_all: if True, return all outputs; else just primary

        Returns:
            Dict with constraint reconstruction predictions
        """
        if z.dim() == 3:
            z = z.mean(dim=1)

        outputs = {
            'count_logits': self.count_head(z),
            'type_logits': self.type_head(z),
        }

        if return_all:
            outputs['value_logits'] = self.value_head(z)
            outputs['position_logits'] = self.position_head(z)

        return outputs


class RememberHead(BloomHead):
    """
    Combined head for REMEMBER level.

    Outputs:
        - Rule classification (which constraint types are present)
        - Constraint reconstruction (verifies understanding)
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__(BloomLevel.REMEMBER, config)

        self.rule_classifier = RuleClassifierHead(config)
        self.constraint_reconstructor = ConstraintReconstructionHead(config)

    def forward(
        self,
        z: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            z: reasoning latent [batch, hidden] or [batch, seq, hidden]

        Returns:
            Dict with rule_logits, constraint predictions
        """
        return {
            'rule_logits': self.rule_classifier(z),
            **self.constraint_reconstructor(z)
        }


# =============================================================================
# Level 2: ANALYZE Heads
# =============================================================================

class BreakInPositionHead(nn.Module):
    """
    Scores each position as a potential break-in point.

    Input: reasoning_latent z_t [batch, seq=num_positions, hidden]
    Output: breakin_scores [batch, num_positions]

    High score = good starting point for reasoning.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_positions = config.num_positions

        # Per-position scoring
        self.position_scorer = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, 1)
        )

        # Global context for relative scoring
        self.context_proj = nn.Linear(config.hidden_size, config.hidden_size // 2)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z: reasoning latent [batch, num_positions, hidden]

        Returns:
            breakin_scores: [batch, num_positions] unnormalized scores
        """
        batch_size = z.shape[0]

        if z.dim() == 2:
            # Expand to per-position
            z = z.unsqueeze(1).expand(-1, self.num_positions, -1)

        # Score each position
        scores = self.position_scorer(z).squeeze(-1)  # [batch, num_positions]

        return scores


class CriticalRegionHead(nn.Module):
    """
    Identifies critical regions (rows, cols, boxes, constraint groups).

    Input: reasoning_latent z_t [batch, hidden]
    Output: region_scores [batch, num_regions + max_constraints]

    Domain-agnostic: num_regions and max_constraints are configurable.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_regions = config.num_regions
        self.max_constraints = config.max_constraints
        self.total_regions = self.num_regions + self.max_constraints

        self.region_scorer = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.GELU(),
            nn.Linear(config.hidden_size, self.total_regions)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z: reasoning latent [batch, hidden]

        Returns:
            region_scores: [batch, num_regions]
        """
        if z.dim() == 3:
            z = z.mean(dim=1)

        return self.region_scorer(z)


class AnalyzeHead(BloomHead):
    """
    Combined head for ANALYZE level.

    Outputs:
        - Break-in position scores (where to start)
        - Critical region scores (what to focus on)
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__(BloomLevel.ANALYZE, config)

        self.breakin_head = BreakInPositionHead(config)
        self.region_head = CriticalRegionHead(config)

    def forward(
        self,
        z: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            z: reasoning latent [batch, num_positions, hidden] or [batch, hidden]

        Returns:
            Dict with breakin_scores, region_scores
        """
        # Get global representation for region scoring
        if z.dim() == 3:
            z_global = z.mean(dim=1)
        else:
            z_global = z

        return {
            'breakin_scores': self.breakin_head(z),
            'region_scores': self.region_head(z_global)
        }


# =============================================================================
# Level 3: EVALUATE Heads
# =============================================================================

class MoveScorerHead(nn.Module):
    """
    Scores candidate moves (position, value pairs).

    Input: solution_state y_t [batch, num_positions, hidden]
    Output: move_scores [batch, num_positions, num_values]

    Each score represents quality of placing value v in position p.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_positions = config.num_positions
        self.num_values = config.num_values

        # Per-position value scorer
        self.value_scorer = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.GELU(),
            nn.Linear(config.hidden_size, self.num_values)
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, num_positions, hidden]

        Returns:
            move_scores: [batch, num_positions, num_values]
        """
        if y.dim() == 2:
            y = y.unsqueeze(1).expand(-1, self.num_positions, -1)

        return self.value_scorer(y)


class SignalClassifierHead(nn.Module):
    """
    Classifies moves into signal categories (e.g., R/S/N for YRSN).

    Input: solution_state y_t + move embedding
    Output: signal_logits [batch, num_positions, num_signal_classes]

    Default classes (YRSN):
        R (Relevant): High-confidence valid move
        S (Superfluous): Valid but uncertain
        N (Noise): Violates constraints

    Configurable for other signal classification schemes.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_positions = config.num_positions
        self.num_classes = config.num_signal_classes

        self.classifier = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, self.num_classes)
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, num_positions, hidden]

        Returns:
            signal_logits: [batch, num_positions, num_signal_classes]
        """
        if y.dim() == 2:
            y = y.unsqueeze(1).expand(-1, self.num_positions, -1)

        return self.classifier(y)


class MoveConfidenceHead(nn.Module):
    """
    Predicts confidence in the top move choice.

    This enables calibrated predictions (model knows when it's uncertain).
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()

        self.confidence = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, hidden] or [batch, num_positions, hidden]

        Returns:
            confidence: [batch, 1]
        """
        if y.dim() == 3:
            y = y.mean(dim=1)

        return self.confidence(y)


class EvaluateHead(BloomHead):
    """
    Combined head for EVALUATE level.

    Outputs:
        - Move scores (quality of each position-value pair)
        - Signal classification (R/S/N per position)
        - Confidence (calibration)
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__(BloomLevel.EVALUATE, config)

        self.move_scorer = MoveScorerHead(config)
        self.signal_classifier = SignalClassifierHead(config)
        self.confidence_head = MoveConfidenceHead(config)

    def forward(
        self,
        y: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            y: solution state [batch, num_positions, hidden]

        Returns:
            Dict with move_scores, signal_logits, confidence
        """
        return {
            'move_scores': self.move_scorer(y),
            'signal_logits': self.signal_classifier(y),
            'confidence': self.confidence_head(y)
        }


# =============================================================================
# Level 4: CREATE Heads
# =============================================================================

class FinalOutputHead(nn.Module):
    """
    Predicts the final solved output.

    Input: solution_state y_T [batch, num_positions, hidden]
    Output: output_logits [batch, num_positions, num_values]

    Each position predicts distribution over possible values.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.num_positions = config.num_positions
        self.num_values = config.num_values

        self.output_predictor = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.GELU(),
            nn.Linear(config.hidden_size, self.num_values)
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, num_positions, hidden]

        Returns:
            output_logits: [batch, num_positions, num_values]
        """
        if y.dim() == 2:
            y = y.unsqueeze(1).expand(-1, self.num_positions, -1)

        return self.output_predictor(y)


class HaltingHead(nn.Module):
    """
    Predicts whether the current state is "solved enough".

    Implements Adaptive Computation Time (ACT) style halting.

    Input: solution_state y_t [batch, hidden]
    Output: halt_prob [batch, 1]
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()

        self.halting = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, 1),
            nn.Sigmoid(),
        )

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, hidden] or [batch, num_positions, hidden]

        Returns:
            halt_prob: [batch, 1] probability of halting
        """
        if y.dim() == 3:
            y = y.mean(dim=1)

        return self.halting(y)


class SolutionPathHead(nn.Module):
    """
    Predicts a sequence of key moves (optional, for interpretability).

    Input: solution_state y_T [batch, hidden]
    Output: path_logits [batch, max_moves, num_positions * num_values]
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.max_moves = config.max_path_length
        self.num_moves = config.num_positions * config.num_values

        # Simple autoregressive path predictor
        self.path_rnn = nn.GRU(
            input_size=config.hidden_size,
            hidden_size=config.hidden_size,
            num_layers=1,
            batch_first=True
        )
        self.move_head = nn.Linear(config.hidden_size, self.num_moves)

    def forward(self, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            y: solution state [batch, hidden]

        Returns:
            path_logits: [batch, max_moves, num_moves]
        """
        if y.dim() == 3:
            y = y.mean(dim=1)

        batch_size = y.shape[0]

        # Initial hidden state
        h = y.unsqueeze(0)  # [1, batch, hidden]

        # Generate path autoregressively
        outputs = []
        x = y.unsqueeze(1)  # [batch, 1, hidden]

        for _ in range(self.max_moves):
            out, h = self.path_rnn(x, h)
            move_logits = self.move_head(out.squeeze(1))  # [batch, num_moves]
            outputs.append(move_logits)
            x = out

        return torch.stack(outputs, dim=1)  # [batch, max_moves, num_moves]


class CreateHead(BloomHead):
    """
    Combined head for CREATE level.

    Outputs:
        - Final output prediction
        - Halting probability (ACT)
        - Optional solution path
    """

    def __init__(self, config: BloomHeadsConfig, include_path: bool = False):
        super().__init__(BloomLevel.CREATE, config)

        self.final_output = FinalOutputHead(config)
        self.halting = HaltingHead(config)
        self.include_path = include_path
        if include_path:
            self.solution_path = SolutionPathHead(config)

    def forward(
        self,
        y: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            y: solution state [batch, num_positions, hidden]

        Returns:
            Dict with output_logits, halt_prob, (path_logits)
        """
        outputs = {
            'output_logits': self.final_output(y),
            'halt_prob': self.halting(y)
        }

        if self.include_path:
            outputs['path_logits'] = self.solution_path(y)

        return outputs


# =============================================================================
# Level 5: META Heads
# =============================================================================

class StrategyClassifierHead(nn.Module):
    """
    Classifies which reasoning strategy should be used.

    Input: reasoning_latent z + solution_state y
    Output: strategy_logits [batch, num_strategies]

    Strategies represent high-level reasoning approaches:
    - Constraint propagation vs search
    - Local vs global reasoning
    - Forward vs backward chaining
    """

    def __init__(self, config: BloomHeadsConfig, num_strategies: int = 20):
        super().__init__()
        self.num_strategies = num_strategies

        self.strategy_encoder = nn.Sequential(
            nn.Linear(config.hidden_size * 2, config.hidden_size),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, num_strategies)
        )

    def forward(self, z: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z: reasoning latent [batch, hidden]
            y: solution state [batch, hidden] or [batch, seq, hidden]

        Returns:
            strategy_logits: [batch, num_strategies]
        """
        if z.dim() == 3:
            z = z.mean(dim=1)
        if y.dim() == 3:
            y = y.mean(dim=1)

        combined = torch.cat([z, y], dim=-1)
        return self.strategy_encoder(combined)


class DomainInvarianceHead(nn.Module):
    """
    Extracts domain-invariant features for transfer learning.

    Input: reasoning_latent z
    Output: invariant_features [batch, feature_dim]

    These features should be consistent across different problem
    variants (e.g., standard vs killer Sudoku).
    """

    def __init__(self, config: BloomHeadsConfig, feature_dim: int = 64):
        super().__init__()
        self.feature_dim = feature_dim

        # Encoder with domain adversarial training in mind
        self.encoder = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size),
            nn.GELU(),
            nn.Linear(config.hidden_size, feature_dim),
        )

        # Optional: domain classifier (for adversarial training)
        self.domain_classifier = nn.Sequential(
            nn.Linear(feature_dim, feature_dim // 2),
            nn.GELU(),
            nn.Linear(feature_dim // 2, config.num_rule_types)  # Classify domain by rule types
        )

    def forward(
        self,
        z: torch.Tensor,
        return_domain_logits: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            z: reasoning latent [batch, hidden]
            return_domain_logits: whether to include domain classification

        Returns:
            Dict with invariant_features and optionally domain_logits
        """
        if z.dim() == 3:
            z = z.mean(dim=1)

        features = self.encoder(z)
        outputs = {'invariant_features': features}

        if return_domain_logits:
            # Gradient reversal would be applied here during training
            outputs['domain_logits'] = self.domain_classifier(features)

        return outputs


class TraceReconstructionHead(nn.Module):
    """
    Reconstructs the reasoning trace from final state.

    Input: solution_state y + reasoning_latent z
    Output: trace_logits [batch, max_path_length, num_moves]

    This encourages the model to maintain interpretable reasoning.
    """

    def __init__(self, config: BloomHeadsConfig):
        super().__init__()
        self.max_path = config.max_path_length
        self.num_moves = config.num_positions * config.num_values

        # Trace decoder using GRU
        self.decoder = nn.GRU(
            input_size=config.hidden_size,
            hidden_size=config.hidden_size,
            num_layers=2,
            batch_first=True,
            dropout=0.1
        )

        self.move_head = nn.Linear(config.hidden_size, self.num_moves)

        # Initial state projection
        self.init_proj = nn.Linear(config.hidden_size * 2, config.hidden_size)

    def forward(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        max_steps: Optional[int] = None
    ) -> torch.Tensor:
        """
        Args:
            z: reasoning latent [batch, hidden]
            y: solution state [batch, hidden] or [batch, seq, hidden]
            max_steps: max trace length (default: config.max_path_length)

        Returns:
            trace_logits: [batch, max_steps, num_moves]
        """
        if z.dim() == 3:
            z = z.mean(dim=1)
        if y.dim() == 3:
            y = y.mean(dim=1)

        batch_size = z.shape[0]
        device = z.device
        max_steps = max_steps or self.max_path

        # Initialize decoder state
        combined = torch.cat([z, y], dim=-1)
        h0 = self.init_proj(combined).unsqueeze(0).repeat(2, 1, 1)  # [2, batch, hidden]

        # Generate trace autoregressively
        x = z.unsqueeze(1)  # [batch, 1, hidden]
        outputs = []

        for _ in range(max_steps):
            out, h0 = self.decoder(x, h0)
            move_logits = self.move_head(out.squeeze(1))  # [batch, num_moves]
            outputs.append(move_logits)
            x = out

        return torch.stack(outputs, dim=1)  # [batch, max_steps, num_moves]


class MetaHead(BloomHead):
    """
    Combined head for META level.

    Outputs:
        - Strategy classification (which approach to use)
        - Domain invariant features (for transfer)
        - Reasoning trace reconstruction (interpretability)
    """

    def __init__(
        self,
        config: BloomHeadsConfig,
        num_strategies: int = 20,
        invariant_dim: int = 64,
        include_trace: bool = True
    ):
        super().__init__(BloomLevel.META, config)

        self.strategy_head = StrategyClassifierHead(config, num_strategies)
        self.domain_head = DomainInvarianceHead(config, invariant_dim)
        self.include_trace = include_trace
        if include_trace:
            self.trace_head = TraceReconstructionHead(config)

    def forward(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        return_trace: bool = True
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            z: reasoning latent [batch, hidden] or [batch, seq, hidden]
            y: solution state [batch, hidden] or [batch, seq, hidden]
            return_trace: whether to compute trace reconstruction

        Returns:
            Dict with strategy_logits, invariant_features, (trace_logits)
        """
        outputs = {
            'strategy_logits': self.strategy_head(z, y),
            **self.domain_head(z, return_domain_logits=True)
        }

        if self.include_trace and return_trace:
            outputs['trace_logits'] = self.trace_head(z, y)

        return outputs


# =============================================================================
# Combined Head Bank
# =============================================================================

class BloomHeadBank(nn.Module):
    """
    Bank of all Bloom-level heads.

    This is the main entry point for level-specific predictions.
    Domain-agnostic: all parameters come from BloomHeadsConfig.
    """

    def __init__(
        self,
        config: Optional[BloomHeadsConfig] = None,
        # Convenience kwargs for quick instantiation
        hidden_size: int = 256,
        num_positions: int = 81,
        num_values: int = 9,
        num_regions: int = 27,
        num_rule_types: int = 10,
        max_constraints: int = 20,
        num_signal_classes: int = 3,
        include_solution_path: bool = False,
    ):
        super().__init__()

        # Build config from kwargs if not provided
        if config is None:
            config = BloomHeadsConfig(
                hidden_size=hidden_size,
                num_positions=num_positions,
                num_values=num_values,
                num_regions=num_regions,
                num_rule_types=num_rule_types,
                max_constraints=max_constraints,
                num_signal_classes=num_signal_classes,
            )

        self.config = config

        # Create all heads
        self.remember = RememberHead(config)
        self.analyze = AnalyzeHead(config)
        self.evaluate = EvaluateHead(config)
        self.create = CreateHead(config, include_path=include_solution_path)
        self.meta = MetaHead(config, include_trace=include_solution_path)

        # Register heads by level
        self.heads = nn.ModuleDict({
            'remember': self.remember,
            'analyze': self.analyze,
            'evaluate': self.evaluate,
            'create': self.create,
            'meta': self.meta,
        })

    def forward(
        self,
        z: torch.Tensor,              # reasoning latent [batch, num_positions, hidden]
        y: torch.Tensor,              # solution state [batch, num_positions, hidden]
        active_levels: List[BloomLevel] = None
    ) -> Dict[str, Dict[str, torch.Tensor]]:
        """
        Run all active Bloom heads.

        Args:
            z: reasoning latent
            y: solution state
            active_levels: which levels to compute (None = all)

        Returns:
            Dict[level_name, Dict[output_name, tensor]]
        """
        if active_levels is None:
            active_levels = list(BloomLevel)

        outputs = {}

        for level in active_levels:
            if level == BloomLevel.REMEMBER:
                outputs['remember'] = self.remember(z)
            elif level == BloomLevel.ANALYZE:
                outputs['analyze'] = self.analyze(z)
            elif level == BloomLevel.EVALUATE:
                outputs['evaluate'] = self.evaluate(y)
            elif level == BloomLevel.CREATE:
                outputs['create'] = self.create(y)
            elif level == BloomLevel.META:
                outputs['meta'] = self.meta(z, y)

        return outputs

    def get_head(self, level: BloomLevel) -> BloomHead:
        """Get head for a specific level."""
        name = level.name.lower()
        return self.heads[name]


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config
    'BloomHeadsConfig',
    # Base
    'BloomHead',
    # Remember
    'RuleClassifierHead',
    'ConstraintReconstructionHead',
    'RememberHead',
    # Analyze
    'BreakInPositionHead',
    'CriticalRegionHead',
    'AnalyzeHead',
    # Evaluate
    'MoveScorerHead',
    'SignalClassifierHead',
    'MoveConfidenceHead',
    'EvaluateHead',
    # Create
    'FinalOutputHead',
    'HaltingHead',
    'SolutionPathHead',
    'CreateHead',
    # Meta
    'StrategyClassifierHead',
    'DomainInvarianceHead',
    'TraceReconstructionHead',
    'MetaHead',
    # Combined
    'BloomHeadBank',
]
