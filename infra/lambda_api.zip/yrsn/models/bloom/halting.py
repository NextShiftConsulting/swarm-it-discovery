"""
Dual Halting Module

Implements adaptive computation time via two complementary approaches:
1. ACT-style sigmoid: Probability accumulation until threshold
2. Q-learning: Learn when to halt based on reward signal

The dual approach provides robustness:
- ACT is differentiable and easy to train
- Q-learning can learn complex halting policies

Configuration:
- mode="act": ACT only (fast, simple)
- mode="qlearning": Q-learning only (flexible, needs reward)
- mode="dual": Both (ensemble for robustness)
"""

from typing import Dict, Optional, Tuple
from dataclasses import dataclass, field
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class HaltingConfig:
    """Configuration for dual halting module."""
    hidden_size: int = 256

    # Mode selection
    mode: str = "dual"  # "act", "qlearning", "dual"

    # ACT parameters
    act_threshold: float = 0.5  # Cumulative probability threshold
    act_epsilon: float = 0.01   # Small value for numerical stability

    # Q-learning parameters
    q_hidden_size: int = 128    # Hidden size for Q-network
    q_epsilon: float = 0.1      # Exploration rate (epsilon-greedy)
    q_gamma: float = 0.99       # Discount factor
    num_q_actions: int = 2      # 0=continue, 1=halt

    # Constraints
    min_steps: int = 2          # Minimum steps before halting allowed
    max_steps: int = 10         # Maximum steps (forced halt)

    # Loss weights
    act_loss_weight: float = 0.01    # ACT ponder cost weight
    q_loss_weight: float = 0.1       # Q-learning TD loss weight


class ACTHaltingHead(nn.Module):
    """
    Adaptive Computation Time halting head.

    Predicts halt probability at each step. Accumulates probabilities
    until threshold is reached.

    Paper: "Adaptive Computation Time for RNNs" (Graves, 2016)
    """

    def __init__(self, config: HaltingConfig):
        super().__init__()
        self.config = config

        self.halting = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(config.hidden_size // 2, 1),
        )

    def forward(
        self,
        state: torch.Tensor,
        cumulative_prob: Optional[torch.Tensor] = None,
        step: int = 0,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Compute halt probability for current step.

        Args:
            state: Current hidden state [batch, hidden]
            cumulative_prob: Accumulated halt probability [batch]
            step: Current step number

        Returns:
            halt_prob: Raw probability for this step [batch]
            cumulative: Updated cumulative probability [batch]
            halted: Boolean mask of halted samples [batch]
        """
        if state.dim() == 3:
            state = state.mean(dim=1)

        batch_size = state.shape[0]
        device = state.device

        # Initialize cumulative if needed
        if cumulative_prob is None:
            cumulative_prob = torch.zeros(batch_size, device=device)

        # Compute halt probability
        halt_logit = self.halting(state).squeeze(-1)  # [batch]
        halt_prob = torch.sigmoid(halt_logit)

        # Before min_steps, force halt_prob to 0
        if step < self.config.min_steps:
            halt_prob = torch.zeros_like(halt_prob)

        # At max_steps, force remaining probability
        if step >= self.config.max_steps - 1:
            halt_prob = 1.0 - cumulative_prob

        # Update cumulative probability
        new_cumulative = cumulative_prob + halt_prob * (1 - cumulative_prob)

        # Determine if halted
        halted = new_cumulative >= self.config.act_threshold

        return halt_prob, new_cumulative, halted

    def compute_act_loss(
        self,
        halt_probs: torch.Tensor,
        num_steps: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute ACT ponder cost loss.

        Penalizes using more computation steps than necessary.

        Args:
            halt_probs: [batch, max_steps] halt probabilities per step
            num_steps: [batch] actual number of steps used

        Returns:
            ACT loss (encourages early halting)
        """
        # Ponder cost is the expected number of steps
        batch_size, max_steps = halt_probs.shape
        step_weights = torch.arange(1, max_steps + 1, device=halt_probs.device).float()

        # Expected steps = sum(p(halt at step t) * t)
        # Where p(halt at t) = p_t * prod(1 - p_i for i < t)
        cumulative = torch.zeros(batch_size, device=halt_probs.device)
        expected_steps = torch.zeros(batch_size, device=halt_probs.device)

        for t in range(max_steps):
            p_halt_at_t = halt_probs[:, t] * (1 - cumulative)
            expected_steps += p_halt_at_t * (t + 1)
            cumulative += p_halt_at_t

        # Add remainder for samples that haven't halted
        remainder = 1 - cumulative
        expected_steps += remainder * (max_steps + 1)

        return expected_steps.mean()


class QLearningHaltingHead(nn.Module):
    """
    Q-learning based halting head.

    Learns Q-values for continue/halt actions. Can learn complex
    halting policies based on problem difficulty.

    Actions:
        0: Continue (take another reasoning step)
        1: Halt (output current solution)
    """

    def __init__(self, config: HaltingConfig):
        super().__init__()
        self.config = config

        # State encoder
        self.state_encoder = nn.Sequential(
            nn.Linear(config.hidden_size, config.q_hidden_size),
            nn.GELU(),
            nn.Dropout(0.1),
        )

        # Q-network
        self.q_network = nn.Sequential(
            nn.Linear(config.q_hidden_size + 1, config.q_hidden_size),  # +1 for step info
            nn.GELU(),
            nn.Linear(config.q_hidden_size, config.num_q_actions)
        )

        # Target network for stable Q-learning
        self.target_encoder = nn.Sequential(
            nn.Linear(config.hidden_size, config.q_hidden_size),
            nn.GELU(),
        )
        self.target_q = nn.Sequential(
            nn.Linear(config.q_hidden_size + 1, config.q_hidden_size),
            nn.GELU(),
            nn.Linear(config.q_hidden_size, config.num_q_actions)
        )

        # Copy initial weights
        self._update_target(tau=1.0)

    def _update_target(self, tau: float = 0.01):
        """Soft update target network."""
        for target_param, param in zip(
            list(self.target_encoder.parameters()) + list(self.target_q.parameters()),
            list(self.state_encoder.parameters()) + list(self.q_network.parameters())
        ):
            target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)

    def forward(
        self,
        state: torch.Tensor,
        step: int = 0,
        explore: bool = True,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Compute Q-values and decide action.

        Args:
            state: Current hidden state [batch, hidden]
            step: Current step number
            explore: Whether to use epsilon-greedy exploration

        Returns:
            q_values: [batch, 2] Q-values for (continue, halt)
            action: [batch] chosen action (0=continue, 1=halt)
            halted: [batch] boolean mask
        """
        if state.dim() == 3:
            state = state.mean(dim=1)

        batch_size = state.shape[0]
        device = state.device

        # Encode state
        encoded = self.state_encoder(state)

        # Add step information (normalized)
        step_info = torch.full((batch_size, 1), step / self.config.max_steps, device=device)
        q_input = torch.cat([encoded, step_info], dim=-1)

        # Compute Q-values
        q_values = self.q_network(q_input)  # [batch, 2]

        # Choose action
        if explore and self.training:
            # Epsilon-greedy
            random_action = torch.randint(0, 2, (batch_size,), device=device)
            greedy_action = q_values.argmax(dim=-1)
            explore_mask = torch.rand(batch_size, device=device) < self.config.q_epsilon
            action = torch.where(explore_mask, random_action, greedy_action)
        else:
            action = q_values.argmax(dim=-1)

        # Enforce min/max step constraints
        if step < self.config.min_steps:
            action = torch.zeros_like(action)  # Force continue
        elif step >= self.config.max_steps - 1:
            action = torch.ones_like(action)   # Force halt

        halted = action == 1

        return q_values, action, halted

    def compute_td_loss(
        self,
        states: torch.Tensor,          # [batch, max_steps, hidden]
        actions: torch.Tensor,          # [batch, max_steps]
        rewards: torch.Tensor,          # [batch, max_steps]
        dones: torch.Tensor,            # [batch, max_steps]
        steps: torch.Tensor,            # [batch, max_steps] step numbers
    ) -> torch.Tensor:
        """
        Compute TD-error loss for Q-learning.

        Args:
            states: Hidden states at each step
            actions: Actions taken at each step
            rewards: Rewards received at each step
            dones: Whether episode ended at each step
            steps: Step numbers

        Returns:
            TD-error loss
        """
        batch_size, max_steps, hidden_size = states.shape
        device = states.device

        total_loss = torch.tensor(0.0, device=device)
        valid_steps = 0

        for t in range(max_steps - 1):
            # Current state Q-values
            encoded = self.state_encoder(states[:, t])
            step_info = steps[:, t:t+1] / self.config.max_steps
            q_input = torch.cat([encoded, step_info], dim=-1)
            q_values = self.q_network(q_input)

            # Q-value of action taken
            q_taken = q_values.gather(1, actions[:, t:t+1].long()).squeeze(-1)

            # Target Q-value
            with torch.no_grad():
                next_encoded = self.target_encoder(states[:, t+1])
                next_step_info = steps[:, t+1:t+2] / self.config.max_steps
                next_q_input = torch.cat([next_encoded, next_step_info], dim=-1)
                next_q = self.target_q(next_q_input)
                next_q_max = next_q.max(dim=-1).values

                target = rewards[:, t] + self.config.q_gamma * next_q_max * (1 - dones[:, t].float())

            # TD-error
            td_error = F.mse_loss(q_taken, target)

            # Mask invalid steps
            valid_mask = steps[:, t] >= 0
            if valid_mask.any():
                total_loss += td_error
                valid_steps += 1

        if valid_steps > 0:
            total_loss = total_loss / valid_steps

        return total_loss


class DualHaltingModule(nn.Module):
    """
    Dual halting module combining ACT and Q-learning.

    The ensemble approach:
    - Uses ACT for differentiable training signal
    - Uses Q-learning for policy learning
    - Combines for robust halting decisions
    """

    def __init__(self, config: HaltingConfig):
        super().__init__()
        self.config = config
        self.mode = config.mode

        # Initialize heads based on mode
        if self.mode in ("act", "dual"):
            self.act_head = ACTHaltingHead(config)
        if self.mode in ("qlearning", "dual"):
            self.q_head = QLearningHaltingHead(config)

        # Combination weights (learnable in dual mode)
        if self.mode == "dual":
            self.combination = nn.Parameter(torch.tensor([0.5, 0.5]))

    def forward(
        self,
        state: torch.Tensor,
        step: int = 0,
        cumulative_prob: Optional[torch.Tensor] = None,
        explore: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute halting decision.

        Args:
            state: Current hidden state [batch, hidden]
            step: Current step number
            cumulative_prob: ACT cumulative probability [batch]
            explore: Whether to explore in Q-learning

        Returns:
            Dict with halt decision and supporting values
        """
        outputs = {'step': step}

        if self.mode in ("act", "dual"):
            halt_prob, new_cumulative, act_halted = self.act_head(
                state, cumulative_prob, step
            )
            outputs['act_halt_prob'] = halt_prob
            outputs['cumulative_prob'] = new_cumulative
            outputs['act_halted'] = act_halted

        if self.mode in ("qlearning", "dual"):
            q_values, action, q_halted = self.q_head(state, step, explore)
            outputs['q_values'] = q_values
            outputs['q_action'] = action
            outputs['q_halted'] = q_halted

        # Combine decisions
        if self.mode == "act":
            outputs['halted'] = outputs['act_halted']
            outputs['halt_confidence'] = outputs['act_halt_prob']
        elif self.mode == "qlearning":
            outputs['halted'] = outputs['q_halted']
            outputs['halt_confidence'] = F.softmax(outputs['q_values'], dim=-1)[:, 1]
        else:  # dual
            # Soft combination
            weights = F.softmax(self.combination, dim=0)
            act_conf = outputs['act_halt_prob']
            q_conf = F.softmax(outputs['q_values'], dim=-1)[:, 1]
            combined_conf = weights[0] * act_conf + weights[1] * q_conf
            outputs['halt_confidence'] = combined_conf

            # Halting decision: either system triggers halt
            outputs['halted'] = outputs['act_halted'] | outputs['q_halted']

        return outputs

    def compute_loss(
        self,
        halt_history: Dict[str, torch.Tensor],
        optimal_steps: Optional[torch.Tensor] = None,
        rewards: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute halting losses.

        Args:
            halt_history: Dict with keys:
                - halt_probs: [batch, max_steps] ACT probabilities
                - states: [batch, max_steps, hidden] for Q-learning
                - actions: [batch, max_steps] Q-actions taken
                - rewards: [batch, max_steps] rewards received
                - dones: [batch, max_steps] episode end flags
                - steps: [batch, max_steps] step numbers
            optimal_steps: [batch] ground truth optimal step count
            rewards: [batch] final reward (for reward shaping)

        Returns:
            Dict with loss components
        """
        losses = {}

        if self.mode in ("act", "dual"):
            # ACT ponder cost
            if 'halt_probs' in halt_history:
                act_loss = self.act_head.compute_act_loss(
                    halt_history['halt_probs'],
                    halt_history.get('num_steps', halt_history['halt_probs'].shape[1])
                )
                losses['act_loss'] = act_loss * self.config.act_loss_weight

            # Optional: supervision towards optimal steps
            if optimal_steps is not None and 'halt_probs' in halt_history:
                # Encourage halt at optimal step
                batch_size, max_steps = halt_history['halt_probs'].shape
                target_probs = torch.zeros_like(halt_history['halt_probs'])
                for b in range(batch_size):
                    if optimal_steps[b] < max_steps:
                        target_probs[b, optimal_steps[b]] = 1.0
                supervised_loss = F.binary_cross_entropy(
                    halt_history['halt_probs'],
                    target_probs
                )
                losses['act_supervised_loss'] = supervised_loss

        if self.mode in ("qlearning", "dual"):
            # Q-learning TD loss
            if all(k in halt_history for k in ['states', 'actions', 'rewards', 'dones', 'steps']):
                q_loss = self.q_head.compute_td_loss(
                    halt_history['states'],
                    halt_history['actions'],
                    halt_history['rewards'],
                    halt_history['dones'],
                    halt_history['steps'],
                )
                losses['q_loss'] = q_loss * self.config.q_loss_weight

                # Update target network
                self.q_head._update_target(tau=0.01)

        # Total loss
        losses['total'] = sum(losses.values())

        return losses


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'HaltingConfig',
    'ACTHaltingHead',
    'QLearningHaltingHead',
    'DualHaltingModule',
]
