"""
Bloom Level Definitions

Maps Bloom's Taxonomy to internal model tasks with precise specifications.

The Cognitive DuPont Decomposition:
    ROE = Margin x Turnover x Leverage  (find financial drivers)
    Reasoning = Remember x Analyze x Evaluate x Create  (find cognitive drivers)

Each level has:
    - Cognitive goal (what the model should achieve)
    - Internal task (what heads/losses implement it)
    - Step range (when in TRM recursion it applies)
    - Diagnostic signal (how to measure success)

This module is domain-agnostic. Domain-specific configurations (e.g., Sudoku)
are created by instantiating BloomLevelSpec with appropriate parameters.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Any


class BloomLevel(Enum):
    """
    Bloom's Taxonomy levels mapped to reasoning tasks.

    Original Bloom (1956): Knowledge -> Comprehension -> Application ->
                          Analysis -> Synthesis -> Evaluation

    Revised Bloom (2001): Remember -> Understand -> Apply ->
                          Analyze -> Evaluate -> Create

    Our Mapping (for constraint reasoning):
        REMEMBER    - Encode rules and state correctly
        UNDERSTAND  - Parse constraint structure (merged with REMEMBER)
        ANALYZE     - Find break-in points and critical constraints
        EVALUATE    - Score candidate moves
        CREATE      - Produce solution path
    """
    REMEMBER = 1      # Encode rules and current state
    ANALYZE = 2       # Find break-in areas, key constraints
    EVALUATE = 3      # Score candidate moves
    CREATE = 4        # Produce solution path / final output
    META = 5          # Strategy selection, domain transfer, trace reconstruction


@dataclass
class BloomLevelSpec:
    """
    Complete specification for a Bloom level.

    This is the "schema" that defines what each level does,
    how it's implemented, and how it's measured.

    Domain-agnostic: instantiate with domain-specific values.
    """
    level: BloomLevel
    name: str
    description: str

    # Cognitive task
    cognitive_goal: str
    input_requirements: List[str]
    output_targets: List[str]

    # Model implementation
    head_type: str                    # Name of the head class
    loss_type: str                    # Name of the loss class
    attached_to: str                  # "reasoning_latent" or "solution_state"

    # TRM step range (which steps this level is active)
    step_range: Tuple[float, float]   # (start_fraction, end_fraction) of total steps
    primary_steps: List[int]          # Which steps have strongest weight

    # Diagnostic
    success_metric: str               # How to measure this level
    failure_symptom: str              # What happens when this level fails

    # Training
    default_weight: float             # Base loss weight
    curriculum_phase: int             # Which training phase emphasizes this


# =============================================================================
# Default Level Specifications (Domain-Agnostic Templates)
# =============================================================================

def create_remember_spec(
    input_requirements: Optional[List[str]] = None,
    output_targets: Optional[List[str]] = None,
    success_metric: str = "encoding_accuracy",
    failure_symptom: str = "Model doesn't recognize constraint types or misparses rules",
) -> BloomLevelSpec:
    """Create REMEMBER level spec with customizable parameters."""
    return BloomLevelSpec(
        level=BloomLevel.REMEMBER,
        name="Remember/Understand",
        description="Encode problem rules and current state correctly",

        cognitive_goal="Correctly represent what constraints exist and what the current state is",
        input_requirements=input_requirements or ["problem_string", "rules_text"],
        output_targets=output_targets or ["constraint_types", "constraint_parameters", "initial_state"],

        head_type="RememberHead",
        loss_type="RememberLoss",
        attached_to="reasoning_latent",

        step_range=(0.0, 0.4),           # First 40% of steps
        primary_steps=[0, 1],             # Steps 0 and 1

        success_metric=success_metric,
        failure_symptom=failure_symptom,

        default_weight=1.0,
        curriculum_phase=1,
    )


def create_analyze_spec(
    input_requirements: Optional[List[str]] = None,
    output_targets: Optional[List[str]] = None,
    success_metric: str = "breakin_detection_accuracy",
    failure_symptom: str = "Model starts reasoning in wrong place, misses key constraints",
) -> BloomLevelSpec:
    """Create ANALYZE level spec with customizable parameters."""
    return BloomLevelSpec(
        level=BloomLevel.ANALYZE,
        name="Analyze",
        description="Find break-in areas and key constraints",

        cognitive_goal="Identify where to start reasoning - most constrained positions",
        input_requirements=input_requirements or ["encoded_state", "constraint_graph"],
        output_targets=output_targets or ["breakin_positions", "critical_regions", "constraint_priorities"],

        head_type="AnalyzeHead",
        loss_type="AnalyzeLoss",
        attached_to="reasoning_latent",

        step_range=(0.1, 0.6),           # Steps 1-3 of 5
        primary_steps=[1, 2],

        success_metric=success_metric,
        failure_symptom=failure_symptom,

        default_weight=1.0,
        curriculum_phase=1,
    )


def create_evaluate_spec(
    input_requirements: Optional[List[str]] = None,
    output_targets: Optional[List[str]] = None,
    success_metric: str = "move_ranking_accuracy",
    failure_symptom: str = "Model scores wrong moves highly, poor signal filtering",
) -> BloomLevelSpec:
    """Create EVALUATE level spec with customizable parameters."""
    return BloomLevelSpec(
        level=BloomLevel.EVALUATE,
        name="Evaluate",
        description="Score candidate moves with signal filtering",

        cognitive_goal="Determine which candidate moves are valid, reliable, or risky",
        input_requirements=input_requirements or ["current_state", "candidate_moves", "constraint_state"],
        output_targets=output_targets or ["move_scores", "signal_classification", "confidence"],

        head_type="EvaluateHead",
        loss_type="EvaluateLoss",
        attached_to="solution_state",

        step_range=(0.3, 0.9),           # Steps 2-4 of 5
        primary_steps=[2, 3],

        success_metric=success_metric,
        failure_symptom=failure_symptom,

        default_weight=1.5,              # Higher weight - this is key
        curriculum_phase=2,
    )


def create_create_spec(
    input_requirements: Optional[List[str]] = None,
    output_targets: Optional[List[str]] = None,
    success_metric: str = "solve_rate",
    failure_symptom: str = "Model produces inconsistent outputs, doesn't know when to stop",
) -> BloomLevelSpec:
    """Create CREATE level spec with customizable parameters."""
    return BloomLevelSpec(
        level=BloomLevel.CREATE,
        name="Create",
        description="Produce consistent solution path and final output",

        cognitive_goal="Generate a complete, valid solution through coordinated moves",
        input_requirements=input_requirements or ["refined_state", "move_history"],
        output_targets=output_targets or ["final_output", "solution_path", "halting_decision"],

        head_type="CreateHead",
        loss_type="CreateLoss",
        attached_to="solution_state",

        step_range=(0.5, 1.0),           # Last half of steps
        primary_steps=[3, 4],

        success_metric=success_metric,
        failure_symptom=failure_symptom,

        default_weight=2.0,              # Highest weight - ultimate goal
        curriculum_phase=3,
    )


def create_meta_spec(
    input_requirements: Optional[List[str]] = None,
    output_targets: Optional[List[str]] = None,
    success_metric: str = "strategy_accuracy",
    failure_symptom: str = "Model doesn't adapt strategy, no transfer learning",
    num_strategies: int = 20,  # Number of reasoning strategies
) -> BloomLevelSpec:
    """Create META level spec with customizable parameters."""
    return BloomLevelSpec(
        level=BloomLevel.META,
        name="Meta/Transfer",
        description="Strategy selection, domain invariance, reasoning trace reconstruction",

        cognitive_goal="Learn high-level strategies and transfer across problem variants",
        input_requirements=input_requirements or ["reasoning_history", "problem_features", "performance_feedback"],
        output_targets=output_targets or ["strategy_classification", "domain_invariant_features", "reasoning_trace"],

        head_type="MetaHead",
        loss_type="MetaLoss",
        attached_to="reasoning_latent+solution_state",  # Uses both states

        step_range=(0.6, 1.0),           # Last 40% of steps (runs late)
        primary_steps=[3, 4],             # Steps 3-4 (overlaps with CREATE)

        success_metric=success_metric,
        failure_symptom=failure_symptom,

        default_weight=0.5,               # Lower weight during initial training
        curriculum_phase=3,               # Emphasized in final training phase
    )


def create_default_hierarchy() -> Dict[BloomLevel, BloomLevelSpec]:
    """Create default Bloom hierarchy with generic specs."""
    return {
        BloomLevel.REMEMBER: create_remember_spec(),
        BloomLevel.ANALYZE: create_analyze_spec(),
        BloomLevel.EVALUATE: create_evaluate_spec(),
        BloomLevel.CREATE: create_create_spec(),
        BloomLevel.META: create_meta_spec(),
    }


# Default hierarchy (can be overridden per domain)
BLOOM_HIERARCHY: Dict[BloomLevel, BloomLevelSpec] = create_default_hierarchy()

BLOOM_ORDER = [BloomLevel.REMEMBER, BloomLevel.ANALYZE, BloomLevel.EVALUATE, BloomLevel.CREATE, BloomLevel.META]


# =============================================================================
# Utilities
# =============================================================================

def level_to_step_range(level: BloomLevel, total_steps: int, hierarchy: Optional[Dict[BloomLevel, BloomLevelSpec]] = None) -> Tuple[int, int]:
    """
    Convert level's fractional step range to actual step indices.

    Args:
        level: Bloom level
        total_steps: Total number of TRM steps
        hierarchy: Optional custom hierarchy (uses default if None)

    Returns:
        (start_step, end_step) inclusive
    """
    hierarchy = hierarchy or BLOOM_HIERARCHY
    spec = hierarchy[level]
    start = int(spec.step_range[0] * total_steps)
    end = int(spec.step_range[1] * total_steps)
    return (start, min(end, total_steps - 1))


def get_level_description(level: BloomLevel, hierarchy: Optional[Dict[BloomLevel, BloomLevelSpec]] = None) -> str:
    """Get human-readable description of a level."""
    hierarchy = hierarchy or BLOOM_HIERARCHY
    spec = hierarchy[level]
    return f"{spec.name}: {spec.description}"


def get_active_levels_at_step(step: int, total_steps: int, hierarchy: Optional[Dict[BloomLevel, BloomLevelSpec]] = None) -> List[BloomLevel]:
    """
    Get which Bloom levels are active at a given TRM step.

    Multiple levels can be active simultaneously (they overlap).
    """
    hierarchy = hierarchy or BLOOM_HIERARCHY
    step_fraction = step / total_steps if total_steps > 0 else 0
    active = []

    for level, spec in hierarchy.items():
        if spec.step_range[0] <= step_fraction <= spec.step_range[1]:
            active.append(level)

    return active


def get_primary_level_at_step(step: int, total_steps: int, hierarchy: Optional[Dict[BloomLevel, BloomLevelSpec]] = None) -> BloomLevel:
    """
    Get the primary (most emphasized) Bloom level at a given step.

    This is the level where this step appears in primary_steps.
    """
    hierarchy = hierarchy or BLOOM_HIERARCHY
    for level in reversed(BLOOM_ORDER):  # Later levels take precedence
        spec = hierarchy[level]
        # Normalize step to 0-based for comparison
        normalized_steps = [int(s * total_steps / 5) for s in spec.primary_steps]
        if step in normalized_steps:
            return level

    # Default to earliest active level
    active = get_active_levels_at_step(step, total_steps, hierarchy)
    return active[0] if active else BloomLevel.REMEMBER


@dataclass
class BloomStepConfig:
    """Configuration for a single TRM step's Bloom-level involvement."""
    step: int
    active_levels: List[BloomLevel]
    primary_level: BloomLevel
    level_weights: Dict[BloomLevel, float]


def compute_step_configs(total_steps: int, hierarchy: Optional[Dict[BloomLevel, BloomLevelSpec]] = None) -> List[BloomStepConfig]:
    """
    Compute Bloom configuration for each TRM step.

    This determines which heads are active and weighted at each step.
    """
    hierarchy = hierarchy or BLOOM_HIERARCHY
    configs = []

    for step in range(total_steps):
        active = get_active_levels_at_step(step, total_steps, hierarchy)
        primary = get_primary_level_at_step(step, total_steps, hierarchy)

        # Compute weights: primary level gets 1.0, others get 0.5
        weights = {}
        for level in active:
            weights[level] = 1.0 if level == primary else 0.5

        configs.append(BloomStepConfig(
            step=step,
            active_levels=active,
            primary_level=primary,
            level_weights=weights
        ))

    return configs


# =============================================================================
# Cognitive DuPont Decomposition
# =============================================================================

@dataclass
class CognitiveDuPont:
    """
    DuPont-style decomposition of reasoning performance.

    Just as financial DuPont shows:
        ROE = (Net Income/Sales) x (Sales/Assets) x (Assets/Equity)
             = Margin x Turnover x Leverage

    Cognitive DuPont shows:
        Solve_Rate = P(Remember) x P(Analyze|Remember) x P(Evaluate|Analyze) x P(Create|Evaluate) x P(Meta|Create)
                   = Encode_Acc x BreakIn_Acc x Move_Acc x Synthesis_Acc x Strategy_Acc

    This lets you find the "driver" of failure - which cognitive level is the bottleneck.
    """
    # Per-level success rates
    remember_accuracy: float        # P(correct encoding)
    analyze_accuracy: float         # P(correct breakin | correct encoding)
    evaluate_accuracy: float        # P(correct move | correct analysis)
    create_accuracy: float          # P(correct solution | correct moves)
    meta_accuracy: float = 1.0      # P(correct strategy | correct solution) - optional

    # Computed
    @property
    def compound_success(self) -> float:
        """Overall success rate (product of conditional probabilities)."""
        return (
            self.remember_accuracy *
            self.analyze_accuracy *
            self.evaluate_accuracy *
            self.create_accuracy *
            self.meta_accuracy
        )

    @property
    def bottleneck_level(self) -> BloomLevel:
        """Which level is the weakest link (lowest accuracy)?"""
        scores = {
            BloomLevel.REMEMBER: self.remember_accuracy,
            BloomLevel.ANALYZE: self.analyze_accuracy,
            BloomLevel.EVALUATE: self.evaluate_accuracy,
            BloomLevel.CREATE: self.create_accuracy,
            BloomLevel.META: self.meta_accuracy,
        }
        return min(scores.keys(), key=lambda k: scores[k])

    @property
    def bottleneck_severity(self) -> float:
        """How much the bottleneck drags down overall performance."""
        scores = [
            self.remember_accuracy,
            self.analyze_accuracy,
            self.evaluate_accuracy,
            self.create_accuracy,
            self.meta_accuracy,
        ]
        min_score = min(scores)
        avg_others = (sum(scores) - min_score) / (len(scores) - 1)

        # Severity = how much worse than average
        return avg_others - min_score

    def to_dict(self) -> Dict[str, Any]:
        return {
            'remember': self.remember_accuracy,
            'analyze': self.analyze_accuracy,
            'evaluate': self.evaluate_accuracy,
            'create': self.create_accuracy,
            'meta': self.meta_accuracy,
            'compound': self.compound_success,
            'bottleneck': self.bottleneck_level.name,
            'severity': self.bottleneck_severity,
        }

    def __repr__(self) -> str:
        return (
            f"CognitiveDuPont(\n"
            f"  Remember:  {self.remember_accuracy:.1%}\n"
            f"  Analyze:   {self.analyze_accuracy:.1%}\n"
            f"  Evaluate:  {self.evaluate_accuracy:.1%}\n"
            f"  Create:    {self.create_accuracy:.1%}\n"
            f"  Meta:      {self.meta_accuracy:.1%}\n"
            f"  -------------------\n"
            f"  Compound:  {self.compound_success:.1%}\n"
            f"  Bottleneck: {self.bottleneck_level.name} (-{self.bottleneck_severity:.1%})\n"
            f")"
        )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Core types
    'BloomLevel',
    'BloomLevelSpec',
    'BloomStepConfig',

    # Spec factories
    'create_remember_spec',
    'create_analyze_spec',
    'create_evaluate_spec',
    'create_create_spec',
    'create_meta_spec',
    'create_default_hierarchy',

    # Default hierarchy
    'BLOOM_HIERARCHY',
    'BLOOM_ORDER',

    # Utilities
    'level_to_step_range',
    'get_level_description',
    'get_active_levels_at_step',
    'get_primary_level_at_step',
    'compute_step_configs',

    # DuPont
    'CognitiveDuPont',
]
