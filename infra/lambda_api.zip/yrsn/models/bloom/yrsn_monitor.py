"""
YRSN Quality Monitor

Provides real-time quality monitoring during reasoning:
1. R/S/N (Relevant/Superfluous/Noise) signal classification
2. Collapse detection from hidden state dynamics
3. Quality metrics for diagnostics

The monitor integrates with the TRM loop to:
- Classify each reasoning output
- Detect when the model is "collapsing" (producing low-quality outputs)
- Provide early warning signals for training instability

This module is domain-agnostic. Specific signal interpretations
are configured via parameters.
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class YRSNMonitorConfig:
    """Configuration for YRSN quality monitor."""
    hidden_size: int = 256

    # Signal classification
    num_signal_classes: int = 3   # Default: R/S/N
    signal_names: List[str] = field(default_factory=lambda: ["Relevant", "Superfluous", "Noise"])

    # Collapse detection
    collapse_window: int = 5      # Window size for detecting collapse
    collapse_threshold: float = 0.8  # Entropy threshold (high = uncertain = collapsing)
    variance_threshold: float = 0.01  # State variance threshold

    # Quality metrics
    track_history: bool = True    # Whether to keep history for analysis
    max_history_length: int = 100  # Max steps to keep in history


class YRSNProjectionHead(nn.Module):
    """
    Projects hidden states to YRSN signal space.

    Each position's hidden state is mapped to a signal classification.
    Default: R (Relevant), S (Superfluous), N (Noise)

    The projection is position-aware, allowing different positions
    to have different signal distributions.
    """

    def __init__(self, config: YRSNMonitorConfig):
        super().__init__()
        self.config = config

        # Per-position signal classifier
        self.classifier = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(config.hidden_size // 2, config.num_signal_classes)
        )

        # Global aggregation for overall quality
        self.global_head = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, config.num_signal_classes)
        )

    def forward(
        self,
        state: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Classify signals at each position and globally.

        Args:
            state: Hidden state [batch, num_positions, hidden] or [batch, hidden]

        Returns:
            Dict with:
                - position_logits: [batch, num_positions, num_classes] (if 3D input)
                - global_logits: [batch, num_classes]
                - position_probs: softmax probabilities
                - global_probs: softmax probabilities
        """
        outputs = {}

        if state.dim() == 3:
            # Per-position classification
            position_logits = self.classifier(state)
            outputs['position_logits'] = position_logits
            outputs['position_probs'] = F.softmax(position_logits, dim=-1)

            # Global from mean
            global_state = state.mean(dim=1)
        else:
            global_state = state

        # Global classification
        global_logits = self.global_head(global_state)
        outputs['global_logits'] = global_logits
        outputs['global_probs'] = F.softmax(global_logits, dim=-1)

        return outputs


class CollapseDetector(nn.Module):
    """
    Detects model collapse during reasoning.

    Collapse indicators:
    1. High entropy in predictions (model is confused)
    2. Low variance in hidden states (model stuck)
    3. Repetitive patterns (oscillation)
    4. Sudden state jumps (instability)

    The detector maintains a rolling window of states
    to detect collapse patterns.
    """

    def __init__(self, config: YRSNMonitorConfig):
        super().__init__()
        self.config = config
        self.window_size = config.collapse_window
        self.entropy_threshold = config.collapse_threshold
        self.variance_threshold = config.variance_threshold

        # Collapse classification head
        self.collapse_head = nn.Sequential(
            nn.Linear(config.hidden_size * 2, config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(config.hidden_size // 2, 4)  # 4 collapse types
        )

        # State buffer (not a parameter, managed externally)
        self._state_buffer = None

    def reset_buffer(self, batch_size: int, device: torch.device):
        """Reset state buffer for new batch."""
        self._state_buffer = []

    def update_buffer(self, state: torch.Tensor):
        """Add state to buffer."""
        if self._state_buffer is not None:
            if state.dim() == 3:
                state = state.mean(dim=1)  # [batch, hidden]
            self._state_buffer.append(state.detach())
            # Trim to window size
            if len(self._state_buffer) > self.window_size:
                self._state_buffer.pop(0)

    def forward(
        self,
        current_state: torch.Tensor,
        use_buffer: bool = True
    ) -> Dict[str, torch.Tensor]:
        """
        Detect collapse indicators.

        Args:
            current_state: Current hidden state [batch, hidden] or [batch, seq, hidden]
            use_buffer: Whether to use state history buffer

        Returns:
            Dict with:
                - collapse_prob: [batch] overall collapse probability
                - collapse_types: [batch, 4] probabilities for each collapse type
                - entropy: [batch] prediction entropy
                - variance: [batch] state variance
                - stability: [batch] state stability score
        """
        if current_state.dim() == 3:
            current_flat = current_state.mean(dim=1)
        else:
            current_flat = current_state

        batch_size = current_flat.shape[0]
        device = current_flat.device
        outputs = {}

        # 1. Entropy-based collapse (from state variance)
        if current_state.dim() == 3:
            # Variance across positions
            position_variance = current_state.var(dim=1).mean(dim=-1)  # [batch]
        else:
            position_variance = current_flat.var(dim=-1)
        outputs['variance'] = position_variance

        # 2. Low variance collapse
        low_variance_collapse = (position_variance < self.variance_threshold).float()

        # 3. Buffer-based analysis
        if use_buffer and self._state_buffer and len(self._state_buffer) >= 2:
            # Stack history
            history = torch.stack(self._state_buffer, dim=1)  # [batch, T, hidden]

            # Variance across time (should be non-zero if making progress)
            temporal_variance = history.var(dim=1).mean(dim=-1)  # [batch]
            outputs['temporal_variance'] = temporal_variance

            # Stability: how much state changes between steps
            diffs = (history[:, 1:] - history[:, :-1]).norm(dim=-1)  # [batch, T-1]
            stability = 1.0 - diffs.mean(dim=-1) / (current_flat.norm(dim=-1) + 1e-8)
            outputs['stability'] = stability.clamp(0, 1)

            # Oscillation detection: correlation between diffs
            if history.shape[1] >= 3:
                # Simple oscillation: check if state oscillates back
                step_back_sim = F.cosine_similarity(
                    history[:, -1] - history[:, -2],
                    history[:, -2] - history[:, -3] if history.shape[1] >= 3 else torch.zeros_like(history[:, -1]),
                    dim=-1
                )
                oscillation_prob = (step_back_sim < -0.5).float()
                outputs['oscillation'] = oscillation_prob
            else:
                outputs['oscillation'] = torch.zeros(batch_size, device=device)

            # Combine features for collapse prediction
            if history.shape[1] >= 2:
                combined = torch.cat([current_flat, history[:, -2]], dim=-1)
            else:
                combined = torch.cat([current_flat, current_flat], dim=-1)

        else:
            outputs['temporal_variance'] = torch.ones(batch_size, device=device)
            outputs['stability'] = torch.ones(batch_size, device=device)
            outputs['oscillation'] = torch.zeros(batch_size, device=device)
            combined = torch.cat([current_flat, current_flat], dim=-1)

        # Collapse type classification
        collapse_types = self.collapse_head(combined)
        outputs['collapse_types'] = F.softmax(collapse_types, dim=-1)

        # Types: [entropy_collapse, stuck_collapse, oscillation, instability]
        type_names = ['high_entropy', 'stuck', 'oscillating', 'unstable']

        # Overall collapse probability
        collapse_indicators = torch.stack([
            low_variance_collapse,
            (outputs.get('temporal_variance', torch.ones(batch_size, device=device)) < self.variance_threshold).float(),
            outputs['oscillation'],
            (outputs['stability'] < 0.5).float() if 'stability' in outputs else torch.zeros(batch_size, device=device)
        ], dim=-1)

        outputs['collapse_prob'] = collapse_indicators.mean(dim=-1)
        outputs['is_collapsing'] = outputs['collapse_prob'] > 0.5

        return outputs


class YRSNMonitor(nn.Module):
    """
    Combined YRSN quality monitor.

    Integrates signal classification and collapse detection
    for comprehensive quality monitoring during reasoning.
    """

    def __init__(self, config: YRSNMonitorConfig):
        super().__init__()
        self.config = config

        self.signal_classifier = YRSNProjectionHead(config)
        self.collapse_detector = CollapseDetector(config)

        # Quality aggregation
        self.quality_head = nn.Sequential(
            nn.Linear(config.num_signal_classes + 4, 32),
            nn.GELU(),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

        # History tracking
        self.history: Dict[str, List[torch.Tensor]] = {}
        self._tracking = config.track_history

    def reset(self, batch_size: int, device: torch.device):
        """Reset monitor for new batch."""
        self.collapse_detector.reset_buffer(batch_size, device)
        self.history = {
            'signal_probs': [],
            'collapse_probs': [],
            'quality_scores': [],
        }

    def forward(
        self,
        state: torch.Tensor,
        step: int = 0,
        track: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """
        Monitor quality of current reasoning state.

        Args:
            state: Hidden state [batch, num_positions, hidden] or [batch, hidden]
            step: Current reasoning step
            track: Whether to track history

        Returns:
            Dict with:
                - signal_outputs: Signal classification results
                - collapse_outputs: Collapse detection results
                - quality_score: [batch] overall quality (0-1)
                - should_halt: [batch] recommendation to halt early
        """
        outputs = {'step': step}

        # Signal classification
        signal_outputs = self.signal_classifier(state)
        outputs['signal'] = signal_outputs

        # Update buffer and detect collapse
        if track:
            self.collapse_detector.update_buffer(state)
        collapse_outputs = self.collapse_detector(state, use_buffer=track)
        outputs['collapse'] = collapse_outputs

        # Compute overall quality
        # Higher R proportion = better, lower collapse = better
        signal_features = signal_outputs['global_probs']  # [batch, num_classes]
        collapse_features = collapse_outputs['collapse_types']  # [batch, 4]
        combined = torch.cat([signal_features, collapse_features], dim=-1)
        quality_score = self.quality_head(combined).squeeze(-1)
        outputs['quality_score'] = quality_score

        # Should halt if quality too low or collapsing
        outputs['should_halt'] = (quality_score < 0.3) | collapse_outputs['is_collapsing']

        # Track history
        if self._tracking and track:
            self.history['signal_probs'].append(signal_outputs['global_probs'].detach())
            self.history['collapse_probs'].append(collapse_outputs['collapse_prob'].detach())
            self.history['quality_scores'].append(quality_score.detach())

        return outputs

    def get_summary(self) -> Dict[str, torch.Tensor]:
        """
        Get summary statistics from tracked history.

        Returns:
            Dict with aggregated metrics over the reasoning trajectory
        """
        if not self.history or not self.history.get('signal_probs'):
            return {}

        # Stack history
        signal_probs = torch.stack(self.history['signal_probs'], dim=1)  # [batch, T, classes]
        collapse_probs = torch.stack(self.history['collapse_probs'], dim=1)  # [batch, T]
        quality_scores = torch.stack(self.history['quality_scores'], dim=1)  # [batch, T]

        return {
            # Average signal distribution
            'avg_signal_probs': signal_probs.mean(dim=1),
            # R-signal (class 0) trajectory
            'r_signal_trajectory': signal_probs[:, :, 0],
            # Collapse progression
            'collapse_trajectory': collapse_probs,
            'max_collapse_prob': collapse_probs.max(dim=1).values,
            # Quality progression
            'quality_trajectory': quality_scores,
            'avg_quality': quality_scores.mean(dim=1),
            'min_quality': quality_scores.min(dim=1).values,
            # Summary flags
            'ever_collapsed': (collapse_probs > 0.5).any(dim=1),
            'quality_stable': quality_scores.std(dim=1) < 0.1,
        }

    def compute_loss(
        self,
        outputs: Dict[str, torch.Tensor],
        signal_targets: Optional[torch.Tensor] = None,
        quality_targets: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute monitoring losses.

        Args:
            outputs: Forward pass outputs
            signal_targets: [batch, num_positions] ground truth signal labels
            quality_targets: [batch] ground truth quality scores

        Returns:
            Dict with loss components
        """
        losses = {}

        # Signal classification loss
        if signal_targets is not None and 'signal' in outputs:
            if 'position_logits' in outputs['signal'] and signal_targets.dim() == 2:
                # Per-position loss
                signal_loss = F.cross_entropy(
                    outputs['signal']['position_logits'].view(-1, self.config.num_signal_classes),
                    signal_targets.view(-1)
                )
            else:
                # Global loss
                signal_loss = F.cross_entropy(
                    outputs['signal']['global_logits'],
                    signal_targets
                )
            losses['signal_loss'] = signal_loss

        # Quality supervision (if available)
        if quality_targets is not None:
            quality_loss = F.mse_loss(outputs['quality_score'], quality_targets)
            losses['quality_loss'] = quality_loss

        # Collapse regularization (encourage low collapse probability)
        collapse_reg = outputs['collapse']['collapse_prob'].mean()
        losses['collapse_reg'] = collapse_reg * 0.1

        losses['total'] = sum(losses.values())

        return losses


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'YRSNMonitorConfig',
    'YRSNProjectionHead',
    'CollapseDetector',
    'YRSNMonitor',
]
