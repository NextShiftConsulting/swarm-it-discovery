"""
Bloom-Structured Thinking Recurrence Machine (TRM)

The main model that integrates:
    1. TRM iterative refinement architecture
    2. Bloom-level heads at different recursion depths
    3. Curriculum-aware loss computation
    4. Cognitive DuPont diagnostics

Architecture:
    Input -> Encoder -> [TRM Steps with Bloom Heads] -> Output

    Step 0-1: REMEMBER heads active (encode rules)
    Step 1-2: ANALYZE heads active (find break-ins)
    Step 2-3: EVALUATE heads active (score moves)
    Step 3-4: CREATE heads active (produce solution)

    Each step outputs from multiple Bloom levels (with overlap).
    Final loss is weighted sum based on curriculum phase.

This module is domain-agnostic. All domain-specific values
are passed via configuration.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Union

from .levels import (
    BloomLevel,
    BLOOM_HIERARCHY,
    get_active_levels_at_step,
    get_primary_level_at_step,
    compute_step_configs,
    BloomStepConfig,
)
from .heads import BloomHeadBank, BloomHeadsConfig
from .losses import BloomLossComputer, BloomLossOutput
from .curriculum import BloomCurriculum, LossWeights


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class BloomTRMConfig:
    """Configuration for Bloom-structured TRM - domain-agnostic."""
    # Model dimensions
    hidden_size: int = 256
    intermediate_size: int = 512
    num_attention_heads: int = 8
    dropout: float = 0.1

    # TRM parameters
    num_steps: int = 5
    share_weights_across_steps: bool = True

    # Input dimensions (set per domain)
    vocab_size: int = 10000         # For text encoding
    num_positions: int = 81         # Number of positions (e.g., 81 for 9x9)
    num_values: int = 9             # Possible values per position
    num_regions: int = 27           # Constraint regions
    num_rule_types: int = 10        # Constraint types

    # Bloom head configuration
    max_constraints: int = 20       # Max constraints per problem
    constraint_dim: int = 32        # Constraint embedding dimension
    max_path_length: int = 81       # Maximum solution path length
    num_signal_classes: int = 3     # Signal classification classes (R/S/N)

    # Output configuration
    output_intermediate_states: bool = True

    def __post_init__(self):
        assert self.hidden_size % self.num_attention_heads == 0

    def to_heads_config(self) -> BloomHeadsConfig:
        """Convert to BloomHeadsConfig."""
        return BloomHeadsConfig(
            hidden_size=self.hidden_size,
            num_positions=self.num_positions,
            num_values=self.num_values,
            num_regions=self.num_regions,
            num_rule_types=self.num_rule_types,
            max_constraints=self.max_constraints,
            num_signal_classes=self.num_signal_classes,
            max_path_length=self.max_path_length,
        )


# =============================================================================
# Output Container
# =============================================================================

@dataclass
class BloomForwardOutput:
    """Output from BloomTRM forward pass."""
    # Final outputs
    final_output_logits: torch.Tensor          # [B, num_positions, num_values]
    final_state: torch.Tensor                  # [B, hidden_size]

    # Per-step outputs
    step_states: List[torch.Tensor]            # List of [B, hidden_size]
    bloom_outputs: Dict[int, Dict[str, Dict[str, torch.Tensor]]]  # step -> level -> head_outputs

    # Halting information
    halt_probs: Optional[torch.Tensor] = None  # [B, num_steps]

    # For loss computation
    def get_bloom_predictions(self) -> Dict[BloomLevel, Dict[str, torch.Tensor]]:
        """
        Aggregate predictions across steps for loss computation.

        Returns predictions keyed by Bloom level (aggregated from steps
        where that level was primary).
        """
        predictions = {level: {} for level in BloomLevel}

        for step, step_outputs in self.bloom_outputs.items():
            for level_name, level_outputs in step_outputs.items():
                level = BloomLevel[level_name.upper()]
                for key, value in level_outputs.items():
                    if key not in predictions[level]:
                        predictions[level][key] = value
                    # Could also average/aggregate across steps here

        return predictions


# =============================================================================
# TRM Step Module
# =============================================================================

class TRMStep(nn.Module):
    """
    Single TRM recurrence step.

    Implements:
        z_{t+1} = f(z_t, x)

    Where f is a transformer-style update with self-attention.
    """

    def __init__(self, config: BloomTRMConfig):
        super().__init__()
        self.config = config

        # Self-attention over latent state
        self.self_attn = nn.MultiheadAttention(
            embed_dim=config.hidden_size,
            num_heads=config.num_attention_heads,
            dropout=config.dropout,
            batch_first=True,
        )

        # Cross-attention to input (optional)
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=config.hidden_size,
            num_heads=config.num_attention_heads,
            dropout=config.dropout,
            batch_first=True,
        )

        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(config.hidden_size, config.intermediate_size),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.intermediate_size, config.hidden_size),
            nn.Dropout(config.dropout),
        )

        # Layer norms
        self.norm1 = nn.LayerNorm(config.hidden_size)
        self.norm2 = nn.LayerNorm(config.hidden_size)
        self.norm3 = nn.LayerNorm(config.hidden_size)

    def forward(
        self,
        z: torch.Tensor,           # [B, S, H] latent state
        x: torch.Tensor,           # [B, L, H] encoded input
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Single recurrence step.

        Args:
            z: Current latent state [B, S, H]
            x: Encoded input [B, L, H]
            mask: Optional attention mask

        Returns:
            Updated latent state [B, S, H]
        """
        # Self-attention
        z_norm = self.norm1(z)
        z_attn, _ = self.self_attn(z_norm, z_norm, z_norm)
        z = z + z_attn

        # Cross-attention to input
        z_norm = self.norm2(z)
        z_cross, _ = self.cross_attn(z_norm, x, x)
        z = z + z_cross

        # FFN
        z_norm = self.norm3(z)
        z = z + self.ffn(z_norm)

        return z


# =============================================================================
# Input Encoder
# =============================================================================

class BloomEncoder(nn.Module):
    """
    Encoder for problem inputs.

    Encodes:
        1. Rule text (constraint descriptions)
        2. Visual elements (optional)
        3. Current state

    Domain-agnostic: dimensions come from config.
    """

    def __init__(self, config: BloomTRMConfig):
        super().__init__()
        self.config = config

        # Text embedding
        self.text_embedding = nn.Embedding(config.vocab_size, config.hidden_size)

        # State encoding (per-position)
        self.value_embedding = nn.Embedding(config.num_values + 1, config.hidden_size)  # +1 for empty
        self.position_embedding = nn.Embedding(config.num_positions, config.hidden_size)

        # Visual element projection (assumes pre-encoded visual features)
        self.visual_proj = nn.Linear(config.hidden_size, config.hidden_size)

        # Combine modalities
        self.modality_fusion = nn.Sequential(
            nn.Linear(config.hidden_size * 3, config.hidden_size * 2),
            nn.GELU(),
            nn.Linear(config.hidden_size * 2, config.hidden_size),
        )

        # Output projection
        self.output_proj = nn.Linear(config.hidden_size, config.hidden_size)
        self.norm = nn.LayerNorm(config.hidden_size)

    def forward(
        self,
        rule_tokens: torch.Tensor,           # [B, L] token ids
        state: torch.Tensor,                 # [B, num_positions] value indices (0=empty)
        visual_features: Optional[torch.Tensor] = None,  # [B, V, H] pre-encoded
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Encode problem input.

        Returns:
            encoded: [B, num_positions, H] per-position encoding
            global_state: [B, H] global problem encoding
        """
        B = state.shape[0]
        device = state.device

        # Encode rule text
        rule_emb = self.text_embedding(rule_tokens)  # [B, L, H]
        rule_global = rule_emb.mean(dim=1)           # [B, H] average pooling

        # Encode state
        positions = torch.arange(self.config.num_positions, device=device).unsqueeze(0).expand(B, -1)
        value_emb = self.value_embedding(state)          # [B, P, H]
        pos_emb = self.position_embedding(positions)      # [B, P, H]
        state_emb = value_emb + pos_emb                   # [B, P, H]

        # Encode visual elements
        if visual_features is not None:
            visual_emb = self.visual_proj(visual_features)  # [B, V, H]
            visual_global = visual_emb.mean(dim=1)           # [B, H]
        else:
            visual_global = torch.zeros(B, self.config.hidden_size, device=device)

        # Fuse modalities for global state
        fused = torch.cat([rule_global, state_emb.mean(dim=1), visual_global], dim=-1)
        global_state = self.modality_fusion(fused)  # [B, H]

        # Per-position encoding (add global context)
        encoded = state_emb + global_state.unsqueeze(1)
        encoded = self.norm(self.output_proj(encoded))

        return encoded, global_state


# =============================================================================
# Main Model
# =============================================================================

class BloomTRM(nn.Module):
    """
    Bloom-Structured Thinking Recurrence Machine.

    The main model that implements:
        1. Multi-step iterative refinement (TRM)
        2. Bloom-level heads attached at appropriate steps
        3. Curriculum-aware training
        4. Cognitive bottleneck diagnostics

    Domain-agnostic: all parameters come from BloomTRMConfig.

    Usage:
        config = BloomTRMConfig(
            num_positions=81,  # Sudoku
            num_values=9,
            num_regions=27,
        )
        model = BloomTRM(config)
        curriculum = BloomCurriculum()

        for epoch in range(60):
            weights = curriculum.get_weights(epoch)

            for batch in dataloader:
                output = model(batch)
                loss = model.compute_loss(output, batch, weights)
                loss.backward()
    """

    def __init__(self, config: Optional[BloomTRMConfig] = None):
        super().__init__()
        self.config = config or BloomTRMConfig()

        # Input encoder
        self.encoder = BloomEncoder(self.config)

        # TRM steps
        if self.config.share_weights_across_steps:
            self.trm_step = TRMStep(self.config)
            self.trm_steps = None
        else:
            self.trm_step = None
            self.trm_steps = nn.ModuleList([
                TRMStep(self.config)
                for _ in range(self.config.num_steps)
            ])

        # Initialize latent state
        self.init_state = nn.Parameter(
            torch.randn(1, self.config.num_positions, self.config.hidden_size) * 0.02
        )

        # Bloom head bank
        heads_config = self.config.to_heads_config()
        self.bloom_heads = BloomHeadBank(
            config=heads_config,
            include_solution_path=False,
        )

        # Halting predictor (ACT-style)
        self.halt_predictor = nn.Sequential(
            nn.Linear(self.config.hidden_size, self.config.hidden_size // 2),
            nn.GELU(),
            nn.Linear(self.config.hidden_size // 2, 1),
            nn.Sigmoid(),
        )

        # Loss computer
        self.loss_computer = BloomLossComputer(
            num_rule_types=self.config.num_rule_types,
            constraint_dim=self.config.constraint_dim,
            num_values=self.config.num_values,
            num_signal_classes=self.config.num_signal_classes,
        )

        # Step configurations
        self.step_configs = compute_step_configs(self.config.num_steps)

    def forward(
        self,
        rule_tokens: torch.Tensor,
        state: torch.Tensor,
        visual_features: Optional[torch.Tensor] = None,
        active_levels: Optional[List[BloomLevel]] = None,
        return_all_steps: bool = True,
    ) -> BloomForwardOutput:
        """
        Forward pass through Bloom TRM.

        Args:
            rule_tokens: [B, L] rule description tokens
            state: [B, num_positions] current state values
            visual_features: [B, V, H] optional visual encodings
            active_levels: Which Bloom levels to compute (None = all)
            return_all_steps: Whether to return intermediate states

        Returns:
            BloomForwardOutput with all predictions
        """
        B = state.shape[0]
        device = state.device

        # Encode input
        encoded, global_state = self.encoder(rule_tokens, state, visual_features)

        # Initialize latent state
        z = self.init_state.expand(B, -1, -1).clone()

        # Storage for outputs
        step_states = []
        bloom_outputs = {}
        halt_probs = []

        # Run TRM steps
        for step in range(self.config.num_steps):
            # Get step module
            if self.trm_steps is not None:
                step_module = self.trm_steps[step]
            else:
                step_module = self.trm_step

            # Update latent state
            z = step_module(z, encoded)

            if return_all_steps:
                step_states.append(z.mean(dim=1))  # [B, H] average over positions

            # Compute halting probability
            halt_prob = self.halt_predictor(z.mean(dim=1))  # [B, 1]
            halt_probs.append(halt_prob)

            # Get active Bloom levels for this step
            step_config = self.step_configs[step]
            step_active_levels = step_config.active_levels

            if active_levels is not None:
                step_active_levels = [l for l in step_active_levels if l in active_levels]

            if step_active_levels:
                # Compute Bloom head outputs
                head_outputs = self.bloom_heads(
                    z=z.mean(dim=1),  # Global state for heads
                    y=z,              # Per-position state for solution
                    active_levels=step_active_levels,
                )
                bloom_outputs[step] = head_outputs

        # Stack halting probabilities
        halt_probs_tensor = torch.cat(halt_probs, dim=-1)  # [B, num_steps]

        # Get final output logits from last CREATE output
        final_output_logits = None
        for step in reversed(range(self.config.num_steps)):
            if step in bloom_outputs and 'create' in bloom_outputs[step]:
                if 'output_logits' in bloom_outputs[step]['create']:
                    final_output_logits = bloom_outputs[step]['create']['output_logits']
                    break

        # Fallback if no CREATE output
        if final_output_logits is None:
            final_output_logits = torch.zeros(
                B, self.config.num_positions, self.config.num_values,
                device=device
            )

        return BloomForwardOutput(
            final_output_logits=final_output_logits,
            final_state=z.mean(dim=1),
            step_states=step_states,
            bloom_outputs=bloom_outputs,
            halt_probs=halt_probs_tensor,
        )

    def compute_loss(
        self,
        output: BloomForwardOutput,
        targets: Dict[str, Any],
        weights: Optional[Union[LossWeights, Dict[BloomLevel, float]]] = None,
    ) -> BloomLossOutput:
        """
        Compute Bloom-structured loss.

        Args:
            output: Forward pass output
            targets: Target dictionary with per-level targets
            weights: Loss weights (from curriculum)

        Returns:
            BloomLossOutput with per-level breakdowns
        """
        if isinstance(weights, LossWeights):
            weights = weights.to_dict()

        predictions = output.get_bloom_predictions()

        # Add halting predictions for CREATE level
        if BloomLevel.CREATE in predictions:
            predictions[BloomLevel.CREATE]['halt_probs'] = output.halt_probs

        # Convert targets to per-level format if needed
        level_targets = self._prepare_targets(targets)

        return self.loss_computer(predictions, level_targets, weights)

    def _prepare_targets(
        self,
        targets: Dict[str, Any],
    ) -> Dict[BloomLevel, Dict[str, torch.Tensor]]:
        """Convert flat targets dict to per-level format."""
        if 'bloom_targets' in targets:
            return targets['bloom_targets']

        level_targets = {}

        # Remember level targets
        remember_targets = {}
        if 'rule_labels' in targets:
            remember_targets['rule_labels'] = targets['rule_labels']
        if 'constraint_vectors' in targets:
            remember_targets['constraint_vectors'] = targets['constraint_vectors']
        if remember_targets:
            level_targets[BloomLevel.REMEMBER] = remember_targets

        # Analyze level targets
        analyze_targets = {}
        if 'breakin_positions' in targets:
            analyze_targets['breakin_positions'] = targets['breakin_positions']
        if 'critical_regions' in targets:
            analyze_targets['critical_regions'] = targets['critical_regions']
        if 'constraint_priorities' in targets:
            analyze_targets['constraint_priorities'] = targets['constraint_priorities']
        if analyze_targets:
            level_targets[BloomLevel.ANALYZE] = analyze_targets

        # Evaluate level targets
        evaluate_targets = {}
        if 'correct_move' in targets:
            evaluate_targets['correct_move'] = targets['correct_move']
        if 'signal_labels' in targets:
            evaluate_targets['signal_labels'] = targets['signal_labels']
        if 'move_correctness' in targets:
            evaluate_targets['move_correctness'] = targets['move_correctness']
        if evaluate_targets:
            level_targets[BloomLevel.EVALUATE] = evaluate_targets

        # Create level targets
        create_targets = {}
        if 'solution' in targets:
            create_targets['solution'] = targets['solution']
        if 'optimal_halt_step' in targets:
            create_targets['optimal_halt_step'] = targets['optimal_halt_step']
        if 'solution_path' in targets:
            create_targets['solution_path'] = targets['solution_path']
        if create_targets:
            level_targets[BloomLevel.CREATE] = create_targets

        return level_targets

    def get_step_level_config(self, step: int) -> BloomStepConfig:
        """Get Bloom level configuration for a specific step."""
        return self.step_configs[step]

    @torch.no_grad()
    def predict(
        self,
        rule_tokens: torch.Tensor,
        state: torch.Tensor,
        visual_features: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Predict solution.

        Args:
            rule_tokens: [B, L] rule tokens
            state: [B, num_positions] current state
            visual_features: Optional visual features

        Returns:
            [B, num_positions] predicted values
        """
        self.eval()
        output = self(rule_tokens, state, visual_features)
        return output.final_output_logits.argmax(dim=-1)


# =============================================================================
# Factory Functions
# =============================================================================

def create_bloom_trm(
    hidden_size: int = 256,
    num_steps: int = 5,
    num_positions: int = 81,
    num_values: int = 9,
    num_regions: int = 27,
    **kwargs,
) -> BloomTRM:
    """Create BloomTRM with specified configuration."""
    config = BloomTRMConfig(
        hidden_size=hidden_size,
        num_steps=num_steps,
        num_positions=num_positions,
        num_values=num_values,
        num_regions=num_regions,
        **kwargs,
    )
    return BloomTRM(config)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config
    'BloomTRMConfig',

    # Output
    'BloomForwardOutput',

    # Main model
    'BloomTRM',

    # Components
    'TRMStep',
    'BloomEncoder',

    # Factories
    'create_bloom_trm',
]
