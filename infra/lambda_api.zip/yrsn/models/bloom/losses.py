"""
Bloom Level-Specific Loss Functions

Each Bloom level has its own loss function that measures success
at that cognitive stage. The total loss is a weighted combination:

    L = l1*L_remember + l2*L_analyze + l3*L_evaluate + l4*L_create

Loss Design Principles:
    1. Each loss measures a DIFFERENT cognitive capability
    2. Losses can be computed independently (modular)
    3. Curriculum controls lambda weights over training
    4. Diagnostics can isolate which level is failing

This module is domain-agnostic. All domain-specific values (num_positions,
num_values, etc.) are passed via configuration.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum

from .levels import BloomLevel, BLOOM_HIERARCHY


# =============================================================================
# Loss Output Containers
# =============================================================================

@dataclass
class LevelLossOutput:
    """Output from a single Bloom level's loss computation."""
    level: BloomLevel
    total_loss: torch.Tensor
    component_losses: Dict[str, torch.Tensor]
    metrics: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'level': self.level.name,
            'total': self.total_loss.item() if self.total_loss.numel() == 1 else self.total_loss.mean().item(),
            'components': {k: v.item() if v.numel() == 1 else v.mean().item()
                          for k, v in self.component_losses.items()},
            'metrics': self.metrics,
        }


@dataclass
class BloomLossOutput:
    """Combined output from all Bloom level losses."""
    level_losses: Dict[BloomLevel, LevelLossOutput]
    weighted_total: torch.Tensor
    weights_used: Dict[BloomLevel, float]

    def to_dict(self) -> Dict[str, Any]:
        return {
            'total': self.weighted_total.item() if self.weighted_total.numel() == 1 else self.weighted_total.mean().item(),
            'weights': {k.name: v for k, v in self.weights_used.items()},
            'levels': {k.name: v.to_dict() for k, v in self.level_losses.items()},
        }


# =============================================================================
# Level 1: Remember Loss
# =============================================================================

class RememberLoss(nn.Module):
    """
    Loss for Remember/Understand level.

    Measures: Can the model correctly encode problem rules and state?

    Components:
        1. Rule Classification Loss - identify constraint types
        2. Constraint Reconstruction Loss - reconstruct constraint parameters
    """

    def __init__(
        self,
        num_rule_types: int = 10,
        constraint_dim: int = 32,
        rule_weight: float = 1.0,
        reconstruction_weight: float = 0.5,
    ):
        super().__init__()
        self.num_rule_types = num_rule_types
        self.constraint_dim = constraint_dim
        self.rule_weight = rule_weight
        self.reconstruction_weight = reconstruction_weight

        # Rule classification uses cross-entropy
        self.rule_ce = nn.CrossEntropyLoss(reduction='none')

        # Constraint reconstruction uses MSE
        self.reconstruction_mse = nn.MSELoss(reduction='none')

    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> LevelLossOutput:
        """
        Compute Remember level loss.

        Args:
            predictions: Dict with 'rule_logits' and 'constraint_reconstruction'
            targets: Dict with 'rule_labels' and 'constraint_vectors'

        Returns:
            LevelLossOutput with component losses
        """
        component_losses = {}
        metrics = {}

        # Rule classification loss
        if 'rule_logits' in predictions and 'rule_labels' in targets:
            rule_logits = predictions['rule_logits']  # [B, num_rules, num_types]
            rule_labels = targets['rule_labels']       # [B, num_rules]

            # Reshape for cross-entropy
            B, R, T = rule_logits.shape
            rule_loss = self.rule_ce(
                rule_logits.view(-1, T),
                rule_labels.view(-1)
            ).view(B, R).mean()

            component_losses['rule_classification'] = rule_loss * self.rule_weight

            # Compute accuracy metric
            with torch.no_grad():
                preds = rule_logits.argmax(dim=-1)
                accuracy = (preds == rule_labels).float().mean().item()
                metrics['rule_accuracy'] = accuracy

        # Constraint reconstruction loss
        if 'constraint_reconstruction' in predictions and 'constraint_vectors' in targets:
            recon = predictions['constraint_reconstruction']  # [B, num_constraints, dim]
            target = targets['constraint_vectors']             # [B, num_constraints, dim]

            recon_loss = self.reconstruction_mse(recon, target).mean()
            component_losses['constraint_reconstruction'] = recon_loss * self.reconstruction_weight

            # Compute reconstruction error metric
            with torch.no_grad():
                mse = F.mse_loss(recon, target).item()
                metrics['reconstruction_mse'] = mse

        # Total loss
        total = sum(component_losses.values()) if component_losses else torch.tensor(0.0)

        return LevelLossOutput(
            level=BloomLevel.REMEMBER,
            total_loss=total,
            component_losses=component_losses,
            metrics=metrics,
        )


# =============================================================================
# Level 2: Analyze Loss
# =============================================================================

class AnalyzeLoss(nn.Module):
    """
    Loss for Analyze level.

    Measures: Can the model find break-in points and critical constraints?

    Components:
        1. Break-in Position Loss - identify where to start reasoning
        2. Critical Region Loss - identify key constraint areas
        3. Constraint Priority Loss - rank constraint importance
    """

    def __init__(
        self,
        breakin_weight: float = 1.0,
        region_weight: float = 0.5,
        priority_weight: float = 0.3,
        margin: float = 0.1,
    ):
        super().__init__()
        self.breakin_weight = breakin_weight
        self.region_weight = region_weight
        self.priority_weight = priority_weight
        self.margin = margin

    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> LevelLossOutput:
        """
        Compute Analyze level loss.

        Args:
            predictions: Dict with 'breakin_scores', 'region_logits', 'priority_scores'
            targets: Dict with 'breakin_positions', 'critical_regions', 'constraint_priorities'
        """
        component_losses = {}
        metrics = {}

        # Break-in position loss (binary cross-entropy or ranking)
        if 'breakin_scores' in predictions and 'breakin_positions' in targets:
            scores = predictions['breakin_scores']      # [B, num_positions]
            labels = targets['breakin_positions']       # [B, num_positions] binary

            # Use BCE with logits
            breakin_loss = F.binary_cross_entropy_with_logits(
                scores, labels.float(), reduction='mean'
            )
            component_losses['breakin'] = breakin_loss * self.breakin_weight

            # Compute precision/recall
            with torch.no_grad():
                preds = (scores > 0).float()
                tp = (preds * labels).sum()
                fp = (preds * (1 - labels)).sum()
                fn = ((1 - preds) * labels).sum()

                precision = tp / (tp + fp + 1e-8)
                recall = tp / (tp + fn + 1e-8)
                metrics['breakin_precision'] = precision.item()
                metrics['breakin_recall'] = recall.item()

        # Critical region loss (multi-label classification)
        if 'region_logits' in predictions and 'critical_regions' in targets:
            logits = predictions['region_logits']   # [B, num_regions]
            labels = targets['critical_regions']     # [B, num_regions] binary

            region_loss = F.binary_cross_entropy_with_logits(
                logits, labels.float(), reduction='mean'
            )
            component_losses['region'] = region_loss * self.region_weight

        # Constraint priority loss (pairwise ranking)
        if 'priority_scores' in predictions and 'constraint_priorities' in targets:
            scores = predictions['priority_scores']      # [B, num_constraints]
            priorities = targets['constraint_priorities']  # [B, num_constraints]

            # Pairwise ranking loss: high-priority constraints should score higher
            priority_loss = self._pairwise_ranking_loss(scores, priorities)
            component_losses['priority'] = priority_loss * self.priority_weight

            # Compute Spearman correlation
            with torch.no_grad():
                corr = self._batch_spearman(scores, priorities)
                metrics['priority_correlation'] = corr.mean().item()

        total = sum(component_losses.values()) if component_losses else torch.tensor(0.0)

        return LevelLossOutput(
            level=BloomLevel.ANALYZE,
            total_loss=total,
            component_losses=component_losses,
            metrics=metrics,
        )

    def _pairwise_ranking_loss(
        self,
        scores: torch.Tensor,
        priorities: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute pairwise ranking loss.

        For each pair (i, j) where priority[i] > priority[j],
        we want score[i] > score[j] + margin.
        """
        B, N = scores.shape

        # Create pairwise differences
        score_diff = scores.unsqueeze(-1) - scores.unsqueeze(-2)  # [B, N, N]
        priority_diff = priorities.unsqueeze(-1) - priorities.unsqueeze(-2)  # [B, N, N]

        # Mask for pairs where first has higher priority
        higher_mask = (priority_diff > 0).float()

        # Hinge loss: max(0, margin - score_diff) for pairs where first should rank higher
        loss = F.relu(self.margin - score_diff) * higher_mask

        # Average over valid pairs
        num_pairs = higher_mask.sum() + 1e-8
        return loss.sum() / num_pairs

    def _batch_spearman(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
    ) -> torch.Tensor:
        """Compute Spearman correlation per batch."""
        # Convert to ranks
        x_ranks = x.argsort(dim=-1).argsort(dim=-1).float()
        y_ranks = y.argsort(dim=-1).argsort(dim=-1).float()

        # Compute Pearson on ranks
        x_centered = x_ranks - x_ranks.mean(dim=-1, keepdim=True)
        y_centered = y_ranks - y_ranks.mean(dim=-1, keepdim=True)

        corr = (x_centered * y_centered).sum(dim=-1) / (
            x_centered.norm(dim=-1) * y_centered.norm(dim=-1) + 1e-8
        )
        return corr


# =============================================================================
# Level 3: Evaluate Loss
# =============================================================================

class EvaluateLoss(nn.Module):
    """
    Loss for Evaluate level.

    Measures: Can the model correctly score candidate moves?

    Components:
        1. Move Classification Loss - pick the correct move
        2. Signal Classification Loss - classify move quality (R/S/N)
        3. Confidence Calibration Loss - well-calibrated confidence
        4. Pairwise Ranking Loss - rank moves correctly
    """

    def __init__(
        self,
        move_weight: float = 1.5,
        signal_weight: float = 1.0,
        confidence_weight: float = 0.3,
        ranking_weight: float = 0.5,
        label_smoothing: float = 0.1,
        num_signal_classes: int = 3,
    ):
        super().__init__()
        self.move_weight = move_weight
        self.signal_weight = signal_weight
        self.confidence_weight = confidence_weight
        self.ranking_weight = ranking_weight
        self.num_signal_classes = num_signal_classes

        self.move_ce = nn.CrossEntropyLoss(
            reduction='mean',
            label_smoothing=label_smoothing
        )
        self.signal_ce = nn.CrossEntropyLoss(reduction='mean')

    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> LevelLossOutput:
        """
        Compute Evaluate level loss.

        Args:
            predictions: Dict with 'move_logits', 'signal_logits', 'confidence', 'move_scores'
            targets: Dict with 'correct_move', 'signal_labels', 'move_correctness'
        """
        component_losses = {}
        metrics = {}

        # Move classification loss (cross-entropy)
        if 'move_logits' in predictions and 'correct_move' in targets:
            logits = predictions['move_logits']  # [B, num_candidates]
            labels = targets['correct_move']      # [B] index of correct move

            move_loss = self.move_ce(logits, labels)
            component_losses['move'] = move_loss * self.move_weight

            # Compute accuracy
            with torch.no_grad():
                preds = logits.argmax(dim=-1)
                accuracy = (preds == labels).float().mean().item()
                metrics['move_accuracy'] = accuracy

        # Signal classification loss (e.g., YRSN)
        if 'signal_logits' in predictions and 'signal_labels' in targets:
            signal_logits = predictions['signal_logits']  # [B, num_positions, num_classes]
            signal_labels = targets['signal_labels']       # [B, num_positions]

            B, P, C = signal_logits.shape
            signal_loss = self.signal_ce(
                signal_logits.view(-1, C),
                signal_labels.view(-1)
            )
            component_losses['signal'] = signal_loss * self.signal_weight

            # Compute per-class accuracy
            with torch.no_grad():
                preds = signal_logits.argmax(dim=-1)
                accuracy = (preds == signal_labels).float().mean().item()
                metrics['signal_accuracy'] = accuracy

        # Confidence calibration loss (ECE-inspired)
        if 'confidence' in predictions and 'move_correctness' in targets:
            confidence = predictions['confidence']      # [B, num_candidates]
            correctness = targets['move_correctness']   # [B, num_candidates] binary

            # Simple calibration loss: confidence should match correctness
            calib_loss = F.mse_loss(confidence, correctness.float())
            component_losses['calibration'] = calib_loss * self.confidence_weight

            with torch.no_grad():
                # Expected calibration error (simplified)
                bins = torch.linspace(0, 1, 11, device=confidence.device)
                ece = 0.0
                for i in range(10):
                    mask = (confidence >= bins[i]) & (confidence < bins[i+1])
                    if mask.sum() > 0:
                        bin_acc = correctness[mask].float().mean()
                        bin_conf = confidence[mask].mean()
                        ece += mask.float().mean() * (bin_acc - bin_conf).abs()
                metrics['ece'] = ece.item()

        # Pairwise ranking loss
        if 'move_scores' in predictions and 'move_correctness' in targets:
            scores = predictions['move_scores']        # [B, num_candidates]
            correctness = targets['move_correctness']   # [B, num_candidates]

            ranking_loss = self._move_ranking_loss(scores, correctness)
            component_losses['ranking'] = ranking_loss * self.ranking_weight

        total = sum(component_losses.values()) if component_losses else torch.tensor(0.0)

        return LevelLossOutput(
            level=BloomLevel.EVALUATE,
            total_loss=total,
            component_losses=component_losses,
            metrics=metrics,
        )

    def _move_ranking_loss(
        self,
        scores: torch.Tensor,
        correctness: torch.Tensor,
    ) -> torch.Tensor:
        """
        Ranking loss: correct moves should score higher than incorrect.
        """
        # Get indices of correct and incorrect moves
        correct_mask = (correctness > 0.5)
        incorrect_mask = ~correct_mask

        B = scores.shape[0]
        total_loss = torch.tensor(0.0, device=scores.device)
        count = 0

        for b in range(B):
            correct_scores = scores[b][correct_mask[b]]
            incorrect_scores = scores[b][incorrect_mask[b]]

            if len(correct_scores) > 0 and len(incorrect_scores) > 0:
                # Hinge loss: correct should be > incorrect + margin
                diff = correct_scores.unsqueeze(-1) - incorrect_scores.unsqueeze(0)
                loss = F.relu(0.1 - diff).mean()
                total_loss = total_loss + loss
                count += 1

        return total_loss / max(count, 1)


# =============================================================================
# Level 4: Create Loss
# =============================================================================

class CreateLoss(nn.Module):
    """
    Loss for Create level.

    Measures: Can the model produce a valid, complete solution?

    Components:
        1. Final Output Loss - reconstruct the solution
        2. Halting Loss - ACT-style early stopping
        3. Solution Path Loss - sequence of moves
        4. Consistency Loss - no constraint violations
    """

    def __init__(
        self,
        num_values: int = 9,
        output_weight: float = 2.0,
        halting_weight: float = 0.5,
        path_weight: float = 0.3,
        consistency_weight: float = 1.0,
        halt_threshold: float = 0.5,
        halt_penalty: float = 0.01,
    ):
        super().__init__()
        self.num_values = num_values
        self.output_weight = output_weight
        self.halting_weight = halting_weight
        self.path_weight = path_weight
        self.consistency_weight = consistency_weight
        self.halt_threshold = halt_threshold
        self.halt_penalty = halt_penalty

        self.output_ce = nn.CrossEntropyLoss(reduction='none')

    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> LevelLossOutput:
        """
        Compute Create level loss.

        Args:
            predictions: Dict with 'output_logits', 'halt_probs', 'path_logits', 'constraint_violations'
            targets: Dict with 'solution', 'optimal_halt_step', 'solution_path'
        """
        component_losses = {}
        metrics = {}

        # Final output reconstruction loss
        if 'output_logits' in predictions and 'solution' in targets:
            logits = predictions['output_logits']  # [B, num_positions, num_values]
            solution = targets['solution']          # [B, num_positions] value labels

            B, P, V = logits.shape
            output_loss = self.output_ce(
                logits.view(-1, V),
                solution.view(-1)
            ).view(B, P).mean()

            component_losses['output'] = output_loss * self.output_weight

            # Compute position accuracy and solve rate
            with torch.no_grad():
                preds = logits.argmax(dim=-1)
                position_acc = (preds == solution).float().mean().item()
                solve_rate = (preds == solution).all(dim=-1).float().mean().item()
                metrics['position_accuracy'] = position_acc
                metrics['solve_rate'] = solve_rate

        # Halting loss (ACT-style)
        if 'halt_probs' in predictions and 'optimal_halt_step' in targets:
            halt_probs = predictions['halt_probs']       # [B, num_steps]
            optimal_step = targets['optimal_halt_step']   # [B] optimal step to halt

            # Encourage halting at the optimal step
            halt_loss = self._halting_loss(halt_probs, optimal_step)
            component_losses['halting'] = halt_loss * self.halting_weight

            # Compute average halt step
            with torch.no_grad():
                cumulative = halt_probs.cumsum(dim=-1)
                halt_step = (cumulative > self.halt_threshold).float().argmax(dim=-1)
                metrics['avg_halt_step'] = halt_step.float().mean().item()

        # Solution path loss (sequence of moves)
        if 'path_logits' in predictions and 'solution_path' in targets:
            path_logits = predictions['path_logits']  # [B, max_steps, num_moves]
            solution_path = targets['solution_path']   # [B, max_steps] move indices
            path_mask = targets.get('path_mask', torch.ones_like(solution_path).bool())

            B, S, M = path_logits.shape
            path_loss = self.output_ce(
                path_logits.view(-1, M),
                solution_path.view(-1)
            ).view(B, S)

            # Mask invalid positions
            path_loss = (path_loss * path_mask.float()).sum() / path_mask.float().sum()
            component_losses['path'] = path_loss * self.path_weight

        # Consistency loss (penalize constraint violations)
        if 'constraint_violations' in predictions:
            violations = predictions['constraint_violations']  # [B] count of violations

            consistency_loss = violations.float().mean()
            component_losses['consistency'] = consistency_loss * self.consistency_weight

            with torch.no_grad():
                metrics['avg_violations'] = violations.float().mean().item()
                metrics['violation_free_rate'] = (violations == 0).float().mean().item()

        total = sum(component_losses.values()) if component_losses else torch.tensor(0.0)

        return LevelLossOutput(
            level=BloomLevel.CREATE,
            total_loss=total,
            component_losses=component_losses,
            metrics=metrics,
        )

    def _halting_loss(
        self,
        halt_probs: torch.Tensor,
        optimal_step: torch.Tensor,
    ) -> torch.Tensor:
        """
        ACT-style halting loss.

        Encourages:
            1. High halt probability at optimal step
            2. Low halt probability before optimal step
            3. Penalizes excessive computation (going past optimal)
        """
        B, S = halt_probs.shape
        device = halt_probs.device

        # Create step indices
        steps = torch.arange(S, device=device).unsqueeze(0).expand(B, S)
        optimal_expanded = optimal_step.unsqueeze(-1).expand(B, S)

        # Target: halt at optimal step
        target_halt = (steps == optimal_expanded).float()

        # Cross-entropy style loss
        halt_loss = F.binary_cross_entropy(
            halt_probs.clamp(1e-6, 1 - 1e-6),
            target_halt,
            reduction='mean'
        )

        # Add penalty for expected computation time
        expected_steps = (halt_probs * steps.float()).sum(dim=-1)
        time_penalty = F.relu(expected_steps - optimal_step.float()).mean()

        return halt_loss + self.halt_penalty * time_penalty


# =============================================================================
# Combined Loss Computer
# =============================================================================

class BloomLossComputer(nn.Module):
    """
    Combined loss computation for all Bloom levels.

    This is the main entry point for loss computation during training.
    It handles:
        1. Computing individual level losses
        2. Applying curriculum-based weights
        3. Aggregating into total loss
        4. Collecting metrics for diagnostics

    Domain-agnostic: all parameters come from configuration.
    """

    def __init__(
        self,
        num_rule_types: int = 10,
        constraint_dim: int = 32,
        num_values: int = 9,
        num_signal_classes: int = 3,
        config: Optional[Dict[str, Any]] = None,
    ):
        super().__init__()

        config = config or {}

        # Initialize per-level loss modules
        self.remember_loss = RememberLoss(
            num_rule_types=num_rule_types,
            constraint_dim=constraint_dim,
            **config.get('remember', {})
        )
        self.analyze_loss = AnalyzeLoss(**config.get('analyze', {}))
        self.evaluate_loss = EvaluateLoss(
            num_signal_classes=num_signal_classes,
            **config.get('evaluate', {})
        )
        self.create_loss = CreateLoss(
            num_values=num_values,
            **config.get('create', {})
        )

        # Default weights (can be overridden by curriculum)
        self.default_weights = {
            BloomLevel.REMEMBER: 1.0,
            BloomLevel.ANALYZE: 1.0,
            BloomLevel.EVALUATE: 1.5,
            BloomLevel.CREATE: 2.0,
        }

    def forward(
        self,
        predictions: Dict[BloomLevel, Dict[str, torch.Tensor]],
        targets: Dict[BloomLevel, Dict[str, torch.Tensor]],
        weights: Optional[Dict[BloomLevel, float]] = None,
        active_levels: Optional[List[BloomLevel]] = None,
    ) -> BloomLossOutput:
        """
        Compute weighted combination of all Bloom level losses.

        Args:
            predictions: Per-level prediction dicts
            targets: Per-level target dicts
            weights: Optional level weights (from curriculum)
            active_levels: Which levels to compute (None = all)

        Returns:
            BloomLossOutput with combined loss and per-level breakdowns
        """
        weights = weights or self.default_weights
        active_levels = active_levels or list(BloomLevel)

        level_losses = {}
        weighted_total = torch.tensor(0.0)

        # Get device from any available tensor
        device = None
        for level_preds in predictions.values():
            for tensor in level_preds.values():
                if isinstance(tensor, torch.Tensor):
                    device = tensor.device
                    break
            if device is not None:
                break

        if device is not None:
            weighted_total = weighted_total.to(device)

        # Compute loss for each active level
        for level in active_levels:
            if level not in predictions or level not in targets:
                continue

            level_preds = predictions[level]
            level_targets = targets[level]

            # Get appropriate loss module
            if level == BloomLevel.REMEMBER:
                level_output = self.remember_loss(level_preds, level_targets)
            elif level == BloomLevel.ANALYZE:
                level_output = self.analyze_loss(level_preds, level_targets)
            elif level == BloomLevel.EVALUATE:
                level_output = self.evaluate_loss(level_preds, level_targets)
            elif level == BloomLevel.CREATE:
                level_output = self.create_loss(level_preds, level_targets)
            else:
                continue

            level_losses[level] = level_output

            # Apply weight
            weight = weights.get(level, 1.0)
            if isinstance(level_output.total_loss, torch.Tensor):
                weighted_total = weighted_total + weight * level_output.total_loss

        return BloomLossOutput(
            level_losses=level_losses,
            weighted_total=weighted_total,
            weights_used=weights,
        )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Output containers
    'LevelLossOutput',
    'BloomLossOutput',

    # Per-level losses
    'RememberLoss',
    'AnalyzeLoss',
    'EvaluateLoss',
    'CreateLoss',

    # Combined
    'BloomLossComputer',
]
