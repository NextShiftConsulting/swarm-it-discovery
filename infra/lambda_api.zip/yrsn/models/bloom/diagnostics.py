"""
Bloom Diagnostics - Interpretability and Bottleneck Detection

Implements the Cognitive DuPont decomposition to find reasoning bottlenecks:

    Solve_Rate = P(Remember) x P(Analyze|Remember) x P(Evaluate|Analyze) x P(Create|Evaluate)

This lets you identify WHICH cognitive level is the limiting factor,
just like financial DuPont shows which business lever is weak.

Key Diagnostics:
    1. Per-level accuracy metrics
    2. Conditional probability decomposition
    3. Error attribution to specific levels
    4. Training progress tracking
    5. Curriculum adjustment recommendations

Usage:
    diagnostics = BloomDiagnostics(model)

    # Evaluate on test set
    analysis = diagnostics.analyze_dataset(test_loader)

    # Find bottleneck
    print(f"Weakest level: {analysis.bottleneck}")
    print(f"Recommendation: {analysis.recommendation}")
"""

import torch
import torch.nn as nn
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Callable
from collections import defaultdict

from .levels import (
    BloomLevel,
    BLOOM_HIERARCHY,
    BLOOM_ORDER,
    CognitiveDuPont,
)


# =============================================================================
# Diagnostic Data Structures
# =============================================================================

@dataclass
class LevelPerformance:
    """Performance metrics for a single Bloom level."""
    level: BloomLevel
    accuracy: float
    conditional_accuracy: float  # P(correct | previous level correct)
    loss_contribution: float
    sample_count: int

    # Per-component metrics
    component_metrics: Dict[str, float] = field(default_factory=dict)

    # Failure analysis
    failure_rate: float = 0.0
    common_failure_patterns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'level': self.level.name,
            'accuracy': self.accuracy,
            'conditional_accuracy': self.conditional_accuracy,
            'loss_contribution': self.loss_contribution,
            'sample_count': self.sample_count,
            'components': self.component_metrics,
            'failure_rate': self.failure_rate,
        }


@dataclass
class BottleneckAnalysis:
    """Complete bottleneck analysis results."""
    # Per-level performance
    level_performances: Dict[BloomLevel, LevelPerformance]

    # DuPont decomposition
    dupont: CognitiveDuPont

    # Identified bottleneck
    bottleneck: BloomLevel
    bottleneck_severity: float

    # Recommendations
    recommendation: str
    suggested_curriculum_adjustment: Dict[str, Any]

    # Raw data for plotting
    raw_metrics: Dict[str, List[float]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'bottleneck': self.bottleneck.name,
            'severity': self.bottleneck_severity,
            'recommendation': self.recommendation,
            'dupont': self.dupont.to_dict(),
            'levels': {k.name: v.to_dict() for k, v in self.level_performances.items()},
            'curriculum_adjustment': self.suggested_curriculum_adjustment,
        }

    def __repr__(self) -> str:
        lines = [
            "=" * 60,
            "BLOOM BOTTLENECK ANALYSIS",
            "=" * 60,
            "",
            str(self.dupont),
            "",
            f"Bottleneck: {self.bottleneck.name}",
            f"Severity: {self.bottleneck_severity:.1%}",
            "",
            "Recommendation:",
            f"  {self.recommendation}",
            "",
            "Per-Level Performance:",
        ]

        for level in BLOOM_ORDER:
            if level in self.level_performances:
                perf = self.level_performances[level]
                lines.append(
                    f"  {level.name}: {perf.accuracy:.1%} "
                    f"(conditional: {perf.conditional_accuracy:.1%})"
                )

        lines.append("=" * 60)
        return "\n".join(lines)


# =============================================================================
# Failure Pattern Detection
# =============================================================================

@dataclass
class FailurePattern:
    """A detected failure pattern."""
    name: str
    description: str
    affected_level: BloomLevel
    frequency: float
    examples: List[Dict[str, Any]] = field(default_factory=list)


class FailurePatternDetector:
    """
    Detect common failure patterns in model predictions.

    Domain-agnostic: works with any BloomTRM model outputs.
    """

    def __init__(self):
        self.pattern_detectors: Dict[BloomLevel, List[Callable]] = {
            BloomLevel.REMEMBER: [
                self._detect_rule_confusion,
                self._detect_state_encoding_error,
            ],
            BloomLevel.ANALYZE: [
                self._detect_wrong_breakin,
                self._detect_missed_constraint,
            ],
            BloomLevel.EVALUATE: [
                self._detect_overconfident_wrong_move,
                self._detect_underconfident_correct_move,
                self._detect_signal_misclassification,
            ],
            BloomLevel.CREATE: [
                self._detect_constraint_violation,
                self._detect_incomplete_solution,
                self._detect_premature_halt,
            ],
        }

    def detect_patterns(
        self,
        predictions: Dict[BloomLevel, Dict[str, torch.Tensor]],
        targets: Dict[BloomLevel, Dict[str, torch.Tensor]],
        level: BloomLevel,
    ) -> List[FailurePattern]:
        """Detect failure patterns for a specific level."""
        patterns = []

        for detector in self.pattern_detectors.get(level, []):
            pattern = detector(predictions.get(level, {}), targets.get(level, {}))
            if pattern is not None and pattern.frequency > 0.01:  # > 1% occurrence
                patterns.append(pattern)

        return patterns

    # Remember level patterns
    def _detect_rule_confusion(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect when model confuses similar rule types."""
        if 'rule_logits' not in preds or 'rule_labels' not in targets:
            return None

        logits = preds['rule_logits']
        labels = targets['rule_labels']

        pred_labels = logits.argmax(dim=-1)
        wrong = pred_labels != labels

        if wrong.float().mean() < 0.01:
            return None

        return FailurePattern(
            name="rule_confusion",
            description="Model confuses similar constraint types",
            affected_level=BloomLevel.REMEMBER,
            frequency=wrong.float().mean().item(),
        )

    def _detect_state_encoding_error(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect state encoding errors."""
        if 'constraint_reconstruction' not in preds:
            return None

        recon = preds['constraint_reconstruction']
        target = targets.get('constraint_vectors')

        if target is None:
            return None

        mse = (recon - target).pow(2).mean(dim=-1)
        high_error = (mse > mse.mean() + 2 * mse.std()).float().mean()

        if high_error < 0.05:
            return None

        return FailurePattern(
            name="state_encoding_error",
            description="High reconstruction error on constraint encoding",
            affected_level=BloomLevel.REMEMBER,
            frequency=high_error.item(),
        )

    # Analyze level patterns
    def _detect_wrong_breakin(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect when model identifies wrong break-in positions."""
        if 'breakin_scores' not in preds or 'breakin_positions' not in targets:
            return None

        scores = preds['breakin_scores']
        labels = targets['breakin_positions']

        pred_breakin = (torch.sigmoid(scores) > 0.5)
        actual_breakin = labels > 0.5

        # Check if predicted break-ins miss actual ones
        missed = actual_breakin & ~pred_breakin
        missed_rate = missed.float().mean()

        if missed_rate < 0.05:
            return None

        return FailurePattern(
            name="wrong_breakin",
            description="Model misses critical break-in positions",
            affected_level=BloomLevel.ANALYZE,
            frequency=missed_rate.item(),
        )

    def _detect_missed_constraint(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect when model misses critical constraints."""
        if 'priority_scores' not in preds or 'constraint_priorities' not in targets:
            return None

        scores = preds['priority_scores']
        priorities = targets['constraint_priorities']

        # High priority = top 20%
        threshold = priorities.quantile(0.8, dim=-1, keepdim=True)
        high_priority = priorities >= threshold

        # Model's top 20% predictions
        score_threshold = scores.quantile(0.8, dim=-1, keepdim=True)
        model_high = scores >= score_threshold

        # Missed high-priority constraints
        missed = high_priority & ~model_high
        missed_rate = missed.float().sum() / high_priority.float().sum()

        if missed_rate < 0.1:
            return None

        return FailurePattern(
            name="missed_constraint",
            description="Model doesn't prioritize critical constraints",
            affected_level=BloomLevel.ANALYZE,
            frequency=missed_rate.item(),
        )

    # Evaluate level patterns
    def _detect_overconfident_wrong_move(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect high confidence on wrong moves."""
        if 'confidence' not in preds or 'move_correctness' not in targets:
            return None

        confidence = preds['confidence']
        correctness = targets['move_correctness']

        # High confidence wrong moves
        overconfident = (confidence > 0.8) & (correctness < 0.5)
        rate = overconfident.float().mean()

        if rate < 0.02:
            return None

        return FailurePattern(
            name="overconfident_wrong",
            description="Model is highly confident on incorrect moves",
            affected_level=BloomLevel.EVALUATE,
            frequency=rate.item(),
        )

    def _detect_underconfident_correct_move(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect low confidence on correct moves."""
        if 'confidence' not in preds or 'move_correctness' not in targets:
            return None

        confidence = preds['confidence']
        correctness = targets['move_correctness']

        # Low confidence correct moves
        underconfident = (confidence < 0.5) & (correctness > 0.5)
        rate = underconfident.float().mean()

        if rate < 0.05:
            return None

        return FailurePattern(
            name="underconfident_correct",
            description="Model lacks confidence in correct moves",
            affected_level=BloomLevel.EVALUATE,
            frequency=rate.item(),
        )

    def _detect_signal_misclassification(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect signal classification errors (e.g., YRSN)."""
        if 'signal_logits' not in preds or 'signal_labels' not in targets:
            return None

        logits = preds['signal_logits']
        labels = targets['signal_labels']

        pred_labels = logits.argmax(dim=-1)
        wrong = pred_labels != labels
        rate = wrong.float().mean()

        if rate < 0.1:
            return None

        return FailurePattern(
            name="signal_misclassification",
            description="Model incorrectly classifies move quality",
            affected_level=BloomLevel.EVALUATE,
            frequency=rate.item(),
        )

    # Create level patterns
    def _detect_constraint_violation(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect constraint violations in solution."""
        if 'constraint_violations' not in preds:
            return None

        violations = preds['constraint_violations']
        rate = (violations > 0).float().mean()

        if rate < 0.05:
            return None

        return FailurePattern(
            name="constraint_violation",
            description="Solution violates problem constraints",
            affected_level=BloomLevel.CREATE,
            frequency=rate.item(),
        )

    def _detect_incomplete_solution(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect incomplete solutions."""
        if 'output_logits' not in preds or 'solution' not in targets:
            return None

        logits = preds['output_logits']
        solution = targets['solution']

        pred_output = logits.argmax(dim=-1)
        per_sample_correct = (pred_output == solution).all(dim=-1)
        incomplete_rate = 1 - per_sample_correct.float().mean()

        if incomplete_rate < 0.1:
            return None

        return FailurePattern(
            name="incomplete_solution",
            description="Model fails to produce complete valid solution",
            affected_level=BloomLevel.CREATE,
            frequency=incomplete_rate.item(),
        )

    def _detect_premature_halt(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Optional[FailurePattern]:
        """Detect premature halting."""
        if 'halt_probs' not in preds or 'optimal_halt_step' not in targets:
            return None

        halt_probs = preds['halt_probs']
        optimal = targets['optimal_halt_step']

        # Find actual halt step (first step with high halt prob)
        cumulative = halt_probs.cumsum(dim=-1)
        actual_halt = (cumulative > 0.5).float().argmax(dim=-1)

        # Premature = halted before optimal
        premature = (actual_halt < optimal).float().mean()

        if premature < 0.1:
            return None

        return FailurePattern(
            name="premature_halt",
            description="Model halts before reaching correct solution",
            affected_level=BloomLevel.CREATE,
            frequency=premature.item(),
        )


# =============================================================================
# Main Diagnostics Class
# =============================================================================

class BloomDiagnostics:
    """
    Comprehensive diagnostics for Bloom-structured models.

    Provides:
        1. Per-level performance evaluation
        2. Cognitive DuPont decomposition
        3. Bottleneck identification
        4. Training recommendations

    Domain-agnostic: works with any BloomTRM model.
    """

    def __init__(self, model: nn.Module):
        """
        Initialize diagnostics.

        Args:
            model: BloomTRM model to analyze
        """
        self.model = model
        self.pattern_detector = FailurePatternDetector()

        # Metric accumulators
        self.reset_metrics()

    def reset_metrics(self):
        """Reset accumulated metrics."""
        self.level_correct = {level: 0 for level in BloomLevel}
        self.level_total = {level: 0 for level in BloomLevel}
        self.conditional_correct = {level: 0 for level in BloomLevel}
        self.conditional_total = {level: 0 for level in BloomLevel}
        self.level_losses = {level: [] for level in BloomLevel}
        self.component_metrics = {level: defaultdict(list) for level in BloomLevel}
        self.all_predictions = []
        self.all_targets = []

    @torch.no_grad()
    def evaluate_batch(
        self,
        predictions: Dict[BloomLevel, Dict[str, torch.Tensor]],
        targets: Dict[BloomLevel, Dict[str, torch.Tensor]],
        loss_output: Optional[Any] = None,
    ):
        """
        Accumulate metrics from a single batch.

        Args:
            predictions: Per-level predictions
            targets: Per-level targets
            loss_output: Optional loss output with component losses
        """
        # Store for pattern analysis
        self.all_predictions.append(predictions)
        self.all_targets.append(targets)

        # Track per-level correctness
        prev_level_correct = None

        for level in BLOOM_ORDER:
            if level not in predictions or level not in targets:
                continue

            preds = predictions[level]
            targs = targets[level]

            # Level-specific correctness check
            correct, total, metrics = self._compute_level_correctness(level, preds, targs)

            self.level_correct[level] += correct
            self.level_total[level] += total

            # Track component metrics
            for name, value in metrics.items():
                self.component_metrics[level][name].append(value)

            # Conditional correctness (given previous level was correct)
            if prev_level_correct is not None:
                cond_mask = prev_level_correct
                if cond_mask.sum() > 0:
                    level_correct_tensor = self._get_level_correct_tensor(level, preds, targs)
                    self.conditional_correct[level] += (level_correct_tensor & cond_mask).sum().item()
                    self.conditional_total[level] += cond_mask.sum().item()

            # Update previous level correctness
            prev_level_correct = self._get_level_correct_tensor(level, preds, targs)

            # Track losses
            if loss_output is not None and hasattr(loss_output, 'level_losses'):
                if level in loss_output.level_losses:
                    level_loss = loss_output.level_losses[level]
                    self.level_losses[level].append(level_loss.total_loss.item())

    def _compute_level_correctness(
        self,
        level: BloomLevel,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> Tuple[int, int, Dict[str, float]]:
        """Compute correctness count and metrics for a level."""
        metrics = {}

        if level == BloomLevel.REMEMBER:
            if 'rule_logits' in preds and 'rule_labels' in targets:
                pred_rules = preds['rule_logits'].argmax(dim=-1)
                correct = (pred_rules == targets['rule_labels']).all(dim=-1).sum().item()
                total = pred_rules.shape[0]
                metrics['rule_acc'] = (pred_rules == targets['rule_labels']).float().mean().item()
                return correct, total, metrics

        elif level == BloomLevel.ANALYZE:
            if 'breakin_scores' in preds and 'breakin_positions' in targets:
                pred_breakin = (torch.sigmoid(preds['breakin_scores']) > 0.5)
                actual_breakin = targets['breakin_positions'] > 0.5
                # Correct if at least one actual breakin is predicted
                correct = (pred_breakin & actual_breakin).any(dim=-1).sum().item()
                total = pred_breakin.shape[0]
                precision = ((pred_breakin & actual_breakin).sum() /
                            (pred_breakin.sum() + 1e-8)).item()
                metrics['breakin_precision'] = precision
                return correct, total, metrics

        elif level == BloomLevel.EVALUATE:
            if 'move_logits' in preds and 'correct_move' in targets:
                pred_move = preds['move_logits'].argmax(dim=-1)
                correct = (pred_move == targets['correct_move']).sum().item()
                total = pred_move.shape[0]
                metrics['move_acc'] = (pred_move == targets['correct_move']).float().mean().item()
                return correct, total, metrics

        elif level == BloomLevel.CREATE:
            if 'output_logits' in preds and 'solution' in targets:
                pred_output = preds['output_logits'].argmax(dim=-1)
                correct = (pred_output == targets['solution']).all(dim=-1).sum().item()
                total = pred_output.shape[0]
                position_acc = (pred_output == targets['solution']).float().mean().item()
                metrics['position_acc'] = position_acc
                metrics['solve_rate'] = correct / max(total, 1)
                return correct, total, metrics

        return 0, 0, metrics

    def _get_level_correct_tensor(
        self,
        level: BloomLevel,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
    ) -> torch.Tensor:
        """Get boolean tensor indicating correctness per sample."""
        if level == BloomLevel.REMEMBER:
            if 'rule_logits' in preds and 'rule_labels' in targets:
                pred_rules = preds['rule_logits'].argmax(dim=-1)
                return (pred_rules == targets['rule_labels']).all(dim=-1)

        elif level == BloomLevel.ANALYZE:
            if 'breakin_scores' in preds and 'breakin_positions' in targets:
                pred_breakin = (torch.sigmoid(preds['breakin_scores']) > 0.5)
                actual_breakin = targets['breakin_positions'] > 0.5
                return (pred_breakin & actual_breakin).any(dim=-1)

        elif level == BloomLevel.EVALUATE:
            if 'move_logits' in preds and 'correct_move' in targets:
                pred_move = preds['move_logits'].argmax(dim=-1)
                return pred_move == targets['correct_move']

        elif level == BloomLevel.CREATE:
            if 'output_logits' in preds and 'solution' in targets:
                pred_output = preds['output_logits'].argmax(dim=-1)
                return (pred_output == targets['solution']).all(dim=-1)

        return torch.zeros(1, dtype=torch.bool)

    def compute_analysis(self) -> BottleneckAnalysis:
        """
        Compute full bottleneck analysis from accumulated metrics.

        Returns:
            BottleneckAnalysis with DuPont decomposition and recommendations
        """
        # Compute per-level performance
        level_performances = {}

        for level in BLOOM_ORDER:
            accuracy = (self.level_correct[level] / max(self.level_total[level], 1))
            conditional = (self.conditional_correct[level] /
                          max(self.conditional_total[level], 1))

            avg_loss = np.mean(self.level_losses[level]) if self.level_losses[level] else 0.0

            # Aggregate component metrics
            component_metrics = {}
            for name, values in self.component_metrics[level].items():
                component_metrics[name] = np.mean(values) if values else 0.0

            level_performances[level] = LevelPerformance(
                level=level,
                accuracy=accuracy,
                conditional_accuracy=conditional if conditional > 0 else accuracy,
                loss_contribution=avg_loss,
                sample_count=self.level_total[level],
                component_metrics=component_metrics,
                failure_rate=1 - accuracy,
            )

        # Compute Cognitive DuPont
        dupont = CognitiveDuPont(
            remember_accuracy=level_performances[BloomLevel.REMEMBER].accuracy,
            analyze_accuracy=level_performances[BloomLevel.ANALYZE].conditional_accuracy,
            evaluate_accuracy=level_performances[BloomLevel.EVALUATE].conditional_accuracy,
            create_accuracy=level_performances[BloomLevel.CREATE].conditional_accuracy,
        )

        # Generate recommendation
        bottleneck = dupont.bottleneck_level
        recommendation, curriculum_adj = self._generate_recommendation(
            bottleneck,
            level_performances,
            dupont,
        )

        return BottleneckAnalysis(
            level_performances=level_performances,
            dupont=dupont,
            bottleneck=bottleneck,
            bottleneck_severity=dupont.bottleneck_severity,
            recommendation=recommendation,
            suggested_curriculum_adjustment=curriculum_adj,
        )

    def _generate_recommendation(
        self,
        bottleneck: BloomLevel,
        performances: Dict[BloomLevel, LevelPerformance],
        dupont: CognitiveDuPont,
    ) -> Tuple[str, Dict[str, Any]]:
        """Generate actionable recommendations based on analysis."""

        recommendations = {
            BloomLevel.REMEMBER: (
                "Focus on rule encoding. Consider:\n"
                "  - Adding more constraint type training examples\n"
                "  - Increasing REMEMBER loss weight\n"
                "  - Extending Phase 1 duration\n"
                "  - Check if constraint vocabulary is sufficient"
            ),
            BloomLevel.ANALYZE: (
                "Focus on break-in detection. Consider:\n"
                "  - Training on more diverse constraint patterns\n"
                "  - Adding explicit break-in position supervision\n"
                "  - Increasing ANALYZE loss weight\n"
                "  - Check constraint priority labels quality"
            ),
            BloomLevel.EVALUATE: (
                "Focus on move evaluation. Consider:\n"
                "  - Adding more move ranking training data\n"
                "  - Improving signal classification supervision\n"
                "  - Increasing EVALUATE loss weight\n"
                "  - Check for move label noise"
            ),
            BloomLevel.CREATE: (
                "Focus on solution synthesis. Consider:\n"
                "  - Training longer on full problems\n"
                "  - Adjusting halting threshold\n"
                "  - Increasing CREATE loss weight\n"
                "  - Check for constraint violation patterns"
            ),
        }

        # Curriculum adjustments
        perf = performances[bottleneck]
        curr_adj = {
            'increase_weight': bottleneck.name,
            'suggested_multiplier': 1.5 if perf.accuracy < 0.7 else 1.2,
            'extend_phase': 1 if bottleneck in [BloomLevel.REMEMBER, BloomLevel.ANALYZE]
                          else (2 if bottleneck == BloomLevel.EVALUATE else 3),
        }

        return recommendations[bottleneck], curr_adj

    @torch.no_grad()
    def analyze_dataset(
        self,
        dataloader,
        max_batches: Optional[int] = None,
    ) -> BottleneckAnalysis:
        """
        Run full analysis on a dataset.

        Args:
            dataloader: PyTorch DataLoader
            max_batches: Optional limit on batches to process

        Returns:
            Complete BottleneckAnalysis
        """
        self.reset_metrics()
        self.model.eval()

        for i, batch in enumerate(dataloader):
            if max_batches is not None and i >= max_batches:
                break

            # Forward pass
            output = self.model(**batch['inputs'])

            # Get predictions in per-level format
            predictions = output.get_bloom_predictions()

            # Get targets
            targets = batch.get('bloom_targets', {})

            # Accumulate metrics
            self.evaluate_batch(predictions, targets)

        return self.compute_analysis()


# =============================================================================
# Convenience Functions
# =============================================================================

def diagnose_reasoning_failure(
    model: nn.Module,
    batch: Dict[str, Any],
    verbose: bool = True,
) -> BottleneckAnalysis:
    """
    Quick diagnosis of why model failed on a batch.

    Args:
        model: BloomTRM model
        batch: Single batch that failed
        verbose: Print diagnosis

    Returns:
        BottleneckAnalysis for this batch
    """
    diagnostics = BloomDiagnostics(model)

    with torch.no_grad():
        model.eval()
        output = model(**batch['inputs'])
        predictions = output.get_bloom_predictions()
        targets = batch.get('bloom_targets', {})

        diagnostics.evaluate_batch(predictions, targets)

    analysis = diagnostics.compute_analysis()

    if verbose:
        print(analysis)

    return analysis


def compare_models(
    models: Dict[str, nn.Module],
    dataloader,
    max_batches: int = 50,
) -> Dict[str, BottleneckAnalysis]:
    """
    Compare multiple models on same data.

    Args:
        models: Dict of model name -> model
        dataloader: Test data
        max_batches: Batches to evaluate

    Returns:
        Dict of model name -> BottleneckAnalysis
    """
    results = {}

    for name, model in models.items():
        diagnostics = BloomDiagnostics(model)
        analysis = diagnostics.analyze_dataset(dataloader, max_batches)
        results[name] = analysis

    return results


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Data structures
    'LevelPerformance',
    'BottleneckAnalysis',
    'FailurePattern',

    # Main class
    'BloomDiagnostics',

    # Pattern detection
    'FailurePatternDetector',

    # Convenience functions
    'diagnose_reasoning_failure',
    'compare_models',
]
