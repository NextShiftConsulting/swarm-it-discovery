"""
Bloom Cognitive Architecture

A domain-agnostic cognitive framework based on Bloom's Taxonomy for
structured reasoning and constraint satisfaction problems.

The Bloom architecture provides:
    1. Hierarchical cognitive levels (Remember, Analyze, Evaluate, Create)
    2. Curriculum-based training with phased skill development
    3. Level-specific neural heads and loss functions
    4. Cognitive DuPont decomposition for bottleneck analysis
    5. TRM (Thinking Recurrence Machine) for iterative refinement

Usage:
    # Configure for your domain (e.g., 9x9 Sudoku)
    config = BloomTRMConfig(
        num_positions=81,
        num_values=9,
        num_regions=27,
        num_rule_types=10,
    )

    # Create model
    model = BloomTRM(config)

    # Create curriculum
    curriculum = BloomCurriculum(
        phase1_epochs=10,
        phase2_epochs=20,
        phase3_epochs=30,
    )

    # Training loop
    for epoch in range(60):
        weights = curriculum.get_weights(epoch)
        for batch in dataloader:
            output = model(batch['tokens'], batch['state'])
            loss = model.compute_loss(output, batch, weights)
            loss.backward()

Components:
    - levels: BloomLevel enum, BloomLevelSpec, CognitiveDuPont
    - curriculum: BloomCurriculum, PhaseConfig, LossWeights
    - heads: BloomHeadBank, per-level heads (Remember, Analyze, Evaluate, Create)
    - losses: BloomLossComputer, per-level losses
    - trm: BloomTRM, TRMStep, BloomEncoder
"""

# Levels and cognitive framework
from .levels import (
    BloomLevel,
    BloomLevelSpec,
    BloomStepConfig,
    CognitiveDuPont,
    BLOOM_HIERARCHY,
    BLOOM_ORDER,
    create_remember_spec,
    create_analyze_spec,
    create_evaluate_spec,
    create_create_spec,
    create_meta_spec,
    create_default_hierarchy,
    level_to_step_range,
    get_level_description,
    get_active_levels_at_step,
    get_primary_level_at_step,
    compute_step_configs,
)

# Curriculum
from .curriculum import (
    CurriculumPhase,
    PhaseConfig,
    LossWeights,
    BloomCurriculum,
    get_default_curriculum,
    get_fast_curriculum,
    get_gated_curriculum,
    get_single_phase_curriculum,
    visualize_curriculum,
    DEFAULT_PHASE_1,
    DEFAULT_PHASE_2,
    DEFAULT_PHASE_3,
    DEFAULT_PHASES,
)

# Heads
from .heads import (
    BloomHeadsConfig,
    BloomHead,
    BloomHeadBank,
    # Remember
    RuleClassifierHead,
    ConstraintReconstructionHead,
    RememberHead,
    # Analyze
    BreakInPositionHead,
    CriticalRegionHead,
    AnalyzeHead,
    # Evaluate
    MoveScorerHead,
    SignalClassifierHead,
    MoveConfidenceHead,
    EvaluateHead,
    # Create
    FinalOutputHead,
    HaltingHead,
    SolutionPathHead,
    CreateHead,
    # Meta
    StrategyClassifierHead,
    DomainInvarianceHead,
    TraceReconstructionHead,
    MetaHead,
)

# Dual Halting
from .halting import (
    HaltingConfig,
    ACTHaltingHead,
    QLearningHaltingHead,
    DualHaltingModule,
)

# YRSN Monitor
from .yrsn_monitor import (
    YRSNMonitorConfig,
    YRSNProjectionHead,
    CollapseDetector,
    YRSNMonitor,
)

# Losses
from .losses import (
    LevelLossOutput,
    BloomLossOutput,
    RememberLoss,
    AnalyzeLoss,
    EvaluateLoss,
    CreateLoss,
    BloomLossComputer,
)

# TRM Model
from .trm import (
    BloomTRMConfig,
    BloomForwardOutput,
    BloomTRM,
    TRMStep,
    BloomEncoder,
    create_bloom_trm,
)

# Diagnostics
from .diagnostics import (
    LevelPerformance,
    BottleneckAnalysis,
    FailurePattern,
    BloomDiagnostics,
    FailurePatternDetector,
    diagnose_reasoning_failure,
    compare_models,
)


__all__ = [
    # Levels
    'BloomLevel',
    'BloomLevelSpec',
    'BloomStepConfig',
    'CognitiveDuPont',
    'BLOOM_HIERARCHY',
    'BLOOM_ORDER',
    'create_remember_spec',
    'create_analyze_spec',
    'create_evaluate_spec',
    'create_create_spec',
    'create_meta_spec',
    'create_default_hierarchy',
    'level_to_step_range',
    'get_level_description',
    'get_active_levels_at_step',
    'get_primary_level_at_step',
    'compute_step_configs',

    # Curriculum
    'CurriculumPhase',
    'PhaseConfig',
    'LossWeights',
    'BloomCurriculum',
    'get_default_curriculum',
    'get_fast_curriculum',
    'get_gated_curriculum',
    'get_single_phase_curriculum',
    'visualize_curriculum',
    'DEFAULT_PHASE_1',
    'DEFAULT_PHASE_2',
    'DEFAULT_PHASE_3',
    'DEFAULT_PHASES',

    # Heads
    'BloomHeadsConfig',
    'BloomHead',
    'BloomHeadBank',
    'RuleClassifierHead',
    'ConstraintReconstructionHead',
    'RememberHead',
    'BreakInPositionHead',
    'CriticalRegionHead',
    'AnalyzeHead',
    'MoveScorerHead',
    'SignalClassifierHead',
    'MoveConfidenceHead',
    'EvaluateHead',
    'FinalOutputHead',
    'HaltingHead',
    'SolutionPathHead',
    'CreateHead',
    # Meta heads
    'StrategyClassifierHead',
    'DomainInvarianceHead',
    'TraceReconstructionHead',
    'MetaHead',

    # Dual Halting
    'HaltingConfig',
    'ACTHaltingHead',
    'QLearningHaltingHead',
    'DualHaltingModule',

    # YRSN Monitor
    'YRSNMonitorConfig',
    'YRSNProjectionHead',
    'CollapseDetector',
    'YRSNMonitor',

    # Losses
    'LevelLossOutput',
    'BloomLossOutput',
    'RememberLoss',
    'AnalyzeLoss',
    'EvaluateLoss',
    'CreateLoss',
    'BloomLossComputer',

    # TRM
    'BloomTRMConfig',
    'BloomForwardOutput',
    'BloomTRM',
    'TRMStep',
    'BloomEncoder',
    'create_bloom_trm',

    # Diagnostics
    'LevelPerformance',
    'BottleneckAnalysis',
    'FailurePattern',
    'BloomDiagnostics',
    'FailurePatternDetector',
    'diagnose_reasoning_failure',
    'compare_models',
]
