"""
Bloom Curriculum - Training Regime and Loss Scheduling

Implements phased training that mirrors cognitive development:

    Phase 1: Focus on REMEMBER + ANALYZE
        - Learn to encode problems correctly
        - Learn to find starting points
        - Lower-level skills must be solid before higher levels

    Phase 2: Add EVALUATE
        - Now that encoding is stable, learn to score moves
        - Move ranking becomes the focus
        - Signal classification introduced

    Phase 3: Full CREATE
        - All levels active with full weights
        - Solution synthesis emphasized
        - Halting behavior refined

Key Insight:
    Just like humans can't evaluate options without understanding the problem,
    models shouldn't be trained on CREATE before REMEMBER is working.

Design Principles:
    1. Monotonic complexity - never decrease capability during training
    2. Loss weight ramping - smooth transitions between phases
    3. Success gating - optionally gate phase transitions on metrics
"""

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Callable, Any
from enum import Enum, auto

from .levels import BloomLevel, BLOOM_HIERARCHY


# =============================================================================
# Curriculum Phase Definition
# =============================================================================

class CurriculumPhase(Enum):
    """Training curriculum phases."""
    PHASE_1 = 1  # Remember + Analyze
    PHASE_2 = 2  # + Evaluate
    PHASE_3 = 3  # + Create (full)


@dataclass
class PhaseConfig:
    """Configuration for a single curriculum phase."""
    phase: CurriculumPhase
    name: str
    description: str

    # Duration
    epochs: int
    warmup_epochs: int = 2

    # Active levels and their target weights at end of phase
    level_weights: Dict[BloomLevel, float] = field(default_factory=dict)

    # Optional success thresholds to advance (if using gated curriculum)
    success_thresholds: Dict[str, float] = field(default_factory=dict)

    # Learning rate multiplier for this phase
    lr_multiplier: float = 1.0


# =============================================================================
# Loss Weights Container
# =============================================================================

@dataclass
class LossWeights:
    """Container for current loss weights."""
    remember: float = 1.0
    analyze: float = 1.0
    evaluate: float = 0.0
    create: float = 0.0

    # Metadata
    epoch: int = 0
    phase: CurriculumPhase = CurriculumPhase.PHASE_1

    def to_dict(self) -> Dict[BloomLevel, float]:
        return {
            BloomLevel.REMEMBER: self.remember,
            BloomLevel.ANALYZE: self.analyze,
            BloomLevel.EVALUATE: self.evaluate,
            BloomLevel.CREATE: self.create,
        }

    def active_levels(self) -> List[BloomLevel]:
        """Get levels with non-zero weights."""
        return [level for level, weight in self.to_dict().items() if weight > 0]

    def __repr__(self) -> str:
        return (
            f"LossWeights(phase={self.phase.name}, epoch={self.epoch}, "
            f"R={self.remember:.2f}, A={self.analyze:.2f}, "
            f"E={self.evaluate:.2f}, C={self.create:.2f})"
        )


# =============================================================================
# Default Phase Configurations
# =============================================================================

DEFAULT_PHASE_1 = PhaseConfig(
    phase=CurriculumPhase.PHASE_1,
    name="Foundation",
    description="Learn to encode problems and find break-in points",
    epochs=10,
    warmup_epochs=2,
    level_weights={
        BloomLevel.REMEMBER: 1.0,
        BloomLevel.ANALYZE: 1.0,
        BloomLevel.EVALUATE: 0.0,
        BloomLevel.CREATE: 0.0,
    },
    success_thresholds={
        'encoding_accuracy': 0.85,
        'breakin_precision': 0.70,
    },
    lr_multiplier=1.0,
)

DEFAULT_PHASE_2 = PhaseConfig(
    phase=CurriculumPhase.PHASE_2,
    name="Evaluation",
    description="Learn to score and rank candidate moves",
    epochs=20,
    warmup_epochs=3,
    level_weights={
        BloomLevel.REMEMBER: 1.0,
        BloomLevel.ANALYZE: 1.0,
        BloomLevel.EVALUATE: 1.5,
        BloomLevel.CREATE: 0.0,
    },
    success_thresholds={
        'move_accuracy': 0.75,
        'signal_accuracy': 0.80,
    },
    lr_multiplier=0.8,
)

DEFAULT_PHASE_3 = PhaseConfig(
    phase=CurriculumPhase.PHASE_3,
    name="Synthesis",
    description="Learn to produce complete solutions",
    epochs=30,
    warmup_epochs=5,
    level_weights={
        BloomLevel.REMEMBER: 1.0,
        BloomLevel.ANALYZE: 1.0,
        BloomLevel.EVALUATE: 1.5,
        BloomLevel.CREATE: 2.0,
    },
    success_thresholds={
        'solve_rate': 0.90,
        'output_accuracy': 0.98,
    },
    lr_multiplier=0.5,
)

DEFAULT_PHASES = [DEFAULT_PHASE_1, DEFAULT_PHASE_2, DEFAULT_PHASE_3]


# =============================================================================
# Curriculum Scheduler
# =============================================================================

class BloomCurriculum:
    """
    Curriculum scheduler for Bloom-structured training.

    Manages:
        1. Phase transitions based on epochs or metrics
        2. Loss weight interpolation within phases
        3. Learning rate scheduling
        4. Logging and monitoring

    Usage:
        curriculum = BloomCurriculum(
            phase1_epochs=10,
            phase2_epochs=20,
            phase3_epochs=30,
        )

        for epoch in range(60):
            weights = curriculum.get_weights(epoch)
            # ... training with weights ...
            curriculum.update_metrics(epoch, metrics)
    """

    def __init__(
        self,
        phase1_epochs: int = 10,
        phase2_epochs: int = 20,
        phase3_epochs: int = 30,
        use_gated_transitions: bool = False,
        warmup_type: str = 'linear',  # 'linear', 'cosine', 'step'
        custom_phases: Optional[List[PhaseConfig]] = None,
    ):
        """
        Initialize curriculum.

        Args:
            phase1_epochs: Epochs for Phase 1 (Remember + Analyze)
            phase2_epochs: Epochs for Phase 2 (+ Evaluate)
            phase3_epochs: Epochs for Phase 3 (+ Create)
            use_gated_transitions: If True, require metrics thresholds to advance
            warmup_type: How to ramp weights within phases
            custom_phases: Override default phase configurations
        """
        self.use_gated_transitions = use_gated_transitions
        self.warmup_type = warmup_type

        # Configure phases
        if custom_phases is not None:
            self.phases = custom_phases
        else:
            self.phases = [
                PhaseConfig(
                    phase=CurriculumPhase.PHASE_1,
                    name="Foundation",
                    description="Learn encoding and analysis",
                    epochs=phase1_epochs,
                    warmup_epochs=min(2, phase1_epochs // 3),
                    level_weights=DEFAULT_PHASE_1.level_weights.copy(),
                    success_thresholds=DEFAULT_PHASE_1.success_thresholds.copy(),
                ),
                PhaseConfig(
                    phase=CurriculumPhase.PHASE_2,
                    name="Evaluation",
                    description="Learn move scoring",
                    epochs=phase2_epochs,
                    warmup_epochs=min(3, phase2_epochs // 4),
                    level_weights=DEFAULT_PHASE_2.level_weights.copy(),
                    success_thresholds=DEFAULT_PHASE_2.success_thresholds.copy(),
                ),
                PhaseConfig(
                    phase=CurriculumPhase.PHASE_3,
                    name="Synthesis",
                    description="Learn solution generation",
                    epochs=phase3_epochs,
                    warmup_epochs=min(5, phase3_epochs // 3),
                    level_weights=DEFAULT_PHASE_3.level_weights.copy(),
                    success_thresholds=DEFAULT_PHASE_3.success_thresholds.copy(),
                ),
            ]

        # Calculate phase boundaries
        self._compute_boundaries()

        # State tracking
        self.current_phase_idx = 0
        self.metrics_history: List[Dict[str, float]] = []
        self.forced_phase: Optional[int] = None

    def _compute_boundaries(self):
        """Compute epoch boundaries for phases."""
        self.phase_boundaries = []
        cumulative = 0

        for phase_config in self.phases:
            start = cumulative
            end = cumulative + phase_config.epochs
            self.phase_boundaries.append((start, end))
            cumulative = end

        self.total_epochs = cumulative

    def get_phase(self, epoch: int) -> Tuple[CurriculumPhase, PhaseConfig]:
        """Get the phase and config for a given epoch."""
        if self.forced_phase is not None:
            return self.phases[self.forced_phase].phase, self.phases[self.forced_phase]

        for i, (start, end) in enumerate(self.phase_boundaries):
            if start <= epoch < end:
                return self.phases[i].phase, self.phases[i]

        # Past all phases - stay in final phase
        return self.phases[-1].phase, self.phases[-1]

    def get_weights(self, epoch: int) -> LossWeights:
        """
        Get loss weights for a given epoch.

        Handles:
            1. Phase determination
            2. Warmup ramping within phase
            3. Smooth interpolation between phases
        """
        phase, config = self.get_phase(epoch)

        # Find epoch within current phase
        phase_idx = self.phases.index(config)
        phase_start, phase_end = self.phase_boundaries[phase_idx]
        epoch_in_phase = epoch - phase_start

        # Get target weights for this phase
        target_weights = config.level_weights

        # Get weights from previous phase (for interpolation)
        if phase_idx > 0:
            prev_weights = self.phases[phase_idx - 1].level_weights
        else:
            prev_weights = {level: 0.0 for level in BloomLevel}
            prev_weights[BloomLevel.REMEMBER] = 1.0
            prev_weights[BloomLevel.ANALYZE] = 1.0

        # Compute interpolation factor based on warmup
        if epoch_in_phase < config.warmup_epochs:
            # During warmup - ramp from previous weights to target
            progress = epoch_in_phase / config.warmup_epochs
            interp_factor = self._warmup_schedule(progress)
        else:
            interp_factor = 1.0

        # Interpolate weights
        weights = {}
        for level in BloomLevel:
            prev = prev_weights.get(level, 0.0)
            target = target_weights.get(level, 0.0)
            weights[level] = prev + interp_factor * (target - prev)

        return LossWeights(
            remember=weights[BloomLevel.REMEMBER],
            analyze=weights[BloomLevel.ANALYZE],
            evaluate=weights[BloomLevel.EVALUATE],
            create=weights[BloomLevel.CREATE],
            epoch=epoch,
            phase=phase,
        )

    def _warmup_schedule(self, progress: float) -> float:
        """Compute warmup factor based on schedule type."""
        if self.warmup_type == 'linear':
            return progress
        elif self.warmup_type == 'cosine':
            return 0.5 * (1 - math.cos(math.pi * progress))
        elif self.warmup_type == 'step':
            return 1.0 if progress >= 0.5 else 0.0
        else:
            return progress

    def get_lr_multiplier(self, epoch: int) -> float:
        """Get learning rate multiplier for epoch."""
        _, config = self.get_phase(epoch)
        return config.lr_multiplier

    def update_metrics(self, epoch: int, metrics: Dict[str, float]):
        """
        Update metrics for potential gated transitions.

        Args:
            epoch: Current epoch
            metrics: Dict of metric name -> value
        """
        self.metrics_history.append({'epoch': epoch, **metrics})

        if self.use_gated_transitions:
            # Check if we should advance phase
            phase, config = self.get_phase(epoch)
            thresholds = config.success_thresholds

            if thresholds:
                all_met = all(
                    metrics.get(name, 0) >= threshold
                    for name, threshold in thresholds.items()
                )

                if all_met:
                    # Allow natural progression
                    pass
                else:
                    # Hold in current phase
                    phase_idx = self.phases.index(config)
                    if epoch >= self.phase_boundaries[phase_idx][1] - 1:
                        # Would advance but metrics not met - extend phase
                        self.forced_phase = phase_idx

    def force_phase(self, phase_idx: int):
        """Manually force a specific phase."""
        self.forced_phase = phase_idx

    def release_phase_lock(self):
        """Release any forced phase lock."""
        self.forced_phase = None

    def get_phase_progress(self, epoch: int) -> Dict[str, Any]:
        """Get detailed progress information."""
        phase, config = self.get_phase(epoch)
        phase_idx = self.phases.index(config)
        phase_start, phase_end = self.phase_boundaries[phase_idx]

        epoch_in_phase = epoch - phase_start
        phase_progress = epoch_in_phase / config.epochs

        return {
            'epoch': epoch,
            'phase': phase.name,
            'phase_name': config.name,
            'phase_idx': phase_idx + 1,
            'total_phases': len(self.phases),
            'epoch_in_phase': epoch_in_phase,
            'phase_epochs': config.epochs,
            'phase_progress': phase_progress,
            'overall_progress': epoch / self.total_epochs,
            'in_warmup': epoch_in_phase < config.warmup_epochs,
            'description': config.description,
        }

    def __repr__(self) -> str:
        phases_str = ', '.join(
            f"{p.name}({p.epochs})"
            for p in self.phases
        )
        return f"BloomCurriculum([{phases_str}], total={self.total_epochs})"


# =============================================================================
# Pre-built Curriculum Configurations
# =============================================================================

def get_default_curriculum(total_epochs: int = 60) -> BloomCurriculum:
    """Get default curriculum scaled to total epochs."""
    # Ratio: 1:2:3 for phases
    phase1 = total_epochs // 6
    phase2 = total_epochs // 3
    phase3 = total_epochs - phase1 - phase2

    return BloomCurriculum(
        phase1_epochs=phase1,
        phase2_epochs=phase2,
        phase3_epochs=phase3,
    )


def get_fast_curriculum(total_epochs: int = 30) -> BloomCurriculum:
    """Get fast curriculum for quick experiments."""
    phase1 = max(3, total_epochs // 6)
    phase2 = max(5, total_epochs // 3)
    phase3 = total_epochs - phase1 - phase2

    return BloomCurriculum(
        phase1_epochs=phase1,
        phase2_epochs=phase2,
        phase3_epochs=phase3,
        warmup_type='step',  # Faster transitions
    )


def get_gated_curriculum(
    base_epochs_per_phase: int = 20,
    max_epochs_per_phase: int = 50,
) -> BloomCurriculum:
    """
    Get curriculum with metric-gated phase transitions.

    Phases don't advance until success thresholds are met.
    """
    return BloomCurriculum(
        phase1_epochs=base_epochs_per_phase,
        phase2_epochs=base_epochs_per_phase,
        phase3_epochs=base_epochs_per_phase,
        use_gated_transitions=True,
    )


def get_single_phase_curriculum(
    phase: CurriculumPhase,
    epochs: int = 30,
) -> BloomCurriculum:
    """
    Get curriculum that stays in a single phase.

    Useful for ablation studies or fine-tuning specific levels.
    """
    if phase == CurriculumPhase.PHASE_1:
        weights = DEFAULT_PHASE_1.level_weights.copy()
    elif phase == CurriculumPhase.PHASE_2:
        weights = DEFAULT_PHASE_2.level_weights.copy()
    else:
        weights = DEFAULT_PHASE_3.level_weights.copy()

    single_phase = PhaseConfig(
        phase=phase,
        name=f"Single-{phase.name}",
        description=f"Training only {phase.name}",
        epochs=epochs,
        warmup_epochs=2,
        level_weights=weights,
    )

    return BloomCurriculum(
        phase1_epochs=epochs if phase == CurriculumPhase.PHASE_1 else 0,
        phase2_epochs=epochs if phase == CurriculumPhase.PHASE_2 else 0,
        phase3_epochs=epochs if phase == CurriculumPhase.PHASE_3 else 0,
        custom_phases=[single_phase],
    )


# =============================================================================
# Curriculum Visualization
# =============================================================================

def visualize_curriculum(
    curriculum: BloomCurriculum,
    epochs: Optional[int] = None,
) -> str:
    """
    Create ASCII visualization of curriculum.

    Returns string showing weight progression across epochs.
    """
    epochs = epochs or curriculum.total_epochs
    lines = []

    lines.append("Bloom Curriculum Weights Over Training")
    lines.append("=" * 60)
    lines.append("")

    # Header
    lines.append(f"{'Epoch':<8}{'Phase':<12}{'Remember':<10}{'Analyze':<10}{'Evaluate':<10}{'Create':<10}")
    lines.append("-" * 60)

    # Sample every few epochs
    step = max(1, epochs // 20)
    for epoch in range(0, epochs, step):
        weights = curriculum.get_weights(epoch)
        phase = weights.phase.name.replace('PHASE_', 'P')

        lines.append(
            f"{epoch:<8}{phase:<12}"
            f"{weights.remember:<10.2f}{weights.analyze:<10.2f}"
            f"{weights.evaluate:<10.2f}{weights.create:<10.2f}"
        )

    lines.append("-" * 60)

    # Phase boundaries
    lines.append("")
    lines.append("Phase Boundaries:")
    for i, (start, end) in enumerate(curriculum.phase_boundaries):
        config = curriculum.phases[i]
        lines.append(f"  {config.name}: epochs {start}-{end-1}")

    return "\n".join(lines)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Types
    'CurriculumPhase',
    'PhaseConfig',
    'LossWeights',

    # Main class
    'BloomCurriculum',

    # Factories
    'get_default_curriculum',
    'get_fast_curriculum',
    'get_gated_curriculum',
    'get_single_phase_curriculum',

    # Utilities
    'visualize_curriculum',

    # Default configs
    'DEFAULT_PHASE_1',
    'DEFAULT_PHASE_2',
    'DEFAULT_PHASE_3',
    'DEFAULT_PHASES',
]
