"""
YRSN-Context Model Registry

Provides unified model access via get_model() factory function.

Usage:
    from yrsn.models import get_model, list_models

    # Get available models
    print(list_models())  # ['hrmv', 'hrm', 'yrsn_hrm', 'hrmv_sig', ...]

    # Instantiate by name
    model = get_model("hrmv", hidden_size=64, use_rope=True)

Version: 0.5.0
"""

from typing import Dict, Any, Optional, Type, List
import torch.nn as nn

from ._common import (
    __version__,
    save_checkpoint,
    load_checkpoint,
    check_checkpoint_compatibility,
    ModelCheckpoint,
    validate_grid_size,
    VALID_GRID_SIZES,
)

# Lazy imports to avoid loading all models at package import
_MODEL_REGISTRY: Dict[str, tuple] = {
    # name: (module_path, class_name, description)
    "hrmv": ("yrsn.models.hrmv", "HRMV", "Visual HRM with regex encoder"),
    "hrm": ("yrsn.models.hrm", "SimplifiedHRM", "Simplified HRM (text-only)"),
    "yrsn_hrm": ("yrsn.models.hrm", "YRSNEnhancedHRM", "YRSN-enhanced HRM with sentence transformer + multimodal"),
    "hrmv_sig": ("yrsn.models.hrmv_sig", "HRMVSig", "HRMV with SigLIP visual encoder"),
    "simple_sudoku": ("yrsn.models.simple_sudoku", "SimpleSudokuModel", "Simple baseline model"),
    "bloom_trm": ("yrsn.models.bloom", "BloomTRM", "Bloom cognitive architecture with TRM"),
}

# Aliases for convenience
_ALIASES: Dict[str, str] = {
    "visual": "hrmv",
    "text": "hrm",
    "yrsn": "yrsn_hrm",
    "siglip": "hrmv_sig",
    "baseline": "simple_sudoku",
    "bloom": "bloom_trm",
}


def list_models() -> List[str]:
    """List all available model names."""
    return list(_MODEL_REGISTRY.keys())


def list_aliases() -> Dict[str, str]:
    """List model aliases (shorthand names)."""
    return dict(_ALIASES)


def get_model_info(name: str) -> Dict[str, str]:
    """Get info about a model by name.

    Args:
        name: Model name or alias

    Returns:
        Dict with 'module', 'class', 'description' keys

    Raises:
        ValueError: If model not found
    """
    # Resolve alias
    resolved = _ALIASES.get(name, name)

    if resolved not in _MODEL_REGISTRY:
        available = ", ".join(list_models())
        raise ValueError(f"Unknown model '{name}'. Available: {available}")

    module_path, class_name, description = _MODEL_REGISTRY[resolved]
    return {
        "name": resolved,
        "module": module_path,
        "class": class_name,
        "description": description,
    }


def get_model_class(name: str) -> Type[nn.Module]:
    """Get the model class by name (without instantiating).

    Args:
        name: Model name or alias

    Returns:
        The model class

    Raises:
        ValueError: If model not found
        ImportError: If model module can't be imported
    """
    import importlib

    info = get_model_info(name)
    module = importlib.import_module(info["module"])
    return getattr(module, info["class"])


def get_model(name: str, **kwargs) -> nn.Module:
    """Instantiate a model by name.

    Args:
        name: Model name or alias (e.g., 'hrmv', 'hrm', 'yrsn_hrm')
        **kwargs: Constructor arguments for the model

    Returns:
        Instantiated model

    Example:
        >>> model = get_model("hrmv", hidden_size=64, use_rope=True)
        >>> model = get_model("visual", hidden_size=128)  # alias for hrmv
    """
    model_class = get_model_class(name)
    return model_class(**kwargs)


def load_model(filepath: str, name: Optional[str] = None, **override_kwargs) -> nn.Module:
    """Load a model from checkpoint, auto-detecting class from metadata.

    Args:
        filepath: Path to checkpoint file
        name: Optional model name (auto-detected from checkpoint if None)
        **override_kwargs: Override config values from checkpoint

    Returns:
        Loaded model with weights

    Raises:
        ValueError: If model class can't be determined
    """
    import torch

    # Load checkpoint to get metadata
    raw = torch.load(filepath, map_location="cpu", weights_only=False)

    # Determine model class
    if name is not None:
        model_name = _ALIASES.get(name, name)
    elif isinstance(raw, dict) and "model_class" in raw:
        # Map checkpoint class to registry name
        ckpt_class = raw["model_class"]
        class_to_name = {
            "HRMV": "hrmv",
            "SimplifiedHRM": "hrm",
            "YRSNEnhancedHRM": "yrsn_hrm",
            "HRMVSig": "hrmv_sig",
            "SimpleSudokuModel": "simple_sudoku",
            "BloomTRM": "bloom_trm",
        }
        model_name = class_to_name.get(ckpt_class)
        if model_name is None:
            raise ValueError(f"Unknown checkpoint class '{ckpt_class}'")
    else:
        raise ValueError("Cannot determine model class. Provide 'name' argument.")

    # Get config from checkpoint
    config = raw.get("config", {}) if isinstance(raw, dict) else {}
    config.update(override_kwargs)

    # Create and load model
    model = get_model(model_name, **config)
    model, metadata = load_checkpoint(filepath, model, strict=False)

    return model


# ResNet for CIFAR (production module)
# Includes model AND matched data loaders to prevent mismatches
try:
    from .resnet_cifar import (
        resnet20_cifar10,
        ResNet,
        BasicBlock,
        # Data loaders matched to model
        CIFAR10_MEAN,
        CIFAR10_STD,
        get_cifar10_transform,
        load_cifar10_for_resnet20,
        create_cifar10_splits,
    )
    HAS_RESNET_CIFAR = True
except ImportError:
    HAS_RESNET_CIFAR = False
    resnet20_cifar10 = None
    ResNet = None
    BasicBlock = None
    CIFAR10_MEAN = None
    CIFAR10_STD = None
    get_cifar10_transform = None
    load_cifar10_for_resnet20 = None
    create_cifar10_splits = None

# Export public API
__all__ = [
    "__version__",
    # Factory functions
    "get_model",
    "get_model_class",
    "get_model_info",
    "load_model",
    "list_models",
    "list_aliases",
    # Checkpoint utilities
    "save_checkpoint",
    "load_checkpoint",
    "check_checkpoint_compatibility",
    "ModelCheckpoint",
    # Grid validation
    "validate_grid_size",
    "VALID_GRID_SIZES",
    # ResNet CIFAR (production)
    "resnet20_cifar10",
    "ResNet",
    "BasicBlock",
    "HAS_RESNET_CIFAR",
    # CIFAR-10 data loaders (matched to ResNet-20)
    "CIFAR10_MEAN",
    "CIFAR10_STD",
    "get_cifar10_transform",
    "load_cifar10_for_resnet20",
    "create_cifar10_splits",
]
