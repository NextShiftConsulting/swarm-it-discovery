"""
Simplified Hierarchical Reasoning Model (HRM) for Sudoku

================================================================================
IMPORTANT: This reasoner is for VARIANT SUDOKU (NOT STANDARD SUDOKU!)
================================================================================

This reasoning module processes encoded VARIANT Sudoku constraints:
- Thermometers, killer cages, arrows
- V constraints (sum to 5), X constraints (sum to 10)
- Visual overlays, underlays, region coloring

Input: Encoded variant rules + visual constraints + board state
Output: Position logits, digit logits

Features:
- RoPE (Rotary Position Embedding) for position-aware attention
- ACT (Adaptive Computation Time) head for learned halting (optional)
- SwiGLU activation and RMSNorm
================================================================================

Based on: https://github.com/sapientinc/HRM
Paper: "Hierarchical Reasoning Models for Complex Multi-Step Problems" (arXiv:2506.21734)

YRSN Simplifications:
1. Removed FlashAttention dependency (use standard PyTorch attention)
2. Removed ACT (Adaptive Computation Time) Q-learning (use fixed iteration steps)
3. Simplified embeddings (removed sparse puzzle embeddings)
4. Integrated with YRSN encoders for input

Core HRM Concept Preserved:
- Two-level hierarchy: H-level (high, abstract) and L-level (low, detailed)
- H-level updates slowly (every T steps)
- L-level updates fast (every step)
- Hierarchical convergence prevents premature convergence
"""

from typing import Tuple, Optional, Dict, Any, Union
from dataclasses import dataclass
import math

import torch
import torch.nn.functional as F
from torch import nn

# Import shared utilities from _common
from ._common import (
    trunc_normal_init_, rms_norm, SwiGLU, RotaryPositionEmbedding,
    compute_yrsn_monitoring_metrics, __version__ as _common_version
)

__version__ = "0.5.0"


@dataclass
class HRMState:
    """State carried between HRM forward passes"""
    z_H: torch.Tensor  # High-level state [batch, seq_len, hidden_size]
    z_L: torch.Tensor  # Low-level state [batch, seq_len, hidden_size]


# Note: trunc_normal_init_, rms_norm, SwiGLU, RotaryPositionEmbedding
# are imported from ._common


class SimplifiedAttention(nn.Module):
    """Multi-head attention with optional RoPE position encoding."""

    def __init__(self, hidden_size: int, num_heads: int, causal: bool = False,
                 use_rope: bool = True, max_seq_len: int = 128):
        super().__init__()
        assert hidden_size % num_heads == 0, "hidden_size must be divisible by num_heads"

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.use_rope = use_rope

        # RoPE for position encoding
        if use_rope:
            self.rope = RotaryPositionEmbedding(self.head_dim, max_seq_len)
        self.causal = causal

        # Init with LeCun normal
        init_std = 1.0 / math.sqrt(hidden_size)

        self.qkv_proj = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        self.out_proj = nn.Linear(hidden_size, hidden_size, bias=False)

        # Initialize
        with torch.no_grad():
            trunc_normal_init_(self.qkv_proj.weight, std=init_std)
            trunc_normal_init_(self.out_proj.weight, std=init_std / math.sqrt(num_heads))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, seq_len, _ = x.shape

        # QKV projection
        qkv = self.qkv_proj(x)
        qkv = qkv.reshape(batch_size, seq_len, 3, self.num_heads, self.head_dim)

        # Apply RoPE BEFORE transpose (like HRM reference)
        # qkv shape here: [batch, seq_len, 3, num_heads, head_dim]
        if self.use_rope:
            q = qkv[:, :, 0]  # [batch, seq_len, num_heads, head_dim]
            k = qkv[:, :, 1]
            v = qkv[:, :, 2]
            q = self.rope(q)
            k = self.rope(k)
            # Transpose to [batch, num_heads, seq_len, head_dim]
            q = q.transpose(1, 2)
            k = k.transpose(1, 2)
            v = v.transpose(1, 2)
        else:
            qkv = qkv.permute(2, 0, 3, 1, 4)  # [3, batch, num_heads, seq_len, head_dim]
            q, k, v = qkv[0], qkv[1], qkv[2]

        # Use PyTorch's SDPA - 2-4x faster than manual attention
        # SDPA automatically picks Flash/Memory-efficient/Math backend
        attn_output = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=None,
            dropout_p=0.0,
            is_causal=self.causal
        )

        # Reshape and project
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(batch_size, seq_len, self.hidden_size)
        output = self.out_proj(attn_output)

        return output


class HRMBlock(nn.Module):
    """Single HRM transformer block with post-norm"""

    def __init__(self, hidden_size: int, num_heads: int, expansion: float = 4.0,
                 rms_norm_eps: float = 1e-5, causal: bool = False):
        super().__init__()

        self.self_attn = SimplifiedAttention(hidden_size, num_heads, causal)
        self.mlp = SwiGLU(hidden_size, expansion)
        self.norm_eps = rms_norm_eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Post-norm (HRM style)
        # Self-attention with residual + norm
        x = rms_norm(x + self.self_attn(x), eps=self.norm_eps)
        # MLP with residual + norm
        x = rms_norm(x + self.mlp(x), eps=self.norm_eps)
        return x


class HRMReasoningModule(nn.Module):
    """Stack of HRM blocks forming one reasoning level with optional ACT head"""

    def __init__(self, num_layers: int, hidden_size: int, num_heads: int,
                 expansion: float = 4.0, rms_norm_eps: float = 1e-5,
                 use_act: bool = True):
        super().__init__()

        self.layers = nn.ModuleList([
            HRMBlock(hidden_size, num_heads, expansion, rms_norm_eps)
            for _ in range(num_layers)
        ])

        # ACT halting head (Q-values for continue vs halt)
        self.use_act = use_act
        if use_act:
            self.q_act_head = nn.Linear(hidden_size, 2)
            nn.init.zeros_(self.q_act_head.weight)
            nn.init.zeros_(self.q_act_head.bias)

    def forward(self, hidden_states: torch.Tensor, input_injection: torch.Tensor):
        """
        Args:
            hidden_states: Current state [batch, seq_len, hidden_size]
            input_injection: Input to inject (add) [batch, seq_len, hidden_size]

        Returns:
            x: Updated hidden states [batch, seq_len, hidden_size]
            q_act_halt: Halt Q-value [batch] (if use_act)
            q_act_continue: Continue Q-value [batch] (if use_act)
        """
        # Input injection (add)
        x = hidden_states + input_injection

        # Forward through layers
        for layer in self.layers:
            x = layer(x)

        # ACT: Compute Q-values from CLS token (first position)
        if self.use_act:
            q_act_logits = self.q_act_head(x[:, 0])
            q_act_halt = q_act_logits[:, 0]
            q_act_continue = q_act_logits[:, 1]
            return x, q_act_halt, q_act_continue

        return x


class StitchingLayer(nn.Module):
    """
    Learned stitching layer for geometric alignment between hierarchy levels.

    Instead of naive addition (z_H + input_embeddings), learns an affine
    transform that projects concatenated inputs to a compatible geometry.

    RATIONALE (ABL-08 / RSCT Geometric Compatibility):
    ─────────────────────────────────────────────────────
    The original HRM uses additive stitching: z_L = L_level(z_L, z_H + input)

    This assumes z_H and input_embeddings share compatible geometry (can be
    meaningfully added). ABL-07 showed that even with constraint tools, LLMs
    fail because information doesn't translate to the right geometric space.

    From model stitching literature (Lenc & Vedaldi 2015, Csiszárik et al. 2021):
    - Additive stitching assumes aligned representations
    - Learned affine stitching works when source geometries differ
    - κ_interface (geometric alignment at stitch point) predicts task success

    This layer learns: stitch(z_H, input) = W @ concat(z_H, input) + b
    Initialized to approximate addition for smooth transition from baseline.

    See: ablations/abl08_hrm_geometric_compatibility_doe.md
    """

    def __init__(self, hidden_size: int, num_inputs: int = 2):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_inputs = num_inputs

        # Concat + project: [hidden * num_inputs] -> [hidden]
        self.proj = nn.Linear(hidden_size * num_inputs, hidden_size, bias=True)

        # Initialize close to mean (smooth transition from additive)
        with torch.no_grad():
            # Initialize to approximate averaging (like addition / num_inputs)
            nn.init.zeros_(self.proj.weight)
            for i in range(num_inputs):
                start = i * hidden_size
                end = (i + 1) * hidden_size
                self.proj.weight[:, start:end] = torch.eye(hidden_size) / num_inputs
            nn.init.zeros_(self.proj.bias)

    def forward(self, *inputs: torch.Tensor) -> torch.Tensor:
        """
        Stitch multiple inputs into compatible geometry.

        Args:
            *inputs: Tensors of shape [batch, seq_len, hidden_size]

        Returns:
            Stitched tensor [batch, seq_len, hidden_size]
        """
        # Concatenate along hidden dimension
        concat = torch.cat(inputs, dim=-1)  # [batch, seq_len, hidden * num_inputs]
        return self.proj(concat)  # [batch, seq_len, hidden]


class SimplifiedHRM(nn.Module):
    """
    Simplified Hierarchical Reasoning Model for YRSN integration

    Architecture (aligned with official sapientinc/HRM):
    - Two-level hierarchy: H (high-level) and L (low-level)
    - H-level: Abstract, slow updates (every H_cycles)
    - L-level: Detailed, fast updates (every L_cycles)
    - Fixed iteration steps (no ACT)
    - Outputs logits for ALL positions (not just position 0)

    For Sudoku: Input is 81 cells, output is 81 predictions (one per cell)
    Each prediction has vocab_size logits (digits 0-9 or position classes)

    Args:
        context_dim: Dimension of input context (from YRSN encoder)
        hidden_size: Hidden dimension
        num_heads: Number of attention heads
        H_layers: Number of layers in H-level module
        L_layers: Number of layers in L-level module
        H_cycles: Number of H-level iterations
        L_cycles: Number of L-level iterations per H-cycle
        expansion: MLP expansion ratio
        output_vocab_size: Size of output vocabulary (10 for digits 0-9 + empty)
        rms_norm_eps: RMS norm epsilon
        use_learned_stitching: Use learned affine stitching instead of addition
    """

    def __init__(
        self,
        context_dim: int = 64,
        hidden_size: int = 256,
        num_heads: int = 8,
        H_layers: int = 4,
        L_layers: int = 4,
        H_cycles: int = 3,
        L_cycles: int = 5,
        expansion: float = 4.0,
        output_vocab_size: int = 10,  # Changed: 10 for digits (0=empty, 1-9)
        rms_norm_eps: float = 1e-5,
        use_learned_stitching: bool = False,  # NEW: learned geometric alignment
    ):
        super().__init__()

        self.context_dim = context_dim
        self.hidden_size = hidden_size
        self.H_cycles = H_cycles
        self.L_cycles = L_cycles
        self.output_vocab_size = output_vocab_size
        self.use_learned_stitching = use_learned_stitching

        # Input projection (YRSN context -> hidden)
        self.input_proj = nn.Linear(context_dim, hidden_size)

        # Positional encoding (sinusoidal, added to input embeddings)
        self.max_seq_len = 256  # Support up to 16x16 grids
        self.pos_encoding = self._create_sinusoidal_pos_encoding(self.max_seq_len, hidden_size)

        # Reasoning modules (use_act=False for backwards compatibility - architecture only)
        self.H_level = HRMReasoningModule(H_layers, hidden_size, num_heads, expansion, rms_norm_eps, use_act=False)
        self.L_level = HRMReasoningModule(L_layers, hidden_size, num_heads, expansion, rms_norm_eps, use_act=False)

        # Learned stitching layers (NEW)
        if use_learned_stitching:
            # H→L stitching: combines z_H + input_embeddings + pos_enc
            self.stitch_H_to_L = StitchingLayer(hidden_size, num_inputs=3)
            # L→H stitching: combines z_L + pos_enc
            self.stitch_L_to_H = StitchingLayer(hidden_size, num_inputs=2)

        # Initial states (learnable)
        self.H_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))
        self.L_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))

        # Single LM head for all positions (like official HRM)
        # Outputs [batch, seq_len, vocab_size] - prediction for each cell
        self.lm_head = nn.Linear(hidden_size, output_vocab_size)

        # Legacy heads for backward compatibility (deprecated)
        self.position_head = nn.Linear(hidden_size, 81)  # For old interface
        self.digit_head = nn.Linear(hidden_size, 9)  # For old interface

        # Initialize output heads
        with torch.no_grad():
            init_std = 1.0 / math.sqrt(hidden_size)
            trunc_normal_init_(self.lm_head.weight, std=init_std)
            self.lm_head.bias.zero_()
            trunc_normal_init_(self.position_head.weight, std=init_std)
            self.position_head.bias.zero_()
            trunc_normal_init_(self.digit_head.weight, std=init_std)
            self.digit_head.bias.zero_()

    def _create_sinusoidal_pos_encoding(self, max_len: int, d_model: int) -> torch.Tensor:
        """Create sinusoidal positional encoding."""
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return nn.Parameter(pe, requires_grad=False)  # Fixed, not learned

    def initial_state(self, batch_size: int, seq_len: int, device: torch.device) -> HRMState:
        """Create initial state for HRM with positional differentiation."""
        # Start from learned init but add positional encoding for differentiation
        z_H_base = self.H_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1)
        z_L_base = self.L_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1)

        # Add positional encoding to make each position unique from the start
        pos_enc = self.pos_encoding[:seq_len].unsqueeze(0).to(device)  # [1, seq_len, hidden]
        z_H = z_H_base + pos_enc * 0.1  # Scale down pos encoding
        z_L = z_L_base + pos_enc * 0.1

        return HRMState(z_H=z_H, z_L=z_L)

    def forward(
        self,
        context: torch.Tensor,
        state: Optional[HRMState] = None,
        return_all_positions: bool = True
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMState]:
        """
        Forward pass with hierarchical reasoning

        Args:
            context: Input context from YRSN encoder [batch, seq_len, context_dim]
            state: Previous HRM state (optional, creates new if None)
            return_all_positions: If True, return logits for all positions (official HRM style)
                                  If False, return legacy format (position 0 only)

        Returns (if return_all_positions=True):
            all_logits: Logits for all positions [batch, seq_len, vocab_size]
            digit_logits: Same as all_logits (for compatibility)
            new_state: Updated HRM state

        Returns (if return_all_positions=False - legacy):
            position_logits: Logits for position prediction [batch, 81]
            digit_logits: Logits for digit prediction [batch, 9]
            new_state: Updated HRM state
        """
        batch_size, seq_len, _ = context.shape
        device = context.device

        # Initialize state if not provided
        if state is None:
            state = self.initial_state(batch_size, seq_len, device)

        # Project input context and add positional encoding
        input_embeddings = self.input_proj(context)
        pos_enc = self.pos_encoding[:seq_len].unsqueeze(0).to(device)
        input_embeddings = input_embeddings + pos_enc  # Add strong positional signal

        # Get initial states
        z_H = state.z_H
        z_L = state.z_L

        # Hierarchical reasoning iterations
        # Full gradient flow for training (can optimize later with gradient checkpointing)
        for h_step in range(self.H_cycles):
            for l_step in range(self.L_cycles):
                # L-level: input = H-level state + input embeddings
                if self.use_learned_stitching:
                    # Learned geometric alignment (better for mismatched geometries)
                    l_input = self.stitch_H_to_L(z_H, input_embeddings, pos_enc * 0.5)
                else:
                    # Additive stitching (original, assumes compatible geometries)
                    l_input = z_H + input_embeddings + pos_enc * 0.5
                z_L = self.L_level(z_L, l_input)

            # H-level: input = L-level state + positional info
            if self.use_learned_stitching:
                h_input = self.stitch_L_to_H(z_L, pos_enc * 0.5)
            else:
                h_input = z_L + pos_enc * 0.5
            z_H = self.H_level(z_H, h_input)

        # Create new state (detached for next iteration)
        new_state = HRMState(z_H=z_H.detach(), z_L=z_L.detach())

        if return_all_positions:
            # Official HRM style: output logits for ALL positions
            # [batch, seq_len, vocab_size] - each position gets a prediction
            all_logits = self.lm_head(z_H)  # [batch, seq_len, vocab_size]
            return all_logits, all_logits, new_state
        else:
            # Legacy mode: only use position 0 (deprecated, kept for compatibility)
            output_repr = z_H[:, 0, :]  # [batch, hidden_size]
            position_logits = self.position_head(output_repr)  # [batch, 81]
            digit_logits = self.digit_head(output_repr)  # [batch, 9]
            return position_logits, digit_logits, new_state


class YRSNProjectionHeads(nn.Module):
    """
    Quality-aware projection heads for R/S/N subspaces.
    
    Projects hidden states to three quality subspaces:
    - R (Relevant): Low-rank, semantically meaningful
    - S (Superfluous): Sparse, structured but non-essential
    - N (Noise): Unstructured stochastic component
    
    Adapted from research innovations for production use.
    
    Note: Both collapse detection approaches (from explicit R/S/N values and from
    latent states) use the same detect_collapse() function. The difference is where
    the R/S/N values come from. The latent-state version (this class) is the newer
    approach that works directly on neural representations without text decoding.
    """
    
    def __init__(
        self,
        hidden_dim: int,
        projection_dim: Optional[int] = None,
        use_learned: bool = False,
        init_scale: float = 0.1,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.projection_dim = projection_dim or hidden_dim
        self.use_learned = use_learned
        
        if use_learned:
            self.R_head = nn.Linear(hidden_dim, self.projection_dim, bias=False)
            self.S_head = nn.Linear(hidden_dim, self.projection_dim, bias=False)
            self.N_head = nn.Linear(hidden_dim, self.projection_dim, bias=False)
            
            nn.init.normal_(self.R_head.weight, std=init_scale)
            nn.init.normal_(self.S_head.weight, std=init_scale)
            nn.init.normal_(self.N_head.weight, std=init_scale)
        else:
            self.R_head = None
            self.S_head = None
            self.N_head = None
    
    def derive_from_model(self, model: nn.Module, device: torch.device) -> None:
        """
        Derive projection heads from model weights using SVD.
        
        Uses HRM's input projection and output head weights to create
        R/S/N projections via singular value decomposition.
        """
        # Get embedding-like weights from HRM
        if hasattr(model, 'input_proj'):
            input_weight = model.input_proj.weight.detach().to(device=device, dtype=torch.float32)
        else:
            # Fallback: find first linear layer with matching input dim
            for module in model.modules():
                if isinstance(module, nn.Linear) and module.in_features == self.hidden_dim:
                    input_weight = module.weight.detach().to(device=device, dtype=torch.float32)
                    break
            else:
                raise RuntimeError("Cannot find suitable weights for projection derivation")
        
        if hasattr(model, 'lm_head'):
            output_weight = model.lm_head.weight.detach().to(device=device, dtype=torch.float32)
        else:
            # Fallback: find last linear layer
            for module in reversed(list(model.modules())):
                if isinstance(module, nn.Linear) and module.out_features < 100:
                    output_weight = module.weight.detach().to(device=device, dtype=torch.float32)
                    break
            else:
                raise RuntimeError("Cannot find suitable weights for projection derivation")
        
        # Compute base matrix (similar to latent realignment)
        # input_weight: [hidden_dim, in_features] from input_proj
        # output_weight: [vocab_size, hidden_dim] from lm_head
        # We need compatible dimensions for the matrix computation

        # Ensure we use the hidden_dim dimension for alignment
        # If output_weight is [vocab, hidden], we compute gram in hidden space
        if output_weight.shape[1] == self.hidden_dim:
            # output_weight is [vocab, hidden] - standard case
            gram = torch.matmul(output_weight.T, output_weight)  # [hidden, hidden]
            reg = 1e-5 * torch.eye(gram.shape[0], device=gram.device, dtype=gram.dtype)
            # Use input_weight directly if it's [hidden, hidden], else transpose
            if input_weight.shape[0] == self.hidden_dim and input_weight.shape[1] == self.hidden_dim:
                base_matrix = torch.linalg.solve(gram + reg, input_weight)  # [hidden, hidden]
            else:
                # Fallback: create identity-like base matrix
                base_matrix = torch.eye(self.hidden_dim, device=device, dtype=torch.float32)
        else:
            # Fallback: create identity-like base matrix when shapes don't align
            base_matrix = torch.eye(self.hidden_dim, device=device, dtype=torch.float32)
        
        # Derive R/S/N projections via SVD
        U, S, Vh = torch.linalg.svd(base_matrix, full_matrices=False)
        rank = min(128, U.shape[1])  # Use top 128 components for R
        R_proj = U[:, :rank] @ torch.diag(S[:rank]) @ Vh[:rank, :]
        
        # S: Sparse (residual after R, thresholded)
        S_residual = base_matrix - R_proj
        S_proj = torch.sign(S_residual) * torch.clamp(torch.abs(S_residual) - 0.01, min=0)
        
        # N: Noise (orthogonal complement)
        N_proj = base_matrix - R_proj - S_proj
        
        # Create linear layers
        self.R_head = nn.Linear(self.hidden_dim, self.projection_dim, bias=False)
        self.S_head = nn.Linear(self.hidden_dim, self.projection_dim, bias=False)
        self.N_head = nn.Linear(self.hidden_dim, self.projection_dim, bias=False)
        
        # Set weights (truncate/pad as needed)
        def pad_or_truncate(weight, target_dim, source_dim):
            if weight.shape[0] >= target_dim:
                return weight[:target_dim, :source_dim]
            else:
                padding = torch.zeros(target_dim - weight.shape[0], source_dim, device=device)
                return torch.cat([weight, padding], dim=0)
        
        R_weight = pad_or_truncate(R_proj, self.projection_dim, self.hidden_dim)
        S_weight = pad_or_truncate(S_proj, self.projection_dim, self.hidden_dim)
        N_weight = pad_or_truncate(N_proj, self.projection_dim, self.hidden_dim)
        
        self.R_head.weight.data = R_weight.to(self.R_head.weight.dtype)
        self.S_head.weight.data = S_weight.to(self.S_head.weight.dtype)
        self.N_head.weight.data = N_weight.to(self.N_head.weight.dtype)
        
        self.R_head.to(device)
        self.S_head.to(device)
        self.N_head.to(device)
    
    def forward(self, hidden: torch.Tensor, projection: str = 'all') -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Project hidden states to quality subspaces.
        
        Args:
            hidden: Hidden states [B, D] or [B, L, D]
            projection: Which projection to return ('R', 'S', 'N', 'all')
        
        Returns:
            Projected tensor(s) in same shape as input
        """
        if self.R_head is None:
            raise RuntimeError("Projection heads not initialized. Call derive_from_model() first.")
        
        # Handle sequence dimension
        is_sequence = hidden.dim() == 3
        if is_sequence:
            B, L, D = hidden.shape
            hidden = hidden.view(B * L, D)
        
        # Project to subspaces
        R_proj = self.R_head(hidden)
        S_proj = self.S_head(hidden)
        N_proj = self.N_head(hidden)
        
        # Reshape if sequence
        if is_sequence:
            R_proj = R_proj.view(B, L, -1)
            S_proj = S_proj.view(B, L, -1)
            N_proj = N_proj.view(B, L, -1)
        
        # Return requested projection
        if projection == 'R':
            return R_proj
        elif projection == 'S':
            return S_proj
        elif projection == 'N':
            return N_proj
        else:  # 'all'
            return {'R': R_proj, 'S': S_proj, 'N': N_proj}
    
    def compute_yrsn_metrics(self, hidden: torch.Tensor, normalize: bool = True) -> Dict[str, Any]:
        """
        Compute YRSN metrics from hidden states.
        
        Projects hidden states to R/S/N subspaces, computes component strengths,
        and detects collapse using the standard detect_collapse() function.
        
        Note: Both collapse detection approaches (from explicit R/S/N values and from
        latent states) use the same detect_collapse() function. The difference is where
        the R/S/N values come from. The latent-state version (this method) is the newer
        approach that works directly on neural representations without text decoding.
        
        Args:
            hidden: Hidden states [B, D] or [B, L, D]
            normalize: Normalize R+S+N to sum to 1.0
        
        Returns:
            Dict with R, S, N, y_score, collapse_risk, collapse_analysis
        """
        # Project to all subspaces
        projections = self.forward(hidden, projection='all')
        
        # Compute component strengths (L2 norm of projections)
        R_strength = projections['R'].norm(dim=-1).mean().item()
        S_strength = projections['S'].norm(dim=-1).mean().item()
        N_strength = projections['N'].norm(dim=-1).mean().item()
        
        # Normalize if requested
        if normalize:
            total = R_strength + S_strength + N_strength
            if total > 0:
                R_strength /= total
                S_strength /= total
                N_strength /= total
        
        # Compute derived metrics
        y_score = R_strength + 0.5 * S_strength
        collapse_risk = S_strength + 1.5 * N_strength
        
        # Detect collapse (lazy import to avoid circular dependency)
        from yrsn.core.decomposition.collapse import detect_collapse
        collapse_analysis = detect_collapse(
            R=R_strength,
            S=S_strength,
            N=N_strength
        )
        
        return {
            'R': R_strength,
            'S': S_strength,
            'N': N_strength,
            'y_score': y_score,
            'collapse_risk': collapse_risk,
            'collapse_type': collapse_analysis.collapse_type,
            'collapse_severity': collapse_analysis.severity,
            'collapse_analysis': collapse_analysis,
        }


class YRSNEnhancedHRM(nn.Module):
    """
    HRM with YRSN context encoding

    Combines:
    - YRSN encoders (rules, visual, board, task) - provided by caller
    - Simplified HRM architecture (aligned with official sapientinc/HRM)
    - Self-calibration support

    Output modes:
    - return_all_positions=True: Returns [batch, seq_len, vocab_size] for all cells
    - return_all_positions=False: Returns legacy format (position_logits, digit_logits)

    Encoder Protocol:
        The encoder must implement an `encode()` method that returns a dict with
        'combined_encoding' key containing a torch.Tensor of shape [seq_len, context_dim].

        Example from yrsn-sudoku:
            from yrsn_sudoku.encoders import IntegratedRulesAndConstraintsEncoder
            encoder = IntegratedRulesAndConstraintsEncoder(context_dim=64)
            model = YRSNEnhancedHRM(encoder=encoder, context_dim=64)
    """

    def __init__(
        self,
        # Encoder (optional - provided by application, e.g., yrsn-sudoku)
        encoder: Optional[nn.Module] = None,
        # YRSN encoder params
        context_dim: int = 64,
        # HRM params
        hidden_size: int = 256,
        num_heads: int = 8,
        H_layers: int = 4,
        L_layers: int = 4,
        H_cycles: int = 3,
        L_cycles: int = 5,
        expansion: float = 4.0,
        output_vocab_size: int = 10,  # 10 for digits (0=empty, 1-9)
        # YRSN projection heads
        use_yrsn_projections: bool = True,
        # ABL-08: Learned geometric stitching between H and L levels
        use_learned_stitching: bool = False,
    ):
        super().__init__()

        # Store encoder (provided by application layer, e.g., yrsn-sudoku)
        # If None, encode() and text-based forward() will raise an error
        self.encoder = encoder
        self.context_dim = context_dim
        self.use_learned_stitching = use_learned_stitching

        # HRM model (ABL-08: pass through learned stitching option)
        self.hrm = SimplifiedHRM(
            context_dim=context_dim,
            hidden_size=hidden_size,
            num_heads=num_heads,
            H_layers=H_layers,
            L_layers=L_layers,
            H_cycles=H_cycles,
            L_cycles=L_cycles,
            expansion=expansion,
            output_vocab_size=output_vocab_size,
            use_learned_stitching=use_learned_stitching,  # ABL-08
        )
        
        # YRSN projection heads for quality-aware reasoning (NEW)
        self.use_yrsn_projections = use_yrsn_projections
        if use_yrsn_projections:
            self.H_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False  # Derive from model weights
            )
            self.L_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False
            )
            # Will be initialized on first forward pass
            self._projections_initialized = False

    def encode(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int,
        task_description: str = "Find the next logical deduction"
    ) -> torch.Tensor:
        """Encode puzzle using YRSN encoder.

        Requires an encoder to be provided at construction time.
        Install yrsn-sudoku for the IntegratedRulesAndConstraintsEncoder.
        """
        if self.encoder is None:
            raise RuntimeError(
                "YRSNEnhancedHRM.encode() requires an encoder. "
                "Install yrsn-sudoku and provide encoder at construction:\n"
                "  from yrsn_sudoku.encoders import IntegratedRulesAndConstraintsEncoder\n"
                "  encoder = IntegratedRulesAndConstraintsEncoder(context_dim=64)\n"
                "  model = YRSNEnhancedHRM(encoder=encoder, context_dim=64)\n"
                "Or use SimplifiedHRM.forward(context) directly with pre-encoded context."
            )
        encoding = self.encoder.encode(
            rules_text=rules_text,
            visual_elements_str=visual_elements_str,
            board_state=board_state,
            rows=rows,
            cols=cols,
            task_description=task_description
        )
        return encoding['combined_encoding']

    def _initialize_projections(self, device: torch.device):
        """Initialize projection heads from HRM weights (lazy initialization)."""
        if not self._projections_initialized:
            self.H_projection_heads.derive_from_model(self.hrm, device)
            self.L_projection_heads.derive_from_model(self.hrm, device)
            self._projections_initialized = True
    
    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int,
        task_description: str = "Find the next logical deduction",
        state: Optional[HRMState] = None,
        return_all_positions: bool = False,  # Default False for backward compatibility
        return_yrsn_metrics: bool = True,  # Default True: Enable quality monitoring by default
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMState, Optional[Dict[str, Any]]]:
        """
        Full forward pass: YRSN encoding + HRM reasoning + YRSN quality metrics

        Args:
            return_all_positions: If True, return logits for all positions (official HRM style)
            return_yrsn_metrics: If True, return YRSN metrics from hidden states (default: True).
                Set to False to disable quality monitoring and save ~5-10% computation.

        Returns:
            logits1: Logits (format depends on return_all_positions)
            logits2: Logits (format depends on return_all_positions)
            new_state: Updated HRM state
            yrsn_metrics: Dict with H and L level metrics, collapse detection (None if return_yrsn_metrics=False)
                - 'H_level': Dict with R, S, N, y_score, collapse_risk, collapse_type, collapse_analysis
                - 'L_level': Dict with R, S, N, y_score, collapse_risk, collapse_type, collapse_analysis
                - 'collapse_detected': bool indicating if collapse was detected
        """
        device = next(self.parameters()).device
        
        # Initialize projections if needed (lazy initialization)
        if self.use_yrsn_projections:
            self._initialize_projections(device)
        
        # YRSN encoding
        context = self.encode(rules_text, visual_elements_str, board_state, rows, cols, task_description)

        # Add batch dimension if needed
        if context.dim() == 2:
            context = context.unsqueeze(0)

        # HRM reasoning
        logits1, logits2, new_state = self.hrm(context, state, return_all_positions=return_all_positions)
        
        # Compute YRSN metrics from hidden states (NEW)
        yrsn_metrics = None
        if self.use_yrsn_projections and return_yrsn_metrics:
            # Get hidden states from HRM state
            z_H = new_state.z_H  # [batch, seq_len, hidden_size]
            z_L = new_state.z_L  # [batch, seq_len, hidden_size]
            
            # Use shared utility to compute metrics (avoids code drift)
            yrsn_metrics = compute_yrsn_monitoring_metrics(
                self.H_projection_heads, self.L_projection_heads, z_H, z_L
            )
        
        # Backward compatible return (if not requesting metrics)
        if not return_yrsn_metrics:
            return logits1, logits2, new_state, None
        else:
            return logits1, logits2, new_state, yrsn_metrics
