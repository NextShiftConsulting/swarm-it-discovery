"""
Simple VAE and GAN for Generating Collapse Data
================================================

These models are intentionally simple - their purpose is to generate
real examples of posterior collapse (VAE) and mode collapse (GAN)
for the YRSN collapse taxonomy evaluation.

Usage:
    from yrsn.models.collapse_generators import (
        SimpleVAE, SimpleGAN,
        train_vae_with_collapse,
        train_gan_with_mode_collapse,
    )

    # Posterior collapse
    vae, collapsed_latents = train_vae_with_collapse(cifar_loader, beta=0.0001)

    # Mode collapse
    gan, collapsed_outputs = train_gan_with_mode_collapse(cifar_loader, epochs=3)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
import numpy as np
from typing import Tuple, Optional
from pathlib import Path


# =============================================================================
# Simple VAE for Posterior Collapse
# =============================================================================

class SimpleVAE(nn.Module):
    """
    Simple VAE for CIFAR-10 that can exhibit posterior collapse.

    Posterior collapse occurs when:
    - KL divergence → 0
    - Latent z ≈ prior N(0,1) regardless of input
    - Decoder ignores z, reconstruction relies only on decoder capacity

    Induced by: setting beta (KL weight) very low (e.g., 0.0001)
    """

    def __init__(self, latent_dim: int = 64, hidden_dim: int = 256):
        super().__init__()
        self.latent_dim = latent_dim

        # Encoder: image → (mu, logvar)
        self.encoder = nn.Sequential(
            nn.Conv2d(3, 32, 4, 2, 1),   # 32x32 → 16x16
            nn.ReLU(),
            nn.Conv2d(32, 64, 4, 2, 1),  # 16x16 → 8x8
            nn.ReLU(),
            nn.Conv2d(64, 128, 4, 2, 1), # 8x8 → 4x4
            nn.ReLU(),
            nn.Flatten(),
        )
        self.fc_mu = nn.Linear(128 * 4 * 4, latent_dim)
        self.fc_logvar = nn.Linear(128 * 4 * 4, latent_dim)

        # Decoder: z → image
        self.fc_decode = nn.Linear(latent_dim, 128 * 4 * 4)
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(128, 64, 4, 2, 1),  # 4x4 → 8x8
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),   # 8x8 → 16x16
            nn.ReLU(),
            nn.ConvTranspose2d(32, 3, 4, 2, 1),    # 16x16 → 32x32
            nn.Sigmoid(),
        )

    def encode(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Encode image to latent distribution parameters."""
        h = self.encoder(x)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        """Reparameterization trick: z = mu + std * eps."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z: torch.Tensor) -> torch.Tensor:
        """Decode latent to image."""
        h = self.fc_decode(z)
        h = h.view(-1, 128, 4, 4)
        return self.decoder(h)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Forward pass returning (reconstruction, mu, logvar)."""
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decode(z)
        return recon, mu, logvar

    def get_latent(self, x: torch.Tensor) -> torch.Tensor:
        """Get latent representation (mu) for input."""
        mu, _ = self.encode(x)
        return mu


def vae_loss(recon: torch.Tensor, x: torch.Tensor,
             mu: torch.Tensor, logvar: torch.Tensor,
             beta: float = 1.0) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    VAE loss = Reconstruction + beta * KL divergence.

    Low beta → posterior collapse (KL term ignored, z becomes uninformative)
    """
    # Reconstruction loss (MSE)
    recon_loss = F.mse_loss(recon, x, reduction='sum') / x.size(0)

    # KL divergence: -0.5 * sum(1 + logvar - mu^2 - exp(logvar))
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / x.size(0)

    total_loss = recon_loss + beta * kl_loss
    return total_loss, recon_loss, kl_loss


def train_vae_with_collapse(
    dataloader: DataLoader,
    beta: float = 0.0001,
    epochs: int = 10,
    latent_dim: int = 64,
    device: Optional[torch.device] = None,
    verbose: bool = True,
) -> Tuple[SimpleVAE, np.ndarray]:
    """
    Train VAE with low beta to induce posterior collapse.

    Args:
        dataloader: CIFAR-10 dataloader
        beta: KL weight (low = collapse). Default 0.0001 induces collapse.
        epochs: Training epochs
        latent_dim: Latent dimension
        device: torch device
        verbose: Print progress

    Returns:
        (trained_vae, collapsed_latents)
        - collapsed_latents: (N, latent_dim) array of collapsed representations
    """
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    vae = SimpleVAE(latent_dim=latent_dim).to(device)
    optimizer = torch.optim.Adam(vae.parameters(), lr=1e-3)

    if verbose:
        print(f"Training VAE with beta={beta} (low beta → posterior collapse)")

    for epoch in range(epochs):
        total_loss = 0
        total_kl = 0
        n_batches = 0

        for images, _ in dataloader:
            images = images.to(device)
            # Normalize to [0, 1] for VAE
            images = (images - images.min()) / (images.max() - images.min() + 1e-8)

            optimizer.zero_grad()
            recon, mu, logvar = vae(images)
            loss, recon_loss, kl_loss = vae_loss(recon, images, mu, logvar, beta)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            total_kl += kl_loss.item()
            n_batches += 1

        if verbose:
            avg_loss = total_loss / n_batches
            avg_kl = total_kl / n_batches
            print(f"  Epoch {epoch+1}/{epochs}: loss={avg_loss:.4f}, KL={avg_kl:.4f}")

    # Extract collapsed latents
    vae.eval()
    latents = []
    with torch.no_grad():
        for images, _ in dataloader:
            images = images.to(device)
            images = (images - images.min()) / (images.max() - images.min() + 1e-8)
            mu, logvar = vae.encode(images)
            latents.append(mu.cpu().numpy())

    collapsed_latents = np.concatenate(latents, axis=0)

    if verbose:
        # Check for collapse: low variance in latents
        latent_var = np.var(collapsed_latents, axis=0).mean()
        print(f"  Latent variance: {latent_var:.6f} (low = collapsed)")

    return vae, collapsed_latents


# =============================================================================
# Simple GAN for Mode Collapse
# =============================================================================

class SimpleGenerator(nn.Module):
    """Simple generator for CIFAR-10."""

    def __init__(self, latent_dim: int = 64, hidden_dim: int = 256):
        super().__init__()
        self.latent_dim = latent_dim

        self.fc = nn.Linear(latent_dim, 128 * 4 * 4)
        self.main = nn.Sequential(
            nn.ConvTranspose2d(128, 64, 4, 2, 1),  # 4x4 → 8x8
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),   # 8x8 → 16x16
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 3, 4, 2, 1),    # 16x16 → 32x32
            nn.Tanh(),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        h = self.fc(z)
        h = h.view(-1, 128, 4, 4)
        return self.main(h)


class SimpleDiscriminator(nn.Module):
    """Simple discriminator for CIFAR-10."""

    def __init__(self):
        super().__init__()
        self.main = nn.Sequential(
            nn.Conv2d(3, 32, 4, 2, 1),   # 32x32 → 16x16
            nn.LeakyReLU(0.2),
            nn.Conv2d(32, 64, 4, 2, 1),  # 16x16 → 8x8
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2),
            nn.Conv2d(64, 128, 4, 2, 1), # 8x8 → 4x4
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2),
            nn.Flatten(),
            nn.Linear(128 * 4 * 4, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.main(x)


class SimpleGAN(nn.Module):
    """
    Simple GAN that can exhibit mode collapse.

    Mode collapse occurs when:
    - Generator produces limited variety of outputs
    - All generated samples look similar regardless of z

    Induced by: very short training, high learning rate, or unbalanced training
    """

    def __init__(self, latent_dim: int = 64):
        super().__init__()
        self.latent_dim = latent_dim
        self.generator = SimpleGenerator(latent_dim)
        self.discriminator = SimpleDiscriminator()

    def generate(self, n_samples: int, device: torch.device = None) -> torch.Tensor:
        """Generate n_samples images."""
        if device is None:
            device = next(self.parameters()).device
        z = torch.randn(n_samples, self.latent_dim, device=device)
        return self.generator(z)


def train_gan_with_mode_collapse(
    dataloader: DataLoader,
    epochs: int = 3,
    latent_dim: int = 64,
    device: Optional[torch.device] = None,
    verbose: bool = True,
) -> Tuple[SimpleGAN, np.ndarray]:
    """
    Train GAN with conditions that induce mode collapse.

    Mode collapse is induced by:
    - Very short training (epochs=3)
    - Unbalanced G/D training (train G more)
    - High learning rate

    Args:
        dataloader: CIFAR-10 dataloader
        epochs: Training epochs (low = collapse)
        latent_dim: Latent dimension
        device: torch device
        verbose: Print progress

    Returns:
        (trained_gan, collapsed_features)
        - collapsed_features: (N, feature_dim) array from collapsed generator
    """
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    gan = SimpleGAN(latent_dim=latent_dim).to(device)
    opt_g = torch.optim.Adam(gan.generator.parameters(), lr=2e-3, betas=(0.5, 0.999))
    opt_d = torch.optim.Adam(gan.discriminator.parameters(), lr=1e-4, betas=(0.5, 0.999))

    criterion = nn.BCELoss()

    if verbose:
        print(f"Training GAN for {epochs} epochs (short training → mode collapse)")

    for epoch in range(epochs):
        g_losses = []
        d_losses = []

        for images, _ in dataloader:
            batch_size = images.size(0)
            images = images.to(device)

            # Labels
            real_labels = torch.ones(batch_size, 1, device=device)
            fake_labels = torch.zeros(batch_size, 1, device=device)

            # Train Discriminator (less frequently to encourage collapse)
            if epoch == 0:  # Only train D in first epoch
                opt_d.zero_grad()
                real_output = gan.discriminator(images)
                d_real_loss = criterion(real_output, real_labels)

                z = torch.randn(batch_size, latent_dim, device=device)
                fake_images = gan.generator(z)
                fake_output = gan.discriminator(fake_images.detach())
                d_fake_loss = criterion(fake_output, fake_labels)

                d_loss = d_real_loss + d_fake_loss
                d_loss.backward()
                opt_d.step()
                d_losses.append(d_loss.item())

            # Train Generator (more aggressively)
            for _ in range(3):  # Multiple G updates per D
                opt_g.zero_grad()
                z = torch.randn(batch_size, latent_dim, device=device)
                fake_images = gan.generator(z)
                fake_output = gan.discriminator(fake_images)
                g_loss = criterion(fake_output, real_labels)
                g_loss.backward()
                opt_g.step()
                g_losses.append(g_loss.item())

        if verbose:
            avg_g = np.mean(g_losses) if g_losses else 0
            avg_d = np.mean(d_losses) if d_losses else 0
            print(f"  Epoch {epoch+1}/{epochs}: G_loss={avg_g:.4f}, D_loss={avg_d:.4f}")

    # Generate collapsed outputs
    gan.eval()
    n_samples = 500
    with torch.no_grad():
        generated = gan.generate(n_samples, device).cpu()

    # Flatten generated images as "features"
    collapsed_features = generated.view(n_samples, -1).numpy()

    if verbose:
        # Check for mode collapse: low diversity
        diversity = np.std(collapsed_features, axis=0).mean()
        print(f"  Output diversity: {diversity:.6f} (low = mode collapsed)")

    return gan, collapsed_features


# =============================================================================
# Convenience function to get both collapsed datasets
# =============================================================================

def generate_collapse_data(
    dataloader: DataLoader,
    device: Optional[torch.device] = None,
    verbose: bool = True,
) -> dict:
    """
    Generate both posterior collapse and mode collapse data.

    Args:
        dataloader: CIFAR-10 dataloader
        device: torch device
        verbose: Print progress

    Returns:
        {
            'posterior_collapse': {
                'vae': trained VAE,
                'latents': collapsed latent representations,
                'latent_variance': variance (low = collapsed),
            },
            'mode_collapse': {
                'gan': trained GAN,
                'features': collapsed generator outputs,
                'diversity': output diversity (low = collapsed),
            }
        }
    """
    if verbose:
        print("=" * 60)
        print("Generating Collapse Data for YRSN Evaluation")
        print("=" * 60)

    results = {}

    # Posterior collapse
    if verbose:
        print("\n1. POSTERIOR COLLAPSE (VAE with β → 0)")
    vae, latents = train_vae_with_collapse(
        dataloader, beta=0.0001, epochs=10, device=device, verbose=verbose
    )
    latent_var = np.var(latents, axis=0).mean()
    results['posterior_collapse'] = {
        'vae': vae,
        'latents': latents,
        'latent_variance': latent_var,
    }

    # Mode collapse
    if verbose:
        print("\n2. MODE COLLAPSE (Undertrained GAN)")
    gan, features = train_gan_with_mode_collapse(
        dataloader, epochs=3, device=device, verbose=verbose
    )
    diversity = np.std(features, axis=0).mean()
    results['mode_collapse'] = {
        'gan': gan,
        'features': features,
        'diversity': diversity,
    }

    if verbose:
        print("\n" + "=" * 60)
        print("COLLAPSE DATA GENERATED")
        print(f"  Posterior collapse latents: {latents.shape}")
        print(f"  Mode collapse features: {features.shape}")
        print("=" * 60)

    return results


__all__ = [
    'SimpleVAE',
    'SimpleGAN',
    'SimpleGenerator',
    'SimpleDiscriminator',
    'vae_loss',
    'train_vae_with_collapse',
    'train_gan_with_mode_collapse',
    'generate_collapse_data',
]
