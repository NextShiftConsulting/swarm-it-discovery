"""
HRMV-Sig: Hierarchical Reasoning Model - Vanilla with SigLIP Visual Encoding

================================================================================
REUSABLE ARCHITECTURE - Parameterized for Multiple Applications
================================================================================

Like HRMV, this is a domain-agnostic hierarchical reasoning architecture.
The SigLIP visual encoder can process any rendered visual constraints.

Parameterized for reuse:
    - num_positions: Number of positions to predict (e.g., 81 for 9x9, 36 for 6x6)
    - num_classes: Number of output classes (e.g., 9 for Sudoku digits)
    - encoder: Optional custom encoder for application-specific inputs

================================================================================

Ablation model: Original HRM architecture + SigLIP visual encoding ONLY.
NO other YRSN techniques (no boosting, no pre-trained text encoder).

Purpose: Measure SigLIP's isolated contribution to performance.

Model Hierarchy for Ablation:
┌─────────────────────────────────────────────────────────────────────┐
│ Model      │ HRM Arch │ Visual       │ Text Encoder  │ Boosting   │
├────────────┼──────────┼──────────────┼───────────────┼────────────┤
│ HRMV       │ ✓        │ Sparse       │ Learned       │ None       │
│ HRMV-Sig   │ ✓        │ SigLIP       │ Learned       │ None       │
│ YRSN-HRM   │ ✓        │ SigLIP       │ Pre-trained   │ 3.73x      │
└─────────────────────────────────────────────────────────────────────┘

Expected Performance (hypothesis):
  HRMV < HRMV-Sig < YRSN-HRM

This measures:
  - HRMV → HRMV-Sig: SigLIP contribution
  - HRMV-Sig → YRSN-HRM: YRSN techniques (boosting + pre-trained text)
"""

from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass
import math
import re

import torch
import torch.nn.functional as F
from torch import nn

# Import core HRM components from HRMV (they're the same)
from yrsn.models.hrmv import (
    HRMVState,
    trunc_normal_init_,
    rms_norm,
    SwiGLU,
    HRMAttention,
    HRMBlock,
    HRMReasoningModule,
    count_parameters
)
from yrsn.models._common import compute_yrsn_monitoring_metrics
from yrsn.models.hrm import StitchingLayer  # ABL-08: learned geometric alignment


class SigLIPVisualEncoder(nn.Module):
    """
    SigLIP visual encoder for variant Sudoku.

    Uses SigLIP to encode rendered visual constraints.
    This is the ONLY YRSN technique in HRMV-Sig.
    """

    def __init__(self, hidden_size: int = 256):
        super().__init__()

        self.hidden_size = hidden_size
        self.siglip_dim = 768  # SigLIP base output dim

        # Try to load SigLIP
        self.siglip_available = False
        try:
            from transformers import AutoProcessor, AutoModel
            self.processor = AutoProcessor.from_pretrained("google/siglip-base-patch16-224")
            self.siglip = AutoModel.from_pretrained("google/siglip-base-patch16-224")

            # Freeze SigLIP weights
            for param in self.siglip.parameters():
                param.requires_grad = False

            self.siglip_available = True
            print("  [HRMV-Sig] SigLIP loaded successfully")
        except Exception as e:
            print(f"  [HRMV-Sig] SigLIP not available: {e}")
            print("  [HRMV-Sig] Falling back to CNN encoder")

        # Projection from SigLIP dim to hidden_size
        if self.siglip_available:
            self.visual_proj = nn.Linear(self.siglip_dim, hidden_size)
        else:
            # Fallback CNN encoder
            self.cnn = nn.Sequential(
                nn.Conv2d(3, 32, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.Conv2d(32, 64, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.Conv2d(64, 128, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.AdaptiveAvgPool2d((7, 7)),
                nn.Flatten(),
                nn.Linear(128 * 7 * 7, hidden_size)
            )

        # Visual element renderer
        self.renderer = None
        try:
            from yrsn.multimodal.renderer import SudokuVisualRenderer
            self.renderer = SudokuVisualRenderer()
        except ImportError:
            pass

    def render_visual_elements(self, visual_str: str, board_size: int = 9) -> torch.Tensor:
        """Render visual elements to image tensor"""
        import json
        from PIL import Image
        import numpy as np

        # Parse visual elements
        try:
            visual_elements = json.loads(visual_str) if visual_str else []
        except json.JSONDecodeError:
            visual_elements = []

        # Use renderer if available
        if self.renderer is not None and visual_elements:
            try:
                image = self.renderer.render(visual_elements, board_size=board_size)
                # Convert to tensor
                img_array = np.array(image) / 255.0
                img_tensor = torch.tensor(img_array, dtype=torch.float32)
                if img_tensor.dim() == 2:
                    img_tensor = img_tensor.unsqueeze(-1).expand(-1, -1, 3)
                img_tensor = img_tensor.permute(2, 0, 1)  # [C, H, W]
                return img_tensor
            except Exception:
                pass

        # Fallback: blank image
        return torch.zeros(3, 224, 224)

    def forward(self, visual_str: str, board_size: int = 9) -> torch.Tensor:
        """
        Encode visual elements using SigLIP.

        Args:
            visual_str: JSON string of visual elements
            board_size: Size of the board (for rendering)

        Returns:
            visual_embedding: [hidden_size] tensor
        """
        device = next(self.parameters()).device

        # Render visual elements to image
        img_tensor = self.render_visual_elements(visual_str, board_size)
        img_tensor = img_tensor.to(device)

        if self.siglip_available:
            # Use SigLIP
            from PIL import Image
            import numpy as np

            # Convert tensor to PIL for processor
            img_np = (img_tensor.permute(1, 2, 0).cpu().numpy() * 255).astype(np.uint8)
            pil_image = Image.fromarray(img_np)

            # Process with SigLIP
            inputs = self.processor(images=pil_image, return_tensors="pt")
            inputs = {k: v.to(device) for k, v in inputs.items()}

            with torch.no_grad():
                outputs = self.siglip.get_image_features(**inputs)

            visual_embedding = self.visual_proj(outputs.squeeze(0))
        else:
            # Use fallback CNN
            img_tensor = img_tensor.unsqueeze(0)  # Add batch dim
            visual_embedding = self.cnn(img_tensor).squeeze(0)

        return visual_embedding


class SimpleTextEncoder(nn.Module):
    """
    Simple learned text encoder (NOT pre-trained).

    Same as HRMV - uses learned word embeddings, not sentence transformers.
    """

    def __init__(self, hidden_size: int = 256, vocab_size: int = 10000, max_seq_len: int = 256):
        super().__init__()

        self.hidden_size = hidden_size
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len

        # Learned word embeddings (NOT pre-trained)
        self.word_embeddings = nn.Embedding(vocab_size, hidden_size)

        # Simple vocabulary
        self._vocab: Dict[str, int] = {}

    def _tokenize(self, text: str):
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        words = text.split()

        tokens = []
        for word in words[:self.max_seq_len]:
            if word not in self._vocab:
                if len(self._vocab) < self.vocab_size - 1:
                    self._vocab[word] = len(self._vocab) + 1
            tokens.append(self._vocab.get(word, 0))

        return tokens

    def forward(self, text: str) -> torch.Tensor:
        """Encode text to embedding"""
        device = self.word_embeddings.weight.device

        tokens = self._tokenize(text)
        if len(tokens) == 0:
            tokens = [0]

        token_tensor = torch.tensor(tokens, dtype=torch.long, device=device)
        word_embeds = self.word_embeddings(token_tensor)
        text_embedding = word_embeds.mean(dim=0)  # Mean pooling

        return text_embedding


class HRMVSigEncoder(nn.Module):
    """
    Encoder for HRMV-Sig: SigLIP visual + simple text.

    Combines:
    - SigLIP for visual constraint encoding (ONLY YRSN technique)
    - Simple learned embeddings for text (NOT pre-trained)
    - One-hot for board state
    """

    def __init__(self, hidden_size: int = 256):
        super().__init__()

        self.hidden_size = hidden_size

        # SigLIP visual encoder (ONLY YRSN technique used)
        self.visual_encoder = SigLIPVisualEncoder(hidden_size)

        # Simple text encoder (NOT pre-trained)
        self.text_encoder = SimpleTextEncoder(hidden_size)

        # Board state encoder
        self.cell_embeddings = nn.Embedding(11, hidden_size)  # 0-9 + empty

        # Positional encoding
        self.max_seq_len = 256
        self.pos_encoding = self._create_sinusoidal_pos_encoding(self.max_seq_len, hidden_size)

        # Combine all inputs
        self.fusion = nn.Linear(hidden_size * 3, hidden_size)

    def _create_sinusoidal_pos_encoding(self, max_len: int, d_model: int) -> torch.Tensor:
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return nn.Parameter(pe, requires_grad=False)

    def _parse_board(self, board_state: str, num_cells: int) -> torch.Tensor:
        cells = []
        for char in board_state:
            if char == '.':
                cells.append(10)
            elif char.isdigit():
                cells.append(int(char))

        if len(cells) < num_cells:
            cells.extend([10] * (num_cells - len(cells)))
        elif len(cells) > num_cells:
            cells = cells[:num_cells]

        return torch.tensor(cells, dtype=torch.long)

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int
    ) -> torch.Tensor:
        """
        Encode variant Sudoku with SigLIP visual.

        Returns:
            context: [num_cells, hidden_size] tensor
        """
        num_cells = rows * cols
        device = self.cell_embeddings.weight.device
        board_size = max(rows, cols)

        # 1. Encode visual with SigLIP (ONLY YRSN technique)
        visual_embed = self.visual_encoder(visual_elements_str, board_size)
        visual_per_cell = visual_embed.unsqueeze(0).expand(num_cells, -1)

        # 2. Encode text with simple embeddings (NOT pre-trained)
        text_embed = self.text_encoder(rules_text)
        text_per_cell = text_embed.unsqueeze(0).expand(num_cells, -1)

        # 3. Encode board state
        board_indices = self._parse_board(board_state, num_cells).to(device)
        board_embed = self.cell_embeddings(board_indices)

        # 4. Fuse all inputs
        combined = torch.cat([visual_per_cell, text_per_cell, board_embed], dim=-1)
        context = self.fusion(combined)

        # 5. Add positional encoding
        pos_enc = self.pos_encoding[:num_cells].to(device)
        context = context + pos_enc

        return context


class HRMVSig(nn.Module):
    """
    HRMV-Sig: Hierarchical Reasoning Model - Vanilla with SigLIP Visual Encoding.

    Reusable architecture - parameterized for multiple applications.

    Ablation model that uses:
    - Original HRM architecture (Wang et al. 2506.21734)
    - SigLIP visual encoding (ONLY YRSN technique)
    - Simple learned text embeddings (NOT pre-trained)
    - NO instruction boosting
    - NO task-specific encoding

    YRSN monitoring can be enabled for passive observation of collapse
    metrics without affecting model behavior. This allows comparing R/S/N metrics
    across all model variants.

    Args:
        hidden_size: Hidden dimension
        num_heads: Number of attention heads
        H_layers: Number of H-level layers
        L_layers: Number of L-level layers
        H_cycles: Number of H-level iterations
        L_cycles: Number of L-level iterations per H-cycle
        use_yrsn_monitoring: Enable passive YRSN collapse monitoring (default False)
        num_positions: Number of positions to predict (default 81, adjustable per application)
        num_classes: Number of output classes per position (default 9, adjustable)
        encoder: Optional custom encoder module. If None, uses HRMVSigEncoder.
    """

    def __init__(
        self,
        hidden_size: int = 256,
        num_heads: int = 8,
        H_layers: int = 4,
        L_layers: int = 4,
        H_cycles: int = 3,
        L_cycles: int = 5,
        expansion: float = 4.0,
        output_vocab_size: int = 10,
        rms_norm_eps: float = 1e-5,
        use_yrsn_monitoring: bool = False,
        use_learned_stitching: bool = False,  # ABL-08: learned geometric alignment
        # Parameterized for reuse across applications
        num_positions: int = 81,
        num_classes: int = 9,
        encoder: Optional[nn.Module] = None,
    ):
        super().__init__()

        self.hidden_size = hidden_size
        self.H_cycles = H_cycles
        self.L_cycles = L_cycles
        self.output_vocab_size = output_vocab_size
        self.use_learned_stitching = use_learned_stitching
        self.num_positions = num_positions
        self.num_classes = num_classes

        # Encoder: use provided encoder or default HRMVSigEncoder
        if encoder is not None:
            self.encoder = encoder
        else:
            self.encoder = HRMVSigEncoder(hidden_size=hidden_size)

        # Original HRM reasoning modules
        self.H_level = HRMReasoningModule(H_layers, hidden_size, num_heads, expansion, rms_norm_eps)
        self.L_level = HRMReasoningModule(L_layers, hidden_size, num_heads, expansion, rms_norm_eps)

        # Learned stitching layers (ABL-08: geometric alignment at interface)
        if use_learned_stitching:
            self.stitch_H_to_L = StitchingLayer(hidden_size, num_inputs=2)
            self.stitch_L_to_H = StitchingLayer(hidden_size, num_inputs=1)

        # Learnable initial states
        self.H_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))
        self.L_init = nn.Parameter(trunc_normal_init_(torch.empty(hidden_size), std=1.0))

        # Output heads (parameterized for reuse)
        self.lm_head = nn.Linear(hidden_size, output_vocab_size)
        self.position_head = nn.Linear(hidden_size, num_positions)
        self.digit_head = nn.Linear(hidden_size, num_classes)

        # Initialize
        init_std = 1.0 / math.sqrt(hidden_size)
        with torch.no_grad():
            trunc_normal_init_(self.lm_head.weight, std=init_std)
            self.lm_head.bias.zero_()
            trunc_normal_init_(self.position_head.weight, std=init_std)
            self.position_head.bias.zero_()
            trunc_normal_init_(self.digit_head.weight, std=init_std)
            self.digit_head.bias.zero_()

        # YRSN monitoring (passive observation, does NOT affect model behavior)
        self.use_yrsn_monitoring = use_yrsn_monitoring
        if use_yrsn_monitoring:
            from yrsn.models.hrm import YRSNProjectionHeads
            self.H_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False  # Derive from model weights
            )
            self.L_projection_heads = YRSNProjectionHeads(
                hidden_dim=hidden_size,
                use_learned=False
            )
            self._projections_initialized = False

    def _initialize_projections(self, device: torch.device):
        """Initialize projection heads from model weights (lazy initialization)."""
        if self.use_yrsn_monitoring and not self._projections_initialized:
            self.H_projection_heads.derive_from_model(self, device)
            self.L_projection_heads.derive_from_model(self, device)
            self._projections_initialized = True

    def initial_state(self, batch_size: int, seq_len: int, device: torch.device) -> HRMVState:
        z_H = self.H_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1).clone()
        z_L = self.L_init.unsqueeze(0).unsqueeze(0).expand(batch_size, seq_len, -1).clone()
        return HRMVState(z_H=z_H, z_L=z_L)

    def forward(
        self,
        rules_text: str,
        visual_elements_str: str,
        board_state: str,
        rows: int,
        cols: int,
        state: Optional[HRMVState] = None,
        return_all_positions: bool = False,
        return_yrsn_metrics: bool = False
    ) -> Tuple[torch.Tensor, torch.Tensor, HRMVState, Optional[Dict[str, Any]]]:
        """Forward pass with hierarchical reasoning.

        Args:
            rules_text: Puzzle rules as text
            visual_elements_str: Visual elements as JSON string
            board_state: Board state as string
            rows: Number of rows
            cols: Number of columns
            state: Previous state (optional)
            return_all_positions: If True, return logits for all positions
            return_yrsn_metrics: If True and use_yrsn_monitoring=True, return YRSN metrics

        Returns:
            position_logits or all_logits: Prediction logits
            digit_logits or all_logits: Digit logits
            new_state: Updated state
            yrsn_metrics: YRSN metrics dict if monitoring enabled and requested, else None
        """
        # Encode with SigLIP visual
        context = self.encoder(rules_text, visual_elements_str, board_state, rows, cols)

        if context.dim() == 2:
            context = context.unsqueeze(0)

        batch_size, seq_len, _ = context.shape
        device = context.device

        if state is None:
            state = self.initial_state(batch_size, seq_len, device)

        z_H = state.z_H
        z_L = state.z_L

        # Hierarchical reasoning (original HRM)
        # ABL-08: Use learned stitching if enabled for geometric alignment
        for h_step in range(self.H_cycles):
            for l_step in range(self.L_cycles):
                if self.use_learned_stitching:
                    l_input = self.stitch_H_to_L(z_H, context)
                else:
                    l_input = z_H + context  # Original additive stitching
                z_L = self.L_level(z_L, l_input)

            if self.use_learned_stitching:
                h_input = self.stitch_L_to_H(z_L)
            else:
                h_input = z_L
            z_H = self.H_level(z_H, h_input)

        new_state = HRMVState(z_H=z_H.detach(), z_L=z_L.detach())

        # Compute YRSN metrics if requested and monitoring is enabled
        yrsn_metrics = None
        if return_yrsn_metrics and self.use_yrsn_monitoring:
            # Lazy initialization of projection heads
            if not self._projections_initialized:
                self._initialize_projections(device)

            # Use shared utility to compute metrics (avoids code drift)
            yrsn_metrics = compute_yrsn_monitoring_metrics(
                self.H_projection_heads, self.L_projection_heads, z_H, z_L
            )

        if return_all_positions:
            all_logits = self.lm_head(z_H)
            return all_logits, all_logits, new_state, yrsn_metrics
        else:
            output_repr = z_H.mean(dim=1)
            position_logits = self.position_head(output_repr)
            digit_logits = self.digit_head(output_repr)
            return position_logits, digit_logits, new_state, yrsn_metrics


def compare_ablation_models():
    """Print comparison of ablation models"""
    print("=" * 70)
    print("HRM Ablation Model Comparison")
    print("=" * 70)
    print()
    print("┌─────────────────────────────────────────────────────────────────────┐")
    print("│ Model      │ HRM Arch │ Visual       │ Text Encoder  │ Boosting   │")
    print("├────────────┼──────────┼──────────────┼───────────────┼────────────┤")
    print("│ HRMV       │ ✓        │ Sparse       │ Learned       │ None       │")
    print("│ HRMV-Sig   │ ✓        │ SigLIP       │ Learned       │ None       │")
    print("│ YRSN-HRM   │ ✓        │ SigLIP       │ Pre-trained   │ 3.73x      │")
    print("└─────────────────────────────────────────────────────────────────────┘")
    print()
    print("Ablation Analysis:")
    print("  HRMV → HRMV-Sig:    Measures SigLIP visual contribution")
    print("  HRMV-Sig → YRSN-HRM: Measures other YRSN techniques")
    print()

    # Count parameters
    from yrsn.models.hrmv import HRMV
    hrmv = HRMV(hidden_size=64, H_layers=2, L_layers=2)
    print(f"HRMV Parameters: {count_parameters(hrmv):,}")

    hrmv_sig = HRMVSig(hidden_size=64, H_layers=2, L_layers=2)
    print(f"HRMV-Sig Parameters: {count_parameters(hrmv_sig):,}")

    try:
        from yrsn.models.hrm import YRSNEnhancedHRM
        yrsn_hrm = YRSNEnhancedHRM(hidden_size=64, H_layers=2, L_layers=2)
        print(f"YRSN-HRM Parameters: {count_parameters(yrsn_hrm):,}")
    except ImportError:
        print("YRSN-HRM: (import failed)")

    print("=" * 70)


if __name__ == "__main__":
    compare_ablation_models()

    print("\nQuick HRMV-Sig test:")
    model = HRMVSig(hidden_size=64, H_layers=2, L_layers=2, H_cycles=2, L_cycles=3)
    print(f"  Parameters: {count_parameters(model):,}")

    pos_logits, digit_logits, state, _ = model(
        rules_text="Normal sudoku rules. Digits on a V sum to 5.",
        visual_elements_str='[{"type": "cage", "cells": ["r1c1", "r1c2"], "value": 5}]',
        board_state="." * 81,
        rows=9,
        cols=9
    )

    print(f"  Position logits shape: {pos_logits.shape}")
    print(f"  Digit logits shape: {digit_logits.shape}")
    print("  HRMV-Sig working correctly!")
