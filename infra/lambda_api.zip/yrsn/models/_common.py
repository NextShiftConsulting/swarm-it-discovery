"""
Common utilities for HRM-family models.

This module contains shared building blocks used across multiple model files.
Model-specific components (attention variants, state classes) stay in their files.

Version: 0.5.0
"""
import math
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Tuple, Dict, Any, Optional, List
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


__version__ = "0.5.0"


def trunc_normal_init_(
    tensor: torch.Tensor,
    std: float = 1.0,
    lower: float = -2.0,
    upper: float = 2.0
) -> torch.Tensor:
    """Truncated normal initialization (from JAX/HRM reference).

    Args:
        tensor: Tensor to initialize in-place
        std: Standard deviation of the normal distribution
        lower: Lower truncation bound (in std units)
        upper: Upper truncation bound (in std units)

    Returns:
        The initialized tensor
    """
    with torch.no_grad():
        if std == 0:
            tensor.zero_()
        else:
            sqrt2 = math.sqrt(2)
            a = math.erf(lower / sqrt2)
            b = math.erf(upper / sqrt2)
            z = (b - a) / 2

            c = (2 * math.pi) ** -0.5
            pdf_u = c * math.exp(-0.5 * upper ** 2)
            pdf_l = c * math.exp(-0.5 * lower ** 2)
            comp_std = std / math.sqrt(
                1 - (upper * pdf_u - lower * pdf_l) / z - ((pdf_u - pdf_l) / z) ** 2
            )

            tensor.uniform_(a, b)
            tensor.erfinv_()
            tensor.mul_(sqrt2 * comp_std)
            tensor.clip_(lower * comp_std, upper * comp_std)
    return tensor


def rms_norm(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """RMS Normalization (from HRM reference).

    Args:
        x: Input tensor [..., dim]
        eps: Small constant for numerical stability

    Returns:
        Normalized tensor with same shape
    """
    return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + eps)


class SwiGLU(nn.Module):
    """SwiGLU activation function (from HRM reference).

    SwiGLU(x) = (Swish(xW1) ⊙ xW3)W2

    Uses truncated normal initialization for stable training.
    """

    def __init__(self, hidden_size: int, expansion: float = 4.0):
        super().__init__()
        intermediate_size = int(hidden_size * expansion)
        init_std = 1.0 / math.sqrt(hidden_size)

        self.w1 = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.w2 = nn.Linear(intermediate_size, hidden_size, bias=False)
        self.w3 = nn.Linear(hidden_size, intermediate_size, bias=False)

        with torch.no_grad():
            trunc_normal_init_(self.w1.weight, std=init_std)
            trunc_normal_init_(self.w2.weight, std=init_std / math.sqrt(expansion))
            trunc_normal_init_(self.w3.weight, std=init_std)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class RotaryPositionEmbedding(nn.Module):
    """Rotary Position Embedding (RoPE) from HRM reference.

    RoPE encodes position information by rotating query/key vectors,
    allowing the model to learn relative position relationships.
    """

    def __init__(self, dim: int, max_length: int = 128, base: float = 10000.0):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        t = torch.arange(max_length, dtype=torch.float32)
        freqs = torch.einsum("i,j->ij", t, inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1).unsqueeze(-2)

        self.register_buffer("cos", emb.cos())
        self.register_buffer("sin", emb.sin())

    def _rotate_half(self, x: torch.Tensor) -> torch.Tensor:
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        return torch.cat((-x2, x1), dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply rotary position embedding.

        Args:
            x: Input tensor [batch, seq_len, num_heads, head_dim]

        Returns:
            Position-encoded tensor with same shape
        """
        seq_len = x.shape[1]
        cos = self.cos[:seq_len]
        sin = self.sin[:seq_len]
        return (x * cos) + (self._rotate_half(x) * sin)


# ============================================================================
# Checkpoint Utilities
# ============================================================================

@dataclass
class ModelCheckpoint:
    """Standardized checkpoint format with metadata for compatibility tracking."""

    # Model identification
    model_class: str  # e.g., "HRMV", "SimplifiedHRM", "YRSNEnhancedHRM"
    model_version: str  # e.g., "0.5.0"

    # Architecture config (for reconstruction)
    config: Dict[str, Any]

    # Weights
    state_dict: Dict[str, torch.Tensor]

    # Training info (optional)
    epoch: Optional[int] = None
    best_metric: Optional[float] = None
    metric_name: Optional[str] = None

    # Metadata
    created_at: str = ""
    pytorch_version: str = ""
    notes: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.pytorch_version:
            self.pytorch_version = torch.__version__


def save_checkpoint(
    model: nn.Module,
    filepath: str,
    config: Dict[str, Any],
    model_class: Optional[str] = None,
    epoch: Optional[int] = None,
    best_metric: Optional[float] = None,
    metric_name: Optional[str] = None,
    notes: str = ""
) -> None:
    """Save model with standardized metadata.

    Args:
        model: Model to save
        filepath: Output path
        config: Model config dict (constructor args)
        model_class: Class name (auto-detected if None)
        epoch: Training epoch
        best_metric: Best validation metric
        metric_name: Name of the metric
        notes: Additional notes
    """
    ckpt = ModelCheckpoint(
        model_class=model_class or model.__class__.__name__,
        model_version=getattr(model, '__version__', __version__),
        config=config,
        state_dict=model.state_dict(),
        epoch=epoch,
        best_metric=best_metric,
        metric_name=metric_name,
        notes=notes
    )

    # Save as dict for torch.load compatibility
    torch.save(asdict(ckpt), filepath)


def load_checkpoint(
    filepath: str,
    model: Optional[nn.Module] = None,
    strict: bool = True,
    map_location: str = "cpu"
) -> Tuple[Optional[nn.Module], Dict[str, Any]]:
    """Load checkpoint with compatibility checking.

    Args:
        filepath: Checkpoint path
        model: Optional model to load into (if None, returns metadata only)
        strict: Strict state_dict loading
        map_location: Device mapping

    Returns:
        (model, metadata) tuple. Model is None if not provided.
    """
    raw = torch.load(filepath, map_location=map_location, weights_only=False)

    # Handle both new format (with metadata) and legacy format (state_dict only)
    if isinstance(raw, dict) and "model_class" in raw and "state_dict" in raw:
        # New format with metadata
        metadata = {k: v for k, v in raw.items() if k != "state_dict"}
        state_dict = raw["state_dict"]
    else:
        # Legacy format (just state_dict)
        metadata = {
            "model_class": "unknown",
            "model_version": "legacy",
            "config": {},
            "notes": "Legacy checkpoint without metadata"
        }
        state_dict = raw

    if model is not None:
        model.load_state_dict(state_dict, strict=strict)

    return model, metadata


def check_checkpoint_compatibility(
    filepath: str,
    model: nn.Module,
    verbose: bool = True
) -> Dict[str, Any]:
    """Check if a checkpoint is compatible with a model.

    Args:
        filepath: Checkpoint path
        model: Model to check compatibility against
        verbose: Print detailed report

    Returns:
        Compatibility report dict
    """
    raw = torch.load(filepath, map_location="cpu", weights_only=False)

    # Handle both formats
    if isinstance(raw, dict) and "state_dict" in raw:
        ckpt_state = raw["state_dict"]
        ckpt_class = raw.get("model_class", "unknown")
        ckpt_version = raw.get("model_version", "legacy")
        ckpt_config = raw.get("config", {})
    else:
        ckpt_state = raw
        ckpt_class = "unknown"
        ckpt_version = "legacy"
        ckpt_config = {}

    model_state = model.state_dict()

    # Compare keys
    ckpt_keys = set(ckpt_state.keys())
    model_keys = set(model_state.keys())

    missing_in_ckpt = model_keys - ckpt_keys
    extra_in_ckpt = ckpt_keys - model_keys
    common_keys = model_keys & ckpt_keys

    # Check shape mismatches
    shape_mismatches = []
    for key in common_keys:
        ckpt_shape = tuple(ckpt_state[key].shape)
        model_shape = tuple(model_state[key].shape)
        if ckpt_shape != model_shape:
            shape_mismatches.append({
                "key": key,
                "checkpoint": ckpt_shape,
                "model": model_shape
            })

    # Infer config from checkpoint
    inferred_config = {}
    for key, tensor in ckpt_state.items():
        if "H_init" in key:
            inferred_config["hidden_size"] = tensor.shape[0]
        if "H_level.layers" in key:
            layer_idx = int(key.split(".")[2]) if key.split(".")[2].isdigit() else 0
            inferred_config["H_layers"] = max(inferred_config.get("H_layers", 0), layer_idx + 1)
        if "L_level.layers" in key:
            layer_idx = int(key.split(".")[2]) if key.split(".")[2].isdigit() else 0
            inferred_config["L_layers"] = max(inferred_config.get("L_layers", 0), layer_idx + 1)

    # Build report
    report = {
        "filepath": str(filepath),
        "checkpoint_class": ckpt_class,
        "checkpoint_version": ckpt_version,
        "checkpoint_config": ckpt_config,
        "inferred_config": inferred_config,
        "model_class": model.__class__.__name__,
        "model_version": getattr(model, '__version__', 'unknown'),
        "compatible": len(missing_in_ckpt) == 0 and len(shape_mismatches) == 0,
        "loadable_strict": len(missing_in_ckpt) == 0 and len(extra_in_ckpt) == 0 and len(shape_mismatches) == 0,
        "missing_keys": list(missing_in_ckpt),
        "extra_keys": list(extra_in_ckpt),
        "shape_mismatches": shape_mismatches,
        "common_keys_count": len(common_keys)
    }

    if verbose:
        print("=" * 70)
        print("CHECKPOINT COMPATIBILITY REPORT")
        print("=" * 70)
        print(f"Checkpoint: {filepath}")
        print(f"  Class: {ckpt_class} (version {ckpt_version})")
        if inferred_config:
            print(f"  Inferred config: {inferred_config}")
        print(f"Model: {model.__class__.__name__}")
        print(f"  Version: {getattr(model, '__version__', 'unknown')}")
        print()
        print(f"Compatible (strict=False): {'YES' if report['compatible'] else 'NO'}")
        print(f"Loadable (strict=True): {'YES' if report['loadable_strict'] else 'NO'}")
        print()
        if missing_in_ckpt:
            print(f"Missing in checkpoint ({len(missing_in_ckpt)}):")
            for k in list(missing_in_ckpt)[:5]:
                print(f"  - {k}")
            if len(missing_in_ckpt) > 5:
                print(f"  ... and {len(missing_in_ckpt) - 5} more")
        if extra_in_ckpt:
            print(f"Extra in checkpoint ({len(extra_in_ckpt)}):")
            for k in list(extra_in_ckpt)[:5]:
                print(f"  - {k}")
            if len(extra_in_ckpt) > 5:
                print(f"  ... and {len(extra_in_ckpt) - 5} more")
        if shape_mismatches:
            print(f"Shape mismatches ({len(shape_mismatches)}):")
            for m in shape_mismatches[:5]:
                print(f"  - {m['key']}: ckpt={m['checkpoint']} vs model={m['model']}")
        print("=" * 70)

    return report


# ============================================================================
# Grid Size Validation
# ============================================================================

VALID_GRID_SIZES = {
    16: (4, 4),   # 4x4 mini sudoku
    36: (6, 6),   # 6x6 sudoku
    81: (9, 9),   # Standard 9x9
}


def validate_grid_size(
    board_state: str,
    rows: Optional[int] = None,
    cols: Optional[int] = None
) -> Tuple[int, int]:
    """Validate and infer grid size from board state.

    Args:
        board_state: Board state string (length must match rows*cols)
        rows: Optional explicit row count
        cols: Optional explicit column count

    Returns:
        (rows, cols) tuple

    Raises:
        ValueError: If grid size is invalid or mismatched
    """
    board_len = len(board_state)

    if rows is not None and cols is not None:
        expected = rows * cols
        if board_len != expected:
            raise ValueError(
                f"Board state length {board_len} doesn't match {rows}x{cols}={expected}"
            )
        return rows, cols

    # Infer from board length
    if board_len not in VALID_GRID_SIZES:
        valid = ", ".join(f"{k} ({v[0]}x{v[1]})" for k, v in VALID_GRID_SIZES.items())
        raise ValueError(
            f"Cannot infer grid size from board length {board_len}. "
            f"Valid lengths: {valid}"
        )

    inferred = VALID_GRID_SIZES[board_len]

    # If one dimension provided, check consistency
    if rows is not None and rows != inferred[0]:
        raise ValueError(f"rows={rows} doesn't match inferred {inferred[0]} from length {board_len}")
    if cols is not None and cols != inferred[1]:
        raise ValueError(f"cols={cols} doesn't match inferred {inferred[1]} from length {board_len}")

    return inferred


# ============================================================================
# YRSN Monitoring Utilities
# ============================================================================

def compute_yrsn_monitoring_metrics(
    H_projection_heads,
    L_projection_heads,
    z_H: torch.Tensor,
    z_L: torch.Tensor
) -> Dict[str, Any]:
    """Compute YRSN monitoring metrics from H and L level hidden states.

    This is a shared utility to ensure consistent metrics computation
    across all HRM-family models (HRMV, HRMVSig, YRSNEnhancedHRM).

    Args:
        H_projection_heads: YRSNProjectionHeads instance for H-level
        L_projection_heads: YRSNProjectionHeads instance for L-level
        z_H: H-level hidden states [batch, seq_len, hidden_size]
        z_L: L-level hidden states [batch, seq_len, hidden_size]

    Returns:
        Dict with:
            - 'H_level': metrics dict (R, S, N, y_score, collapse_risk, etc.)
            - 'L_level': metrics dict (R, S, N, y_score, collapse_risk, etc.)
            - 'collapse_detected': bool indicating if any level has collapse
    """
    h_metrics = H_projection_heads.compute_yrsn_metrics(z_H)
    l_metrics = L_projection_heads.compute_yrsn_metrics(z_L)

    return {
        'H_level': h_metrics,
        'L_level': l_metrics,
        'collapse_detected': (
            h_metrics['collapse_type'].name != 'NONE' or
            l_metrics['collapse_type'].name != 'NONE'
        ),
    }


# Export all public symbols
__all__ = [
    "__version__",
    "trunc_normal_init_",
    "rms_norm",
    "SwiGLU",
    "RotaryPositionEmbedding",
    "ModelCheckpoint",
    "save_checkpoint",
    "load_checkpoint",
    "check_checkpoint_compatibility",
    "validate_grid_size",
    "VALID_GRID_SIZES",
    "compute_yrsn_monitoring_metrics",
]
