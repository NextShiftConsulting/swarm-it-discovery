"""
YRSN Framework Integrations.

This module provides integrations with popular AI agent frameworks:

- CrewAI: Multi-agent orchestration
- LangChain: LLM application framework
- LlamaIndex: Data framework for LLM applications

Example:
    # CrewAI integration
    from yrsn.integrations.crewai import (
        YRSNCrewAI,
        get_quality_tools,
        create_quality_agent,
    )

    tools = get_quality_tools()
    agent = create_quality_agent()
"""

from yrsn.integrations.crewai import (
    YRSNCrewAI,
    get_quality_tools,
    get_temperature_tools,
    get_all_tools,
    create_quality_agent,
    create_temperature_agent,
    create_retrieval_agent,
    YRSNQualityGate,
    YRSNMemoryWrapper,
)

__all__ = [
    # CrewAI
    "YRSNCrewAI",
    "get_quality_tools",
    "get_temperature_tools",
    "get_all_tools",
    "create_quality_agent",
    "create_temperature_agent",
    "create_retrieval_agent",
    "YRSNQualityGate",
    "YRSNMemoryWrapper",
]
