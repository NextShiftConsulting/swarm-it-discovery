"""
YRSN × CrewAI Integration Module.

Provides seamless integration between YRSN context engineering and CrewAI
multi-agent orchestration framework.

Features:
- Pre-built YRSN tools for CrewAI agents
- Quality-aware agents with collapse detection
- Temperature-controlled LLM inference
- YRSN-backed memory systems
- Quality gates for task execution

Example:
    from yrsn.integrations.crewai import (
        YRSNCrewAI,
        get_quality_tools,
        create_quality_agent,
    )

    # Quick start
    yrsn = YRSNCrewAI()
    tools = yrsn.get_tools()
    agent = yrsn.create_agent(role="Analyst", goal="Analyze quality")

    # Or use convenience functions
    tools = get_quality_tools()
    agent = create_quality_agent()
"""

from __future__ import annotations

import functools
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Type, Union

logger = logging.getLogger(__name__)

# Type hints for CrewAI (may not be installed)
try:
    from crewai import Agent, Crew, Process, Task, Tool

    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    Agent = Any
    Crew = Any
    Process = Any
    Task = Any
    Tool = Any


@dataclass
class YRSNCrewAI:
    """
    Main integration class for YRSN × CrewAI.

    Provides a unified interface for:
    - Generating CrewAI-compatible tools from YRSN
    - Creating quality-aware agents
    - Building crews with YRSN capabilities
    - Memory and quality gate integrations

    Example:
        yrsn = YRSNCrewAI(llm_model="gpt-4", verbose=True)

        # Get all YRSN tools
        tools = yrsn.get_tools()

        # Create a quality-focused agent
        analyst = yrsn.create_agent(
            role="Quality Analyst",
            goal="Ensure context quality",
            tool_names=["yrsn_detect_collapse", "yrsn_compute_temperature"]
        )

        # Create a complete crew
        crew = yrsn.create_crew(
            agents=[analyst],
            tasks=[{"description": "Analyze quality", "agent": analyst}]
        )
    """

    llm_model: str = "gpt-4"
    verbose: bool = True
    memory: bool = True
    quality_threshold: float = 0.3  # Minimum quality for task execution

    def __post_init__(self):
        if not CREWAI_AVAILABLE:
            logger.warning(
                "CrewAI not installed. Install with: pip install crewai"
            )

    # =========================================================================
    # Tool Generation
    # =========================================================================

    def get_tools(
        self,
        categories: Optional[List[str]] = None,
        names: Optional[List[str]] = None,
    ) -> List[Tool]:
        """
        Get YRSN tools as CrewAI Tool instances.

        Args:
            categories: Filter by categories ("quality", "temperature", etc.)
            names: Specific tool names to include

        Returns:
            List of CrewAI Tool instances
        """
        from yrsn.tools import ToolCategory, tool_registry

        tools = tool_registry.list_tools()

        # Filter by category
        if categories:
            category_enums = [ToolCategory(c) for c in categories if hasattr(ToolCategory, c.upper())]
            tools = [t for t in tools if t.category in category_enums]

        # Filter by name
        if names:
            tools = [t for t in tools if t.name in names]

        if not CREWAI_AVAILABLE:
            return [{"name": t.name, "description": t.description, "func": t.function} for t in tools]

        return [
            Tool(
                name=t.name,
                description=t.description,
                func=self._wrap_tool(t.function),
            )
            for t in tools
        ]

    def _wrap_tool(self, func: Callable) -> Callable:
        """Wrap tool function for CrewAI compatibility."""

        @functools.wraps(func)
        def wrapped(*args: Any, **kwargs: Any) -> str:
            try:
                result = func(*args, **kwargs)
                if isinstance(result, dict):
                    return json.dumps(result, indent=2, default=str)
                return str(result)
            except Exception as e:
                logger.exception(f"Tool error: {e}")
                return f"Error: {str(e)}"

        return wrapped

    # =========================================================================
    # Agent Creation
    # =========================================================================

    def create_agent(
        self,
        role: str,
        goal: str,
        backstory: Optional[str] = None,
        tool_names: Optional[List[str]] = None,
        tool_categories: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Agent:
        """
        Create a CrewAI agent with YRSN tools.

        Args:
            role: Agent role
            goal: Agent goal
            backstory: Agent backstory (auto-generated if None)
            tool_names: Specific tools to include
            tool_categories: Tool categories to include
            **kwargs: Additional Agent parameters

        Returns:
            CrewAI Agent instance
        """
        # Get tools
        tools = self.get_tools(
            categories=tool_categories,
            names=tool_names,
        )

        # Auto-generate backstory
        if backstory is None:
            tool_list = ", ".join([t.name if hasattr(t, 'name') else t['name'] for t in tools[:3]])
            backstory = (
                f"You are a {role} specializing in context quality engineering. "
                f"You use YRSN decomposition (Relevant/Superfluous/Noise) to analyze "
                f"and optimize context. Your available tools include: {tool_list}."
            )

        if not CREWAI_AVAILABLE:
            return {
                "role": role,
                "goal": goal,
                "backstory": backstory,
                "tools": [t['name'] if isinstance(t, dict) else t.name for t in tools],
                **kwargs,
            }

        return Agent(
            role=role,
            goal=goal,
            backstory=backstory,
            tools=tools,
            verbose=self.verbose,
            memory=self.memory,
            llm=self.llm_model,
            **kwargs,
        )

    # =========================================================================
    # Task Creation
    # =========================================================================

    def create_task(
        self,
        description: str,
        expected_output: str,
        agent: Optional[Agent] = None,
        quality_gate: bool = False,
        **kwargs: Any,
    ) -> Task:
        """
        Create a CrewAI task, optionally with quality gate.

        Args:
            description: Task description
            expected_output: Expected output description
            agent: Agent to assign task to
            quality_gate: Enable quality checking before execution
            **kwargs: Additional Task parameters

        Returns:
            CrewAI Task instance
        """
        if not CREWAI_AVAILABLE:
            return {
                "description": description,
                "expected_output": expected_output,
                "quality_gate": quality_gate,
                **kwargs,
            }

        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            **kwargs,
        )

        # TODO: Add quality gate callback when CrewAI supports it
        if quality_gate:
            logger.info(f"Quality gate enabled for task: {description[:50]}...")

        return task

    # =========================================================================
    # Crew Creation
    # =========================================================================

    def create_crew(
        self,
        agents: List[Union[Agent, Dict[str, Any]]],
        tasks: List[Union[Task, Dict[str, Any]]],
        process: str = "sequential",
        **kwargs: Any,
    ) -> Crew:
        """
        Create a CrewAI crew with YRSN capabilities.

        Args:
            agents: List of agents or agent configs
            tasks: List of tasks or task configs
            process: Execution process ("sequential" or "hierarchical")
            **kwargs: Additional Crew parameters

        Returns:
            CrewAI Crew instance
        """
        # Convert agent configs to agents
        crewai_agents = []
        for agent in agents:
            if isinstance(agent, dict):
                crewai_agents.append(self.create_agent(**agent))
            else:
                crewai_agents.append(agent)

        # Convert task configs to tasks
        crewai_tasks = []
        for i, task in enumerate(tasks):
            if isinstance(task, dict):
                # Assign agent if not specified
                if "agent" not in task and crewai_agents:
                    task["agent"] = crewai_agents[i % len(crewai_agents)]
                crewai_tasks.append(self.create_task(**task))
            else:
                crewai_tasks.append(task)

        if not CREWAI_AVAILABLE:
            return {
                "agents": crewai_agents,
                "tasks": crewai_tasks,
                "process": process,
                **kwargs,
            }

        process_enum = Process.sequential if process == "sequential" else Process.hierarchical

        return Crew(
            agents=crewai_agents,
            tasks=crewai_tasks,
            process=process_enum,
            verbose=self.verbose,
            **kwargs,
        )


# =============================================================================
# Quality Gate
# =============================================================================


class YRSNQualityGate:
    """
    Quality gate for CrewAI task execution.

    Checks context quality before allowing task execution.
    Can escalate to human review on low quality or collapse.

    Example:
        gate = YRSNQualityGate(threshold=0.4, escalate_on_collapse=True)

        @gate.guard
        def my_task_callback(context):
            # Only executes if quality >= threshold
            return process(context)
    """

    def __init__(
        self,
        threshold: float = 0.3,
        escalate_on_collapse: bool = True,
        collapse_types: Optional[List[str]] = None,
    ):
        self.threshold = threshold
        self.escalate_on_collapse = escalate_on_collapse
        self.collapse_types = collapse_types or ["POISONING", "CONFLICT"]

    def check(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check context quality.

        Args:
            context: Context with R, S, N scores

        Returns:
            Quality check result
        """
        from yrsn_context import detect_collapse

        r = context.get("R", 0.5)
        s = context.get("S", 0.3)
        n = context.get("N", 0.2)

        total = r + s + n
        alpha = r / total if total > 0 else 0.5

        collapse = detect_collapse(r, s, n)

        passed = alpha >= self.threshold
        if self.escalate_on_collapse and collapse.collapse_type.name in self.collapse_types:
            passed = False

        return {
            "passed": passed,
            "quality_score": alpha,
            "collapse_type": collapse.collapse_type.name,
            "severity": collapse.severity.name,
            "recommendation": collapse.recommendation,
        }

    def guard(self, func: Callable) -> Callable:
        """
        Decorator to guard a function with quality check.

        Args:
            func: Function to guard

        Returns:
            Guarded function
        """

        @functools.wraps(func)
        def wrapped(context: Dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            result = self.check(context)
            if not result["passed"]:
                raise QualityGateError(
                    f"Quality gate failed: {result['quality_score']:.2f} < {self.threshold}, "
                    f"collapse: {result['collapse_type']}"
                )
            return func(context, *args, **kwargs)

        return wrapped


class QualityGateError(Exception):
    """Raised when quality gate check fails."""

    pass


# =============================================================================
# Memory Wrapper
# =============================================================================


class YRSNMemoryWrapper:
    """
    YRSN-backed memory for CrewAI agents.

    Provides quality-aware memory with:
    - 4-layer memory system (SDM, Hopfield, EWC, Replay)
    - Temperature-controlled recall
    - Quality-based storage prioritization

    Example:
        memory = YRSNMemoryWrapper()

        # Store with quality
        memory.store("key", "value", quality=0.8)

        # Recall with temperature
        result = memory.recall("key", temperature=1.5)
    """

    def __init__(
        self,
        dim: int = 256,
        sdm_weight: float = 0.3,
        hopfield_weight: float = 0.4,
        ewc_weight: float = 0.2,
        replay_weight: float = 0.1,
    ):
        self.dim = dim
        self.weights = {
            "sdm": sdm_weight,
            "hopfield": hopfield_weight,
            "ewc": ewc_weight,
            "replay": replay_weight,
        }
        self._learner = None

    @property
    def learner(self) -> Any:
        """Get or create the YRSN learner."""
        if self._learner is None:
            try:
                from yrsn.core.memory import BaseLearnerConfig

                config = BaseLearnerConfig(
                    context_dim=self.dim,
                    sdm_weight=self.weights["sdm"],
                    hopfield_weight=self.weights["hopfield"],
                    ewc_weight=self.weights["ewc"],
                    replay_weight=self.weights["replay"],
                )
                # Use mock learner since BaseLearner is abstract
                # In production, use a concrete implementation
                self._learner = _MockLearner(config)
            except ImportError:
                logger.warning("YRSN memory not available")
                self._learner = _MockLearner()
        return self._learner

    def store(
        self,
        key: str,
        value: Any,
        quality: float = 0.5,
        **metadata: Any,
    ) -> None:
        """
        Store value with quality score.

        Args:
            key: Storage key
            value: Value to store
            quality: Quality score (affects priority)
            **metadata: Additional metadata
        """
        import numpy as np

        # Create embedding (simplified - use real embeddings in production)
        context = np.random.randn(self.dim).astype(np.float32)
        context = context / np.linalg.norm(context)

        self.learner.learn(
            context=context,
            label=key,
            reward=quality,
            feedback={"value": value, **metadata},
        )

    def recall(
        self,
        query: str,
        temperature: float = 1.0,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Recall from memory with temperature control.

        Args:
            query: Query string
            temperature: Recall temperature (higher = more diverse)
            top_k: Number of results

        Returns:
            List of recalled items
        """
        import numpy as np

        # Create query embedding
        context = np.random.randn(self.dim).astype(np.float32)
        context = context / np.linalg.norm(context)

        result = self.learner.predict(context, alpha=1.0 / temperature)
        return [{"label": result.label, "confidence": result.confidence}]


class _MockLearner:
    """Mock learner when YRSN memory unavailable."""

    def __init__(self, config: Any = None):
        self.config = config
        self._storage: Dict[str, Any] = {}

    def learn(self, context: Any, label: str, reward: float, feedback: Any) -> Any:
        self._storage[label] = {"reward": reward, "feedback": feedback}
        return type("Result", (), {"success": True})()

    def predict(self, context: Any, alpha: float) -> Any:
        if self._storage:
            key = list(self._storage.keys())[0]
            return type("Result", (), {"label": key, "confidence": 0.5})()
        return type("Result", (), {"label": None, "confidence": 0.0})()


# =============================================================================
# Convenience Functions
# =============================================================================


def get_quality_tools() -> List[Tool]:
    """Get YRSN quality analysis tools."""
    return YRSNCrewAI().get_tools(categories=["quality"])


def get_temperature_tools() -> List[Tool]:
    """Get YRSN temperature control tools."""
    return YRSNCrewAI().get_tools(categories=["temperature"])


def get_all_tools() -> List[Tool]:
    """Get all YRSN tools."""
    return YRSNCrewAI().get_tools()


def create_quality_agent(
    llm_model: str = "gpt-4",
    **kwargs: Any,
) -> Agent:
    """Create a pre-configured quality analysis agent."""
    return YRSNCrewAI(llm_model=llm_model).create_agent(
        role="Quality Analyst",
        goal="Analyze and ensure context quality using YRSN decomposition",
        tool_categories=["quality"],
        **kwargs,
    )


def create_temperature_agent(
    llm_model: str = "gpt-4",
    **kwargs: Any,
) -> Agent:
    """Create a pre-configured temperature control agent."""
    return YRSNCrewAI(llm_model=llm_model).create_agent(
        role="Temperature Controller",
        goal="Optimize LLM inference temperature based on context quality",
        tool_categories=["temperature"],
        **kwargs,
    )


def create_retrieval_agent(
    llm_model: str = "gpt-4",
    **kwargs: Any,
) -> Agent:
    """Create a pre-configured retrieval specialist agent."""
    return YRSNCrewAI(llm_model=llm_model).create_agent(
        role="Retrieval Specialist",
        goal="Retrieve and rank context using YRSN quality scores",
        tool_categories=["retrieval"],
        **kwargs,
    )


__all__ = [
    "YRSNCrewAI",
    "YRSNQualityGate",
    "YRSNMemoryWrapper",
    "QualityGateError",
    "get_quality_tools",
    "get_temperature_tools",
    "get_all_tools",
    "create_quality_agent",
    "create_temperature_agent",
    "create_retrieval_agent",
    "CREWAI_AVAILABLE",
]
