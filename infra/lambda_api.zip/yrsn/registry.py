"""
YRSN Registry - One-stop discovery for datasets and checkpoints

Usage:
    from yrsn.registry import (
        list_checkpoints,
        list_datasets,
        get_checkpoint,
        get_dataset,
        status,
    )

    # Discovery
    list_checkpoints()  # See what's available
    list_datasets()     # See what's available

    # Loading (simple, consistent)
    projection = get_checkpoint('rsn_cifar64')
    dataset = get_dataset('cifar10.1')

    # Status
    status()  # Show what's available vs missing
"""

from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
import os

# =============================================================================
# Configuration
# =============================================================================

def _get_project_root() -> Path:
    """
    Get project root (where checkpoints/ and data/ live).

    Resolution order (hex-arch compliant):
    1. YRSN_ROOT environment variable (explicit injection)
    2. Relative to this file (development fallback)
    3. Current working directory (runtime fallback)
    """
    # 1. Environment variable (preferred - explicit injection)
    if 'YRSN_ROOT' in os.environ:
        return Path(os.environ['YRSN_ROOT'])

    # 2. Relative to this file: src/yrsn/registry.py -> go up to project root
    file_based = Path(__file__).parent.parent.parent.parent
    if (file_based / 'checkpoints').exists() or (file_based / 'data').exists():
        return file_based

    # 3. Current working directory (runtime)
    cwd = Path.cwd()
    if (cwd / 'checkpoints').exists() or (cwd / 'data').exists():
        return cwd

    # 4. Final fallback
    return file_based


def _resolve_root() -> Path:
    """Resolve project root, caching result."""
    global _PROJECT_ROOT_CACHE
    if _PROJECT_ROOT_CACHE is None:
        _PROJECT_ROOT_CACHE = _get_project_root()
    return _PROJECT_ROOT_CACHE


_PROJECT_ROOT_CACHE: Optional[Path] = None


def get_project_root() -> Path:
    """
    Get project root path.

    Hex-arch compliant: Can be overridden via YRSN_ROOT env var.
    """
    return _resolve_root()


def set_project_root(path: Union[str, Path]) -> None:
    """
    Explicitly set project root (hex-arch dependency injection).

    Use this in tests or when running from non-standard locations.
    """
    global _PROJECT_ROOT_CACHE
    _PROJECT_ROOT_CACHE = Path(path)


# Lazy accessors for hex-arch compliance (no module-level constants)
def _checkpoint_dir() -> Path:
    return get_project_root() / 'checkpoints'


def _model_dir() -> Path:
    return get_project_root() / 'models'


def _data_dir() -> Path:
    return get_project_root() / 'data'


# =============================================================================
# Checkpoint Registry
# =============================================================================

@dataclass
class CheckpointInfo:
    """Metadata for a checkpoint."""
    name: str
    path: str
    input_dim: int
    description: str
    loader: str  # Function to use for loading
    compatible_with: List[str]  # Other checkpoints/models it works with


CHECKPOINTS: Dict[str, CheckpointInfo] = {
    'rsn_cifar64': CheckpointInfo(
        name='rsn_cifar64',
        path='checkpoints/trained_rsn_cifar64.pt',
        input_dim=64,
        description='RSN projection for 64-dim features (CIFAR-10)',
        loader='TrainedRSNProjection.from_checkpoint',
        compatible_with=['resnet20'],
    ),
    'resnet20': CheckpointInfo(
        name='resnet20',
        path='models/resnet20_cifar10.th',
        input_dim=3072,  # 3x32x32 images
        description='Pretrained ResNet20 for CIFAR-10 (91.78% acc)',
        loader='resnet20_cifar10(pretrained=True)',
        compatible_with=['rsn_cifar64'],
    ),
}


def list_checkpoints(verbose: bool = False) -> List[str]:
    """
    List available checkpoints.

    Args:
        verbose: If True, print details

    Returns:
        List of checkpoint names

    Example:
        >>> list_checkpoints()
        ['rsn_cifar64', 'resnet20']

        >>> list_checkpoints(verbose=True)
        rsn_cifar64  ✓  RSN projection for 64-dim features (CIFAR-10)
        resnet20     ✓  Pretrained ResNet20 for CIFAR-10 (91.78% acc)
    """
    names = list(CHECKPOINTS.keys())

    if verbose:
        print("\nAvailable Checkpoints:")
        print("-" * 60)
        for name, info in CHECKPOINTS.items():
            exists = (get_project_root() / info.path).exists()
            marker = "✓" if exists else "✗"
            print(f"  {name:15} {marker}  {info.description}")
        print()

    return names


def get_checkpoint(
    name: str,
    device: str = 'cpu',
    **kwargs
) -> Any:
    """
    Load a checkpoint by name.

    Args:
        name: Checkpoint name (see list_checkpoints())
        device: Target device
        **kwargs: Passed to loader

    Returns:
        Loaded checkpoint (type depends on checkpoint)

    Example:
        >>> projection = get_checkpoint('rsn_cifar64')
        >>> model = get_checkpoint('resnet20')
    """
    if name not in CHECKPOINTS:
        available = ', '.join(CHECKPOINTS.keys())
        raise ValueError(f"Unknown checkpoint '{name}'. Available: {available}")

    info = CHECKPOINTS[name]
    path = get_project_root() / info.path

    if not path.exists():
        raise FileNotFoundError(
            f"Checkpoint '{name}' not found at {path}\n"
            f"Run: python -m yrsn.registry download {name}"
        )

    # Load based on type
    if name == 'rsn_cifar64':
        from yrsn.core.decomposition.trained_projection import TrainedRSNProjection
        return TrainedRSNProjection.from_checkpoint(str(path), device=device, **kwargs)

    elif name == 'resnet20':
        from yrsn.models.resnet_cifar import resnet20_cifar10
        return resnet20_cifar10(pretrained=True, device=device)

    else:
        raise NotImplementedError(f"No loader defined for '{name}'")


def checkpoint_info(name: str) -> CheckpointInfo:
    """Get metadata for a checkpoint."""
    if name not in CHECKPOINTS:
        available = ', '.join(CHECKPOINTS.keys())
        raise ValueError(f"Unknown checkpoint '{name}'. Available: {available}")
    return CHECKPOINTS[name]


# =============================================================================
# Dataset Registry
# =============================================================================

@dataclass
class DatasetInfo:
    """Metadata for a dataset."""
    name: str
    path: str
    n_samples: int
    description: str
    adapter: str  # Class name to use
    download_cmd: Optional[str]


DATASETS: Dict[str, DatasetInfo] = {
    'cifar10': DatasetInfo(
        name='cifar10',
        path='data/cifar-10-batches-py',
        n_samples=60000,
        description='Standard CIFAR-10 (auto-downloads)',
        adapter='CIFAR10Adapter',
        download_cmd=None,  # Auto-downloads via torchvision
    ),
    'cifar10.1': DatasetInfo(
        name='cifar10.1',
        path='data/cifar10.1',
        n_samples=2000,
        description='CIFAR-10.1 temporal shift (2018)',
        adapter='CIFAR10_1Adapter',
        download_cmd='./scripts/download_datasets.sh cifar10.1',
    ),
    'cifar10.2': DatasetInfo(
        name='cifar10.2',
        path='data/cifar10.2',
        n_samples=2000,
        description='CIFAR-10.2 temporal shift (2021)',
        adapter='CIFAR10_2Adapter',
        download_cmd='./scripts/download_datasets.sh cifar10.2',
    ),
    'cifar10h': DatasetInfo(
        name='cifar10h',
        path='data/cifar10h',
        n_samples=10000,
        description='CIFAR-10H human uncertainty labels',
        adapter='CIFAR10HAdapter',
        download_cmd='./scripts/download_datasets.sh cifar10h',
    ),
    'cifar10c': DatasetInfo(
        name='cifar10c',
        path='data/CIFAR-10-C',
        n_samples=500000,  # 10k * 5 severities * 19 corruptions (subset)
        description='CIFAR-10-C corruption benchmark',
        adapter='CIFAR10CAdapter',
        download_cmd='./scripts/download_datasets.sh cifar10c',
    ),
}


def list_datasets(verbose: bool = False) -> List[str]:
    """
    List available datasets.

    Args:
        verbose: If True, print details

    Returns:
        List of dataset names

    Example:
        >>> list_datasets()
        ['cifar10', 'cifar10.1', 'cifar10.2', 'cifar10h', 'cifar10c']
    """
    names = list(DATASETS.keys())

    if verbose:
        print("\nAvailable Datasets:")
        print("-" * 70)
        for name, info in DATASETS.items():
            exists = (get_project_root() / info.path).exists()
            status = "✓" if exists else "✗"
            samples = f"{info.n_samples:,}"
            print(f"  {name:12} {status}  {samples:>8} samples  {info.description}")
        print()

    return names


def get_dataset(
    name: str,
    root: Optional[Union[str, Path]] = None,
    **kwargs
) -> Any:
    """
    Load a dataset by name.

    Args:
        name: Dataset name (see list_datasets())
        root: Override data root directory
        **kwargs: Passed to adapter

    Returns:
        Dataset adapter instance

    Example:
        >>> dataset = get_dataset('cifar10.1')
        >>> img, label = dataset.get_item(0)
    """
    # Try exact match first
    if name in DATASETS:
        matched = name
    else:
        # Normalize and try fuzzy match
        name_normalized = name.lower().replace('-', '').replace('_', '').replace('.', '')

        matched = None
        for key in DATASETS:
            key_normalized = key.replace('.', '').replace('-', '')
            if key_normalized == name_normalized:
                matched = key
                break

    if matched is None:
        available = ', '.join(DATASETS.keys())
        raise ValueError(f"Unknown dataset '{name}'. Available: {available}")

    info = DATASETS[matched]
    data_root = Path(root) if root else _data_dir()

    # Check if exists
    full_path = get_project_root() / info.path if root is None else data_root / info.path.split('/')[-1]

    if not full_path.exists() and info.download_cmd:
        raise FileNotFoundError(
            f"Dataset '{matched}' not found at {full_path}\n"
            f"Download with: {info.download_cmd}"
        )

    # Load using adapter
    from yrsn.datasets.adapters.cifar10 import (
        CIFAR10Adapter, CIFAR10_1Adapter, CIFAR10_2Adapter,
        CIFAR10HAdapter, CIFAR10CAdapter
    )

    adapters = {
        'CIFAR10Adapter': CIFAR10Adapter,
        'CIFAR10_1Adapter': CIFAR10_1Adapter,
        'CIFAR10_2Adapter': CIFAR10_2Adapter,
        'CIFAR10HAdapter': CIFAR10HAdapter,
        'CIFAR10CAdapter': CIFAR10CAdapter,
    }

    adapter_class = adapters[info.adapter]
    return adapter_class(root=data_root, **kwargs)


def dataset_info(name: str) -> DatasetInfo:
    """Get metadata for a dataset."""
    if name not in DATASETS:
        available = ', '.join(DATASETS.keys())
        raise ValueError(f"Unknown dataset '{name}'. Available: {available}")
    return DATASETS[name]


# =============================================================================
# Status / Discovery
# =============================================================================

def status() -> Dict[str, Any]:
    """
    Show status of all datasets and checkpoints.

    Returns:
        Dict with status info

    Example:
        >>> status()
        Checkpoints: 2/2 available
          rsn_cifar64  ✓
          resnet20     ✓

        Datasets: 4/5 available
          cifar10      ✓
          cifar10.1    ✓
          cifar10.2    ✓
          cifar10h     ✓
          cifar10c     ✗  (run: ./scripts/download_datasets.sh cifar10c)
    """
    result = {
        'checkpoints': {'available': 0, 'total': len(CHECKPOINTS), 'items': {}},
        'datasets': {'available': 0, 'total': len(DATASETS), 'items': {}},
    }

    print("\n" + "=" * 50)
    print("YRSN Registry Status")
    print("=" * 50)

    # Checkpoints
    print(f"\nCheckpoints:")
    for name, info in CHECKPOINTS.items():
        exists = (get_project_root() / info.path).exists()
        result['checkpoints']['items'][name] = exists
        if exists:
            result['checkpoints']['available'] += 1
        marker = "✓" if exists else "✗"
        print(f"  {name:15} {marker}")

    # Datasets
    print(f"\nDatasets:")
    for name, info in DATASETS.items():
        exists = (get_project_root() / info.path).exists()
        result['datasets']['items'][name] = exists
        if exists:
            result['datasets']['available'] += 1
        status = "✓" if exists else "✗"
        suffix = ""
        if not exists and info.download_cmd:
            suffix = f"  (run: {info.download_cmd})"
        print(f"  {name:12} {status}{suffix}")

    print(f"\nSummary:")
    print(f"  Checkpoints: {result['checkpoints']['available']}/{result['checkpoints']['total']}")
    print(f"  Datasets:    {result['datasets']['available']}/{result['datasets']['total']}")
    print()

    return result


# =============================================================================
# Convenience - Load Everything for Experiments
# =============================================================================

def load_cifar_stack(device: str = 'cpu'):
    """
    Load the standard CIFAR-10 experiment stack.

    Returns:
        (model, projection) tuple ready for experiments

    Example:
        >>> model, projection = load_cifar_stack()
        >>> features = model(images, return_features=True)
        >>> rsn = projection.compute_rsn_batch(features.numpy())
    """
    model = get_checkpoint('resnet20', device=device)
    projection = get_checkpoint('rsn_cifar64', device=device)
    return model, projection


# =============================================================================
# CLI Interface
# =============================================================================

def _cli():
    """Command-line interface."""
    import sys

    if len(sys.argv) < 2:
        print("Usage: python -m yrsn.registry <command>")
        print("\nCommands:")
        print("  status              Show what's available")
        print("  checkpoints         List checkpoints")
        print("  datasets            List datasets")
        print("  info <name>         Show details for checkpoint/dataset")
        return

    cmd = sys.argv[1]

    if cmd == 'status':
        status()
    elif cmd == 'checkpoints':
        list_checkpoints(verbose=True)
    elif cmd == 'datasets':
        list_datasets(verbose=True)
    elif cmd == 'info' and len(sys.argv) > 2:
        name = sys.argv[2]
        if name in CHECKPOINTS:
            info = CHECKPOINTS[name]
            print(f"\nCheckpoint: {info.name}")
            print(f"  Path:        {info.path}")
            print(f"  Input dim:   {info.input_dim}")
            print(f"  Description: {info.description}")
            print(f"  Loader:      {info.loader}")
            print(f"  Compatible:  {', '.join(info.compatible_with)}")
        elif name in DATASETS:
            info = DATASETS[name]
            print(f"\nDataset: {info.name}")
            print(f"  Path:        {info.path}")
            print(f"  Samples:     {info.n_samples:,}")
            print(f"  Description: {info.description}")
            print(f"  Adapter:     {info.adapter}")
            if info.download_cmd:
                print(f"  Download:    {info.download_cmd}")
        else:
            print(f"Unknown: '{name}'")
    else:
        print(f"Unknown command: {cmd}")


if __name__ == '__main__':
    _cli()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Discovery
    'list_checkpoints',
    'list_datasets',
    'checkpoint_info',
    'dataset_info',
    'status',

    # Loading
    'get_checkpoint',
    'get_dataset',
    'load_cifar_stack',

    # Info classes
    'CheckpointInfo',
    'DatasetInfo',

    # Path management (hex-arch compliant)
    'get_project_root',
    'set_project_root',  # For dependency injection
]
