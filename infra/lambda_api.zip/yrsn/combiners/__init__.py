"""
YRSN Combiners - Things that FUSE.

Combine multiple signals, modalities, or agent outputs into unified representations.

Available Combiners:
    YRSNLatentCombiner     - Multi-agent latent space consensus
    AdaptiveRoutingCombiner - Dynamic routing based on input
    StrategyRouter         - Routes to appropriate reasoning head
    MultimodalEncoder      - Vision + Text fusion (SigLIP/CLIP)

Example:
    from yrsn.combiners import YRSNLatentCombiner, StrategyRouter

    combiner = YRSNLatentCombiner(heads=["rule", "move", "halt"])
    router = StrategyRouter()

    decision = router.route(features)
    fused = combiner.combine(head_outputs)
"""

# Latent Space Combiners (multi-agent consensus)
try:
    from yrsn_context.neural.latent_combiner import (
        YRSNLatentCombiner,
        AdaptiveRoutingCombiner,
        YRSNScores,
        CombinerOutput,
        create_yrsn_combiner,
    )
    HAS_LATENT = True
except ImportError:
    HAS_LATENT = False
    YRSNLatentCombiner = None
    AdaptiveRoutingCombiner = None
    YRSNScores = None
    CombinerOutput = None
    create_yrsn_combiner = None

# Strategy Router (picks which head)
try:
    from yrsn_context.neural.strategy_router import (
        StrategyRouter,
        RoutedYRSNCombiner,
        RoutingDecision,
        create_routed_combiner,
        STRATEGY_TO_HEAD,
        HEAD_TO_STRATEGY,
    )
    HAS_ROUTER = True
except ImportError:
    HAS_ROUTER = False
    StrategyRouter = None
    RoutedYRSNCombiner = None
    RoutingDecision = None
    create_routed_combiner = None
    STRATEGY_TO_HEAD = None
    HEAD_TO_STRATEGY = None

# Multimodal Encoder (vision + text)
try:
    from yrsn_context.multimodal import (
        MultimodalConstraintEncoder,
        BaseVisualRenderer,
        DummyRenderer,
    )
    HAS_MULTIMODAL = True
except ImportError:
    HAS_MULTIMODAL = False
    MultimodalConstraintEncoder = None
    BaseVisualRenderer = None
    DummyRenderer = None


def list_combiners():
    """List available combiners."""
    available = []
    if HAS_LATENT:
        available.extend(["YRSNLatentCombiner", "AdaptiveRoutingCombiner"])
    if HAS_ROUTER:
        available.extend(["StrategyRouter", "RoutedYRSNCombiner"])
    if HAS_MULTIMODAL:
        available.append("MultimodalConstraintEncoder")
    return available


__all__ = [
    # Latent combiners
    "YRSNLatentCombiner",
    "AdaptiveRoutingCombiner",
    "YRSNScores",
    "CombinerOutput",
    "create_yrsn_combiner",
    # Strategy router
    "StrategyRouter",
    "RoutedYRSNCombiner",
    "RoutingDecision",
    "create_routed_combiner",
    "STRATEGY_TO_HEAD",
    "HEAD_TO_STRATEGY",
    # Multimodal
    "MultimodalConstraintEncoder",
    "BaseVisualRenderer",
    "DummyRenderer",
    # Utils
    "list_combiners",
    # Availability flags
    "HAS_LATENT",
    "HAS_ROUTER",
    "HAS_MULTIMODAL",
]
