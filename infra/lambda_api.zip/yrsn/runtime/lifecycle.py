"""Lifecycle - Base class for lifecycle-aware components."""

from enum import Enum
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any

from yrsn.contracts import Observation, YrsnState


class LifecycleState(str, Enum):
    """Lifecycle states (matches ROS2 LifecycleNode)."""

    UNCONFIGURED = "unconfigured"  # No baseline, not ready
    INACTIVE = "inactive"  # Configured, not processing
    ACTIVE = "active"  # Processing observations
    ERROR = "error"  # Error state, needs recovery


class LifecycleNode(ABC):
    """
    Base class for all YRSN processing components.

    Implements the lifecycle pattern from ROS2 for:
    - Clean initialization/shutdown
    - State machine transitions
    - Error recovery

    Lifecycle:
        UNCONFIGURED → configure() → INACTIVE → activate() → ACTIVE
        ACTIVE → deactivate() → INACTIVE → shutdown() → UNCONFIGURED
        Any → error → ERROR → reset() → UNCONFIGURED
    """

    def __init__(self, name: str):
        """
        Initialize lifecycle node.

        Args:
            name: Node name for identification
        """
        self.name = name
        self._state = LifecycleState.UNCONFIGURED
        self._config: Dict[str, Any] = {}
        self._error: Optional[str] = None

    @property
    def state(self) -> LifecycleState:
        """Current lifecycle state."""
        return self._state

    @property
    def is_active(self) -> bool:
        """Check if node is active and processing."""
        return self._state == LifecycleState.ACTIVE

    @property
    def error(self) -> Optional[str]:
        """Error message if in ERROR state."""
        return self._error

    # === Lifecycle transitions ===

    def configure(self, config: Dict[str, Any]) -> bool:
        """
        UNCONFIGURED → INACTIVE: Load config, build baseline.

        Args:
            config: Configuration dictionary

        Returns:
            True if successful
        """
        if self._state != LifecycleState.UNCONFIGURED:
            return False

        try:
            self._config = config
            if self.on_configure(config):
                self._state = LifecycleState.INACTIVE
                return True
        except Exception as e:
            self._error = str(e)
            self._state = LifecycleState.ERROR

        return False

    def activate(self) -> bool:
        """
        INACTIVE → ACTIVE: Start processing.

        Returns:
            True if successful
        """
        if self._state != LifecycleState.INACTIVE:
            return False

        try:
            if self.on_activate():
                self._state = LifecycleState.ACTIVE
                return True
        except Exception as e:
            self._error = str(e)
            self._state = LifecycleState.ERROR

        return False

    def deactivate(self) -> bool:
        """
        ACTIVE → INACTIVE: Stop processing.

        Returns:
            True if successful
        """
        if self._state != LifecycleState.ACTIVE:
            return False

        self.on_deactivate()
        self._state = LifecycleState.INACTIVE
        return True

    def shutdown(self) -> None:
        """Any → UNCONFIGURED: Full cleanup."""
        self.on_shutdown()
        self._state = LifecycleState.UNCONFIGURED
        self._config = {}

    def reset(self) -> bool:
        """
        ERROR → UNCONFIGURED: Recovery.

        Returns:
            True if successful
        """
        if self._state == LifecycleState.ERROR:
            self.on_shutdown()
            self._state = LifecycleState.UNCONFIGURED
            self._error = None
            return True
        return False

    # === Abstract methods (implement in subclasses) ===

    @abstractmethod
    def on_configure(self, config: Dict[str, Any]) -> bool:
        """
        Called during configure(). Build baseline, load models.

        Args:
            config: Configuration dictionary

        Returns:
            True on success
        """
        pass

    @abstractmethod
    def on_activate(self) -> bool:
        """
        Called during activate(). Prepare for processing.

        Returns:
            True on success
        """
        pass

    def on_deactivate(self) -> None:
        """Called during deactivate(). Override if needed."""
        pass

    def on_shutdown(self) -> None:
        """Called during shutdown(). Cleanup resources. Override if needed."""
        pass

    @abstractmethod
    def tick(self, observation: Observation) -> YrsnState:
        """
        Process one observation.

        Only callable when ACTIVE.

        Args:
            observation: Input observation

        Returns:
            YRSN state output

        Raises:
            RuntimeError: If not in ACTIVE state
        """
        pass

    def __call__(self, observation: Observation) -> YrsnState:
        """Convenience: call tick() directly."""
        if not self.is_active:
            raise RuntimeError(f"Node {self.name} is not active (state: {self._state})")
        return self.tick(observation)
