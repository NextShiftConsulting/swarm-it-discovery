"""
YRSN Runtime - Lifecycle and Infrastructure

Provides:
    - LifecycleNode: Base class for all processing components
    - LifecycleState: State machine states
    - EventBus: Pub/sub messaging (via adapters)
    - Registry: Plugin discovery
    - Container: Dependency injection
"""

from yrsn.runtime.lifecycle import LifecycleNode, LifecycleState

__all__ = [
    "LifecycleNode",
    "LifecycleState",
]
