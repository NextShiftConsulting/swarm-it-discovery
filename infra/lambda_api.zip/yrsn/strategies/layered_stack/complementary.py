"""Complementary context pairing for balanced retrieval."""

from typing import Any, Dict, List, Set


class ComplementaryContextPair:
    """
    Models complementary context types.

    Inspired by n-type/p-type transistor pairing:
    - n-type (OxTs): Fast, high mobility
    - p-type (OrTs): Complementary characteristics

    For context:
    - Type A: Fast retrieval, broad coverage (like n-type)
    - Type B: Precise, specific (like p-type)

    Both needed for balanced "CMOS-like" operation.

    The paper deliberately sized transistors differently (OxT: 20μm channel,
    OrT: 30μm channel) to achieve matched saturation currents between n-type
    and p-type devices—critical for CMOS logic performance.

    Args:
        fast_retriever: Broad, fast retriever (n-type analog)
        precise_retriever: Narrow, precise retriever (p-type analog)
        balance_ratio: Ratio for balancing outputs (like channel width matching)
    """

    def __init__(
        self,
        fast_retriever: Any,
        precise_retriever: Any,
        balance_ratio: float = 1.0,
    ):
        self.fast = fast_retriever
        self.precise = precise_retriever
        self.balance_ratio = balance_ratio

    def retrieve_balanced(
        self, query: str, fast_k: int = 10, precise_k: int = 5
    ) -> Dict[str, List[Any]]:
        """
        Retrieve with both methods, balance the outputs.

        Like balancing n-MOS and p-MOS for proper inverter operation.

        Args:
            query: Query string
            fast_k: Number of fast results
            precise_k: Number of precise results

        Returns:
            Dictionary with 'fast', 'precise', and 'combined' results
        """
        # Fast retrieval (broad coverage)
        fast_results = self._retrieve(self.fast, query, k=fast_k)

        # Precise retrieval (high accuracy)
        precise_results = self._retrieve(self.precise, query, k=precise_k)

        # Balance based on ratio
        # Analogous to sizing OrT larger (30µm vs 20µm channel)
        # to match saturation currents
        adjusted_precise_k = int(precise_k * self.balance_ratio)
        precise_results = precise_results[:adjusted_precise_k]

        return {
            "fast": fast_results,
            "precise": precise_results,
            "combined": self._merge_complementary(fast_results, precise_results),
        }

    def _retrieve(self, retriever: Any, query: str, k: int) -> List[Any]:
        """Retrieve using a specific retriever."""
        if hasattr(retriever, "retrieve"):
            return retriever.retrieve(query, k=k)
        return []

    def _merge_complementary(self, fast_results: List[Any], precise_results: List[Any]) -> List[Any]:
        """
        Merge results for "complementary logic" operation.

        Like CMOS inverter: uses both n-type and p-type for
        robust output with wide noise margins.

        Precise results get priority (like p-MOS pull-up).
        Fast results fill gaps (like n-MOS pull-down).

        Args:
            fast_results: Results from fast retriever
            precise_results: Results from precise retriever

        Returns:
            Merged list with deduplication
        """
        # Precise results get priority
        merged = list(precise_results)
        seen_content: Set[str] = {
            self._get_content(r)[:100] for r in precise_results
        }

        # Add fast results that aren't duplicates
        for r in fast_results:
            content_key = self._get_content(r)[:100]
            if content_key not in seen_content:
                merged.append(r)
                seen_content.add(content_key)

        return merged

    def _get_content(self, item: Any) -> str:
        """Extract content string from an item."""
        if hasattr(item, "content"):
            return str(item.content)
        return str(item)
