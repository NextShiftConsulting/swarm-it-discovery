"""Layered context stack with quality management."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

import numpy as np

from yrsn.core.types import ContextBlock


@dataclass
class ContextLayer:
    """
    A single layer in the context stack.

    Analogous to a transistor stack layer (S1-OxTs, S2-OrTs, etc.)
    in the 3D integrated circuits paper.

    Attributes:
        name: Layer name
        level: Layer level (0 = foundation, higher = upper layers)
        content: List of content strings in this layer
        quality_score: Interface quality score (0-1)
        roughness: Surface roughness analog (higher = worse quality)
        dependencies: Names of layers this depends on
    """

    name: str
    level: int
    content: List[str]
    quality_score: float
    roughness: float
    dependencies: List[str] = field(default_factory=list)


@dataclass
class LayerInterface:
    """
    Interface between two context layers.

    Analogous to parylene C dielectric in the paper:
    - Provides isolation
    - Enables smooth transition
    - Affects performance of upper layer

    Attributes:
        lower_layer: Name of lower layer
        upper_layer: Name of upper layer
        coupling_strength: How much upper depends on lower (0-1)
        interface_quality: Quality of interface (0-1)
        buffer_type: Type of buffer ('semantic', 'structural', 'temporal')
    """

    lower_layer: str
    upper_layer: str
    coupling_strength: float
    interface_quality: float
    buffer_type: str = "semantic"


class LayeredContextStack:
    """
    Multi-layer context architecture with quality management.

    Layer hierarchy (analogous to 6-stack transistors):
    - Layer 0: Core knowledge (like silicon substrate + S1-OxTs)
    - Layer 1: Domain context (like S2-OrTs)
    - Layer 2: Task-specific (like S3-OxTs)
    - Layer 3: Session context (like S4-OrTs)
    - Layer 4: Recent history (like S5-OxTs)
    - Layer 5: Current input (like S6-OrTs)

    Key insight from paper: Lower stacks (S1, S2) outperformed upper stacks
    due to smoother interfaces. Foundation layer quality propagates through
    the entire stack.

    Args:
        max_layers: Maximum number of layers (default: 6)
    """

    def __init__(self, max_layers: int = 6):
        self.layers: Dict[int, ContextLayer] = {}
        self.interfaces: Dict[str, LayerInterface] = {}
        self.max_layers = max_layers

        # Quality thresholds (derived from paper's findings)
        # S1-OxTs had 0.55nm roughness, S5-OxTs had ~3.6nm
        self.quality_thresholds = {
            0: 0.95,  # Foundation must be very high quality
            1: 0.85,
            2: 0.75,
            3: 0.65,
            4: 0.55,
            5: 0.45,  # Top layer can be rougher
        }

    def add_layer(
        self,
        level: int,
        name: str,
        content: Union[List[str], List[ContextBlock]],
        quality_score: Optional[float] = None,
    ) -> bool:
        """
        Add a layer to the stack.

        Like the paper's findings:
        - Lower layers with poor quality affect everything above
        - Quality requirements are stricter for lower layers

        YRSN mapping:
        - Layer quality = α of layer content
        - Roughness = N component (noise propagates like roughness)
        - Interface quality = min(lower_α, upper_α) * ω

        Args:
            level: Layer level (0 = foundation)
            name: Layer name
            content: List of content strings or ContextBlock objects
            quality_score: Quality score (0-1), auto-computed from R/S/N if ContextBlocks

        Returns:
            True if layer added successfully
        """
        if level >= self.max_layers:
            return False

        # Compute quality from YRSN if content is ContextBlock list
        if content and isinstance(content[0], ContextBlock):
            blocks: List[ContextBlock] = content  # type: ignore
            # Use YRSN metrics: α * ω for distribution-adjusted quality
            layer_alpha = np.mean([b.alpha for b in blocks])
            layer_omega = np.mean([b.omega for b in blocks])
            layer_N = np.mean([b.N for b in blocks])
            computed_quality = layer_alpha * layer_omega
            # Roughness = noise component (noise propagates like roughness)
            layer_roughness = layer_N * 2.0
            # Extract content strings from blocks
            content_strings = [b.content for b in blocks]
        else:
            computed_quality = quality_score if quality_score is not None else 0.5
            layer_roughness = (1 - computed_quality) * 2.0
            content_strings = content  # type: ignore

        final_quality = quality_score if quality_score is not None else computed_quality

        # Check quality threshold
        min_quality = self.quality_thresholds.get(level, 0.5)
        if final_quality < min_quality:
            print(
                f"Warning: Layer {level} quality {final_quality:.2f} "
                f"below threshold {min_quality:.2f}"
            )

        # Roughness compounds from lower layers
        roughness = layer_roughness
        if level > 0 and (level - 1) in self.layers:
            lower_roughness = self.layers[level - 1].roughness
            roughness = np.sqrt(roughness**2 + lower_roughness**2)

        self.layers[level] = ContextLayer(
            name=name,
            level=level,
            content=content_strings,
            quality_score=final_quality,
            roughness=roughness,
            dependencies=[self.layers[level - 1].name] if level > 0 else [],
        )

        # Create interface to lower layer
        if level > 0:
            self._create_interface(level - 1, level)

        return True

    def _create_interface(self, lower_level: int, upper_level: int) -> None:
        """Create interface between adjacent layers."""
        lower = self.layers[lower_level]
        upper = self.layers[upper_level]

        # Interface quality depends on both layers
        # Like parylene C dielectric quality depending on surface preparation
        interface_quality = min(lower.quality_score, upper.quality_score)

        # Adjust for roughness compound effect
        roughness_penalty = (lower.roughness + upper.roughness) / 10
        interface_quality = max(0, interface_quality - roughness_penalty)

        self.interfaces[f"{lower_level}-{upper_level}"] = LayerInterface(
            lower_layer=lower.name,
            upper_layer=upper.name,
            coupling_strength=0.8,  # Default coupling
            interface_quality=interface_quality,
            buffer_type="semantic",
        )

    def get_effective_context(
        self, target_layer: int, include_lower: bool = True
    ) -> List[Tuple[str, float]]:
        """
        Get context from a layer, accounting for interface quality.

        Like how transistor performance in upper stacks is affected
        by interface quality from all lower layers.

        Args:
            target_layer: Layer level to retrieve
            include_lower: Whether to include lower layers

        Returns:
            List of (content, weight) tuples
        """
        if target_layer not in self.layers:
            return []

        layer = self.layers[target_layer]

        if not include_lower or target_layer == 0:
            return [(c, 1.0) for c in layer.content]

        # Accumulate context from lower layers with interface weighting
        all_content: List[Tuple[str, float, int]] = []

        for level in range(target_layer + 1):
            current_layer = self.layers[level]

            # Compute effective weight based on interface quality chain
            weight = 1.0
            for i in range(level, target_layer):
                interface_key = f"{i}-{i+1}"
                if interface_key in self.interfaces:
                    weight *= self.interfaces[interface_key].interface_quality

            # Add content with weight and level
            for item in current_layer.content:
                all_content.append((item, weight, level))

        # Sort by weight and return
        all_content.sort(key=lambda x: (-x[1], x[2]))
        return [(item[0], item[1]) for item in all_content]

    def compute_stack_quality(self) -> float:
        """
        Compute overall stack quality.

        Analogous to overall circuit performance which depends on
        all layer qualities and interface qualities.

        Returns:
            Overall quality score (0-1)
        """
        if not self.layers:
            return 0.0

        # Product of all interface qualities
        interface_product = 1.0
        for interface in self.interfaces.values():
            interface_product *= interface.interface_quality

        # Weighted average of layer qualities
        # Foundation layers contribute more
        weighted_sum = 0.0
        weight_total = 0.0
        for level, layer in self.layers.items():
            weight = 2 ** (self.max_layers - level)  # Higher weight for lower layers
            weighted_sum += layer.quality_score * weight
            weight_total += weight

        layer_quality = weighted_sum / weight_total if weight_total > 0 else 0

        # Combine (70% layer quality, 30% interface quality)
        return layer_quality * 0.7 + interface_product * 0.3
