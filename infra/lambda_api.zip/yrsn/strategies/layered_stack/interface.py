"""Interface optimization between context layers."""

from typing import Any, List

import numpy as np

from yrsn.strategies.layered_stack.stack import LayerInterface


class InterfaceOptimizer:
    """
    Optimizes interface quality between context layers.

    Analogous to the paper's optimization of:
    - Parylene C thickness (25nm dielectric, 200nm buffer)
    - ICP-RIE patterning to avoid edge roughness
    - Low-power sputtering for smoother surfaces

    Args:
        embedding_model: Model for computing semantic embeddings
    """

    def __init__(self, embedding_model: Any):
        self.embedding_model = embedding_model

    def optimize_interface(
        self, lower_content: List[str], upper_content: List[str], interface: LayerInterface
    ) -> LayerInterface:
        """
        Optimize interface between two layers.

        Strategies analogous to the paper:
        1. Semantic buffering (like parylene C buffer)
        2. Content smoothing (like ICP-RIE patterning)
        3. Relevance filtering (like SiO₂ sacrificial layer)

        Args:
            lower_content: Content from lower layer
            upper_content: Content from upper layer
            interface: Current interface configuration

        Returns:
            Optimized LayerInterface
        """
        # Strategy 1: Semantic buffering
        # Add intermediate concepts that bridge the two layers
        buffer_concepts = self._find_bridging_concepts(lower_content, upper_content)

        # Strategy 2: Compute semantic coherence
        coherence = self._compute_coherence(lower_content, upper_content)

        # Strategy 3: Filter mismatched content
        filtered_quality = self._filter_for_compatibility(lower_content, upper_content)

        # Update interface quality
        new_quality = coherence * 0.5 + filtered_quality * 0.5

        return LayerInterface(
            lower_layer=interface.lower_layer,
            upper_layer=interface.upper_layer,
            coupling_strength=interface.coupling_strength,
            interface_quality=new_quality,
            buffer_type="optimized",
        )

    def _find_bridging_concepts(self, lower: List[str], upper: List[str]) -> List[str]:
        """Find concepts that naturally bridge two layers."""
        if not lower or not upper:
            return []

        lower_embeddings = [self._encode(c) for c in lower]
        upper_embeddings = [self._encode(c) for c in upper]

        # Find pairs with high similarity
        bridges = []
        for i, lower_emb in enumerate(lower_embeddings):
            for j, upper_emb in enumerate(upper_embeddings):
                similarity = np.dot(lower_emb, upper_emb)
                if similarity > 0.7:
                    bridges.append(f"[{lower[i][:50]} ↔ {upper[j][:50]}]")

        return bridges

    def _compute_coherence(self, lower: List[str], upper: List[str]) -> float:
        """Compute semantic coherence between layers."""
        if not lower or not upper:
            return 0.5

        lower_emb = np.mean([self._encode(c) for c in lower], axis=0)
        upper_emb = np.mean([self._encode(c) for c in upper], axis=0)

        # Cosine similarity
        similarity = np.dot(lower_emb, upper_emb) / (
            np.linalg.norm(lower_emb) * np.linalg.norm(upper_emb) + 1e-8
        )

        return float((similarity + 1) / 2)  # Scale to 0-1

    def _filter_for_compatibility(self, lower: List[str], upper: List[str]) -> float:
        """Estimate quality if incompatible content is filtered."""
        if not lower or not upper:
            return 0.5

        # Simple heuristic: more shared vocabulary = better compatibility
        lower_words = set(" ".join(lower).lower().split())
        upper_words = set(" ".join(upper).lower().split())

        overlap = len(lower_words & upper_words)
        total = len(lower_words | upper_words)

        return overlap / total if total > 0 else 0.5

    def _encode(self, text: str) -> np.ndarray:
        """Encode text to embedding vector."""
        if hasattr(self.embedding_model, "encode"):
            result = self.embedding_model.encode(text)
            if isinstance(result, np.ndarray):
                return result
            return np.array(result, dtype=np.float32)

        # Fallback: random embedding
        return np.random.randn(768).astype(np.float32)
