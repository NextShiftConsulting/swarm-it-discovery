"""
Paradigm 4: Layered Stack (3D Circuits)

Inspired by 3D integrated hybrid circuits from Nature Electronics.
Implements: Foundation → Derived layers with quality propagation

Hardware Analogy: Circuit stacking with interface quality management
"""

from yrsn.strategies.layered_stack.stack import LayeredContextStack, ContextLayer
from yrsn.strategies.layered_stack.interface import LayerInterface, InterfaceOptimizer
from yrsn.strategies.layered_stack.complementary import ComplementaryContextPair

__all__ = [
    "LayeredContextStack",
    "ContextLayer",
    "LayerInterface",
    "InterfaceOptimizer",
    "ComplementaryContextPair",
]

