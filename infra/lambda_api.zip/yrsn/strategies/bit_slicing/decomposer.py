"""Decomposes context into granularity slices."""

from typing import Dict

from yrsn.strategies.bit_slicing.sliced_context import SlicedContext
from yrsn.core.base import LLMClient


class GranularityDecomposer:
    """
    Decomposes content into multiple granularity slices.

    Similar to how the RRAM paper slices a matrix:
    A → [A₀, A₁, A₂, A₃] where each is 3-bit

    We slice context:
    Document → [Core, Details, Background, Tangential]

    Args:
        llm_client: LLM client for analyzing and categorizing content
    """

    # Mapping from category name to slice level
    LEVEL_MAP: Dict[str, int] = {
        "CORE": 0,
        "DETAIL": 1,
        "BACKGROUND": 2,
        "TANGENTIAL": 3,
    }

    def __init__(self, llm_client: LLMClient):
        self.llm = llm_client

    def decompose(self, content: str, query: str) -> SlicedContext:
        """
        Decompose content into granularity slices relative to query.

        Args:
            content: The content to decompose
            query: The query that provides context for categorization

        Returns:
            SlicedContext with content organized by importance level
        """
        prompt = self._build_prompt(content, query)
        response = self.llm.complete(prompt)
        return self._parse_response(response)

    def _build_prompt(self, content: str, query: str) -> str:
        """Build prompt for LLM to categorize content."""
        return f"""Analyze this content relative to the query and categorize each piece of information.

Query: {query}

Content: {content}

Categorize each distinct piece of information into one of:
- CORE: Directly answers the query, essential facts
- DETAIL: Supporting details, examples, elaborations
- BACKGROUND: Contextual information helpful for understanding
- TANGENTIAL: Related but not essential information

Format as:
CORE: [information]
DETAIL: [information]
BACKGROUND: [information]
TANGENTIAL: [information]
"""

    def _parse_response(self, response: str) -> SlicedContext:
        """Parse LLM response into SlicedContext."""
        sliced = SlicedContext()

        for line in response.split("\n"):
            line = line.strip()
            if not line:
                continue

            for prefix, level in self.LEVEL_MAP.items():
                if line.startswith(prefix + ":"):
                    info = line[len(prefix) + 1 :].strip()
                    # Filter out placeholder text
                    if info and info != "[information]" and len(info) > 5:
                        sliced.add_slice(level=level, content=info, source="decomposed")
                    break

        return sliced
