"""Bit-sliced retrieval system."""

from typing import Any, Dict, List

from yrsn.strategies.bit_slicing.decomposer import GranularityDecomposer
from yrsn.strategies.bit_slicing.sliced_context import SlicedContext


class BitSlicedRetrieval:
    """
    Retrieval system that naturally produces bit-sliced context.

    Uses multiple retrieval strategies corresponding to different
    precision levels, then combines them with appropriate weights.

    Similar to how the RRAM paper uses multiple bit-sliced arrays
    and combines results with shift-and-add.

    Args:
        keyword_retriever: Fast, coarse retriever (like A₃)
        semantic_retriever: Medium precision retriever (like A₁, A₂)
        rerank_retriever: High precision retriever (like A₀)
        decomposer: Optional decomposer for further slicing
    """

    def __init__(
        self,
        keyword_retriever: Any,
        semantic_retriever: Any,
        rerank_retriever: Any,
        decomposer: GranularityDecomposer = None,
    ):
        self.retrievers = {
            3: keyword_retriever,  # Lowest precision slice
            1: semantic_retriever,  # Medium precision
            0: rerank_retriever,  # Highest precision slice
        }
        self.decomposer = decomposer

    def retrieve_sliced(
        self, query: str, slices_to_use: List[int] = None
    ) -> SlicedContext:
        """
        Retrieve context at multiple precision levels.

        Analogous to:
        - Running LP-MVM on each slice matrix
        - Combining with shift-and-add

        Args:
            query: Query string
            slices_to_use: List of slice levels to use (default: [0, 1, 3])

        Returns:
            SlicedContext with results from multiple retrievers
        """
        if slices_to_use is None:
            slices_to_use = [0, 1, 3]

        sliced = SlicedContext()

        for slice_level in slices_to_use:
            if slice_level not in self.retrievers:
                continue

            retriever = self.retrievers[slice_level]
            results = self._retrieve(retriever, query)

            for result in results:
                # Confidence based on retriever precision
                confidence = 1.0 - (slice_level * 0.1)

                sliced.add_slice(
                    level=slice_level,
                    content=result["text"],
                    source=result.get("source", "unknown"),
                    confidence=confidence * result.get("score", 1.0),
                )

        return sliced

    def adaptive_precision_retrieve(
        self, query: str, target_precision_bits: int = 12
    ) -> SlicedContext:
        """
        Retrieve with just enough slices for target precision.

        If query is simple, fewer slices needed.
        If query is complex, more slices activated.

        Analogous to adaptive precision in the RRAM paper where
        well-conditioned matrices need fewer iterations.

        Args:
            query: Query string
            target_precision_bits: Target precision in bits

        Returns:
            SlicedContext with adaptive number of slices
        """
        # Estimate query complexity (condition number analog)
        complexity = self._estimate_complexity(query)

        # Determine which slices to use
        # Higher complexity = need more slices
        if complexity < 0.3:
            slices = [0]  # Just highest precision
        elif complexity < 0.6:
            slices = [0, 1]
        elif complexity < 0.8:
            slices = [0, 1, 2]
        else:
            slices = [0, 1, 2, 3]  # All slices

        return self.retrieve_sliced(query, slices)

    def _retrieve(self, retriever: Any, query: str) -> List[Dict[str, Any]]:
        """Retrieve using a specific retriever."""
        if hasattr(retriever, "retrieve"):
            results = retriever.retrieve(query)
            # Convert to dict format if needed
            if results and hasattr(results[0], "__dict__"):
                # Use YRSN α (quality score) instead of generic relevance_score
                return [{"text": r.content, "score": r.alpha} for r in results]
            return results
        return []

    def assign_slice_from_rsn(self, R: float, S: float, N: float) -> int:
        """
        Assign slice level based on YRSN decomposition.

        YRSN mapping to bit-slices:
        - Slice 0 (Core): High R content (R > 0.7)
        - Slice 1 (Detail): Medium R, low N (R > 0.4, N < 0.2)
        - Slice 2 (Background): High S content (S > 0.5)
        - Slice 3 (Tangential): High N content (candidate for removal)

        Args:
            R: Relevant component score (0-1)
            S: Superfluous component score (0-1)
            N: Noise component score (0-1)

        Returns:
            Slice level (0-3)
        """
        if R > 0.7:
            return 0  # Core - most significant slice
        elif R > 0.4 and N < 0.2:
            return 1  # Detail - supporting information
        elif S > 0.5:
            return 2  # Background - neutral context
        else:
            return 3  # Tangential/Noise - least significant

    def _estimate_complexity(self, query: str) -> float:
        """
        Estimate query complexity.

        Analogous to condition number in the matrix paper -
        well-conditioned (simple) queries need less precision.

        Returns:
            Complexity score in [0, 1]
        """
        word_count = len(query.split())
        has_multiple_parts = any(sep in query for sep in ["and", "or", "but", ";", ","])
        is_open_ended = any(
            w in query.lower() for w in ["how", "why", "explain", "compare"]
        )

        complexity = 0.0
        complexity += min(word_count / 30, 0.3)
        complexity += 0.2 if has_multiple_parts else 0.0
        complexity += 0.3 if is_open_ended else 0.0

        return min(complexity, 1.0)
