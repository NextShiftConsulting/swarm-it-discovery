"""
Paradigm 2: Bit-Slicing (Multi-Granularity)

Inspired by bit-slicing decomposition from RRAM matrix solving paper.
Implements: A = 2⁰A₀ + 2³A₁ + 2⁶A₂ + ...

Hardware Analogy: Multi-bit precision levels (MSB, Middle, LSB)
"""

from yrsn.strategies.bit_slicing.sliced_context import SlicedContext, ContextSlice
from yrsn.strategies.bit_slicing.decomposer import GranularityDecomposer
from yrsn.strategies.bit_slicing.retrieval import BitSlicedRetrieval

__all__ = [
    "SlicedContext",
    "ContextSlice",
    "GranularityDecomposer",
    "BitSlicedRetrieval",
]

