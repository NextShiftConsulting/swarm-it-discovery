"""Multi-granularity context representation using bit-slicing."""

from dataclasses import dataclass, field
from typing import Callable, Dict, List

import numpy as np
import numpy.typing as npt


@dataclass
class ContextSlice:
    """
    A single granularity slice of context.

    Analogous to a single bit-slice in the RRAM paper (e.g., A₀, A₁, A₂).
    Each slice represents information at a specific importance level.

    Attributes:
        level: Slice level (0 = most significant, higher = less significant)
        weight: Importance weight (typically 2^(-level * m))
        content: Text content of this slice
        source: Source identifier
        confidence: Confidence score for this slice (0-1)
    """

    level: int
    weight: float
    content: str
    source: str
    confidence: float = 1.0


@dataclass
class SlicedContext:
    """
    Multi-granularity context representation.

    Just as the RRAM paper decomposes a high-precision matrix into
    multiple 3-bit slices (A = 2⁰A₀ + 2³A₁ + 2⁶A₂ + ...),
    we decompose context into multiple granularity levels:
    - Slice 0 (highest weight): Core facts, definitions
    - Slice 1: Supporting details, examples
    - Slice 2: Contextual background
    - Slice 3 (lowest weight): Tangential information

    Attributes:
        slices: Dictionary mapping level to list of ContextSlice objects
        slice_bit_width: Bit width per slice (analogous to 3-bit RRAM)
        max_slices: Maximum number of slices to maintain
    """

    slices: Dict[int, List[ContextSlice]] = field(default_factory=dict)
    slice_bit_width: int = 3
    max_slices: int = 4

    def add_slice(
        self, level: int, content: str, source: str, confidence: float = 1.0
    ) -> None:
        """
        Add content at a specific granularity level.

        Args:
            level: Granularity level (0 = most important)
            content: Text content
            source: Source identifier
            confidence: Confidence score (0-1)
        """
        if level not in self.slices:
            self.slices[level] = []

        weight = 2 ** (-level * self.slice_bit_width)

        self.slices[level].append(
            ContextSlice(
                level=level, weight=weight, content=content, source=source, confidence=confidence
            )
        )

    def combine(self, target_precision: int = 24) -> str:
        """
        Combine slices with shift-and-add, analogous to:
        A = 2⁰A₀ + 2⁻³A₁ + 2⁻⁶A₂ + ...

        Args:
            target_precision: Target precision in bits

        Returns:
            Formatted context string with appropriate emphasis
        """
        combined_parts = []

        # Number of slices needed for target precision
        n_slices = min(
            self.max_slices, (target_precision + self.slice_bit_width - 1) // self.slice_bit_width
        )

        for level in range(n_slices):
            if level not in self.slices:
                continue

            slices_at_level = self.slices[level]

            # Format based on importance
            if level == 0:
                header = "## Core Information (Primary)"
                format_fn = lambda s: f"**{s.content}**"
            elif level == 1:
                header = "### Supporting Details"
                format_fn = lambda s: f"• {s.content}"
            elif level == 2:
                header = "#### Background Context"
                format_fn = lambda s: f"  - {s.content}"
            else:
                header = "##### Additional Notes"
                format_fn = lambda s: f"    · {s.content}"

            combined_parts.append(header)
            for slice_item in slices_at_level:
                combined_parts.append(format_fn(slice_item))

        return "\n".join(combined_parts)

    def get_weighted_embedding(
        self, embedding_fn: Callable[[str], npt.NDArray[np.float32]]
    ) -> npt.NDArray[np.float32]:
        """
        Compute weighted combination of slice embeddings.

        Analogous to the shift-and-add in HP-MVM where partial results
        are combined with appropriate weights.

        Args:
            embedding_fn: Function that converts text to embedding vector

        Returns:
            Weighted average embedding vector
        """
        embeddings = []
        weights = []

        for level, slices_at_level in self.slices.items():
            for slice_item in slices_at_level:
                emb = embedding_fn(slice_item.content)
                embeddings.append(emb)
                weights.append(slice_item.weight * slice_item.confidence)

        if not embeddings:
            return np.zeros(768, dtype=np.float32)  # Default embedding size

        embeddings_array = np.array(embeddings, dtype=np.float32)
        weights_array = np.array(weights, dtype=np.float32)

        # Normalize weights
        if weights_array.sum() > 0:
            weights_array = weights_array / weights_array.sum()

        return np.sum(embeddings_array * weights_array[:, np.newaxis], axis=0)

    def get_slices_for_precision(self, target_precision: int) -> List[ContextSlice]:
        """
        Get only the slices needed for target precision.

        Args:
            target_precision: Target precision in bits

        Returns:
            List of ContextSlice objects needed
        """
        n_slices = min(
            self.max_slices, (target_precision + self.slice_bit_width - 1) // self.slice_bit_width
        )

        result = []
        for level in range(n_slices):
            if level in self.slices:
                result.extend(self.slices[level])

        return result
