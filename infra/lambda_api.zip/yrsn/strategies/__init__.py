"""
YRSN Strategies: Reusable Context Engineering Patterns

Five strategies for applying YRSN decomposition:

1. Iterative Refinement (HP-INV inspired)
   - Coarse retrieval → residual analysis → precise refinement

2. Bit-Slicing (RRAM inspired)
   - Multi-granularity context representation

3. Hierarchical Decomposition (BlockAMC inspired)
   - Systematic breakdown of large contexts

4. Layered Architecture (3D stacking inspired)
   - Stack management with interface quality propagation

5. Self-Calibration
   - Learn optimal parameters from execution traces
"""

from yrsn.strategies.iterative_refinement import (
    IterativeContextEngine,
    CoarseRetriever,
    FineRetriever,
    ResidualAnalyzer,
)

from yrsn.strategies.bit_slicing import (
    SlicedContext,
    ContextSlice,
    GranularityDecomposer,
    BitSlicedRetrieval,
)

from yrsn.strategies.hierarchical_decomposition import (
    HierarchicalContextDecomposer,
    BlockAMCProcessor,
    ComplexQueryDecomposer,
    ContextBlock,
    BlockType,
)

from yrsn.strategies.layered_stack import (
    LayeredContextStack,
    ContextLayer,
    LayerInterface,
    InterfaceOptimizer,
    ComplementaryContextPair,
)

from yrsn.strategies.self_calibration import (
    YRSNSelfCalibrator,
    YRSNExecutionTrace,
)

__all__ = [
    # Iterative
    "IterativeContextEngine",
    "CoarseRetriever",
    "FineRetriever",
    "ResidualAnalyzer",
    # Bit-slicing
    "SlicedContext",
    "ContextSlice",
    "GranularityDecomposer",
    "BitSlicedRetrieval",
    # Hierarchical
    "HierarchicalContextDecomposer",
    "BlockAMCProcessor",
    "ComplexQueryDecomposer",
    "ContextBlock",
    "BlockType",
    # Layered
    "LayeredContextStack",
    "ContextLayer",
    "LayerInterface",
    "InterfaceOptimizer",
    "ComplementaryContextPair",
    # Self-Calibration
    "YRSNSelfCalibrator",
    "YRSNExecutionTrace",
]
