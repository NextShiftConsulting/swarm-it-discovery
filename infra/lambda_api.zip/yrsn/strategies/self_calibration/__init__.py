"""
Self-Calibration Strategy: Learn Optimal Parameters from Execution

The 5th YRSN paradigm - automatically adjusts parameters based on
comparing what YRSN predicted vs. what actually worked.

Adjusts:
- Bit-slice weights (Level 0/1/2 importance)
- Instruction boost factors
- Precision thresholds

Best for: Long-running systems where continuous optimization matters.
"""

from yrsn.strategies.self_calibration.calibrator import (
    YRSNSelfCalibrator,
    YRSNExecutionTrace,
)

__all__ = [
    "YRSNSelfCalibrator",
    "YRSNExecutionTrace",
]
