"""
YRSN Self-Calibration: Learn from Execution Traces

Inspired by the context compression framework's self-calibration loop.

Automatically adjusts YRSN parameters based on CTM attention patterns:
- Bit-slice weights (0.5, 0.3, 0.2)
- Instruction boost factors
- Hierarchical decomposition priorities

The system learns from misalignments between:
- What YRSN classified as important
- What CTM actually attended to
- Whether deductions were correct

This is CRITICAL for optimal performance!
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import numpy as np
import torch


@dataclass
class YRSNExecutionTrace:
    """
    Execution trace for YRSN self-calibration.

    Records what happened during one reasoning step:
    - YRSN's classification (which cells/constraints were important)
    - CTM's attention (what CTM actually used)
    - Result (whether the deduction was correct)
    """
    # YRSN classifications
    cell_importance: np.ndarray  # [num_cells] - YRSN's importance scores
    constraint_importance: Dict[str, float]  # Constraint ID -> importance

    # CTM actual usage
    ctm_attention_weights: np.ndarray  # [num_cells] - What CTM attended to

    # Result
    deduction_correct: bool
    deduction_confidence: float
    cells_deduced: List[int]  # Which cells were filled

    # Context
    puzzle_id: str
    iteration: int
    precision_level: int  # Which bit-slicing level was used
    bit_slice_weights: Tuple[float, float, float]  # Weights at this iteration

    # Optional fields
    ctm_internal_states: Optional[torch.Tensor] = None  # [num_ticks, num_cells, hidden_dim]
    timestamp: Optional[float] = None


class YRSNSelfCalibrator:
    """
    Self-calibration for YRSN reasoning system.

    Learns optimal parameters by comparing:
    - YRSN's predictions (what should be important)
    - CTM's behavior (what it actually used)
    - Results (whether deductions were correct)

    Adjusts:
    1. Bit-slice weights (Level 0/1/2 importance)
    2. Instruction boost factors
    3. Precision thresholds for adaptive computation
    """

    def __init__(
        self,
        learning_rate: float = 0.1,
        min_traces_for_calibration: int = 20,
        false_positive_threshold: float = 0.3,
        false_negative_threshold: float = 0.3
    ):
        """
        Initialize self-calibrator.

        Args:
            learning_rate: How much to adjust parameters (0.1 = 10% adjustment)
            min_traces_for_calibration: Need this many traces before calibrating
            false_positive_threshold: Max acceptable false positive rate
            false_negative_threshold: Max acceptable false negative rate
        """
        self.learning_rate = learning_rate
        self.min_traces = min_traces_for_calibration
        self.fp_threshold = false_positive_threshold
        self.fn_threshold = false_negative_threshold

        # Storage
        self.traces: List[YRSNExecutionTrace] = []

        # Statistics
        self.false_positive_rates: List[float] = []
        self.false_negative_rates: List[float] = []
        self.calibration_history: List[Dict] = []

    def record_trace(self, trace: YRSNExecutionTrace):
        """
        Record execution trace for later calibration.

        Args:
            trace: Execution trace from one reasoning step
        """
        self.traces.append(trace)

        # Compute error rates for this trace
        fp_rate = self._compute_false_positive_rate(trace)
        fn_rate = self._compute_false_negative_rate(trace)

        self.false_positive_rates.append(fp_rate)
        self.false_negative_rates.append(fn_rate)

    def _compute_false_positive_rate(self, trace: YRSNExecutionTrace) -> float:
        """
        Compute false positive rate: YRSN said important, CTM didn't use.

        False positive = We thought cell was important, but CTM ignored it
        """
        yrsn_important = trace.cell_importance > 0.5  # YRSN marked as important
        ctm_used = trace.ctm_attention_weights > 0.1  # CTM actually attended

        false_positives = np.sum(yrsn_important & ~ctm_used)
        total_yrsn_important = np.sum(yrsn_important)

        if total_yrsn_important == 0:
            return 0.0

        return false_positives / total_yrsn_important

    def _compute_false_negative_rate(self, trace: YRSNExecutionTrace) -> float:
        """
        Compute false negative rate: YRSN said unimportant, CTM needed it.

        False negative = We thought cell was unimportant, but CTM needed it
        """
        yrsn_important = trace.cell_importance > 0.5
        ctm_used = trace.ctm_attention_weights > 0.1

        false_negatives = np.sum(~yrsn_important & ctm_used)
        total_ctm_used = np.sum(ctm_used)

        if total_ctm_used == 0:
            return 0.0

        return false_negatives / total_ctm_used

    def calibrate(
        self,
        current_bit_slice_weights: Tuple[float, float, float],
        current_instruction_boost: float
    ) -> Dict:
        """
        Calibrate YRSN parameters based on accumulated traces.

        Analyzes misalignments and adjusts parameters to reduce them.

        Args:
            current_bit_slice_weights: Current (w0, w1, w2) weights
            current_instruction_boost: Current instruction boost factor

        Returns:
            {
                'status': 'calibrated' | 'insufficient_traces' | 'no_adjustment_needed',
                'new_bit_slice_weights': Tuple[float, float, float],
                'new_instruction_boost': float,
                'mean_fp_rate': float,
                'mean_fn_rate': float,
                'adjustment_magnitude': float,
                'recommendation': str
            }
        """
        if len(self.traces) < self.min_traces:
            return {
                'status': 'insufficient_traces',
                'traces_collected': len(self.traces),
                'traces_needed': self.min_traces
            }

        # Compute average error rates (recent traces only)
        recent_window = min(self.min_traces, len(self.false_positive_rates))
        avg_fp = np.mean(self.false_positive_rates[-recent_window:])
        avg_fn = np.mean(self.false_negative_rates[-recent_window:])

        print(f"\n[Self-Calibration] Analyzing {len(self.traces)} traces...")
        print(f"  Avg false positive rate: {avg_fp:.3f} (threshold: {self.fp_threshold})")
        print(f"  Avg false negative rate: {avg_fn:.3f} (threshold: {self.fn_threshold})")

        # Decide on adjustments
        new_weights = list(current_bit_slice_weights)
        new_boost = current_instruction_boost
        adjustments_made = []

        # CASE 1: Too many false positives (over-emphasizing)
        if avg_fp > self.fp_threshold:
            # Flatten bit-slice weights (reduce emphasis on Level 0)
            adjustment = self.learning_rate * (avg_fp - self.fp_threshold)
            new_weights[0] -= adjustment  # Reduce Level 0
            new_weights[1] += adjustment / 2  # Increase Level 1
            new_weights[2] += adjustment / 2  # Increase Level 2

            adjustments_made.append(
                f"Flattened bit-slice weights (FP rate {avg_fp:.3f} > {self.fp_threshold})"
            )

        # CASE 2: Too many false negatives (under-emphasizing)
        if avg_fn > self.fn_threshold:
            # Sharpen bit-slice weights (increase emphasis on Level 0)
            adjustment = self.learning_rate * (avg_fn - self.fn_threshold)
            new_weights[0] += adjustment  # Increase Level 0
            new_weights[1] -= adjustment / 2  # Decrease Level 1
            new_weights[2] -= adjustment / 2  # Decrease Level 2

            adjustments_made.append(
                f"Sharpened bit-slice weights (FN rate {avg_fn:.3f} > {self.fn_threshold})"
            )

        # CASE 3: CTM not using instructions enough
        avg_instruction_attention = self._compute_avg_instruction_attention()
        if avg_instruction_attention < 0.15:  # Less than 15% on instructions
            # Increase instruction boost
            new_boost = current_instruction_boost * 1.2

            adjustments_made.append(
                f"Increased instruction boost (attention {avg_instruction_attention:.3f} < 0.15)"
            )

        # Normalize weights
        weight_sum = sum(new_weights)
        new_weights = tuple(w / weight_sum for w in new_weights)

        # Compute adjustment magnitude
        weight_change = np.linalg.norm(
            np.array(new_weights) - np.array(current_bit_slice_weights)
        )
        boost_change = abs(new_boost - current_instruction_boost)
        total_adjustment = weight_change + boost_change

        # Record calibration
        calibration_record = {
            'timestamp': len(self.calibration_history),
            'traces_analyzed': len(self.traces),
            'old_weights': current_bit_slice_weights,
            'new_weights': new_weights,
            'old_boost': current_instruction_boost,
            'new_boost': new_boost,
            'fp_rate': avg_fp,
            'fn_rate': avg_fn,
            'adjustments': adjustments_made
        }
        self.calibration_history.append(calibration_record)

        # Determine status
        if len(adjustments_made) == 0:
            status = 'no_adjustment_needed'
            recommendation = "Parameters are well-calibrated. Continue monitoring."
        else:
            status = 'calibrated'
            recommendation = "; ".join(adjustments_made)

        result = {
            'status': status,
            'new_bit_slice_weights': new_weights,
            'new_instruction_boost': new_boost,
            'mean_fp_rate': avg_fp,
            'mean_fn_rate': avg_fn,
            'adjustment_magnitude': total_adjustment,
            'recommendation': recommendation,
            'adjustments_made': len(adjustments_made)
        }

        print(f"\n[Self-Calibration] {status.upper()}")
        if status == 'calibrated':
            print(f"  Old weights: {current_bit_slice_weights}")
            print(f"  New weights: {new_weights}")
            print(f"  Old boost: {current_instruction_boost:.2f}")
            print(f"  New boost: {new_boost:.2f}")
            print(f"  Adjustments: {adjustments_made}")
        else:
            print(f"  {recommendation}")

        return result

    def _compute_avg_instruction_attention(self) -> float:
        """
        Compute average CTM attention to instruction tokens.

        Assumes first 10% of tokens are instructions (rules + task).
        """
        if not self.traces:
            return 0.0

        instruction_attentions = []
        for trace in self.traces[-self.min_traces:]:
            # Assume first 10% are instruction tokens
            num_instruction_tokens = max(1, int(len(trace.ctm_attention_weights) * 0.1))
            instruction_attn = np.mean(trace.ctm_attention_weights[:num_instruction_tokens])
            instruction_attentions.append(instruction_attn)

        return np.mean(instruction_attentions)

    def get_statistics(self) -> Dict:
        """
        Get calibration statistics.

        Returns:
            {
                'total_traces': int,
                'calibrations_performed': int,
                'current_fp_rate': float,
                'current_fn_rate': float,
                'fp_rate_trend': 'improving' | 'stable' | 'worsening',
                'fn_rate_trend': 'improving' | 'stable' | 'worsening'
            }
        """
        if not self.traces:
            return {'status': 'no_traces'}

        recent_window = min(10, len(self.false_positive_rates))
        current_fp = np.mean(self.false_positive_rates[-recent_window:])
        current_fn = np.mean(self.false_negative_rates[-recent_window:])

        # Compute trends
        def compute_trend(rates: List[float]) -> str:
            if len(rates) < 20:
                return 'insufficient_data'

            recent = np.mean(rates[-10:])
            older = np.mean(rates[-20:-10])

            if recent < older * 0.9:
                return 'improving'
            elif recent > older * 1.1:
                return 'worsening'
            else:
                return 'stable'

        return {
            'status': 'ok',
            'total_traces': len(self.traces),
            'calibrations_performed': len(self.calibration_history),
            'current_fp_rate': current_fp,
            'current_fn_rate': current_fn,
            'fp_rate_trend': compute_trend(self.false_positive_rates),
            'fn_rate_trend': compute_trend(self.false_negative_rates),
            'needs_calibration': current_fp > self.fp_threshold or current_fn > self.fn_threshold
        }

    def reset_traces(self):
        """Clear accumulated traces (after calibration or for new puzzle set)."""
        self.traces = []
        self.false_positive_rates = []
        self.false_negative_rates = []


def example_usage():
    """Demonstrate self-calibration."""
    print("=" * 80)
    print("YRSN SELF-CALIBRATION EXAMPLE")
    print("=" * 80)

    calibrator = YRSNSelfCalibrator(
        learning_rate=0.15,
        min_traces_for_calibration=20
    )

    # Simulate 25 execution traces
    np.random.seed(42)

    current_weights = (0.5, 0.3, 0.2)
    current_boost = 1.5

    for i in range(25):
        # Simulate YRSN importance (biased toward certain cells)
        cell_importance = np.random.beta(2, 5, size=81)

        # Simulate CTM attention (diverges from YRSN - creates learning signal)
        ctm_attention = np.random.beta(3, 7, size=81)

        # Simulate that CTM attended more to cells YRSN thought were unimportant
        # This creates false negatives
        low_importance_cells = cell_importance < 0.3
        ctm_attention[low_importance_cells] *= 2.0  # CTM needed these!

        # Normalize
        ctm_attention = ctm_attention / ctm_attention.sum()

        trace = YRSNExecutionTrace(
            cell_importance=cell_importance,
            constraint_importance={'killer_A': 0.8, 'thermo_B': 0.6},
            ctm_attention_weights=ctm_attention,
            deduction_correct=np.random.rand() > 0.2,  # 80% correct
            deduction_confidence=np.random.beta(8, 2),
            cells_deduced=[np.random.randint(0, 81)],
            puzzle_id=f"puzzle_{i % 5}",
            iteration=i,
            precision_level=2,
            bit_slice_weights=current_weights
        )

        calibrator.record_trace(trace)

        if (i + 1) % 10 == 0:
            print(f"\nCollected {i + 1} traces...")
            stats = calibrator.get_statistics()
            print(f"  Current FP rate: {stats['current_fp_rate']:.3f}")
            print(f"  Current FN rate: {stats['current_fn_rate']:.3f}")

    # Run calibration
    print("\n" + "=" * 80)
    print("RUNNING CALIBRATION")
    print("=" * 80)

    result = calibrator.calibrate(current_weights, current_boost)

    print(f"\nCalibration result:")
    print(f"  Status: {result['status']}")
    print(f"  Adjustments made: {result['adjustments_made']}")
    print(f"  Adjustment magnitude: {result['adjustment_magnitude']:.4f}")

    # Show final statistics
    print("\n" + "=" * 80)
    print("FINAL STATISTICS")
    print("=" * 80)

    stats = calibrator.get_statistics()
    print(f"  Total traces analyzed: {stats['total_traces']}")
    print(f"  Calibrations performed: {stats['calibrations_performed']}")
    print(f"  FP rate trend: {stats['fp_rate_trend']}")
    print(f"  FN rate trend: {stats['fn_rate_trend']}")
    print(f"  Needs calibration: {stats['needs_calibration']}")

    print("\n" + "=" * 80)
    print("KEY INSIGHT")
    print("=" * 80)

    print("""
    Self-calibration LEARNS optimal parameters from execution:

    1. Record what YRSN predicted (cell importance)
    2. Record what CTM actually used (attention weights)
    3. Compare and compute error rates:
       - False positives: YRSN said important, CTM ignored
       - False negatives: YRSN said unimportant, CTM needed

    4. Adjust parameters to reduce errors:
       - Too many FP? Flatten weights (reduce Level 0 emphasis)
       - Too many FN? Sharpen weights (increase Level 0 emphasis)
       - CTM ignoring instructions? Increase instruction boost

    This is AUTOMATIC parameter tuning based on real behavior!
    """)


if __name__ == "__main__":
    example_usage()
