"""Residual analysis for iterative refinement."""

from typing import List

from yrsn.core.base import LLMClient
from yrsn.core.types import ContextBlock


class ResidualAnalyzer:
    """
    Analyzes what's "missing" from current context relative to query.

    Analogous to computing r^(k+1) = r^(k) - A Δx^(k) in the HP-INV algorithm.
    The residual represents unsatisfied information needs.

    Args:
        llm_client: LLM client for analyzing gaps in context
    """

    def __init__(self, llm_client: LLMClient):
        self.llm = llm_client

    def compute_residual(
        self, original_query: str, current_context: List[ContextBlock]
    ) -> List[str]:
        """
        Identify sub-queries that current context doesn't address.

        Args:
            original_query: The original user query
            current_context: Context blocks retrieved so far

        Returns:
            List of "residual queries" - information still needed
        """
        if not current_context:
            # No context yet, original query is the residual
            return [original_query]

        # Summarize current context
        context_summary = self._summarize_context(current_context)

        # Generate prompt for LLM to identify gaps
        prompt = self._build_prompt(original_query, context_summary)

        # Get LLM response
        response = self.llm.complete(prompt)

        # Parse residual queries from response
        return self._parse_residual_queries(response)

    def _summarize_context(self, context: List[ContextBlock], max_items: int = 10) -> str:
        """Create a concise summary of current context."""
        summary_lines = []
        for i, block in enumerate(context[:max_items], 1):
            # Truncate long content
            content_preview = block.content[:200]
            if len(block.content) > 200:
                content_preview += "..."
            summary_lines.append(f"{i}. {content_preview}")

        return "\n".join(summary_lines)

    def _build_prompt(self, query: str, context_summary: str) -> str:
        """Build prompt for LLM to identify information gaps."""
        return f"""Given this query and retrieved context, identify what information is still missing.

Original Query: {query}

Retrieved Context:
{context_summary}

List 1-3 specific follow-up queries that would fill gaps in the current context.
Return only the queries, one per line. If context is sufficient, return "NONE".
"""

    def _parse_residual_queries(self, response: str) -> List[str]:
        """Parse residual queries from LLM response."""
        # Check if context is sufficient
        if "NONE" in response.upper():
            return []

        # Split response into lines and filter
        queries = []
        for line in response.strip().split("\n"):
            line = line.strip()
            # Remove numbering if present (e.g., "1. ", "- ")
            for prefix in ["1.", "2.", "3.", "-", "*"]:
                if line.startswith(prefix):
                    line = line[len(prefix) :].strip()
                    break

            if line and len(line) > 10:  # Reasonable query length
                queries.append(line)

        return queries[:3]  # Limit to 3 residual queries
