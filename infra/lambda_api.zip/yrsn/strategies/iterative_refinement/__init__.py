"""
Paradigm 1: Iterative Refinement (HP-INV)

Inspired by HP-INV algorithm from RRAM matrix solving paper.
Implements: Coarse → Residual → Fine → Iterate

Hardware Analogy: LP-INV (fast approximate) + HP-MVM (precise refinement)
"""

from yrsn.strategies.iterative_refinement.engine import IterativeContextEngine
from yrsn.strategies.iterative_refinement.residual import ResidualAnalyzer
from yrsn.strategies.iterative_refinement.retrievers import CoarseRetriever, FineRetriever

__all__ = [
    "IterativeContextEngine",
    "CoarseRetriever",
    "FineRetriever",
    "ResidualAnalyzer",
]

