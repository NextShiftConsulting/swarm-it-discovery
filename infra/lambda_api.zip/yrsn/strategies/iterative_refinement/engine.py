"""Main engine for iterative context refinement."""

from typing import List, Set

from yrsn.core.types import ContextBlock, RefinementState
from yrsn.strategies.iterative_refinement.residual import ResidualAnalyzer
from yrsn.strategies.iterative_refinement.retrievers import CoarseRetriever, FineRetriever


class IterativeContextEngine:
    """
    Main engine implementing iterative refinement for context retrieval.

    Inspired by the HP-INV algorithm from the RRAM matrix solving paper:
    1. Initial coarse retrieval (like LP-INV giving approximate solution)
    2. Compute residual (what's missing from current context)
    3. Refine with high-precision retrieval (like HP-MVM)
    4. Update context and check convergence

    The algorithm iterates until either:
    - Precision threshold is met
    - Maximum iterations reached
    - Convergence rate drops below threshold

    Args:
        coarse_retriever: Fast, approximate retriever
        fine_retriever: Slow, precise retriever
        residual_analyzer: Analyzer for computing information gaps
        max_iterations: Maximum number of refinement iterations
        precision_threshold: Target precision for convergence (0-1)
        min_convergence_rate: Minimum rate of improvement to continue
    """

    def __init__(
        self,
        coarse_retriever: CoarseRetriever,
        fine_retriever: FineRetriever,
        residual_analyzer: ResidualAnalyzer,
        max_iterations: int = 5,
        precision_threshold: float = 0.95,
        min_convergence_rate: float = 0.01,
    ):
        self.coarse_retriever = coarse_retriever
        self.fine_retriever = fine_retriever
        self.residual_analyzer = residual_analyzer
        self.max_iterations = max_iterations
        self.precision_threshold = precision_threshold
        self.min_convergence_rate = min_convergence_rate

    def retrieve(self, query: str) -> RefinementState:
        """
        Iterative retrieval process.

        Analogous to the HP-INV algorithm:
        - x^(0) = 0, r^(0) = b (initialization)
        - Δx^(k) = A₀⁻¹ r^(k) (LP-INV step)
        - r^(k+1) = r^(k) - A Δx^(k) (residual update via HP-MVM)
        - x^(k+1) = x^(k) + Δx^(k+1) (solution update)

        Args:
            query: The input query

        Returns:
            RefinementState with final context and convergence info
        """
        # Initialize: r^(0) = b (the full query is the initial "residual")
        state = RefinementState(
            current_context=[],
            residual_queries=[query],
            iteration=0,
            precision_achieved=0.0,
            convergence_rate=0.0,
        )

        prev_precision = 0.0

        for iteration in range(self.max_iterations):
            state.iteration = iteration

            # Step 1: Coarse retrieval on residual queries (LP-INV analog)
            # Δx^(k) = A₀⁻¹ r^(k)
            coarse_results = self._coarse_retrieval_step(state.residual_queries)

            # Step 2: Deduplicate against existing context
            # This is analogous to: Δr^(k) = A Δx^(k)
            delta_context = self._deduplicate(coarse_results, state.current_context)

            # Step 3: High-precision refinement on most relevant additions
            # Refine the Δx^(k) with high precision
            refined_additions = self._fine_refinement_step(delta_context, k=3)

            # Step 4: Update context (x^(k+1) = x^(k) + Δx^(k+1))
            state.current_context = self._merge_contexts(
                state.current_context, delta_context, refined_additions
            )

            # Step 5: Compute new residual queries
            # r^(k+1) = r^(k) - A Δx^(k)
            state.residual_queries = self.residual_analyzer.compute_residual(
                original_query=query, current_context=state.current_context
            )

            # Step 6: Check convergence
            state.precision_achieved = self._compute_precision(query, state.current_context)
            state.convergence_rate = state.precision_achieved - prev_precision
            prev_precision = state.precision_achieved

            # Convergence check (analogous to ||r^(k)|| < 2^(-t))
            if state.precision_achieved >= self.precision_threshold:
                break

            # Early termination if not converging
            if iteration > 1 and state.convergence_rate < self.min_convergence_rate:
                break

            # Early termination if no residual queries
            if not state.residual_queries:
                break

        return state

    def _coarse_retrieval_step(self, residual_queries: List[str]) -> List[ContextBlock]:
        """Perform coarse retrieval for all residual queries."""
        results = []
        for rq in residual_queries:
            results.extend(self.coarse_retriever.retrieve(rq, k=5))
        return results

    def _fine_refinement_step(
        self, delta_context: List[ContextBlock], k: int = 3
    ) -> List[ContextBlock]:
        """Perform fine-grained refinement on top candidates."""
        refined = []
        for block in delta_context[:k]:
            # Use content as query for expansion
            query_text = block.content[:200]
            fine_results = self.fine_retriever.retrieve(query_text, k=2)
            refined.extend(fine_results)
        return refined

    def _deduplicate(
        self, new_blocks: List[ContextBlock], existing: List[ContextBlock]
    ) -> List[ContextBlock]:
        """Remove duplicates and already-retrieved content."""
        existing_contents: Set[str] = {b.content for b in existing}
        return [b for b in new_blocks if b.content not in existing_contents]

    def _merge_contexts(
        self,
        existing: List[ContextBlock],
        coarse_additions: List[ContextBlock],
        fine_additions: List[ContextBlock],
    ) -> List[ContextBlock]:
        """
        Merge contexts with priority to high-precision results.

        Analogous to bit-slicing combination with weights.
        Uses YRSN decomposition: high R (relevant) and low N (noise) preferred.
        """
        # Fine results get priority (higher precision weight)
        all_blocks = existing + fine_additions + coarse_additions

        # Sort by (precision_level, α quality score, -N noise)
        # High precision, high R, low N = best
        all_blocks.sort(
            key=lambda b: (b.precision_level, b.alpha, -b.N), reverse=True
        )

        # Deduplicate keeping highest precision version
        seen_content: Set[int] = set()
        merged = []
        for block in all_blocks:
            content_hash = hash(block.content[:100])
            if content_hash not in seen_content:
                seen_content.add(content_hash)
                merged.append(block)

        return merged

    def _compute_precision(self, query: str, context: List[ContextBlock]) -> float:
        """
        Estimate how well current context addresses the query.

        Uses YRSN decomposition:
        - α = R/(R+S+N) as base quality score
        - Weight by (1-N) to penalize noisy content
        - Weight by precision level

        Returns a score in [0, 1] where 1 means perfect coverage.
        """
        if not context:
            return 0.0

        # Weighted average using YRSN metrics
        # - Precision level gives hardware-inspired weight
        # - (1-N) penalizes noise
        weights = [2**block.precision_level * (1 - block.N) for block in context]
        scores = [block.alpha for block in context]  # α = R/(R+S+N)

        if sum(weights) == 0:
            return 0.0

        return sum(w * s for w, s in zip(weights, scores)) / sum(weights)

    def _identify_residual_blocks(
        self, context: List[ContextBlock], noise_threshold: float = 0.3
    ) -> List[ContextBlock]:
        """
        Identify high-noise blocks that should be replaced.

        YRSN mapping: Residual = content with high N (noise to eliminate).

        Args:
            context: Current context blocks
            noise_threshold: Blocks with N > threshold are residual

        Returns:
            List of blocks that should be refined/replaced
        """
        return [b for b in context if b.N > noise_threshold]
