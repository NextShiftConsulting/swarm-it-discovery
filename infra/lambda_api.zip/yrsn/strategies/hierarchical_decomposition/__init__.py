"""
Paradigm 3: Hierarchical Decomposition (BlockAMC)

Inspired by BlockAMC algorithm for scalable matrix operations.
Implements: Divide → Process → Combine

Hardware Analogy: Block matrix operations (O(N³) → O(N^1.59))
"""

from yrsn.strategies.hierarchical_decomposition.decomposer import (
    HierarchicalContextDecomposer,
    ContextBlock,
    BlockType,
)
from yrsn.strategies.hierarchical_decomposition.processor import BlockAMCProcessor, BlockResult
from yrsn.strategies.hierarchical_decomposition.query import ComplexQueryDecomposer

__all__ = [
    "HierarchicalContextDecomposer",
    "BlockAMCProcessor",
    "ComplexQueryDecomposer",
    "ContextBlock",
    "BlockResult",
    "BlockType",
]

