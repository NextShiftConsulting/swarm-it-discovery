"""Hierarchical decomposition of context into block structure."""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List


class BlockType(Enum):
    """Types of context blocks, analogous to matrix block positions."""

    DIAGONAL = "diagonal"  # Independent, can be processed alone
    OFF_DIAGONAL = "off_diag"  # Depends on other blocks
    COUPLING = "coupling"  # Links between blocks


@dataclass
class ContextBlock:
    """
    A block in the hierarchical context structure.

    Analogous to a sub-matrix in BlockAMC decomposition.

    Attributes:
        id: Unique identifier for this block
        content: Text content of this block
        block_type: Type of block (diagonal, off-diagonal, coupling)
        dependencies: IDs of blocks this depends on
        level: Hierarchy level (0 = leaf, higher = more abstract)
    """

    id: str
    content: str
    block_type: BlockType
    dependencies: List[str]
    level: int


class HierarchicalContextDecomposer:
    """
    Decomposes large context problems into block structure.

    Similar to how BlockAMC partitions:
    - 16×16 matrix → 4 blocks of 8×8
    - 8×8 blocks → 4 blocks of 4×4 (if needed)

    For context:
    - Large document → sections
    - Sections → subsections
    - Subsections → paragraphs

    Args:
        base_block_size: Size of base blocks in characters (analogous to N₀ = 32)
        max_levels: Maximum recursion depth for decomposition
    """

    def __init__(self, base_block_size: int = 1000, max_levels: int = 3):
        self.base_block_size = base_block_size
        self.max_levels = max_levels

    def decompose(self, content: str, query: str) -> Dict[str, ContextBlock]:
        """
        Recursively decompose content into blocks.

        Args:
            content: The content to decompose
            query: Query for context (may influence decomposition)

        Returns:
            Dictionary mapping block_id to ContextBlock
        """
        blocks: Dict[str, ContextBlock] = {}
        self._decompose_recursive(
            content=content, query=query, level=0, parent_id="root", blocks=blocks
        )
        return blocks

    def _decompose_recursive(
        self,
        content: str,
        query: str,
        level: int,
        parent_id: str,
        blocks: Dict[str, ContextBlock],
    ) -> List[str]:
        """
        Recursive decomposition into hierarchical blocks.

        Returns:
            List of block IDs created at this level
        """
        if len(content) <= self.base_block_size or level >= self.max_levels:
            # Base case: create leaf block
            block_id = f"{parent_id}_leaf_{len(blocks)}"
            blocks[block_id] = ContextBlock(
                id=block_id,
                content=content,
                block_type=BlockType.DIAGONAL,  # Leaf blocks are independent
                dependencies=[],
                level=level,
            )
            return [block_id]

        # Split into sub-blocks (2-way split like BlockAMC's 2×2 partition)
        midpoint = len(content) // 2
        break_point = self._find_natural_break(content, midpoint)

        part1 = content[:break_point]
        part2 = content[break_point:]

        # Recursively decompose each part
        block1_ids = self._decompose_recursive(part1, query, level + 1, f"{parent_id}_1", blocks)
        block2_ids = self._decompose_recursive(part2, query, level + 1, f"{parent_id}_2", blocks)

        # Create coupling block (analogous to off-diagonal blocks M₂, M₃)
        coupling_id = f"{parent_id}_coupling_{level}"
        blocks[coupling_id] = ContextBlock(
            id=coupling_id,
            content=f"[Coupling between {block1_ids} and {block2_ids}]",
            block_type=BlockType.COUPLING,
            dependencies=block1_ids + block2_ids,
            level=level,
        )

        return block1_ids + block2_ids + [coupling_id]

    def _find_natural_break(self, content: str, target: int) -> int:
        """
        Find natural break point near target position.

        Looks for paragraph or sentence boundaries to avoid
        breaking in the middle of semantic units.

        Args:
            content: Text content
            target: Target break position

        Returns:
            Actual break position
        """
        # Look for paragraph breaks first
        search_radius = min(200, len(content) - target)
        for offset in range(search_radius):
            for delta in [offset, -offset]:
                pos = target + delta
                if 0 <= pos < len(content) - 1:
                    if content[pos : pos + 2] == "\n\n":
                        return pos + 2

        # Fall back to sentence breaks
        search_radius = min(100, len(content) - target)
        for offset in range(search_radius):
            for delta in [offset, -offset]:
                pos = target + delta
                if 0 <= pos < len(content):
                    if content[pos] in ".!?" and pos + 1 < len(content) and content[pos + 1] == " ":
                        return pos + 2

        return target
