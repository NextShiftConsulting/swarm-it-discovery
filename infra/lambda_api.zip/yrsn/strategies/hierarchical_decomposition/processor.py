"""Processes context blocks following BlockAMC-style algorithm."""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from yrsn.strategies.hierarchical_decomposition.decomposer import BlockType, ContextBlock


@dataclass
class BlockResult:
    """
    Result from processing a context block.

    Attributes:
        block_id: ID of the processed block
        output: Processed output text
        residual: Optional residual for iterative refinement
        confidence: Confidence score (0-1)
    """

    block_id: str
    output: str
    residual: Optional[str] = None
    confidence: float = 1.0


class BlockAMCProcessor:
    """
    Processes context blocks following BlockAMC-style algorithm.

    The paper's algorithm for 2×2 blocks:
    1. Step 1: INV with M₁ (process top-left independently)
    2. Step 2: MVM with M₃ (propagate to bottom using top result)
    3. Step 3: INV with M₄ (process bottom-right)
    4. Step 4: MVM with M₂ (back-propagate to top)
    5. Step 5: INV with M₁ (refine top based on bottom result)

    For context:
    1. Process independent blocks (diagonal)
    2. Propagate context to dependent blocks
    3. Process dependent blocks
    4. Refine initial blocks based on full context

    Args:
        block_processor: Processor for individual blocks
        propagator: Propagator for coupling blocks
    """

    def __init__(self, block_processor: Any, propagator: Any):
        self.block_processor = block_processor
        self.propagator = propagator

    def process_hierarchical(
        self, blocks: Dict[str, ContextBlock], query: str
    ) -> Dict[str, BlockResult]:
        """
        Process all blocks following BlockAMC order.

        Args:
            blocks: Dictionary of all blocks to process
            query: Query for context

        Returns:
            Dictionary mapping block_id to BlockResult
        """
        results: Dict[str, BlockResult] = {}

        # Step 1: Process all diagonal (independent) blocks
        diagonal_blocks = [b for b in blocks.values() if b.block_type == BlockType.DIAGONAL]

        for block in diagonal_blocks:
            results[block.id] = self._process_block(block, query, {})

        # Step 2-3: Process coupling blocks with dependencies
        coupling_blocks = [b for b in blocks.values() if b.block_type == BlockType.COUPLING]

        # Sort by level (process lower levels first)
        coupling_blocks.sort(key=lambda b: -b.level)

        for block in coupling_blocks:
            # Get results from dependencies
            dep_results = {
                dep_id: results[dep_id] for dep_id in block.dependencies if dep_id in results
            }

            results[block.id] = self._process_coupling(block, query, dep_results)

        # Step 4-5: Refine diagonal blocks based on coupling results
        for block in diagonal_blocks:
            # Find relevant coupling blocks
            relevant_couplings = [
                results[cb.id] for cb in coupling_blocks if block.id in cb.dependencies
            ]

            if relevant_couplings:
                results[block.id] = self._refine_block(
                    block, results[block.id], relevant_couplings, query
                )

        return results

    def _process_block(
        self, block: ContextBlock, query: str, context: Dict[str, BlockResult]
    ) -> BlockResult:
        """
        Process single block (INV operation analog).

        Args:
            block: Block to process
            query: Query for context
            context: Context from other blocks

        Returns:
            BlockResult with processed output
        """
        if hasattr(self.block_processor, "process"):
            return self.block_processor.process(block, query, context)

        # Fallback: simple passthrough
        return BlockResult(block_id=block.id, output=block.content, confidence=0.5)

    def _process_coupling(
        self, block: ContextBlock, query: str, dep_results: Dict[str, BlockResult]
    ) -> BlockResult:
        """
        Process coupling block (MVM operation analog).

        Propagates information between blocks.

        Args:
            block: Coupling block to process
            query: Query for context
            dep_results: Results from dependent blocks

        Returns:
            BlockResult with propagated information
        """
        if hasattr(self.propagator, "propagate"):
            return self.propagator.propagate(block, query, dep_results)

        # Fallback: combine dependent results
        combined_output = " | ".join([r.output[:100] for r in dep_results.values()])
        return BlockResult(block_id=block.id, output=combined_output, confidence=0.7)

    def _refine_block(
        self,
        block: ContextBlock,
        initial_result: BlockResult,
        coupling_results: List[BlockResult],
        query: str,
    ) -> BlockResult:
        """
        Refine block based on coupling information.

        Analogous to Step 5 (final INV with M₁).

        Args:
            block: Block to refine
            initial_result: Initial processing result
            coupling_results: Results from coupling blocks
            query: Query for context

        Returns:
            Refined BlockResult
        """
        if hasattr(self.block_processor, "refine"):
            # Combine initial result with coupling context
            combined_context = (
                f"Initial: {initial_result.output}\n"
                f"From related sections: "
                + " | ".join(cr.output[:200] for cr in coupling_results)
            )

            return self.block_processor.refine(block, initial_result, combined_context, query)

        # Fallback: return initial result
        return initial_result
