"""Complex query decomposition."""

from typing import Any, List, Tuple

from yrsn.core.base import LLMClient


class ComplexQueryDecomposer:
    """
    For complex queries (analogous to complex-valued matrices),
    decompose into multiple sub-queries.

    The paper handles complex matrices by expanding:
    ΩA = [Re(A)  -Im(A)]
         [Im(A)   Re(A)]

    For queries:
    - "What" questions → Factual retrieval
    - "Why/How" questions → Reasoning retrieval
    - Combined questions → Both, then merge

    Args:
        llm_client: LLM client for query analysis and decomposition
    """

    def __init__(self, llm_client: LLMClient):
        self.llm = llm_client

    def decompose_query(self, query: str) -> Tuple[List[str], str]:
        """
        Decompose complex query into components.

        Args:
            query: The complex query to decompose

        Returns:
            Tuple of (sub_queries, merge_strategy)
            where merge_strategy is 'single', 'sequential', 'parallel', or 'hierarchical'
        """
        prompt = self._build_prompt(query)
        response = self.llm.complete(prompt)
        return self._parse_response(response, query)

    def process_complex(self, query: str, retriever: Any, processor: Any = None) -> Any:
        """
        Process complex query using decomposition.

        Analogous to handling complex-valued matrices through
        expansion to real-valued form.

        Args:
            query: Query to process
            retriever: Retriever to use for sub-queries
            processor: Optional processor for merging results

        Returns:
            Merged results based on strategy
        """
        sub_queries, merge_strategy = self.decompose_query(query)

        if merge_strategy == "single" or len(sub_queries) <= 1:
            if hasattr(retriever, "retrieve"):
                return retriever.retrieve(query)
            return []

        # Process each sub-query
        sub_results = []
        for sq in sub_queries:
            if hasattr(retriever, "retrieve"):
                result = retriever.retrieve(sq)
                sub_results.append(result)

        # Merge based on strategy
        if merge_strategy == "parallel":
            return self._parallel_merge(sub_results, query)
        elif merge_strategy == "sequential":
            return self._sequential_merge(sub_results, query, processor)
        elif merge_strategy == "hierarchical":
            return self._hierarchical_merge(sub_results, query)

        return sub_results

    def _build_prompt(self, query: str) -> str:
        """Build prompt for query decomposition."""
        return f"""Analyze this query and decompose into simpler sub-queries if needed.

Query: {query}

If the query has multiple parts or requires different types of information, list the sub-queries.
Also specify how to combine results: sequential, parallel, or hierarchical.

Format:
SUB_QUERIES:
1. [first sub-query]
2. [second sub-query]
...
MERGE_STRATEGY: [sequential/parallel/hierarchical]

If query is simple enough, respond with:
SUB_QUERIES:
1. {query}
MERGE_STRATEGY: single
"""

    def _parse_response(self, response: str, original_query: str) -> Tuple[List[str], str]:
        """Parse LLM response into sub-queries and merge strategy."""
        sub_queries = []
        merge_strategy = "sequential"

        in_queries = False
        for line in response.split("\n"):
            line = line.strip()

            if "SUB_QUERIES:" in line:
                in_queries = True
                continue
            if "MERGE_STRATEGY:" in line:
                in_queries = False
                strategy = line.split(":", 1)[1].strip().lower()
                if strategy in ["single", "sequential", "parallel", "hierarchical"]:
                    merge_strategy = strategy
                continue

            if in_queries and line:
                # Extract query from numbered line
                if ". " in line:
                    query_text = line.split(". ", 1)[1].strip()
                    if query_text:
                        sub_queries.append(query_text)

        # Fallback if no sub-queries found
        if not sub_queries:
            sub_queries = [original_query]
            merge_strategy = "single"

        return sub_queries, merge_strategy

    def _parallel_merge(self, results: List[Any], query: str) -> List[Any]:
        """Merge results with equal weight."""
        all_content = []
        seen = set()

        for r in results:
            if isinstance(r, list):
                for item in r:
                    content = getattr(item, "content", str(item))
                    if content not in seen:
                        seen.add(content)
                        all_content.append(item)
            else:
                content = getattr(r, "content", str(r))
                if content not in seen:
                    seen.add(content)
                    all_content.append(r)

        return all_content

    def _sequential_merge(self, results: List[Any], query: str, processor: Any) -> Any:
        """Each result builds on previous."""
        if not results:
            return []

        merged = results[0]
        for r in results[1:]:
            if processor and hasattr(processor, "merge_with_context"):
                merged = processor.merge_with_context(merged, r, query)
            else:
                # Simple concatenation fallback
                if isinstance(merged, list) and isinstance(r, list):
                    merged.extend(r)
                else:
                    merged = [merged, r]

        return merged

    def _hierarchical_merge(self, results: List[Any], query: str) -> Any:
        """Recursive pairwise merging."""
        if not results:
            return []
        if len(results) == 1:
            return results[0]

        # Merge pairs
        merged = []
        for i in range(0, len(results), 2):
            if i + 1 < len(results):
                merged.append(self._merge_pair(results[i], results[i + 1], query))
            else:
                merged.append(results[i])

        return self._hierarchical_merge(merged, query)

    def _merge_pair(self, r1: Any, r2: Any, query: str) -> Any:
        """Merge two result sets."""
        return self._parallel_merge([r1, r2], query)
