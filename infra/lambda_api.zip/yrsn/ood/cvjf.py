"""
CVJF: Confidence-Variance Joint Filtering
==========================================

Mechanism for detecting hallucination risk by combining prediction
confidence with representation variance.

The key insight from VDT: Reliable samples have BOTH:
1. High prediction confidence (classifier is certain)
2. Low representation variance (encoder is stable)

Samples with high confidence but high variance are HALLUCINATION RISKS:
the model is confident despite having an unreliable representation.

Formula:
    score = α₁·confidence + α₂·variance
    With α₁ > 0, α₂ < 0: Select high-confidence + low-variance samples

YRSN Application:
    hallucination_risk = (alpha > 0.7) AND (omega < 0.5)
    "High apparent quality but low distributional alignment"

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
from collections import deque
import numpy as np


@dataclass
class CVJFConfig:
    """Configuration for Confidence-Variance Joint Filtering."""
    alpha_confidence: float = 2.0   # Weight for confidence (positive)
    alpha_variance: float = -1.0    # Weight for variance (negative)
    base_threshold: float = 0.9     # Base filtering threshold
    adaptive_threshold: bool = True # Adapt threshold to batch statistics
    hallucination_alpha_threshold: float = 0.7  # Quality above this is "confident"
    hallucination_omega_threshold: float = 0.5  # Omega below this is "unreliable"
    history_size: int = 1000        # For adaptive thresholding


class ConfidenceVarianceJointFilter(nn.Module):
    """
    Select high-quality samples for test-time adaptation or pseudo-labeling.

    VDT Insight: Reliable samples have BOTH:
    1. High prediction confidence (classifier is certain)
    2. Low representation variance (encoder is stable)

    YRSN Extension: Filter out hallucination-risk samples where
    the model appears confident (high α) but representations are
    unstable (high variance → low ω).
    """

    def __init__(self, config: Optional[CVJFConfig] = None):
        super().__init__()

        if config is None:
            config = CVJFConfig()
        self.config = config

        # Running statistics for adaptive thresholding
        self.register_buffer('score_mean', torch.tensor(0.0))
        self.register_buffer('score_std', torch.tensor(1.0))
        self.register_buffer('n_samples', torch.tensor(0))

    def compute_quality_score(
        self,
        confidence: torch.Tensor,
        variance: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute per-sample quality scores.

        Args:
            confidence: [B] - prediction confidence (e.g., max softmax)
            variance: [B] or [B, n_factors] - representation variance

        Returns:
            scores: [B] - quality scores (higher = more reliable)

        Formula: score = α₁·conf + α₂·var
        With α₁=2, α₂=-1: Rewards high confidence, penalizes high variance
        """
        if variance.dim() > 1:
            variance = variance.mean(dim=-1)  # Average across factors

        scores = (
            self.config.alpha_confidence * confidence +
            self.config.alpha_variance * variance
        )
        return scores

    def get_threshold(self, scores: torch.Tensor) -> float:
        """
        Get filtering threshold (adaptive or fixed).
        """
        if not self.config.adaptive_threshold:
            return self.config.base_threshold

        # Update running statistics
        batch_mean = scores.mean().item()
        batch_var = scores.var().item()
        n = self.n_samples.item()
        batch_size = len(scores)

        if n == 0:
            self.score_mean.fill_(batch_mean)
            self.score_std.fill_(np.sqrt(batch_var) if batch_var > 0 else 1.0)
        else:
            # Welford's online algorithm
            delta = batch_mean - self.score_mean.item()
            self.score_mean += delta * batch_size / (n + batch_size)
            # Simplified variance update
            new_var = (n * self.score_std.item()**2 + batch_size * batch_var) / (n + batch_size)
            self.score_std.fill_(np.sqrt(new_var) if new_var > 0 else 1.0)

        self.n_samples += batch_size

        # Adaptive threshold: mean + 0.5*std (select top ~30%)
        return self.score_mean.item() + 0.5 * self.score_std.item()

    def filter(
        self,
        confidence: torch.Tensor,
        variance: torch.Tensor,
        return_scores: bool = False
    ) -> torch.Tensor:
        """
        Filter samples by joint confidence-variance criterion.

        Args:
            confidence: [B] - prediction confidence
            variance: [B] or [B, n_factors] - representation variance
            return_scores: Whether to return quality scores

        Returns:
            mask: [B] - boolean mask (True = reliable sample)
            (optional) scores: [B] - quality scores
        """
        scores = self.compute_quality_score(confidence, variance)
        threshold = self.get_threshold(scores)
        mask = scores > threshold

        if return_scores:
            return mask, scores
        return mask

    def forward(
        self,
        confidence: torch.Tensor,
        variance: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Full CVJF analysis.

        Returns:
            Dictionary with scores, mask, threshold, statistics
        """
        scores = self.compute_quality_score(confidence, variance)
        threshold = self.get_threshold(scores)
        mask = scores > threshold

        return {
            'scores': scores,
            'mask': mask,
            'threshold': torch.tensor(threshold),
            'reliable_fraction': mask.float().mean(),
            'mean_score': scores.mean(),
            'std_score': scores.std(),
        }


class HallucinationDetector(nn.Module):
    """
    Detect hallucination risk: high apparent quality but low reliability.

    YRSN Definition:
        Hallucination Risk = (α > threshold) AND (ω < threshold)
        "The model thinks it knows, but it doesn't."

    This is the dangerous zone where:
    - R/S/N decomposition looks good (high α)
    - But variance is high / gates are active (low ω)
    - Model would be confidently wrong
    """

    def __init__(
        self,
        alpha_threshold: float = 0.7,
        omega_threshold: float = 0.5,
        risk_amplification: float = 2.0
    ):
        super().__init__()
        self.alpha_threshold = alpha_threshold
        self.omega_threshold = omega_threshold
        self.risk_amplification = risk_amplification

    def detect(
        self,
        alpha: torch.Tensor,
        omega: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Detect hallucination risk.

        Args:
            alpha: [B] - quality score (R / (R+S+N))
            omega: [B] - distributional alignment (1 - avg_gate)

        Returns:
            at_risk: [B] - boolean mask (True = hallucination risk)
            risk_score: [B] - continuous risk score [0, 1]
        """
        # Binary detection
        at_risk = (alpha > self.alpha_threshold) & (omega < self.omega_threshold)

        # Continuous risk score
        # Higher alpha + lower omega = more dangerous
        alpha_excess = F.relu(alpha - self.alpha_threshold)
        omega_deficit = F.relu(self.omega_threshold - omega)

        risk_score = self.risk_amplification * alpha_excess * omega_deficit

        # Normalize to [0, 1]
        risk_score = torch.sigmoid(risk_score)

        return at_risk, risk_score

    def forward(
        self,
        alpha: torch.Tensor,
        omega: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Full hallucination analysis.
        """
        at_risk, risk_score = self.detect(alpha, omega)

        return {
            'at_risk': at_risk,
            'risk_score': risk_score,
            'risk_fraction': at_risk.float().mean(),
            'max_risk': risk_score.max(),
            'mean_risk': risk_score.mean(),
        }

    def get_remediation(self, risk_score: torch.Tensor) -> Dict[str, any]:
        """
        Get remediation strategy based on risk level.
        """
        mean_risk = risk_score.mean().item()

        if mean_risk > 0.7:
            return {
                'severity': 'CRITICAL',
                'action': 'REFUSE',
                'reason': 'Extreme hallucination risk - do not proceed',
                'tau_override': float('inf'),  # No confidence
            }
        elif mean_risk > 0.5:
            return {
                'severity': 'HIGH',
                'action': 'ESCALATE',
                'reason': 'High hallucination risk - require human review',
                'tau_override': 5.0,  # Very exploratory
            }
        elif mean_risk > 0.3:
            return {
                'severity': 'MEDIUM',
                'action': 'FLAG',
                'reason': 'Moderate hallucination risk - flag output',
                'tau_override': 2.5,  # Exploratory
            }
        else:
            return {
                'severity': 'LOW',
                'action': 'PROCEED',
                'reason': 'Low hallucination risk',
                'tau_override': None,  # Use computed tau
            }


class OODPoisoningDetector(nn.Module):
    """
    Detect O_POISONING: OOD content that looks like Relevant signal.

    YRSN Definition:
        O_POISONING = (R_norm > threshold) AND (ω < threshold)
        "OOD content misclassified as relevant signal."

    This is distinct from HALLUCINATION:
    - HALLUCINATION: High overall quality (α) but low reliability (ω)
    - O_POISONING: High R specifically but low reliability (ω)

    The danger: OOD content gets projected onto R space, appearing
    as signal when it's actually distributional noise.
    """

    def __init__(
        self,
        r_threshold: float = 0.5,
        omega_threshold: float = 0.5,
        risk_amplification: float = 2.0
    ):
        super().__init__()
        self.r_threshold = r_threshold
        self.omega_threshold = omega_threshold
        self.risk_amplification = risk_amplification

    def detect(
        self,
        R_norm: torch.Tensor,
        omega: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Detect O_POISONING risk.

        Args:
            R_norm: [B] - R component norm (or R ratio)
            omega: [B] - distributional alignment (1 - avg_gate)

        Returns:
            at_risk: [B] - boolean mask (True = O_POISONING risk)
            risk_score: [B] - continuous risk score [0, 1]
        """
        # Binary detection: High R but low omega
        at_risk = (R_norm > self.r_threshold) & (omega < self.omega_threshold)

        # Continuous risk score
        # Higher R_norm + lower omega = more dangerous (OOD looks like signal)
        r_excess = F.relu(R_norm - self.r_threshold)
        omega_deficit = F.relu(self.omega_threshold - omega)

        risk_score = self.risk_amplification * r_excess * omega_deficit

        # Normalize to [0, 1]
        risk_score = torch.sigmoid(risk_score)

        return at_risk, risk_score

    def forward(
        self,
        R_norm: torch.Tensor,
        omega: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Full O_POISONING analysis.
        """
        at_risk, risk_score = self.detect(R_norm, omega)

        return {
            'at_risk': at_risk,
            'risk_score': risk_score,
            'risk_fraction': at_risk.float().mean(),
            'max_risk': risk_score.max(),
            'mean_risk': risk_score.mean(),
        }

    def get_remediation(self, risk_score: torch.Tensor) -> Dict[str, any]:
        """
        Get remediation strategy for O_POISONING.
        """
        mean_risk = risk_score.mean().item()

        if mean_risk > 0.7:
            return {
                'severity': 'CRITICAL',
                'action': 'QUARANTINE',
                'reason': 'OOD content strongly resembles signal - quarantine source',
                'tau_override': float('inf'),
            }
        elif mean_risk > 0.5:
            return {
                'severity': 'HIGH',
                'action': 'FILTER',
                'reason': 'OOD content projected as R - filter high-R OOD samples',
                'tau_override': 5.0,
            }
        elif mean_risk > 0.3:
            return {
                'severity': 'MEDIUM',
                'action': 'VALIDATE',
                'reason': 'Potential OOD as R - cross-validate with trusted source',
                'tau_override': 2.5,
            }
        else:
            return {
                'severity': 'LOW',
                'action': 'PROCEED',
                'reason': 'Low O_POISONING risk',
                'tau_override': None,
            }


class AdaptiveCVJF(nn.Module):
    """
    Adaptive CVJF with learned weighting and domain-specific thresholds.

    Extension: Learn optimal (α₁, α₂) weights from validation data
    rather than using fixed VDT defaults.
    """

    def __init__(
        self,
        n_domains: int = 1,
        init_alpha_conf: float = 2.0,
        init_alpha_var: float = -1.0
    ):
        super().__init__()

        # Learnable weights (shared or per-domain)
        self.alpha_confidence = nn.Parameter(
            torch.ones(n_domains) * init_alpha_conf
        )
        self.alpha_variance = nn.Parameter(
            torch.ones(n_domains) * init_alpha_var
        )

        # Per-domain thresholds
        self.thresholds = nn.Parameter(torch.ones(n_domains) * 0.9)

        # History for online adaptation
        self.score_history = deque(maxlen=1000)
        self.outcome_history = deque(maxlen=1000)

    def compute_score(
        self,
        confidence: torch.Tensor,
        variance: torch.Tensor,
        domain_id: int = 0
    ) -> torch.Tensor:
        """Compute quality score with learned weights."""
        if variance.dim() > 1:
            variance = variance.mean(dim=-1)

        alpha_c = self.alpha_confidence[domain_id]
        alpha_v = self.alpha_variance[domain_id]

        return alpha_c * confidence + alpha_v * variance

    def update_from_outcome(
        self,
        scores: torch.Tensor,
        outcomes: torch.Tensor,
        learning_rate: float = 0.01
    ):
        """
        Update weights based on outcome feedback.

        If high-score samples had bad outcomes, adjust weights.
        """
        # Store for analysis
        self.score_history.extend(scores.detach().cpu().tolist())
        self.outcome_history.extend(outcomes.detach().cpu().tolist())

        # Compute correlation between scores and outcomes
        if len(self.score_history) < 100:
            return  # Not enough data

        scores_arr = np.array(list(self.score_history)[-100:])
        outcomes_arr = np.array(list(self.outcome_history)[-100:])

        correlation = np.corrcoef(scores_arr, outcomes_arr)[0, 1]

        # If correlation is low, weights need adjustment
        # (This is a simplified heuristic - full implementation would use gradient descent)
        if abs(correlation) < 0.3:
            # Increase confidence weight if outcomes don't correlate
            with torch.no_grad():
                self.alpha_confidence *= (1 + learning_rate)
                self.alpha_variance *= (1 - learning_rate)

    def forward(
        self,
        confidence: torch.Tensor,
        variance: torch.Tensor,
        domain_id: int = 0
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass with learned parameters.
        """
        scores = self.compute_score(confidence, variance, domain_id)
        threshold = self.thresholds[domain_id]
        mask = scores > threshold

        return {
            'scores': scores,
            'mask': mask,
            'threshold': threshold,
            'alpha_confidence': self.alpha_confidence[domain_id],
            'alpha_variance': self.alpha_variance[domain_id],
        }


class YRSNHallucinationGate(nn.Module):
    """
    Combined CVJF + Hallucination Detection for YRSN pipeline.

    This is the primary module for gating YRSN outputs based on
    joint confidence-variance analysis.
    """

    def __init__(
        self,
        cvjf_config: Optional[CVJFConfig] = None,
        alpha_threshold: float = 0.7,
        omega_threshold: float = 0.5
    ):
        super().__init__()

        self.cvjf = ConfidenceVarianceJointFilter(cvjf_config)
        self.hallucination_detector = HallucinationDetector(
            alpha_threshold=alpha_threshold,
            omega_threshold=omega_threshold
        )

    def forward(
        self,
        yrsn_output: Dict[str, torch.Tensor]
    ) -> Dict[str, torch.Tensor]:
        """
        Analyze YRSN output for reliability.

        Args:
            yrsn_output: Output from YRSNProjectionHeads containing:
                - alpha: Quality score
                - omega: OOD score
                - var_R, var_S, var_N: Component variances (optional)

        Returns:
            Dictionary with reliability analysis
        """
        alpha = yrsn_output['alpha']
        omega = yrsn_output['omega']

        # Get average variance if available
        if 'var_R' in yrsn_output:
            avg_var = (
                yrsn_output['var_R'].mean(dim=-1) +
                yrsn_output['var_S'].mean(dim=-1) +
                yrsn_output['var_N'].mean(dim=-1)
            ) / 3
        else:
            # Derive from omega: high omega → low variance
            avg_var = 1 - omega

        # CVJF analysis
        cvjf_result = self.cvjf(confidence=alpha, variance=avg_var)

        # Hallucination detection
        hall_result = self.hallucination_detector(alpha=alpha, omega=omega)

        # Combined reliability
        reliable = cvjf_result['mask'] & ~hall_result['at_risk']

        # Get remediation
        remediation = self.hallucination_detector.get_remediation(
            hall_result['risk_score']
        )

        return {
            # CVJF results
            'cvjf_scores': cvjf_result['scores'],
            'cvjf_reliable': cvjf_result['mask'],
            # Hallucination results
            'hallucination_risk': hall_result['at_risk'],
            'hallucination_score': hall_result['risk_score'],
            # Combined
            'reliable': reliable,
            'reliable_fraction': reliable.float().mean(),
            # Remediation
            'remediation': remediation,
        }


# =============================================================================
# Demo
# =============================================================================

def demo_cvjf():
    """Demonstrate CVJF functionality."""
    print("=" * 60)
    print("CVJF: Confidence-Variance Joint Filtering Demo")
    print("=" * 60)

    # Create detector
    gate = YRSNHallucinationGate()

    # Simulate YRSN outputs
    batch_size = 32

    # Case 1: High quality, in-distribution (safe)
    yrsn_safe = {
        'alpha': torch.ones(batch_size) * 0.8,  # High quality
        'omega': torch.ones(batch_size) * 0.9,  # In-distribution
        'var_R': torch.ones(batch_size, 256) * 0.1,
        'var_S': torch.ones(batch_size, 256) * 0.1,
        'var_N': torch.ones(batch_size, 256) * 0.1,
    }

    result_safe = gate(yrsn_safe)
    print("\nCase 1: High Quality + In-Distribution")
    print(f"  Reliable fraction: {result_safe['reliable_fraction']:.2%}")
    print(f"  Hallucination risk: {result_safe['hallucination_risk'].float().mean():.2%}")
    print(f"  Remediation: {result_safe['remediation']['action']}")

    # Case 2: High quality, OOD (DANGEROUS - hallucination risk!)
    yrsn_hallucination = {
        'alpha': torch.ones(batch_size) * 0.85,  # Appears high quality
        'omega': torch.ones(batch_size) * 0.3,   # But OOD!
        'var_R': torch.ones(batch_size, 256) * 0.8,  # High variance
        'var_S': torch.ones(batch_size, 256) * 0.8,
        'var_N': torch.ones(batch_size, 256) * 0.8,
    }

    result_hall = gate(yrsn_hallucination)
    print("\nCase 2: High Quality + OOD (Hallucination Risk!)")
    print(f"  Reliable fraction: {result_hall['reliable_fraction']:.2%}")
    print(f"  Hallucination risk: {result_hall['hallucination_risk'].float().mean():.2%}")
    print(f"  Risk score: {result_hall['hallucination_score'].mean():.3f}")
    print(f"  Remediation: {result_hall['remediation']['action']}")
    print(f"  Reason: {result_hall['remediation']['reason']}")

    # Case 3: Low quality, OOD (correctly uncertain)
    yrsn_uncertain = {
        'alpha': torch.ones(batch_size) * 0.3,  # Low quality
        'omega': torch.ones(batch_size) * 0.3,  # OOD
        'var_R': torch.ones(batch_size, 256) * 0.8,
        'var_S': torch.ones(batch_size, 256) * 0.8,
        'var_N': torch.ones(batch_size, 256) * 0.8,
    }

    result_uncertain = gate(yrsn_uncertain)
    print("\nCase 3: Low Quality + OOD (Correctly Uncertain)")
    print(f"  Reliable fraction: {result_uncertain['reliable_fraction']:.2%}")
    print(f"  Hallucination risk: {result_uncertain['hallucination_risk'].float().mean():.2%}")
    print(f"  Remediation: {result_uncertain['remediation']['action']}")

    print("\n" + "=" * 60)
    print("Key Insight: Case 2 is the dangerous one!")
    print("Model appears confident but representations are unstable.")
    print("CVJF detects this and flags for review.")
    print("=" * 60)


if __name__ == "__main__":
    demo_cvjf()
