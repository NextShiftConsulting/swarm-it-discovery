"""
YRSN: Unified YRSN + OOD Pipeline
===================================

Integrates all P0-P2 components into a single production-ready module.

Component Priority:
    P0 (Foundation): VGFA, SCP
    P1 (Production): CVJF, SEDA, MSDF
    P2 (Enhancement): TTVA, MVDA, RGFS

Architecture:
    Input → SEDA (shared encoder) → VGFA (variance gating) →
    SCP (collapse prevention) → CVJF (hallucination detection) →
    MSDF (multi-source fusion) → MVDA (temperature derivation) →
    Output (α, ω, τ, reliability metrics)

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, Optional, List, Tuple, Any
from collections import deque

# Import all components
from .vgfa import (
    VGFAConfig,
    VarianceGatedFactorAttenuation,
    YRSNProjectionHeads,
    RSNVariationalHead,
    create_yrsn_heads,
)
from .scp import (
    SCPConfig,
    SemanticCollapsePreventor,
    DualComponentConstraint,
    CollapseAwareLoss,
    RSNCollapseMonitor,
)
from .cvjf import (
    CVJFConfig,
    ConfidenceVarianceJointFilter,
    HallucinationDetector,
    YRSNHallucinationGate,
)
from .seda import (
    SEDAConfig,
    SharedEncoderDomainAlignment,
    MultiDomainRSNEncoder,
)
from .msdf import (
    MSDFConfig,
    MultiSourceDomainFusion,
    SourceReliabilityTracker,
)
from .ttva import (
    TTVAConfig,
    TestTimeVariationalAdapter,
    DriftAwareAdapter,
)
from .mvda import (
    MVDAConfig,
    MeanVarianceDecomposedAlignment,
    DualPathQuality,
    TemperatureFromVariance,
)
from .rgfs import (
    RGFSConfig,
    ReconstructionGuidedFactorSelection,
    BBPReconstructionBridge,
)


@dataclass
class YRSNConfig:
    """Complete configuration for YRSN pipeline."""

    # Dimensions
    embed_dim: int = 768
    rsn_dim: int = 256
    hidden_dim: int = 512

    # Components to enable
    enable_seda: bool = True      # P1: Shared encoder
    enable_vgfa: bool = True      # P0: Variance gating (required)
    enable_scp: bool = True       # P0: Collapse prevention (required)
    enable_cvjf: bool = True      # P1: Hallucination detection
    enable_msdf: bool = True      # P1: Multi-source fusion
    enable_ttva: bool = False     # P2: Test-time adaptation (optional)
    enable_mvda: bool = True      # P2: Dual-path quality
    enable_rgfs: bool = False     # P2: Rank selection (optional)

    # VGFA config
    vgfa_temperature: float = 1.0
    vgfa_learnable: bool = True

    # SCP config
    scp_beta_kl: float = 1.5
    scp_diversity_weight: float = 0.1

    # CVJF config
    hallucination_alpha_threshold: float = 0.7
    hallucination_omega_threshold: float = 0.5

    # MSDF config
    n_sources: int = 10
    quarantine_threshold: float = 0.3

    # TTVA config
    ttva_trigger_threshold: float = 0.4
    ttva_adaptation_steps: int = 10

    # Output behavior
    compute_temperature: bool = True
    default_prior_alpha: float = 0.5


@dataclass
class YRSNOutput:
    """Output from YRSN pipeline."""

    # Core outputs
    R: torch.Tensor                    # [B, rsn_dim] - gated relevance
    S: torch.Tensor                    # [B, rsn_dim] - gated superfluous
    N: torch.Tensor                    # [B, rsn_dim] - gated noise
    alpha: torch.Tensor                # [B] - quality score
    omega: torch.Tensor                # [B] - distributional alignment
    tau: torch.Tensor                  # [B] - temperature

    # Reliability metrics
    reliable: torch.Tensor             # [B] - boolean reliability mask
    hallucination_risk: torch.Tensor   # [B] - boolean risk mask
    risk_score: torch.Tensor           # [B] - continuous risk [0, 1]

    # Intermediate values (optional)
    details: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    source_id: Optional[int] = None
    adapted: bool = False
    collapse_detected: Dict[str, bool] = field(default_factory=dict)


class YRSN(nn.Module):
    """
    Unified YRSN Pipeline: YRSN with OOD Detection.

    Combines all P0-P2 components:
        P0: VGFA (variance gating) + SCP (collapse prevention)
        P1: CVJF (hallucination) + SEDA (shared encoder) + MSDF (fusion)
        P2: TTVA (adaptation) + MVDA (dual-path) + RGFS (rank selection)

    Key insight: Variance naturally encodes OOD uncertainty.
    No external OOD detector needed - ω emerges from representation.

    Example:
        >>> yrsn = YRSN(YRSNConfig(embed_dim=768))
        >>> output = yrsn(embeddings)
        >>> print(f"Quality: {output.alpha.mean():.3f}")
        >>> print(f"Reliability: {output.omega.mean():.3f}")
        >>> print(f"Temperature: {output.tau.mean():.3f}")
    """

    def __init__(self, config: Optional[YRSNConfig] = None):
        super().__init__()

        if config is None:
            config = YRSNConfig()
        self.config = config

        # =====================================================================
        # P0: Foundation (Required)
        # =====================================================================

        # VGFA: Variance-Gated Factor Attenuation
        vgfa_config = VGFAConfig(
            n_factors=config.rsn_dim,
            temperature_init=config.vgfa_temperature,
            learnable_temperature=config.vgfa_learnable,
        )
        self.projection_heads = YRSNProjectionHeads(
            embed_dim=config.embed_dim,
            rsn_dim=config.rsn_dim,
            hidden_dim=config.hidden_dim,
            vgfa_config=vgfa_config,
        )

        # SCP: Semantic Collapse Prevention
        if config.enable_scp:
            self.scp = SemanticCollapsePreventor(SCPConfig(
                beta_kl=config.scp_beta_kl,
                diversity_weight=config.scp_diversity_weight,
            ))
            self.collapse_monitor = RSNCollapseMonitor()
        else:
            self.scp = None
            self.collapse_monitor = None

        # =====================================================================
        # P1: Production
        # =====================================================================

        # CVJF: Confidence-Variance Joint Filtering
        if config.enable_cvjf:
            self.hallucination_gate = YRSNHallucinationGate(
                alpha_threshold=config.hallucination_alpha_threshold,
                omega_threshold=config.hallucination_omega_threshold,
            )
        else:
            self.hallucination_gate = None

        # SEDA: Shared Encoder Domain Alignment
        if config.enable_seda:
            self.seda = MultiDomainRSNEncoder(
                embed_dim=config.embed_dim,
                rsn_dim=config.rsn_dim,
                n_sources=config.n_sources,
            )
        else:
            self.seda = None

        # MSDF: Multi-Source Domain Fusion
        if config.enable_msdf:
            self.msdf = MultiSourceDomainFusion(MSDFConfig(
                n_sources=config.n_sources,
                hidden_dim=config.rsn_dim,
                quarantine_threshold=config.quarantine_threshold,
            ))
        else:
            self.msdf = None

        # =====================================================================
        # P2: Enhancement
        # =====================================================================

        # MVDA: Mean-Variance Decomposed Alignment
        if config.enable_mvda:
            self.dual_path = DualPathQuality(combination='multiply')
        else:
            self.dual_path = None

        # TTVA: Test-Time Variational Adaptation (requires decoder)
        self.ttva = None  # Initialized separately if needed

        # RGFS: Reconstruction-Guided Factor Selection
        self.rgfs = None  # Initialized separately if needed

        # =====================================================================
        # State tracking
        # =====================================================================
        self.register_buffer('alpha_prior', torch.tensor(config.default_prior_alpha))

    def forward(
        self,
        x: torch.Tensor,
        source_id: Optional[int] = None,
        return_details: bool = False,
    ) -> YRSNOutput:
        """
        Process input through YRSN pipeline.

        Args:
            x: [B, embed_dim] - input embeddings
            source_id: Optional source identifier for SEDA/MSDF
            return_details: Include intermediate values in output

        Returns:
            YRSNOutput with quality, reliability, and temperature
        """
        details = {}

        # -----------------------------------------------------------------
        # Step 1: R/S/N Projection with Variance Gating (VGFA)
        # -----------------------------------------------------------------
        proj_result = self.projection_heads(x, return_details=True)

        R = proj_result['R']
        S = proj_result['S']
        N = proj_result['N']
        alpha = proj_result['alpha']
        omega = proj_result['omega']
        tau = proj_result['tau']

        if return_details:
            details['projection'] = proj_result

        # -----------------------------------------------------------------
        # Step 2: Collapse Detection (SCP)
        # -----------------------------------------------------------------
        collapse_detected = {}
        if self.collapse_monitor is not None:
            self.collapse_monitor.update(
                R, S, N, proj_result['logvar_R']
            )
            collapse_status = self.collapse_monitor.get_status()
            collapse_detected = {
                'any': collapse_status['status'] == 'collapse_risk',
                'alerts': collapse_status.get('alerts', []),
            }
            if return_details:
                details['collapse'] = collapse_status

        # -----------------------------------------------------------------
        # Step 3: Dual-Path Quality (MVDA)
        # -----------------------------------------------------------------
        if self.dual_path is not None:
            mvda_result = self.dual_path(
                R, S, N,
                proj_result['var_R'],
                proj_result['var_S'],
                proj_result['var_N'],
            )
            # Use MVDA's combined quality and temperature
            alpha = mvda_result['quality']
            omega = mvda_result['omega']
            tau = mvda_result['tau']

            if return_details:
                details['mvda'] = mvda_result

        # -----------------------------------------------------------------
        # Step 4: Hallucination Detection (CVJF)
        # -----------------------------------------------------------------
        if self.hallucination_gate is not None:
            gate_input = {
                'alpha': alpha,
                'omega': omega,
                'var_R': proj_result['var_R'],
                'var_S': proj_result['var_S'],
                'var_N': proj_result['var_N'],
            }
            gate_result = self.hallucination_gate(gate_input)

            reliable = gate_result['reliable']
            hallucination_risk = gate_result['hallucination_risk']
            risk_score = gate_result['hallucination_score']

            # Override tau based on remediation
            remediation = gate_result['remediation']
            if remediation['tau_override'] is not None:
                tau = torch.full_like(tau, remediation['tau_override'])

            if return_details:
                details['hallucination'] = gate_result
        else:
            # Default: all reliable, no risk
            reliable = torch.ones_like(alpha, dtype=torch.bool)
            hallucination_risk = torch.zeros_like(alpha, dtype=torch.bool)
            risk_score = torch.zeros_like(alpha)

        # -----------------------------------------------------------------
        # Step 5: Source tracking (SEDA/MSDF)
        # -----------------------------------------------------------------
        if source_id is not None and self.msdf is not None:
            # Update source reliability tracker
            self.msdf.weighter.tracker.update(source_id, omega)

        return YRSNOutput(
            R=R,
            S=S,
            N=N,
            alpha=alpha,
            omega=omega,
            tau=tau,
            reliable=reliable,
            hallucination_risk=hallucination_risk,
            risk_score=risk_score,
            details=details if return_details else {},
            source_id=source_id,
            adapted=False,
            collapse_detected=collapse_detected,
        )

    def process_multi_source(
        self,
        source_embeddings: Dict[int, torch.Tensor],
        query: Optional[torch.Tensor] = None,
    ) -> Tuple[YRSNOutput, Dict[str, Any]]:
        """
        Process multiple sources and fuse results.

        Args:
            source_embeddings: {source_id: [B, embed_dim]} per-source embeddings
            query: Optional query for attention-based fusion

        Returns:
            Fused YRSNOutput and fusion metadata
        """
        if self.msdf is None:
            raise ValueError("MSDF not enabled. Set enable_msdf=True in config.")

        # Process each source
        source_outputs: Dict[int, YRSNOutput] = {}
        source_rsn: Dict[int, torch.Tensor] = {}
        source_omegas: Dict[int, torch.Tensor] = {}

        for sid, emb in source_embeddings.items():
            output = self.forward(emb, source_id=sid)
            source_outputs[sid] = output

            # Concatenate R/S/N for fusion
            rsn = torch.cat([output.R, output.S, output.N], dim=-1)
            source_rsn[sid] = rsn
            source_omegas[sid] = output.omega

        # Fuse using MSDF
        fusion_result = self.msdf(source_rsn, source_omegas, query)

        # Extract fused R/S/N
        fused = fusion_result['fused']
        rsn_dim = self.config.rsn_dim
        R_fused = fused[:, :rsn_dim]
        S_fused = fused[:, rsn_dim:2*rsn_dim]
        N_fused = fused[:, 2*rsn_dim:]

        # Compute fused quality metrics
        R_norm = torch.norm(R_fused, dim=-1)
        S_norm = torch.norm(S_fused, dim=-1)
        N_norm = torch.norm(N_fused, dim=-1)
        total = R_norm + S_norm + N_norm + 1e-8
        alpha_fused = R_norm / total

        # Weighted omega from active sources
        omega_fused = torch.zeros_like(alpha_fused)
        for sid, weight in fusion_result['active_weights'].items():
            omega_fused += weight * source_omegas[sid][:omega_fused.shape[0]]

        # Temperature
        tau_fused = 1.0 / (alpha_fused + 1e-8)

        # Aggregate reliability
        reliable_fused = torch.ones_like(alpha_fused, dtype=torch.bool)
        risk_fused = torch.zeros_like(alpha_fused)
        for sid, output in source_outputs.items():
            if sid in fusion_result['active_weights']:
                reliable_fused &= output.reliable[:reliable_fused.shape[0]]
                risk_fused = torch.max(risk_fused, output.risk_score[:risk_fused.shape[0]])

        fused_output = YRSNOutput(
            R=R_fused,
            S=S_fused,
            N=N_fused,
            alpha=alpha_fused,
            omega=omega_fused,
            tau=tau_fused,
            reliable=reliable_fused,
            hallucination_risk=risk_fused > 0.5,
            risk_score=risk_fused,
            source_id=None,  # Multi-source
        )

        return fused_output, {
            'fusion': fusion_result,
            'source_outputs': source_outputs,
        }

    def get_training_loss(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute training losses including SCP's L_dcc.

        Args:
            x: Original input
            x_recon: Reconstructed input

        Returns:
            Dictionary of loss components
        """
        # Get projection with details
        result = self.projection_heads(x, return_details=True)

        losses = {}

        # SCP loss (L_dcc)
        if self.scp is not None:
            # Combine mu and logvar from all components
            mu = torch.cat([result['mu_R'], result['mu_S'], result['mu_N']], dim=-1)
            logvar = torch.cat([
                result['logvar_R'], result['logvar_S'], result['logvar_N']
            ], dim=-1)

            scp_result = self.scp(
                x, x_recon, mu, logvar,
                result['R'], result['S'], result['N']
            )
            losses['scp_total'] = scp_result['total']
            losses['reconstruction'] = scp_result['reconstruction']
            losses['kl'] = scp_result['kl']
            if 'diversity' in scp_result:
                losses['diversity'] = scp_result['diversity']

        # KL from projection heads
        kl_loss = self.projection_heads.get_kl_divergence(
            result['mu_R'], result['logvar_R'],
            result['mu_S'], result['logvar_S'],
            result['mu_N'], result['logvar_N'],
        )
        losses['kl_rsn'] = kl_loss.mean()

        return losses

    def get_source_report(self) -> Dict[int, Dict[str, Any]]:
        """Get reliability report for all sources."""
        if self.msdf is None:
            return {}
        return self.msdf.get_source_report()

    def should_adapt(self, omega: torch.Tensor) -> bool:
        """Check if TTVA should trigger."""
        return omega.mean().item() < self.config.ttva_trigger_threshold


class YRSNLite(nn.Module):
    """
    Lightweight YRSN with only P0 components.

    Use when:
    - Latency is critical
    - Single-source input
    - No multi-source fusion needed

    Includes: VGFA + SCP
    Excludes: CVJF, SEDA, MSDF, TTVA, MVDA, RGFS
    """

    def __init__(
        self,
        embed_dim: int = 768,
        rsn_dim: int = 256,
    ):
        super().__init__()

        self.heads = create_yrsn_heads(embed_dim, rsn_dim)
        self.dcc = DualComponentConstraint(beta=1.5)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Quick forward pass with core metrics."""
        return self.heads(x)


# =============================================================================
# Factory Functions
# =============================================================================

def create_yrsn_minimal() -> YRSN:
    """Create minimal YRSN with only P0 components."""
    return YRSN(YRSNConfig(
        enable_seda=False,
        enable_cvjf=False,
        enable_msdf=False,
        enable_mvda=False,
    ))


def create_yrsn_production() -> YRSN:
    """Create production YRSN with P0 + P1 components."""
    return YRSN(YRSNConfig(
        enable_seda=True,
        enable_cvjf=True,
        enable_msdf=True,
        enable_mvda=True,
        enable_ttva=False,
        enable_rgfs=False,
    ))


def create_yrsn_full() -> YRSN:
    """Create full YRSN with all components."""
    return YRSN(YRSNConfig(
        enable_seda=True,
        enable_cvjf=True,
        enable_msdf=True,
        enable_mvda=True,
        enable_ttva=True,
        enable_rgfs=True,
    ))


# =============================================================================
# Demo
# =============================================================================

def demo_yrsn():
    """Demonstrate unified YRSN pipeline."""
    print("=" * 70)
    print("YRSN: Unified YRSN + OOD Detection Pipeline")
    print("=" * 70)

    # Create production YRSN
    yrsn = create_yrsn_production()
    print(f"\nConfig: {yrsn.config}")

    # Single source processing
    print("\n" + "-" * 50)
    print("1. Single Source Processing")
    print("-" * 50)

    x = torch.randn(16, 768)
    output = yrsn(x, source_id=0, return_details=True)

    print(f"   Alpha (quality):     {output.alpha.mean():.3f}")
    print(f"   Omega (reliability): {output.omega.mean():.3f}")
    print(f"   Tau (temperature):   {output.tau.mean():.3f}")
    print(f"   Reliable fraction:   {output.reliable.float().mean():.1%}")
    print(f"   Hallucination risk:  {output.hallucination_risk.float().mean():.1%}")

    # Multi-source processing
    print("\n" + "-" * 50)
    print("2. Multi-Source Processing")
    print("-" * 50)

    source_embeddings = {
        0: torch.randn(16, 768),      # High quality source
        1: torch.randn(16, 768) * 2,  # Medium quality
        2: torch.randn(16, 768) * 5,  # Low quality (OOD)
    }

    fused_output, fusion_meta = yrsn.process_multi_source(source_embeddings)

    print(f"   Fused alpha:   {fused_output.alpha.mean():.3f}")
    print(f"   Fused omega:   {fused_output.omega.mean():.3f}")
    print(f"   Active sources: {fusion_meta['fusion']['n_active_sources']}")
    print(f"   Source weights:")
    for sid, weight in fusion_meta['fusion']['weights'].items():
        reliability = fusion_meta['fusion']['source_reliabilities'][sid]
        print(f"      Source {sid}: weight={weight:.3f}, reliability={reliability:.3f}")

    # Hallucination detection
    print("\n" + "-" * 50)
    print("3. Hallucination Detection")
    print("-" * 50)

    # Simulate high-alpha but OOD input (hallucination risk)
    x_risky = torch.randn(16, 768) * 0.1  # Low variance input
    output_risky = yrsn(x_risky)

    print(f"   Risk score:       {output_risky.risk_score.mean():.3f}")
    print(f"   Hallucination %:  {output_risky.hallucination_risk.float().mean():.1%}")

    # Training loss
    print("\n" + "-" * 50)
    print("4. Training Loss Components")
    print("-" * 50)

    x_recon = x + 0.1 * torch.randn_like(x)
    losses = yrsn.get_training_loss(x, x_recon)

    for name, value in losses.items():
        print(f"   {name}: {value.item():.4f}")

    print("\n" + "=" * 70)
    print("YRSN provides: α (quality), ω (reliability), τ (temperature)")
    print("All from a single unified pipeline with emergent OOD detection!")
    print("=" * 70)


if __name__ == "__main__":
    demo_yrsn()
