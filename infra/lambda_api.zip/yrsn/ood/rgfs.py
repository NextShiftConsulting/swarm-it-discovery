"""
RGFS: Reconstruction-Guided Factor Selection
=============================================

Mechanism for selecting optimal number of R/S/N factors using
reconstruction error as a guide.

The key insight: If we can't reconstruct the input from latent z,
we may have too few factors. If reconstruction is perfect but
generalization is poor, we may have too many (overfitting).

Connection to BBP: The BBP threshold tells us when eigenvalues
are signal vs noise. RGFS uses reconstruction to empirically
validate this threshold.

YRSN Application:
    Use reconstruction error to guide BBP rank selection.
    Balance compression vs information preservation.

Reference: Extension of VDT + BBP concepts
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, List, Tuple
import numpy as np


@dataclass
class RGFSConfig:
    """Configuration for Reconstruction-Guided Factor Selection."""
    min_rank: int = 8
    max_rank: int = 128
    reconstruction_threshold: float = 0.1
    rank_search_method: str = 'binary'  # 'binary', 'linear', 'adaptive'
    validation_fraction: float = 0.1


class ReconstructionGuidedFactorSelection(nn.Module):
    """
    Select optimal number of factors using reconstruction error.

    The idea: More factors = better reconstruction but risk of overfitting.
    Find the sweet spot where reconstruction is good but not overfit.

    Connection to BBP:
    - BBP says: eigenvalue > (1 + sqrt(c))² → signal
    - RGFS validates: can we reconstruct from these components?
    """

    def __init__(self, config: Optional[RGFSConfig] = None):
        super().__init__()

        if config is None:
            config = RGFSConfig()
        self.config = config

        # History for adaptive selection
        self.reconstruction_history: Dict[int, List[float]] = {}
        self.generalization_history: Dict[int, List[float]] = {}

    def compute_reconstruction_error(
        self,
        x: torch.Tensor,
        z: torch.Tensor,
        decoder: nn.Module
    ) -> torch.Tensor:
        """
        Compute reconstruction error from latent representation.
        """
        x_recon = decoder(z)
        return F.mse_loss(x_recon, x, reduction='none').mean(dim=-1)

    def rank_to_latent(
        self,
        z_full: torch.Tensor,
        rank: int
    ) -> torch.Tensor:
        """
        Reduce latent dimension to specified rank.
        Simple truncation - could use PCA or learned projection.
        """
        return z_full[:, :rank]

    def evaluate_rank(
        self,
        x: torch.Tensor,
        z_full: torch.Tensor,
        decoder: nn.Module,
        rank: int
    ) -> Dict[str, float]:
        """
        Evaluate reconstruction quality at a given rank.
        """
        # Truncate to rank
        z_truncated = self.rank_to_latent(z_full, rank)

        # Pad back to decoder's expected dimension if needed
        if z_truncated.shape[-1] < z_full.shape[-1]:
            padding = torch.zeros(
                z_truncated.shape[0],
                z_full.shape[-1] - z_truncated.shape[-1],
                device=z_truncated.device
            )
            z_padded = torch.cat([z_truncated, padding], dim=-1)
        else:
            z_padded = z_truncated

        # Compute reconstruction error
        recon_error = self.compute_reconstruction_error(x, z_padded, decoder)

        return {
            'rank': rank,
            'recon_error_mean': recon_error.mean().item(),
            'recon_error_std': recon_error.std().item(),
            'recon_error_max': recon_error.max().item(),
        }

    def find_optimal_rank_binary(
        self,
        x: torch.Tensor,
        z_full: torch.Tensor,
        decoder: nn.Module
    ) -> int:
        """
        Find optimal rank using binary search.

        Search for smallest rank where reconstruction error < threshold.
        """
        low = self.config.min_rank
        high = min(self.config.max_rank, z_full.shape[-1])

        while low < high:
            mid = (low + high) // 2
            result = self.evaluate_rank(x, z_full, decoder, mid)

            if result['recon_error_mean'] < self.config.reconstruction_threshold:
                high = mid
            else:
                low = mid + 1

        return low

    def find_optimal_rank_elbow(
        self,
        x: torch.Tensor,
        z_full: torch.Tensor,
        decoder: nn.Module
    ) -> int:
        """
        Find optimal rank using elbow method.

        Look for point where adding more factors gives diminishing returns.
        """
        ranks = list(range(
            self.config.min_rank,
            min(self.config.max_rank, z_full.shape[-1]) + 1,
            4  # Step size
        ))

        errors = []
        for rank in ranks:
            result = self.evaluate_rank(x, z_full, decoder, rank)
            errors.append(result['recon_error_mean'])

        # Find elbow (maximum curvature)
        if len(errors) < 3:
            return ranks[0]

        # Second derivative
        d1 = np.diff(errors)
        d2 = np.diff(d1)

        # Elbow is where d2 is maximum (steepest decrease slowing down)
        elbow_idx = np.argmax(d2) + 1
        return ranks[elbow_idx]

    def forward(
        self,
        x: torch.Tensor,
        z_full: torch.Tensor,
        decoder: nn.Module,
        method: Optional[str] = None
    ) -> Dict[str, any]:
        """
        Find optimal rank and return recommendation.
        """
        method = method or self.config.rank_search_method

        if method == 'binary':
            optimal_rank = self.find_optimal_rank_binary(x, z_full, decoder)
        elif method == 'elbow':
            optimal_rank = self.find_optimal_rank_elbow(x, z_full, decoder)
        else:
            # Default to binary
            optimal_rank = self.find_optimal_rank_binary(x, z_full, decoder)

        # Evaluate at optimal rank
        final_eval = self.evaluate_rank(x, z_full, decoder, optimal_rank)

        return {
            'optimal_rank': optimal_rank,
            **final_eval,
            'method': method,
        }


class AutoRankSelector(nn.Module):
    """
    Automatically select rank based on input characteristics.

    Different inputs may need different ranks:
    - Simple context → fewer factors
    - Complex context → more factors
    """

    def __init__(
        self,
        input_dim: int,
        max_rank: int = 128,
        min_rank: int = 8
    ):
        super().__init__()

        self.max_rank = max_rank
        self.min_rank = min_rank

        # Learn to predict optimal rank from input
        self.rank_predictor = nn.Sequential(
            nn.Linear(input_dim, input_dim // 2),
            nn.ReLU(),
            nn.Linear(input_dim // 2, 1),
            nn.Sigmoid()  # Output in [0, 1]
        )

    def predict_rank(self, x: torch.Tensor) -> torch.Tensor:
        """
        Predict optimal rank for each input.
        """
        # Use mean of input for prediction
        x_summary = x.mean(dim=0) if x.dim() > 1 else x

        # Predict normalized rank
        rank_normalized = self.rank_predictor(x_summary)

        # Scale to [min_rank, max_rank]
        rank = self.min_rank + (self.max_rank - self.min_rank) * rank_normalized

        return rank.squeeze()

    def forward(
        self,
        x: torch.Tensor,
        return_integer: bool = True
    ) -> torch.Tensor:
        """
        Get predicted rank for input.
        """
        rank = self.predict_rank(x)

        if return_integer:
            return rank.round().int()
        return rank


class BBPReconstructionBridge(nn.Module):
    """
    Bridge between BBP theoretical thresholds and empirical reconstruction.

    BBP tells us: α_ℓ = (ℓ-1)/(2ℓ) is the threshold for rank ℓ
    RGFS tells us: reconstruction error validates this choice

    This module combines both signals.
    """

    def __init__(
        self,
        embed_dim: int = 768,
        latent_dim: int = 256,
        n_components: int = 3  # R, S, N
    ):
        super().__init__()

        self.embed_dim = embed_dim
        self.latent_dim = latent_dim
        self.n_components = n_components

        # Per-component rank selection
        self.rgfs = ReconstructionGuidedFactorSelection(RGFSConfig(
            min_rank=4,
            max_rank=latent_dim // n_components
        ))

        # Reconstruction decoder (shared or per-component)
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, embed_dim),
        )

    def compute_bbp_threshold(self, rank: int) -> float:
        """
        Compute BBP threshold for given rank.
        α_ℓ = (ℓ-1)/(2ℓ)
        """
        if rank <= 0:
            return 0.0
        return (rank - 1) / (2 * rank)

    def validate_rank_with_reconstruction(
        self,
        x: torch.Tensor,
        z: torch.Tensor,
        proposed_rank: int
    ) -> Dict[str, any]:
        """
        Validate BBP-proposed rank using reconstruction.
        """
        # BBP threshold for this rank
        bbp_threshold = self.compute_bbp_threshold(proposed_rank)

        # Reconstruction validation
        recon_result = self.rgfs.evaluate_rank(x, z, self.decoder, proposed_rank)

        # Decision: is the rank appropriate?
        recon_ok = recon_result['recon_error_mean'] < self.rgfs.config.reconstruction_threshold

        return {
            'proposed_rank': proposed_rank,
            'bbp_threshold': bbp_threshold,
            'recon_error': recon_result['recon_error_mean'],
            'rank_validated': recon_ok,
            'recommendation': 'accept' if recon_ok else 'increase_rank',
        }

    def find_validated_rank(
        self,
        x: torch.Tensor,
        z: torch.Tensor,
        quality_alpha: float
    ) -> Dict[str, any]:
        """
        Find rank that both BBP and reconstruction agree on.

        Args:
            x: Input for reconstruction validation
            z: Full latent representation
            quality_alpha: Current quality score

        Returns:
            Validated rank recommendation
        """
        # Find BBP-recommended rank for this quality
        # Invert: α = (ℓ-1)/(2ℓ) → ℓ = 1/(2-2α) for α < 0.5
        if quality_alpha >= 0.5:
            bbp_rank = self.latent_dim  # Full rank
        else:
            bbp_rank = max(1, int(1 / (2 - 2 * quality_alpha)))
            bbp_rank = min(bbp_rank, self.latent_dim)

        # Validate with reconstruction
        validation = self.validate_rank_with_reconstruction(x, z, bbp_rank)

        # If not validated, find optimal via RGFS
        if not validation['rank_validated']:
            rgfs_result = self.rgfs(x, z, self.decoder)
            final_rank = rgfs_result['optimal_rank']
            source = 'rgfs'
        else:
            final_rank = bbp_rank
            source = 'bbp'

        return {
            'final_rank': final_rank,
            'bbp_rank': bbp_rank,
            'source': source,
            'quality_alpha': quality_alpha,
            **validation,
        }


# =============================================================================
# Demo
# =============================================================================

def demo_rgfs():
    """Demonstrate RGFS functionality."""
    print("=" * 60)
    print("RGFS: Reconstruction-Guided Factor Selection Demo")
    print("=" * 60)

    embed_dim = 256
    latent_dim = 64

    # Create simple encoder/decoder
    encoder = nn.Linear(embed_dim, latent_dim)
    decoder = nn.Linear(latent_dim, embed_dim)

    # Create RGFS
    rgfs = ReconstructionGuidedFactorSelection(RGFSConfig(
        min_rank=4,
        max_rank=latent_dim,
        reconstruction_threshold=0.15
    ))

    # Generate data
    x = torch.randn(32, embed_dim)
    z = encoder(x)

    print("\nEvaluating different ranks:")
    for rank in [4, 8, 16, 32, 64]:
        result = rgfs.evaluate_rank(x, z, decoder, rank)
        print(f"   Rank {rank:3d}: recon_error = {result['recon_error_mean']:.4f}")

    # Find optimal
    optimal = rgfs(x, z, decoder, method='binary')
    print(f"\nOptimal rank (binary search): {optimal['optimal_rank']}")
    print(f"   Reconstruction error: {optimal['recon_error_mean']:.4f}")

    # BBP bridge
    print("\n" + "-" * 40)
    print("BBP-Reconstruction Bridge:")

    bridge = BBPReconstructionBridge(
        embed_dim=embed_dim,
        latent_dim=latent_dim
    )

    for alpha in [0.3, 0.5, 0.7, 0.9]:
        result = bridge.find_validated_rank(x, z, alpha)
        print(f"\n   α = {alpha}:")
        print(f"      BBP rank: {result['bbp_rank']}")
        print(f"      Final rank: {result['final_rank']} (source: {result['source']})")
        print(f"      Validated: {result['rank_validated']}")


if __name__ == "__main__":
    demo_rgfs()
