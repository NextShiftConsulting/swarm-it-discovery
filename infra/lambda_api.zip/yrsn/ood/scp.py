"""
SCP: Semantic Collapse Prevention
==================================

Mechanism for preventing R/S/N representations from collapsing.

The key insight from VDT: Without explicit prevention, variational
representations can collapse - all inputs map to similar latents,
destroying discriminative power.

VDT's L_dcc (Dual Component Constraint):
    L_dcc = L_recon + β·L_kl

The β weighting is critical. VDT shows 10% F1 drop without L_dcc!

YRSN Application:
    Prevent R/S/N projections from collapsing to same representation.
    Different context types must remain distinguishable.

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
from collections import deque
import numpy as np


@dataclass
class SCPConfig:
    """Configuration for Semantic Collapse Prevention."""
    beta_kl: float = 1.5          # KL weight (VDT optimal)
    gamma_recon: float = 1.0      # Reconstruction weight
    diversity_weight: float = 0.1  # R/S/N diversity
    min_variance: float = 0.01    # Minimum allowed variance
    collapse_threshold: float = 0.1  # Distance below this = collapse
    monitor_window: int = 100


class SemanticCollapsePreventor(nn.Module):
    """
    Prevent semantic collapse in variational R/S/N representations.

    VDT Insight: L_dcc = L_recon + β·L_kl prevents collapse.
    β = 1.5 is optimal (Table 4: 10% F1 drop without).

    Collapse Types:
    1. Posterior collapse: All inputs → same z (variance → 0)
    2. R/S/N collapse: R ≈ S ≈ N (no discrimination)
    3. Mode collapse: Limited diversity in outputs
    """

    def __init__(self, config: Optional[SCPConfig] = None):
        super().__init__()

        if config is None:
            config = SCPConfig()
        self.config = config

        # Monitoring
        self.variance_history = deque(maxlen=config.monitor_window)
        self.diversity_history = deque(maxlen=config.monitor_window)

    def compute_kl_loss(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        free_bits: float = 0.0
    ) -> torch.Tensor:
        """
        Compute KL divergence with optional free bits.

        Free bits: Allow some "free" KL before penalty kicks in.
        Prevents over-regularization that leads to collapse.
        """
        # Per-dimension KL
        kl_per_dim = -0.5 * (1 + log_var - mu.pow(2) - log_var.exp())

        # Apply free bits (don't penalize KL below threshold)
        if free_bits > 0:
            kl_per_dim = F.relu(kl_per_dim - free_bits)

        return kl_per_dim.sum(dim=-1).mean()

    def compute_reconstruction_loss(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        reduction: str = 'mean'
    ) -> torch.Tensor:
        """
        Compute reconstruction loss.
        """
        return F.mse_loss(x_recon, x, reduction=reduction)

    def compute_diversity_loss(
        self,
        R: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor
    ) -> torch.Tensor:
        """
        Encourage diversity between R, S, N representations.

        If R ≈ S ≈ N, the decomposition is useless.
        Penalize when they become too similar.
        """
        # Cosine similarity between component means
        R_mean = R.mean(dim=0)
        S_mean = S.mean(dim=0)
        N_mean = N.mean(dim=0)

        cos_RS = F.cosine_similarity(R_mean, S_mean, dim=0)
        cos_RN = F.cosine_similarity(R_mean, N_mean, dim=0)
        cos_SN = F.cosine_similarity(S_mean, N_mean, dim=0)

        # We want low similarity → penalize high similarity
        diversity_loss = (cos_RS.abs() + cos_RN.abs() + cos_SN.abs()) / 3

        return diversity_loss

    def compute_variance_floor_loss(
        self,
        log_var: torch.Tensor
    ) -> torch.Tensor:
        """
        Prevent variance from collapsing to zero.

        When variance → 0, the model becomes deterministic and
        loses the benefits of variational inference.
        """
        variance = log_var.exp()
        # Penalize variance below minimum
        floor_violation = F.relu(self.config.min_variance - variance)
        return floor_violation.mean()

    def compute_dcc_loss(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        R: Optional[torch.Tensor] = None,
        S: Optional[torch.Tensor] = None,
        N: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Compute complete Dual Component Constraint loss.

        L_dcc = γ·L_recon + β·L_kl + δ·L_diversity + ε·L_floor

        This is the main SCP loss function.
        """
        losses = {}

        # Reconstruction
        losses['reconstruction'] = self.config.gamma_recon * self.compute_reconstruction_loss(x, x_recon)

        # KL divergence
        losses['kl'] = self.config.beta_kl * self.compute_kl_loss(mu, log_var)

        # R/S/N diversity (if provided)
        if R is not None and S is not None and N is not None:
            losses['diversity'] = self.config.diversity_weight * self.compute_diversity_loss(R, S, N)

        # Variance floor
        losses['variance_floor'] = self.compute_variance_floor_loss(log_var)

        # Total
        losses['total'] = sum(losses.values())

        return losses

    def detect_collapse(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        R: Optional[torch.Tensor] = None,
        S: Optional[torch.Tensor] = None,
        N: Optional[torch.Tensor] = None
    ) -> Dict[str, bool]:
        """
        Detect various collapse types.
        """
        collapse_types = {}

        # Posterior collapse: variance too low
        avg_var = log_var.exp().mean().item()
        self.variance_history.append(avg_var)
        collapse_types['posterior_collapse'] = avg_var < self.config.min_variance

        # Mode collapse: all means similar
        if mu.shape[0] > 1:
            mean_distances = torch.pdist(mu).mean().item()
            collapse_types['mode_collapse'] = mean_distances < self.config.collapse_threshold

        # R/S/N collapse: components too similar
        if R is not None and S is not None and N is not None:
            diversity = 1 - self.compute_diversity_loss(R, S, N).item()
            self.diversity_history.append(diversity)
            collapse_types['rsn_collapse'] = diversity < 0.3

        return collapse_types

    def forward(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        R: Optional[torch.Tensor] = None,
        S: Optional[torch.Tensor] = None,
        N: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Full SCP analysis and loss computation.
        """
        # Compute losses
        losses = self.compute_dcc_loss(x, x_recon, mu, log_var, R, S, N)

        # Detect collapse
        collapse = self.detect_collapse(mu, log_var, R, S, N)

        return {
            **losses,
            'collapse_detected': collapse,
            'avg_variance': log_var.exp().mean(),
            'variance_trend': np.mean(list(self.variance_history)) if self.variance_history else 0,
        }


class DualComponentConstraint(nn.Module):
    """
    Simplified L_dcc implementation for direct use.

    L_dcc = L_recon + β·L_kl

    This is the core VDT contribution.
    """

    def __init__(self, beta: float = 1.5):
        super().__init__()
        self.beta = beta

    def forward(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        log_var: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute L_dcc.
        """
        recon_loss = F.mse_loss(x_recon, x)
        kl_loss = -0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp(), dim=-1).mean()

        return recon_loss + self.beta * kl_loss


class CollapseAwareLoss(nn.Module):
    """
    Loss function that adapts when collapse is detected.

    When collapse detected:
    - Increase diversity weight
    - Decrease KL weight (let variance grow)
    - Add variance regularization
    """

    def __init__(
        self,
        base_beta: float = 1.5,
        base_diversity: float = 0.1,
        collapse_beta_multiplier: float = 0.5,
        collapse_diversity_multiplier: float = 3.0
    ):
        super().__init__()

        self.scp = SemanticCollapsePreventor(SCPConfig(
            beta_kl=base_beta,
            diversity_weight=base_diversity,
        ))

        self.base_beta = base_beta
        self.base_diversity = base_diversity
        self.collapse_beta_mult = collapse_beta_multiplier
        self.collapse_diversity_mult = collapse_diversity_multiplier

    def forward(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        R: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Compute collapse-aware loss.
        """
        # Detect collapse
        collapse = self.scp.detect_collapse(mu, log_var, R, S, N)

        # Adapt weights based on collapse detection
        if any(collapse.values()):
            # Collapse detected - adjust weights
            self.scp.config.beta_kl = self.base_beta * self.collapse_beta_mult
            self.scp.config.diversity_weight = self.base_diversity * self.collapse_diversity_mult
        else:
            # No collapse - use base weights
            self.scp.config.beta_kl = self.base_beta
            self.scp.config.diversity_weight = self.base_diversity

        # Compute losses with adapted weights
        result = self.scp(x, x_recon, mu, log_var, R, S, N)

        return result


class CorrelationAlignmentLoss(nn.Module):
    """
    L_idc: Intra-Domain Correlation Alignment Loss

    IDOL-inspired: Align the correlation structure of R/S/N projections
    with ground truth labels.

    Key Insight: If two samples have similar R/S/N projections, they should
    have similar labels. If two samples have different labels, their
    projections should differ.

    Formula:
        L_idc = MAE(P·P^T, Y·Y^T)

    Where P = [R, S, N] projections and Y = label indicators.

    This provides implicit regularization that improves projection
    discriminability, particularly in low-data regimes.

    Reference: IDOL (Yang et al., NeurIPS 2024)
    """

    def __init__(self, normalize: bool = True):
        super().__init__()
        self.normalize = normalize

    def forward(
        self,
        rsn_projections: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute correlation alignment loss.

        Args:
            rsn_projections: [B, 3] or [B, D] tensor of R/S/N scores or concatenated projections
            labels: [B, C] one-hot or soft labels, or [B] class indices

        Returns:
            Correlation alignment loss (scalar)
        """
        # Handle class indices
        if labels.dim() == 1:
            num_classes = labels.max().item() + 1
            labels = F.one_hot(labels, num_classes).float()

        # Normalize for correlation computation
        if self.normalize:
            P_norm = F.normalize(rsn_projections.float(), dim=-1)
            Y_norm = F.normalize(labels.float(), dim=-1)
        else:
            P_norm = rsn_projections.float()
            Y_norm = labels.float()

        # Correlation matrices
        P_corr = P_norm @ P_norm.T  # [B, B]
        Y_corr = Y_norm @ Y_norm.T  # [B, B]

        # Align correlation structures using MAE
        return F.l1_loss(P_corr, Y_corr)

    def forward_with_components(
        self,
        R: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute L_idc from separate R, S, N components.

        Args:
            R: [B, D] relevance projections
            S: [B, D] superfluous projections
            N: [B, D] noise projections
            labels: [B, C] or [B] labels

        Returns:
            Correlation alignment loss
        """
        # Compute norms as RSN scores
        R_norm = torch.norm(R, dim=-1, keepdim=True)
        S_norm = torch.norm(S, dim=-1, keepdim=True)
        N_norm = torch.norm(N, dim=-1, keepdim=True)

        rsn_projections = torch.cat([R_norm, S_norm, N_norm], dim=-1)
        return self.forward(rsn_projections, labels)


def correlation_alignment_loss(
    rsn_projections: torch.Tensor,
    labels: torch.Tensor
) -> torch.Tensor:
    """
    Standalone function for L_idc correlation alignment loss.

    IDOL-inspired: Align intra-sample correlation patterns.

    If two samples have similar R/S/N projections, they should have similar labels.
    If two samples have different labels, their projections should differ.

    Args:
        rsn_projections: [B, 3] tensor of [R, S, N] scores
        labels: [B, C] one-hot or soft labels

    Returns:
        Correlation alignment loss (scalar)
    """
    # Handle class indices
    if labels.dim() == 1:
        num_classes = labels.max().item() + 1
        labels = F.one_hot(labels, num_classes).float()

    # Normalize for correlation computation
    P_norm = F.normalize(rsn_projections.float(), dim=-1)
    Y_norm = F.normalize(labels.float(), dim=-1)

    # Correlation matrices
    P_corr = P_norm @ P_norm.T  # [B, B]
    Y_corr = Y_norm @ Y_norm.T  # [B, B]

    # Align correlation structures
    return F.l1_loss(P_corr, Y_corr)


class RSNCollapseMonitor:
    """
    Monitor for R/S/N representation collapse over time.

    Provides alerts and recommendations when collapse detected.
    """

    def __init__(self, window_size: int = 100):
        self.window_size = window_size

        self.r_s_similarity = deque(maxlen=window_size)
        self.r_n_similarity = deque(maxlen=window_size)
        self.s_n_similarity = deque(maxlen=window_size)
        self.variance_history = deque(maxlen=window_size)

    def update(
        self,
        R: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor,
        log_var: torch.Tensor
    ):
        """Update monitoring statistics."""
        with torch.no_grad():
            R_mean = R.mean(0)
            S_mean = S.mean(0)
            N_mean = N.mean(0)

            self.r_s_similarity.append(
                F.cosine_similarity(R_mean, S_mean, dim=0).item()
            )
            self.r_n_similarity.append(
                F.cosine_similarity(R_mean, N_mean, dim=0).item()
            )
            self.s_n_similarity.append(
                F.cosine_similarity(S_mean, N_mean, dim=0).item()
            )
            self.variance_history.append(log_var.exp().mean().item())

    def get_status(self) -> Dict[str, any]:
        """Get current collapse monitoring status."""
        if len(self.r_s_similarity) < 10:
            return {'status': 'insufficient_data'}

        avg_rs = np.mean(list(self.r_s_similarity)[-20:])
        avg_rn = np.mean(list(self.r_n_similarity)[-20:])
        avg_sn = np.mean(list(self.s_n_similarity)[-20:])
        avg_var = np.mean(list(self.variance_history)[-20:])

        alerts = []

        if abs(avg_rs) > 0.8:
            alerts.append('HIGH_RS_SIMILARITY')
        if abs(avg_rn) > 0.8:
            alerts.append('HIGH_RN_SIMILARITY')
        if abs(avg_sn) > 0.8:
            alerts.append('HIGH_SN_SIMILARITY')
        if avg_var < 0.01:
            alerts.append('VARIANCE_COLLAPSE')

        return {
            'status': 'collapse_risk' if alerts else 'healthy',
            'alerts': alerts,
            'r_s_similarity': avg_rs,
            'r_n_similarity': avg_rn,
            's_n_similarity': avg_sn,
            'avg_variance': avg_var,
            'recommendation': self._get_recommendation(alerts),
        }

    def _get_recommendation(self, alerts: List[str]) -> str:
        if not alerts:
            return 'Continue training normally'

        if 'VARIANCE_COLLAPSE' in alerts:
            return 'Decrease β (KL weight) to allow higher variance'

        if len(alerts) >= 2:
            return 'Increase diversity loss weight significantly'

        return 'Increase diversity loss weight'


# =============================================================================
# Demo
# =============================================================================

def demo_scp():
    """Demonstrate SCP functionality."""
    print("=" * 60)
    print("SCP: Semantic Collapse Prevention Demo")
    print("=" * 60)

    # Create SCP
    scp = SemanticCollapsePreventor()

    # Simulate healthy representations
    print("\n1. Healthy representations:")
    x = torch.randn(32, 256)
    x_recon = x + 0.1 * torch.randn_like(x)  # Good reconstruction
    mu = torch.randn(32, 64)
    log_var = torch.zeros(32, 64) - 1  # Reasonable variance

    R = torch.randn(32, 64)
    S = torch.randn(32, 64) + 2  # Different from R
    N = torch.randn(32, 64) - 2  # Different from R and S

    result = scp(x, x_recon, mu, log_var, R, S, N)
    print(f"   Total loss: {result['total']:.4f}")
    print(f"   Collapse detected: {result['collapse_detected']}")

    # Simulate collapsing representations
    print("\n2. Collapsing representations:")
    mu_collapsed = torch.ones(32, 64) * 0.5  # All similar
    log_var_collapsed = torch.ones(32, 64) * -10  # Near-zero variance

    R_collapsed = torch.ones(32, 64)
    S_collapsed = torch.ones(32, 64) * 1.01  # Almost same as R
    N_collapsed = torch.ones(32, 64) * 0.99  # Almost same as R

    result_collapsed = scp(x, x_recon, mu_collapsed, log_var_collapsed,
                          R_collapsed, S_collapsed, N_collapsed)
    print(f"   Total loss: {result_collapsed['total']:.4f}")
    print(f"   Collapse detected: {result_collapsed['collapse_detected']}")

    # Show VDT's β=1.5 importance
    print("\n3. Effect of β (KL weight):")
    dcc_low = DualComponentConstraint(beta=0.1)
    dcc_optimal = DualComponentConstraint(beta=1.5)

    loss_low = dcc_low(x, x_recon, mu, log_var)
    loss_optimal = dcc_optimal(x, x_recon, mu, log_var)

    print(f"   β=0.1: L_dcc = {loss_low:.4f}")
    print(f"   β=1.5: L_dcc = {loss_optimal:.4f}")
    print("   VDT shows 10% F1 drop without proper β!")


if __name__ == "__main__":
    demo_scp()
