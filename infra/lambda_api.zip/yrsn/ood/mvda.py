"""
MVDA: Mean-Variance Decomposed Alignment
==========================================

Mechanism for deriving temperature directly from variance structure.

The key insight: In VGFA, we already have variance per factor.
This variance can directly inform temperature without computing α first.

τ = f(σ²) instead of τ = 1/α

This creates a more direct path from uncertainty to behavior.

YRSN Application:
    Temperature derived from representation variance, not quality score.
    High variance → high τ (exploratory)
    Low variance → low τ (deterministic)

Reference: Extension of VDT concepts
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class MVDAConfig:
    """Configuration for Mean-Variance Decomposed Alignment."""
    tau_min: float = 0.1
    tau_max: float = 5.0
    variance_scale: float = 2.0
    use_log_variance: bool = True
    aggregation: str = 'mean'  # 'mean', 'max', 'weighted'


class MeanVarianceDecomposedAlignment(nn.Module):
    """
    Decompose quality into mean (content) and variance (uncertainty) paths.

    Standard YRSN: quality α → temperature τ = 1/α
    MVDA: variance σ² → temperature τ directly

    Benefits:
    - More direct uncertainty → behavior mapping
    - Variance already computed by VGFA
    - No need for α computation for temperature
    """

    def __init__(self, config: Optional[MVDAConfig] = None):
        super().__init__()

        if config is None:
            config = MVDAConfig()
        self.config = config

    def variance_to_temperature(
        self,
        variance: torch.Tensor,
        per_component: bool = False
    ) -> torch.Tensor:
        """
        Convert variance to temperature.

        High variance → high temperature (exploratory)
        Low variance → low temperature (deterministic)

        Args:
            variance: [B, n_factors] or [B] - variance values
            per_component: Return per-factor temperature

        Returns:
            tau: Temperature values
        """
        if self.config.use_log_variance:
            # Use log for numerical stability
            log_var = torch.log(variance + 1e-8)
            # Scale and shift to get reasonable range
            scaled = log_var * self.config.variance_scale
        else:
            scaled = variance * self.config.variance_scale

        # Aggregate if needed
        if not per_component and variance.dim() > 1:
            if self.config.aggregation == 'mean':
                scaled = scaled.mean(dim=-1)
            elif self.config.aggregation == 'max':
                scaled = scaled.max(dim=-1).values
            else:
                scaled = scaled.mean(dim=-1)

        # Map to temperature range using sigmoid
        tau_normalized = torch.sigmoid(scaled)
        tau = self.config.tau_min + (self.config.tau_max - self.config.tau_min) * tau_normalized

        return tau

    def forward(
        self,
        mu: torch.Tensor,
        variance: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Compute decomposed quality metrics.

        Args:
            mu: [B, n_factors] - mean (content signal)
            variance: [B, n_factors] - variance (uncertainty)

        Returns:
            Dictionary with mean-based and variance-based metrics
        """
        # Mean path: content quality
        mu_norm = torch.norm(mu, dim=-1)
        mu_quality = torch.sigmoid(mu_norm)  # Normalized to [0, 1]

        # Variance path: uncertainty
        avg_variance = variance.mean(dim=-1)
        tau_from_variance = self.variance_to_temperature(variance)

        # Combined quality (weighted by inverse variance)
        weights = 1.0 / (variance + 1e-8)
        weights = weights / weights.sum(dim=-1, keepdim=True)
        weighted_mu = (mu * weights).sum(dim=-1)

        return {
            'mu_quality': mu_quality,
            'mu_weighted': weighted_mu,
            'avg_variance': avg_variance,
            'tau_from_variance': tau_from_variance,
            'confidence': 1.0 / (1.0 + avg_variance),  # Inverse variance as confidence
        }


class TemperatureFromVariance(nn.Module):
    """
    Direct τ = f(σ²) mapping for YRSN.

    This replaces the standard τ = 1/α with a variance-based computation.
    """

    def __init__(
        self,
        tau_min: float = 0.1,
        tau_max: float = 5.0,
        learnable: bool = True
    ):
        super().__init__()

        self.tau_min = tau_min
        self.tau_max = tau_max

        if learnable:
            self.scale = nn.Parameter(torch.tensor(2.0))
            self.shift = nn.Parameter(torch.tensor(0.0))
        else:
            self.register_buffer('scale', torch.tensor(2.0))
            self.register_buffer('shift', torch.tensor(0.0))

    def forward(
        self,
        var_R: torch.Tensor,
        var_S: torch.Tensor,
        var_N: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute temperature from R/S/N variances.

        Strategy: Temperature should be high when ANY component is uncertain.
        Use max variance across components.
        """
        # Per-sample max variance across components
        max_var = torch.stack([
            var_R.mean(dim=-1),
            var_S.mean(dim=-1),
            var_N.mean(dim=-1)
        ]).max(dim=0).values

        # Map to temperature
        log_var = torch.log(max_var + 1e-8)
        scaled = self.scale * log_var + self.shift
        tau_normalized = torch.sigmoid(scaled)

        tau = self.tau_min + (self.tau_max - self.tau_min) * tau_normalized

        return tau


class DualPathQuality(nn.Module):
    """
    Compute quality through two parallel paths:
    1. Mean path: α = R/(R+S+N) from gated means
    2. Variance path: ω from variance structure

    Combine for robust quality estimation.
    """

    def __init__(
        self,
        combination: str = 'multiply',  # 'multiply', 'min', 'weighted'
        alpha_weight: float = 0.5
    ):
        super().__init__()
        self.combination = combination
        self.alpha_weight = alpha_weight

        self.mvda = MeanVarianceDecomposedAlignment()
        self.tau_from_var = TemperatureFromVariance()

    def forward(
        self,
        R_gated: torch.Tensor,
        S_gated: torch.Tensor,
        N_gated: torch.Tensor,
        var_R: torch.Tensor,
        var_S: torch.Tensor,
        var_N: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Compute quality through dual paths.
        """
        # Path 1: Mean-based quality (standard α)
        R_norm = torch.norm(R_gated, dim=-1)
        S_norm = torch.norm(S_gated, dim=-1)
        N_norm = torch.norm(N_gated, dim=-1)

        total = R_norm + S_norm + N_norm + 1e-8
        alpha = R_norm / total

        # Path 2: Variance-based confidence
        avg_var = (var_R.mean(-1) + var_S.mean(-1) + var_N.mean(-1)) / 3
        omega = 1.0 / (1.0 + avg_var)  # Inverse variance as confidence

        # Temperature from variance
        tau_variance = self.tau_from_var(var_R, var_S, var_N)

        # Temperature from alpha
        tau_alpha = 1.0 / (alpha + 1e-8)

        # Combine quality scores
        if self.combination == 'multiply':
            quality_combined = alpha * omega
        elif self.combination == 'min':
            quality_combined = torch.min(alpha, omega)
        else:  # weighted
            quality_combined = self.alpha_weight * alpha + (1 - self.alpha_weight) * omega

        # Combine temperatures (use max for safety)
        tau_combined = torch.max(tau_alpha, tau_variance)

        return {
            # Path 1 (mean)
            'alpha': alpha,
            'tau_alpha': tau_alpha,
            # Path 2 (variance)
            'omega': omega,
            'tau_variance': tau_variance,
            # Combined
            'quality': quality_combined,
            'tau': tau_combined,
            # Components
            'R_norm': R_norm,
            'S_norm': S_norm,
            'N_norm': N_norm,
            'avg_variance': avg_var,
        }


class VarianceWeightedQuality(nn.Module):
    """
    Weight quality contributions by inverse variance.

    Factors with low variance contribute more to quality score.
    Factors with high variance are down-weighted.
    """

    def __init__(self, temperature: float = 1.0):
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        mu: torch.Tensor,
        variance: torch.Tensor,
        labels: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Compute variance-weighted quality.

        Args:
            mu: [B, n_factors] - mean values
            variance: [B, n_factors] - variance values
            labels: Optional target weights

        Returns:
            quality: [B] - weighted quality score
        """
        # Inverse variance weights
        weights = 1.0 / (variance + 1e-8)
        weights = weights / weights.sum(dim=-1, keepdim=True)

        # Temperature scaling
        weights = F.softmax(weights / self.temperature, dim=-1)

        # Weighted mean magnitude
        weighted_quality = (mu.abs() * weights).sum(dim=-1)

        return weighted_quality


# =============================================================================
# Demo
# =============================================================================

def demo_mvda():
    """Demonstrate MVDA functionality."""
    print("=" * 60)
    print("MVDA: Mean-Variance Decomposed Alignment Demo")
    print("=" * 60)

    # Create dual path quality
    dual_path = DualPathQuality(combination='multiply')

    # Simulate YRSN outputs
    batch_size = 32
    rsn_dim = 256

    print("\n1. High confidence (low variance):")
    R_gated = torch.randn(batch_size, rsn_dim) * 2
    S_gated = torch.randn(batch_size, rsn_dim) * 0.5
    N_gated = torch.randn(batch_size, rsn_dim) * 0.3
    var_R = torch.ones(batch_size, rsn_dim) * 0.1
    var_S = torch.ones(batch_size, rsn_dim) * 0.1
    var_N = torch.ones(batch_size, rsn_dim) * 0.1

    result = dual_path(R_gated, S_gated, N_gated, var_R, var_S, var_N)
    print(f"   α (mean path): {result['alpha'].mean():.3f}")
    print(f"   ω (variance path): {result['omega'].mean():.3f}")
    print(f"   τ from α: {result['tau_alpha'].mean():.3f}")
    print(f"   τ from variance: {result['tau_variance'].mean():.3f}")
    print(f"   Combined τ: {result['tau'].mean():.3f}")

    print("\n2. Low confidence (high variance):")
    var_R_high = torch.ones(batch_size, rsn_dim) * 2.0
    var_S_high = torch.ones(batch_size, rsn_dim) * 2.0
    var_N_high = torch.ones(batch_size, rsn_dim) * 2.0

    result_high = dual_path(R_gated, S_gated, N_gated, var_R_high, var_S_high, var_N_high)
    print(f"   α (mean path): {result_high['alpha'].mean():.3f}")
    print(f"   ω (variance path): {result_high['omega'].mean():.3f}")
    print(f"   τ from α: {result_high['tau_alpha'].mean():.3f}")
    print(f"   τ from variance: {result_high['tau_variance'].mean():.3f}")
    print(f"   Combined τ: {result_high['tau'].mean():.3f}")

    print("\n" + "-" * 40)
    print("Key Insight: Variance provides direct path to temperature!")
    print("High variance → high τ regardless of α")
    print("-" * 40)


if __name__ == "__main__":
    demo_mvda()
