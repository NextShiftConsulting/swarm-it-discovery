"""
MSDF: Multi-Source Domain Fusion
=================================

Mechanism for fusing information from multiple context sources.

The key insight from VDT: Multi-source training (ALL→target) significantly
outperforms single-source (one→target). VDT shows 84.52% vs 81.65%.

YRSN Application:
    Multiple context sources (databases, APIs, documents) should be
    fused intelligently, not just concatenated. Weight sources by
    their reliability (omega history) and domain relevance.

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, List, Tuple
from collections import deque
import numpy as np


@dataclass
class MSDFConfig:
    """Configuration for Multi-Source Domain Fusion."""
    n_sources: int = 10
    hidden_dim: int = 256
    fusion_method: str = 'attention'  # 'attention', 'weighted', 'gated'
    reliability_decay: float = 0.99
    min_reliability: float = 0.1
    max_reliability: float = 1.0
    quarantine_threshold: float = 0.3


class SourceReliabilityTracker(nn.Module):
    """
    Track reliability of each context source over time.

    Reliability based on:
    1. Historical omega (OOD score)
    2. Consistency of quality
    3. Error rate (if feedback available)
    """

    def __init__(self, n_sources: int = 10, decay: float = 0.99):
        super().__init__()

        self.n_sources = n_sources
        self.decay = decay

        # Running statistics per source
        self.register_buffer('omega_ema', torch.ones(n_sources) * 0.8)
        self.register_buffer('omega_var', torch.ones(n_sources) * 0.1)
        self.register_buffer('sample_count', torch.zeros(n_sources))
        self.register_buffer('error_rate', torch.zeros(n_sources))

        # History for trend analysis
        self.omega_history: Dict[int, deque] = {
            i: deque(maxlen=100) for i in range(n_sources)
        }

    def update(
        self,
        source_id: int,
        omega: torch.Tensor,
        error: Optional[torch.Tensor] = None
    ):
        """
        Update statistics for a source.

        Args:
            source_id: Source identifier
            omega: OOD scores from this source
            error: Optional error indicator (1 = error, 0 = correct)
        """
        batch_omega = omega.mean().item()
        self.omega_history[source_id].append(batch_omega)

        # EMA update for omega
        n = self.sample_count[source_id].item()
        batch_size = omega.shape[0]

        if n == 0:
            self.omega_ema[source_id] = batch_omega
        else:
            self.omega_ema[source_id] = (
                self.decay * self.omega_ema[source_id] +
                (1 - self.decay) * batch_omega
            )

        # Variance update
        if len(self.omega_history[source_id]) > 10:
            self.omega_var[source_id] = np.var(list(self.omega_history[source_id])[-20:])

        # Error rate update (if provided)
        if error is not None:
            error_rate = error.float().mean().item()
            self.error_rate[source_id] = (
                self.decay * self.error_rate[source_id] +
                (1 - self.decay) * error_rate
            )

        self.sample_count[source_id] += batch_size

    def get_reliability(self, source_id: int) -> float:
        """
        Get reliability score for a source.

        Combines omega history and error rate.
        """
        omega = self.omega_ema[source_id].item()
        var = self.omega_var[source_id].item()
        error = self.error_rate[source_id].item()

        # Reliability = high omega, low variance, low error
        reliability = omega * (1 - var) * (1 - error)

        return max(0.1, min(1.0, reliability))

    def get_all_reliabilities(self) -> torch.Tensor:
        """Get reliability scores for all sources."""
        return torch.tensor([
            self.get_reliability(i) for i in range(self.n_sources)
        ])

    def should_quarantine(self, source_id: int, threshold: float = 0.3) -> bool:
        """Check if source should be quarantined."""
        return self.get_reliability(source_id) < threshold

    def get_drift_rate(self, source_id: int) -> float:
        """Get omega trend for a source (negative = drifting OOD)."""
        history = list(self.omega_history[source_id])
        if len(history) < 20:
            return 0.0

        x = np.arange(len(history))
        slope = np.polyfit(x, history, 1)[0]
        return slope


class AdaptiveSourceWeighting(nn.Module):
    """
    Compute adaptive weights for source fusion.

    Weight sources by:
    1. Reliability (from tracker)
    2. Relevance (learned attention)
    3. Current quality (omega)
    """

    def __init__(
        self,
        n_sources: int = 10,
        hidden_dim: int = 256,
        use_attention: bool = True
    ):
        super().__init__()

        self.tracker = SourceReliabilityTracker(n_sources)
        self.use_attention = use_attention

        if use_attention:
            # Learned attention for source relevance
            self.query = nn.Linear(hidden_dim, hidden_dim // 4)
            self.key = nn.Linear(hidden_dim, hidden_dim // 4)

    def compute_weights(
        self,
        source_embeddings: Dict[int, torch.Tensor],
        query: Optional[torch.Tensor] = None
    ) -> Dict[int, torch.Tensor]:
        """
        Compute fusion weights for each source.

        Args:
            source_embeddings: {source_id: embeddings}
            query: Optional query for attention

        Returns:
            weights: {source_id: weight} normalized across sources
        """
        source_ids = list(source_embeddings.keys())
        weights = {}

        # Get reliability weights
        for sid in source_ids:
            reliability = self.tracker.get_reliability(sid)
            weights[sid] = reliability

        # Add attention weights if query provided
        if self.use_attention and query is not None:
            q = self.query(query.mean(dim=0, keepdim=True))  # [1, d]

            attention_scores = {}
            for sid, emb in source_embeddings.items():
                k = self.key(emb.mean(dim=0, keepdim=True))  # [1, d]
                score = (q * k).sum().item()
                attention_scores[sid] = score

            # Softmax over attention
            max_score = max(attention_scores.values())
            exp_scores = {
                sid: np.exp(score - max_score)
                for sid, score in attention_scores.items()
            }
            total = sum(exp_scores.values())
            attention_weights = {
                sid: exp / total for sid, exp in exp_scores.items()
            }

            # Combine reliability and attention
            for sid in source_ids:
                weights[sid] = 0.5 * weights[sid] + 0.5 * attention_weights[sid]

        # Normalize
        total = sum(weights.values())
        weights = {sid: w / total for sid, w in weights.items()}

        return weights


class MultiSourceDomainFusion(nn.Module):
    """
    Fuse context from multiple sources with adaptive weighting.

    VDT shows: Multi-source (ALL→U: 84.52%) >> Single-source (G→U: 81.65%)

    Fusion Methods:
    1. Weighted average (simple, interpretable)
    2. Attention-based (learned relevance)
    3. Gated fusion (learn what to keep/discard)
    """

    def __init__(self, config: Optional[MSDFConfig] = None):
        super().__init__()

        if config is None:
            config = MSDFConfig()
        self.config = config

        self.weighter = AdaptiveSourceWeighting(
            n_sources=config.n_sources,
            hidden_dim=config.hidden_dim,
            use_attention=(config.fusion_method == 'attention')
        )

        if config.fusion_method == 'gated':
            self.gate = nn.Sequential(
                nn.Linear(config.hidden_dim * 2, config.hidden_dim),
                nn.ReLU(),
                nn.Linear(config.hidden_dim, config.hidden_dim),
                nn.Sigmoid()
            )

    def fuse_weighted(
        self,
        source_embeddings: Dict[int, torch.Tensor],
        weights: Dict[int, float]
    ) -> torch.Tensor:
        """Simple weighted average fusion."""
        result = None
        for sid, emb in source_embeddings.items():
            w = weights[sid]
            if result is None:
                result = w * emb
            else:
                # Handle different batch sizes
                min_batch = min(result.shape[0], emb.shape[0])
                result = result[:min_batch] + w * emb[:min_batch]

        return result

    def fuse_gated(
        self,
        source_embeddings: Dict[int, torch.Tensor],
        weights: Dict[int, float]
    ) -> torch.Tensor:
        """Gated fusion - learn what to keep from each source."""
        # Start with weighted average
        weighted = self.fuse_weighted(source_embeddings, weights)

        # For each source, compute gate
        fused = torch.zeros_like(weighted)

        for sid, emb in source_embeddings.items():
            min_batch = min(weighted.shape[0], emb.shape[0])

            # Concatenate source with weighted average
            concat = torch.cat([emb[:min_batch], weighted[:min_batch]], dim=-1)
            gate = self.gate(concat)

            # Gated contribution
            fused[:min_batch] += weights[sid] * gate * emb[:min_batch]

        return fused

    def forward(
        self,
        source_embeddings: Dict[int, torch.Tensor],
        source_omegas: Optional[Dict[int, torch.Tensor]] = None,
        query: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Fuse embeddings from multiple sources.

        Args:
            source_embeddings: {source_id: [B, D] embeddings}
            source_omegas: {source_id: [B] omega scores} for updating tracker
            query: Optional query for attention weighting

        Returns:
            Dictionary with fused embeddings and metadata
        """
        # Update tracker with current omegas
        if source_omegas is not None:
            for sid, omega in source_omegas.items():
                self.weighter.tracker.update(sid, omega)

        # Compute weights
        weights = self.weighter.compute_weights(source_embeddings, query)

        # Check for quarantined sources
        active_sources = {
            sid: emb for sid, emb in source_embeddings.items()
            if not self.weighter.tracker.should_quarantine(
                sid, self.config.quarantine_threshold
            )
        }

        if not active_sources:
            # All sources quarantined - use with warning
            active_sources = source_embeddings
            quarantine_warning = True
        else:
            quarantine_warning = False

        # Recompute weights for active sources only
        active_weights = {
            sid: weights[sid] for sid in active_sources
        }
        total = sum(active_weights.values())
        active_weights = {sid: w / total for sid, w in active_weights.items()}

        # Fuse
        if self.config.fusion_method == 'gated':
            fused = self.fuse_gated(active_sources, active_weights)
        else:
            fused = self.fuse_weighted(active_sources, active_weights)

        return {
            'fused': fused,
            'weights': weights,
            'active_weights': active_weights,
            'n_active_sources': len(active_sources),
            'quarantine_warning': quarantine_warning,
            'source_reliabilities': {
                sid: self.weighter.tracker.get_reliability(sid)
                for sid in source_embeddings.keys()
            },
        }

    def get_source_report(self) -> Dict[int, Dict]:
        """Get detailed report on all sources."""
        report = {}
        for sid in range(self.config.n_sources):
            if self.weighter.tracker.sample_count[sid] > 0:
                report[sid] = {
                    'reliability': self.weighter.tracker.get_reliability(sid),
                    'omega_ema': self.weighter.tracker.omega_ema[sid].item(),
                    'omega_var': self.weighter.tracker.omega_var[sid].item(),
                    'error_rate': self.weighter.tracker.error_rate[sid].item(),
                    'sample_count': self.weighter.tracker.sample_count[sid].item(),
                    'drift_rate': self.weighter.tracker.get_drift_rate(sid),
                    'quarantined': self.weighter.tracker.should_quarantine(sid),
                }
        return report


# =============================================================================
# Demo
# =============================================================================

def demo_msdf():
    """Demonstrate MSDF functionality."""
    print("=" * 60)
    print("MSDF: Multi-Source Domain Fusion Demo")
    print("=" * 60)

    # Create fusion module
    fusion = MultiSourceDomainFusion(MSDFConfig(
        n_sources=5,
        hidden_dim=256,
        fusion_method='attention'
    ))

    # Simulate multiple sources with different quality
    print("\nSimulating 3 sources with different reliability:")

    # Source 0: High quality
    emb_0 = torch.randn(16, 256)
    omega_0 = torch.ones(16) * 0.9

    # Source 1: Medium quality
    emb_1 = torch.randn(16, 256)
    omega_1 = torch.ones(16) * 0.6

    # Source 2: Low quality (should be down-weighted)
    emb_2 = torch.randn(16, 256)
    omega_2 = torch.ones(16) * 0.25

    source_embeddings = {0: emb_0, 1: emb_1, 2: emb_2}
    source_omegas = {0: omega_0, 1: omega_1, 2: omega_2}

    # Simulate several batches to build up statistics
    for _ in range(10):
        result = fusion(source_embeddings, source_omegas)

    print(f"\nFusion weights after training:")
    for sid, weight in result['weights'].items():
        reliability = result['source_reliabilities'][sid]
        print(f"   Source {sid}: weight={weight:.3f}, reliability={reliability:.3f}")

    print(f"\nActive sources: {result['n_active_sources']}")
    print(f"Quarantine warning: {result['quarantine_warning']}")

    # Get detailed report
    print("\nDetailed source report:")
    report = fusion.get_source_report()
    for sid, stats in report.items():
        status = "QUARANTINED" if stats['quarantined'] else "active"
        print(f"   Source {sid} ({status}):")
        print(f"      Reliability: {stats['reliability']:.3f}")
        print(f"      Omega EMA: {stats['omega_ema']:.3f}")
        print(f"      Drift rate: {stats['drift_rate']:.6f}")


if __name__ == "__main__":
    demo_msdf()
