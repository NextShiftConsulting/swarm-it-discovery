"""
Shift Detection: Three-Shift OOD Taxonomy
==========================================

Implements the IDOL-inspired three-shift taxonomy for OOD detection:

1. Covariate Shift: P(X) != P(X') - Input distribution changed
2. Label Shift: P(Y) != P(Y') - Output distribution changed
3. Concept Shift: P(Y|X) != P(Y'|X') - Input-output mapping changed

Each shift type requires different detection strategies and remediation.

Reference: IDOL (Yang et al., NeurIPS 2024)
"""

import torch
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple, List, Any
from enum import Enum, auto
from collections import deque
import numpy as np


class ShiftType(Enum):
    """Types of distribution shift."""
    NONE = auto()           # In-distribution
    COVARIATE = auto()      # P(X) changed - input OOD
    LABEL = auto()          # P(Y) changed - output OOD
    CONCEPT = auto()        # P(Y|X) changed - mapping OOD
    UNKNOWN = auto()        # Cannot determine


@dataclass
class ShiftDetectionConfig:
    """Configuration for shift detection."""
    # Covariate shift thresholds
    mahalanobis_threshold: float = 3.0  # Standard deviations

    # Label shift thresholds
    omega_window: int = 50              # Window for omega tracking
    omega_decline_threshold: float = -0.15  # Trigger on 15% decline

    # Concept shift thresholds
    alpha_omega_variance_threshold: float = 0.05  # High variance = concept shift
    concept_window: int = 20            # Window for variance computation

    # General
    min_samples_for_detection: int = 10


@dataclass
class ShiftDetectionResult:
    """Result from shift detection."""
    shift_type: ShiftType
    description: str
    confidence: float
    details: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""


class ReferenceDistribution:
    """
    Tracks reference distribution statistics for covariate shift detection.

    Maintains running mean and covariance of in-distribution embeddings.
    """

    def __init__(self, embed_dim: int, max_samples: int = 10000):
        self.embed_dim = embed_dim
        self.max_samples = max_samples

        # Running statistics
        self.n_samples = 0
        self.mean = None
        self.cov = None
        self.cov_inv = None

        # Sample buffer for initial estimation
        self._buffer: List[torch.Tensor] = []
        self._buffer_size = 1000

    def update(self, x: torch.Tensor):
        """
        Update reference distribution with new samples.

        Args:
            x: [B, embed_dim] - input embeddings
        """
        x = x.detach()

        if self.n_samples < self._buffer_size:
            # Buffer phase: collect samples
            self._buffer.append(x.cpu())
            self.n_samples += x.shape[0]

            if self.n_samples >= self._buffer_size:
                # Compute initial statistics
                all_samples = torch.cat(self._buffer, dim=0)
                self.mean = all_samples.mean(dim=0)
                centered = all_samples - self.mean
                self.cov = (centered.T @ centered) / (self.n_samples - 1)

                # Regularize covariance for numerical stability
                self.cov = self.cov + 1e-5 * torch.eye(self.embed_dim)
                self.cov_inv = torch.linalg.inv(self.cov)

                self._buffer = []  # Free memory
        else:
            # Online update using Welford's algorithm
            batch_mean = x.mean(dim=0).cpu()
            batch_size = x.shape[0]

            # Update mean
            delta = batch_mean - self.mean
            self.mean = self.mean + delta * batch_size / (self.n_samples + batch_size)

            self.n_samples += batch_size

            # Periodically recompute covariance inverse
            if self.n_samples % 1000 == 0 and self.cov is not None:
                self.cov_inv = torch.linalg.inv(self.cov)

    def mahalanobis_distance(self, x: torch.Tensor) -> torch.Tensor:
        """
        Compute Mahalanobis distance from reference distribution.

        Args:
            x: [B, embed_dim] - input embeddings

        Returns:
            distances: [B] - Mahalanobis distance per sample
        """
        if self.mean is None or self.cov_inv is None:
            # Not enough samples yet
            return torch.zeros(x.shape[0], device=x.device)

        x_cpu = x.detach().cpu()
        centered = x_cpu - self.mean

        # Mahalanobis: sqrt((x-μ)^T Σ^-1 (x-μ))
        left = centered @ self.cov_inv
        distances = torch.sqrt((left * centered).sum(dim=-1))

        return distances.to(x.device)

    @property
    def is_ready(self) -> bool:
        """Check if reference distribution has enough samples."""
        return self.mean is not None and self.cov_inv is not None


class OmegaTracker:
    """
    Tracks omega (ω) history for label shift detection.

    Label shift manifests as declining ω over time even when
    inputs appear normal (covariate in-distribution).
    """

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.history = deque(maxlen=window_size)
        self.timestamps = deque(maxlen=window_size)
        self._step = 0

    def update(self, omega: torch.Tensor):
        """
        Update omega history.

        Args:
            omega: [B] or scalar - omega values
        """
        if omega.dim() > 0:
            omega_val = omega.mean().item()
        else:
            omega_val = omega.item()

        self.history.append(omega_val)
        self.timestamps.append(self._step)
        self._step += 1

    def get_trend(self, window: Optional[int] = None) -> float:
        """
        Compute omega trend (slope) over window.

        Returns:
            Negative value indicates declining omega (potential label shift)
        """
        if len(self.history) < 10:
            return 0.0

        if window is None:
            window = len(self.history)
        window = min(window, len(self.history))

        recent = list(self.history)[-window:]

        # Simple linear regression slope
        x = np.arange(len(recent))
        y = np.array(recent)

        # slope = Cov(x,y) / Var(x)
        x_mean = x.mean()
        y_mean = y.mean()

        cov_xy = ((x - x_mean) * (y - y_mean)).mean()
        var_x = ((x - x_mean) ** 2).mean()

        if var_x < 1e-8:
            return 0.0

        slope = cov_xy / var_x

        # Normalize to percentage change per step
        return slope

    def detect_decline(self, threshold: float = -0.01) -> Tuple[bool, float]:
        """
        Detect significant omega decline.

        Args:
            threshold: Slope threshold (negative = decline)

        Returns:
            (is_declining, trend_value)
        """
        if len(self.history) < 20:
            return False, 0.0

        trend = self.get_trend()
        return trend < threshold, trend


class AlphaOmegaVarianceMonitor:
    """
    Monitors α_ω variance for concept shift detection.

    Concept shift: The input-output mapping has changed.
    Detection: High variance in α_ω despite stable inputs.
    """

    def __init__(self, window_size: int = 50):
        self.window_size = window_size
        self.alpha_omega_history = deque(maxlen=window_size)

    def update(self, alpha: torch.Tensor, omega: torch.Tensor):
        """
        Update with new α and ω values.

        Args:
            alpha: [B] - quality scores
            omega: [B] - reliability scores
        """
        # Compute α_ω = ω * α + (1-ω) * prior
        prior = 0.5
        alpha_omega = omega * alpha + (1 - omega) * prior

        # Store batch statistics
        self.alpha_omega_history.append({
            'mean': alpha_omega.mean().item(),
            'std': alpha_omega.std().item() if alpha_omega.numel() > 1 else 0.0,
            'min': alpha_omega.min().item(),
            'max': alpha_omega.max().item(),
        })

    def get_variance(self) -> float:
        """
        Compute variance of α_ω over window.

        High variance indicates concept shift (mapping unstable).
        """
        if len(self.alpha_omega_history) < 10:
            return 0.0

        means = [h['mean'] for h in self.alpha_omega_history]
        return np.var(means)

    def detect_concept_shift(self, threshold: float = 0.05) -> Tuple[bool, float]:
        """
        Detect concept shift from α_ω variance.

        Args:
            threshold: Variance threshold for concept shift

        Returns:
            (is_concept_shift, variance_value)
        """
        variance = self.get_variance()
        return variance > threshold, variance


class ShiftDetector:
    """
    Unified shift detection combining all three shift types.

    Architecture:
        Input → Covariate Check (Mahalanobis) →
                Label Check (ω trend) →
                Concept Check (α_ω variance) →
                Shift Classification

    Example:
        >>> detector = ShiftDetector(embed_dim=768)
        >>> # Feed in-distribution samples to build reference
        >>> for batch in train_loader:
        ...     detector.update_reference(batch['embeddings'])
        >>> # Detect shifts on new data
        >>> result = detector.detect(new_embeddings, omega, alpha)
        >>> if result.shift_type != ShiftType.NONE:
        ...     print(f"Detected: {result.description}")
    """

    def __init__(
        self,
        embed_dim: int,
        config: Optional[ShiftDetectionConfig] = None
    ):
        if config is None:
            config = ShiftDetectionConfig()
        self.config = config
        self.embed_dim = embed_dim

        # Component trackers
        self.reference = ReferenceDistribution(embed_dim)
        self.omega_tracker = OmegaTracker(config.omega_window)
        self.alpha_omega_monitor = AlphaOmegaVarianceMonitor(config.concept_window)

    def update_reference(self, x: torch.Tensor):
        """Update reference distribution with in-distribution samples."""
        self.reference.update(x)

    def update_tracking(
        self,
        omega: torch.Tensor,
        alpha: Optional[torch.Tensor] = None
    ):
        """Update omega and alpha tracking."""
        self.omega_tracker.update(omega)
        if alpha is not None:
            self.alpha_omega_monitor.update(alpha, omega)

    def detect_shift_type(
        self,
        x_current: torch.Tensor,
        omega: torch.Tensor,
        alpha: Optional[torch.Tensor] = None,
    ) -> ShiftDetectionResult:
        """
        Identify which distribution shift is occurring.

        Three-Shift Taxonomy [IDOL, Yang et al. 2024]:
        - Covariate: P(X) != P(X') - detected via Mahalanobis distance
        - Label: P(Y) != P(Y') - detected via omega decline
        - Concept: P(Y|X) != P(Y'|X') - detected via alpha_omega variance

        Args:
            x_current: [B, embed_dim] - current input embeddings
            omega: [B] - current omega (reliability) scores
            alpha: [B] - current alpha (quality) scores (optional)

        Returns:
            ShiftDetectionResult with shift type and details
        """
        # Update tracking
        self.update_tracking(omega, alpha)

        # Check 1: Covariate shift (input distribution changed)
        if self.reference.is_ready:
            mahal_dist = self.reference.mahalanobis_distance(x_current)
            avg_dist = mahal_dist.mean().item()

            if avg_dist > self.config.mahalanobis_threshold:
                return ShiftDetectionResult(
                    shift_type=ShiftType.COVARIATE,
                    description="Input OOD - Semantic/Structural shift detected",
                    confidence=min(1.0, avg_dist / (2 * self.config.mahalanobis_threshold)),
                    details={
                        'mahalanobis_distance': avg_dist,
                        'threshold': self.config.mahalanobis_threshold,
                        'per_sample_distances': mahal_dist.tolist(),
                    },
                    remediation="Filter input or retrain on new domain"
                )

        # Check 2: Label shift (output distribution changed)
        is_declining, trend = self.omega_tracker.detect_decline(
            self.config.omega_decline_threshold
        )
        if is_declining:
            return ShiftDetectionResult(
                shift_type=ShiftType.LABEL,
                description="Output OOD - Temporal drift detected (omega declining)",
                confidence=min(1.0, abs(trend) / abs(self.config.omega_decline_threshold)),
                details={
                    'omega_trend': trend,
                    'threshold': self.config.omega_decline_threshold,
                    'recent_omega': list(self.omega_tracker.history)[-10:],
                },
                remediation="Recalibrate model or update output distribution prior"
            )

        # Check 3: Concept shift (mapping changed)
        if alpha is not None:
            is_concept_shift, variance = self.alpha_omega_monitor.detect_concept_shift(
                self.config.alpha_omega_variance_threshold
            )
            if is_concept_shift:
                return ShiftDetectionResult(
                    shift_type=ShiftType.CONCEPT,
                    description="Mapping OOD - Domain/Adversarial shift (unstable alpha_omega)",
                    confidence=min(1.0, variance / (2 * self.config.alpha_omega_variance_threshold)),
                    details={
                        'alpha_omega_variance': variance,
                        'threshold': self.config.alpha_omega_variance_threshold,
                    },
                    remediation="Investigate data quality or adversarial inputs"
                )

        # No shift detected
        return ShiftDetectionResult(
            shift_type=ShiftType.NONE,
            description="In-distribution",
            confidence=1.0,
            details={
                'mahalanobis_distance': mahal_dist.mean().item() if self.reference.is_ready else None,
                'omega_trend': trend,
            }
        )


def detect_shift_type(
    x_current: torch.Tensor,
    x_reference_mean: torch.Tensor,
    x_reference_cov: torch.Tensor,
    omega_history: List[float],
    alpha: Optional[torch.Tensor] = None,
    threshold_covariate: float = 3.0,
    threshold_label: float = -0.15,
    threshold_concept: float = 0.05,
    window: int = 20,
) -> Tuple[ShiftType, str]:
    """
    Standalone function to identify which distribution shift is occurring.

    This matches the paper's pseudocode exactly.

    Args:
        x_current: Current input embeddings [B, D]
        x_reference_mean: Reference distribution mean [D]
        x_reference_cov: Reference distribution covariance [D, D]
        omega_history: List of historical omega values
        alpha: Current alpha scores (optional) [B]
        threshold_covariate: Mahalanobis distance threshold
        threshold_label: Omega trend threshold (negative = decline)
        threshold_concept: Alpha_omega variance threshold
        window: Window size for trend computation

    Returns:
        (ShiftType, description)
    """
    # Covariate shift: input distribution changed
    try:
        cov_inv = torch.linalg.inv(x_reference_cov + 1e-5 * torch.eye(x_reference_cov.shape[0]))
        centered = x_current - x_reference_mean
        mahal_dist = torch.sqrt((centered @ cov_inv * centered).sum(dim=-1))

        if mahal_dist.mean() > threshold_covariate:
            return ShiftType.COVARIATE, "Input OOD - Semantic/Structural"
    except Exception:
        pass  # Skip if covariance is singular

    # Label shift: output distribution changed (omega declining)
    if len(omega_history) > window:
        recent = omega_history[-window:]
        earlier = omega_history[-2*window:-window] if len(omega_history) > 2*window else omega_history[:window]

        omega_trend = np.mean(recent) - np.mean(earlier)

        if omega_trend < threshold_label:
            return ShiftType.LABEL, "Output OOD - Temporal drift"

    # Concept shift: relationship changed (alpha_omega unstable despite stable inputs)
    if alpha is not None and len(omega_history) > window:
        # Compute alpha_omega variance over recent samples
        omega_tensor = torch.tensor(omega_history[-window:])
        alpha_omega_samples = omega_tensor * alpha.mean() + (1 - omega_tensor) * 0.5
        alpha_omega_variance = alpha_omega_samples.var().item()

        if alpha_omega_variance > threshold_concept:
            return ShiftType.CONCEPT, "Mapping OOD - Domain/Adversarial"

    return ShiftType.NONE, "In-distribution"


# =============================================================================
# Demo
# =============================================================================

def demo_shift_detection():
    """Demonstrate shift detection functionality."""
    print("=" * 60)
    print("Three-Shift OOD Taxonomy Detection Demo")
    print("=" * 60)

    embed_dim = 256
    detector = ShiftDetector(embed_dim=embed_dim)

    # Phase 1: Build reference distribution with in-distribution data
    print("\n1. Building reference distribution...")
    for _ in range(20):
        x_id = torch.randn(32, embed_dim)
        detector.update_reference(x_id)
        omega = torch.ones(32) * 0.85 + torch.randn(32) * 0.05
        alpha = torch.ones(32) * 0.75 + torch.randn(32) * 0.05
        detector.update_tracking(omega, alpha)

    print(f"   Reference samples: {detector.reference.n_samples}")
    print(f"   Reference ready: {detector.reference.is_ready}")

    # Phase 2: Test covariate shift
    print("\n2. Testing Covariate Shift (OOD input)...")
    x_ood = torch.randn(32, embed_dim) * 5 + 10  # Different distribution
    omega = torch.ones(32) * 0.85
    alpha = torch.ones(32) * 0.75

    result = detector.detect_shift_type(x_ood, omega, alpha)
    print(f"   Shift Type: {result.shift_type.name}")
    print(f"   Description: {result.description}")
    print(f"   Confidence: {result.confidence:.2f}")
    if 'mahalanobis_distance' in result.details:
        print(f"   Mahalanobis: {result.details['mahalanobis_distance']:.2f}")

    # Phase 3: Test label shift (declining omega)
    print("\n3. Testing Label Shift (declining omega)...")
    # Reset omega tracker
    detector.omega_tracker = OmegaTracker(50)

    # Simulate declining omega
    for i in range(30):
        omega_declining = torch.ones(32) * (0.9 - i * 0.02)  # Decline from 0.9 to 0.32
        detector.update_tracking(omega_declining, alpha)

    x_normal = torch.randn(32, embed_dim)  # Normal input
    result = detector.detect_shift_type(x_normal, omega_declining, alpha)
    print(f"   Shift Type: {result.shift_type.name}")
    print(f"   Description: {result.description}")
    if 'omega_trend' in result.details:
        print(f"   Omega Trend: {result.details['omega_trend']:.4f}")

    # Phase 4: Test concept shift (unstable alpha_omega)
    print("\n4. Testing Concept Shift (unstable alpha_omega)...")
    # Reset monitors
    detector.omega_tracker = OmegaTracker(50)
    detector.alpha_omega_monitor = AlphaOmegaVarianceMonitor(50)

    # Simulate unstable alpha_omega
    for i in range(30):
        # Alternating high/low to create variance
        if i % 2 == 0:
            omega_var = torch.ones(32) * 0.9
            alpha_var = torch.ones(32) * 0.8
        else:
            omega_var = torch.ones(32) * 0.3
            alpha_var = torch.ones(32) * 0.4
        detector.update_tracking(omega_var, alpha_var)

    result = detector.detect_shift_type(x_normal, omega_var, alpha_var)
    print(f"   Shift Type: {result.shift_type.name}")
    print(f"   Description: {result.description}")
    if 'alpha_omega_variance' in result.details:
        print(f"   Alpha_omega Variance: {result.details['alpha_omega_variance']:.4f}")

    print("\n" + "=" * 60)
    print("Three-shift taxonomy enables targeted remediation!")
    print("=" * 60)


if __name__ == "__main__":
    demo_shift_detection()
