"""
SEDA: Shared Encoder Domain Alignment
======================================

Mechanism for forcing domain invariance through architectural constraints.

The key insight from VDT: Use the SAME encoder for all domains.
This architectural constraint forces representations to be domain-invariant
without explicit alignment losses.

Unlike domain adaptation approaches that add alignment losses:
- SEDA makes invariance a structural property
- Same weights process source and target
- No domain labels needed at test time

YRSN Application:
    All context sources (documents, databases, APIs) share the same
    R/S/N projection heads, forcing invariant representations.

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List


@dataclass
class SEDAConfig:
    """Configuration for Shared Encoder Domain Alignment."""
    embed_dim: int = 768
    latent_dim: int = 256
    n_domains: int = 1  # Will be expanded as domains discovered
    domain_embedding_dim: int = 64
    use_domain_embedding: bool = False  # Add domain info to input
    alignment_weight: float = 1.0
    use_mean_alignment: bool = True
    use_variance_alignment: bool = True


class SharedEncoderDomainAlignment(nn.Module):
    """
    Force domain invariance through shared encoder architecture.

    VDT Insight: Same θ for source/target forces invariance.
    No explicit alignment loss needed - it's structural.

    YRSN Extension: Single R/S/N projection heads for all sources.
    Different sources get different domain embeddings (optional),
    but share the core projection weights.
    """

    def __init__(self, config: Optional[SEDAConfig] = None):
        super().__init__()

        if config is None:
            config = SEDAConfig()
        self.config = config

        # Shared encoder (the invariance constraint)
        self.shared_encoder = nn.Sequential(
            nn.Linear(config.embed_dim, config.embed_dim),
            nn.LayerNorm(config.embed_dim),
            nn.GELU(),
            nn.Linear(config.embed_dim, config.latent_dim * 2),  # mu, logvar
        )

        # Optional: Domain embeddings (allow some domain-specific info)
        if config.use_domain_embedding:
            self.domain_embeddings = nn.Embedding(
                config.n_domains,
                config.domain_embedding_dim
            )
            self.domain_projector = nn.Linear(
                config.embed_dim + config.domain_embedding_dim,
                config.embed_dim
            )

        # For tracking per-domain statistics
        self.register_buffer('domain_means', torch.zeros(config.n_domains, config.latent_dim))
        self.register_buffer('domain_vars', torch.ones(config.n_domains, config.latent_dim))
        self.register_buffer('domain_counts', torch.zeros(config.n_domains))

    def encode(
        self,
        x: torch.Tensor,
        domain_id: Optional[int] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Encode input through shared encoder.

        Args:
            x: [B, embed_dim] - input embeddings
            domain_id: Optional domain identifier

        Returns:
            mu: [B, latent_dim]
            log_var: [B, latent_dim]
        """
        # Add domain embedding if specified
        if self.config.use_domain_embedding and domain_id is not None:
            domain_emb = self.domain_embeddings(
                torch.tensor([domain_id], device=x.device)
            ).expand(x.shape[0], -1)
            x = self.domain_projector(torch.cat([x, domain_emb], dim=-1))

        # Shared encoder
        out = self.shared_encoder(x)
        mu = out[:, :self.config.latent_dim]
        log_var = out[:, self.config.latent_dim:]

        # Update domain statistics
        if domain_id is not None and self.training:
            self._update_domain_stats(mu, log_var, domain_id)

        return mu, log_var

    def _update_domain_stats(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        domain_id: int
    ):
        """Update running statistics for domain."""
        with torch.no_grad():
            batch_mean = mu.mean(dim=0)
            batch_var = log_var.exp().mean(dim=0)

            n = self.domain_counts[domain_id]
            batch_size = mu.shape[0]

            # Online mean update
            if n == 0:
                self.domain_means[domain_id] = batch_mean
                self.domain_vars[domain_id] = batch_var
            else:
                delta = batch_mean - self.domain_means[domain_id]
                self.domain_means[domain_id] += delta * batch_size / (n + batch_size)
                self.domain_vars[domain_id] = (
                    (n * self.domain_vars[domain_id] + batch_size * batch_var) /
                    (n + batch_size)
                )

            self.domain_counts[domain_id] += batch_size

    def compute_alignment_loss(
        self,
        mu_source: torch.Tensor,
        logvar_source: torch.Tensor,
        mu_target: torch.Tensor,
        logvar_target: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute explicit alignment loss between domains.

        Even though architecture forces sharing, explicit alignment
        can help during training.
        """
        losses = []

        if self.config.use_mean_alignment:
            # Mean alignment (contrastive)
            mean_loss = F.mse_loss(mu_source.mean(0), mu_target.mean(0))
            losses.append(mean_loss)

        if self.config.use_variance_alignment:
            # Variance alignment
            var_source = logvar_source.exp().mean(0)
            var_target = logvar_target.exp().mean(0)
            var_loss = F.mse_loss(var_source, var_target)
            losses.append(var_loss)

        return self.config.alignment_weight * sum(losses) if losses else torch.tensor(0.0)

    def get_domain_divergence(
        self,
        domain_i: int,
        domain_j: int
    ) -> float:
        """
        Compute divergence between two domains based on statistics.
        """
        if self.domain_counts[domain_i] == 0 or self.domain_counts[domain_j] == 0:
            return float('inf')

        mean_diff = (self.domain_means[domain_i] - self.domain_means[domain_j]).pow(2).mean()
        var_diff = (self.domain_vars[domain_i] - self.domain_vars[domain_j]).pow(2).mean()

        return (mean_diff + var_diff).item()

    def forward(
        self,
        x: torch.Tensor,
        domain_id: Optional[int] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass through shared encoder.
        """
        mu, log_var = self.encode(x, domain_id)

        return {
            'mu': mu,
            'log_var': log_var,
            'var': log_var.exp(),
        }


class DomainInvariantEncoder(nn.Module):
    """
    Encoder explicitly trained for domain invariance.

    Combines SEDA (shared architecture) with gradient reversal
    for adversarial domain invariance.
    """

    def __init__(
        self,
        embed_dim: int = 768,
        latent_dim: int = 256,
        n_domains: int = 2,
        adversarial_weight: float = 0.1
    ):
        super().__init__()

        self.seda = SharedEncoderDomainAlignment(SEDAConfig(
            embed_dim=embed_dim,
            latent_dim=latent_dim,
            n_domains=n_domains,
        ))

        # Domain discriminator (for adversarial training)
        self.domain_discriminator = nn.Sequential(
            nn.Linear(latent_dim, latent_dim // 2),
            nn.ReLU(),
            nn.Linear(latent_dim // 2, n_domains),
        )

        self.adversarial_weight = adversarial_weight
        self.n_domains = n_domains

    def forward(
        self,
        x: torch.Tensor,
        domain_id: int
    ) -> Dict[str, torch.Tensor]:
        """
        Forward with domain invariance enforcement.
        """
        # Encode
        result = self.seda(x, domain_id)
        mu = result['mu']

        # Domain prediction (for adversarial loss)
        domain_logits = self.domain_discriminator(mu)
        domain_labels = torch.full((x.shape[0],), domain_id, device=x.device, dtype=torch.long)

        # Domain classification loss (to minimize for discriminator)
        domain_loss = F.cross_entropy(domain_logits, domain_labels)

        result['domain_logits'] = domain_logits
        result['domain_loss'] = domain_loss
        result['adversarial_loss'] = -self.adversarial_weight * domain_loss  # Negate for encoder

        return result


class MultiDomainRSNEncoder(nn.Module):
    """
    YRSN-specific: Shared R/S/N heads across all context sources.

    All sources share the same projection weights, forcing
    domain-invariant R/S/N decomposition.
    """

    def __init__(
        self,
        embed_dim: int = 768,
        rsn_dim: int = 256,
        n_sources: int = 10
    ):
        super().__init__()

        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim

        # SHARED projection heads (the key constraint)
        self.shared_R_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, rsn_dim * 2),  # mu, logvar
        )
        self.shared_S_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, rsn_dim * 2),
        )
        self.shared_N_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, rsn_dim * 2),
        )

        # Source embeddings (optional, for source-specific adjustments)
        self.source_embeddings = nn.Embedding(n_sources, embed_dim // 4)
        self.source_adapter = nn.Linear(embed_dim + embed_dim // 4, embed_dim)

        # Per-source statistics tracking
        self.register_buffer('source_omega_mean', torch.ones(n_sources) * 0.8)
        self.register_buffer('source_omega_count', torch.zeros(n_sources))

    def forward(
        self,
        x: torch.Tensor,
        source_id: Optional[int] = None,
        return_details: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Process through shared R/S/N heads.

        Args:
            x: [B, embed_dim] - input embeddings
            source_id: Optional source identifier
        """
        # Optional: Add source-specific information
        if source_id is not None:
            source_emb = self.source_embeddings(
                torch.tensor([source_id], device=x.device)
            ).expand(x.shape[0], -1)
            x = self.source_adapter(torch.cat([x, source_emb], dim=-1))

        # Shared R/S/N projections
        R_out = self.shared_R_head(x)
        S_out = self.shared_S_head(x)
        N_out = self.shared_N_head(x)

        # Split into mu, logvar
        mu_R, logvar_R = R_out.chunk(2, dim=-1)
        mu_S, logvar_S = S_out.chunk(2, dim=-1)
        mu_N, logvar_N = N_out.chunk(2, dim=-1)

        # Apply VGFA-style gating
        gate_R = torch.sigmoid(logvar_R)
        gate_S = torch.sigmoid(logvar_S)
        gate_N = torch.sigmoid(logvar_N)

        R_gated = mu_R * (1 - gate_R)
        S_gated = mu_S * (1 - gate_S)
        N_gated = mu_N * (1 - gate_N)

        # Compute norms and quality
        R_norm = torch.norm(R_gated, dim=-1)
        S_norm = torch.norm(S_gated, dim=-1)
        N_norm = torch.norm(N_gated, dim=-1)

        total = R_norm + S_norm + N_norm + 1e-8
        alpha = R_norm / total

        # Omega from gates
        avg_gate = (gate_R.mean(-1) + gate_S.mean(-1) + gate_N.mean(-1)) / 3
        omega = 1 - avg_gate

        # Update source statistics
        if source_id is not None and self.training:
            self._update_source_stats(omega, source_id)

        result = {
            'R': R_gated, 'S': S_gated, 'N': N_gated,
            'alpha': alpha, 'omega': omega,
            'tau': 1.0 / (alpha + 1e-8),
            'source_id': source_id,
        }

        if return_details:
            result.update({
                'mu_R': mu_R, 'mu_S': mu_S, 'mu_N': mu_N,
                'logvar_R': logvar_R, 'logvar_S': logvar_S, 'logvar_N': logvar_N,
                'gate_R': gate_R, 'gate_S': gate_S, 'gate_N': gate_N,
            })

        return result

    def _update_source_stats(self, omega: torch.Tensor, source_id: int):
        """Update running omega statistics for source."""
        with torch.no_grad():
            n = self.source_omega_count[source_id]
            batch_omega = omega.mean().item()
            batch_size = omega.shape[0]

            self.source_omega_mean[source_id] = (
                (n * self.source_omega_mean[source_id] + batch_size * batch_omega) /
                (n + batch_size)
            )
            self.source_omega_count[source_id] += batch_size

    def get_source_reliability(self, source_id: int) -> float:
        """Get reliability score for a source based on historical omega."""
        return self.source_omega_mean[source_id].item()


# =============================================================================
# Demo
# =============================================================================

def demo_seda():
    """Demonstrate SEDA functionality."""
    print("=" * 60)
    print("SEDA: Shared Encoder Domain Alignment Demo")
    print("=" * 60)

    # Create multi-domain encoder
    encoder = MultiDomainRSNEncoder(
        embed_dim=768,
        rsn_dim=256,
        n_sources=5
    )

    print("\nProcessing from different sources with SHARED weights:")

    # Process from different sources
    for source_id in range(3):
        x = torch.randn(16, 768)
        result = encoder(x, source_id=source_id)

        print(f"\n  Source {source_id}:")
        print(f"    Alpha: {result['alpha'].mean():.3f}")
        print(f"    Omega: {result['omega'].mean():.3f}")
        print(f"    Tau: {result['tau'].mean():.3f}")

    print("\n" + "-" * 40)
    print("Key Insight: SAME weights process ALL sources!")
    print("This forces domain-invariant R/S/N representations.")
    print("-" * 40)

    # Show source reliability
    print("\nSource reliability (from omega history):")
    for source_id in range(3):
        reliability = encoder.get_source_reliability(source_id)
        print(f"  Source {source_id}: {reliability:.3f}")


if __name__ == "__main__":
    demo_seda()
