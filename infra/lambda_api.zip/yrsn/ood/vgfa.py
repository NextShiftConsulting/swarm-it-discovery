"""
VGFA: Variance-Gated Factor Attenuation
========================================

Core mechanism for making OOD detection emergent from representation uncertainty.

The key insight from VDT: High variance in latent representations indicates
uncertainty about the input. Instead of computing a separate OOD score,
we use variance to directly attenuate uncertain features.

Formula:
    F = μ(1 - gate)    where gate = sigmoid(log σ²)

High variance → gate ≈ 1 → feature attenuated (suppressed)
Low variance → gate ≈ 0 → feature preserved

This replaces explicit OOD detectors (Mahalanobis, Energy) with an
intrinsic, differentiable mechanism that emerges from VAE-style training.

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
import numpy as np


@dataclass
class VGFAConfig:
    """Configuration for Variance-Gated Factor Attenuation."""
    n_factors: int = 256
    temperature_init: float = 1.0
    gate_bias_init: float = 0.0
    min_gate: float = 0.01  # Never fully preserve (numerical stability)
    max_gate: float = 0.99  # Never fully attenuate
    learnable_temperature: bool = True
    learnable_bias: bool = True


class VarianceGatedFactorAttenuation(nn.Module):
    """
    Attenuate disentangled factors based on representation uncertainty.

    Key Insight: High-variance factors contain less reliable information
    and should be down-weighted in downstream tasks.

    VDT Formula: F = μ(1 - sigmoid(log σ²))
    Extension: Per-factor gating with learned temperature

    YRSN Integration:
        - Apply to R/S/N projections separately
        - ω (OOD score) emerges from average gate activation
        - No separate OOD detector needed
    """

    def __init__(self, config: Optional[VGFAConfig] = None, n_factors: int = 256):
        super().__init__()

        if config is None:
            config = VGFAConfig(n_factors=n_factors)
        self.config = config

        # Per-factor learnable temperatures
        if config.learnable_temperature:
            self.temperatures = nn.Parameter(
                torch.ones(config.n_factors) * config.temperature_init
            )
        else:
            self.register_buffer(
                'temperatures',
                torch.ones(config.n_factors) * config.temperature_init
            )

        # Optional: Learn gate bias per factor
        if config.learnable_bias:
            self.gate_bias = nn.Parameter(
                torch.zeros(config.n_factors) + config.gate_bias_init
            )
        else:
            self.register_buffer(
                'gate_bias',
                torch.zeros(config.n_factors) + config.gate_bias_init
            )

    def compute_gates(self, log_var: torch.Tensor) -> torch.Tensor:
        """
        Compute per-factor gates from log-variance.

        Args:
            log_var: [B, n_factors] - log variance per factor

        Returns:
            gates: [B, n_factors] - attenuation gates in [0, 1]

        Theory:
            - High log_var → high gate → feature suppressed
            - Low log_var → low gate → feature preserved
            - Temperature controls sensitivity to variance changes
        """
        # Expand temperatures for batch
        temps = self.temperatures.unsqueeze(0)  # [1, n_factors]
        bias = self.gate_bias.unsqueeze(0)  # [1, n_factors]

        # Temperature-scaled sigmoid
        scaled_logvar = log_var / (temps + 1e-8)
        gates = torch.sigmoid(scaled_logvar + bias)

        # Clamp for numerical stability
        gates = torch.clamp(gates, self.config.min_gate, self.config.max_gate)

        return gates

    def forward(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        return_gates: bool = False
    ) -> torch.Tensor:
        """
        Apply variance-gated attenuation.

        Args:
            mu: [B, n_factors] - mean of latent distribution
            log_var: [B, n_factors] - log variance
            return_gates: Whether to return gate values

        Returns:
            z_attenuated: [B, n_factors] - uncertainty-attenuated features
            (optional) gates: [B, n_factors] - gate values
        """
        gates = self.compute_gates(log_var)
        z_attenuated = mu * (1 - gates)

        if return_gates:
            return z_attenuated, gates
        return z_attenuated

    def get_factor_confidence(self, log_var: torch.Tensor) -> torch.Tensor:
        """
        Return per-factor confidence scores (inverse of gates).

        High confidence = low variance = feature preserved
        """
        gates = self.compute_gates(log_var)
        return 1 - gates

    def get_omega(
        self,
        log_var: torch.Tensor,
        epsilon: Optional[torch.Tensor] = None,
        epsilon_weight: float = 0.3,
    ) -> torch.Tensor:
        """
        Compute ω (distributional alignment score) from gate activations AND reconstruction error.

        High ω = low average gate + low epsilon = in-distribution, good decomposition fit
        Low ω = high average gate OR high epsilon = OOD or poor decomposition fit

        ω captures two failure modes:
            1. High variance (uncertainty) → high gate → low ω
            2. High epsilon (unexplained signal) → low ω

        Args:
            log_var: [B, n_factors] - log variance per factor
            epsilon: [B] - optional reconstruction error per sample
            epsilon_weight: Weight for epsilon contribution (0-1), default 0.3

        Returns:
            omega: [B] - distributional alignment score in [0, 1]

        Formula:
            ω_var = 1 - mean(gates)              # from variance
            ω_eps = 1 / (1 + epsilon)            # from reconstruction error
            ω = (1 - w) * ω_var + w * ω_eps      # combined
        """
        # Variance-based omega (original mechanism)
        gates = self.compute_gates(log_var)
        omega_var = 1 - gates.mean(dim=-1)  # [B]

        # If no epsilon provided, return variance-only omega
        if epsilon is None:
            return omega_var

        # Epsilon-based omega: high epsilon → low omega
        # Using 1/(1+ε) which maps [0, ∞) → (0, 1]
        omega_eps = 1.0 / (1.0 + epsilon)  # [B]

        # Combine: weighted average of variance-based and epsilon-based omega
        omega = (1 - epsilon_weight) * omega_var + epsilon_weight * omega_eps

        return omega


class HierarchicalVGFA(nn.Module):
    """
    Extension: Hierarchical variance gating with factor dependencies.

    Insight: Some factors should only be attenuated if their
    parent factors are also uncertain (cascade attenuation).

    YRSN Application:
        - R depends on base embedding quality
        - S depends on R (superfluous is relative to relevance)
        - N depends on both (noise detection requires context)
    """

    def __init__(
        self,
        n_factors: int,
        dependency_graph: Optional[Dict[int, List[int]]] = None
    ):
        super().__init__()
        self.n_factors = n_factors

        # Default: no dependencies
        if dependency_graph is None:
            dependency_graph = {}
        self.dependency_graph = dependency_graph

        self.base_vgfa = VarianceGatedFactorAttenuation(n_factors=n_factors)

        # Dependency mixing weights
        self.dependency_weights = nn.ParameterDict()
        for child, parents in dependency_graph.items():
            if parents:
                self.dependency_weights[str(child)] = nn.Parameter(
                    torch.ones(len(parents)) / len(parents)
                )

    def forward(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        return_gates: bool = False
    ) -> torch.Tensor:
        """
        Apply hierarchical variance gating.

        Parent uncertainty propagates to children.
        """
        base_gates = self.base_vgfa.compute_gates(log_var)

        # Propagate parent uncertainty to children
        effective_gates = base_gates.clone()

        for child, parents in self.dependency_graph.items():
            if parents:
                weights = torch.softmax(
                    self.dependency_weights[str(child)], dim=0
                )
                parent_gates = base_gates[:, parents]  # [B, n_parents]
                parent_contribution = (parent_gates * weights.unsqueeze(0)).sum(dim=1)

                # Max of own gate and weighted parent gates
                effective_gates[:, child] = torch.max(
                    base_gates[:, child],
                    parent_contribution
                )

        z_attenuated = mu * (1 - effective_gates)

        if return_gates:
            return z_attenuated, effective_gates
        return z_attenuated


class RSNVariationalHead(nn.Module):
    """
    Single R, S, or N projection head with variational output.

    Produces (μ, log σ²) instead of just embedding.
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: Optional[int] = None
    ):
        super().__init__()

        if hidden_dim is None:
            hidden_dim = (input_dim + output_dim) // 2

        # Shared encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
        )

        # Separate heads for mean and log-variance
        self.mu_head = nn.Linear(hidden_dim, output_dim)
        self.logvar_head = nn.Linear(hidden_dim, output_dim)

        # Initialize logvar head to output small variances initially
        nn.init.zeros_(self.logvar_head.weight)
        nn.init.constant_(self.logvar_head.bias, -2.0)  # exp(-2) ≈ 0.14

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: [B, input_dim] - input embeddings

        Returns:
            mu: [B, output_dim] - mean
            log_var: [B, output_dim] - log variance
        """
        h = self.encoder(x)
        mu = self.mu_head(h)
        log_var = self.logvar_head(h)

        # Clamp log_var for numerical stability
        log_var = torch.clamp(log_var, min=-10.0, max=10.0)

        return mu, log_var

    def sample(
        self,
        mu: torch.Tensor,
        log_var: torch.Tensor,
        n_samples: int = 1
    ) -> torch.Tensor:
        """
        Reparameterization trick for sampling.
        """
        std = torch.exp(0.5 * log_var)
        eps = torch.randn(n_samples, *mu.shape, device=mu.device)
        return mu.unsqueeze(0) + eps * std.unsqueeze(0)


class YRSNProjectionHeads(nn.Module):
    """
    YRSN: R/S/N projections with variance-gated attenuation.

    This is the core YRSN module that replaces standard YRSN projections.
    Variance naturally encodes OOD uncertainty.

    Key differences from YRSN:
        1. Each projection outputs (μ, σ²) not just embedding
        2. VGFA gates uncertain features
        3. ω emerges from average gate activation
        4. No separate OOD detector needed
    """

    def __init__(
        self,
        embed_dim: int = 768,
        rsn_dim: int = 256,
        hidden_dim: Optional[int] = None,
        vgfa_config: Optional[VGFAConfig] = None
    ):
        super().__init__()

        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim

        # Variational projection heads
        self.head_R = RSNVariationalHead(embed_dim, rsn_dim, hidden_dim)
        self.head_S = RSNVariationalHead(embed_dim, rsn_dim, hidden_dim)
        self.head_N = RSNVariationalHead(embed_dim, rsn_dim, hidden_dim)

        # Per-component VGFA
        if vgfa_config is None:
            vgfa_config = VGFAConfig(n_factors=rsn_dim)

        self.vgfa_R = VarianceGatedFactorAttenuation(vgfa_config)
        self.vgfa_S = VarianceGatedFactorAttenuation(vgfa_config)
        self.vgfa_N = VarianceGatedFactorAttenuation(vgfa_config)

    def forward(
        self,
        x: torch.Tensor,
        return_details: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Process input through YRSN projection heads.

        Args:
            x: [B, embed_dim] - input embeddings
            return_details: Whether to return intermediate values

        Returns:
            Dictionary containing:
                - R, S, N: Gated projections
                - omega: OOD score (emergent from variance)
                - alpha: Quality score
                - tau: Temperature
        """
        # Get mean and variance for each component
        mu_R, logvar_R = self.head_R(x)
        mu_S, logvar_S = self.head_S(x)
        mu_N, logvar_N = self.head_N(x)

        # Apply variance gating
        R_gated, gates_R = self.vgfa_R(mu_R, logvar_R, return_gates=True)
        S_gated, gates_S = self.vgfa_S(mu_S, logvar_S, return_gates=True)
        N_gated, gates_N = self.vgfa_N(mu_N, logvar_N, return_gates=True)

        # Compute norms
        R_norm = torch.norm(R_gated, dim=-1)
        S_norm = torch.norm(S_gated, dim=-1)
        N_norm = torch.norm(N_gated, dim=-1)

        # Quality score
        total = R_norm + S_norm + N_norm + 1e-8
        alpha = R_norm / total

        # Omega emerges from average gate activation
        # High gates = high uncertainty = low omega = OOD
        avg_gate = (gates_R.mean(dim=-1) + gates_S.mean(dim=-1) + gates_N.mean(dim=-1)) / 3
        omega = 1 - avg_gate

        # Temperature from quality (already incorporates OOD via gating)
        tau = 1.0 / (alpha + 1e-8)

        result = {
            'R': R_gated,
            'S': S_gated,
            'N': N_gated,
            'alpha': alpha,
            'omega': omega,
            'tau': tau,
            'R_norm': R_norm,
            'S_norm': S_norm,
            'N_norm': N_norm,
        }

        if return_details:
            result.update({
                'mu_R': mu_R, 'mu_S': mu_S, 'mu_N': mu_N,
                'logvar_R': logvar_R, 'logvar_S': logvar_S, 'logvar_N': logvar_N,
                'gates_R': gates_R, 'gates_S': gates_S, 'gates_N': gates_N,
                'var_R': logvar_R.exp(), 'var_S': logvar_S.exp(), 'var_N': logvar_N.exp(),
            })

        return result

    def get_kl_divergence(
        self,
        mu_R: torch.Tensor, logvar_R: torch.Tensor,
        mu_S: torch.Tensor, logvar_S: torch.Tensor,
        mu_N: torch.Tensor, logvar_N: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute KL divergence from standard normal for VAE training.

        KL(q(z|x) || p(z)) = -0.5 * sum(1 + log_var - mu^2 - exp(log_var))
        """
        def kl_single(mu, logvar):
            return -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=-1)

        kl_R = kl_single(mu_R, logvar_R)
        kl_S = kl_single(mu_S, logvar_S)
        kl_N = kl_single(mu_N, logvar_N)

        return kl_R + kl_S + kl_N


# =============================================================================
# Convenience Functions
# =============================================================================

def create_yrsn_heads(
    embed_dim: int = 768,
    rsn_dim: int = 256,
    temperature_init: float = 1.0
) -> YRSNProjectionHeads:
    """Factory function for YRSN projection heads."""
    config = VGFAConfig(
        n_factors=rsn_dim,
        temperature_init=temperature_init
    )
    return YRSNProjectionHeads(embed_dim, rsn_dim, vgfa_config=config)


def demo_vgfa():
    """Demonstrate VGFA functionality."""
    print("=" * 60)
    print("VGFA: Variance-Gated Factor Attenuation Demo")
    print("=" * 60)

    # Create YRSN heads
    heads = create_yrsn_heads(embed_dim=768, rsn_dim=256)

    # Simulate in-distribution input
    x_id = torch.randn(32, 768)
    result_id = heads(x_id, return_details=True)

    print("\nIn-Distribution Input:")
    print(f"  Alpha (quality): {result_id['alpha'].mean():.3f}")
    print(f"  Omega (OOD score): {result_id['omega'].mean():.3f}")
    print(f"  Tau (temperature): {result_id['tau'].mean():.3f}")
    print(f"  Avg R gate: {result_id['gates_R'].mean():.3f}")
    print(f"  Avg S gate: {result_id['gates_S'].mean():.3f}")
    print(f"  Avg N gate: {result_id['gates_N'].mean():.3f}")

    # Simulate OOD input (different distribution)
    x_ood = torch.randn(32, 768) * 5 + 10
    result_ood = heads(x_ood, return_details=True)

    print("\nOut-of-Distribution Input:")
    print(f"  Alpha (quality): {result_ood['alpha'].mean():.3f}")
    print(f"  Omega (OOD score): {result_ood['omega'].mean():.3f}")
    print(f"  Tau (temperature): {result_ood['tau'].mean():.3f}")
    print(f"  Avg R gate: {result_ood['gates_R'].mean():.3f}")
    print(f"  Avg S gate: {result_ood['gates_S'].mean():.3f}")
    print(f"  Avg N gate: {result_ood['gates_N'].mean():.3f}")

    print("\n" + "=" * 60)
    print("Key Insight: OOD input has higher gates → lower omega")
    print("Variance gating makes OOD detection EMERGENT!")
    print("=" * 60)


if __name__ == "__main__":
    demo_vgfa()
