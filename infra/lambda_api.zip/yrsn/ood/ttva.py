"""
TTVA: Test-Time Variational Adaptation
=======================================

Mechanism for adapting the encoder during inference when OOD is detected.

The key insight from VDT: When distribution drift is detected, we can
update the encoder (not decoder) using reconstruction loss on the
new distribution.

Unlike standard fine-tuning:
- Only update encoder parameters
- Use reconstruction as self-supervised signal
- No labels needed
- Happens at inference time

YRSN Application:
    When ω drops below threshold, trigger TTVA to adapt R/S/N
    projections to the new distribution.

Reference: VDT (Yang et al., Nov 2025)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
from collections import deque
import copy


@dataclass
class TTVAConfig:
    """Configuration for Test-Time Variational Adaptation."""
    adaptation_lr: float = 1e-4
    adaptation_steps: int = 10
    omega_trigger_threshold: float = 0.4
    min_batch_size: int = 8
    ema_decay: float = 0.99
    freeze_decoder: bool = True
    use_reconstruction: bool = True
    use_contrastive: bool = False
    kl_weight: float = 0.1


class TestTimeVariationalAdapter(nn.Module):
    """
    Adapt encoder at test time using self-supervised signals.

    VDT Insight: Update encoder, freeze decoder, use reconstruction
    as the adaptation signal. No labels needed!

    YRSN Extension: Trigger adaptation when ω drops below threshold,
    indicating distribution shift in context.
    """

    def __init__(
        self,
        encoder: nn.Module,
        decoder: nn.Module,
        config: Optional[TTVAConfig] = None
    ):
        super().__init__()

        if config is None:
            config = TTVAConfig()
        self.config = config

        # Keep reference to original encoder
        self.encoder = encoder
        self.decoder = decoder

        # Create EMA version for stability
        self.encoder_ema = copy.deepcopy(encoder)
        for param in self.encoder_ema.parameters():
            param.requires_grad = False

        # Freeze decoder
        if config.freeze_decoder:
            for param in self.decoder.parameters():
                param.requires_grad = False

        # Optimizer for adaptation
        self.optimizer = None

        # Buffer for batch accumulation
        self.buffer = []

        # Track adaptation state
        self.adaptation_count = 0
        self.omega_history = deque(maxlen=100)

    def should_adapt(self, omega: torch.Tensor) -> bool:
        """
        Determine if adaptation should be triggered.

        Triggers when:
        1. Current ω is below threshold
        2. We have enough samples in buffer
        """
        self.omega_history.append(omega.mean().item())

        current_omega = omega.mean().item()
        if current_omega < self.config.omega_trigger_threshold:
            if len(self.buffer) >= self.config.min_batch_size:
                return True
        return False

    def accumulate(self, x: torch.Tensor):
        """Add samples to adaptation buffer."""
        self.buffer.extend(x.detach().cpu().unbind(0))

        # Limit buffer size
        if len(self.buffer) > 1000:
            self.buffer = self.buffer[-500:]

    def get_adaptation_batch(self) -> torch.Tensor:
        """Get batch from buffer for adaptation."""
        if len(self.buffer) < self.config.min_batch_size:
            return None

        # Random sample from buffer
        indices = torch.randperm(len(self.buffer))[:self.config.min_batch_size]
        batch = torch.stack([self.buffer[i] for i in indices])
        return batch.to(next(self.encoder.parameters()).device)

    def compute_adaptation_loss(
        self,
        x: torch.Tensor,
        mu: torch.Tensor,
        log_var: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute self-supervised adaptation loss.

        Components:
        1. Reconstruction loss (main signal)
        2. KL divergence (regularization)
        """
        losses = {}

        # Reconstruction loss
        if self.config.use_reconstruction:
            # Sample from latent
            std = torch.exp(0.5 * log_var)
            eps = torch.randn_like(std)
            z = mu + eps * std

            # Decode
            x_recon = self.decoder(z)

            # MSE reconstruction
            recon_loss = F.mse_loss(x_recon, x)
            losses['reconstruction'] = recon_loss

        # KL divergence
        kl_loss = -0.5 * torch.sum(
            1 + log_var - mu.pow(2) - log_var.exp(),
            dim=-1
        ).mean()
        losses['kl'] = self.config.kl_weight * kl_loss

        # Total
        total_loss = sum(losses.values())
        losses['total'] = total_loss

        return total_loss, losses

    def adapt(self, x: torch.Tensor) -> Dict[str, float]:
        """
        Perform adaptation steps on encoder.

        Args:
            x: Batch of inputs to adapt on

        Returns:
            Dictionary of loss values during adaptation
        """
        if self.optimizer is None:
            self.optimizer = torch.optim.Adam(
                self.encoder.parameters(),
                lr=self.config.adaptation_lr
            )

        self.encoder.train()
        loss_history = []

        for step in range(self.config.adaptation_steps):
            self.optimizer.zero_grad()

            # Forward through encoder
            mu, log_var = self.encoder(x)

            # Compute loss
            loss, losses = self.compute_adaptation_loss(x, mu, log_var)

            # Backward
            loss.backward()
            self.optimizer.step()

            # Update EMA
            with torch.no_grad():
                for ema_param, param in zip(
                    self.encoder_ema.parameters(),
                    self.encoder.parameters()
                ):
                    ema_param.data.mul_(self.config.ema_decay)
                    ema_param.data.add_(param.data, alpha=1 - self.config.ema_decay)

            loss_history.append(losses['total'].item())

        self.encoder.eval()
        self.adaptation_count += 1

        return {
            'final_loss': loss_history[-1],
            'loss_reduction': loss_history[0] - loss_history[-1],
            'adaptation_count': self.adaptation_count,
        }

    def forward(
        self,
        x: torch.Tensor,
        omega: Optional[torch.Tensor] = None,
        force_adapt: bool = False
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """
        Forward pass with optional adaptation.

        Args:
            x: Input embeddings
            omega: OOD scores (triggers adaptation if low)
            force_adapt: Force adaptation regardless of omega

        Returns:
            mu: Mean from encoder
            log_var: Log variance from encoder
            info: Dictionary with adaptation info
        """
        info = {'adapted': False}

        # Accumulate samples
        self.accumulate(x)

        # Check if adaptation needed
        if force_adapt or (omega is not None and self.should_adapt(omega)):
            batch = self.get_adaptation_batch()
            if batch is not None:
                adapt_info = self.adapt(batch)
                info.update(adapt_info)
                info['adapted'] = True

        # Forward through (possibly adapted) encoder
        mu, log_var = self.encoder(x)

        return mu, log_var, info


class OnlineEncoderUpdate(nn.Module):
    """
    Lightweight online encoder update for streaming contexts.

    Instead of batch adaptation, performs single-step updates
    on each incoming sample when OOD is detected.
    """

    def __init__(
        self,
        encoder: nn.Module,
        learning_rate: float = 1e-5,
        momentum: float = 0.9
    ):
        super().__init__()
        self.encoder = encoder
        self.lr = learning_rate
        self.momentum = momentum

        # Momentum buffer
        self.velocity = {}
        for name, param in encoder.named_parameters():
            self.velocity[name] = torch.zeros_like(param)

    def update_step(
        self,
        x: torch.Tensor,
        target_omega: float = 0.8
    ) -> Dict[str, float]:
        """
        Single gradient step to improve omega.

        Uses the insight that we want representations with
        lower variance (higher omega).
        """
        self.encoder.train()

        # Forward
        mu, log_var = self.encoder(x)

        # Loss: encourage lower variance (higher omega)
        # Omega = 1 - avg(sigmoid(log_var))
        gates = torch.sigmoid(log_var)
        current_omega = 1 - gates.mean()

        # Loss to push omega toward target
        omega_loss = F.mse_loss(current_omega, torch.tensor(target_omega))

        # Also regularize KL
        kl_loss = -0.5 * torch.sum(
            1 + log_var - mu.pow(2) - log_var.exp()
        ) / x.shape[0]

        total_loss = omega_loss + 0.01 * kl_loss

        # Compute gradients
        total_loss.backward()

        # SGD with momentum
        with torch.no_grad():
            for name, param in self.encoder.named_parameters():
                if param.grad is not None:
                    self.velocity[name] = (
                        self.momentum * self.velocity[name] +
                        param.grad
                    )
                    param.data -= self.lr * self.velocity[name]
                    param.grad.zero_()

        self.encoder.eval()

        return {
            'omega_before': current_omega.item(),
            'loss': total_loss.item(),
        }


class DriftAwareAdapter(nn.Module):
    """
    Adaptation triggered by distribution drift detection.

    Monitors omega over time and triggers adaptation when
    consistent drift is detected (not just single low omega).
    """

    def __init__(
        self,
        encoder: nn.Module,
        decoder: nn.Module,
        drift_window: int = 50,
        drift_threshold: float = 0.15
    ):
        super().__init__()

        self.ttva = TestTimeVariationalAdapter(encoder, decoder)
        self.drift_window = drift_window
        self.drift_threshold = drift_threshold

        # Track omega over time
        self.omega_history = deque(maxlen=drift_window)
        self.baseline_omega = None

    def update_baseline(self, omega: torch.Tensor):
        """Update baseline omega from initial distribution."""
        if self.baseline_omega is None:
            self.baseline_omega = omega.mean().item()
        else:
            # EMA update
            self.baseline_omega = (
                0.99 * self.baseline_omega +
                0.01 * omega.mean().item()
            )

    def detect_drift(self) -> Tuple[bool, float]:
        """
        Detect if distribution has drifted.

        Returns:
            drift_detected: Boolean
            drift_magnitude: How much omega has dropped
        """
        if len(self.omega_history) < self.drift_window // 2:
            return False, 0.0

        if self.baseline_omega is None:
            return False, 0.0

        recent_omega = sum(list(self.omega_history)[-20:]) / 20
        drift = self.baseline_omega - recent_omega

        return drift > self.drift_threshold, drift

    def forward(
        self,
        x: torch.Tensor,
        omega: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """
        Forward with drift-aware adaptation.
        """
        # Track omega
        self.omega_history.append(omega.mean().item())

        # Detect drift
        drift_detected, drift_magnitude = self.detect_drift()

        info = {
            'drift_detected': drift_detected,
            'drift_magnitude': drift_magnitude,
            'baseline_omega': self.baseline_omega,
            'current_omega': omega.mean().item(),
        }

        # Trigger adaptation if drift detected
        if drift_detected:
            mu, log_var, adapt_info = self.ttva(
                x, omega=omega, force_adapt=True
            )
            info.update(adapt_info)

            # Reset baseline after adaptation
            self.baseline_omega = None
        else:
            mu, log_var, _ = self.ttva(x, omega=omega)
            # Update baseline during stable period
            if omega.mean().item() > 0.7:
                self.update_baseline(omega)

        return mu, log_var, info


# =============================================================================
# Demo
# =============================================================================

def demo_ttva():
    """Demonstrate TTVA functionality."""
    print("=" * 60)
    print("TTVA: Test-Time Variational Adaptation Demo")
    print("=" * 60)

    # Create simple encoder/decoder
    embed_dim = 768
    latent_dim = 256

    encoder = nn.Sequential(
        nn.Linear(embed_dim, 512),
        nn.ReLU(),
        nn.Linear(512, latent_dim * 2),  # mu and log_var
    )

    # Wrap to split output
    class EncoderWrapper(nn.Module):
        def __init__(self, net, latent_dim):
            super().__init__()
            self.net = net
            self.latent_dim = latent_dim

        def forward(self, x):
            out = self.net(x)
            mu = out[:, :self.latent_dim]
            log_var = out[:, self.latent_dim:]
            return mu, log_var

    encoder = EncoderWrapper(encoder, latent_dim)
    decoder = nn.Linear(latent_dim, embed_dim)

    # Create TTVA
    ttva = TestTimeVariationalAdapter(encoder, decoder)

    # Simulate in-distribution data
    print("\nPhase 1: In-distribution data")
    for i in range(10):
        x = torch.randn(16, embed_dim)
        omega = torch.ones(16) * 0.85
        mu, log_var, info = ttva(x, omega=omega)
        print(f"  Batch {i+1}: omega={omega.mean():.2f}, adapted={info['adapted']}")

    # Simulate distribution shift
    print("\nPhase 2: Distribution shift (low omega)")
    for i in range(5):
        x = torch.randn(16, embed_dim) * 3 + 5  # Shifted
        omega = torch.ones(16) * 0.3  # Low omega
        mu, log_var, info = ttva(x, omega=omega)
        print(f"  Batch {i+1}: omega={omega.mean():.2f}, adapted={info['adapted']}")
        if info['adapted']:
            print(f"    -> Adaptation triggered! Loss reduction: {info.get('loss_reduction', 0):.4f}")

    print("\n" + "=" * 60)
    print("Key Insight: TTVA adapts encoder when ω drops!")
    print("No labels needed - uses reconstruction as signal.")
    print("=" * 60)


if __name__ == "__main__":
    demo_ttva()
