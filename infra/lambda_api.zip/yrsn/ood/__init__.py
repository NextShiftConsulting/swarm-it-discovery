"""
YRSN: Out-of-Distribution Aware Context Engineering
=====================================================

This module extends YRSN with OOD detection capabilities through
8 novel techniques from VDT cross-pollination analysis.

Components:
- VGFA: Variance-Gated Factor Attenuation
- CVJF: Confidence-Variance Joint Filtering
- TTVA: Test-Time Variational Adaptation
- SEDA: Shared Encoder Domain Alignment
- SCP: Semantic Collapse Prevention
- MVDA: Mean-Variance Decomposed Alignment
- MSDF: Multi-Source Domain Fusion
- RGFS: Reconstruction-Guided Factor Selection

The core insight: Variance naturally encodes OOD uncertainty.
Instead of bolting on separate OOD detectors, we make uncertainty
*emergent* from VAE-style representations.

Reference: VDT (Yang et al., Nov 2025) - Variational Domain-Invariant
Learning with Test-Time Training for Out-of-Context Detection
"""

from .vgfa import (
    VarianceGatedFactorAttenuation,
    HierarchicalVGFA,
    YRSNProjectionHeads,
)

from .cvjf import (
    ConfidenceVarianceJointFilter,
    HallucinationDetector,
    OODPoisoningDetector,
    AdaptiveCVJF,
)

from .ttva import (
    TestTimeVariationalAdapter,
    OnlineEncoderUpdate,
    DriftAwareAdapter,
)

from .seda import (
    SharedEncoderDomainAlignment,
    DomainInvariantEncoder,
    MultiDomainRSNEncoder,
)

from .scp import (
    SemanticCollapsePreventor,
    DualComponentConstraint,
    CollapseAwareLoss,
    CorrelationAlignmentLoss,
    correlation_alignment_loss,
)

from .shift_detection import (
    ShiftType,
    ShiftDetector,
    ShiftDetectionConfig,
    ShiftDetectionResult,
    ReferenceDistribution,
    OmegaTracker,
    AlphaOmegaVarianceMonitor,
    detect_shift_type,
)

from .mvda import (
    MeanVarianceDecomposedAlignment,
    TemperatureFromVariance,
    DualPathQuality,
)

from .msdf import (
    MultiSourceDomainFusion,
    SourceReliabilityTracker,
    AdaptiveSourceWeighting,
)

from .rgfs import (
    ReconstructionGuidedFactorSelection,
    AutoRankSelector,
    BBPReconstructionBridge,
)

# Unified YRSN pipeline
from .yrsn_pipeline import (
    YRSN,
    YRSNConfig,
    YRSNOutput,
    YRSNLite,
    create_yrsn_minimal,
    create_yrsn_production,
    create_yrsn_full,
)

__all__ = [
    # Unified Pipeline
    'YRSN',
    'YRSNConfig',
    'YRSNOutput',
    'YRSNLite',
    'create_yrsn_minimal',
    'create_yrsn_production',
    'create_yrsn_full',
    # VGFA
    'VarianceGatedFactorAttenuation',
    'HierarchicalVGFA',
    'YRSNProjectionHeads',
    # CVJF
    'ConfidenceVarianceJointFilter',
    'HallucinationDetector',
    'OODPoisoningDetector',
    'AdaptiveCVJF',
    # TTVA
    'TestTimeVariationalAdapter',
    'OnlineEncoderUpdate',
    'DriftAwareAdapter',
    # SEDA
    'SharedEncoderDomainAlignment',
    'DomainInvariantEncoder',
    'MultiDomainRSNEncoder',
    # SCP
    'SemanticCollapsePreventor',
    'DualComponentConstraint',
    'CollapseAwareLoss',
    'CorrelationAlignmentLoss',
    'correlation_alignment_loss',
    # Shift Detection
    'ShiftType',
    'ShiftDetector',
    'ShiftDetectionConfig',
    'ShiftDetectionResult',
    'ReferenceDistribution',
    'OmegaTracker',
    'AlphaOmegaVarianceMonitor',
    'detect_shift_type',
    # MVDA
    'MeanVarianceDecomposedAlignment',
    'TemperatureFromVariance',
    'DualPathQuality',
    # MSDF
    'MultiSourceDomainFusion',
    'SourceReliabilityTracker',
    'AdaptiveSourceWeighting',
    # RGFS
    'ReconstructionGuidedFactorSelection',
    'AutoRankSelector',
    'BBPReconstructionBridge',
]
