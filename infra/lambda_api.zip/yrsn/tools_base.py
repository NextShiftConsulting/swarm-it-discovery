"""
YRSN Tool System - FastAPI-style declarative tool definitions.

This module provides a decorator-based API for defining YRSN tools that can be
automatically exported to various formats (OpenAPI, MCP, CrewAI, LangChain).

Example:
    from yrsn.tools import YRSNTool, tool_registry

    @YRSNTool(
        name="analyze_quality",
        description="Analyze context quality using YRSN decomposition",
        tags=["quality", "analysis"]
    )
    def analyze_quality(blocks: List[ContextBlock]) -> CollapseAnalysis:
        '''Detailed docstring becomes extended description.'''
        r = sum(b.R for b in blocks) / len(blocks)
        s = sum(b.S for b in blocks) / len(blocks)
        n = sum(b.N for b in blocks) / len(blocks)
        return detect_collapse(r, s, n)

    # Auto-generate for different frameworks
    crewai_tools = tool_registry.to_crewai()
    openapi_schema = tool_registry.to_openapi()
    mcp_manifest = tool_registry.to_mcp()
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Type,
    TypeVar,
    Union,
    get_type_hints,
)

# Type variables
T = TypeVar("T")
R = TypeVar("R")


class ToolCategory(Enum):
    """Categories for organizing YRSN tools."""

    QUALITY = "quality"  # Quality analysis and collapse detection
    RETRIEVAL = "retrieval"  # Context retrieval and ranking
    MEMORY = "memory"  # Memory operations
    REASONING = "reasoning"  # Constraint reasoning
    ROUTING = "routing"  # Decision routing
    TEMPERATURE = "temperature"  # Temperature control
    OOD = "ood"  # Out-of-distribution detection
    HARDWARE = "hardware"  # Hardware integration
    QUANTUM = "quantum"  # Quantum operations


@dataclass
class ToolParameter:
    """Schema for a tool parameter."""

    name: str
    type: str
    description: str
    required: bool = True
    default: Any = None
    enum: Optional[List[str]] = None

    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        schema: Dict[str, Any] = {
            "type": self._python_type_to_json(self.type),
            "description": self.description,
        }
        if self.default is not None:
            schema["default"] = self.default
        if self.enum:
            schema["enum"] = self.enum
        return schema

    @staticmethod
    def _python_type_to_json(python_type: str) -> str:
        """Map Python type hints to JSON Schema types."""
        type_map = {
            "str": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
            "list": "array",
            "dict": "object",
            "List": "array",
            "Dict": "object",
            "None": "null",
            "Any": "object",
        }
        # Handle generic types like List[str]
        base_type = python_type.split("[")[0]
        return type_map.get(base_type, "object")


@dataclass
class ToolSchema:
    """Complete schema for a YRSN tool."""

    name: str
    description: str
    function: Callable
    parameters: List[ToolParameter] = field(default_factory=list)
    return_type: str = "object"
    return_description: str = ""
    tags: List[str] = field(default_factory=list)
    category: ToolCategory = ToolCategory.QUALITY
    is_async: bool = False
    requires_auth: bool = False
    rate_limit: Optional[int] = None  # Requests per minute
    examples: List[Dict[str, Any]] = field(default_factory=list)

    def to_openapi(self) -> Dict[str, Any]:
        """Generate OpenAPI operation schema."""
        properties = {}
        required = []

        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)

        return {
            "operationId": self.name,
            "summary": self.description,
            "description": self.function.__doc__ or self.description,
            "tags": self.tags,
            "requestBody": {
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "properties": properties,
                            "required": required,
                        }
                    }
                },
            },
            "responses": {
                "200": {
                    "description": self.return_description or "Successful response",
                    "content": {
                        "application/json": {
                            "schema": {"type": self._get_return_json_type()}
                        }
                    },
                }
            },
        }

    def to_mcp(self) -> Dict[str, Any]:
        """Generate MCP (Model Context Protocol) tool schema."""
        properties = {}
        required = []

        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)

        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        }

    def to_crewai(self) -> Dict[str, Any]:
        """Generate CrewAI Tool-compatible schema."""
        return {
            "name": self.name,
            "description": self.description,
            "func": self.function,
            "args_schema": self._generate_pydantic_schema(),
        }

    def to_langchain(self) -> Dict[str, Any]:
        """Generate LangChain Tool-compatible schema."""
        return {
            "name": self.name,
            "description": self.description,
            "func": self.function,
            "args_schema": self._generate_pydantic_schema(),
            "return_direct": False,
        }

    def _get_return_json_type(self) -> str:
        """Get JSON Schema type for return value."""
        type_map = {
            "str": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
            "list": "array",
            "dict": "object",
            "None": "null",
        }
        base_type = self.return_type.split("[")[0]
        return type_map.get(base_type, "object")

    def _generate_pydantic_schema(self) -> Optional[Type]:
        """Generate a Pydantic model for args validation."""
        try:
            from pydantic import BaseModel, Field, create_model

            fields = {}
            for param in self.parameters:
                python_type = self._json_to_python_type(param.type)
                if param.required:
                    fields[param.name] = (
                        python_type,
                        Field(description=param.description),
                    )
                else:
                    fields[param.name] = (
                        Optional[python_type],
                        Field(default=param.default, description=param.description),
                    )

            return create_model(f"{self.name}Args", **fields)
        except ImportError:
            return None

    @staticmethod
    def _json_to_python_type(json_type: str) -> Type:
        """Map JSON Schema types back to Python types."""
        type_map = {
            "string": str,
            "integer": int,
            "number": float,
            "boolean": bool,
            "array": list,
            "object": dict,
            "null": type(None),
        }
        return type_map.get(json_type, Any)


class ToolRegistry:
    """
    Global registry for YRSN tools.

    Provides methods to export tools to various formats and frameworks.
    """

    _instance: Optional["ToolRegistry"] = None
    _tools: Dict[str, ToolSchema] = {}

    def __new__(cls) -> "ToolRegistry":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._tools = {}
        return cls._instance

    def register(self, schema: ToolSchema) -> None:
        """Register a tool schema."""
        self._tools[schema.name] = schema

    def get(self, name: str) -> Optional[ToolSchema]:
        """Get a tool by name."""
        return self._tools.get(name)

    def list_tools(
        self, category: Optional[ToolCategory] = None, tags: Optional[List[str]] = None
    ) -> List[ToolSchema]:
        """List tools, optionally filtered by category or tags."""
        tools = list(self._tools.values())

        if category:
            tools = [t for t in tools if t.category == category]

        if tags:
            tools = [t for t in tools if any(tag in t.tags for tag in tags)]

        return tools

    def to_openapi(self) -> Dict[str, Any]:
        """Generate complete OpenAPI schema for all tools."""
        paths = {}
        for name, schema in self._tools.items():
            paths[f"/tools/{name}"] = {"post": schema.to_openapi()}

        return {
            "openapi": "3.1.0",
            "info": {
                "title": "YRSN Tools API",
                "version": "0.5.0",
                "description": "YRSN Context Engineering Framework Tools",
            },
            "paths": paths,
            "tags": [{"name": cat.value, "description": f"{cat.value} tools"} for cat in ToolCategory],
        }

    def to_mcp(self) -> Dict[str, Any]:
        """Generate MCP manifest for all tools."""
        return {
            "name": "yrsn-tools",
            "version": "0.5.0",
            "description": "YRSN Context Engineering Framework Tools",
            "tools": [schema.to_mcp() for schema in self._tools.values()],
        }

    def to_crewai(self) -> List[Any]:
        """Generate CrewAI Tool instances for all tools."""
        try:
            from crewai import Tool

            return [
                Tool(
                    name=schema.name,
                    description=schema.description,
                    func=schema.function,
                )
                for schema in self._tools.values()
            ]
        except ImportError:
            # Return dict format if CrewAI not installed
            return [schema.to_crewai() for schema in self._tools.values()]

    def to_langchain(self) -> List[Any]:
        """Generate LangChain Tool instances for all tools."""
        try:
            from langchain.tools import StructuredTool

            tools = []
            for schema in self._tools.values():
                tool = StructuredTool.from_function(
                    func=schema.function,
                    name=schema.name,
                    description=schema.description,
                )
                tools.append(tool)
            return tools
        except ImportError:
            return [schema.to_langchain() for schema in self._tools.values()]

    def clear(self) -> None:
        """Clear all registered tools (useful for testing)."""
        self._tools.clear()


# Global registry instance
tool_registry = ToolRegistry()


def YRSNTool(
    name: Optional[str] = None,
    description: Optional[str] = None,
    category: ToolCategory = ToolCategory.QUALITY,
    tags: Optional[List[str]] = None,
    requires_auth: bool = False,
    rate_limit: Optional[int] = None,
    examples: Optional[List[Dict[str, Any]]] = None,
) -> Callable[[Callable[..., R]], Callable[..., R]]:
    """
    Decorator to register a function as a YRSN tool.

    Args:
        name: Tool name (defaults to function name)
        description: Short description (defaults to first line of docstring)
        category: Tool category for organization
        tags: List of tags for filtering
        requires_auth: Whether tool requires authentication
        rate_limit: Max requests per minute (None = unlimited)
        examples: Example inputs/outputs for documentation

    Returns:
        Decorated function with schema attached

    Example:
        @YRSNTool(
            name="detect_collapse",
            description="Detect quality collapse in context",
            category=ToolCategory.QUALITY,
            tags=["quality", "safety"]
        )
        def detect_collapse(r: float, s: float, n: float) -> CollapseAnalysis:
            '''
            Analyze R/S/N ratios to detect collapse patterns.

            Collapse types:
            - POISONING: High noise corrupts signal
            - DISTRACTION: Superfluous overwhelms relevant
            - CONFLICT: Both S and N are high
            - CLASH: Variable reliability across sources
            '''
            ...
    """

    def decorator(func: Callable[..., R]) -> Callable[..., R]:
        # Extract function metadata
        func_name = name or func.__name__
        func_doc = func.__doc__ or ""
        func_description = description or func_doc.split("\n")[0].strip() or func_name

        # Parse type hints for parameters
        hints = get_type_hints(func) if hasattr(func, "__annotations__") else {}
        sig = inspect.signature(func)

        parameters = []
        for param_name, param in sig.parameters.items():
            if param_name in ("self", "cls"):
                continue

            param_type = hints.get(param_name, Any)
            type_str = getattr(param_type, "__name__", str(param_type))

            # Extract parameter description from docstring if available
            param_desc = f"Parameter: {param_name}"
            if func_doc:
                # Simple extraction - could be enhanced
                for line in func_doc.split("\n"):
                    if param_name in line and ":" in line:
                        param_desc = line.split(":", 1)[-1].strip()
                        break

            parameters.append(
                ToolParameter(
                    name=param_name,
                    type=type_str,
                    description=param_desc,
                    required=param.default == inspect.Parameter.empty,
                    default=None if param.default == inspect.Parameter.empty else param.default,
                )
            )

        # Get return type
        return_type = hints.get("return", Any)
        return_type_str = getattr(return_type, "__name__", str(return_type))

        # Check if async
        is_async = asyncio.iscoroutinefunction(func)

        # Create schema
        schema = ToolSchema(
            name=func_name,
            description=func_description,
            function=func,
            parameters=parameters,
            return_type=return_type_str,
            return_description=f"Returns {return_type_str}",
            tags=tags or [],
            category=category,
            is_async=is_async,
            requires_auth=requires_auth,
            rate_limit=rate_limit,
            examples=examples or [],
        )

        # Register in global registry
        tool_registry.register(schema)

        # Attach schema to function
        func._yrsn_schema = schema  # type: ignore

        # Create sync wrapper for async functions
        if is_async:

            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> R:
                return asyncio.get_event_loop().run_until_complete(func(*args, **kwargs))

            func.sync = sync_wrapper  # type: ignore

        return func

    return decorator


# =============================================================================
# Pre-registered YRSN Tools (Core capabilities)
# =============================================================================


def _register_core_tools() -> None:
    """Register core YRSN tools on module import."""
    from yrsn_context import (
        CollapseAnalysis,
        CollapseType,
        ContextBlock,
        detect_collapse,
    )
    from yrsn.core.temperature import map_quality_to_temperature

    @YRSNTool(
        name="yrsn_detect_collapse",
        description="Detect quality collapse patterns in context (POISON/DISTRACT/CONFUSE/CLASH)",
        category=ToolCategory.QUALITY,
        tags=["quality", "safety", "collapse"],
    )
    def yrsn_detect_collapse(r: float, s: float, n: float) -> Dict[str, Any]:
        """
        Analyze R/S/N ratios to identify collapse patterns.

        Args:
            r: Relevant component score (0-1)
            s: Superfluous component score (0-1)
            n: Noise component score (0-1)

        Returns:
            Collapse analysis with type, severity, and recommendations
        """
        result = detect_collapse(r, s, n)
        return {
            "collapse_type": result.collapse_type.name,
            "severity": result.severity.name,
            "recommendation": result.recommendation,
            "risk_score": s + 1.5 * n,
            "quality_score": r + 0.5 * s,
        }

    @YRSNTool(
        name="yrsn_compute_temperature",
        description="Map context quality to LLM inference temperature",
        category=ToolCategory.TEMPERATURE,
        tags=["temperature", "llm", "inference"],
    )
    def yrsn_compute_temperature(alpha: float, mode: str = "power") -> Dict[str, float]:
        """
        Compute inference temperature from quality score.

        The temperature τ = 1/α controls LLM sampling:
        - High quality (α→1): Low temperature → deterministic
        - Low quality (α→0): High temperature → exploratory

        Args:
            alpha: Quality score (0-1)
            mode: Temperature mode ("power", "linear", "sigmoid")

        Returns:
            Temperature value and quality phase
        """
        tau = map_quality_to_temperature(alpha, mode=mode)
        phase = "HIGH" if alpha > 0.7 else ("MEDIUM" if alpha > 0.4 else "LOW")
        return {
            "temperature": tau,
            "quality_phase": phase,
            "alpha": alpha,
            "mode": mode,
        }

    @YRSNTool(
        name="yrsn_analyze_context",
        description="Analyze a list of context blocks for overall quality",
        category=ToolCategory.QUALITY,
        tags=["quality", "analysis", "context"],
    )
    def yrsn_analyze_context(blocks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Compute aggregate quality metrics for context blocks.

        Args:
            blocks: List of context blocks with R, S, N scores

        Returns:
            Aggregate metrics including avg quality, collapse risk, recommended temperature
        """
        if not blocks:
            return {"error": "No context blocks provided"}

        avg_r = sum(b.get("R", 0.5) for b in blocks) / len(blocks)
        avg_s = sum(b.get("S", 0.3) for b in blocks) / len(blocks)
        avg_n = sum(b.get("N", 0.2) for b in blocks) / len(blocks)

        alpha = avg_r / (avg_r + avg_s + avg_n) if (avg_r + avg_s + avg_n) > 0 else 0.5
        risk = avg_s + 1.5 * avg_n

        collapse_result = detect_collapse(avg_r, avg_s, avg_n)

        # τ from α_ω; without OOD context, assume omega=1.0 (in-distribution)
        omega = 1.0
        quality_prior = 0.5
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        recommended_tau = 1.0 / max(alpha_omega, 0.1)

        return {
            "num_blocks": len(blocks),
            "avg_R": round(avg_r, 3),
            "avg_S": round(avg_s, 3),
            "avg_N": round(avg_n, 3),
            "quality_alpha": round(alpha, 3),
            "collapse_risk": round(risk, 3),
            "collapse_type": collapse_result.collapse_type.name,
            "severity": collapse_result.severity.name,
            "recommended_temperature": round(recommended_tau, 2),
            "recommendation": collapse_result.recommendation,
        }


# Register core tools when module is imported
try:
    _register_core_tools()
except ImportError:
    # Core modules not available yet (during package build)
    pass


__all__ = [
    "YRSNTool",
    "ToolSchema",
    "ToolParameter",
    "ToolCategory",
    "ToolRegistry",
    "tool_registry",
]
