"""
YRSN Dependency Injection Container.

Provides a centralized container for managing YRSN component dependencies,
similar to FastAPI's dependency injection but tailored for YRSN workflows.

Example:
    from yrsn.container import YRSNContainer, get_container

    # Configure container
    container = YRSNContainer()
    container.configure(
        llm_provider="openai",
        retriever_provider="chroma",
        memory_enabled=True,
    )

    # Get configured components
    llm = container.llm_client()
    retriever = container.retriever()
    memory = container.memory()

    # Or use context manager
    with YRSNContainer.configured(config_path="yrsn.yaml") as container:
        llm = container.llm_client()
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, Generic, Optional, Type, TypeVar, Union

T = TypeVar("T")


class Provider(Enum):
    """Supported providers for YRSN components."""

    # LLM Providers
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    BEDROCK = "bedrock"
    OLLAMA = "ollama"
    HUGGINGFACE = "huggingface"
    LOCAL = "local"

    # Retriever Providers
    CHROMA = "chroma"
    QDRANT = "qdrant"
    SIMPLE = "simple"
    DUMMY = "dummy"

    # Memory Providers
    SQLITE = "sqlite"
    REDIS = "redis"
    MEMORY = "memory"


@dataclass
class YRSNConfig:
    """
    Configuration for YRSN container.

    Can be loaded from:
    - Environment variables (YRSN_*)
    - YAML file (yrsn.yaml)
    - Direct configuration
    """

    # LLM Configuration
    llm_provider: str = "openai"
    llm_model: str = "gpt-4"
    llm_api_key: Optional[str] = None
    llm_base_url: Optional[str] = None
    llm_temperature_mode: str = "adaptive"  # "fixed", "adaptive", "annealing"

    # Retriever Configuration
    retriever_provider: str = "chroma"
    retriever_collection: str = "yrsn_default"
    retriever_embedding_model: str = "text-embedding-3-small"
    retriever_top_k: int = 5

    # Memory Configuration
    memory_enabled: bool = True
    memory_dim: int = 256
    memory_sdm_weight: float = 0.3
    memory_hopfield_weight: float = 0.4
    memory_ewc_weight: float = 0.2
    memory_replay_weight: float = 0.1

    # Quality Configuration
    quality_collapse_threshold: float = 0.6
    quality_auto_escalate: bool = True

    # OOD Configuration
    ood_detection_enabled: bool = True
    ood_threshold: float = 0.7

    # Observability
    telemetry_enabled: bool = False
    telemetry_exporter: str = "otlp"
    telemetry_endpoint: Optional[str] = None

    # Logging
    log_level: str = "INFO"
    log_format: str = "structured"  # "structured", "plain"

    @classmethod
    def from_env(cls, prefix: str = "YRSN") -> "YRSNConfig":
        """Load configuration from environment variables."""
        config = cls()

        env_mappings = {
            f"{prefix}_LLM_PROVIDER": "llm_provider",
            f"{prefix}_LLM_MODEL": "llm_model",
            f"{prefix}_LLM_API_KEY": "llm_api_key",
            f"{prefix}_LLM_BASE_URL": "llm_base_url",
            f"{prefix}_LLM_TEMPERATURE_MODE": "llm_temperature_mode",
            f"{prefix}_RETRIEVER_PROVIDER": "retriever_provider",
            f"{prefix}_RETRIEVER_COLLECTION": "retriever_collection",
            f"{prefix}_RETRIEVER_EMBEDDING_MODEL": "retriever_embedding_model",
            f"{prefix}_RETRIEVER_TOP_K": "retriever_top_k",
            f"{prefix}_MEMORY_ENABLED": "memory_enabled",
            f"{prefix}_MEMORY_DIM": "memory_dim",
            f"{prefix}_QUALITY_COLLAPSE_THRESHOLD": "quality_collapse_threshold",
            f"{prefix}_OOD_DETECTION_ENABLED": "ood_detection_enabled",
            f"{prefix}_TELEMETRY_ENABLED": "telemetry_enabled",
            f"{prefix}_LOG_LEVEL": "log_level",
        }

        for env_var, attr in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                # Type conversion
                current = getattr(config, attr)
                if isinstance(current, bool):
                    value = value.lower() in ("true", "1", "yes")
                elif isinstance(current, int):
                    value = int(value)
                elif isinstance(current, float):
                    value = float(value)
                setattr(config, attr, value)

        return config

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> "YRSNConfig":
        """Load configuration from YAML file."""
        try:
            import yaml
        except ImportError:
            raise ImportError("PyYAML required for YAML config: pip install pyyaml")

        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path) as f:
            data = yaml.safe_load(f)

        config = cls()

        # Flatten nested config
        def flatten(d: Dict, parent_key: str = "") -> Dict[str, Any]:
            items: list = []
            for k, v in d.items():
                new_key = f"{parent_key}_{k}" if parent_key else k
                if isinstance(v, dict):
                    items.extend(flatten(v, new_key).items())
                else:
                    items.append((new_key, v))
            return dict(items)

        flat = flatten(data)

        for key, value in flat.items():
            attr = key.lower()
            if hasattr(config, attr):
                setattr(config, attr, value)

        return config

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "llm": {
                "provider": self.llm_provider,
                "model": self.llm_model,
                "temperature_mode": self.llm_temperature_mode,
            },
            "retriever": {
                "provider": self.retriever_provider,
                "collection": self.retriever_collection,
                "embedding_model": self.retriever_embedding_model,
                "top_k": self.retriever_top_k,
            },
            "memory": {
                "enabled": self.memory_enabled,
                "dim": self.memory_dim,
                "sdm_weight": self.memory_sdm_weight,
                "hopfield_weight": self.memory_hopfield_weight,
                "ewc_weight": self.memory_ewc_weight,
                "replay_weight": self.memory_replay_weight,
            },
            "quality": {
                "collapse_threshold": self.quality_collapse_threshold,
                "auto_escalate": self.quality_auto_escalate,
            },
            "ood": {
                "detection_enabled": self.ood_detection_enabled,
                "threshold": self.ood_threshold,
            },
            "telemetry": {
                "enabled": self.telemetry_enabled,
                "exporter": self.telemetry_exporter,
                "endpoint": self.telemetry_endpoint,
            },
            "logging": {
                "level": self.log_level,
                "format": self.log_format,
            },
        }


class Dependency(Generic[T]):
    """
    Lazy dependency wrapper with caching.

    Similar to FastAPI's Depends() but for YRSN components.
    """

    def __init__(
        self,
        factory: Callable[..., T],
        singleton: bool = True,
        **kwargs: Any,
    ):
        self._factory = factory
        self._singleton = singleton
        self._kwargs = kwargs
        self._instance: Optional[T] = None

    def __call__(self, **override_kwargs: Any) -> T:
        """Get or create the dependency instance."""
        if self._singleton and self._instance is not None:
            return self._instance

        merged_kwargs = {**self._kwargs, **override_kwargs}
        instance = self._factory(**merged_kwargs)

        if self._singleton:
            self._instance = instance

        return instance

    def reset(self) -> None:
        """Reset cached instance (useful for testing)."""
        self._instance = None


class YRSNContainer:
    """
    Dependency injection container for YRSN components.

    Manages lifecycle and configuration of:
    - LLM clients (OpenAI, Anthropic, Bedrock, etc.)
    - Retrievers (ChromaDB, Qdrant, simple)
    - Memory systems (4-layer learner)
    - Quality monitors
    - Temperature schedulers

    Example:
        container = YRSNContainer()
        container.configure(llm_provider="anthropic", llm_model="claude-3-opus")

        llm = container.llm_client()
        retriever = container.retriever()
    """

    _instance: Optional["YRSNContainer"] = None

    def __init__(self, config: Optional[YRSNConfig] = None):
        self._config = config or YRSNConfig()
        self._dependencies: Dict[str, Dependency] = {}
        self._overrides: Dict[str, Any] = {}
        self._setup_dependencies()

    @classmethod
    def get_instance(cls) -> "YRSNContainer":
        """Get or create singleton container instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    @contextmanager
    def configured(
        cls,
        config: Optional[YRSNConfig] = None,
        config_path: Optional[Union[str, Path]] = None,
        **kwargs: Any,
    ):
        """
        Context manager for configured container.

        Args:
            config: Pre-built config object
            config_path: Path to YAML config file
            **kwargs: Override specific config values
        """
        if config_path:
            config = YRSNConfig.from_yaml(config_path)
        elif config is None:
            config = YRSNConfig.from_env()

        # Apply overrides
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        container = cls(config)
        old_instance = cls._instance
        cls._instance = container

        try:
            yield container
        finally:
            cls._instance = old_instance
            container.shutdown()

    def configure(self, **kwargs: Any) -> "YRSNContainer":
        """Update configuration values."""
        for key, value in kwargs.items():
            if hasattr(self._config, key):
                setattr(self._config, key, value)
        self._setup_dependencies()
        return self

    def override(self, name: str, instance: Any) -> "YRSNContainer":
        """Override a dependency with a specific instance (for testing)."""
        self._overrides[name] = instance
        return self

    def _setup_dependencies(self) -> None:
        """Initialize dependency factories based on config."""
        # LLM Client
        self._dependencies["llm_client"] = Dependency(
            self._create_llm_client,
            singleton=True,
        )

        # Retriever
        self._dependencies["retriever"] = Dependency(
            self._create_retriever,
            singleton=True,
        )

        # Memory
        self._dependencies["memory"] = Dependency(
            self._create_memory,
            singleton=True,
        )

        # Temperature Scheduler
        self._dependencies["temperature_scheduler"] = Dependency(
            self._create_temperature_scheduler,
            singleton=True,
        )

        # Quality Monitor
        self._dependencies["quality_monitor"] = Dependency(
            self._create_quality_monitor,
            singleton=True,
        )

        # Pipeline
        self._dependencies["pipeline"] = Dependency(
            self._create_pipeline,
            singleton=False,  # New pipeline per request
        )

    def _create_llm_client(self) -> Any:
        """Create LLM client based on provider config."""
        provider = self._config.llm_provider.lower()

        # Handle dummy/mock provider for testing
        if provider in ("dummy", "mock"):
            return _MockLLMClient(self._config.llm_model)

        try:
            from yrsn.infrastructure.llm_adapters import (
                AnthropicClient,
                BedrockClient,
                HuggingFaceClient,
                OllamaClient,
                OpenAIClient,
            )

            clients = {
                "openai": OpenAIClient,
                "anthropic": AnthropicClient,
                "bedrock": BedrockClient,
                "ollama": OllamaClient,
                "huggingface": HuggingFaceClient,
            }

            client_class = clients.get(provider)
            if client_class is None:
                raise ValueError(f"Unknown LLM provider: {provider}")

            kwargs: Dict[str, Any] = {"model": self._config.llm_model}
            if self._config.llm_api_key:
                kwargs["api_key"] = self._config.llm_api_key
            if self._config.llm_base_url:
                kwargs["base_url"] = self._config.llm_base_url

            return client_class(**kwargs)

        except ImportError:
            # Return mock client if infrastructure not available
            return _MockLLMClient(self._config.llm_model)

    def _create_retriever(self) -> Any:
        """Create retriever based on provider config."""
        provider = self._config.retriever_provider.lower()

        # Handle dummy/mock provider for testing
        if provider in ("dummy", "mock"):
            return _MockRetriever()

        try:
            from yrsn.infrastructure.retriever_adapters import (
                ChromaRetriever,
                DummyRetriever,
                SimpleEmbeddingRetriever,
            )

            retrievers = {
                "chroma": ChromaRetriever,
                "simple": SimpleEmbeddingRetriever,
                "dummy": DummyRetriever,
            }

            retriever_class = retrievers.get(provider)
            if retriever_class is None:
                raise ValueError(f"Unknown retriever provider: {provider}")

            kwargs: Dict[str, Any] = {}
            if provider == "chroma":
                kwargs["collection_name"] = self._config.retriever_collection

            return retriever_class(**kwargs)

        except ImportError:
            return _MockRetriever()

    def _create_memory(self) -> Any:
        """Create memory system based on config."""
        if not self._config.memory_enabled:
            return None

        try:
            from yrsn.core.memory import BaseLearnerConfig

            config = BaseLearnerConfig(
                context_dim=self._config.memory_dim,
                sdm_weight=self._config.memory_sdm_weight,
                hopfield_weight=self._config.memory_hopfield_weight,
                ewc_weight=self._config.memory_ewc_weight,
                replay_weight=self._config.memory_replay_weight,
            )

            # Return mock memory since BaseLearner is abstract
            # In production, use a concrete implementation
            return _MockMemory(config)

        except ImportError:
            return _MockMemory()

    def _create_temperature_scheduler(self) -> Any:
        """Create temperature scheduler."""
        try:
            from yrsn.core.temperature import TemperatureScheduler

            return TemperatureScheduler(mode=self._config.llm_temperature_mode)
        except ImportError:
            return _MockTemperatureScheduler(self._config.llm_temperature_mode)

    def _create_quality_monitor(self) -> Any:
        """Create quality monitor."""
        try:
            from yrsn.monitoring import CalibrationManager, CalibrationConfig

            config = CalibrationConfig(
                collapse_threshold=self._config.quality_collapse_threshold,
            )
            return CalibrationManager(config)
        except ImportError:
            return None

    def _create_pipeline(self) -> Any:
        """Create YRSN pipeline with all dependencies."""
        try:
            from yrsn.core.pipeline_runner import StandardYRSNPipeline

            return StandardYRSNPipeline(
                llm_client=self.llm_client(),
                retriever=self.retriever(),
                memory=self.memory(),
            )
        except ImportError:
            return None

    # Public accessors
    def llm_client(self) -> Any:
        """Get configured LLM client."""
        if "llm_client" in self._overrides:
            return self._overrides["llm_client"]
        return self._dependencies["llm_client"]()

    def retriever(self) -> Any:
        """Get configured retriever."""
        if "retriever" in self._overrides:
            return self._overrides["retriever"]
        return self._dependencies["retriever"]()

    def memory(self) -> Any:
        """Get configured memory system."""
        if "memory" in self._overrides:
            return self._overrides["memory"]
        return self._dependencies["memory"]()

    def temperature_scheduler(self) -> Any:
        """Get temperature scheduler."""
        if "temperature_scheduler" in self._overrides:
            return self._overrides["temperature_scheduler"]
        return self._dependencies["temperature_scheduler"]()

    def quality_monitor(self) -> Any:
        """Get quality monitor."""
        if "quality_monitor" in self._overrides:
            return self._overrides["quality_monitor"]
        return self._dependencies["quality_monitor"]()

    def pipeline(self) -> Any:
        """Get new pipeline instance."""
        if "pipeline" in self._overrides:
            return self._overrides["pipeline"]
        return self._dependencies["pipeline"]()

    @property
    def config(self) -> YRSNConfig:
        """Get current configuration."""
        return self._config

    def reset(self) -> None:
        """Reset all cached dependencies."""
        for dep in self._dependencies.values():
            dep.reset()
        self._overrides.clear()

    def shutdown(self) -> None:
        """Cleanup resources."""
        self.reset()

    @classmethod
    def for_testing(cls, **overrides: Any) -> "YRSNContainer":
        """Create container configured for testing."""
        config = YRSNConfig(
            llm_provider="dummy",
            retriever_provider="dummy",
            memory_enabled=False,
            telemetry_enabled=False,
        )
        container = cls(config)
        for name, instance in overrides.items():
            container.override(name, instance)
        return container

    @classmethod
    def for_crewai(cls, **kwargs: Any) -> "YRSNContainer":
        """Create container optimized for CrewAI integration."""
        config = YRSNConfig.from_env("YRSN")

        # CrewAI-specific defaults
        if "llm_temperature_mode" not in kwargs:
            kwargs["llm_temperature_mode"] = "adaptive"

        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        return cls(config)


# =============================================================================
# Mock implementations for when infrastructure is not available
# =============================================================================


class _MockLLMClient:
    """Mock LLM client for testing/development."""

    def __init__(self, model: str = "mock"):
        self.model = model

    def complete(self, prompt: str, **kwargs: Any) -> str:
        return f"[Mock response from {self.model}]"

    def embed(self, text: str) -> list:
        return [0.0] * 256


class _MockRetriever:
    """Mock retriever for testing."""

    def retrieve(self, query: str, k: int = 5) -> list:
        from yrsn.core.types import ContextBlock

        return [
            ContextBlock(
                content=f"Mock result {i} for: {query}",
                source="mock",
                R=0.7,
                S=0.2,
                N=0.1,
            )
            for i in range(k)
        ]


class _MockTemperatureScheduler:
    """Mock temperature scheduler."""

    def __init__(self, mode: str = "adaptive"):
        self.mode = mode

    def compute(self, alpha: float, omega: float = 1.0) -> float:
        """Compute τ from α_ω (reliability-adjusted), NOT raw α."""
        if self.mode == "adaptive":
            quality_prior = 0.5
            alpha_omega = omega * alpha + (1 - omega) * quality_prior
            return 1.0 / max(alpha_omega, 0.1)
        return 1.0


class _MockMemory:
    """Mock memory system for testing."""

    def __init__(self, config: Any = None):
        self.config = config
        self._storage: Dict[str, Any] = {}

    def store(self, key: str, value: Any, relevance: float = 1.0) -> None:
        self._storage[key] = {"value": value, "relevance": relevance}

    def retrieve(self, key: str) -> Any:
        return self._storage.get(key, {}).get("value")

    def compute_quality(self, context: Any) -> float:
        return 0.8  # Mock quality

    def compute_reward(self, response: Any, feedback: Any) -> float:
        return 0.5  # Mock reward


# Convenience function
def get_container() -> YRSNContainer:
    """Get the global container instance."""
    return YRSNContainer.get_instance()


__all__ = [
    "YRSNContainer",
    "YRSNConfig",
    "Provider",
    "Dependency",
    "get_container",
]
