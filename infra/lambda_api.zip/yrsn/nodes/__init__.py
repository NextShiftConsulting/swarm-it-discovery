"""
YRSN Nodes - Lifecycle-aware processing components.

Provides LifecycleNode implementations for various domains:
- VLAQualityNode: Quality assessment for Vision-Language-Action models

Usage:
    from yrsn.nodes import VLAQualityNode, VLAQualityConfig

    config = VLAQualityConfig(
        skill_id="franka_pick_place",
        vla_type="openvla",
    )
    node = VLAQualityNode(config=config)

    # Lifecycle
    node.configure({"device": "cuda"})
    node.activate()

    # Process observations
    state = node.tick(observation)

    # Shutdown
    node.deactivate()
    node.shutdown()
"""

from yrsn.nodes.vla_quality_node import (
    VLAQualityConfig,
    VLAQualityNode,
)

__all__ = [
    "VLAQualityConfig",
    "VLAQualityNode",
]
