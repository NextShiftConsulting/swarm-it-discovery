"""
VLA Quality Node - Lifecycle-aware VLA control with YRSN quality signals.

This node orchestrates Vision-Language-Action control with YRSN quality:
- Decomposes instructions to get R/S/N quality signals
- Routes actions based on quality (α) thresholds
- Applies phase-aware impedance control
- Monitors for collapse and stability
- Emits telemetry for early warning alerts

Hexagonal Architecture:
- Ports injected via constructor (Dependency Injection)
- Core YRSN services used directly (decompose, ControlBarrier, etc.)

Usage:
    from yrsn.nodes import VLAQualityNode, VLAQualityConfig

    # Create with injected dependencies
    node = VLAQualityNode(
        config=VLAQualityConfig(skill_id="pick_place"),
        vla_model=openvla_adapter,
        robot=mujoco_adapter,
        telemetry=telemetry_adapter,
    )

    # Lifecycle
    node.configure({"device": "cuda"})
    node.activate()

    # Process observations
    while running:
        state = node.tick(observation)
        if state.collapse:
            handle_collapse(state)

    # Shutdown
    node.deactivate()
    node.shutdown()
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path
from enum import Enum
import time
import logging
import math

# Core YRSN imports
from yrsn.core.decomposition import decompose, DecompositionScore
from yrsn.core.decomposition.collapse import detect_collapse, CollapseType
from yrsn.core.control import (
    ControlBarrier,
    BarrierConfig,
    FeasibilityFilter,
    FeasibilityConfig,
    EarlyCollapseMonitor,
    StochasticStabilityMonitor,
)
from yrsn.contracts.state import YRSNState, Mode, CollapseType as StateCollapseType

# Ports
from yrsn.ports.vla import IVLAModel, VLAAction
from yrsn.ports.humanoid import (
    IHumanoidController,
    HumanoidState,
    HumanoidCommand,
    BodyPart,
)
from yrsn.ports.phase import VLAPhase, IPhaseDetector, get_phase_alpha_threshold

# Core humanoid
from yrsn.core.humanoid import (
    SimplePhaseDetector,
    ImpedanceSelector,
    SubsystemRouter,
    GaitScaler,
    # Laplacian interaction preservation
    InteractionPreservingController,
    LaplacianDeformationTracker,
    build_manipulation_mesh,
    Keypoint,
    # Kinematic retargeting
    KinematicRetargeter,
    DemoKeypoint,
    RetargetingResult,
)

logger = logging.getLogger(__name__)


class NodeState(str, Enum):
    """Lifecycle state of the node."""
    UNCONFIGURED = "unconfigured"
    CONFIGURED = "configured"
    ACTIVE = "active"
    INACTIVE = "inactive"
    SHUTDOWN = "shutdown"


@dataclass
class VLAQualityConfig:
    """Configuration for VLAQualityNode."""

    # Identity
    skill_id: str = "default"
    vla_type: str = "mock"
    robot_type: str = "h1"

    # Quality thresholds
    alpha_min_global: float = 0.2      # Emergency stop below this
    alpha_min_prediction: float = 0.3  # Don't execute below this
    alpha_min_write: float = 0.5       # Don't store experience below this

    # Subsystem thresholds (override global)
    alpha_min_legs: float = 0.4        # Legs need higher quality (fall risk)
    alpha_min_arms: float = 0.3        # Arms can operate lower (contact phase)
    alpha_min_torso: float = 0.2       # Torso is critical (balance)

    # Barrier configuration
    barrier_config: Optional[BarrierConfig] = None

    # Telemetry
    emit_telemetry: bool = True
    telemetry_rate_hz: float = 10.0

    # Collapse detection
    enable_collapse_monitor: bool = True
    enable_stability_monitor: bool = True

    # Interaction preservation (Laplacian mesh)
    enable_interaction_preservation: bool = True
    object_fragility: str = "standard"  # fragile, delicate, standard, robust

    # Kinematic retargeting
    enable_retargeting: bool = True
    retargeting_smoothness: float = 0.5

    # Checkpointing (task transition persistence)
    enable_checkpointing: bool = True
    checkpoint_dir: Optional[str] = None  # None = use temp dir
    checkpoint_on_deactivate: bool = True
    load_checkpoint_on_activate: bool = True


@dataclass
class VLATickResult:
    """Result of one VLA control cycle."""

    # YRSN state
    yrsn_state: YRSNState

    # Action result
    action_executed: bool = False
    action: Optional[VLAAction] = None
    command: Optional[HumanoidCommand] = None

    # Phase
    phase: VLAPhase = VLAPhase.FREE_MOTION

    # Decomposition
    R: float = 0.0
    S: float = 0.0
    N: float = 0.0
    alpha: float = 0.0

    # Subsystem quality
    legs_alpha: Optional[float] = None
    arms_alpha: Optional[float] = None
    torso_alpha: Optional[float] = None

    # Timing
    processing_time_ms: float = 0.0

    # Retargeting quality
    retargeting_residual: float = 0.0
    retargeting_feasible: bool = True

    # Interaction preservation
    deformation_energy: float = 0.0
    contact_slip: float = 0.0
    interaction_safe: bool = True
    safety_adjustments: Optional[Dict[str, float]] = None


class VLAQualityNode:
    """
    Lifecycle-aware VLA control node with YRSN quality signals.

    Coordinates:
    - VLA model for action generation
    - Robot controller for execution
    - YRSN decomposition for quality assessment
    - Phase detection for impedance selection
    - Barrier control for safety
    - Telemetry for monitoring
    """

    def __init__(
        self,
        config: Optional[VLAQualityConfig] = None,
        vla_model: Optional[IVLAModel] = None,
        robot: Optional[IHumanoidController] = None,
        phase_detector: Optional[IPhaseDetector] = None,
        telemetry: Optional[Any] = None,  # YRSNTelemetryAdapter
        barrier: Optional[ControlBarrier] = None,
        feasibility: Optional[FeasibilityFilter] = None,
    ):
        """
        Initialize VLA quality node.

        Args:
            config: Node configuration
            vla_model: VLA model adapter (port)
            robot: Robot controller adapter (port)
            phase_detector: Phase detector (port)
            telemetry: Telemetry adapter (port)
            barrier: Control barrier (core service)
            feasibility: Feasibility filter (core service)
        """
        self.config = config or VLAQualityConfig()

        # Injected ports
        self.vla = vla_model
        self.robot = robot
        self.phase_detector = phase_detector or SimplePhaseDetector()
        self.telemetry = telemetry

        # Core services
        self.barrier = barrier or ControlBarrier(
            self.config.barrier_config or BarrierConfig(
                alpha_min=self.config.alpha_min_prediction
            )
        )
        self.feasibility = feasibility or FeasibilityFilter()

        # Monitors
        self.collapse_monitor = EarlyCollapseMonitor() if self.config.enable_collapse_monitor else None
        self.stability_monitor = StochasticStabilityMonitor() if self.config.enable_stability_monitor else None

        # Humanoid control
        self.impedance_selector = ImpedanceSelector()
        self.subsystem_router = SubsystemRouter(robot_type=self.config.robot_type)
        self.gait_scaler = GaitScaler()

        # Kinematic retargeting (VLA → robot joints)
        self.retargeter = KinematicRetargeter(
            robot_type=self.config.robot_type
        ) if self.config.enable_retargeting else None
        self._previous_q: Optional[Dict[str, float]] = None

        # Interaction preservation (Laplacian mesh)
        self.interaction_controller = InteractionPreservingController(
            object_fragility=self.config.object_fragility
        ) if self.config.enable_interaction_preservation else None
        self._source_mesh_set = False

        # State
        self.state = NodeState.UNCONFIGURED
        self.current_phase = VLAPhase.FREE_MOTION
        self.last_alpha = 0.5
        self.tick_count = 0
        self.last_telemetry_time = 0.0

        # History for stability monitoring
        self._alpha_history: List[float] = []

    # =========================================================================
    # Lifecycle Methods
    # =========================================================================

    def configure(self, params: Optional[Dict[str, Any]] = None) -> bool:
        """
        Configure the node with parameters.

        Args:
            params: Configuration parameters (device, etc.)

        Returns:
            True if configuration successful
        """
        if self.state not in [NodeState.UNCONFIGURED, NodeState.INACTIVE]:
            logger.warning(f"Cannot configure in state {self.state}")
            return False

        params = params or {}

        # Configure VLA model if provided
        if self.vla and hasattr(self.vla, "configure"):
            self.vla.configure(params)

        self.state = NodeState.CONFIGURED
        logger.info(f"VLAQualityNode configured: skill_id={self.config.skill_id}")
        return True

    def activate(self) -> bool:
        """
        Activate the node for processing.

        Loads checkpoint if enabled to restore learned state from previous sessions.

        Returns:
            True if activation successful
        """
        if self.state != NodeState.CONFIGURED:
            logger.warning(f"Cannot activate in state {self.state}")
            return False

        # Validate required ports
        if self.vla is None:
            logger.error("VLA model not provided")
            return False
        if self.robot is None:
            logger.error("Robot controller not provided")
            return False

        # Load checkpoint if available (task transition resume)
        if self.config.enable_checkpointing and self.config.load_checkpoint_on_activate:
            try:
                if self.load_checkpoint():
                    logger.info(f"Checkpoint loaded for skill: {self.config.skill_id}")
            except Exception as e:
                logger.debug(f"No checkpoint found or load failed: {e}")

        self.state = NodeState.ACTIVE
        self.tick_count = 0
        logger.info("VLAQualityNode activated")
        return True

    def deactivate(self) -> bool:
        """
        Deactivate the node (stop processing but keep configuration).

        Saves checkpoint if enabled to preserve learned state for task transitions.

        Returns:
            True if deactivation successful
        """
        if self.state != NodeState.ACTIVE:
            return True

        # Stop robot
        if self.robot:
            self.robot.emergency_stop()

        # Save checkpoint for task transition persistence
        if self.config.enable_checkpointing and self.config.checkpoint_on_deactivate:
            try:
                checkpoint_path = self.save_checkpoint()
                logger.info(f"Checkpoint saved: {checkpoint_path}")
            except Exception as e:
                logger.warning(f"Checkpoint save failed: {e}")

        self.state = NodeState.INACTIVE
        logger.info("VLAQualityNode deactivated")
        return True

    def shutdown(self) -> None:
        """Shutdown the node completely."""
        self.deactivate()

        # Shutdown telemetry
        if self.telemetry and hasattr(self.telemetry, "shutdown"):
            self.telemetry.shutdown()

        self.state = NodeState.SHUTDOWN
        logger.info("VLAQualityNode shutdown complete")

    # =========================================================================
    # Main Processing
    # =========================================================================

    def tick(
        self,
        vision: Any,
        instruction: str,
        context: Optional[str] = None,
    ) -> VLATickResult:
        """
        Process one control cycle.

        Args:
            vision: Camera image tensor
            instruction: Language instruction
            context: Optional additional context

        Returns:
            VLATickResult with YRSN state and action result
        """
        start_time = time.time()
        self.tick_count += 1

        # 1. Get robot state
        robot_state = self.robot.get_state()

        # 2. Decompose instruction quality
        decomp = self._decompose_instruction(instruction, context)

        # 3. Check safety barriers
        safety_ok, safety_reason = self._check_safety(decomp.alpha, robot_state)

        if not safety_ok:
            # Safety violation - emergency response
            return self._handle_safety_violation(decomp, safety_reason, start_time)

        # 4. Detect manipulation phase
        phase_info = self._detect_phase(robot_state)
        self.current_phase = phase_info.phase

        # 5. Check phase-appropriate quality
        phase_alpha_min = get_phase_alpha_threshold(self.current_phase)
        if decomp.alpha < phase_alpha_min:
            logger.warning(
                f"Quality {decomp.alpha:.2f} below phase threshold {phase_alpha_min:.2f}"
            )
            # Don't fail, but note the concern

        # 6. Generate VLA action
        try:
            # τ from α_ω (reliability-adjusted), NOT raw α
            omega = getattr(decomp, 'omega', 1.0)
            quality_prior = 0.5
            alpha_omega = omega * decomp.alpha + (1 - omega) * quality_prior
            base_tau = 1.0 / max(0.1, alpha_omega)
            temperature = self.barrier.compute_safe_tau(
                decomp.alpha, base_tau, mode="prediction"
            )[0]
            action = self.vla.generate_action(
                vision=vision,
                language=instruction,
                temperature=temperature,
                context=context,
            )
        except Exception as e:
            logger.error(f"VLA action generation failed: {e}")
            return self._handle_vla_error(decomp, str(e), start_time)

        # 7. Retarget VLA action to robot joints
        retarget_result = self._retarget_action(action, robot_state)

        # 8. Check interaction preservation (Laplacian safety)
        interaction_result = self._check_interaction_safety(robot_state, retarget_result)

        # 9. Build robot command with phase-aware impedance
        command = self._build_command(
            action, decomp.alpha, self.current_phase,
            retarget_result=retarget_result,
            interaction_result=interaction_result,
        )

        # 10. Execute command
        action_executed = self.robot.send_command(command)

        # 11. Build YRSN state with retargeting quality feedback
        yrsn_state = self._build_yrsn_state(decomp, robot_state, retarget_result)
        blended_alpha = yrsn_state.alpha  # Uses retargeting feedback

        # 12. Update monitors with blended alpha (includes retargeting quality)
        self._update_monitors_with_alpha(blended_alpha)

        # 13. Emit telemetry with blended alpha
        self._emit_telemetry(decomp, phase_info, yrsn_state, blended_alpha)

        # 14. Store blended alpha for history
        self.last_alpha = blended_alpha
        self._alpha_history.append(blended_alpha)
        if len(self._alpha_history) > 1000:
            self._alpha_history = self._alpha_history[-500:]

        processing_time = (time.time() - start_time) * 1000

        return VLATickResult(
            yrsn_state=yrsn_state,
            action_executed=action_executed,
            action=action,
            command=command,
            phase=self.current_phase,
            # YRSN signals - use blended alpha for closed-loop feedback
            R=decomp.R,
            S=decomp.S,
            N=decomp.N,
            alpha=blended_alpha,  # Includes retargeting quality feedback
            processing_time_ms=processing_time,
            # Retargeting quality
            retargeting_residual=retarget_result.residual_error if retarget_result else 0.0,
            retargeting_feasible=retarget_result.is_feasible if retarget_result else True,
            # Interaction preservation (Laplacian safety)
            deformation_energy=interaction_result.get("deformation", {}).get("total_energy", 0.0) if interaction_result else 0.0,
            contact_slip=interaction_result.get("deformation", {}).get("contact_slip", 0.0) if interaction_result else 0.0,
            interaction_safe=interaction_result.get("is_safe", True) if interaction_result else True,
            safety_adjustments=interaction_result.get("adjustments") if interaction_result else None,
        )

    # =========================================================================
    # Internal Methods
    # =========================================================================

    def _decompose_instruction(
        self,
        instruction: str,
        context: Optional[str] = None,
    ) -> DecompositionScore:
        """Decompose instruction using YRSN."""
        full_text = instruction
        if context:
            full_text = f"{context}\n{instruction}"

        return decompose(full_text, query=instruction)

    def _check_safety(
        self,
        alpha: float,
        robot_state: HumanoidState,
    ) -> Tuple[bool, str]:
        """Check safety barriers."""

        # Global alpha threshold
        if alpha < self.config.alpha_min_global:
            return False, f"Global alpha {alpha:.2f} < {self.config.alpha_min_global}"

        # Barrier check
        if not self.barrier.is_prediction_allowed(alpha):
            h = self.barrier.compute_barrier(alpha)
            return False, f"Barrier violated: h={h:.3f}"

        # Balance check
        if not robot_state.is_balanced():
            return False, "Balance lost"

        # Drift check
        if self.stability_monitor:
            result = self.stability_monitor.update(alpha)
            if result.drift_violation:
                return False, f"Drift violation: {result.drift:.3f}"

        return True, "OK"

    def _detect_phase(self, robot_state: HumanoidState) -> Any:
        """Detect manipulation phase from robot state."""
        # Get force from hands
        force_magnitude = robot_state.get_total_force("right_hand")

        # Estimate distance to target (simplified - would need task info)
        # For now use a proxy based on force
        if force_magnitude > 1.0:
            distance = 0.05  # In contact
        else:
            distance = 0.5  # Far from target

        return self.phase_detector.get_phase_info(force_magnitude, distance)

    def _retarget_action(
        self,
        action: VLAAction,
        robot_state: HumanoidState,
    ) -> Optional[RetargetingResult]:
        """
        Retarget VLA action to robot joint configuration.

        Converts end-effector delta commands to joint angles via:
        1. Extract target positions from VLA action
        2. Build demo keypoints from action deltas
        3. Retarget to robot joints with smoothness constraint
        """
        if not self.retargeter:
            return None

        # Extract end-effector deltas from VLA action
        # Typically: [dx, dy, dz, rx, ry, rz, gripper]
        ee_delta = action.end_effector_delta if hasattr(action, 'end_effector_delta') else [0.0] * 7
        if len(ee_delta) < 3:
            ee_delta = [0.0] * 7

        # Get current hand positions from robot state
        current_hand = robot_state.get_end_effector_pose("right_hand")
        if current_hand is None:
            current_hand = (0.25, -0.2, 1.0)  # Default

        # Build target position
        target_pos = (
            current_hand[0] + ee_delta[0],
            current_hand[1] + ee_delta[1],
            current_hand[2] + ee_delta[2],
        )

        # Create demo keypoint for retargeting
        demo_keypoints = [
            DemoKeypoint(
                name="right_hand",
                position=target_pos,
                velocity=(ee_delta[0] * 10, ee_delta[1] * 10, ee_delta[2] * 10),
            )
        ]

        # Retarget with temporal smoothness
        result = self.retargeter.retarget_frame(demo_keypoints, self._previous_q)

        # Update previous joints for next frame
        self._previous_q = result.joint_positions.copy()

        return result

    def _check_interaction_safety(
        self,
        robot_state: HumanoidState,
        retarget_result: Optional[RetargetingResult],
    ) -> Optional[Dict[str, Any]]:
        """
        Check Laplacian interaction preservation for object safety.

        Builds interaction mesh from current robot and object state,
        tracks deformation from source mesh, returns safety assessment.
        """
        if not self.interaction_controller:
            return None

        # Build current mesh from robot keypoints
        robot_keypoints = []

        # Get hand positions
        right_hand = robot_state.get_end_effector_pose("right_hand")
        if right_hand:
            robot_keypoints.append(("right_hand", right_hand[:3]))

        left_hand = robot_state.get_end_effector_pose("left_hand")
        if left_hand:
            robot_keypoints.append(("left_hand", left_hand[:3]))

        # Get elbow positions (estimated from joints if available)
        if retarget_result:
            # Use FK from retarget result to get elbow
            joints = retarget_result.joint_positions
            sp = joints.get("right_shoulder_pitch", 0.0)
            elbow_x = 0.3 * math.sin(sp)
            elbow_z = 1.3 - 0.3 * math.cos(sp)
            robot_keypoints.append(("right_elbow", (elbow_x, -0.2, elbow_z)))

        # Get object keypoints from robot state (contact points)
        object_keypoints = []
        for contact in robot_state.contacts:
            if hasattr(contact, 'position'):
                object_keypoints.append(contact.position)

        # If no contacts, use estimated object position
        if not object_keypoints and right_hand:
            # Assume object is near hand
            object_keypoints.append((right_hand[0], right_hand[1], right_hand[2] - 0.05))

        # Build mesh
        current_mesh = build_manipulation_mesh(
            robot_keypoints=robot_keypoints,
            object_keypoints=object_keypoints,
        )

        # Set source mesh on first call
        if not self._source_mesh_set:
            self.interaction_controller.tracker.set_source_mesh(current_mesh)
            self._source_mesh_set = True
            return {"is_safe": True, "deformation": {}, "adjustments": {}}

        # Track deformation
        deformation = self.interaction_controller.tracker.update_current_mesh(current_mesh)

        # Check safety against fragility thresholds
        safety = self.interaction_controller.check_safety(deformation)

        return {
            "is_safe": safety["is_safe"],
            "violations": safety["violations"],
            "adjustments": safety["adjustments"],
            "deformation": {
                "total_energy": deformation.total_energy,
                "max_deformation": deformation.max_deformation,
                "contact_slip": deformation.contact_slip,
                "contact_ratio": deformation.contact_preservation_ratio,
            },
        }

    def _build_command(
        self,
        action: VLAAction,
        alpha: float,
        phase: VLAPhase,
        retarget_result: Optional[RetargetingResult] = None,
        interaction_result: Optional[Dict[str, Any]] = None,
    ) -> HumanoidCommand:
        """Build robot command with quality-scaled impedance."""

        # Get impedance for phase
        K, D = self.impedance_selector.get_impedance(phase, alpha)

        # Apply interaction safety adjustments if needed
        if interaction_result and not interaction_result.get("is_safe", True):
            adjustments = interaction_result.get("adjustments", {})
            # Reduce stiffness if deformation exceeded
            if "stiffness_scale" in adjustments:
                K = K * adjustments["stiffness_scale"]
            # Reduce damping proportionally
            if K < 50:
                D = D * 0.7

        # Build command
        arm_joints = self.subsystem_router.get_joints(BodyPart.ARMS)

        # Use retargeted joints if available, else default to zeros
        if retarget_result:
            joint_targets = {
                j: retarget_result.joint_positions.get(j, 0.0)
                for j in arm_joints
            }
        else:
            joint_targets = {j: 0.0 for j in arm_joints}

        command = HumanoidCommand(
            joint_targets=joint_targets,
            impedance_K={j: K for j in arm_joints},
            impedance_D={j: D for j in arm_joints},
            gripper_positions={"right_gripper": action.metadata.get("gripper", 0.0)},
        )

        # Apply quality scaling per subsystem
        command = self.subsystem_router.apply_quality_scaling(
            command, BodyPart.ARMS, alpha, phase
        )

        return command

    def _update_monitors_with_alpha(self, alpha: float):
        """Update collapse and stability monitors with blended alpha."""

        if self.collapse_monitor:
            # Would need class probabilities from VLA
            # For now just update with prediction
            pass

        if self.stability_monitor:
            self.stability_monitor.update(alpha)

    def _build_yrsn_state(
        self,
        decomp: DecompositionScore,
        robot_state: HumanoidState,
        retarget_result: Optional[RetargetingResult] = None,
    ) -> YRSNState:
        """
        Build YRSN state from decomposition with retargeting quality feedback.

        Closes the loop: VLA → retarget → execute → observe → update quality
        """
        # Base quality from instruction decomposition
        base_alpha = decomp.alpha

        # Incorporate retargeting quality if available
        if retarget_result and self.retargeter:
            # Assess retargeting quality using YRSN signals
            retarget_quality = self.retargeter.assess_retargeting_quality(
                retarget_result,
                []  # Would pass demo keypoints if available
            )
            # Blend retargeting quality into alpha
            # Low retargeting quality reduces overall confidence
            retarget_alpha = retarget_quality.get("alpha", 1.0)
            alpha = base_alpha * (0.7 + 0.3 * retarget_alpha)
        else:
            alpha = base_alpha

        # Determine mode based on final alpha
        if alpha < self.config.alpha_min_global:
            mode = Mode.ERROR
        elif alpha < self.config.alpha_min_prediction:
            mode = Mode.CAUTION
        else:
            mode = Mode.NORMAL

        # Check for collapse using detect_collapse
        collapse_analysis = detect_collapse(decomp.R, decomp.S, decomp.N)
        collapse_detected = collapse_analysis.collapse_type != CollapseType.NONE

        # Use α_ω for tau computation, NOT raw alpha
        omega = getattr(decomp, 'omega', 1.0)
        quality_prior = getattr(decomp, 'quality_prior', 0.5)
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        tau = 1.0 / max(0.1, alpha_omega)

        return YRSNState(
            alpha=alpha,
            omega=omega,
            tau=tau,
            collapse=collapse_detected,
            collapse_type=collapse_analysis.collapse_type.value if collapse_detected else "NONE",
            mode=mode,
            source_id=f"vla_{self.config.skill_id}",
            r=decomp.R,
            s=decomp.S,
            n=decomp.N,
        )

    def _emit_telemetry(
        self,
        decomp: DecompositionScore,
        phase_info: Any,
        yrsn_state: YRSNState,
        blended_alpha: float,
    ):
        """Emit telemetry if enabled."""
        if not self.telemetry or not self.config.emit_telemetry:
            return

        now = time.time()
        if now - self.last_telemetry_time < 1.0 / self.config.telemetry_rate_hz:
            return

        self.last_telemetry_time = now

        try:
            # Record decomposition (raw R/S/N signals)
            self.telemetry.record_decomposition(
                R=decomp.R,
                S=decomp.S,
                N=decomp.N,
                attributes={
                    "subsystem": "vla",
                    "skill_id": self.config.skill_id,
                    "phase": phase_info.phase.value,
                }
            )

            # Record quality with blended alpha (includes retargeting feedback)
            self.telemetry.record_quality(
                alpha=blended_alpha,  # Use blended alpha, not raw decomp.alpha
                omega=getattr(decomp, 'omega', 1.0),
                attributes={
                    "skill_id": self.config.skill_id,
                    "phase": phase_info.phase.value,
                    "raw_alpha": decomp.alpha,  # Include raw for debugging
                }
            )

            # Record collapse if detected
            if yrsn_state.collapse:
                self.telemetry.record_collapse(
                    collapse_type=str(yrsn_state.collapse_type),
                    severity=yrsn_state.collapse_severity,
                    domain="vla",
                )

        except Exception as e:
            logger.warning(f"Telemetry emission failed: {e}")

    def _handle_safety_violation(
        self,
        decomp: DecompositionScore,
        reason: str,
        start_time: float,
    ) -> VLATickResult:
        """Handle safety violation."""
        logger.warning(f"Safety violation: {reason}")

        # Emergency stop
        self.robot.emergency_stop()

        # Determine collapse type from reason
        if "drift" in reason.lower():
            collapse_type = "DRIFT"
        elif "barrier" in reason.lower():
            collapse_type = "CONFLICT"
        elif "balance" in reason.lower():
            collapse_type = "SATURATION"
        else:
            collapse_type = "CONFLICT"

        # Build error state
        yrsn_state = YRSNState(
            alpha=decomp.alpha,
            omega=1.0,
            tau=10.0,
            collapse=True,
            collapse_type=collapse_type,
            collapse_action="HALT",
            mode=Mode.ERROR,
            source_id=f"vla_{self.config.skill_id}",
            r=decomp.R,
            s=decomp.S,
            n=decomp.N,
        )

        return VLATickResult(
            yrsn_state=yrsn_state,
            action_executed=False,
            phase=self.current_phase,
            R=decomp.R,
            S=decomp.S,
            N=decomp.N,
            alpha=decomp.alpha,
            processing_time_ms=(time.time() - start_time) * 1000,
        )

    def _handle_vla_error(
        self,
        decomp: DecompositionScore,
        error: str,
        start_time: float,
    ) -> VLATickResult:
        """Handle VLA error."""
        logger.error(f"VLA error: {error}")

        yrsn_state = YRSNState(
            alpha=decomp.alpha,
            omega=0.5,
            tau=5.0,
            collapse=True,
            collapse_type="CONFLICT",
            collapse_action="RETRY",
            mode=Mode.ERROR,
            source_id=f"vla_{self.config.skill_id}",
        )

        return VLATickResult(
            yrsn_state=yrsn_state,
            action_executed=False,
            phase=self.current_phase,
            R=decomp.R,
            S=decomp.S,
            N=decomp.N,
            alpha=decomp.alpha,
            processing_time_ms=(time.time() - start_time) * 1000,
        )

    # =========================================================================
    # Query Methods
    # =========================================================================

    def get_current_phase(self) -> VLAPhase:
        """Get current manipulation phase."""
        return self.current_phase

    def get_alpha_trend(self, window: int = 100) -> float:
        """Get alpha trend (slope) over recent history."""
        if len(self._alpha_history) < 2:
            return 0.0

        recent = self._alpha_history[-window:]
        if len(recent) < 2:
            return 0.0

        # Simple linear regression
        n = len(recent)
        x_mean = (n - 1) / 2
        y_mean = sum(recent) / n

        numerator = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(recent))
        denominator = sum((i - x_mean) ** 2 for i in range(n))

        if denominator == 0:
            return 0.0

        return numerator / denominator

    def is_quality_declining(self, threshold: float = -0.001) -> bool:
        """Check if quality is declining."""
        return self.get_alpha_trend() < threshold

    # =========================================================================
    # Checkpointing (Task Transition Persistence)
    # =========================================================================

    def _get_checkpoint_path(self) -> Path:
        """Get checkpoint file path for current skill."""
        from pathlib import Path
        import tempfile

        if self.config.checkpoint_dir:
            base_dir = Path(self.config.checkpoint_dir)
        else:
            base_dir = Path(tempfile.gettempdir()) / "yrsn_checkpoints"

        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir / f"vla_node_{self.config.skill_id}.pkl.gz"

    def save_checkpoint(self, path: Optional[str] = None) -> Path:
        """
        Save node state for task transition persistence.

        Saves:
        - Alpha history (quality trend)
        - Retargeting state (previous joint positions)
        - Interaction mesh source (Laplacian reference)
        - Tick count and timing

        Args:
            path: Optional custom path, defaults to skill-based path

        Returns:
            Path to saved checkpoint
        """
        from pathlib import Path
        from yrsn.hardware.serialization import save_memristor_state

        checkpoint_path = Path(path) if path else self._get_checkpoint_path()

        # Build checkpoint state
        state = {
            "skill_id": self.config.skill_id,
            "robot_type": self.config.robot_type,
            "tick_count": self.tick_count,
            "last_alpha": self.last_alpha,
            "alpha_history": self._alpha_history.copy(),
            "current_phase": self.current_phase.value,
            # Retargeting state
            "previous_q": self._previous_q,
            # Interaction mesh state
            "source_mesh_set": self._source_mesh_set,
        }

        # Add interaction controller state if available
        if self.interaction_controller and self._source_mesh_set:
            tracker = self.interaction_controller.tracker
            if tracker._source_mesh:
                state["source_mesh"] = {
                    "keypoints": [
                        {"name": kp.name, "position": kp.position, "source": kp.source, "is_contact": kp.is_contact}
                        for kp in tracker._source_mesh.keypoints
                    ],
                    "edges": tracker._source_mesh.edges,
                    "laplacian_coords": dict(tracker._source_mesh.laplacian_coords),
                }

        # Save with numpy-safe serialization
        save_memristor_state(
            state,
            checkpoint_path,
            format="pickle",
            compress=True,
            metadata={
                "node_type": "VLAQualityNode",
                "skill_id": self.config.skill_id,
            }
        )

        return checkpoint_path

    def load_checkpoint(self, path: Optional[str] = None) -> bool:
        """
        Load node state from checkpoint.

        Restores:
        - Alpha history (quality trend continues)
        - Retargeting state (smooth motion continues)
        - Interaction mesh source (object safety reference)

        Args:
            path: Optional custom path, defaults to skill-based path

        Returns:
            True if checkpoint loaded successfully
        """
        from pathlib import Path
        from yrsn.hardware.serialization import load_memristor_state

        checkpoint_path = Path(path) if path else self._get_checkpoint_path()

        if not checkpoint_path.exists():
            return False

        try:
            state = load_memristor_state(checkpoint_path)

            # Verify skill matches
            if state.get("skill_id") != self.config.skill_id:
                logger.warning(
                    f"Checkpoint skill mismatch: {state.get('skill_id')} != {self.config.skill_id}"
                )
                # Still load - might be intentional transfer

            # Restore alpha history
            self._alpha_history = state.get("alpha_history", [])
            self.last_alpha = state.get("last_alpha", 0.5)
            self.tick_count = state.get("tick_count", 0)

            # Restore retargeting state
            self._previous_q = state.get("previous_q")

            # Restore interaction mesh source
            if "source_mesh" in state and self.interaction_controller:
                mesh_data = state["source_mesh"]
                from yrsn.core.humanoid import InteractionMesh, Keypoint

                mesh = InteractionMesh()
                for kp_data in mesh_data.get("keypoints", []):
                    mesh.add_keypoint(Keypoint(
                        name=kp_data["name"],
                        position=tuple(kp_data["position"]),
                        source=kp_data["source"],
                        is_contact=kp_data.get("is_contact", False),
                    ))
                mesh.edges = mesh_data.get("edges", [])
                mesh.laplacian_coords = {
                    int(k): tuple(v) for k, v in mesh_data.get("laplacian_coords", {}).items()
                }
                self.interaction_controller.tracker.set_source_mesh(mesh)
                self._source_mesh_set = True

            logger.info(f"Loaded checkpoint: {len(self._alpha_history)} history points, tick={self.tick_count}")
            return True

        except Exception as e:
            logger.warning(f"Failed to load checkpoint: {e}")
            return False

    def get_checkpoint_info(self) -> Optional[Dict[str, Any]]:
        """Get info about existing checkpoint without loading it."""
        from yrsn.hardware.serialization import get_state_info

        checkpoint_path = self._get_checkpoint_path()
        if not checkpoint_path.exists():
            return None

        try:
            return get_state_info(checkpoint_path)
        except Exception:
            return None


__all__ = [
    "VLAQualityNode",
    "VLAQualityConfig",
    "VLATickResult",
    "NodeState",
]
