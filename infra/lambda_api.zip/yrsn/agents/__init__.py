"""
YRSN Agent Framework

Provides specialized agents for multi-agent coordination:
- JudgeAgent: Failure escalation and recovery
"""

from src.yrsn.agents.judge import (
    JudgeAgent,
    MockJudgeAgent,
    FailureType,
    create_judge_agent
)

__all__ = [
    'JudgeAgent',
    'MockJudgeAgent',
    'FailureType',
    'create_judge_agent'
]
