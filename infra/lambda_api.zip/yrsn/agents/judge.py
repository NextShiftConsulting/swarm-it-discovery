"""
Judge Agent for Failure Escalation

Implements high-reasoning failure analysis using LLM (Gemini 2.0 Flash Thinking,
Claude Opus, or GPT-4) to recommend recovery strategies when standard retry
logic fails.

Requirements (AGENT_OPERATIONS_GUIDE.md):
1. Zero-state analysis from heartbeats and traces
2. Failure classification (LOGIC_LOOP, TIMEOUT, etc.)
3. Modification authority (can reset retry counter once)
4. 60-second timeout requirement
5. Certificate invalidation authority
6. Structured JSON response

Usage:
    judge = JudgeAgent(provider="openai", model="gpt-4")
    decision = await judge.analyze_failure(
        agent_id="agent_123",
        error=exception,
        error_type=FailureType.TIMEOUT,
        heartbeats=heartbeat_list,
        exception_trace=traceback_str,
        certificate_history=cert_list
    )
"""

import asyncio
import json
from typing import Dict, Any, List, Optional
from enum import Enum
from datetime import datetime

from src.yrsn.keys.config_manager import get_config


class FailureType(Enum):
    """Failure types for classification."""
    LOGIC_LOOP = "logic_loop"
    TIMEOUT = "timeout"
    DEPENDENCY_FAILURE = "dependency_failure"
    INVALID_STATE = "invalid_state"
    CERTIFICATE_INVALID = "certificate_invalid"
    UNKNOWN = "unknown"


class JudgeAgent:
    """
    Production Judge Agent for failure escalation.

    Uses high-reasoning LLM to analyze failures and recommend recovery.
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None
    ):
        """
        Initialize Judge Agent.

        Args:
            provider: LLM provider (openai, anthropic, gemini) - defaults to config
            model: Model name - defaults to config
            api_key: API key - defaults to config
        """
        config = get_config()

        self.provider = provider or config.llm_provider
        self.model = model or config.llm_model
        self.api_key = api_key or config.llm_api_key

        if not self.api_key:
            raise ValueError(
                "No LLM API key configured. Set YRSN_LLM_API_KEY or configure in aws_config.yaml"
            )

        # Initialize LLM client based on provider
        self._init_client()

    def _init_client(self):
        """Initialize LLM client based on provider."""
        if self.provider.lower() == "openai":
            try:
                from openai import AsyncOpenAI
                self.client = AsyncOpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError("openai package required for OpenAI provider")

        elif self.provider.lower() == "anthropic":
            try:
                from anthropic import AsyncAnthropic
                self.client = AsyncAnthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError("anthropic package required for Anthropic provider")

        elif self.provider.lower() == "gemini":
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.client = genai
            except ImportError:
                raise ImportError("google-generativeai package required for Gemini provider")

        else:
            raise ValueError(f"Unsupported provider: {self.provider}")

    async def analyze_failure(
        self,
        agent_id: str,
        error: Exception,
        error_type: FailureType,
        heartbeats: List[Dict[str, Any]],
        exception_trace: str,
        certificate_history: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyze failure and recommend recovery strategy.

        Args:
            agent_id: Failing agent identifier
            error: Exception that was raised
            error_type: Classified failure type
            heartbeats: Recent heartbeat messages (last 10)
            exception_trace: Full exception traceback
            certificate_history: Recent certificates (last 5)

        Returns:
            Decision dict:
            {
                'decision': 'RETRY_WITH_MODIFICATION' or 'ABORT',
                'failure_type': str,
                'reasoning': str,
                'modifications': dict,
                'certificate_invalidations': list[str]
            }

        Raises:
            asyncio.TimeoutError: If analysis exceeds 60 seconds
        """
        # Construct analysis prompt
        prompt = self._build_analysis_prompt(
            agent_id=agent_id,
            error=error,
            error_type=error_type,
            heartbeats=heartbeats,
            exception_trace=exception_trace,
            certificate_history=certificate_history
        )

        # Call LLM with 60-second timeout
        try:
            async with asyncio.timeout(60):
                response_text = await self._call_llm(prompt)

            # Parse response
            decision = self._parse_response(response_text)

            # Validate response structure
            self._validate_decision(decision)

            return decision

        except asyncio.TimeoutError:
            # Judge exceeded 60s timeout - default to ABORT
            return {
                'decision': 'ABORT',
                'failure_type': error_type.value,
                'reasoning': 'Judge analysis exceeded 60-second timeout',
                'modifications': {},
                'certificate_invalidations': []
            }

    def _build_analysis_prompt(
        self,
        agent_id: str,
        error: Exception,
        error_type: FailureType,
        heartbeats: List[Dict[str, Any]],
        exception_trace: str,
        certificate_history: List[Dict[str, Any]]
    ) -> str:
        """Build analysis prompt for LLM."""
        prompt = f"""You are a Judge Agent analyzing a multi-agent system failure.

FAILURE CONTEXT:
Agent ID: {agent_id}
Error Type: {error_type.value}
Error Message: {str(error)}

HEARTBEAT HISTORY (last 10):
{json.dumps(heartbeats, indent=2)}

EXCEPTION TRACE:
{exception_trace}

CERTIFICATE HISTORY (last 5):
{json.dumps(certificate_history, indent=2)}

ANALYSIS REQUIRED:
1. Determine if this is a recoverable failure
2. Classify the root cause (logic loop, timeout, dependency, state corruption, certificate issue)
3. Recommend recovery strategy

DECISION OPTIONS:
- RETRY_WITH_MODIFICATION: Suggest parameter changes, timeout extensions, or other modifications
- ABORT: Failure is non-recoverable or requires manual intervention

RESPONSE FORMAT (JSON):
{{
    "decision": "RETRY_WITH_MODIFICATION" or "ABORT",
    "failure_type": "{error_type.value}",
    "reasoning": "Detailed explanation of why this decision was made",
    "modifications": {{
        "timeout": 600,
        "max_iterations": 100,
        "other_params": "as needed"
    }},
    "certificate_invalidations": ["cert_id_1", "cert_id_2"]
}}

CONSTRAINTS:
- You have ONE retry reset authority (use wisely)
- Analysis must complete in 60 seconds
- Only invalidate certificates if they are clearly corrupt (κ_A < 0.5)

Provide your analysis:"""

        return prompt

    async def _call_llm(self, prompt: str) -> str:
        """Call LLM API based on provider."""
        if self.provider.lower() == "openai":
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a Judge Agent analyzing multi-agent failures."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,  # Low temperature for consistent analysis
                max_tokens=1000
            )
            return response.choices[0].message.content

        elif self.provider.lower() == "anthropic":
            response = await self.client.messages.create(
                model=self.model,
                max_tokens=1000,
                temperature=0.2,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            return response.content[0].text

        elif self.provider.lower() == "gemini":
            # Gemini async API
            model = self.client.GenerativeModel(self.model)
            response = await model.generate_content_async(
                prompt,
                generation_config={"temperature": 0.2, "max_output_tokens": 1000}
            )
            return response.text

        else:
            raise ValueError(f"Unsupported provider: {self.provider}")

    def _parse_response(self, response_text: str) -> Dict[str, Any]:
        """Parse LLM response into decision dict."""
        # Try to extract JSON from response
        # Handle both pure JSON and JSON in markdown code blocks
        response_text = response_text.strip()

        # Remove markdown code blocks if present
        if response_text.startswith("```"):
            lines = response_text.split("\n")
            response_text = "\n".join(lines[1:-1])  # Remove first and last lines

        # Parse JSON
        try:
            decision = json.loads(response_text)
        except json.JSONDecodeError:
            # Fallback: try to find JSON in text
            start = response_text.find("{")
            end = response_text.rfind("}") + 1
            if start >= 0 and end > start:
                decision = json.loads(response_text[start:end])
            else:
                # Default to ABORT if can't parse
                decision = {
                    'decision': 'ABORT',
                    'failure_type': 'unknown',
                    'reasoning': 'Failed to parse Judge response',
                    'modifications': {},
                    'certificate_invalidations': []
                }

        return decision

    def _validate_decision(self, decision: Dict[str, Any]):
        """Validate decision structure."""
        required_fields = ['decision', 'failure_type', 'reasoning', 'modifications']
        for field in required_fields:
            if field not in decision:
                raise ValueError(f"Missing required field: {field}")

        valid_decisions = ['RETRY_WITH_MODIFICATION', 'ABORT']
        if decision['decision'] not in valid_decisions:
            raise ValueError(f"Invalid decision: {decision['decision']}")

        # Ensure certificate_invalidations exists
        if 'certificate_invalidations' not in decision:
            decision['certificate_invalidations'] = []


class MockJudgeAgent:
    """
    Mock Judge Agent for testing without LLM.

    Use this when LLM API keys are not configured.
    """

    async def analyze_failure(
        self,
        agent_id: str,
        error: Exception,
        error_type: FailureType,
        heartbeats: List[Dict[str, Any]],
        exception_trace: str,
        certificate_history: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Mock analysis with simple heuristics."""
        print(f"  [MOCK JUDGE] Analyzing failure: {agent_id} - {error_type.value}")

        if error_type == FailureType.LOGIC_LOOP:
            return {
                'decision': 'RETRY_WITH_MODIFICATION',
                'failure_type': error_type.value,
                'reasoning': 'Logic loop detected - adding iteration limit',
                'modifications': {'max_iterations': 100, 'timeout': 300},
                'certificate_invalidations': []
            }
        elif error_type == FailureType.TIMEOUT:
            return {
                'decision': 'ABORT',
                'failure_type': error_type.value,
                'reasoning': 'Timeout suggests systemic issue',
                'modifications': {},
                'certificate_invalidations': []
            }
        elif error_type == FailureType.CERTIFICATE_INVALID:
            corrupt_certs = [
                cert['certificate_id']
                for cert in certificate_history
                if cert.get('κ_A', 0) < 0.5
            ]
            return {
                'decision': 'RETRY_WITH_MODIFICATION',
                'failure_type': error_type.value,
                'reasoning': 'Invalid certificates detected',
                'modifications': {'recertify': True},
                'certificate_invalidations': corrupt_certs
            }
        else:
            return {
                'decision': 'ABORT',
                'failure_type': error_type.value,
                'reasoning': 'Unknown failure - defaulting to abort',
                'modifications': {},
                'certificate_invalidations': []
            }


def create_judge_agent(use_mock: bool = False) -> JudgeAgent | MockJudgeAgent:
    """
    Factory function to create Judge Agent.

    Args:
        use_mock: If True, return MockJudgeAgent. Otherwise, try to create
                  real JudgeAgent (falls back to mock if no API key).

    Returns:
        JudgeAgent or MockJudgeAgent
    """
    if use_mock:
        return MockJudgeAgent()

    try:
        # Try to create real Judge
        return JudgeAgent()
    except ValueError:
        # No API key - fallback to mock
        print("[WARN] No LLM API key configured - using MockJudgeAgent")
        print("       Set YRSN_LLM_API_KEY to enable real Judge")
        return MockJudgeAgent()
