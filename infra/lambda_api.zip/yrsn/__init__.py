"""
YRSN - Context Quality Engineering

Y = R + S + N decomposition for AI context quality.

Patent Notice: This software includes material that is the subject of one
or more pending patent applications. See PATENT_NOTICE.md for details.

Architecture: Hexagonal (Ports & Adapters)
    - ports/     : Abstract interfaces (ILLMClient, IStorage, IEventBus)
    - core/      : Domain logic (decomposition, temperature, memory)
    - adapters/  : Implementations (REST, CrewAI, ROS2, OpenAI, Chroma)

Quick Start:
    from yrsn import YRSN, YrsnState

    y = YRSN("Your content", query="optional query")
    print(y.alpha, y.omega, y.tau)

Nodes (Lifecycle-aware):
    from yrsn.nodes import QualityMonitorNode

    node = QualityMonitorNode()
    node.configure({"alpha_threshold": 0.7})
    node.activate()
    state = node.tick(observation)

CrewAI:
    from yrsn.adapters.inbound.crewai import YRSN_TOOLS, create_quality_crew

ROS2:
    from yrsn.adapters.inbound.ros2 import QualityMonitorROS

API:
    from yrsn.adapters.inbound.rest import YRSNApp
"""

__version__ = "1.0.0"
__author__ = "Next Shift Consulting LLC"

# =============================================================================
# Legal Notice (embedded in package)
# =============================================================================
from yrsn._legal import PATENT_NOTICE  # noqa: F401

# =============================================================================
# Contracts (always available)
# =============================================================================
from yrsn.contracts import (
    Observation,
    YrsnState,
    YrsnEvent,
    Mode,
    EventType,
)

# =============================================================================
# Core API
# =============================================================================
from yrsn.core import (
    YRSN,
    compute_yrsn,
    compute_quality,
    compute_temperature,
    detect_collapse,
    quality_gate,
    CollapseType,
    Severity,
)

# =============================================================================
# Runtime
# =============================================================================
from yrsn.runtime import (
    LifecycleNode,
    LifecycleState,
)

# =============================================================================
# Aliases (simple API)
# =============================================================================
decompose = compute_yrsn
quality = compute_quality
temperature = compute_temperature

__all__ = [
    # Version
    "__version__",

    # Contracts
    "Observation",
    "YrsnState",
    "YrsnEvent",
    "Mode",
    "EventType",

    # Core
    "YRSN",
    "compute_yrsn",
    "compute_quality",
    "compute_temperature",
    "detect_collapse",
    "quality_gate",
    "CollapseType",
    "Severity",

    # Aliases
    "decompose",
    "quality",
    "temperature",

    # Runtime
    "LifecycleNode",
    "LifecycleState",
]
