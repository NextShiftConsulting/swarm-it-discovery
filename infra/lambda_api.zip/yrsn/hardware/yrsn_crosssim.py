"""
YRSNCrossSim - Hexagonal Architecture Adapter for CrossSim.

Implements ICrossbar port for hardware claim validation (EXP100-105).

This adapter provides:
1. ICrossbar protocol compliance for hexagonal architecture
2. Full CrossSim feature exposure (non-idealities, ADC/DAC, stuck cells)
3. R/S/N projection support for hardware validation experiments
4. Device model selection (RRAM, PCM, SONOS, etc.)

Usage:
    from yrsn.hardware import YRSNCrossSim, YRSNCrossSimConfig

    config = YRSNCrossSimConfig(
        read_noise=0.05,
        programming_error=0.02,
        adc_bits=8,
    )
    crossbar = YRSNCrossSim(shape=(256, 64), config=config)
    crossbar.program(weights)
    output = crossbar.matvec(input_vector)
"""

from typing import Optional, Dict, Any, List, Tuple, Union, Literal
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
from numpy.typing import NDArray

try:
    from simulator import AnalogCore, CrossSimParameters
    CROSSSIM_AVAILABLE = True
except ImportError:
    CROSSSIM_AVAILABLE = False
    AnalogCore = None
    CrossSimParameters = None


# Device models available in CrossSim
DeviceModel = Literal[
    "IdealDevice",
    "NormalIndependentDevice",
    "NormalProportionalDevice",
    "UniformIndependentDevice",
    "PCMJoshi",
    "RRAMMilo",
    "RRAMWan",
    "SONOS",
]


@dataclass
class YRSNCrossSimConfig:
    """
    Configuration for YRSNCrossSim adapter.

    Exposes all CrossSim features needed for hardware claim validation:
    - Device non-idealities (noise, drift, programming error)
    - ADC/DAC precision
    - Stuck cells simulation
    - Parasitic effects
    - Device model selection
    """
    # Non-idealities
    read_noise: float = 0.0  # Fraction of signal [0-1]
    programming_error: float = 0.0  # Fraction of range [0-1]
    drift_magnitude: float = 0.0  # Fraction [0-1]

    # Device model
    device_model: DeviceModel = "NormalProportionalDevice"

    # Quantization
    adc_bits: int = 16  # ADC precision (4-16 typical)
    dac_bits: int = 16  # DAC precision (4-16 typical)
    weight_bits: int = 8  # Weight precision

    # Stuck cells
    stuck_on_fraction: float = 0.0  # Fraction of cells stuck at max
    stuck_off_fraction: float = 0.0  # Fraction of cells stuck at min

    # Parasitic effects
    parasitic_resistance: float = 0.0  # Ohms
    parasitic_capacitance: float = 0.0  # Farads

    # Bit-slicing
    bit_sliced: bool = False
    slice_bits: int = 2  # Bits per slice

    # Misc
    seed: Optional[int] = 42  # For reproducibility

    def to_crosssim_params(self) -> "CrossSimParameters":
        """Convert to CrossSim parameters object."""
        if not CROSSSIM_AVAILABLE:
            raise ImportError("CrossSim not installed")

        params = CrossSimParameters()

        # Read noise
        if self.read_noise > 0:
            params.xbar.device.read_noise.enable = True
            params.xbar.device.read_noise.magnitude = self.read_noise
            params.xbar.device.read_noise.model = self.device_model

        # Programming error
        if self.programming_error > 0:
            params.xbar.device.programming_error.enable = True
            params.xbar.device.programming_error.magnitude = self.programming_error
            params.xbar.device.programming_error.model = self.device_model

        # Drift
        if self.drift_magnitude > 0:
            params.xbar.device.drift_error.enable = True
            params.xbar.device.drift_error.magnitude = self.drift_magnitude
            params.xbar.device.drift_error.model = self.device_model

        # Bit-slicing
        if self.bit_sliced:
            params.core.bit_sliced = True
            params.core.weight_bits = self.weight_bits

        return params


class YRSNCrossSim:
    """
    ICrossbar-compliant adapter for CrossSim.

    Implements the hardware port protocol for hexagonal architecture.

    Example:
        config = YRSNCrossSimConfig(read_noise=0.05)
        crossbar = YRSNCrossSim((256, 64), config)
        crossbar.program(W)
        y = crossbar.matvec(x)
    """

    def __init__(
        self,
        shape: Tuple[int, int],
        config: Optional[YRSNCrossSimConfig] = None,
    ):
        """
        Initialize CrossSim crossbar.

        Args:
            shape: (rows, cols) crossbar dimensions
            config: Hardware configuration
        """
        if not CROSSSIM_AVAILABLE:
            raise ImportError(
                "CrossSim not installed. Install with:\n"
                "  pip install git+https://github.com/sandialabs/cross-sim.git"
            )

        self._shape = shape
        self.config = config or YRSNCrossSimConfig()

        # Get CrossSim parameters
        self._params = self.config.to_crosssim_params()

        # Initialize with zeros
        initial_weights = np.zeros(shape, dtype=np.float32)
        self._core = AnalogCore(initial_weights, self._params)

        # Stuck cells mask
        self._stuck_on_mask: Optional[NDArray] = None
        self._stuck_off_mask: Optional[NDArray] = None

        if self.config.stuck_on_fraction > 0 or self.config.stuck_off_fraction > 0:
            self._init_stuck_cells()

    # =========================================================================
    # ICrossbar Protocol Implementation
    # =========================================================================

    @property
    def shape(self) -> Tuple[int, int]:
        """Crossbar dimensions (rows, cols)."""
        return self._shape

    def program(self, weights: NDArray[np.float64]) -> None:
        """
        Program weight matrix into crossbar.

        Applies stuck cell effects if configured.

        Args:
            weights: Weight matrix to program
        """
        W = weights.astype(np.float32)

        # Apply stuck cells
        if self._stuck_on_mask is not None:
            W[self._stuck_on_mask] = 1.0
        if self._stuck_off_mask is not None:
            W[self._stuck_off_mask] = 0.0

        self._core.set_matrix(W)

    def matvec(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """
        Matrix-vector multiplication through analog crossbar.

        Includes all configured non-idealities.

        Args:
            x: Input vector

        Returns:
            Output vector with hardware effects
        """
        x_in = x.astype(np.float32)

        # Apply DAC quantization if configured
        if self.config.dac_bits < 16:
            x_in = self._quantize(x_in, self.config.dac_bits)

        # Analog computation with non-idealities
        y = self._core.matvec(x_in)

        # Apply ADC quantization if configured
        if self.config.adc_bits < 16:
            y = self._quantize(y, self.config.adc_bits)

        return y.astype(np.float64)

    def matmul(
        self,
        x: NDArray[np.float64],
        w: NDArray[np.float64]
    ) -> NDArray[np.float64]:
        """
        Matrix multiplication (program + compute).

        Args:
            x: Input vector
            w: Weight matrix

        Returns:
            Output vector
        """
        self.program(w)
        return self.matvec(x)

    # =========================================================================
    # Extended Hardware Features
    # =========================================================================

    def get_weights(self) -> NDArray[np.float64]:
        """Get current programmed weights."""
        return self._core.get_matrix().astype(np.float64)

    def inject_noise(self, noise_level: float) -> None:
        """
        Temporarily increase read noise.

        Useful for sweeping noise levels in experiments.

        Args:
            noise_level: Noise magnitude [0-1]
        """
        self._params.xbar.device.read_noise.enable = noise_level > 0
        self._params.xbar.device.read_noise.magnitude = noise_level

        # Re-create core with new params (CrossSim requirement)
        W = self._core.get_matrix()
        self._core = AnalogCore(W, self._params)

    def inject_drift(self, drift_level: float) -> None:
        """
        Apply conductance drift.

        Args:
            drift_level: Drift magnitude [0-1]
        """
        self._params.xbar.device.drift_error.enable = drift_level > 0
        self._params.xbar.device.drift_error.magnitude = drift_level

        W = self._core.get_matrix()
        self._core = AnalogCore(W, self._params)

    def inject_stuck_cells(
        self,
        stuck_on: float = 0.0,
        stuck_off: float = 0.0,
        seed: Optional[int] = None,
    ) -> int:
        """
        Inject stuck cells (permanent faults).

        Args:
            stuck_on: Fraction stuck at max conductance
            stuck_off: Fraction stuck at min conductance
            seed: Random seed for reproducibility

        Returns:
            Total number of stuck cells
        """
        rng = np.random.RandomState(seed or self.config.seed)
        n_cells = self._shape[0] * self._shape[1]

        # Generate masks
        n_stuck_on = int(stuck_on * n_cells)
        n_stuck_off = int(stuck_off * n_cells)

        indices = rng.permutation(n_cells)

        self._stuck_on_mask = np.zeros(self._shape, dtype=bool)
        self._stuck_off_mask = np.zeros(self._shape, dtype=bool)

        stuck_on_idx = indices[:n_stuck_on]
        stuck_off_idx = indices[n_stuck_on:n_stuck_on + n_stuck_off]

        self._stuck_on_mask.flat[stuck_on_idx] = True
        self._stuck_off_mask.flat[stuck_off_idx] = True

        # Re-program with stuck cells
        W = self._core.get_matrix()
        self.program(W)

        return n_stuck_on + n_stuck_off

    def set_adc_precision(self, bits: int) -> None:
        """Set ADC bit precision."""
        self.config.adc_bits = bits

    def set_dac_precision(self, bits: int) -> None:
        """Set DAC bit precision."""
        self.config.dac_bits = bits

    # =========================================================================
    # Private Methods
    # =========================================================================

    def _init_stuck_cells(self) -> None:
        """Initialize stuck cell masks from config."""
        self.inject_stuck_cells(
            self.config.stuck_on_fraction,
            self.config.stuck_off_fraction,
            self.config.seed,
        )

    def _quantize(self, x: np.ndarray, bits: int) -> np.ndarray:
        """Quantize values to given bit precision."""
        if bits >= 16:
            return x

        levels = 2 ** bits
        x_min, x_max = x.min(), x.max()

        if x_max - x_min < 1e-10:
            return x

        # Normalize to [0, 1], quantize, scale back
        x_norm = (x - x_min) / (x_max - x_min + 1e-10)
        x_quant = np.round(x_norm * (levels - 1)) / (levels - 1)
        return x_quant * (x_max - x_min) + x_min


class YRSNCrossSimRSN:
    """
    Complete R/S/N projection using three YRSNCrossSim crossbars.

    This is the primary interface for hardware validation experiments.

    Example:
        config = YRSNCrossSimConfig(read_noise=0.05)
        rsn = YRSNCrossSimRSN(embed_dim=64, rsn_dim=32, config=config)
        rsn.program_from_projection(trained_projection)
        result = rsn.compute_rsn(features)
    """

    def __init__(
        self,
        embed_dim: int,
        rsn_dim: int,
        config: Optional[YRSNCrossSimConfig] = None,
    ):
        """
        Initialize R/S/N crossbar array.

        Args:
            embed_dim: Input embedding dimension
            rsn_dim: R/S/N projection dimension
            config: Hardware configuration
        """
        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim
        self.config = config or YRSNCrossSimConfig()

        # Three crossbars for R, S, N
        self.R_crossbar = YRSNCrossSim((rsn_dim, embed_dim), config)
        self.S_crossbar = YRSNCrossSim((rsn_dim, embed_dim), config)
        self.N_crossbar = YRSNCrossSim((rsn_dim, embed_dim), config)

    def program_from_projection(self, projection) -> None:
        """
        Program weights from a trained TrainedRSNProjection.

        Args:
            projection: TrainedRSNProjection with projection_heads
        """
        heads = projection.projection_heads

        W_r = heads.R_head[0].weight.detach().cpu().numpy()
        W_s = heads.S_head[0].weight.detach().cpu().numpy()
        W_n = heads.N_head[0].weight.detach().cpu().numpy()

        self.R_crossbar.program(W_r)
        self.S_crossbar.program(W_s)
        self.N_crossbar.program(W_n)

    def program_weights(
        self,
        W_r: np.ndarray,
        W_s: np.ndarray,
        W_n: np.ndarray,
    ) -> None:
        """
        Program weights directly.

        Args:
            W_r: R projection matrix
            W_s: S projection matrix
            W_n: N projection matrix
        """
        self.R_crossbar.program(W_r)
        self.S_crossbar.program(W_s)
        self.N_crossbar.program(W_n)

    def compute_rsn(self, x: np.ndarray) -> Dict[str, Any]:
        """
        Compute R/S/N from input features through hardware.

        Args:
            x: Input features [embed_dim]

        Returns:
            Dict with R, S, N, alpha, tau, etc.
        """
        x = x.astype(np.float32)

        # Project through each crossbar
        R_proj = self.R_crossbar.matvec(x)
        S_proj = self.S_crossbar.matvec(x)
        N_proj = self.N_crossbar.matvec(x)

        # Compute norms as scores
        R_score = np.linalg.norm(R_proj)
        S_score = np.linalg.norm(S_proj)
        N_score = np.linalg.norm(N_proj)

        # Normalize to simplex
        total = R_score + S_score + N_score + 1e-8
        R = R_score / total
        S = S_score / total
        N = N_score / total

        # Derived metrics
        alpha = R
        omega = 1.0  # Default for hardware simulation
        quality_prior = 0.5
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        return {
            'R': float(R),
            'S': float(S),
            'N': float(N),
            'R_proj': R_proj,
            'S_proj': S_proj,
            'N_proj': N_proj,
            'alpha': float(alpha),
            'omega': float(omega),
            'tau': float(tau),
            'backend': 'yrsn_crosssim',
        }

    def compute_rsn_batch(self, features: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Compute R/S/N for a batch of features.

        Args:
            features: Input features [batch, embed_dim]

        Returns:
            Dict with R, S, N arrays [batch]
        """
        batch_size = len(features)
        R_vals = np.zeros(batch_size)
        S_vals = np.zeros(batch_size)
        N_vals = np.zeros(batch_size)
        alpha_vals = np.zeros(batch_size)
        tau_vals = np.zeros(batch_size)

        for i, x in enumerate(features):
            result = self.compute_rsn(x)
            R_vals[i] = result['R']
            S_vals[i] = result['S']
            N_vals[i] = result['N']
            alpha_vals[i] = result['alpha']
            tau_vals[i] = result['tau']

        return {
            'R': R_vals,
            'S': S_vals,
            'N': N_vals,
            'alpha': alpha_vals,
            'tau': tau_vals,
        }

    # =========================================================================
    # Hardware Injection Methods (for experiments)
    # =========================================================================

    def inject_noise(self, noise_level: float) -> None:
        """Inject read noise into all crossbars."""
        self.R_crossbar.inject_noise(noise_level)
        self.S_crossbar.inject_noise(noise_level)
        self.N_crossbar.inject_noise(noise_level)

    def inject_drift(self, drift_level: float) -> None:
        """Inject conductance drift into all crossbars."""
        self.R_crossbar.inject_drift(drift_level)
        self.S_crossbar.inject_drift(drift_level)
        self.N_crossbar.inject_drift(drift_level)

    def apply_drift(self, time_delta: float) -> None:
        """
        Apply physics-based weight drift over time.

        Models temporal drift as: drift_magnitude = k * sqrt(time_delta)
        where k is a device-specific constant (default 0.01).

        This is the ICrossbarRSN-compliant interface for temporal degradation.

        Args:
            time_delta: Time elapsed (arbitrary units)
        """
        # Physics model: drift magnitude scales with sqrt(time) for diffusion
        k = 0.01  # Device-specific drift constant
        drift_magnitude = k * np.sqrt(max(time_delta, 0))
        self.inject_drift(drift_magnitude)

    def inject_stuck_cells(
        self,
        stuck_on: float = 0.0,
        stuck_off: float = 0.0,
        seed: Optional[int] = None,
    ) -> int:
        """Inject stuck cells into all crossbars."""
        total = 0
        total += self.R_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed)
        total += self.S_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed + 1 if seed else None)
        total += self.N_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed + 2 if seed else None)
        return total

    def set_adc_precision(self, bits: int) -> None:
        """Set ADC precision for all crossbars."""
        self.R_crossbar.set_adc_precision(bits)
        self.S_crossbar.set_adc_precision(bits)
        self.N_crossbar.set_adc_precision(bits)

    def set_dac_precision(self, bits: int) -> None:
        """Set DAC precision for all crossbars."""
        self.R_crossbar.set_dac_precision(bits)
        self.S_crossbar.set_dac_precision(bits)
        self.N_crossbar.set_dac_precision(bits)


# Fallback simulation for when CrossSim is not available
class YRSNCrossSimSimulated:
    """
    Simulated YRSNCrossSim for when CrossSim is not installed.

    Provides compatible interface with numpy-based non-ideality simulation.
    """

    def __init__(
        self,
        shape: Tuple[int, int],
        config: Optional[YRSNCrossSimConfig] = None,
    ):
        self._shape = shape
        self.config = config or YRSNCrossSimConfig()
        self._weights = np.zeros(shape, dtype=np.float64)
        self._rng = np.random.RandomState(self.config.seed)

        self._stuck_on_mask: Optional[NDArray] = None
        self._stuck_off_mask: Optional[NDArray] = None

    @property
    def shape(self) -> Tuple[int, int]:
        return self._shape

    def program(self, weights: NDArray[np.float64]) -> None:
        self._weights = weights.copy()

        if self._stuck_on_mask is not None:
            self._weights[self._stuck_on_mask] = 1.0
        if self._stuck_off_mask is not None:
            self._weights[self._stuck_off_mask] = 0.0

    def matvec(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        # DAC quantization
        if self.config.dac_bits < 16:
            x = self._quantize(x, self.config.dac_bits)

        # Matrix-vector multiply with noise
        y = self._weights @ x

        # Add read noise
        if self.config.read_noise > 0:
            noise = self._rng.normal(0, self.config.read_noise * np.abs(y).max(), y.shape)
            y = y + noise

        # Add drift
        if self.config.drift_magnitude > 0:
            drift = self._rng.normal(0, self.config.drift_magnitude, y.shape)
            y = y * (1 + drift)

        # ADC quantization
        if self.config.adc_bits < 16:
            y = self._quantize(y, self.config.adc_bits)

        return y

    def matmul(self, x: NDArray[np.float64], w: NDArray[np.float64]) -> NDArray[np.float64]:
        self.program(w)
        return self.matvec(x)

    def get_weights(self) -> NDArray[np.float64]:
        return self._weights.copy()

    def inject_noise(self, noise_level: float) -> None:
        self.config.read_noise = noise_level

    def inject_drift(self, drift_level: float) -> None:
        self.config.drift_magnitude = drift_level

    def inject_stuck_cells(
        self,
        stuck_on: float = 0.0,
        stuck_off: float = 0.0,
        seed: Optional[int] = None,
    ) -> int:
        rng = np.random.RandomState(seed or self.config.seed)
        n_cells = self._shape[0] * self._shape[1]

        n_stuck_on = int(stuck_on * n_cells)
        n_stuck_off = int(stuck_off * n_cells)

        indices = rng.permutation(n_cells)

        self._stuck_on_mask = np.zeros(self._shape, dtype=bool)
        self._stuck_off_mask = np.zeros(self._shape, dtype=bool)

        self._stuck_on_mask.flat[indices[:n_stuck_on]] = True
        self._stuck_off_mask.flat[indices[n_stuck_on:n_stuck_on + n_stuck_off]] = True

        self.program(self._weights)
        return n_stuck_on + n_stuck_off

    def set_adc_precision(self, bits: int) -> None:
        self.config.adc_bits = bits

    def set_dac_precision(self, bits: int) -> None:
        self.config.dac_bits = bits

    def _quantize(self, x: np.ndarray, bits: int) -> np.ndarray:
        if bits >= 16:
            return x

        levels = 2 ** bits
        x_min, x_max = x.min(), x.max()

        if x_max - x_min < 1e-10:
            return x

        x_norm = (x - x_min) / (x_max - x_min + 1e-10)
        x_quant = np.round(x_norm * (levels - 1)) / (levels - 1)
        return x_quant * (x_max - x_min) + x_min


class YRSNCrossSimRSNSimulated:
    """Simulated R/S/N projection matching YRSNCrossSimRSN interface."""

    def __init__(
        self,
        embed_dim: int,
        rsn_dim: int,
        config: Optional[YRSNCrossSimConfig] = None,
    ):
        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim
        self.config = config or YRSNCrossSimConfig()

        self.R_crossbar = YRSNCrossSimSimulated((rsn_dim, embed_dim), config)
        self.S_crossbar = YRSNCrossSimSimulated((rsn_dim, embed_dim), config)
        self.N_crossbar = YRSNCrossSimSimulated((rsn_dim, embed_dim), config)

        # Initialize with small random weights for simulated hardware
        # (Can be overridden with program_weights() or program_from_projection())
        rng = np.random.RandomState(config.seed if config else 42)
        W_r = rng.randn(rsn_dim, embed_dim) * 0.1
        W_s = rng.randn(rsn_dim, embed_dim) * 0.1
        W_n = rng.randn(rsn_dim, embed_dim) * 0.1
        self.R_crossbar.program(W_r)
        self.S_crossbar.program(W_s)
        self.N_crossbar.program(W_n)

    def program_from_projection(self, projection) -> None:
        heads = projection.projection_heads

        W_r = heads.R_head[0].weight.detach().cpu().numpy()
        W_s = heads.S_head[0].weight.detach().cpu().numpy()
        W_n = heads.N_head[0].weight.detach().cpu().numpy()

        self.R_crossbar.program(W_r)
        self.S_crossbar.program(W_s)
        self.N_crossbar.program(W_n)

    def program_weights(self, W_r, W_s, W_n) -> None:
        self.R_crossbar.program(W_r)
        self.S_crossbar.program(W_s)
        self.N_crossbar.program(W_n)

    def compute_rsn(self, x: np.ndarray, mint_certificate: bool = True) -> Dict[str, Any]:
        """
        Compute R/S/N through hardware crossbars with full certificate integration.

        Args:
            x: Input vector
            mint_certificate: If True, mint and validate certificate (default: True)

        Returns:
            Dict with R, S, N, alpha, omega, tau, T4 coordinates, and optional certificate
        """
        x = x.astype(np.float32)

        R_proj = self.R_crossbar.matvec(x)
        S_proj = self.S_crossbar.matvec(x)
        N_proj = self.N_crossbar.matvec(x)

        R_score = np.linalg.norm(R_proj)
        S_score = np.linalg.norm(S_proj)
        N_score = np.linalg.norm(N_proj)

        total = R_score + S_score + N_score + 1e-8
        R = R_score / total
        S = S_score / total
        N = N_score / total

        alpha = R / (R + N + 1e-8)  # Proper alpha calculation
        omega = 1.0 - N  # OOD confidence decreases with noise
        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        # INTEGRATION GAP #2: Compute T4 coordinates from hardware measurements
        from yrsn.core.decomposition.geometric_utils import compute_t4_coordinates

        t4_coords = compute_t4_coordinates(
            np.array([R]),
            np.array([S]),
            np.array([N])
        )

        result = {
            'R': float(R),
            'S': float(S),
            'N': float(N),
            'R_proj': R_proj,
            'S_proj': S_proj,
            'N_proj': N_proj,
            'alpha': float(alpha),
            'omega': float(omega),
            'tau': float(tau),
            'backend': 'yrsn_crosssim_simulated',
            # T4 coordinates (GAP #2 FIXED)
            't4_simplex_theta': float(t4_coords['simplex_theta'][0]),
            't4_phi_simplex': float(t4_coords['phi_simplex'][0]),
            't4_alpha': float(t4_coords['alpha_t4'][0]),
            't4_omega': float(t4_coords['omega_t4'][0]),
        }

        # INTEGRATION GAP #1: Mint certificate from hardware measurements
        if mint_certificate:
            import hashlib
            from yrsn.api.isa import ContextQualityISA
            from yrsn.api.certificate_validator import validate_certificate

            # Compute fingerprint from T4 coordinates
            fingerprint_str = f"{t4_coords['simplex_theta'][0]:.6f},{t4_coords['phi_simplex'][0]:.6f},{t4_coords['alpha_t4'][0]:.6f},{t4_coords['omega_t4'][0]:.6f}"
            fingerprint = hashlib.sha256(fingerprint_str.encode()).digest()[:32]

            # Mint certificate
            isa = ContextQualityISA()
            cert_dict = isa.cert_mint(
                R=R, S=S, N=N,
                alpha=alpha, omega=omega, tau=tau,
                fingerprint=fingerprint,
                enforcement={'actions': [], 'hardware_source': 'crosssim'},
                domain='hardware',
            )

            # Validate certificate (E401-E411 checks) (GAP #1 FIXED)
            validate_certificate(cert_dict)

            result['certificate'] = cert_dict
            result['certificate_valid'] = True

        return result

    def compute_rsn_batch(self, features: np.ndarray) -> Dict[str, np.ndarray]:
        batch_size = len(features)
        results = {
            'R': np.zeros(batch_size),
            'S': np.zeros(batch_size),
            'N': np.zeros(batch_size),
            'alpha': np.zeros(batch_size),
            'tau': np.zeros(batch_size),
        }

        # Disable certificate minting for batch operations (performance optimization)
        for i, x in enumerate(features):
            r = self.compute_rsn(x, mint_certificate=False)
            results['R'][i] = r['R']
            results['S'][i] = r['S']
            results['N'][i] = r['N']
            results['alpha'][i] = r['alpha']
            results['tau'][i] = r['tau']

        return results

    def inject_noise(self, noise_level: float) -> None:
        self.R_crossbar.inject_noise(noise_level)
        self.S_crossbar.inject_noise(noise_level)
        self.N_crossbar.inject_noise(noise_level)

    def inject_drift(self, drift_level: float) -> None:
        self.R_crossbar.inject_drift(drift_level)
        self.S_crossbar.inject_drift(drift_level)
        self.N_crossbar.inject_drift(drift_level)

    def apply_drift(self, time_delta: float) -> None:
        """Apply physics-based weight drift over time."""
        k = 0.01
        drift_magnitude = k * np.sqrt(max(time_delta, 0))
        self.inject_drift(drift_magnitude)

    def inject_stuck_cells(self, stuck_on=0.0, stuck_off=0.0, seed=None) -> int:
        total = 0
        total += self.R_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed)
        total += self.S_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed + 1 if seed else None)
        total += self.N_crossbar.inject_stuck_cells(stuck_on, stuck_off, seed + 2 if seed else None)
        return total

    def set_adc_precision(self, bits: int) -> None:
        self.R_crossbar.set_adc_precision(bits)
        self.S_crossbar.set_adc_precision(bits)
        self.N_crossbar.set_adc_precision(bits)

    def set_dac_precision(self, bits: int) -> None:
        self.R_crossbar.set_dac_precision(bits)
        self.S_crossbar.set_dac_precision(bits)
        self.N_crossbar.set_dac_precision(bits)


# Factory function for automatic backend selection
def create_yrsn_crosssim(
    embed_dim: int,
    rsn_dim: int,
    config: Optional[YRSNCrossSimConfig] = None,
    force_simulation: bool = False,
) -> Union[YRSNCrossSimRSN, YRSNCrossSimRSNSimulated]:
    """
    Factory function to create appropriate YRSNCrossSim backend.

    Automatically selects CrossSim or simulation based on availability.

    Args:
        embed_dim: Input embedding dimension
        rsn_dim: R/S/N projection dimension
        config: Hardware configuration
        force_simulation: Force numpy simulation even if CrossSim available

    Returns:
        YRSNCrossSimRSN or YRSNCrossSimRSNSimulated
    """
    if CROSSSIM_AVAILABLE and not force_simulation:
        return YRSNCrossSimRSN(embed_dim, rsn_dim, config)
    else:
        return YRSNCrossSimRSNSimulated(embed_dim, rsn_dim, config)


# =============================================================================
# MockCrossbar - For Unit Testing Without Simulator Overhead
# =============================================================================

class MockCrossbarRSN:
    """
    Mock implementation of ICrossbarRSN for unit testing.

    Allows testing HardwareValidator logic without CrossSim overhead.
    Returns deterministic or configurable values for testing.

    Example:
        mock = MockCrossbarRSN(embed_dim=64, rsn_dim=32)
        mock.set_alpha_distribution([0.1, 0.2, 0.8, 0.9])
        validator = HardwareValidator(mock)
        results = validator.run_validation_suite(...)
    """

    def __init__(
        self,
        embed_dim: int = 64,
        rsn_dim: int = 32,
        seed: Optional[int] = 42,
    ):
        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim
        self._rng = np.random.RandomState(seed)

        # Configurable return values
        self._alpha_values: Optional[np.ndarray] = None
        self._noise_level = 0.0
        self._drift_applied = 0.0
        self._stuck_cells = 0

        # Identity-like weights for predictable behavior
        self._W_r = np.eye(rsn_dim, embed_dim)
        self._W_s = np.eye(rsn_dim, embed_dim) * 0.5
        self._W_n = np.eye(rsn_dim, embed_dim) * 0.1

    def set_alpha_distribution(self, alphas: np.ndarray) -> None:
        """Set predetermined alpha values for testing."""
        self._alpha_values = np.array(alphas)

    def program_weights(self, W_r, W_s, W_n) -> None:
        """Mock weight programming."""
        self._W_r = W_r
        self._W_s = W_s
        self._W_n = W_n

    def program_from_projection(self, projection) -> None:
        """Mock programming from projection."""
        pass  # No-op for mock

    def compute_rsn(self, x: np.ndarray) -> Dict[str, Any]:
        """Return mock R/S/N values."""
        if self._alpha_values is not None and len(self._alpha_values) > 0:
            alpha = float(self._alpha_values[0])
        else:
            alpha = float(self._rng.random())

        R = alpha
        S = (1 - alpha) * 0.6
        N = (1 - alpha) * 0.4
        omega = 1.0
        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        return {
            'R': R,
            'S': S,
            'N': N,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
            'backend': 'mock',
        }

    def compute_rsn_batch(self, features: np.ndarray) -> Dict[str, np.ndarray]:
        """Return mock batch R/S/N values."""
        batch_size = len(features)

        if self._alpha_values is not None:
            alpha = self._alpha_values[:batch_size]
            if len(alpha) < batch_size:
                # Pad with random values if needed
                pad = self._rng.random(batch_size - len(alpha))
                alpha = np.concatenate([alpha, pad])
        else:
            alpha = self._rng.random(batch_size)

        R = alpha
        S = (1 - alpha) * 0.6
        N = (1 - alpha) * 0.4

        return {
            'R': R,
            'S': S,
            'N': N,
            'alpha': alpha,
            'tau': 1.0 / np.maximum(alpha, 0.01),
        }

    def apply_drift(self, time_delta: float) -> None:
        """Track drift application for testing."""
        self._drift_applied += time_delta

    def inject_noise(self, noise_level: float) -> None:
        """Track noise injection for testing."""
        self._noise_level = noise_level

    def inject_drift(self, drift_level: float) -> None:
        """Track drift injection for testing."""
        self._drift_applied = drift_level

    def inject_stuck_cells(self, stuck_on=0.0, stuck_off=0.0, seed=None) -> int:
        """Track stuck cell injection for testing."""
        n_cells = self.rsn_dim * self.embed_dim * 3
        self._stuck_cells = int((stuck_on + stuck_off) * n_cells)
        return self._stuck_cells

    def set_adc_precision(self, bits: int) -> None:
        """No-op for mock."""
        pass

    def set_dac_precision(self, bits: int) -> None:
        """No-op for mock."""
        pass

    # Test inspection methods
    def get_drift_applied(self) -> float:
        """Get total drift applied (for test assertions)."""
        return self._drift_applied

    def get_noise_level(self) -> float:
        """Get current noise level (for test assertions)."""
        return self._noise_level

    def get_stuck_cells(self) -> int:
        """Get number of stuck cells (for test assertions)."""
        return self._stuck_cells
