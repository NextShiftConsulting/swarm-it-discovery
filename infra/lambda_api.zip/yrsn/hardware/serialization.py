"""
Numpy-safe serialization for memristor state persistence.

Handles numpy arrays, lists, and nested dicts for JSON/msgpack serialization.
Supports multiple backends:
- JSON (human-readable, portable)
- Pickle (fast, full numpy support)
- Msgpack (compact, fast, portable)

Usage:
    from yrsn.hardware.serialization import (
        save_memristor_state,
        load_memristor_state,
    )

    # Save to file
    save_memristor_state(projection.save_state(), "checkpoint.bin")

    # Load from file
    state = load_memristor_state("checkpoint.bin")
    projection.load_state(state)
"""

import json
import pickle
import gzip
from pathlib import Path
from typing import Dict, Any, Union, Optional
from datetime import datetime

# Try to import msgpack (optional but preferred)
try:
    import msgpack
    import msgpack_numpy as m
    m.patch()  # Monkey-patch msgpack for numpy support
    MSGPACK_AVAILABLE = True
except ImportError:
    MSGPACK_AVAILABLE = False

# numpy is required
import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy arrays and types."""

    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return {
                "__numpy__": True,
                "dtype": str(obj.dtype),
                "shape": obj.shape,
                "data": obj.tolist(),
            }
        if isinstance(obj, (np.integer, np.int64, np.int32)):
            return int(obj)
        if isinstance(obj, (np.floating, np.float64, np.float32)):
            return float(obj)
        if isinstance(obj, np.bool_):
            return bool(obj)
        return super().default(obj)


def numpy_decoder(obj: Dict) -> Any:
    """JSON decoder hook for numpy arrays."""
    if isinstance(obj, dict) and obj.get("__numpy__"):
        return np.array(obj["data"], dtype=obj["dtype"]).reshape(obj["shape"])
    return obj


def _convert_numpy_for_json(obj: Any) -> Any:
    """Recursively convert numpy types for JSON serialization."""
    if isinstance(obj, np.ndarray):
        return {
            "__numpy__": True,
            "dtype": str(obj.dtype),
            "shape": list(obj.shape),
            "data": obj.tolist(),
        }
    if isinstance(obj, (np.integer, np.int64, np.int32)):
        return int(obj)
    if isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, dict):
        return {k: _convert_numpy_for_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_numpy_for_json(v) for v in obj]
    return obj


def _restore_numpy_from_json(obj: Any) -> Any:
    """Recursively restore numpy arrays from JSON-decoded dict."""
    if isinstance(obj, dict):
        if obj.get("__numpy__"):
            return np.array(obj["data"], dtype=obj["dtype"]).reshape(obj["shape"])
        return {k: _restore_numpy_from_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_restore_numpy_from_json(v) for v in obj]
    return obj


def save_memristor_state(
    state: Dict[str, Any],
    path: Union[str, Path],
    format: str = "auto",
    compress: bool = True,
    metadata: Optional[Dict[str, Any]] = None,
) -> Path:
    """
    Save memristor state to file with numpy support.

    Args:
        state: State dict from save_state()
        path: Output file path
        format: "auto", "json", "pickle", or "msgpack"
        compress: Whether to gzip compress (default True)
        metadata: Optional metadata (timestamp, version, etc.)

    Returns:
        Path to saved file
    """
    path = Path(path)

    # Auto-detect format from extension
    if format == "auto":
        suffix = path.suffix.lower()
        if suffix in (".json", ".json.gz"):
            format = "json"
        elif suffix in (".msgpack", ".msg", ".msgpack.gz"):
            format = "msgpack"
        else:
            format = "pickle"

    # Add metadata wrapper
    wrapped = {
        "version": "1.0",
        "format": format,
        "timestamp": datetime.utcnow().isoformat(),
        "state": state,
    }
    if metadata:
        wrapped["metadata"] = metadata

    # Serialize based on format
    if format == "json":
        # Convert numpy for JSON
        json_safe = _convert_numpy_for_json(wrapped)
        data = json.dumps(json_safe, indent=2).encode("utf-8")

    elif format == "msgpack":
        if not MSGPACK_AVAILABLE:
            raise ImportError(
                "msgpack-python and msgpack-numpy required: "
                "pip install msgpack-python msgpack-numpy"
            )
        data = msgpack.packb(wrapped, use_bin_type=True)

    else:  # pickle
        data = pickle.dumps(wrapped, protocol=pickle.HIGHEST_PROTOCOL)

    # Compress if requested
    if compress:
        data = gzip.compress(data)
        if not path.suffix.endswith(".gz"):
            path = path.with_suffix(path.suffix + ".gz")

    # Write to file
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

    return path


def load_memristor_state(
    path: Union[str, Path],
    format: str = "auto",
) -> Dict[str, Any]:
    """
    Load memristor state from file.

    Args:
        path: Input file path
        format: "auto", "json", "pickle", or "msgpack"

    Returns:
        State dict for load_state()
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Memristor state file not found: {path}")

    # Read raw data
    data = path.read_bytes()

    # Decompress if gzipped
    if path.suffix == ".gz" or data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)

    # Auto-detect format
    if format == "auto":
        # Try to detect from file extension (without .gz)
        stem = path.stem if path.suffix == ".gz" else path.name
        if stem.endswith(".json"):
            format = "json"
        elif stem.endswith((".msgpack", ".msg")):
            format = "msgpack"
        elif stem.endswith((".pkl", ".pickle")):
            format = "pickle"
        else:
            # Try to auto-detect from content
            if data[:1] == b"{":
                format = "json"
            elif data[:2] == b"\x80\x05" or data[:2] == b"\x80\x04":
                # Pickle protocol 4 or 5
                format = "pickle"
            elif MSGPACK_AVAILABLE and data[:1] in (b"\x81", b"\x82", b"\x83", b"\x84", b"\x85"):
                # msgpack fixmap markers (not 0x80 which conflicts with pickle)
                format = "msgpack"
            else:
                # Default to pickle for unknown binary formats
                format = "pickle"

    # Deserialize
    if format == "json":
        wrapped = json.loads(data.decode("utf-8"))
        wrapped = _restore_numpy_from_json(wrapped)

    elif format == "msgpack":
        if not MSGPACK_AVAILABLE:
            raise ImportError(
                "msgpack-python and msgpack-numpy required: "
                "pip install msgpack-python msgpack-numpy"
            )
        wrapped = msgpack.unpackb(data, raw=False)

    else:  # pickle
        wrapped = pickle.loads(data)

    # Handle versioned format
    if isinstance(wrapped, dict) and "version" in wrapped and "state" in wrapped:
        return wrapped["state"]

    # Legacy format (just the state dict)
    return wrapped


def get_state_info(path: Union[str, Path]) -> Dict[str, Any]:
    """
    Get metadata about a saved state file without loading full state.

    Args:
        path: Input file path

    Returns:
        Dict with version, timestamp, format, and size info
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Memristor state file not found: {path}")

    info = {
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
    }

    # Try to peek at header for version info
    try:
        data = path.read_bytes()
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data[:1024])  # Just decompress header
            info["compressed"] = True
        else:
            data = data[:1024]
            info["compressed"] = False

        if data[:1] == b"{":
            # JSON - parse just enough to get metadata
            partial = json.loads(data.decode("utf-8", errors="ignore").split('"state"')[0] + "}")
            info["format"] = "json"
            info["version"] = partial.get("version", "unknown")
            info["timestamp"] = partial.get("timestamp", "unknown")
        else:
            info["format"] = "binary"
    except Exception:
        info["format"] = "unknown"

    return info


__all__ = [
    "save_memristor_state",
    "load_memristor_state",
    "get_state_info",
    "NumpyEncoder",
    "MSGPACK_AVAILABLE",
]
