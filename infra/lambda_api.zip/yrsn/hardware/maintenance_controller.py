"""
YRSN Hardware Maintenance Controller

Certificate-Directed Hardware Health Management using the 6D YRSN Signal:
- R (Relevant): Semantic content preserved
- S (Superfluous): Redundant computation acceptable
- N (Noise): Hardware degradation indicator ← PRIMARY HEALTH SIGNAL
- α (alpha): Quality/reliability metric
- ω (omega): In-distribution confidence
- τ (tau): Plasticity/learning rate modulator

The YRSN certificate IS the health signal. This controller doesn't just
use MCC/Jaccard - it uses the certificate to drive maintenance decisions:

1. N rising → Hardware degradation detected
2. α dropping → Quality below threshold, needs refresh
3. τ high → Aggressive refresh (high uncertainty)
4. ω low → Out-of-distribution, may need recalibration

MCC/Jaccard serve as SECONDARY validation, not primary drivers.

Architecture:
    YRSNCertificate → MaintenanceController → ICrossbarRSN
         ↑                                          ↓
    AdvancedStats ←──────── Validation ←───────────┘
"""

import numpy as np
from typing import Dict, Any, Optional, List, Tuple, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from yrsn.core.certificate import YRSNCertificate
from yrsn.hardware.yrsn_crosssim import (
    YRSNCrossSimConfig,
    YRSNCrossSimRSN,
    YRSNCrossSimRSNSimulated,
    create_yrsn_crosssim,
)


class HealthStatus(Enum):
    """Hardware health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    CRITICAL = "critical"
    REFRESH_NEEDED = "refresh_needed"


# YRSNCertificate is imported from yrsn.core.certificate
# It provides the 6D signal (R, S, N, alpha, omega, tau) plus oracle-free helpers


@dataclass
class TileHealthReport:
    """Health report for a single crossbar tile."""
    tile_id: int
    status: HealthStatus
    certificate: YRSNCertificate

    # YRSN-derived health signals
    n_baseline: float  # Expected N for healthy hardware
    n_current: float   # Current N value
    n_delta: float     # Deviation from baseline

    alpha_threshold: float  # Minimum acceptable alpha
    alpha_current: float    # Current alpha

    # Secondary metrics (validation only)
    mcc: Optional[float] = None
    jaccard: Optional[float] = None

    # Recommendations
    refresh_recommended: bool = False
    refresh_urgency: float = 0.0  # 0-1, tau-modulated

    # INTEGRATION GAP #3: UnifiedEnforcementEngine results
    enforcement_authorized: Optional[bool] = None  # True if execution authorized
    enforcement_gear: Optional[str] = None  # Current gearbox gear
    enforcement_failure_code: Optional[str] = None  # E-code if blocked

    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class MaintenanceAction:
    """Action taken by the maintenance controller."""
    tile_id: int
    action: str  # "refresh", "recalibrate", "none", "emergency_stop"
    reason: str
    certificate_at_action: YRSNCertificate
    metrics: Dict[str, float]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class YRSNMaintenanceController:
    """
    YRSN Certificate-Directed Hardware Maintenance Controller.

    The key insight: The YRSN certificate itself tells us hardware health.
    - N component rises with degradation
    - alpha drops when quality degrades
    - tau modulates how aggressively we should respond

    This is NOT just a generic metrics-based controller. The 6D certificate
    IS the health signal that drives maintenance decisions.

    Example:
        controller = YRSNMaintenanceController(crossbar)
        controller.calibrate_baseline(calibration_features)

        # During operation
        report = controller.check_health(current_features)
        if report.refresh_recommended:
            controller.execute_refresh(report.tile_id)
    """

    def __init__(
        self,
        crossbar: Union[YRSNCrossSimRSN, YRSNCrossSimRSNSimulated],
        # YRSN Certificate Thresholds (PRIMARY)
        n_threshold: float = 0.15,       # N above this = degraded
        n_critical: float = 0.25,        # N above this = critical
        alpha_threshold: float = 0.5,    # alpha below this = degraded
        alpha_critical: float = 0.3,     # alpha below this = critical
        omega_threshold: float = 0.3,    # omega below this = OOD warning
        # Secondary Validation (NOT primary drivers)
        mcc_threshold: float = 0.4,      # For validation only
        jaccard_threshold: float = 0.3,  # For validation only
        # Control parameters
        tau_scaling: bool = True,        # Use tau to modulate refresh urgency
        # INTEGRATION GAP #3: Enforcement engine integration
        enforcement_engine: Optional[Any] = None,  # UnifiedEnforcementEngine instance
    ):
        """
        Initialize YRSN-directed maintenance controller.

        Args:
            crossbar: ICrossbarRSN-compliant hardware adapter
            n_threshold: N component threshold for degradation detection
            n_critical: N component threshold for critical status
            alpha_threshold: Minimum acceptable quality
            alpha_critical: Quality level requiring immediate action
            omega_threshold: OOD detection threshold
            mcc_threshold: Secondary MCC validation threshold
            jaccard_threshold: Secondary Jaccard validation threshold
            tau_scaling: Whether to use tau to modulate refresh urgency
        """
        self.crossbar = crossbar

        # YRSN thresholds (PRIMARY control signals)
        self.n_threshold = n_threshold
        self.n_critical = n_critical
        self.alpha_threshold = alpha_threshold
        self.alpha_critical = alpha_critical
        self.omega_threshold = omega_threshold

        # INTEGRATION GAP #3 FIX: Link to enforcement engine
        self.enforcement_engine = enforcement_engine

        # Secondary thresholds (validation only)
        self.mcc_threshold = mcc_threshold
        self.jaccard_threshold = jaccard_threshold

        self.tau_scaling = tau_scaling

        # Baseline calibration
        self._n_baseline: Optional[float] = None
        self._alpha_baseline: Optional[float] = None
        self._calibrated: bool = False

        # Logging
        self.health_history: List[TileHealthReport] = []
        self.action_log: List[MaintenanceAction] = []

    def calibrate_baseline(
        self,
        calibration_features: np.ndarray,
        n_iterations: int = 5,
    ) -> Dict[str, float]:
        """
        Establish YRSN baseline from healthy hardware.

        This captures what the 6D certificate looks like when
        hardware is functioning correctly.

        Args:
            calibration_features: Known-good input features
            n_iterations: Number of calibration passes

        Returns:
            Baseline certificate statistics
        """
        print("Calibrating YRSN baseline...")

        n_values = []
        alpha_values = []

        for i in range(n_iterations):
            rsn = self.crossbar.compute_rsn_batch(calibration_features)
            n_values.extend(rsn['N'].tolist())
            alpha_values.extend(rsn['alpha'].tolist())

        self._n_baseline = float(np.mean(n_values))
        self._alpha_baseline = float(np.mean(alpha_values))
        self._calibrated = True

        baseline = {
            'n_baseline': self._n_baseline,
            'n_std': float(np.std(n_values)),
            'alpha_baseline': self._alpha_baseline,
            'alpha_std': float(np.std(alpha_values)),
            'n_samples': len(n_values),
        }

        # FIX BUG #2: Propagate baseline to enforcement engine
        # Changed to comply with P6 (Early Warning Through Trajectory) and P11 (Experimental Rigor)
        # Baseline propagation enables trajectory tracking for drift detection
        if self.enforcement_engine is not None:
            # Create baseline DecompositionScore for drift monitoring
            from yrsn.core.decomposition import DecompositionScore

            # Compute T4 coordinates for baseline
            # Use first few samples to get average R, S values
            baseline_r_values = []
            baseline_s_values = []
            for i in range(min(5, len(calibration_features))):
                single_result = self.crossbar.compute_rsn(
                    calibration_features[i] if calibration_features.ndim > 1 else calibration_features,
                    mint_certificate=False
                )
                baseline_r_values.append(single_result['R'])
                baseline_s_values.append(single_result['S'])

            baseline_score = DecompositionScore(
                relevant=float(np.mean(baseline_r_values)),
                superfluous=float(np.mean(baseline_s_values)),
                noise=self._n_baseline,
                quality_prior=self._alpha_baseline,
                omega=1.0,
                computation_method='hardware_baseline'
            )

            # If T4 coords available, add them
            if hasattr(baseline_score, 't4_simplex_theta') and baseline_score.t4_simplex_theta is not None:
                print(f"  Baseline T4: θ={baseline_score.t4_simplex_theta:.1f}°")

            # Set baseline in enforcement engine
            self.enforcement_engine.set_baseline(baseline_score)
            print(f"  [OK] Baseline propagated to enforcement engine")

        print(f"  N baseline: {self._n_baseline:.4f} +/- {baseline['n_std']:.4f}")
        print(f"  alpha baseline: {self._alpha_baseline:.4f} +/- {baseline['alpha_std']:.4f}")

        return baseline

    def compute_certificate(
        self,
        features: np.ndarray,
    ) -> YRSNCertificate:
        """
        Compute YRSN 6D certificate for input features.

        This certificate IS the health signal.
        """
        rsn = self.crossbar.compute_rsn_batch(features)

        return YRSNCertificate(
            R=float(np.mean(rsn['R'])),
            S=float(np.mean(rsn['S'])),
            N=float(np.mean(rsn['N'])),
            alpha=float(np.mean(rsn['alpha'])),
            omega=1.0,  # Default, would come from OOD detector
            tau=float(np.mean(rsn['tau'])),
        )

    def check_health(
        self,
        features: np.ndarray,
        tile_id: int = 0,
        ground_truth_errors: Optional[np.ndarray] = None,
    ) -> TileHealthReport:
        """
        Check hardware health using YRSN certificate.

        The certificate drives the health assessment:
        - N rising above baseline → degradation
        - alpha dropping below threshold → quality issue
        - tau high → high uncertainty, aggressive refresh

        Args:
            features: Input features to evaluate
            tile_id: Which tile to check
            ground_truth_errors: Optional ground truth for secondary validation

        Returns:
            TileHealthReport with YRSN-directed assessment
        """
        if not self._calibrated:
            raise RuntimeError("Must call calibrate_baseline() first")

        # Handle 1D feature vectors (single sample)
        if features.ndim == 1:
            features = features.reshape(1, -1)

        # Compute current YRSN certificate
        cert = self.compute_certificate(features)

        # PRIMARY HEALTH SIGNAL: N deviation from baseline
        n_delta = cert.N - self._n_baseline

        # Determine status based on YRSN signals
        if cert.N > self.n_critical or cert.alpha < self.alpha_critical:
            status = HealthStatus.CRITICAL
            refresh_recommended = True
        elif cert.N > self.n_threshold or cert.alpha < self.alpha_threshold:
            status = HealthStatus.DEGRADED
            refresh_recommended = True
        else:
            status = HealthStatus.HEALTHY
            refresh_recommended = False

        # Tau-modulated urgency (YRSN insight: high tau = high uncertainty)
        if self.tau_scaling:
            # tau typically in range [1, 10], normalize to [0, 1]
            urgency = min(1.0, (cert.tau - 1.0) / 9.0)
            # Weight by N deviation
            urgency = urgency * (n_delta / self.n_critical) if n_delta > 0 else 0.0
        else:
            urgency = 1.0 if refresh_recommended else 0.0

        # Secondary validation (optional, not primary driver)
        mcc, jaccard = None, None
        if ground_truth_errors is not None:
            from series_003.hardware_validators import AdvancedStatistics
            rsn = self.crossbar.compute_rsn_batch(features)
            stats = AdvancedStatistics.run_validation_suite(
                rsn['alpha'], ground_truth_errors
            )
            mcc = stats.get('mcc')
            jaccard = stats.get('jaccard_index')

            # Secondary validation can escalate (but not de-escalate)
            if mcc is not None and mcc < self.mcc_threshold:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                refresh_recommended = True

        # INTEGRATION GAP #3 FIX: Run enforcement if engine available
        enforcement_authorized = None
        enforcement_gear = None
        enforcement_failure_code = None

        if self.enforcement_engine is not None:
            from yrsn.core.enforcement import UnifiedEnforcementEngine
            from yrsn.core.decomposition import DecompositionScore

            # FIX BUG #1: Create current_score with T4 coordinates for drift detection
            # Changed to comply with P13 (Certificate as Port) and P1 (Measurement-Signal-Control)
            # Certificate must carry ALL context for enforcement (T⁴ coordinates for drift monitoring)
            # Compute single sample to get T4 coords
            if features.ndim == 1:
                single_input = features
            else:
                single_input = features[0]  # Use first sample

            single_result = self.crossbar.compute_rsn(single_input, mint_certificate=False)

            # Create DecompositionScore for drift monitoring
            current_score = DecompositionScore(
                relevant=single_result['R'],
                superfluous=single_result['S'],
                noise=single_result['N'],
                quality_prior=single_result['alpha'],
                omega=single_result.get('omega', 1.0),
                computation_method='hardware',
                # T4 coordinates for drift detection
                t4_simplex_theta=single_result.get('t4_simplex_theta'),
                t4_phi_simplex=single_result.get('t4_phi_simplex'),
                t4_alpha=single_result.get('t4_alpha'),
                t4_omega=single_result.get('t4_omega'),
            )

            # Now drift monitoring will actually run!
            result = self.enforcement_engine.enforce_certificate(
                cert,
                current_score=current_score  # FIX: Pass score for drift detection
            )

            enforcement_authorized = result.authorized
            enforcement_gear = result.current_gear.value if result.current_gear else None
            enforcement_failure_code = result.failure_code

            # Enforcement can escalate health status
            if not result.authorized:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                refresh_recommended = True

        report = TileHealthReport(
            tile_id=tile_id,
            status=status,
            certificate=cert,
            n_baseline=self._n_baseline,
            n_current=cert.N,
            n_delta=n_delta,
            alpha_threshold=self.alpha_threshold,
            alpha_current=cert.alpha,
            mcc=mcc,
            jaccard=jaccard,
            refresh_recommended=refresh_recommended,
            refresh_urgency=float(urgency),
            # INTEGRATION GAP #3: Add enforcement results
            enforcement_authorized=enforcement_authorized,
            enforcement_gear=enforcement_gear,
            enforcement_failure_code=enforcement_failure_code,
        )

        self.health_history.append(report)
        return report

    def execute_refresh(
        self,
        tile_id: int,
        method: str = "reprogram",
    ) -> MaintenanceAction:
        """
        Execute hardware refresh for a tile.

        Refresh strategy is modulated by current certificate:
        - High tau → aggressive refresh
        - Low alpha → full reprogram
        - Moderate degradation → partial refresh
        """
        # Get current certificate before action
        # (In real system, would use cached value)
        cert = self.compute_certificate(
            np.random.randn(10, self.crossbar.embed_dim)  # Placeholder
        )

        # Determine refresh strategy based on certificate
        if cert.alpha < self.alpha_critical:
            action_type = "emergency_reprogram"
            reason = f"Critical alpha ({cert.alpha:.3f}) below threshold"
        elif cert.N > self.n_critical:
            action_type = "full_refresh"
            reason = f"Critical N ({cert.N:.3f}) above threshold"
        elif cert.tau > 5.0:
            action_type = "aggressive_refresh"
            reason = f"High tau ({cert.tau:.2f}) indicates high uncertainty"
        else:
            action_type = "standard_refresh"
            reason = "Routine maintenance"

        # Execute refresh on crossbar
        # In real implementation, this would reprogram the tile
        print(f"🔧 Executing {action_type} on tile {tile_id}: {reason}")

        # Reset noise/drift (simulated refresh)
        self.crossbar.inject_noise(0.0)
        self.crossbar.inject_drift(0.0)

        action = MaintenanceAction(
            tile_id=tile_id,
            action=action_type,
            reason=reason,
            certificate_at_action=cert,
            metrics={
                'N': cert.N,
                'alpha': cert.alpha,
                'tau': cert.tau,
                'n_baseline': self._n_baseline,
            }
        )

        self.action_log.append(action)
        return action

    def monitor_and_heal(
        self,
        features: np.ndarray,
        ground_truth_errors: Optional[np.ndarray] = None,
        auto_refresh: bool = True,
    ) -> List[TileHealthReport]:
        """
        YRSN-directed monitoring and healing loop.

        The YRSN certificate drives all decisions:
        1. Check N component (degradation signal)
        2. Check alpha (quality signal)
        3. Use tau to modulate refresh urgency
        4. Validate with MCC/Jaccard if ground truth available

        Args:
            features: Input features to monitor
            ground_truth_errors: Optional ground truth for validation
            auto_refresh: Whether to automatically refresh degraded tiles

        Returns:
            List of health reports for all tiles
        """
        reports = []

        # In multi-tile system, would iterate over tiles
        # For now, treat as single tile
        tile_id = 0

        report = self.check_health(
            features, tile_id, ground_truth_errors
        )
        reports.append(report)

        # YRSN-directed output
        status_emoji = {
            HealthStatus.HEALTHY: "✅",
            HealthStatus.DEGRADED: "⚠️",
            HealthStatus.CRITICAL: "🚨",
            HealthStatus.REFRESH_NEEDED: "🔧",
        }

        print(f"\n{status_emoji[report.status]} Tile {tile_id}: {report.status.value}")
        print(f"   YRSN Certificate:")
        print(f"     N: {report.certificate.N:.4f} (baseline: {report.n_baseline:.4f}, Δ: {report.n_delta:+.4f})")
        print(f"     α: {report.certificate.alpha:.4f} (threshold: {report.alpha_threshold:.2f})")
        print(f"     τ: {report.certificate.tau:.2f}")

        if report.mcc is not None:
            print(f"   Validation: MCC={report.mcc:.3f}, Jaccard={report.jaccard:.3f}")

        if report.refresh_recommended:
            print(f"   Refresh urgency: {report.refresh_urgency:.2%}")

            if auto_refresh:
                self.execute_refresh(tile_id)

        return reports

    def get_health_summary(self) -> Dict[str, Any]:
        """Get summary of health history."""
        if not self.health_history:
            return {'status': 'no_data'}

        recent = self.health_history[-10:]

        return {
            'total_checks': len(self.health_history),
            'total_refreshes': len(self.action_log),
            'recent_n_mean': np.mean([r.n_current for r in recent]),
            'recent_alpha_mean': np.mean([r.alpha_current for r in recent]),
            'recent_status': recent[-1].status.value,
            'baseline_n': self._n_baseline,
            'baseline_alpha': self._alpha_baseline,
        }


def create_maintenance_controller(
    projection,
    config: Optional[YRSNCrossSimConfig] = None,
    **kwargs,
) -> YRSNMaintenanceController:
    """
    Factory function to create YRSN maintenance controller.

    Args:
        projection: TrainedRSNProjection instance
        config: Optional hardware configuration
        **kwargs: Additional arguments for controller

    Returns:
        Configured YRSNMaintenanceController
    """
    # Get dimensions from projection
    heads = projection.projection_heads
    embed_dim = heads.R_head[0].weight.shape[1]
    rsn_dim = heads.R_head[0].weight.shape[0]

    # Create crossbar
    crossbar = create_yrsn_crosssim(embed_dim, rsn_dim, config)
    crossbar.program_from_projection(projection)

    return YRSNMaintenanceController(crossbar, **kwargs)
