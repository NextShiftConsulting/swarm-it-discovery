"""
YRSN Hardware Module - Hardware-faithful implementations.

**📖 UNIFIED DOCUMENTATION:** See `docs/GENERATORS_UNIFIED_GUIDE.md` for complete guide to all generators and simulators.

This module provides hardware-faithful implementations of YRSN concepts:
- Memristor crossbar arrays for R/S/N projection
- Quantized bit-slicing for efficient computation
- Temperature-modulated plasticity
- CrossSim integration for validated hardware simulation
- ADAPTIVE CALIBRATION - learns parameters from data (no hardcoding!)

These implementations bridge the gap from "hardware-inspired naming"
to "hardware-faithful implementation" that could eventually be validated
on actual neuromorphic hardware.

Adaptive Calibration (NEW):
    from yrsn.hardware import discover_optimal_config
    config = discover_optimal_config(X_train, targets)  # Learns from data!
    proj = YRSNMemristorProjection(config)

CrossSim Integration:
    pip install git+https://github.com/sandialabs/cross-sim.git

    from yrsn.hardware import CrossSimProjection, CrossSimConfig
    proj = CrossSimProjection(CrossSimConfig(embed_dim=768, rsn_dim=256))
    result = proj.forward(embedding)
"""

from .memristor_projection import (
    # Configuration
    MemristorConfig,
    YRSNMemristorConfig,
    # Core components
    VirtualMemristor,
    MemristorArray,
    # YRSN projections
    YRSNMemristorProjection,
    BitSlicedMemristorProjection,
    # Utilities
    quantize_embedding,
    dequantize_embedding,
)

# Torch-native device-aware implementations (GPU-accelerated)
from .memristor_projection_torch import (
    TorchMemristorConfig,
    TorchYRSNMemristorConfig,
    TorchMemristorArray,
    TorchYRSNMemristorProjection,
    TorchBitSlicedMemristorProjection,
    create_projection,
)

# Serialization for numpy-safe state persistence
from .serialization import (
    save_memristor_state,
    load_memristor_state,
    get_state_info,
)

# Adaptive calibration - learns parameters from data
from .adaptive_calibration import (
    AdaptiveMemristorCalibrator,
    CalibrationResult,
    RuntimeCalibrator,
    discover_optimal_config,
    quick_calibrate,
    # RSN_DIM presets (not adaptive - compute/capacity tradeoff)
    get_rsn_dim,
    RSN_DIM_PRESETS,
)

# CrossSim adapter (optional dependency)
try:
    from .crosssim_adapter import (
        CrossSimConfig,
        CrossSimProjection,
        CrossSimBitSlicedProjection,
        CROSSSIM_AVAILABLE,
    )
except ImportError:
    CROSSSIM_AVAILABLE = False
    CrossSimConfig = None
    CrossSimProjection = None
    CrossSimBitSlicedProjection = None

# YRSNCrossSim - Hexagonal architecture adapter (ICrossbar compliant)
from .yrsn_crosssim import (
    YRSNCrossSimConfig,
    YRSNCrossSim,
    YRSNCrossSimRSN,
    YRSNCrossSimSimulated,
    YRSNCrossSimRSNSimulated,
    create_yrsn_crosssim,
    MockCrossbarRSN,  # For unit testing
)

# YRSN-directed hardware maintenance (Certificate-in-the-loop)
from .maintenance_controller import (
    YRSNMaintenanceController,
    TileHealthReport,
    MaintenanceAction,
    HealthStatus,
    create_maintenance_controller,
)
# YRSNCertificate is the canonical certificate from yrsn.core
from yrsn.core.certificate import YRSNCertificate

# Quantized CNN to Memristor adapter
from .quantized_cnn_memristor import (
    QuantizationConfig,
    QuantizationScheme,
    ConductanceMappingConfig,
    WeightToConductanceMapper,
    PulseProgrammer,
    QuantizedConv2dMemristor,
    TinyDenoisingCNN,
    YRSNQualityAwareDenoiser,
    create_denoising_model,
    # Backend selection
    MemristorBackend,
    # YRSN Signal Integration
    YRSNDenoisingSignal,
    YRSNDenoisingAdapter,
)

__all__ = [
    # Built-in memristor simulation (numpy-based, legacy)
    'MemristorConfig',
    'YRSNMemristorConfig',
    'VirtualMemristor',
    'MemristorArray',
    'YRSNMemristorProjection',
    'BitSlicedMemristorProjection',
    'quantize_embedding',
    'dequantize_embedding',
    # Torch-native device-aware (GPU-accelerated, recommended)
    'TorchMemristorConfig',
    'TorchYRSNMemristorConfig',
    'TorchMemristorArray',
    'TorchYRSNMemristorProjection',
    'TorchBitSlicedMemristorProjection',
    'create_projection',
    # Numpy-safe serialization for state persistence
    'save_memristor_state',
    'load_memristor_state',
    'get_state_info',
    # Adaptive calibration (learns from data!)
    'AdaptiveMemristorCalibrator',
    'CalibrationResult',
    'RuntimeCalibrator',
    'discover_optimal_config',
    'quick_calibrate',
    # RSN_DIM presets (compute/capacity tradeoff)
    'get_rsn_dim',
    'RSN_DIM_PRESETS',
    # CrossSim integration (optional)
    'CROSSSIM_AVAILABLE',
    'CrossSimConfig',
    'CrossSimProjection',
    'CrossSimBitSlicedProjection',
    # YRSNCrossSim - Hexagonal architecture adapter
    'YRSNCrossSimConfig',
    'YRSNCrossSim',
    'YRSNCrossSimRSN',
    'YRSNCrossSimSimulated',
    'YRSNCrossSimRSNSimulated',
    'create_yrsn_crosssim',
    'MockCrossbarRSN',  # For unit testing
    # YRSN-directed maintenance controller
    'YRSNMaintenanceController',
    'YRSNCertificate',
    'TileHealthReport',
    'MaintenanceAction',
    'HealthStatus',
    'create_maintenance_controller',
    # Quantized CNN to Memristor adapter
    'QuantizationConfig',
    'QuantizationScheme',
    'ConductanceMappingConfig',
    'WeightToConductanceMapper',
    'PulseProgrammer',
    'QuantizedConv2dMemristor',
    'TinyDenoisingCNN',
    'YRSNQualityAwareDenoiser',
    'create_denoising_model',
    # Backend selection
    'MemristorBackend',
    # YRSN Signal Integration
    'YRSNDenoisingSignal',
    'YRSNDenoisingAdapter',
]
