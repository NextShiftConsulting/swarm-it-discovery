"""
CrossSim Adapter - Bridge YRSN memristor projection to Sandia's CrossSim.

**📖 UNIFIED DOCUMENTATION:** See `docs/GENERATORS_UNIFIED_GUIDE.md` for complete guide to all generators and simulators.

CrossSim provides validated hardware simulation including:
- Device non-idealities (programming errors, drift, noise)
- Parasitic resistances
- ADC precision loss
- Bit-slicing support

This adapter allows running YRSNMemristorProjection on CrossSim's
validated analog hardware simulator.

Requirements:
    pip install git+https://github.com/sandialabs/cross-sim.git
"""

from typing import Optional, Dict, Any, List, Union
from pathlib import Path
import numpy as np

try:
    from simulator import AnalogCore, CrossSimParameters
    CROSSSIM_AVAILABLE = True
except ImportError:
    CROSSSIM_AVAILABLE = False
    AnalogCore = None
    CrossSimParameters = None


def check_crosssim():
    """Check if CrossSim is available."""
    if not CROSSSIM_AVAILABLE:
        raise ImportError(
            "CrossSim not installed. Install with:\n"
            "  pip install git+https://github.com/sandialabs/cross-sim.git"
        )


class CrossSimConfig:
    """Configuration for CrossSim-backed projection."""

    def __init__(
        self,
        embed_dim: int = 768,
        rsn_dim: int = 256,
        # Device parameters
        weight_bits: int = 8,
        adc_bits: int = 8,
        dac_bits: int = 8,
        # Non-idealities
        programming_error: float = 0.0,  # 0-1, fraction of range
        read_noise: float = 0.0,         # 0-1, fraction of signal
        drift_enabled: bool = False,
    ):
        self.embed_dim = embed_dim
        self.rsn_dim = rsn_dim
        self.weight_bits = weight_bits
        self.adc_bits = adc_bits
        self.dac_bits = dac_bits
        self.programming_error = programming_error
        self.read_noise = read_noise
        self.drift_enabled = drift_enabled


class CrossSimProjection:
    """
    YRSN R/S/N projection using CrossSim's validated hardware simulator.

    Three AnalogCore arrays simulate memristor crossbars for R/S/N projection.
    Supports configurable non-idealities for realistic hardware modeling.
    """

    def __init__(self, config: Optional[CrossSimConfig] = None):
        check_crosssim()

        self.config = config or CrossSimConfig()

        # CrossSim parameters
        self.params = CrossSimParameters()

        # Configure non-idealities if specified
        # Valid models: NormalIndependentDevice, NormalProportionalDevice,
        # UniformIndependentDevice, PCMJoshi, RRAMMilo, RRAMWan, SONOS, IdealDevice
        if self.config.programming_error > 0:
            self.params.xbar.device.programming_error.enable = True
            self.params.xbar.device.programming_error.magnitude = self.config.programming_error
            self.params.xbar.device.programming_error.model = "NormalProportionalDevice"

        if self.config.read_noise > 0:
            self.params.xbar.device.read_noise.enable = True
            self.params.xbar.device.read_noise.magnitude = self.config.read_noise
            self.params.xbar.device.read_noise.model = "NormalProportionalDevice"

        if self.config.drift_enabled:
            self.params.xbar.device.drift_error.enable = True
            self.params.xbar.device.drift_error.magnitude = 0.05
            self.params.xbar.device.drift_error.model = "NormalProportionalDevice"

        # Initialize weight matrices (rsn_dim x embed_dim for matvec)
        # Random initialization centered at zero
        np.random.seed(42)  # Reproducible
        W_R = np.random.randn(self.config.rsn_dim, self.config.embed_dim).astype(np.float32) * 0.1
        W_S = np.random.randn(self.config.rsn_dim, self.config.embed_dim).astype(np.float32) * 0.1
        W_N = np.random.randn(self.config.rsn_dim, self.config.embed_dim).astype(np.float32) * 0.1

        # Create CrossSim cores
        self.R_core = AnalogCore(W_R, self.params)
        self.S_core = AnalogCore(W_S, self.params)
        self.N_core = AnalogCore(W_N, self.params)

        print(f"CrossSim cores initialized: {self.config.rsn_dim}x{self.config.embed_dim}")

    def forward(self, embedding: np.ndarray) -> Dict[str, Any]:
        """
        Project embedding through R/S/N CrossSim cores.

        This runs on CrossSim's validated hardware simulator,
        including any configured non-idealities.

        Args:
            embedding: Input embedding [embed_dim]

        Returns:
            Dict with R, S, N scores and derived metrics
        """
        embedding = embedding.astype(np.float32)

        # Project through each crossbar (simulated MVM)
        R_proj = self.R_core.matvec(embedding)
        S_proj = self.S_core.matvec(embedding)
        N_proj = self.N_core.matvec(embedding)

        # Compute norms as scores
        R_score = np.linalg.norm(R_proj)
        S_score = np.linalg.norm(S_proj)
        N_score = np.linalg.norm(N_proj)

        # Normalize to [0, 1]
        total = R_score + S_score + N_score + 1e-8
        R = R_score / total
        S = S_score / total
        N = N_score / total

        # Derived metrics
        alpha = R
        # ω defaults to 1.0 (in-distribution) for hardware simulation
        # In production, ω should be computed from OOD detection
        omega = 1.0
        quality_prior = 0.5
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        return {
            'R': float(R),
            'S': float(S),
            'N': float(N),
            'R_proj': R_proj,
            'S_proj': S_proj,
            'N_proj': N_proj,
            'alpha': float(alpha),
            'omega': float(omega),
            'alpha_omega': float(alpha_omega),
            'tau': float(tau),
            'backend': 'crosssim',
        }

    def set_weights(self, W_R: np.ndarray, W_S: np.ndarray, W_N: np.ndarray):
        """Set projection weights directly."""
        self.R_core.set_matrix(W_R.astype(np.float32))
        self.S_core.set_matrix(W_S.astype(np.float32))
        self.N_core.set_matrix(W_N.astype(np.float32))

    def get_weights(self) -> Dict[str, np.ndarray]:
        """Get current projection weights."""
        return {
            'W_R': self.R_core.get_matrix(),
            'W_S': self.S_core.get_matrix(),
            'W_N': self.N_core.get_matrix(),
        }

    # =========================================================================
    # State Persistence
    # =========================================================================

    def save_state(self) -> Dict[str, Any]:
        """
        Save CrossSim projection state for persistence.

        Returns:
            Dict with config and weight matrices (numpy arrays)
        """
        weights = self.get_weights()
        return {
            'backend': 'crosssim',
            'config': {
                'embed_dim': self.config.embed_dim,
                'rsn_dim': self.config.rsn_dim,
                'weight_bits': self.config.weight_bits,
                'adc_bits': self.config.adc_bits,
                'dac_bits': self.config.dac_bits,
                'programming_error': self.config.programming_error,
                'read_noise': self.config.read_noise,
                'drift_enabled': self.config.drift_enabled,
            },
            'W_R': weights['W_R'],
            'W_S': weights['W_S'],
            'W_N': weights['W_N'],
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """
        Load projection state from saved dict.

        Args:
            state: From save_state()
        """
        self.set_weights(state['W_R'], state['W_S'], state['W_N'])

    @classmethod
    def from_saved_state(cls, state: Dict[str, Any]) -> 'CrossSimProjection':
        """
        Create new projection from saved state.

        Args:
            state: From save_state()

        Returns:
            New CrossSimProjection with loaded weights
        """
        cfg = state['config']
        config = CrossSimConfig(
            embed_dim=cfg['embed_dim'],
            rsn_dim=cfg['rsn_dim'],
            weight_bits=cfg.get('weight_bits', 8),
            adc_bits=cfg.get('adc_bits', 8),
            dac_bits=cfg.get('dac_bits', 8),
            programming_error=cfg.get('programming_error', 0.0),
            read_noise=cfg.get('read_noise', 0.0),
            drift_enabled=cfg.get('drift_enabled', False),
        )
        proj = cls(config)
        proj.load_state(state)
        return proj

    def save_to_file(
        self,
        path: Union[str, Path],
        format: str = "auto",
        compress: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Path:
        """
        Save projection state to file with numpy support.

        Args:
            path: Output file path
            format: "auto", "json", "pickle", or "msgpack"
            compress: Whether to gzip compress
            metadata: Optional metadata

        Returns:
            Path to saved file
        """
        from yrsn.hardware.serialization import save_memristor_state
        return save_memristor_state(
            self.save_state(),
            path,
            format=format,
            compress=compress,
            metadata=metadata,
        )

    @classmethod
    def load_from_file(
        cls,
        path: Union[str, Path],
        format: str = "auto",
    ) -> 'CrossSimProjection':
        """
        Load projection from file.

        Args:
            path: Input file path
            format: "auto", "json", "pickle", or "msgpack"

        Returns:
            New CrossSimProjection with loaded weights
        """
        from yrsn.hardware.serialization import load_memristor_state
        state = load_memristor_state(path, format=format)
        return cls.from_saved_state(state)


class CrossSimBitSlicedProjection(CrossSimProjection):
    """
    YRSN projection with CrossSim's native bit-slicing support.

    Uses CrossSim's built-in bit_sliced mode for hardware-accurate
    multi-precision computation.
    """

    def __init__(
        self,
        config: Optional[CrossSimConfig] = None,
        weight_bits: int = 8,
        slice_bits: int = 2,
    ):
        self.slice_bits = slice_bits
        self.num_slices = weight_bits // slice_bits

        # Enable bit-slicing in CrossSim
        config = config or CrossSimConfig()
        config.weight_bits = weight_bits

        super().__init__(config)

        # Configure bit-slicing
        self.params.core.bit_sliced = True
        self.params.core.weight_bits = weight_bits

        print(f"Bit-sliced mode: {weight_bits} bits in {self.num_slices} slices of {slice_bits} bits")


def example_usage():
    """Demonstrate CrossSim-backed YRSN projection."""
    check_crosssim()

    print("=== CrossSim YRSN Projection Demo ===\n")

    # Basic projection
    config = CrossSimConfig(
        embed_dim=128,
        rsn_dim=32,
        programming_error=0.0,  # Start ideal
        read_noise=0.0,
    )

    proj = CrossSimProjection(config)

    # Random embedding
    embedding = np.random.randn(128).astype(np.float32)

    # Forward pass
    result = proj.forward(embedding)
    print("Ideal hardware simulation:")
    print(f"  R={result['R']:.3f}, S={result['S']:.3f}, N={result['N']:.3f}")
    print(f"  α={result['alpha']:.3f}, τ={result['tau']:.3f}")
    print(f"  Backend: {result['backend']}")

    # Now with non-idealities
    print("\n--- Adding non-idealities ---\n")

    config_noisy = CrossSimConfig(
        embed_dim=128,
        rsn_dim=32,
        programming_error=0.05,  # 5% programming error
        read_noise=0.02,         # 2% read noise
    )

    proj_noisy = CrossSimProjection(config_noisy)

    # Same embedding
    result_noisy = proj_noisy.forward(embedding)
    print("With programming error + read noise:")
    print(f"  R={result_noisy['R']:.3f}, S={result_noisy['S']:.3f}, N={result_noisy['N']:.3f}")

    # Compare
    print(f"\nDifference due to non-idealities:")
    print(f"  ΔR = {abs(result['R'] - result_noisy['R']):.4f}")
    print(f"  ΔS = {abs(result['S'] - result_noisy['S']):.4f}")
    print(f"  ΔN = {abs(result['N'] - result_noisy['N']):.4f}")


if __name__ == "__main__":
    example_usage()
