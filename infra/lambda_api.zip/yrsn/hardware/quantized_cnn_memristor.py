"""
Quantized CNN to Memristor Crossbar Adapter

Bridges quantized CNN frameworks (like CAS-CLab/quantized-cnn) to YRSN's memristor projection system.

Key Features:
1. Weight quantization → memristor conductance mapping
2. Pulse programming simulation (weight → conductance via pulses)
3. Quantized CNN inference on memristor crossbars
4. Integration with YRSN R/S/N decomposition for quality-aware denoising
5. Device-agnostic: works on host (CPU), GPU (CUDA/MPS), and TPU (XLA)

References:
- CAS-CLab/quantized-cnn: https://github.com/jiaxiang-wu/quantized-cnn
- Hardware-Aware Quantization for Accurate Memristor CIM (ACM 2025)
- Mapping-Aware Biased Training (TU Delft 2023)
"""

import numpy as np
import torch
import torch.nn as nn
from typing import Optional, Dict, Any, Tuple, List, Callable, Union
from dataclasses import dataclass
from enum import Enum

from .memristor_projection import (
    MemristorConfig,
    MemristorArray,
    YRSNMemristorConfig,
    YRSNMemristorProjection,
    VirtualMemristor,
    MemristorType
)

# Device-agnostic utilities
try:
    from yrsn.adapters.outbound.vla.device import (
        DeviceManager,
        get_default_device,
        get_optimal_dtype,
        is_device_available,
    )
    DEVICE_MANAGER_AVAILABLE = True
    DEFAULT_DEVICE = None  # Will use get_default_device()
except ImportError:
    # Fallback if DeviceManager not available
    DEVICE_MANAGER_AVAILABLE = False
    DeviceManager = None
    get_default_device = lambda: "cpu"  # CPU is always available as fallback
    get_optimal_dtype = lambda device: "float32"
    is_device_available = lambda device: device == "cpu"  # Only CPU available without DeviceManager
    DEFAULT_DEVICE = "cpu"  # Fallback device (CPU is always available)


# ============================================================================
# Quantization Schemes
# ============================================================================

class QuantizationScheme(Enum):
    """Quantization schemes for CNN weights."""
    SYMMETRIC = "symmetric"      # [-max, max] → [-levels/2, levels/2-1]
    ASYMMETRIC = "asymmetric"    # [min, max] → [0, levels-1]
    POWER_OF_2 = "power_of_2"    # Quantize to powers of 2 (hardware-friendly)
    UNIFORM = "uniform"          # Uniform quantization levels


@dataclass
class QuantizationConfig:
    """Configuration for weight quantization."""
    weight_bits: int = 4          # Bits for weights (4-bit = 16 levels)
    activation_bits: int = 8       # Bits for activations
    scheme: QuantizationScheme = QuantizationScheme.SYMMETRIC
    per_channel: bool = True      # Per-channel quantization (better accuracy)
    calibration_samples: int = 100 # Samples for calibration


# ============================================================================
# Weight → Conductance Mapping
# ============================================================================

@dataclass
class ConductanceMappingConfig:
    """Configuration for weight-to-conductance mapping."""
    G_min: float = 1e-6           # Minimum conductance (Siemens)
    G_max: float = 1e-3           # Maximum conductance (Siemens)
    G_levels: int = 16             # Number of conductance levels
    mapping_strategy: str = "linear"  # "linear", "log", "variation_aware"
    variation_profile: Optional[Dict[str, float]] = None  # Variation-aware mapping


class WeightToConductanceMapper:
    """
    Maps quantized CNN weights to memristor conductance values.
    
    Supports multiple mapping strategies:
    - Linear: G = G_min + (w_norm) * (G_max - G_min)
    - Logarithmic: G = G_min * (G_max/G_min)^w_norm
    - Variation-aware: Critical weights → low-variation conductance regions
    """
    
    def __init__(self, config: ConductanceMappingConfig):
        self.config = config
        self.G_range = config.G_max - config.G_min
        
        # Pre-compute conductance levels
        if config.mapping_strategy == "linear":
            self.conductance_levels = np.linspace(
                config.G_min, config.G_max, config.G_levels
            )
        elif config.mapping_strategy == "log":
            self.conductance_levels = np.logspace(
                np.log10(config.G_min), np.log10(config.G_max), config.G_levels
            )
        else:
            self.conductance_levels = np.linspace(
                config.G_min, config.G_max, config.G_levels
            )
    
    def map_weight(self, weight: float, weight_min: float, weight_max: float) -> float:
        """
        Map quantized weight to conductance.
        
        Args:
            weight: Quantized weight value
            weight_min: Minimum weight in layer
            weight_max: Maximum weight in layer
        
        Returns:
            Conductance value (Siemens)
        """
        # Normalize weight to [0, 1]
        if weight_max > weight_min:
            w_norm = (weight - weight_min) / (weight_max - weight_min)
        else:
            w_norm = 0.5
        
        # Map to conductance
        if self.config.mapping_strategy == "linear":
            G = self.config.G_min + w_norm * self.G_range
        elif self.config.mapping_strategy == "log":
            G = self.config.G_min * (self.config.G_max / self.config.G_min) ** w_norm
        else:
            G = self.config.G_min + w_norm * self.G_range
        
        # Quantize to nearest level
        idx = np.argmin(np.abs(self.conductance_levels - G))
        return self.conductance_levels[idx]
    
    def map_weights_tensor(
        self, 
        weights: torch.Tensor,
        per_channel: bool = True
    ) -> torch.Tensor:
        """
        Map weight tensor to conductance tensor.
        
        Args:
            weights: Weight tensor [out_channels, in_channels, ...]
            per_channel: Whether to normalize per channel
        
        Returns:
            Conductance tensor (same shape as weights, on same device)
        """
        # Device-agnostic: move to host device for numpy operations, preserve original device
        original_device = weights.device
        # Numpy requires host memory (CPU), so move tensor to host
        weights_host = weights.detach()
        if weights_host.device.type != "cpu":
            weights_host = weights_host.cpu()
        weights_np = weights_host.numpy()
        
        if per_channel and len(weights.shape) >= 2:
            # Per-channel mapping (better for variation-aware)
            conductances = np.zeros_like(weights_np)
            for i in range(weights.shape[0]):  # For each output channel
                channel_weights = weights_np[i]
                w_min, w_max = channel_weights.min(), channel_weights.max()
                for idx in np.ndindex(channel_weights.shape):
                    conductances[i][idx] = self.map_weight(
                        channel_weights[idx], w_min, w_max
                    )
        else:
            # Global mapping
            w_min, w_max = weights_np.min(), weights_np.max()
            conductances = np.array([
                self.map_weight(w, w_min, w_max) for w in weights_np.flatten()
            ]).reshape(weights_np.shape)
        
        # Move back to original device
        return torch.from_numpy(conductances).to(original_device)


# ============================================================================
# Pulse Programming Simulation
# ============================================================================

class PulseProgrammer:
    """
    Simulates pulse programming to set memristor conductance.
    
    Maps desired conductance → pulse parameters (voltage, width, shape).
    Can use learned NN model (from "Neural Networks Facilitating Memristor Programming" paper).
    """
    
    def __init__(
        self,
        programming_model: Optional[nn.Module] = None,
        use_learned: bool = False
    ):
        self.programming_model = programming_model
        self.use_learned = use_learned
    
    def compute_pulse_parameters(
        self,
        desired_G: float,
        current_G: float,
        tau: float = 1.0
    ) -> Dict[str, float]:
        """
        Compute pulse parameters to achieve desired conductance.
        
        Args:
            desired_G: Target conductance
            current_G: Current conductance
            tau: Temperature from YRSN (modulates programming aggressiveness)
        
        Returns:
            Dict with pulse parameters: {voltage, width, shape, ...}
        """
        if self.use_learned and self.programming_model is not None:
            # Learned programming (NN-based)
            delta_G = desired_G - current_G
            inputs = torch.tensor([[delta_G, current_G, tau]], dtype=torch.float32)
            pulse_params = self.programming_model(inputs)
            return {
                'voltage': pulse_params[0, 0].item(),
                'width': pulse_params[0, 1].item(),
                'shape': pulse_params[0, 2].item() if pulse_params.shape[1] > 2 else 1.0
            }
        else:
            # Deterministic programming (simplified model)
            delta_G = desired_G - current_G
            # Simple model: voltage ∝ |ΔG|, width ∝ |ΔG|
            voltage = np.clip(abs(delta_G) * 1e6 * tau, 0.1, 3.0)  # 0.1-3.0V
            width = np.clip(abs(delta_G) * 1e3 * tau, 1e-6, 1e-3)  # 1μs-1ms
            return {
                'voltage': voltage,
                'width': width,
                'shape': 1.0  # Square pulse
            }
    
    def apply_pulse(
        self,
        memristor: VirtualMemristor,
        desired_G: float,
        tau: float = 1.0
    ) -> float:
        """
        Apply pulse to memristor to achieve desired conductance.
        
        Args:
            memristor: VirtualMemristor instance
            desired_G: Target conductance
            tau: Temperature from YRSN
        
        Returns:
            New conductance after pulse
        """
        current_G = memristor.conductance
        pulse_params = self.compute_pulse_parameters(desired_G, current_G, tau)
        
        # Convert pulse to current (simplified: I = V / R)
        # In reality, this would be more complex (pulse shape, device physics)
        V = pulse_params['voltage']
        R_target = 1.0 / desired_G
        I = V / R_target  # Simplified current calculation
        
        # Apply current (this updates memristor state)
        memristor.apply_current(I, tau=tau, dt=pulse_params['width'])
        
        return memristor.conductance


# ============================================================================
# Quantized CNN Layer with Memristor Crossbar
# ============================================================================

class MemristorBackend(Enum):
    """Backend for memristor simulation."""
    VIRTUAL = "virtual"      # Built-in VirtualMemristor (HP Labs dynamics)
    CROSSSIM = "crosssim"    # Sandia's validated CrossSim simulator


class QuantizedConv2dMemristor(nn.Module):
    """
    Quantized 2D Convolution layer that runs on memristor crossbar.

    Workflow:
    1. Quantize weights (training-aware or post-training)
    2. Map quantized weights → conductance
    3. Store conductance in memristor crossbar
    4. Forward pass: analog crossbar computation (I = G × V)
    5. Apply hardware noise (read noise, quantization, etc.)

    Backend Options:
    - VIRTUAL: Built-in VirtualMemristor with HP Labs dynamics
    - CROSSSIM: Sandia's validated CrossSim simulator (requires install)
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        stride: int = 1,
        padding: int = 0,
        quantization_config: Optional[QuantizationConfig] = None,
        conductance_config: Optional[ConductanceMappingConfig] = None,
        hardware_noise: bool = True,
        backend: MemristorBackend = MemristorBackend.VIRTUAL,
        device: Optional[Union[str, torch.device]] = None,
    ):
        super().__init__()

        # Device-agnostic setup with graceful fallback
        if device is None:
            device = get_default_device() if DEVICE_MANAGER_AVAILABLE else DEFAULT_DEVICE
        elif isinstance(device, torch.device):
            device = str(device)
        
        self.device_str = device
        if DEVICE_MANAGER_AVAILABLE:
            try:
                self.device_manager = DeviceManager(device=device)
                self._device = self.device_manager.torch_device
            except (ValueError, RuntimeError):
                # Fallback to default device if requested device unavailable
                fallback_device = get_default_device()
                self.device_str = fallback_device
                self.device_manager = DeviceManager(device=fallback_device)
                self._device = self.device_manager.torch_device
        else:
            self.device_manager = None
            try:
                self._device = torch.device(device)
            except Exception:
                # Fallback to default device
                self.device_str = DEFAULT_DEVICE
                self._device = torch.device(DEFAULT_DEVICE)

        # Standard conv layer (for training)
        self.conv = nn.Conv2d(
            in_channels, out_channels, kernel_size,
            stride=stride, padding=padding
        )

        # Quantization config
        self.quant_config = quantization_config or QuantizationConfig()

        # Conductance mapping
        self.cond_config = conductance_config or ConductanceMappingConfig()
        self.mapper = WeightToConductanceMapper(self.cond_config)

        # Backend selection
        self.backend = backend
        self.hardware_noise = hardware_noise

        # Memristor crossbar (one per output channel)
        # Backend determines actual implementation:
        # - VIRTUAL: MemristorArray with VirtualMemristor
        # - CROSSSIM: Sandia's AnalogCore
        self.crossbars: List[Any] = []
        self._crosssim_cores: List[Any] = []  # For CrossSim backend

        # Quantization parameters (calibrated during training)
        self.register_buffer('weight_scale', torch.ones(out_channels))
        self.register_buffer('weight_zero_point', torch.zeros(out_channels))
    
    def quantize_weights(self) -> torch.Tensor:
        """Quantize weights for memristor deployment."""
        weights = self.conv.weight.data  # [out_ch, in_ch, H, W]
        
        if self.quant_config.per_channel:
            # Per-channel quantization (better accuracy)
            quantized = torch.zeros_like(weights)
            for i in range(weights.shape[0]):
                channel_weights = weights[i]
                w_min, w_max = channel_weights.min(), channel_weights.max()
                
                # Quantize
                levels = 2 ** self.quant_config.weight_bits
                scale = (w_max - w_min) / (levels - 1) if w_max > w_min else 1.0
                quantized[i] = torch.round((channel_weights - w_min) / scale)
                quantized[i] = torch.clamp(quantized[i], 0, levels - 1)
                
                # Store scale/zero_point
                self.weight_scale[i] = scale
                self.weight_zero_point[i] = w_min
        else:
            # Global quantization
            w_min, w_max = weights.min(), weights.max()
            levels = 2 ** self.quant_config.weight_bits
            scale = (w_max - w_min) / (levels - 1) if w_max > w_min else 1.0
            quantized = torch.round((weights - w_min) / scale)
            quantized = torch.clamp(quantized, 0, levels - 1)
            
            self.weight_scale.fill_(scale)
            self.weight_zero_point.fill_(w_min)
        
        return quantized
    
    def map_to_conductance(self, quantized_weights: torch.Tensor) -> torch.Tensor:
        """Map quantized weights to conductance."""
        # Dequantize first (to get float values for mapping)
        dequantized = quantized_weights.float() * self.weight_scale.view(-1, 1, 1, 1) + \
                     self.weight_zero_point.view(-1, 1, 1, 1)
        
        # Map to conductance
        return self.mapper.map_weights_tensor(dequantized, per_channel=True)
    
    def initialize_crossbars(self):
        """Initialize memristor crossbars from quantized weights."""
        quantized = self.quantize_weights()
        conductances = self.map_to_conductance(quantized)

        # Create crossbar for each output channel
        self.crossbars.clear()
        self._crosssim_cores.clear()
        in_ch = self.conv.in_channels
        kernel_size = self.conv.kernel_size[0] * self.conv.kernel_size[1]

        if self.backend == MemristorBackend.CROSSSIM:
            # Use Sandia's CrossSim validated simulator
            self._initialize_crosssim(conductances, in_ch, kernel_size)
        else:
            # Use built-in VirtualMemristor
            self._initialize_virtual(conductances, in_ch, kernel_size)

    def _initialize_virtual(self, conductances: torch.Tensor, in_ch: int, kernel_size: int):
        """Initialize with built-in VirtualMemristor backend."""
        for i in range(self.conv.out_channels):
            # Crossbar: [in_channels * kernel_size] × [1] (one output per channel)
            crossbar = MemristorArray(
                rows=in_ch * kernel_size,
                cols=1,
                config=MemristorConfig()
            )

            # Set conductances (flatten kernel weights)
            # Move to host device for numpy operations
            channel_cond_tensor = conductances[i].flatten()
            if channel_cond_tensor.device.type != "cpu":
                channel_cond_tensor = channel_cond_tensor.cpu()
            channel_cond = channel_cond_tensor.numpy()
            for j, G in enumerate(channel_cond):
                if j < crossbar.rows:
                    # Set memristor conductance (inverse of resistance)
                    crossbar.memristors[j][0].R = 1.0 / max(G, 1e-9)

            self.crossbars.append(crossbar)

    def _initialize_crosssim(self, conductances: torch.Tensor, in_ch: int, kernel_size: int):
        """Initialize with Sandia's CrossSim validated simulator."""
        try:
            from simulator import AnalogCore, CrossSimParameters
        except ImportError:
            raise ImportError(
                "CrossSim not installed. Install with:\n"
                "  pip install git+https://github.com/sandialabs/cross-sim.git\n"
                "Or use backend=MemristorBackend.VIRTUAL"
            )

        # CrossSim parameters with hardware non-idealities
        params = CrossSimParameters()
        if self.hardware_noise:
            params.xbar.device.read_noise.enable = True
            params.xbar.device.read_noise.magnitude = 0.02  # 2% read noise
            params.xbar.device.programming_error.enable = True
            params.xbar.device.programming_error.magnitude = 0.05  # 5% programming error

        for i in range(self.conv.out_channels):
            # Get conductance matrix for this channel [in_ch * kernel_size, 1]
            # CrossSim AnalogCore expects (cols, rows) = (1, in_ch * kernel_size)
            # So we transpose: (rows, cols) -> (cols, rows)
            # Move to host device for numpy operations
            channel_cond_tensor = conductances[i].flatten()
            if channel_cond_tensor.device.type != "cpu":
                channel_cond_tensor = channel_cond_tensor.cpu()
            channel_cond = channel_cond_tensor.numpy().reshape(-1, 1)
            channel_cond_transposed = channel_cond.T.astype(np.float32)  # (1, in_ch * kernel_size)

            # Create CrossSim AnalogCore with transposed weights
            core = AnalogCore(channel_cond_transposed, params)
            self._crosssim_cores.append(core)

        print(f"CrossSim initialized: {self.conv.out_channels} cores, "
              f"noise={'ON' if self.hardware_noise else 'OFF'}")
    
    def forward_memristor(
        self,
        x: torch.Tensor,
        tau: float = 1.0
    ) -> torch.Tensor:
        """
        Forward pass on memristor crossbar (simulated or CrossSim).

        Args:
            x: Input tensor [B, C, H, W]
            tau: Temperature from YRSN (for hardware noise)

        Returns:
            Output tensor [B, C_out, H_out, W_out]
        """
        # Initialize if needed
        if self.backend == MemristorBackend.CROSSSIM:
            if len(self._crosssim_cores) == 0:
                self.initialize_crossbars()
        else:
            if len(self.crossbars) == 0:
                self.initialize_crossbars()
        
        B, C, H, W = x.shape
        kernel_size = self.conv.kernel_size[0]
        stride = self.conv.stride[0]
        padding = self.conv.padding[0]
        
        # Compute output dimensions
        H_out = (H + 2 * padding - kernel_size) // stride + 1
        W_out = (W + 2 * padding - kernel_size) // stride + 1
        
        # Initialize output (device-agnostic)
        output_device = x.device
        output = torch.zeros(B, self.conv.out_channels, H_out, W_out, device=output_device)
        
        # For each output channel
        for out_ch in range(self.conv.out_channels):
            # Get the appropriate backend
            if self.backend == MemristorBackend.CROSSSIM:
                crosssim_core = self._crosssim_cores[out_ch]
            else:
                crossbar = self.crossbars[out_ch]

            # For each spatial position
            for h in range(H_out):
                for w in range(W_out):
                    # Extract input patch
                    h_start = h * stride - padding
                    w_start = w * stride - padding

                    # Pad if needed (device-agnostic)
                    patch = torch.zeros(B, C, kernel_size, kernel_size, device=output_device)
                    for b in range(B):
                        for c in range(C):
                            for kh in range(kernel_size):
                                for kw in range(kernel_size):
                                    ph = h_start + kh
                                    pw = w_start + kw
                                    if 0 <= ph < H and 0 <= pw < W:
                                        patch[b, c, kh, kw] = x[b, c, ph, pw]

                    # Flatten patch to vector (input voltages)
                    patch_flat = patch.flatten(1)  # [B, in_ch * kernel_size]

                    # Crossbar computation: I = G × V (for each batch)
                    # Note: Memristor simulation requires host memory (numpy), but we move results back to original device
                    for b in range(B):
                        # Move to host device for memristor simulation (numpy-based)
                        voltages_tensor = patch_flat[b].detach()
                        if voltages_tensor.device.type != "cpu":
                            voltages_tensor = voltages_tensor.cpu()
                        voltages = voltages_tensor.numpy().astype(np.float32)

                        if self.backend == MemristorBackend.CROSSSIM:
                            # CrossSim: validated hardware simulation
                            # matvec includes noise if enabled in params
                            # CrossSim matvec expects 1D array matching the number of input rows
                            # The weight matrix was transposed during initialization: (1, rows)
                            # So matvec expects input of shape (rows,)
                            currents = crosssim_core.matvec(voltages)  # Returns (1,) array
                            # Extract scalar value
                            if isinstance(currents, np.ndarray):
                                current_value = float(currents.item() if currents.size == 1 else currents[0])
                            else:
                                current_value = float(currents)
                        else:
                            # VirtualMemristor: built-in simulation
                            currents = crossbar.forward(voltages)  # [1]
                            current_value = float(currents[0])

                            # Apply hardware noise if enabled (VirtualMemristor only)
                            if self.hardware_noise:
                                # Read noise (proportional to current)
                                noise_std = 0.01 * abs(current_value)
                                noise = np.random.normal(0, noise_std)
                                current_value += noise

                                # ADC quantization
                                adc_bits = 8
                                levels = 2 ** adc_bits
                                current_value = np.round(current_value * levels) / levels
                        
                        # Move result back to original device
                        output[b, out_ch, h, w] = torch.tensor(
                            current_value, 
                            device=output_device, 
                            dtype=output.dtype
                        )

        return output
    
    def forward(self, x: torch.Tensor, use_memristor: bool = False, tau: float = 1.0):
        """
        Forward pass.
        
        Args:
            x: Input tensor
            use_memristor: If True, use memristor crossbar; else use standard conv
            tau: Temperature from YRSN (for memristor mode)
        """
        if use_memristor:
            return self.forward_memristor(x, tau=tau)
        else:
            return self.conv(x)


# ============================================================================
# Tiny CNN for Image Denoising
# ============================================================================

class TinyDenoisingCNN(nn.Module):
    """
    Tiny CNN for image denoising, adapted for memristor crossbar inference.
    
    Architecture:
    - Input: Noisy image [B, 1, H, W] (grayscale) or [B, 3, H, W] (RGB)
    - Encoder: 2-3 conv layers with ReLU
    - Decoder: 2-3 conv layers with ReLU
    - Output: Denoised image (same size as input)
    """
    
    def __init__(
        self,
        in_channels: int = 1,
        base_channels: int = 16,
        num_layers: int = 3,
        quantization_config: Optional[QuantizationConfig] = None,
        conductance_config: Optional[ConductanceMappingConfig] = None,
        device: Optional[Union[str, torch.device]] = None,
    ):
        super().__init__()
        
        self.in_channels = in_channels
        self.base_channels = base_channels
        
        # Device-agnostic setup with graceful fallback
        if device is None:
            device = get_default_device() if DEVICE_MANAGER_AVAILABLE else DEFAULT_DEVICE
        elif isinstance(device, torch.device):
            device = str(device)
        
        # Validate device and fallback to default if invalid
        if DEVICE_MANAGER_AVAILABLE:
            try:
                if not is_device_available(device):
                    device = get_default_device()
            except Exception:
                device = get_default_device()
        else:
            # Basic validation: try to create device, fallback on error
            try:
                torch.device(device)
            except Exception:
                device = DEFAULT_DEVICE
        
        self.device_str = device
        
        # Encoder
        encoder_layers = []
        for i in range(num_layers):
            in_ch = in_channels if i == 0 else base_channels * (2 ** (i - 1))
            out_ch = base_channels * (2 ** i)
            encoder_layers.append(
                QuantizedConv2dMemristor(
                    in_ch, out_ch, kernel_size=3, padding=1,
                    quantization_config=quantization_config,
                    conductance_config=conductance_config,
                    device=device,
                )
            )
            encoder_layers.append(nn.ReLU(inplace=True))
        
        self.encoder = nn.Sequential(*encoder_layers)
        
        # Decoder (symmetric)
        decoder_layers = []
        for i in range(num_layers - 1, -1, -1):
            in_ch = base_channels * (2 ** i) if i < num_layers - 1 else base_channels * (2 ** (num_layers - 1))
            out_ch = base_channels * (2 ** (i - 1)) if i > 0 else in_channels
            decoder_layers.append(
                QuantizedConv2dMemristor(
                    in_ch, out_ch, kernel_size=3, padding=1,
                    quantization_config=quantization_config,
                    conductance_config=conductance_config,
                    device=device,
                )
            )
            if i > 0:
                decoder_layers.append(nn.ReLU(inplace=True))
        
        self.decoder = nn.Sequential(*decoder_layers)
    
    def forward(
        self,
        x: torch.Tensor,
        use_memristor: bool = False,
        tau: float = 1.0
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            x: Noisy image [B, C, H, W]
            use_memristor: If True, use memristor crossbars
            tau: Temperature from YRSN (for memristor mode)
        """
        # Encoder
        if use_memristor:
            encoded = x
            for layer in self.encoder:
                if isinstance(layer, QuantizedConv2dMemristor):
                    encoded = layer(encoded, use_memristor=True, tau=tau)
                else:
                    encoded = layer(encoded)
        else:
            encoded = self.encoder(x)
        
        # Decoder
        if use_memristor:
            decoded = encoded
            for layer in self.decoder:
                if isinstance(layer, QuantizedConv2dMemristor):
                    decoded = layer(decoded, use_memristor=True, tau=tau)
                else:
                    decoded = layer(decoded)
        else:
            decoded = self.decoder(encoded)
        
        return decoded


# ============================================================================
# YRSN Integration: Quality-Aware Denoising
# ============================================================================

class YRSNQualityAwareDenoiser(nn.Module):
    """
    Image denoiser with YRSN quality-aware gating.
    
    Uses YRSN R/S/N decomposition to:
    1. Measure input image quality (α)
    2. Gate denoising based on quality threshold
    3. Track hardware health via N component
    """
    
    def __init__(
        self,
        denoiser: TinyDenoisingCNN,
        yrsn_projection: Optional[YRSNMemristorProjection] = None,
        quality_threshold: float = 0.5
    ):
        super().__init__()
        self.denoiser = denoiser
        self.yrsn_projection = yrsn_projection
        self.quality_threshold = quality_threshold
    
    def forward(
        self,
        x: torch.Tensor,
        use_memristor: bool = False,
        tau: float = 1.0
    ) -> Dict[str, Any]:
        """
        Forward pass with quality gating.
        
        Returns:
            Dict with:
            - 'denoised': Denoised image
            - 'quality': Quality signal (α)
            - 'rsn': R/S/N decomposition
            - 'gated': Whether denoising was applied
        """
        # Measure input quality via YRSN
        if self.yrsn_projection is not None:
            # Flatten image to embedding (simplified)
            # In practice, use proper feature extraction
            # Use flattened image as embedding (ensure it's 1D)
            # Device-agnostic: move to host device for numpy operations, then back
            # Note: numpy operations require host memory, so we detach and move to host temporarily
            x_host = x.detach()
            if x_host.device.type != "cpu":
                x_host = x_host.cpu()
            embeddings = x_host.flatten(1).numpy()  # [B, H*W*C]
            
            # Get quality signal
            quality_signals = []
            for emb in embeddings:
                # Ensure embedding is 1D array, not scalar
                if emb.ndim == 0:
                    emb = np.array([emb.item()])
                elif emb.ndim > 1:
                    emb = emb.flatten()
                # Pad or truncate to match embed_dim
                embed_dim = self.yrsn_projection.config.embed_dim
                if len(emb) < embed_dim:
                    # Pad with zeros
                    emb = np.pad(emb, (0, embed_dim - len(emb)), mode='constant')
                elif len(emb) > embed_dim:
                    # Truncate
                    emb = emb[:embed_dim]
                rsn = self.yrsn_projection.forward(emb)
                quality_signals.append(rsn)
            
            # Average quality across batch
            avg_alpha = np.mean([qs['alpha'] for qs in quality_signals])
            avg_n = np.mean([qs['N'] for qs in quality_signals])
            
            # Gate denoising
            if avg_alpha >= self.quality_threshold:
                # High quality: apply denoising
                denoised = self.denoiser(x, use_memristor=use_memristor, tau=tau)
                gated = True
            else:
                # Low quality: skip denoising (or apply minimal)
                denoised = x  # Or apply light denoising
                gated = False
        else:
            # No YRSN: always denoise
            denoised = self.denoiser(x, use_memristor=use_memristor, tau=tau)
            avg_alpha = 1.0
            avg_n = 0.0
            gated = True
        
        return {
            'denoised': denoised,
            'quality': avg_alpha,
            'N': avg_n,  # Hardware health indicator
            'gated': gated
        }


# ============================================================================
# YRSN Signal Integration
# ============================================================================

from yrsn.core.decomposition.collapse import detect_collapse, CollapseType, CollapseAnalysis
from yrsn.core.signal_spec import Phase


@dataclass
class YRSNDenoisingSignal:
    """
    YRSN-compatible signal output from denoising.

    Follows Signal Specification v1.0 structure.
    """
    # Core R/S/N decomposition
    R: float
    S: float
    N: float

    # Derived signals
    alpha: float           # Quality = R
    alpha_omega: float     # Reliability-adjusted quality
    tau: float             # Temperature = 1/α_ω
    omega: float           # Reliability (1.0 if in-distribution)

    # Phase
    phase: Phase

    # Collapse detection
    collapse_type: Optional[CollapseType]
    collapse_severity: float

    # Denoising result
    denoised: torch.Tensor
    gated: bool            # Whether denoising was applied

    # Hardware health
    hardware_health: float  # 1 - N (higher is healthier)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict for API compatibility."""
        return {
            'decomposition': {
                'R': self.R,
                'S': self.S,
                'N': self.N,
            },
            'signals': {
                'alpha': self.alpha,
                'alpha_omega': self.alpha_omega,
                'tau': self.tau,
                'omega': self.omega,
            },
            'phase': self.phase.value,
            'collapse': {
                'type': self.collapse_type.value if self.collapse_type else None,
                'severity': self.collapse_severity,
            },
            'denoised': self.denoised,
            'gated': self.gated,
            'hardware_health': self.hardware_health,
        }


class YRSNDenoisingAdapter(nn.Module):
    """
    YRSN Signal-compatible wrapper for quantized CNN denoiser.

    Transforms raw denoiser output into full YRSN signal format:
    - R/S/N decomposition with simplex validation
    - α, α_ω, τ derived signals
    - Phase determination (EXPLOIT/EXPLORE/TRANSITION)
    - Collapse detection and classification
    - Hardware health monitoring via N component

    Usage:
        from yrsn.hardware import YRSNDenoisingAdapter, create_denoising_model

        # Create base model
        base_model = create_denoising_model(use_yrsn=True)

        # Wrap with YRSN signal adapter
        adapter = YRSNDenoisingAdapter(base_model)

        # Forward returns full YRSN signal
        signal = adapter(noisy_image, use_memristor=True)
        print(f"Phase: {signal.phase}")
        print(f"Collapse: {signal.collapse_type}")
    """

    # Phase thresholds (from Signal Spec)
    TAU_EXPLOIT = 1.5      # τ < 1.5 → EXPLOIT (high confidence)
    TAU_EXPLORE = 3.0      # τ > 3.0 → EXPLORE (low confidence)

    # Collapse thresholds
    N_POISONING_THRESHOLD = 0.4
    S_DISTRACTION_THRESHOLD = 0.5

    def __init__(
        self,
        denoiser: nn.Module,
        quality_prior: float = 0.5,
        validate_simplex: bool = True,
    ):
        """
        Initialize YRSN denoising adapter.

        Args:
            denoiser: Base denoiser (YRSNQualityAwareDenoiser or TinyDenoisingCNN)
            quality_prior: Prior for α_ω computation when ω is unknown
            validate_simplex: Whether to validate R+S+N=1
        """
        super().__init__()
        self.denoiser = denoiser
        self.quality_prior = quality_prior
        self.validate_simplex = validate_simplex

        # Track N history for hardware health trending
        self._n_history: List[float] = []
        self._n_baseline: Optional[float] = None

    def forward(
        self,
        x: torch.Tensor,
        use_memristor: bool = True,
        tau: float = 1.0,
        compute_omega: bool = False,
    ) -> YRSNDenoisingSignal:
        """
        Forward pass with full YRSN signal output.

        Args:
            x: Input image [B, C, H, W]
            use_memristor: Whether to use memristor crossbar
            tau: Temperature (can override computed τ)
            compute_omega: Whether to compute ω from OOD detection

        Returns:
            YRSNDenoisingSignal with full signal decomposition
        """
        # Get base denoiser output
        if isinstance(self.denoiser, YRSNQualityAwareDenoiser):
            output = self.denoiser(x, use_memristor=use_memristor, tau=tau)
            R = output.get('R', output.get('quality', 0.33))
            S = output.get('S', 0.33)
            N = output.get('N', 0.33)
            denoised = output['denoised']
            gated = output.get('gated', True)
        else:
            # Raw denoiser without R/S/N
            denoised = self.denoiser(x, use_memristor=use_memristor, tau=tau)
            R, S, N = 0.33, 0.33, 0.34  # Default uniform
            gated = True

        # Validate simplex constraint
        if self.validate_simplex:
            total = R + S + N
            if abs(total - 1.0) > 0.01:
                # Renormalize
                R, S, N = R / total, S / total, N / total

        # Compute derived signals
        alpha = R  # Quality = Relevance

        # Compute omega (reliability)
        if compute_omega:
            # TODO: Integrate OOD detection
            omega = 1.0  # Placeholder
        else:
            omega = 1.0  # Assume in-distribution

        # Reliability-adjusted quality
        alpha_omega = omega * alpha + (1 - omega) * self.quality_prior

        # Temperature
        tau_computed = 1.0 / max(alpha_omega, 0.01)

        # Determine phase
        if tau_computed < self.TAU_EXPLOIT:
            phase = Phase.EXPLOIT
        elif tau_computed > self.TAU_EXPLORE:
            phase = Phase.EXPLORE
        else:
            phase = Phase.TRANSITION

        # Detect collapse
        collapse_analysis = detect_collapse(R=R, S=S, N=N)
        collapse_type = collapse_analysis.collapse_type if collapse_analysis.is_collapsed else None
        collapse_severity = collapse_analysis.severity

        # Track hardware health (N component)
        self._n_history.append(N)
        if len(self._n_history) > 100:
            self._n_history = self._n_history[-100:]

        # Compute baseline if not set
        if self._n_baseline is None and len(self._n_history) >= 10:
            self._n_baseline = np.mean(self._n_history[:10])

        # Hardware health: 1 - N (higher is better)
        # Alert if N is rising significantly above baseline
        hardware_health = 1.0 - N
        if self._n_baseline is not None:
            delta_n = N - self._n_baseline
            if delta_n > 0.1:
                # Hardware degradation detected
                hardware_health = max(0.0, 1.0 - N - delta_n)

        return YRSNDenoisingSignal(
            R=R,
            S=S,
            N=N,
            alpha=alpha,
            alpha_omega=alpha_omega,
            tau=tau_computed,
            omega=omega,
            phase=phase,
            collapse_type=collapse_type,
            collapse_severity=collapse_severity,
            denoised=denoised,
            gated=gated,
            hardware_health=hardware_health,
        )

    def reset_health_tracking(self):
        """Reset hardware health tracking."""
        self._n_history.clear()
        self._n_baseline = None

    def get_health_trend(self) -> Dict[str, Any]:
        """Get hardware health trend analysis."""
        if len(self._n_history) < 2:
            return {'status': 'insufficient_data'}

        recent = self._n_history[-10:] if len(self._n_history) >= 10 else self._n_history
        trend = np.polyfit(range(len(recent)), recent, 1)[0]  # Linear slope

        return {
            'baseline_N': self._n_baseline,
            'current_N': self._n_history[-1],
            'trend_slope': trend,
            'status': 'degrading' if trend > 0.01 else 'stable' if trend > -0.01 else 'improving',
            'samples': len(self._n_history),
        }


# ============================================================================
# Example Usage
# ============================================================================

def create_denoising_model(
    in_channels: int = 1,
    weight_bits: int = 4,
    use_yrsn: bool = True,
    device: Optional[Union[str, torch.device]] = None,
) -> nn.Module:
    """
    Create a quantized CNN denoising model ready for memristor deployment.
    
    Args:
        in_channels: Input channels (1=grayscale, 3=RGB)
        weight_bits: Quantization bits for weights
        use_yrsn: Whether to use YRSN quality-aware gating
        device: Device string (e.g., "cuda:0", "mps", "auto", or None for auto-detect)
    
    Returns:
        Denoising model (moved to specified device)
    """
    # Device-agnostic setup with graceful fallback
    if device is None:
        device = get_default_device() if DEVICE_MANAGER_AVAILABLE else DEFAULT_DEVICE
    elif isinstance(device, torch.device):
        device = str(device)
    
    # Validate device and fallback to default if invalid
    if DEVICE_MANAGER_AVAILABLE:
        try:
            if not is_device_available(device):
                device = get_default_device()
        except Exception:
            device = get_default_device()
    else:
        # Basic validation: try to create device, fallback on error
        try:
            torch.device(device)
        except Exception:
            device = DEFAULT_DEVICE
    
    # Quantization config
    quant_config = QuantizationConfig(
        weight_bits=weight_bits,
        activation_bits=8,
        scheme=QuantizationScheme.SYMMETRIC,
        per_channel=True
    )
    
    # Conductance mapping config
    cond_config = ConductanceMappingConfig(
        G_min=1e-6,
        G_max=1e-3,
        G_levels=2 ** weight_bits,
        mapping_strategy="linear"
    )
    
    # Create denoiser
    denoiser = TinyDenoisingCNN(
        in_channels=in_channels,
        base_channels=16,
        num_layers=3,
        quantization_config=quant_config,
        conductance_config=cond_config,
        device=device,
    )
    
    if use_yrsn:
        # Create YRSN projection for quality measurement
        yrsn_config = YRSNMemristorConfig(
            embed_dim=128,  # Adjust based on feature extraction
            rsn_dim=32
        )
        yrsn_projection = YRSNMemristorProjection(config=yrsn_config)
        
        # Wrap with quality-aware denoiser
        model = YRSNQualityAwareDenoiser(
            denoiser=denoiser,
            yrsn_projection=yrsn_projection,
            quality_threshold=0.5
        )
    else:
        model = denoiser
    
    # Move model to device
    default_device = get_default_device() if DEVICE_MANAGER_AVAILABLE else DEFAULT_DEVICE
    if device != default_device:
        try:
            model = model.to(device)
        except Exception:
            # Fallback to default device if requested device unavailable
            model = model.to(default_device)
    
    return model


if __name__ == "__main__":
    # Example: Create and test model
    model = create_denoising_model(in_channels=1, weight_bits=4, use_yrsn=True)
    
    # Test input
    x = torch.randn(1, 1, 64, 64)  # [B, C, H, W]
    
    # Standard forward (training)
    output_standard = model.denoiser(x, use_memristor=False)
    print(f"Standard output shape: {output_standard.shape}")
    
    # Memristor forward (inference)
    output_memristor = model(x, use_memristor=True, tau=1.0)
    print(f"Memristor output shape: {output_memristor['denoised'].shape}")
    print(f"Quality (α): {output_memristor['quality']:.3f}")
    print(f"Hardware health (N): {output_memristor['N']:.3f}")

