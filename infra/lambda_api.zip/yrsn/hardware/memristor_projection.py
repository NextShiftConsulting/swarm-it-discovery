"""
YRSN Memristor Projection - Hardware-faithful R/S/N decomposition.

Uses memristor crossbar arrays for actual R/S/N projection:
- Three separate arrays: W_R, W_S, W_N
- Conductance encodes learned projections
- Temperature (τ) modulates plasticity

This bridges the gap from "hardware-inspired naming" to "hardware-faithful implementation".

References:
- HP Labs memristor model (Strukov et al., Nature 2008)
- RRAM crossbar computation (Nature Electronics, 2024)
"""

from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, List, Union
from pathlib import Path
from enum import Enum
import numpy as np

# Optional torch support for device-aware operation
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


# ============================================================================
# Memristor Core (inline to avoid cross-repo dependency)
# Based on yrsn-iars/memristor/core/memristor.py
# ============================================================================

class MemristorType(Enum):
    """Types of memristor dynamics."""
    LINEAR = "linear"           # ΔR ∝ I (simple drift)
    THRESHOLD = "threshold"     # ΔR only when |I| > threshold
    NONLINEAR = "nonlinear"     # ΔR ∝ sinh(I) (HP Labs model)
    SPINTRONIC = "spintronic"   # Domain wall dynamics


@dataclass
class MemristorConfig:
    """Configuration for virtual memristor."""
    R_min: float = 0.1          # Minimum resistance (high confidence)
    R_max: float = 10.0         # Maximum resistance (low confidence)
    R_init: float = 1.0         # Initial resistance
    memristor_type: MemristorType = MemristorType.NONLINEAR  # Dynamics model
    drift_rate: float = 0.01    # How fast R changes
    threshold: float = 0.1      # For THRESHOLD/SPINTRONIC types
    decay_rate: float = 0.001   # Passive decay toward R_init
    noise_std: float = 0.01     # Johnson-Nyquist noise
    temperature_coupling: float = 1.0  # How much τ affects dynamics
    energy_barrier: float = 0.5  # Landauer: prevents thermal drift
    ewc_gamma: float = 0.9      # EWC Fisher decay factor
    # Gradient Accumulation (GA) - from Tan et al. 2024
    ga_batch_size: int = 8      # Accumulate this many gradients before update
    # Error Compensation (EC) - quantization error tracking
    ec_enabled: bool = True     # Track and compensate quantization errors
    # Sparse Updates - for endurance optimization
    sparse_threshold: float = 0.01  # Only update if |ΔR| > threshold


class VirtualMemristor:
    """
    Virtual memristor with HP Labs dynamics.

    Core equation: dR/dt = μ_v × (R_on/D²) × I × f(R)

    Temperature τ modulates plasticity:
    - High τ (low quality) = more plasticity
    - Low τ (high quality) = less plasticity (protect memory)

    EWC (Elastic Weight Consolidation):
    - Tracks Fisher information (importance of this weight)
    - Penalizes changes to important weights for continual learning
    """

    def __init__(self, config: Optional[MemristorConfig] = None):
        self.config = config or MemristorConfig()
        self.R = self.config.R_init
        self.q = 0.0       # Accumulated charge (experience)
        self.phi = 0.0     # Flux linkage (cumulative signal)
        self.fisher = 0.0  # EWC: Fisher information (importance)
        self.t = 0         # Time step
        self.R_history: List[float] = [self.R]

        # Gradient Accumulation (GA) - Tan et al. 2024
        self._gradient_buffer: List[float] = []  # Accumulated gradients
        self._ga_count = 0  # Count of accumulated gradients

        # Error Compensation (EC) - tracks quantization rounding errors
        self._ec_residual = 0.0  # Accumulated rounding error

        # Sparse Updates - tracking
        self._update_count = 0  # Total updates applied
        self._skipped_count = 0  # Updates skipped due to sparse threshold

        # Oobleck: Stress-Adaptive Plasticity (shear-thickening behavior)
        # When quality signals change rapidly, reduce plasticity to protect weights.
        #
        # Theoretical foundations:
        # - BCM sliding threshold: Bienenstock, Cooper, Munro (1982)
        # - Metaplasticity: Abraham & Bear (1996)
        # - EWC weight protection: Kirkpatrick et al. (2017)
        # - Surprise-based learning: Iigaya et al. (2016) [PMC5008908]
        # - Fast rate detector need: Zenke et al. (2013) [PLOS Comp Bio]
        #
        # Novel contributions:
        # - Asymmetric dynamics (fast lock, slow unlock) - like physical oobleck
        # - Integration with YRSN quality signals (α, κ)
        # - Sigmoidal phase transition (not gradual)
        #
        # See: docs/design/OOBLECK_PRIOR_WORK.md
        self._prev_tau: float = 1.0
        self._prev_alpha: float = 0.5
        self._stress: float = 0.0  # 0=liquid (learn), 1=solid (protect)
        self._stress_threshold: float = 0.3  # Shear threshold for phase transition
        self._lock_speed: float = 0.8  # Fast solidification (asymmetric)
        self._unlock_speed: float = 0.1  # Slow relaxation (asymmetric)

    @property
    def conductance(self) -> float:
        """G = 1/R (maps to weight/confidence)."""
        return 1.0 / self.R

    @property
    def normalized_R(self) -> float:
        """Resistance normalized to [0, 1]."""
        return (self.R - self.config.R_min) / (self.config.R_max - self.config.R_min)

    @property
    def stress(self) -> float:
        """Current stress state: 0=liquid (learning), 1=solid (protected)."""
        return self._stress

    @property
    def stress_regime(self) -> str:
        """Current stress regime: 'liquid', 'transition', or 'solid'."""
        if self._stress < 0.2:
            return "liquid"
        elif self._stress > 0.7:
            return "solid"
        return "transition"

    def compute_stress(self, tau: float, alpha: float, dt: float = 1.0) -> float:
        """
        Compute stress from rate of change of quality signals (Oobleck behavior).

        Implements shear-thickening: rapid changes → high stress → reduced plasticity.
        Asymmetric dynamics: fast solidification, slow relaxation.

        This is the NAIVE implementation. For geometric shear force that respects
        T⁴ topology and simplex constraints, use compute_stress_geometric().

        Args:
            tau: Current temperature (τ = 1/α_ω)
            alpha: Current quality signal
            dt: Time step

        Returns:
            Current stress level [0, 1]

        See Also:
            compute_stress_geometric: Uses T⁴ geodesic velocity
            yrsn.core.oobleck.GeometricShearForce: Full geometric implementation
        """
        # Compute shear force from rate of change (naive: Euclidean)
        d_tau = abs(tau - self._prev_tau) / max(dt, 0.01)
        d_alpha = abs(alpha - self._prev_alpha) / max(dt, 0.01)

        # Weighted shear: alpha changes are more significant
        shear = 0.3 * d_tau + 0.7 * d_alpha * 5.0  # Scale alpha to comparable range

        # Sigmoidal response (phase transition)
        target_stress = 1.0 / (1.0 + np.exp(-10.0 * (shear - self._stress_threshold)))

        # Asymmetric smoothing: fast lock, slow unlock
        if target_stress > self._stress:
            speed = self._lock_speed  # Fast solidification
        else:
            speed = self._unlock_speed  # Slow relaxation

        self._stress = (1.0 - speed) * self._stress + speed * target_stress

        # Update history
        self._prev_tau = tau
        self._prev_alpha = alpha

        return self._stress

    def compute_stress_geometric(
        self,
        t4_coords: Optional[Dict[str, float]] = None,
        rsn: Optional[Tuple[float, float, float]] = None,
        alpha: Optional[float] = None,
        kappa: Optional[float] = None,
        tau: Optional[float] = None,
    ) -> float:
        """
        Compute stress using GEOMETRIC shear force on T⁴ manifold.

        Unlike compute_stress() which uses naive |Δα| + |Δτ|, this method:
        1. Computes geodesic velocity on T⁴ (respects toroidal topology)
        2. Computes velocity on R/S/N simplex (respects constraint manifold)
        3. Combines into geometric shear force F_s

        This is more principled because:
        - 10° → 350° is 20° change, not 340° (toroidal wrap)
        - R/S/N changes stay on the simplex (sum = 1)

        Args:
            t4_coords: T⁴ coordinates {'simplex_theta', 'phi_simplex', 'alpha', 'omega'}
            rsn: (R, S, N) tuple on probability simplex
            alpha: Quality signal [0, 1] (fallback if t4_coords not provided)
            kappa: Compatibility signal [0, 1]
            tau: Temperature signal

        Returns:
            Current stress level [0, 1]

        Reference:
            yrsn.core.oobleck.GeometricShearForce
            docs/CIP_01_T4_PARAMETERIZATION.md
            arXiv:2503.24075 (Riemannian optimization on simplices)
        """
        # Lazy import to avoid circular dependency
        try:
            from yrsn.core.oobleck import GeometricShearForce
        except ImportError:
            # Fallback to naive if oobleck module not available
            return self.compute_stress(tau or 1.0, alpha or 0.5)

        # Create geometric shear computer if not exists
        if not hasattr(self, '_geometric_shear'):
            self._geometric_shear = GeometricShearForce(
                stress_threshold=self._stress_threshold,
                lock_speed=self._lock_speed,
                unlock_speed=self._unlock_speed,
            )

        # Update geometric shear
        state = self._geometric_shear.update(
            t4_coords=t4_coords,
            rsn=rsn,
            alpha=alpha,
            kappa=kappa,
            tau=tau,
        )

        # Use geometric stress
        self._stress = state.stress

        return self._stress

    def get_stress_plasticity_multiplier(self) -> float:
        """
        Get plasticity multiplier based on stress state.

        Returns:
            Multiplier in [0.1, 1.0]: 1.0 = full plasticity, 0.1 = mostly locked
        """
        return max(0.1, 1.0 - self._stress * 0.9)

    def apply_current(self, I: float, tau: float = 1.0, dt: float = 1.0,
                      alpha: Optional[float] = None) -> float:
        """
        Apply current and update resistance with optional stress-adaptive plasticity.

        When alpha is provided, enables Oobleck behavior:
        - Rapid quality changes → high stress → reduced plasticity (protect weights)
        - Gradual changes → low stress → normal plasticity (learn freely)

        Args:
            I: Current signal (error or Hebbian)
            tau: Temperature from YRSN (τ = 1/α_ω)
            dt: Time step
            alpha: Quality signal [0,1] for stress computation (optional)

        Returns:
            New resistance
        """
        cfg = self.config

        # Oobleck: Compute stress and modulate plasticity if alpha provided
        if alpha is not None:
            self.compute_stress(tau, alpha, dt)
            stress_multiplier = self.get_stress_plasticity_multiplier()
        else:
            stress_multiplier = 1.0

        # Temperature modulates learning rate, with stress dampening
        effective_rate = cfg.drift_rate * tau * cfg.temperature_coupling * stress_multiplier

        # Compute dR based on memristor type
        x = self.normalized_R
        window = 1.0 - (2*x - 1)**4  # Biolek window

        if cfg.memristor_type == MemristorType.LINEAR:
            # Simple drift: ΔR ∝ I
            dR = effective_rate * I * dt

        elif cfg.memristor_type == MemristorType.THRESHOLD:
            # Only update when |I| > threshold
            if abs(I) > cfg.threshold:
                dR = effective_rate * np.sign(I) * (abs(I) - cfg.threshold) * dt
            else:
                dR = 0.0

        elif cfg.memristor_type == MemristorType.NONLINEAR:
            # HP Labs sinh model with window function
            dR = effective_rate * np.sinh(I) * window * dt

        elif cfg.memristor_type == MemristorType.SPINTRONIC:
            # Domain wall dynamics: threshold + tanh
            if abs(I) > cfg.threshold:
                dR = effective_rate * np.tanh(I) * dt
            else:
                dR = 0.0
        else:
            dR = 0.0

        # Apply energy barrier (Landauer's principle)
        # Prevents small fluctuations from changing state
        if abs(dR) < cfg.energy_barrier * cfg.noise_std:
            dR = 0.0

        # Passive decay
        decay = cfg.decay_rate * (self.R - cfg.R_init) * dt
        dR -= decay

        # Add noise (only if exceeds energy barrier)
        if cfg.noise_std > 0:
            noise = np.random.normal(0, cfg.noise_std)
            if abs(noise) > cfg.energy_barrier:
                dR += noise * 0.1  # Attenuated noise

        # Update with bounds
        self.R = np.clip(self.R + dR, cfg.R_min, cfg.R_max)
        self.q += abs(I) * dt
        self.phi += I * dt
        self.t += 1
        self.R_history.append(self.R)

        return self.R

    # =========================================================================
    # Gradient Accumulation (GA) - Tan et al. 2024
    # Batch gradients before applying to reduce write operations
    # =========================================================================

    def accumulate_gradient(self, I: float, tau: float = 1.0) -> bool:
        """
        Accumulate gradient without immediately applying.

        From Tan et al. 2024: Gradient accumulation reduces write operations
        by batching updates, improving memristor endurance.

        Args:
            I: Current/gradient signal
            tau: Temperature from YRSN

        Returns:
            True if batch is full and flush_gradients() should be called
        """
        self._gradient_buffer.append((I, tau))
        self._ga_count += 1
        return self._ga_count >= self.config.ga_batch_size

    def flush_gradients(self, dt: float = 1.0) -> float:
        """
        Apply accumulated gradients as a single update.

        Uses mean gradient with Error Compensation (EC).

        Returns:
            New resistance after batched update
        """
        if not self._gradient_buffer:
            return self.R

        # Average gradients
        avg_I = np.mean([g[0] for g in self._gradient_buffer])
        avg_tau = np.mean([g[1] for g in self._gradient_buffer])

        # Add error compensation residual
        if self.config.ec_enabled:
            avg_I += self._ec_residual

        # Apply the accumulated gradient
        old_R = self.R
        new_R = self._apply_current_internal(avg_I, avg_tau, dt)

        # Track quantization error for EC
        if self.config.ec_enabled:
            # The "ideal" change vs actual change
            ideal_dR = self._compute_ideal_dR(avg_I, avg_tau, dt)
            actual_dR = new_R - old_R
            self._ec_residual = ideal_dR - actual_dR

        # Clear buffer
        self._gradient_buffer = []
        self._ga_count = 0

        return new_R

    def _compute_ideal_dR(self, I: float, tau: float, dt: float) -> float:
        """Compute ideal dR without bounds/noise for EC tracking."""
        cfg = self.config
        effective_rate = cfg.drift_rate * tau * cfg.temperature_coupling
        x = self.normalized_R
        window = 1.0 - (2*x - 1)**4

        if cfg.memristor_type == MemristorType.LINEAR:
            return effective_rate * I * dt
        elif cfg.memristor_type == MemristorType.THRESHOLD:
            if abs(I) > cfg.threshold:
                return effective_rate * np.sign(I) * (abs(I) - cfg.threshold) * dt
            return 0.0
        elif cfg.memristor_type == MemristorType.NONLINEAR:
            return effective_rate * np.sinh(I) * window * dt
        elif cfg.memristor_type == MemristorType.SPINTRONIC:
            if abs(I) > cfg.threshold:
                return effective_rate * np.tanh(I) * dt
            return 0.0
        return 0.0

    def _apply_current_internal(self, I: float, tau: float, dt: float) -> float:
        """Internal current application with sparse update check."""
        cfg = self.config
        effective_rate = cfg.drift_rate * tau * cfg.temperature_coupling

        # Compute dR based on memristor type
        x = self.normalized_R
        window = 1.0 - (2*x - 1)**4

        if cfg.memristor_type == MemristorType.LINEAR:
            dR = effective_rate * I * dt
        elif cfg.memristor_type == MemristorType.THRESHOLD:
            if abs(I) > cfg.threshold:
                dR = effective_rate * np.sign(I) * (abs(I) - cfg.threshold) * dt
            else:
                dR = 0.0
        elif cfg.memristor_type == MemristorType.NONLINEAR:
            dR = effective_rate * np.sinh(I) * window * dt
        elif cfg.memristor_type == MemristorType.SPINTRONIC:
            if abs(I) > cfg.threshold:
                dR = effective_rate * np.tanh(I) * dt
            else:
                dR = 0.0
        else:
            dR = 0.0

        # Passive decay
        decay = cfg.decay_rate * (self.R - cfg.R_init) * dt
        dR -= decay

        # Sparse Update check (Tan et al. 2024)
        # Only apply update if change exceeds threshold - improves endurance
        if abs(dR) < cfg.sparse_threshold:
            self._skipped_count += 1
            return self.R  # Skip this update

        # Add noise (only if exceeds energy barrier)
        if cfg.noise_std > 0:
            noise = np.random.normal(0, cfg.noise_std)
            if abs(noise) > cfg.energy_barrier:
                dR += noise * 0.1

        # Update with bounds
        self.R = np.clip(self.R + dR, cfg.R_min, cfg.R_max)
        self._update_count += 1
        self.t += 1
        self.R_history.append(self.R)

        return self.R

    @property
    def endurance_stats(self) -> Dict[str, Any]:
        """Get endurance statistics (updates vs skipped)."""
        total = self._update_count + self._skipped_count
        skip_rate = self._skipped_count / total if total > 0 else 0.0
        return {
            'total_updates': self._update_count,
            'skipped_updates': self._skipped_count,
            'skip_rate': skip_rate,
            'ec_residual': self._ec_residual,
        }

    # =========================================================================
    # EWC (Elastic Weight Consolidation) for Continual Learning
    # =========================================================================

    def update_fisher(self, gradient: float) -> None:
        """
        Update Fisher information (importance for EWC).

        Fisher information measures how sensitive the loss is to this weight.
        High Fisher = important weight = resist change.

        Args:
            gradient: Gradient of loss with respect to this weight
        """
        gamma = self.config.ewc_gamma
        # Online Fisher estimation: F = γF + (1-γ)g²
        self.fisher = gamma * self.fisher + (1 - gamma) * gradient**2

    def get_ewc_penalty(self, old_R: float, ewc_lambda: float = 1000.0) -> float:
        """
        Compute EWC penalty for deviating from old resistance.

        L_ewc = (λ/2) × F × (R - R*)²

        Used to prevent catastrophic forgetting in continual learning.

        Args:
            old_R: Optimal resistance from previous task
            ewc_lambda: Regularization strength

        Returns:
            EWC penalty term
        """
        return 0.5 * ewc_lambda * self.fisher * (self.R - old_R)**2

    # =========================================================================
    # State Persistence
    # =========================================================================

    def save_state(self) -> Dict[str, Any]:
        """Save memristor state for persistence."""
        return {
            'R': self.R,
            'q': self.q,
            'phi': self.phi,
            'fisher': self.fisher,
            't': self.t,
            'R_history': self.R_history.copy(),
            # GA/EC/Sparse state
            'ec_residual': self._ec_residual,
            'update_count': self._update_count,
            'skipped_count': self._skipped_count,
            'config': {
                'R_min': self.config.R_min,
                'R_max': self.config.R_max,
                'R_init': self.config.R_init,
                'memristor_type': self.config.memristor_type.value,
                'drift_rate': self.config.drift_rate,
                'threshold': self.config.threshold,
                'decay_rate': self.config.decay_rate,
                'noise_std': self.config.noise_std,
                'temperature_coupling': self.config.temperature_coupling,
                'energy_barrier': self.config.energy_barrier,
                'ewc_gamma': self.config.ewc_gamma,
                'ga_batch_size': self.config.ga_batch_size,
                'ec_enabled': self.config.ec_enabled,
                'sparse_threshold': self.config.sparse_threshold,
            }
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load memristor state from saved dict."""
        self.R = state['R']
        self.q = state.get('q', 0.0)
        self.phi = state.get('phi', 0.0)
        self.fisher = state.get('fisher', 0.0)
        self.t = state.get('t', 0)
        self.R_history = state.get('R_history', [self.R])

        # GA/EC/Sparse state
        self._ec_residual = state.get('ec_residual', 0.0)
        self._update_count = state.get('update_count', 0)
        self._skipped_count = state.get('skipped_count', 0)
        self._gradient_buffer = []
        self._ga_count = 0

        if 'config' in state:
            cfg = state['config']
            # Parse memristor_type from string if present
            mem_type_str = cfg.get('memristor_type', 'nonlinear')
            mem_type = MemristorType(mem_type_str)
            self.config = MemristorConfig(
                R_min=cfg.get('R_min', 0.1),
                R_max=cfg.get('R_max', 10.0),
                R_init=cfg.get('R_init', 1.0),
                memristor_type=mem_type,
                drift_rate=cfg.get('drift_rate', 0.01),
                threshold=cfg.get('threshold', 0.1),
                decay_rate=cfg.get('decay_rate', 0.001),
                noise_std=cfg.get('noise_std', 0.01),
                temperature_coupling=cfg.get('temperature_coupling', 1.0),
                energy_barrier=cfg.get('energy_barrier', 0.5),
                ewc_gamma=cfg.get('ewc_gamma', 0.9),
                ga_batch_size=cfg.get('ga_batch_size', 8),
                ec_enabled=cfg.get('ec_enabled', True),
                sparse_threshold=cfg.get('sparse_threshold', 0.01),
            )

    def reset(self) -> None:
        """Reset to initial state."""
        self.R = self.config.R_init
        self.q = 0.0
        self.phi = 0.0
        self.fisher = 0.0
        self.t = 0
        self.R_history = [self.R]
        # Reset GA/EC/Sparse state
        self._gradient_buffer = []
        self._ga_count = 0
        self._ec_residual = 0.0
        self._update_count = 0
        self._skipped_count = 0


class MemristorArray:
    """
    Crossbar array of memristors for matrix-vector multiplication.

    In hardware: y = G @ x in O(1) time (Ohm's law + Kirchhoff's law)
    """

    def __init__(self, rows: int, cols: int, config: Optional[MemristorConfig] = None):
        self.rows = rows
        self.cols = cols
        self.config = config or MemristorConfig()
        self.memristors = [
            [VirtualMemristor(self.config) for _ in range(cols)]
            for _ in range(rows)
        ]

    @property
    def conductance_matrix(self) -> np.ndarray:
        """Get conductance matrix G = 1/R."""
        G = np.zeros((self.rows, self.cols))
        for i in range(self.rows):
            for j in range(self.cols):
                G[i, j] = self.memristors[i][j].conductance
        return G

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Matrix-vector multiplication: y = G.T @ x

        In crossbar: rows=inputs, cols=outputs
        G[i,j] connects input i to output j
        y[j] = sum_i(G[i,j] * x[i])
        """
        return self.conductance_matrix.T @ x

    def apply_hebbian_update(
        self,
        pre: np.ndarray,
        post: np.ndarray,
        tau: float = 1.0,
        learning_rate: float = 0.01
    ) -> None:
        """
        Hebbian learning: Δw ∝ pre × post

        Temperature modulates plasticity:
        - High τ = aggressive learning (OOD/low quality)
        - Low τ = conservative learning (protect high-quality memories)
        """
        for i in range(min(len(pre), self.rows)):
            for j in range(min(len(post), self.cols)):
                # Negative I → decrease R → increase G (strengthen connection)
                I = -learning_rate * pre[i] * post[j]
                self.memristors[i][j].apply_current(I, tau=tau)

    def apply_anti_hebbian_update(
        self,
        pre: np.ndarray,
        post: np.ndarray,
        tau: float = 1.0,
        learning_rate: float = 0.01
    ) -> None:
        """
        Anti-Hebbian learning: Δw ∝ -pre × post

        Used for competitive learning and decorrelation.
        """
        for i in range(min(len(pre), self.rows)):
            for j in range(min(len(post), self.cols)):
                I = learning_rate * pre[i] * post[j]  # Positive = increase R
                self.memristors[i][j].apply_current(I, tau=tau)

    def apply_error_update(
        self,
        error: np.ndarray,
        input_pattern: np.ndarray,
        tau: float = 1.0,
        learning_rate: float = 0.01
    ) -> None:
        """
        Error-driven update for supervised learning.

        Δw[i,j] ∝ error[j] × input[i]
        """
        for i in range(min(len(input_pattern), self.rows)):
            for j in range(min(len(error), self.cols)):
                I = -learning_rate * error[j] * input_pattern[i]
                self.memristors[i][j].apply_current(I, tau=tau)

    # =========================================================================
    # Gradient Accumulation (GA) - Array Level
    # From Tan et al. 2024 Siamese learning
    # =========================================================================

    def accumulate_hebbian_update(
        self,
        pre: np.ndarray,
        post: np.ndarray,
        tau: float = 1.0,
        learning_rate: float = 0.01
    ) -> bool:
        """
        Accumulate Hebbian gradients without immediately applying.

        Call flush_all_gradients() when batch is complete.

        Returns:
            True if any memristor's batch is full
        """
        any_full = False
        for i in range(min(len(pre), self.rows)):
            for j in range(min(len(post), self.cols)):
                I = -learning_rate * pre[i] * post[j]
                if self.memristors[i][j].accumulate_gradient(I, tau=tau):
                    any_full = True
        return any_full

    def accumulate_error_update(
        self,
        error: np.ndarray,
        input_pattern: np.ndarray,
        tau: float = 1.0,
        learning_rate: float = 0.01
    ) -> bool:
        """
        Accumulate error-driven gradients without immediately applying.

        Returns:
            True if any memristor's batch is full
        """
        any_full = False
        for i in range(min(len(input_pattern), self.rows)):
            for j in range(min(len(error), self.cols)):
                I = -learning_rate * error[j] * input_pattern[i]
                if self.memristors[i][j].accumulate_gradient(I, tau=tau):
                    any_full = True
        return any_full

    def flush_all_gradients(self, dt: float = 1.0) -> None:
        """Flush accumulated gradients for all memristors."""
        for i in range(self.rows):
            for j in range(self.cols):
                self.memristors[i][j].flush_gradients(dt)

    def get_endurance_stats(self) -> Dict[str, Any]:
        """Get aggregate endurance statistics for the array."""
        total_updates = 0
        total_skipped = 0
        total_ec_residual = 0.0

        for i in range(self.rows):
            for j in range(self.cols):
                stats = self.memristors[i][j].endurance_stats
                total_updates += stats['total_updates']
                total_skipped += stats['skipped_updates']
                total_ec_residual += abs(stats['ec_residual'])

        total = total_updates + total_skipped
        skip_rate = total_skipped / total if total > 0 else 0.0

        return {
            'total_updates': total_updates,
            'skipped_updates': total_skipped,
            'skip_rate': skip_rate,
            'avg_ec_residual': total_ec_residual / (self.rows * self.cols),
            'endurance_gain': f"{1/(1-skip_rate) if skip_rate < 1 else float('inf'):.2f}x",
        }

    # =========================================================================
    # EWC Support
    # =========================================================================

    def get_fisher_matrix(self) -> np.ndarray:
        """Get Fisher information matrix for EWC."""
        F = np.zeros((self.rows, self.cols))
        for i in range(self.rows):
            for j in range(self.cols):
                F[i, j] = self.memristors[i][j].fisher
        return F

    def get_ewc_penalty(self, old_R_matrix: np.ndarray, ewc_lambda: float = 1000.0) -> float:
        """
        Compute total EWC penalty for the array.

        Args:
            old_R_matrix: Resistance matrix from previous task
            ewc_lambda: Regularization strength

        Returns:
            Total EWC penalty
        """
        penalty = 0.0
        for i in range(self.rows):
            for j in range(self.cols):
                penalty += self.memristors[i][j].get_ewc_penalty(
                    old_R_matrix[i, j], ewc_lambda
                )
        return penalty

    # =========================================================================
    # State Persistence
    # =========================================================================

    def save_state(self) -> Dict[str, Any]:
        """Save array state for persistence."""
        return {
            'rows': self.rows,
            'cols': self.cols,
            'memristors': [
                [self.memristors[i][j].save_state() for j in range(self.cols)]
                for i in range(self.rows)
            ]
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load array state from saved dict."""
        for i in range(min(state['rows'], self.rows)):
            for j in range(min(state['cols'], self.cols)):
                self.memristors[i][j].load_state(state['memristors'][i][j])

    @property
    def resistance_matrix(self) -> np.ndarray:
        """Get resistance matrix R."""
        R = np.zeros((self.rows, self.cols))
        for i in range(self.rows):
            for j in range(self.cols):
                R[i, j] = self.memristors[i][j].R
        return R


# ============================================================================
# YRSN Memristor Projection
# ============================================================================

@dataclass
class YRSNMemristorConfig:
    """Configuration for YRSN memristor projection."""
    embed_dim: int = 768        # Input embedding dimension
    rsn_dim: int = 256          # R/S/N projection dimension
    learning_rate: float = 0.01
    memristor_config: Optional[MemristorConfig] = None


class YRSNMemristorProjection:
    """
    YRSN R/S/N projection using memristor crossbar arrays.

    Three separate arrays learn to project embeddings onto R/S/N subspaces:
    - R_array: Projects to Relevant subspace
    - S_array: Projects to Superfluous subspace
    - N_array: Projects to Noise subspace

    Temperature (τ) modulates plasticity:
    - High τ (low quality/OOD) → more learning
    - Low τ (high quality) → protect learned projections (EWC-like)

    This is hardware-faithful: memristor conductance IS the projection weight.
    """

    def __init__(self, config: Optional[YRSNMemristorConfig] = None):
        self.config = config or YRSNMemristorConfig()
        mem_cfg = self.config.memristor_config or MemristorConfig()

        # Three crossbar arrays for R/S/N projection
        self.R_array = MemristorArray(self.config.embed_dim, self.config.rsn_dim, mem_cfg)
        self.S_array = MemristorArray(self.config.embed_dim, self.config.rsn_dim, mem_cfg)
        self.N_array = MemristorArray(self.config.embed_dim, self.config.rsn_dim, mem_cfg)

    def forward(self, embedding: Union[np.ndarray, "torch.Tensor"]) -> Dict[str, Any]:
        """
        Project embedding through R/S/N memristor arrays.

        Device-aware: accepts torch tensors and returns results on the same device.

        Args:
            embedding: Input embedding [embed_dim] - numpy array or torch tensor

        Returns:
            Dict with R, S, N projections and derived metrics.
            If input was a torch tensor, scalar outputs (R, S, N, alpha, etc.) 
            are returned as tensors on the same device.
        """
        # Handle device-awareness
        input_device = None
        input_is_tensor = False

        if TORCH_AVAILABLE and isinstance(embedding, torch.Tensor):
            input_is_tensor = True
            input_device = embedding.device
            embedding_np = embedding.detach().cpu().numpy()
        else:
            embedding_np = embedding

        # Project through each crossbar (O(1) in hardware!)
        R_proj = self.R_array.forward(embedding_np)
        S_proj = self.S_array.forward(embedding_np)
        N_proj = self.N_array.forward(embedding_np)

        # Compute norms as R/S/N scores
        R_score = np.linalg.norm(R_proj)
        S_score = np.linalg.norm(S_proj)
        N_score = np.linalg.norm(N_proj)

        # Normalize to [0, 1]
        total = R_score + S_score + N_score + 1e-8
        R = R_score / total
        S = S_score / total
        N = N_score / total

        # Compute derived metrics
        alpha = R  # α = R / (R + S + N), but already normalized
        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        # Simple ω approximation for base memristor (use BaseLearner for full OOD)
        omega = 1.0 - N
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        # Return on same device if input was tensor
        if input_is_tensor:
            return {
                'R': torch.tensor(R, device=input_device, dtype=torch.float32),
                'S': torch.tensor(S, device=input_device, dtype=torch.float32),
                'N': torch.tensor(N, device=input_device, dtype=torch.float32),
                'R_proj': torch.from_numpy(R_proj).to(input_device),
                'S_proj': torch.from_numpy(S_proj).to(input_device),
                'N_proj': torch.from_numpy(N_proj).to(input_device),
                'alpha': torch.tensor(alpha, device=input_device, dtype=torch.float32),
                'omega': torch.tensor(omega, device=input_device, dtype=torch.float32),
                'alpha_omega': torch.tensor(alpha_omega, device=input_device, dtype=torch.float32),
                'tau': torch.tensor(tau, device=input_device, dtype=torch.float32),
            }

        return {
            'R': R,
            'S': S,
            'N': N,
            'R_proj': R_proj,
            'S_proj': S_proj,
            'N_proj': N_proj,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
        }

    def learn(
        self,
        embedding: Union[np.ndarray, "torch.Tensor"],
        target_R: float,
        target_S: float,
        target_N: float,
        tau: float = 1.0
    ) -> None:
        """
        Learn R/S/N projection via temperature-modulated Hebbian update.

        Device-aware: accepts torch tensors (internally converts to numpy).

        High τ (low quality/OOD) → aggressive learning
        Low τ (high quality) → conservative (protect memories)

        Args:
            embedding: Input embedding (numpy or torch tensor)
            target_R: Target R score (0-1)
            target_S: Target S score (0-1)
            target_N: Target N score (0-1)
            tau: Temperature (from context quality)
        """
        # Convert tensor to numpy if needed
        if TORCH_AVAILABLE and isinstance(embedding, torch.Tensor):
            embedding_np = embedding.detach().cpu().numpy()
        else:
            embedding_np = embedding

        # Current projections (use numpy version for internal computation)
        result = self.forward(embedding_np)

        # Error signals
        R_error = target_R - result['R']
        S_error = target_S - result['S']
        N_error = target_N - result['N']

        # Create target vectors scaled by error
        R_target = np.ones(self.config.rsn_dim) * R_error
        S_target = np.ones(self.config.rsn_dim) * S_error
        N_target = np.ones(self.config.rsn_dim) * N_error

        # Hebbian update: strengthen correct associations
        # τ modulates plasticity - high τ = more learning
        lr = self.config.learning_rate
        self.R_array.apply_hebbian_update(embedding_np, R_target, tau=tau, learning_rate=lr)
        self.S_array.apply_hebbian_update(embedding_np, S_target, tau=tau, learning_rate=lr)
        self.N_array.apply_hebbian_update(embedding_np, N_target, tau=tau, learning_rate=lr)

    def learn_with_ga(
        self,
        embedding: Union[np.ndarray, "torch.Tensor"],
        target_R: float,
        target_S: float,
        target_N: float,
        tau: float = 1.0,
        auto_flush: bool = True
    ) -> bool:
        """
        Learn with Gradient Accumulation (GA) - Tan et al. 2024.

        Device-aware: accepts torch tensors (internally converts to numpy).

        Accumulates gradients across multiple samples before applying updates.
        This reduces write operations, improving memristor endurance.

        Args:
            embedding: Input embedding (numpy or torch tensor)
            target_R/S/N: Target scores (0-1)
            tau: Temperature (from context quality)
            auto_flush: If True, flush when batch is full

        Returns:
            True if gradients were flushed this call
        """
        # Convert tensor to numpy if needed
        if TORCH_AVAILABLE and isinstance(embedding, torch.Tensor):
            embedding_np = embedding.detach().cpu().numpy()
        else:
            embedding_np = embedding

        # Current projections
        result = self.forward(embedding_np)

        # Error signals
        R_error = target_R - result['R']
        S_error = target_S - result['S']
        N_error = target_N - result['N']

        # Create target vectors scaled by error
        R_target = np.ones(self.config.rsn_dim) * R_error
        S_target = np.ones(self.config.rsn_dim) * S_error
        N_target = np.ones(self.config.rsn_dim) * N_error

        # Accumulate gradients (don't apply yet)
        lr = self.config.learning_rate
        r_full = self.R_array.accumulate_hebbian_update(embedding_np, R_target, tau=tau, learning_rate=lr)
        s_full = self.S_array.accumulate_hebbian_update(embedding_np, S_target, tau=tau, learning_rate=lr)
        n_full = self.N_array.accumulate_hebbian_update(embedding_np, N_target, tau=tau, learning_rate=lr)

        any_full = r_full or s_full or n_full

        if auto_flush and any_full:
            self.flush_gradients()
            return True

        return False

    def flush_gradients(self) -> None:
        """
        Flush accumulated gradients in all arrays.

        Call this after accumulating a batch of gradients via learn_with_ga().
        """
        self.R_array.flush_all_gradients()
        self.S_array.flush_all_gradients()
        self.N_array.flush_all_gradients()

    def get_endurance_stats(self) -> Dict[str, Dict[str, Any]]:
        """
        Get endurance statistics for all arrays.

        Shows benefit of GA + Sparse Updates.
        """
        return {
            'R_array': self.R_array.get_endurance_stats(),
            'S_array': self.S_array.get_endurance_stats(),
            'N_array': self.N_array.get_endurance_stats(),
        }

    def get_conductance_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics about learned conductances."""
        def array_stats(arr: MemristorArray) -> Dict[str, float]:
            G = arr.conductance_matrix
            return {
                'mean': float(np.mean(G)),
                'std': float(np.std(G)),
                'min': float(np.min(G)),
                'max': float(np.max(G)),
            }

        return {
            'R_array': array_stats(self.R_array),
            'S_array': array_stats(self.S_array),
            'N_array': array_stats(self.N_array),
        }

    # =========================================================================
    # EWC for Continual Learning
    # =========================================================================

    def snapshot_for_ewc(self) -> Dict[str, np.ndarray]:
        """
        Take snapshot of current resistance matrices for EWC.

        Call this after training on a task to remember optimal weights.

        Returns:
            Dict with R_matrix, S_matrix, N_matrix
        """
        return {
            'R_matrix': self.R_array.resistance_matrix.copy(),
            'S_matrix': self.S_array.resistance_matrix.copy(),
            'N_matrix': self.N_array.resistance_matrix.copy(),
        }

    def get_ewc_penalty(self, snapshot: Dict[str, np.ndarray], ewc_lambda: float = 1000.0) -> float:
        """
        Compute total EWC penalty for all arrays.

        Add this to your loss function to prevent forgetting.

        Args:
            snapshot: From snapshot_for_ewc()
            ewc_lambda: Regularization strength

        Returns:
            Total EWC penalty
        """
        penalty = 0.0
        penalty += self.R_array.get_ewc_penalty(snapshot['R_matrix'], ewc_lambda)
        penalty += self.S_array.get_ewc_penalty(snapshot['S_matrix'], ewc_lambda)
        penalty += self.N_array.get_ewc_penalty(snapshot['N_matrix'], ewc_lambda)
        return penalty

    # =========================================================================
    # State Persistence
    # =========================================================================

    def save_state(self) -> Dict[str, Any]:
        """
        Save full projection state for persistence.

        Use this to checkpoint training or deploy a trained model.

        Returns:
            Dict that can be serialized to JSON/pickle
        """
        return {
            'config': {
                'embed_dim': self.config.embed_dim,
                'rsn_dim': self.config.rsn_dim,
                'learning_rate': self.config.learning_rate,
            },
            'R_array': self.R_array.save_state(),
            'S_array': self.S_array.save_state(),
            'N_array': self.N_array.save_state(),
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """
        Load projection state from saved dict.

        Args:
            state: From save_state()
        """
        self.R_array.load_state(state['R_array'])
        self.S_array.load_state(state['S_array'])
        self.N_array.load_state(state['N_array'])

    @classmethod
    def from_saved_state(cls, state: Dict[str, Any]) -> 'YRSNMemristorProjection':
        """
        Create new projection from saved state.

        Args:
            state: From save_state()

        Returns:
            New YRSNMemristorProjection with loaded weights
        """
        config = YRSNMemristorConfig(
            embed_dim=state['config']['embed_dim'],
            rsn_dim=state['config']['rsn_dim'],
            learning_rate=state['config']['learning_rate'],
        )
        proj = cls(config)
        proj.load_state(state)
        return proj

    # =========================================================================
    # File I/O (numpy-safe persistence)
    # =========================================================================

    def save_to_file(
        self,
        path: Union[str, Path],
        format: str = "auto",
        compress: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Path:
        """
        Save projection state to file with numpy support.

        Args:
            path: Output file path (.json, .pkl, .msgpack, or auto-detect)
            format: "auto", "json", "pickle", or "msgpack"
            compress: Whether to gzip compress (default True)
            metadata: Optional metadata (training info, version, etc.)

        Returns:
            Path to saved file

        Example:
            projection.save_to_file("checkpoint.json.gz")
            projection.save_to_file("model.pkl", compress=False)
        """
        from yrsn.hardware.serialization import save_memristor_state
        return save_memristor_state(
            self.save_state(),
            path,
            format=format,
            compress=compress,
            metadata=metadata,
        )

    @classmethod
    def load_from_file(
        cls,
        path: Union[str, Path],
        format: str = "auto",
    ) -> 'YRSNMemristorProjection':
        """
        Load projection from file.

        Args:
            path: Input file path
            format: "auto", "json", "pickle", or "msgpack"

        Returns:
            New YRSNMemristorProjection with loaded weights

        Example:
            projection = YRSNMemristorProjection.load_from_file("checkpoint.json.gz")
        """
        from yrsn.hardware.serialization import load_memristor_state
        state = load_memristor_state(path, format=format)
        return cls.from_saved_state(state)


# ============================================================================
# Quantized Bit-Slicing
# ============================================================================

def quantize_embedding(
    embedding: np.ndarray,
    bits: int = 3,
    symmetric: bool = True
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """
    Quantize embedding to n-bit representation (true bit-slicing).

    Like RRAM paper: multiple precision levels for efficiency.

    Args:
        embedding: Input embedding
        bits: Number of bits (3 = 8 levels)
        symmetric: Whether to use symmetric quantization

    Returns:
        Tuple of (quantized_embedding, metadata)
    """
    levels = 2 ** bits

    if symmetric:
        # Symmetric: [-max, max] → [-levels/2, levels/2-1]
        max_val = np.max(np.abs(embedding))
        scale = max_val / (levels // 2) if max_val > 0 else 1.0
        quantized = np.round(embedding / scale)
        quantized = np.clip(quantized, -levels//2, levels//2 - 1)
    else:
        # Asymmetric: [min, max] → [0, levels-1]
        min_val, max_val = np.min(embedding), np.max(embedding)
        scale = (max_val - min_val) / (levels - 1) if max_val > min_val else 1.0
        quantized = np.round((embedding - min_val) / scale)
        quantized = np.clip(quantized, 0, levels - 1)

    metadata = {
        'bits': bits,
        'levels': levels,
        'scale': scale,
        'symmetric': symmetric,
        'min_val': float(np.min(embedding)),
        'max_val': float(np.max(embedding)),
    }

    return quantized.astype(np.int8), metadata


def dequantize_embedding(
    quantized: np.ndarray,
    metadata: Dict[str, Any]
) -> np.ndarray:
    """Dequantize embedding back to float."""
    if metadata['symmetric']:
        return quantized.astype(np.float32) * metadata['scale']
    else:
        return quantized.astype(np.float32) * metadata['scale'] + metadata['min_val']


class BitSlicedMemristorProjection(YRSNMemristorProjection):
    """
    YRSN projection with true bit-sliced quantization.

    Combines:
    1. Quantized embeddings (3-bit like RRAM paper)
    2. Memristor crossbar projection
    3. Multiple precision slices
    """

    def __init__(
        self,
        config: Optional[YRSNMemristorConfig] = None,
        bits: int = 3
    ):
        super().__init__(config)
        self.bits = bits
        self.slices = bits  # One slice per bit

    def forward_quantized(
        self,
        embedding: Union[np.ndarray, "torch.Tensor"],
        slice_weights: Optional[List[float]] = None
    ) -> Dict[str, Any]:
        """
        Project with bit-sliced quantization.

        Device-aware: accepts torch tensors and returns results on the same device.

        Args:
            embedding: Input embedding (numpy or torch tensor)
            slice_weights: Optional weights per slice [MSB, ..., LSB]

        Returns:
            Dict with R/S/N and quantization info
        """
        # Handle device-awareness
        input_device = None
        input_is_tensor = False

        if TORCH_AVAILABLE and isinstance(embedding, torch.Tensor):
            input_is_tensor = True
            input_device = embedding.device
            embedding_np = embedding.detach().cpu().numpy()
        else:
            embedding_np = embedding

        # Quantize input
        quantized, quant_meta = quantize_embedding(embedding_np, bits=self.bits)

        # Default weights: MSB = 4, middle = 2, LSB = 1
        if slice_weights is None:
            slice_weights = [2**(self.bits - 1 - i) for i in range(self.bits)]

        # Decompose into bit slices
        slices = []
        for i in range(self.bits):
            bit_slice = (quantized >> i) & 1  # Extract bit i
            slices.append(bit_slice.astype(np.float32))

        # Project each slice and weight-combine
        R_total = np.zeros(self.config.rsn_dim)
        S_total = np.zeros(self.config.rsn_dim)
        N_total = np.zeros(self.config.rsn_dim)

        for i, (bit_slice, weight) in enumerate(zip(slices, slice_weights)):
            R_total += weight * self.R_array.forward(bit_slice)
            S_total += weight * self.S_array.forward(bit_slice)
            N_total += weight * self.N_array.forward(bit_slice)

        # Normalize
        R_score = np.linalg.norm(R_total)
        S_score = np.linalg.norm(S_total)
        N_score = np.linalg.norm(N_total)
        total = R_score + S_score + N_score + 1e-8

        R = R_score / total
        S = S_score / total
        N = N_score / total

        alpha = R
        # ω defaults to 1.0 (in-distribution) for memristor simulation
        # In production, ω should be computed from OOD detection
        omega = 1.0
        quality_prior = 0.5
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        # Return on same device if input was tensor
        if input_is_tensor:
            return {
                'R': torch.tensor(R, device=input_device, dtype=torch.float32),
                'S': torch.tensor(S, device=input_device, dtype=torch.float32),
                'N': torch.tensor(N, device=input_device, dtype=torch.float32),
                'alpha': torch.tensor(alpha, device=input_device, dtype=torch.float32),
                'omega': torch.tensor(omega, device=input_device, dtype=torch.float32),
                'alpha_omega': torch.tensor(alpha_omega, device=input_device, dtype=torch.float32),
                'tau': torch.tensor(tau, device=input_device, dtype=torch.float32),
                'quantization': quant_meta,
                'slice_weights': slice_weights,
            }

        return {
            'R': R,
            'S': S,
            'N': N,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
            'quantization': quant_meta,
            'slice_weights': slice_weights,
        }


# ============================================================================
# Example Usage
# ============================================================================

def example_usage():
    """Demonstrate YRSN memristor projection."""
    print("=== YRSN Memristor Projection Demo ===\n")

    # Configuration with GA/EC/Sparse settings
    # Use permissive settings for demo to show learning
    mem_cfg = MemristorConfig(
        ga_batch_size=8,          # Batch 8 gradients before update
        ec_enabled=True,          # Track quantization errors
        sparse_threshold=0.0001,  # Low threshold for demo
        energy_barrier=0.01,      # Lower barrier for demo
        drift_rate=0.1,           # Higher drift rate
    )
    config = YRSNMemristorConfig(
        embed_dim=128,  # Smaller for demo
        rsn_dim=32,
        learning_rate=0.2,        # Higher LR for demo
        memristor_config=mem_cfg,
    )

    # Initialize projection
    proj = YRSNMemristorProjection(config)

    # Random embedding
    embedding = np.random.randn(128).astype(np.float32)

    # Initial projection (random weights)
    result = proj.forward(embedding)
    print("Initial projection:")
    print(f"  R={result['R']:.3f}, S={result['S']:.3f}, N={result['N']:.3f}")
    print(f"  alpha={result['alpha']:.3f}, tau={result['tau']:.3f}")

    # Learn: this embedding should be high-R
    print("\nLearning (target: R=0.8, S=0.1, N=0.1)...")
    for i in range(100):
        tau = result['tau']  # Use current tau for plasticity
        proj.learn(embedding, target_R=0.8, target_S=0.1, target_N=0.1, tau=tau)
        result = proj.forward(embedding)

    print("After learning:")
    print(f"  R={result['R']:.3f}, S={result['S']:.3f}, N={result['N']:.3f}")
    print(f"  alpha={result['alpha']:.3f}, tau={result['tau']:.3f}")

    # Conductance stats
    stats = proj.get_conductance_stats()
    print("\nConductance statistics:")
    for name, s in stats.items():
        print(f"  {name}: mean={s['mean']:.3f}, std={s['std']:.3f}")

    # =========================================================================
    # Gradient Accumulation (GA) Demo - Tan et al. 2024
    # =========================================================================
    print("\n=== Gradient Accumulation (GA) Demo ===\n")

    # Fresh projection for GA demo
    proj_ga = YRSNMemristorProjection(config)

    # Generate batch of training samples
    n_samples = 50
    embeddings = [np.random.randn(128).astype(np.float32) for _ in range(n_samples)]

    # Train WITH gradient accumulation
    print(f"Training {n_samples} samples with GA (batch_size={mem_cfg.ga_batch_size})...")
    for emb in embeddings:
        result = proj_ga.forward(emb)
        proj_ga.learn_with_ga(
            emb,
            target_R=0.7, target_S=0.2, target_N=0.1,
            tau=result['tau'],
            auto_flush=True
        )

    # Flush any remaining gradients
    proj_ga.flush_gradients()

    # Check endurance stats
    endurance = proj_ga.get_endurance_stats()
    print("\nEndurance statistics (benefit of GA + Sparse Updates):")
    for name, stats in endurance.items():
        print(f"  {name}:")
        print(f"    Updates: {stats['total_updates']}, Skipped: {stats['skipped_updates']}")
        print(f"    Skip rate: {stats['skip_rate']:.1%} -> {stats['endurance_gain']} endurance gain")

    # =========================================================================
    # Bit-sliced version
    # =========================================================================
    print("\n=== Bit-Sliced Projection ===\n")

    bs_proj = BitSlicedMemristorProjection(config, bits=3)
    result_q = bs_proj.forward_quantized(embedding)
    print("Quantized projection (3-bit):")
    print(f"  R={result_q['R']:.3f}, S={result_q['S']:.3f}, N={result_q['N']:.3f}")
    print(f"  Slice weights: {result_q['slice_weights']}")
    print(f"  Quantization: {result_q['quantization']['bits']} bits, "
          f"{result_q['quantization']['levels']} levels")


if __name__ == "__main__":
    example_usage()
