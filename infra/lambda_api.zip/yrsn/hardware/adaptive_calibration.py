"""
YRSN Adaptive Memristor Calibration
====================================

Learns optimal memristor parameters FROM DATA - no hardcoding!

This is the key YRSN principle: the system adapts to whatever data it encounters.

Discovers:
1. sparse_threshold - from gradient distribution percentiles
2. learning_rate - from gradient magnitude statistics
3. drift_rate - from input signal characteristics
4. ga_batch_size - from convergence/endurance trade-off
5. energy_barrier - from noise floor estimation

Usage:
    from yrsn.hardware.adaptive_calibration import (
        AdaptiveMemristorCalibrator,
        discover_optimal_config
    )

    calibrator = AdaptiveMemristorCalibrator()
    config = calibrator.calibrate(X_train, targets)
    # Returns MemristorConfig with learned parameters

Author: YRSN Framework
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Tuple, List, Callable
import numpy as np

from .memristor_projection import (
    MemristorConfig,
    MemristorType,
    YRSNMemristorConfig,
    YRSNMemristorProjection,
)

# Parameter transparency
try:
    from ..core.parameter_transparency import (
        ParameterRegistry,
        ParameterSource,
        ParameterCategory,
        register_memristor_params,
    )
    HAS_TRANSPARENCY = True
except ImportError:
    HAS_TRANSPARENCY = False


# =============================================================================
# RSN_DIM PRESETS
# =============================================================================
# RSN_DIM is a compute/capacity tradeoff, not worth adaptive discovery.
# Simple presets based on sqrt(embed_dim) work well.

RSN_DIM_PRESETS = {
    'small': 0.5,    # Fast, low memory, simple tasks
    'medium': 1.0,   # Balanced (default)
    'large': 2.0,    # More capacity, slower
    'xlarge': 4.0,   # Maximum capacity, slowest
}


def get_rsn_dim(embed_dim: int, size: str = 'medium') -> int:
    """
    Get RSN_DIM based on input dimension and size preference.

    RSN_DIM controls the projection space for R/S/N classification.
    Unlike other parameters, this is a compute/capacity tradeoff
    that doesn't benefit from adaptive discovery.

    Formula: rsn_dim ≈ sqrt(embed_dim) × multiplier

    Args:
        embed_dim: Input dimension (e.g., 784 for MNIST, 3072 for CIFAR)
        size: One of 'small', 'medium', 'large', 'xlarge'

    Returns:
        Recommended RSN_DIM

    Examples:
        >>> get_rsn_dim(784, 'medium')   # MNIST
        28
        >>> get_rsn_dim(784, 'small')    # MNIST, fast
        14
        >>> get_rsn_dim(3072, 'medium')  # CIFAR
        55

    Tradeoffs:
        | Size   | Speed  | Capacity | Use case                    |
        |--------|--------|----------|-----------------------------|
        | small  | Fast   | Low      | Quick experiments, simple   |
        | medium | Medium | Medium   | Default, most tasks         |
        | large  | Slow   | High     | Complex tasks, fine-grained |
        | xlarge | Slowest| Highest  | Maximum accuracy needed     |
    """
    if size not in RSN_DIM_PRESETS:
        raise ValueError(f"size must be one of {list(RSN_DIM_PRESETS.keys())}, got '{size}'")

    base = int(np.sqrt(embed_dim))
    multiplier = RSN_DIM_PRESETS[size]
    return max(8, int(base * multiplier))  # Minimum 8 for stability


# =============================================================================
# CALIBRATION RESULT
# =============================================================================

@dataclass
class CalibrationResult:
    """
    Result of adaptive calibration.

    Contains discovered parameters and diagnostics.
    """
    # Discovered parameters
    sparse_threshold: float
    learning_rate: float
    drift_rate: float
    ga_batch_size: int
    energy_barrier: float

    # Diagnostics
    gradient_stats: Dict[str, float] = field(default_factory=dict)
    signal_stats: Dict[str, float] = field(default_factory=dict)
    noise_stats: Dict[str, float] = field(default_factory=dict)

    # Validation results
    expected_skip_rate: float = 0.0
    expected_accuracy: float = 0.0
    convergence_estimate: int = 0  # Estimated samples to converge

    # Metadata
    n_samples_probed: int = 0
    calibration_time_ms: float = 0.0

    def to_memristor_config(self) -> MemristorConfig:
        """Convert to MemristorConfig for use with memristor arrays."""
        return MemristorConfig(
            sparse_threshold=self.sparse_threshold,
            drift_rate=self.drift_rate,
            ga_batch_size=self.ga_batch_size,
            energy_barrier=self.energy_barrier,
            ec_enabled=True,
            # Keep defaults for physical parameters
            R_min=0.1,
            R_max=10.0,
            R_init=1.0,
            memristor_type=MemristorType.NONLINEAR,
            decay_rate=0.001,
            noise_std=0.01,
            temperature_coupling=1.0,
        )

    def to_yrsn_config(self, embed_dim: int = 784, rsn_dim: int = 32) -> YRSNMemristorConfig:
        """Convert to full YRSN config."""
        return YRSNMemristorConfig(
            embed_dim=embed_dim,
            rsn_dim=rsn_dim,
            learning_rate=self.learning_rate,
            memristor_config=self.to_memristor_config(),
        )

    def register_for_transparency(self) -> None:
        """Register discovered parameters for audit trail."""
        if not HAS_TRANSPARENCY:
            return

        register_memristor_params(
            sparse_threshold=self.sparse_threshold,
            learning_rate=self.learning_rate,
            drift_rate=self.drift_rate,
            ga_batch_size=self.ga_batch_size,
            energy_barrier=self.energy_barrier,
            source=ParameterSource.ADAPTIVE,
            discovery_method='adaptive_calibration',
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for logging/saving."""
        return {
            'sparse_threshold': self.sparse_threshold,
            'learning_rate': self.learning_rate,
            'drift_rate': self.drift_rate,
            'ga_batch_size': self.ga_batch_size,
            'energy_barrier': self.energy_barrier,
            'gradient_stats': self.gradient_stats,
            'signal_stats': self.signal_stats,
            'noise_stats': self.noise_stats,
            'expected_skip_rate': self.expected_skip_rate,
            'expected_accuracy': self.expected_accuracy,
            'convergence_estimate': self.convergence_estimate,
            'n_samples_probed': self.n_samples_probed,
            'calibration_time_ms': self.calibration_time_ms,
        }


# =============================================================================
# ADAPTIVE CALIBRATOR
# =============================================================================

class AdaptiveMemristorCalibrator:
    """
    Adaptive calibration for memristor parameters.

    YRSN learns its own parameters - no hardcoding!

    The calibrator:
    1. Probes gradient magnitudes with no filtering
    2. Analyzes input signal characteristics
    3. Estimates noise floor
    4. Discovers optimal parameters from distributions

    Example:
        calibrator = AdaptiveMemristorCalibrator()
        result = calibrator.calibrate(X_train, y_train_targets)

        # Use discovered config
        proj = YRSNMemristorProjection(result.to_yrsn_config())
    """

    def __init__(
        self,
        target_skip_rate: float = 0.5,
        target_accuracy: float = 0.6,
        n_probe_samples: int = 50,
        seed: int = 42,
    ):
        """
        Initialize calibrator.

        Args:
            target_skip_rate: Desired skip rate for endurance (0.5 = 2x endurance)
            target_accuracy: Minimum acceptable accuracy
            n_probe_samples: Number of samples to probe for calibration
            seed: Random seed for reproducibility
        """
        self.target_skip_rate = target_skip_rate
        self.target_accuracy = target_accuracy
        self.n_probe_samples = n_probe_samples
        self.seed = seed

        # Internal state
        self._gradient_mags: Optional[np.ndarray] = None
        self._signal_mags: Optional[np.ndarray] = None
        self._noise_estimates: Optional[np.ndarray] = None

    def calibrate(
        self,
        X: np.ndarray,
        targets: np.ndarray,
        rsn_dim: int = 32,
        verbose: bool = True,
    ) -> CalibrationResult:
        """
        Discover optimal parameters from data.

        Args:
            X: Training data [n_samples, embed_dim]
            targets: Target R/S/N values [n_samples, 3]
            rsn_dim: Dimension of R/S/N projection
            verbose: Print progress

        Returns:
            CalibrationResult with discovered parameters
        """
        import time
        start_time = time.time()

        np.random.seed(self.seed)

        if verbose:
            print("=" * 60)
            print(" ADAPTIVE MEMRISTOR CALIBRATION")
            print(" Learning parameters from data distribution...")
            print("=" * 60)

        # Phase 1: Probe gradients
        if verbose:
            print("\n Phase 1: Probing gradient magnitudes...")
        gradient_stats = self._probe_gradients(X, targets, rsn_dim, verbose)

        # Phase 2: Analyze input signals
        if verbose:
            print("\n Phase 2: Analyzing input signal characteristics...")
        signal_stats = self._analyze_signals(X, verbose)

        # Phase 3: Estimate noise floor
        if verbose:
            print("\n Phase 3: Estimating noise floor...")
        noise_stats = self._estimate_noise(X, verbose)

        # Phase 4: Discover parameters
        if verbose:
            print("\n Phase 4: Computing optimal parameters...")

        # 4a. Sparse threshold from gradient percentile
        sparse_threshold = self._discover_sparse_threshold(gradient_stats, verbose)

        # 4b. Learning rate from gradient magnitude
        learning_rate = self._discover_learning_rate(gradient_stats, signal_stats, verbose)

        # 4c. Drift rate from signal characteristics
        drift_rate = self._discover_drift_rate(signal_stats, verbose)

        # 4d. GA batch size from convergence estimate
        ga_batch_size = self._discover_ga_batch_size(gradient_stats, verbose)

        # 4e. Energy barrier from noise floor
        energy_barrier = self._discover_energy_barrier(noise_stats, verbose)

        # Phase 5: Validate
        if verbose:
            print("\n Phase 5: Validating discovered parameters...")
        expected_skip, expected_acc = self._validate_parameters(
            X, targets, rsn_dim,
            sparse_threshold, learning_rate, drift_rate,
            ga_batch_size, energy_barrier,
            verbose
        )

        calibration_time = (time.time() - start_time) * 1000

        result = CalibrationResult(
            sparse_threshold=sparse_threshold,
            learning_rate=learning_rate,
            drift_rate=drift_rate,
            ga_batch_size=ga_batch_size,
            energy_barrier=energy_barrier,
            gradient_stats=gradient_stats,
            signal_stats=signal_stats,
            noise_stats=noise_stats,
            expected_skip_rate=expected_skip,
            expected_accuracy=expected_acc,
            convergence_estimate=self._estimate_convergence(gradient_stats, learning_rate),
            n_samples_probed=min(self.n_probe_samples, len(X)),
            calibration_time_ms=calibration_time,
        )

        if verbose:
            print("\n" + "=" * 60)
            print(" CALIBRATION COMPLETE")
            print("=" * 60)
            print(f"\n Discovered parameters:")
            print(f"   sparse_threshold: {sparse_threshold:.6f}")
            print(f"   learning_rate:    {learning_rate:.4f}")
            print(f"   drift_rate:       {drift_rate:.4f}")
            print(f"   ga_batch_size:    {ga_batch_size}")
            print(f"   energy_barrier:   {energy_barrier:.4f}")
            print(f"\n Expected performance:")
            print(f"   Skip rate: ~{expected_skip*100:.0f}%")
            print(f"   Accuracy:  ~{expected_acc*100:.0f}%")
            print(f"   Endurance: ~{1/(1-expected_skip):.1f}x")
            print(f"\n Calibration time: {calibration_time:.1f}ms")
            print("=" * 60)

        # Register for transparency/audit
        result.register_for_transparency()

        return result

    # =========================================================================
    # PHASE 1: Gradient Probing
    # =========================================================================

    def _probe_gradients(
        self,
        X: np.ndarray,
        targets: np.ndarray,
        rsn_dim: int,
        verbose: bool,
    ) -> Dict[str, float]:
        """
        Probe gradient magnitudes with NO filtering.

        Returns distribution statistics.
        """
        # Create projection with NO sparse threshold
        mem_cfg = MemristorConfig(
            ga_batch_size=8,
            ec_enabled=True,
            sparse_threshold=0.0,  # Capture ALL gradients
            drift_rate=0.15,
            energy_barrier=0.001,
        )
        config = YRSNMemristorConfig(
            embed_dim=X.shape[1],
            rsn_dim=rsn_dim,
            learning_rate=0.3,
            memristor_config=mem_cfg,
        )
        proj = YRSNMemristorProjection(config)

        # Collect gradient magnitudes
        gradient_mags = []
        n_samples = min(self.n_probe_samples, len(X))
        indices = np.random.choice(len(X), n_samples, replace=False)

        for idx in indices:
            result = proj.forward(X[idx])
            t = targets[idx]
            tau = result['tau']

            # Compute gradient magnitudes (approximation)
            errors = [t[0] - result['R'], t[1] - result['S'], t[2] - result['N']]
            for error in errors:
                for val in X[idx]:
                    # grad_mag = lr * input * error * drift * tau
                    grad_mag = abs(0.3 * val * error * 0.15 * tau)
                    if grad_mag > 0:
                        gradient_mags.append(grad_mag)

            # Train to get realistic evolving gradients
            proj.learn_with_ga(X[idx], t[0], t[1], t[2], tau=tau)

        proj.flush_gradients()

        self._gradient_mags = np.array(gradient_mags)

        stats = {
            'count': len(gradient_mags),
            'min': float(np.min(gradient_mags)),
            'max': float(np.max(gradient_mags)),
            'mean': float(np.mean(gradient_mags)),
            'std': float(np.std(gradient_mags)),
            'median': float(np.median(gradient_mags)),
            'p25': float(np.percentile(gradient_mags, 25)),
            'p50': float(np.percentile(gradient_mags, 50)),
            'p75': float(np.percentile(gradient_mags, 75)),
            'p90': float(np.percentile(gradient_mags, 90)),
            'p95': float(np.percentile(gradient_mags, 95)),
            'p99': float(np.percentile(gradient_mags, 99)),
        }

        if verbose:
            print(f"   Collected {stats['count']} gradient samples")
            print(f"   Range: [{stats['min']:.6f}, {stats['max']:.6f}]")
            print(f"   Mean: {stats['mean']:.6f}, Std: {stats['std']:.6f}")

        return stats

    # =========================================================================
    # PHASE 2: Signal Analysis
    # =========================================================================

    def _analyze_signals(
        self,
        X: np.ndarray,
        verbose: bool,
    ) -> Dict[str, float]:
        """
        Analyze input signal characteristics.

        Used to calibrate drift_rate and learning_rate.
        """
        n_samples = min(self.n_probe_samples, len(X))
        indices = np.random.choice(len(X), n_samples, replace=False)
        samples = X[indices]

        # Flatten all signals
        all_signals = samples.flatten()
        self._signal_mags = np.abs(all_signals)

        # Compute statistics
        stats = {
            'mean_abs': float(np.mean(np.abs(all_signals))),
            'std': float(np.std(all_signals)),
            'max_abs': float(np.max(np.abs(all_signals))),
            'sparsity': float(np.mean(np.abs(all_signals) < 0.01)),  # % near zero
            'dynamic_range': float(np.max(np.abs(all_signals)) / (np.mean(np.abs(all_signals)) + 1e-8)),
            'p90_abs': float(np.percentile(np.abs(all_signals), 90)),
        }

        if verbose:
            print(f"   Mean |signal|: {stats['mean_abs']:.4f}")
            print(f"   Dynamic range: {stats['dynamic_range']:.1f}x")
            print(f"   Sparsity: {stats['sparsity']*100:.1f}% near zero")

        return stats

    # =========================================================================
    # PHASE 3: Noise Estimation
    # =========================================================================

    def _estimate_noise(
        self,
        X: np.ndarray,
        verbose: bool,
    ) -> Dict[str, float]:
        """
        Estimate noise floor in data.

        Used to calibrate energy_barrier.
        """
        n_samples = min(self.n_probe_samples, len(X))
        indices = np.random.choice(len(X), n_samples, replace=False)
        samples = X[indices]

        # Estimate noise via local variance (high-freq component)
        # Simple approach: difference between adjacent samples
        noise_estimates = []
        for sample in samples:
            # Local differences approximate noise
            diffs = np.abs(np.diff(sample))
            noise_estimates.extend(diffs)

        self._noise_estimates = np.array(noise_estimates)

        stats = {
            'mean': float(np.mean(noise_estimates)),
            'std': float(np.std(noise_estimates)),
            'p10': float(np.percentile(noise_estimates, 10)),  # Noise floor
            'p50': float(np.percentile(noise_estimates, 50)),
            'p90': float(np.percentile(noise_estimates, 90)),
        }

        if verbose:
            print(f"   Estimated noise floor (p10): {stats['p10']:.6f}")
            print(f"   Median noise: {stats['p50']:.6f}")

        return stats

    # =========================================================================
    # PHASE 4: Parameter Discovery
    # =========================================================================

    def _discover_sparse_threshold(
        self,
        gradient_stats: Dict[str, float],
        verbose: bool,
    ) -> float:
        """
        Discover sparse_threshold from gradient distribution.

        The threshold that skips X% of updates is the X-th percentile.
        """
        if self._gradient_mags is None or len(self._gradient_mags) == 0:
            return 0.0001  # Fallback

        # Use target skip rate to determine percentile
        threshold = np.percentile(self._gradient_mags, self.target_skip_rate * 100)

        if verbose:
            print(f"   Target skip rate: {self.target_skip_rate*100:.0f}%")
            print(f"   -> sparse_threshold = {threshold:.6f}")

        return float(threshold)

    def _discover_learning_rate(
        self,
        gradient_stats: Dict[str, float],
        signal_stats: Dict[str, float],
        verbose: bool,
    ) -> float:
        """
        Discover learning_rate from gradient and signal statistics.

        Goal: Gradients should be in a reasonable range for memristor updates.
        """
        # Scale LR inversely with signal magnitude
        # If signals are large, need smaller LR to prevent overshooting
        mean_signal = signal_stats['mean_abs']

        # Target: gradient magnitudes around 0.01-0.1 for memristor stability
        target_grad_mag = 0.05
        current_grad_mag = gradient_stats['mean']

        # Adjust based on ratio
        if current_grad_mag > 0:
            scale_factor = target_grad_mag / current_grad_mag
            # Clamp to reasonable range
            lr = np.clip(0.3 * scale_factor, 0.01, 1.0)
        else:
            lr = 0.1  # Default

        if verbose:
            print(f"   Target gradient mag: {target_grad_mag:.4f}")
            print(f"   Current gradient mag: {current_grad_mag:.4f}")
            print(f"   -> learning_rate = {lr:.4f}")

        return float(lr)

    def _discover_drift_rate(
        self,
        signal_stats: Dict[str, float],
        verbose: bool,
    ) -> float:
        """
        Discover drift_rate from signal characteristics.

        drift_rate controls memristor plasticity.
        """
        # Higher dynamic range -> lower drift rate (more stable)
        # Lower dynamic range -> higher drift rate (more responsive)
        dynamic_range = signal_stats['dynamic_range']

        # Inverse relationship, clamped
        base_drift = 0.15
        if dynamic_range > 10:
            drift_rate = base_drift / (dynamic_range / 10)
        else:
            drift_rate = base_drift

        drift_rate = np.clip(drift_rate, 0.01, 0.5)

        if verbose:
            print(f"   Dynamic range: {dynamic_range:.1f}x")
            print(f"   -> drift_rate = {drift_rate:.4f}")

        return float(drift_rate)

    def _discover_ga_batch_size(
        self,
        gradient_stats: Dict[str, float],
        verbose: bool,
    ) -> int:
        """
        Discover ga_batch_size from gradient variance.

        High variance -> larger batches (more averaging)
        Low variance -> smaller batches (faster updates)
        """
        # Coefficient of variation (CV) = std / mean
        cv = gradient_stats['std'] / (gradient_stats['mean'] + 1e-8)

        # Higher CV -> larger batch
        if cv > 2.0:
            batch_size = 16
        elif cv > 1.0:
            batch_size = 8
        elif cv > 0.5:
            batch_size = 4
        else:
            batch_size = 2

        if verbose:
            print(f"   Gradient CV (std/mean): {cv:.2f}")
            print(f"   -> ga_batch_size = {batch_size}")

        return batch_size

    def _discover_energy_barrier(
        self,
        noise_stats: Dict[str, float],
        verbose: bool,
    ) -> float:
        """
        Discover energy_barrier from noise floor.

        Prevents thermal noise from causing unwanted state changes.
        """
        # Energy barrier should be above noise floor
        # Use p10 (10th percentile) as noise floor estimate
        noise_floor = noise_stats['p10']

        # Set barrier slightly above noise floor
        energy_barrier = noise_floor * 2.0

        # Clamp to reasonable range
        energy_barrier = np.clip(energy_barrier, 0.001, 1.0)

        if verbose:
            print(f"   Noise floor (p10): {noise_floor:.6f}")
            print(f"   -> energy_barrier = {energy_barrier:.4f}")

        return float(energy_barrier)

    # =========================================================================
    # PHASE 5: Validation
    # =========================================================================

    def _validate_parameters(
        self,
        X: np.ndarray,
        targets: np.ndarray,
        rsn_dim: int,
        sparse_threshold: float,
        learning_rate: float,
        drift_rate: float,
        ga_batch_size: int,
        energy_barrier: float,
        verbose: bool,
    ) -> Tuple[float, float]:
        """
        Quick validation of discovered parameters.

        Returns (expected_skip_rate, expected_accuracy).
        """
        # Create config with discovered parameters
        mem_cfg = MemristorConfig(
            ga_batch_size=ga_batch_size,
            ec_enabled=True,
            sparse_threshold=sparse_threshold,
            drift_rate=drift_rate,
            energy_barrier=energy_barrier,
        )
        config = YRSNMemristorConfig(
            embed_dim=X.shape[1],
            rsn_dim=rsn_dim,
            learning_rate=learning_rate,
            memristor_config=mem_cfg,
        )

        proj = YRSNMemristorProjection(config)

        # Quick training
        n_train = min(100, len(X))
        train_indices = np.random.choice(len(X), n_train, replace=False)

        for idx in train_indices:
            result = proj.forward(X[idx])
            t = targets[idx]
            proj.learn_with_ga(X[idx], t[0], t[1], t[2], tau=result['tau'])

        proj.flush_gradients()

        # Get endurance stats
        stats = proj.get_endurance_stats()
        total_updates = sum(s['total_updates'] for s in stats.values())
        total_skipped = sum(s['skipped_updates'] for s in stats.values())
        total = total_updates + total_skipped
        skip_rate = total_skipped / total if total > 0 else 0.0

        # Quick accuracy test
        n_test = min(50, len(X))
        test_indices = np.random.choice(len(X), n_test, replace=False)

        correct = 0
        for idx in test_indices:
            result = proj.forward(X[idx])
            pred = np.argmax([result['R'], result['S'], result['N']])
            actual = np.argmax(targets[idx])
            if pred == actual:
                correct += 1

        accuracy = correct / n_test

        if verbose:
            print(f"   Validation skip rate: {skip_rate*100:.1f}%")
            print(f"   Validation accuracy: {accuracy*100:.1f}%")

        return skip_rate, accuracy

    def _estimate_convergence(
        self,
        gradient_stats: Dict[str, float],
        learning_rate: float,
    ) -> int:
        """
        Estimate number of samples needed to converge.
        """
        # Rough estimate based on gradient magnitude and LR
        # More gradients needed if they're small or LR is low
        grad_scale = gradient_stats['mean'] * learning_rate
        if grad_scale > 0.01:
            return 100
        elif grad_scale > 0.001:
            return 500
        else:
            return 1000


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def discover_optimal_config(
    X: np.ndarray,
    targets: np.ndarray,
    target_skip_rate: float = 0.5,
    rsn_dim: int = 32,
    verbose: bool = True,
    seed: int = 42,
) -> YRSNMemristorConfig:
    """
    One-liner to discover optimal config from data.

    Example:
        config = discover_optimal_config(X_train, y_train_targets)
        proj = YRSNMemristorProjection(config)
    """
    calibrator = AdaptiveMemristorCalibrator(
        target_skip_rate=target_skip_rate,
        seed=seed,
    )
    result = calibrator.calibrate(X, targets, rsn_dim=rsn_dim, verbose=verbose)
    return result.to_yrsn_config(embed_dim=X.shape[1], rsn_dim=rsn_dim)


def quick_calibrate(
    X: np.ndarray,
    targets: np.ndarray,
    n_samples: int = 30,
) -> CalibrationResult:
    """
    Fast calibration with minimal samples.

    Good for quick experiments or when data is limited.
    """
    calibrator = AdaptiveMemristorCalibrator(
        n_probe_samples=n_samples,
    )
    return calibrator.calibrate(X, targets, verbose=False)


# =============================================================================
# ADAPTIVE ADJUSTMENT (Runtime)
# =============================================================================

class RuntimeCalibrator:
    """
    Runtime adaptive adjustment of parameters.

    Monitors performance and adjusts parameters during training.
    Use when initial calibration may not be optimal.

    Example:
        runtime_cal = RuntimeCalibrator(proj)

        for batch in data:
            # Train
            loss = train_step(batch)

            # Check if adjustment needed
            if runtime_cal.should_adjust():
                new_config = runtime_cal.adjust(loss, skip_rate)
                proj.update_config(new_config)
    """

    def __init__(
        self,
        initial_config: CalibrationResult,
        adjustment_interval: int = 100,
        skip_rate_tolerance: float = 0.1,
    ):
        self.config = initial_config
        self.adjustment_interval = adjustment_interval
        self.skip_rate_tolerance = skip_rate_tolerance

        self._step = 0
        self._skip_rates: List[float] = []
        self._accuracies: List[float] = []

    def record(self, skip_rate: float, accuracy: float) -> None:
        """Record metrics for monitoring."""
        self._skip_rates.append(skip_rate)
        self._accuracies.append(accuracy)
        self._step += 1

    def should_adjust(self) -> bool:
        """Check if parameters should be adjusted."""
        if self._step < self.adjustment_interval:
            return False
        if self._step % self.adjustment_interval != 0:
            return False

        # Check if skip rate drifted from target
        recent_skip = np.mean(self._skip_rates[-20:])
        target_skip = 0.5  # Could be configurable

        return abs(recent_skip - target_skip) > self.skip_rate_tolerance

    def adjust(self) -> CalibrationResult:
        """
        Adjust parameters based on recent performance.

        Returns updated CalibrationResult.
        """
        recent_skip = np.mean(self._skip_rates[-20:])
        recent_acc = np.mean(self._accuracies[-20:])

        # Adjust sparse threshold
        if recent_skip > 0.9:
            # Too much skipping, lower threshold
            new_threshold = self.config.sparse_threshold * 0.5
        elif recent_skip < 0.2 and recent_acc > 0.6:
            # Could skip more for better endurance
            new_threshold = self.config.sparse_threshold * 1.5
        else:
            new_threshold = self.config.sparse_threshold

        # Adjust learning rate based on accuracy
        if recent_acc < 0.5:
            new_lr = self.config.learning_rate * 1.2
        elif recent_acc > 0.9:
            new_lr = self.config.learning_rate * 0.8
        else:
            new_lr = self.config.learning_rate

        # Create updated config
        self.config = CalibrationResult(
            sparse_threshold=new_threshold,
            learning_rate=new_lr,
            drift_rate=self.config.drift_rate,
            ga_batch_size=self.config.ga_batch_size,
            energy_barrier=self.config.energy_barrier,
            expected_skip_rate=recent_skip,
            expected_accuracy=recent_acc,
        )

        return self.config


# =============================================================================
# TEST
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print(" ADAPTIVE MEMRISTOR CALIBRATION - Demo")
    print("=" * 70)

    # Generate synthetic data
    np.random.seed(42)
    n_samples = 200
    embed_dim = 128

    X = np.random.randn(n_samples, embed_dim).astype(np.float32)

    # Synthetic targets (3-class R/S/N)
    targets = np.zeros((n_samples, 3), dtype=np.float32)
    for i in range(n_samples):
        cls = i % 3
        if cls == 0:
            targets[i] = [0.7, 0.2, 0.1]
        elif cls == 1:
            targets[i] = [0.2, 0.7, 0.1]
        else:
            targets[i] = [0.1, 0.2, 0.7]

    # Run calibration
    calibrator = AdaptiveMemristorCalibrator(
        target_skip_rate=0.5,
        n_probe_samples=50,
    )

    result = calibrator.calibrate(X, targets, rsn_dim=32, verbose=True)

    # Use discovered config
    print("\n" + "=" * 70)
    print(" Using Discovered Config")
    print("=" * 70)

    config = result.to_yrsn_config(embed_dim=embed_dim, rsn_dim=32)
    proj = YRSNMemristorProjection(config)

    # Quick training
    print("\nTraining with discovered parameters...")
    for i in range(100):
        result_fwd = proj.forward(X[i])
        proj.learn_with_ga(
            X[i],
            targets[i][0], targets[i][1], targets[i][2],
            tau=result_fwd['tau']
        )
    proj.flush_gradients()

    # Check results
    stats = proj.get_endurance_stats()
    total_updates = sum(s['total_updates'] for s in stats.values())
    total_skipped = sum(s['skipped_updates'] for s in stats.values())
    total = total_updates + total_skipped
    actual_skip = total_skipped / total if total > 0 else 0

    print(f"\nActual skip rate: {actual_skip*100:.1f}%")
    print(f"Endurance gain: {1/(1-actual_skip):.1f}x")

    print("\n" + "=" * 70)
    print(" KEY INSIGHT: Parameters learned FROM data, not hardcoded!")
    print("=" * 70)
