"""
YRSN Memristor Projection - PyTorch Device-Aware Implementation.

This is the device-aware refactoring of memristor_projection.py that uses
native PyTorch operations for GPU acceleration.

Key Changes from numpy version:
- All operations use torch tensors on specified device
- nn.Module inheritance for proper .to(device) support
- Differentiable operations for gradient-based training
- No numpy/CPU conversions in forward path

Usage:
    from yrsn.hardware.memristor_projection_torch import (
        TorchMemristorArray,
        TorchYRSNMemristorProjection,
    )
    
    # Create device-aware projection
    proj = TorchYRSNMemristorProjection(config, device='cuda')
    
    # Forward pass stays on device
    embedding = torch.randn(64, device='cuda')
    result = proj(embedding)  # All on CUDA
"""

from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, List, Union
from pathlib import Path
from enum import Enum
import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================================
# Configuration
# ============================================================================

class MemristorType(Enum):
    """Types of memristor dynamics."""
    LINEAR = "linear"
    THRESHOLD = "threshold"
    NONLINEAR = "nonlinear"
    SPINTRONIC = "spintronic"


@dataclass
class TorchMemristorConfig:
    """Configuration for torch-based memristor."""
    R_min: float = 0.1
    R_max: float = 10.0
    R_init: float = 1.0
    memristor_type: MemristorType = MemristorType.NONLINEAR
    drift_rate: float = 0.01
    threshold: float = 0.1
    decay_rate: float = 0.001
    noise_std: float = 0.01
    temperature_coupling: float = 1.0
    energy_barrier: float = 0.5


@dataclass
class TorchYRSNMemristorConfig:
    """Configuration for torch YRSN memristor projection."""
    embed_dim: int = 768
    rsn_dim: int = 256
    learning_rate: float = 0.01
    memristor_config: Optional[TorchMemristorConfig] = None


# ============================================================================
# Torch Memristor Array (replaces numpy MemristorArray)
# ============================================================================

class TorchMemristorArray(nn.Module):
    """
    Crossbar array of memristors using PyTorch operations.
    
    Matrix-vector multiplication: y = G @ x in O(1) time (Ohm's law).
    Fully differentiable and device-aware.
    """
    
    def __init__(
        self, 
        rows: int, 
        cols: int, 
        config: Optional[TorchMemristorConfig] = None,
        device: Optional[torch.device] = None,
    ):
        super().__init__()
        self.rows = rows
        self.cols = cols
        self.config = config or TorchMemristorConfig()
        
        # Device handling
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self._device = device
        
        # Resistance matrix (learnable parameter)
        # Initialize near R_init with small random perturbation
        R_init = torch.full((rows, cols), self.config.R_init, device=device)
        R_init = R_init + torch.randn(rows, cols, device=device) * 0.1
        R_init = torch.clamp(R_init, self.config.R_min, self.config.R_max)
        self.R = nn.Parameter(R_init)
        
        # Track charge and flux (for memristor state)
        self.register_buffer('q', torch.zeros(rows, cols, device=device))
        self.register_buffer('phi', torch.zeros(rows, cols, device=device))
        
    @property
    def device(self) -> torch.device:
        return self.R.device
    
    @property
    def conductance_matrix(self) -> torch.Tensor:
        """Get conductance matrix G = 1/R."""
        return 1.0 / self.R
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Matrix-vector multiplication: y = G.T @ x
        
        Args:
            x: Input tensor [rows] or [batch, rows]
            
        Returns:
            Output tensor [cols] or [batch, cols]
        """
        # Ensure input is on same device
        x = x.to(self.device)
        
        G = self.conductance_matrix
        
        if x.dim() == 1:
            # Single vector: [rows] -> [cols]
            return G.T @ x
        else:
            # Batched: [batch, rows] -> [batch, cols]
            return x @ G
    
    def apply_hebbian_update(
        self,
        pre: torch.Tensor,
        post: torch.Tensor,
        tau: float = 1.0,
        learning_rate: float = 0.01,
    ) -> None:
        """
        Hebbian learning: ΔR ∝ -pre × post
        
        Temperature modulates plasticity.
        """
        pre = pre.to(self.device)
        post = post.to(self.device)
        
        # Compute update magnitude
        effective_rate = learning_rate * tau * self.config.temperature_coupling
        
        # Outer product for weight update
        if pre.dim() == 1 and post.dim() == 1:
            dR = -effective_rate * torch.outer(pre[:self.rows], post[:self.cols])
        else:
            # Handle batched case - average over batch
            dR = -effective_rate * (pre[:, :self.rows].T @ post[:, :self.cols]) / pre.size(0)
        
        # Apply energy barrier (minimum change threshold)
        mask = torch.abs(dR) > self.config.energy_barrier * self.config.noise_std
        dR = dR * mask.float()
        
        # Passive decay toward R_init
        decay = self.config.decay_rate * (self.R.data - self.config.R_init)
        
        # Update resistance with bounds
        with torch.no_grad():
            self.R.data = torch.clamp(
                self.R.data + dR - decay,
                self.config.R_min,
                self.config.R_max
            )


# ============================================================================
# Torch YRSN Memristor Projection
# ============================================================================

class TorchYRSNMemristorProjection(nn.Module):
    """
    YRSN R/S/N projection using PyTorch memristor arrays.
    
    Three arrays project embeddings onto R/S/N subspaces:
    - R_array: Projects to Relevant subspace
    - S_array: Projects to Superfluous subspace
    - N_array: Projects to Noise subspace
    
    Fully device-aware: all operations stay on specified device.
    """
    
    def __init__(
        self,
        config: Optional[TorchYRSNMemristorConfig] = None,
        device: Optional[Union[str, torch.device]] = None,
    ):
        super().__init__()
        self.config = config or TorchYRSNMemristorConfig()
        
        # Device handling
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        elif isinstance(device, str):
            device = torch.device(device)
        self._device = device
        
        mem_cfg = self.config.memristor_config or TorchMemristorConfig()
        
        # Three crossbar arrays for R/S/N projection
        self.R_array = TorchMemristorArray(
            self.config.embed_dim, self.config.rsn_dim, mem_cfg, device
        )
        self.S_array = TorchMemristorArray(
            self.config.embed_dim, self.config.rsn_dim, mem_cfg, device
        )
        self.N_array = TorchMemristorArray(
            self.config.embed_dim, self.config.rsn_dim, mem_cfg, device
        )
    
    @property
    def device(self) -> torch.device:
        return self.R_array.device
    
    def forward(self, embedding: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Project embedding through R/S/N memristor arrays.
        
        All operations stay on device - no CPU conversions.
        
        Args:
            embedding: Input embedding [embed_dim] or [batch, embed_dim]
            
        Returns:
            Dict with R, S, N scores and derived metrics (all tensors on device)
        """
        # Ensure on same device
        embedding = embedding.to(self.device)
        
        # Handle both single and batched inputs
        batched = embedding.dim() == 2
        if not batched:
            embedding = embedding.unsqueeze(0)
        
        # Project through each crossbar
        R_proj = self.R_array(embedding)  # [batch, rsn_dim]
        S_proj = self.S_array(embedding)
        N_proj = self.N_array(embedding)
        
        # Compute norms as scores
        R_score = torch.norm(R_proj, dim=-1)  # [batch]
        S_score = torch.norm(S_proj, dim=-1)
        N_score = torch.norm(N_proj, dim=-1)
        
        # Normalize to [0, 1]
        total = R_score + S_score + N_score + 1e-8
        R = R_score / total
        S = S_score / total
        N = N_score / total
        
        # Derived metrics
        alpha = R
        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        # Simple ω approximation for base memristor (use BaseLearner for full OOD)
        omega = 1.0 - N
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / torch.clamp(alpha_omega, min=0.01)

        # Remove batch dim if input was unbatched
        if not batched:
            R, S, N = R.squeeze(0), S.squeeze(0), N.squeeze(0)
            alpha, tau = alpha.squeeze(0), tau.squeeze(0)
            omega = omega.squeeze(0)
            alpha_omega = alpha_omega.squeeze(0)
            R_proj = R_proj.squeeze(0)
            S_proj = S_proj.squeeze(0)
            N_proj = N_proj.squeeze(0)

        return {
            'R': R,
            'S': S,
            'N': N,
            'R_proj': R_proj,
            'S_proj': S_proj,
            'N_proj': N_proj,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
        }
    
    def learn(
        self,
        embedding: torch.Tensor,
        target_R: float,
        target_S: float,
        target_N: float,
        tau: float = 1.0,
    ) -> None:
        """
        Learn R/S/N projection via temperature-modulated Hebbian update.
        
        All operations on device.
        """
        embedding = embedding.to(self.device)
        
        # Current projections
        result = self.forward(embedding)
        
        # Error signals
        R_error = target_R - result['R'].detach().mean().item()
        S_error = target_S - result['S'].detach().mean().item()
        N_error = target_N - result['N'].detach().mean().item()
        
        # Create target vectors scaled by error
        R_target = torch.ones(self.config.rsn_dim, device=self.device) * R_error
        S_target = torch.ones(self.config.rsn_dim, device=self.device) * S_error
        N_target = torch.ones(self.config.rsn_dim, device=self.device) * N_error
        
        # Flatten embedding if batched
        if embedding.dim() == 2:
            embedding = embedding.mean(dim=0)
        
        # Hebbian updates
        lr = self.config.learning_rate
        self.R_array.apply_hebbian_update(embedding, R_target, tau=tau, learning_rate=lr)
        self.S_array.apply_hebbian_update(embedding, S_target, tau=tau, learning_rate=lr)
        self.N_array.apply_hebbian_update(embedding, N_target, tau=tau, learning_rate=lr)
    
    def get_conductance_stats(self) -> Dict[str, Dict[str, float]]:
        """Get statistics about learned conductances."""
        def array_stats(arr: TorchMemristorArray) -> Dict[str, float]:
            G = arr.conductance_matrix
            return {
                'mean': float(G.mean().item()),
                'std': float(G.std().item()),
                'min': float(G.min().item()),
                'max': float(G.max().item()),
            }
        
        return {
            'R_array': array_stats(self.R_array),
            'S_array': array_stats(self.S_array),
            'N_array': array_stats(self.N_array),
        }


# ============================================================================
# Bit-Sliced Version
# ============================================================================

def quantize_embedding_torch(
    embedding: torch.Tensor,
    bits: int = 3,
    symmetric: bool = True,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Quantize embedding to n-bit representation (torch version)."""
    levels = 2 ** bits
    
    if symmetric:
        max_val = torch.max(torch.abs(embedding))
        scale = max_val / (levels // 2) if max_val > 0 else torch.tensor(1.0)
        quantized = torch.round(embedding / scale)
        quantized = torch.clamp(quantized, -levels // 2, levels // 2 - 1)
    else:
        min_val, max_val = torch.min(embedding), torch.max(embedding)
        scale = (max_val - min_val) / (levels - 1) if max_val > min_val else torch.tensor(1.0)
        quantized = torch.round((embedding - min_val) / scale)
        quantized = torch.clamp(quantized, 0, levels - 1)
    
    metadata = {
        'bits': bits,
        'levels': levels,
        'scale': scale,
        'symmetric': symmetric,
    }
    
    return quantized.to(torch.int8), metadata


class TorchBitSlicedMemristorProjection(TorchYRSNMemristorProjection):
    """
    YRSN projection with bit-sliced quantization (PyTorch version).
    """
    
    def __init__(
        self,
        config: Optional[TorchYRSNMemristorConfig] = None,
        bits: int = 3,
        device: Optional[Union[str, torch.device]] = None,
    ):
        super().__init__(config, device)
        self.bits = bits
        self.slices = bits
    
    def forward_quantized(
        self,
        embedding: torch.Tensor,
        slice_weights: Optional[List[float]] = None,
    ) -> Dict[str, torch.Tensor]:
        """Project with bit-sliced quantization."""
        embedding = embedding.to(self.device)
        
        # Quantize input
        quantized, quant_meta = quantize_embedding_torch(embedding, bits=self.bits)
        
        # Default slice weights: MSB = 4, middle = 2, LSB = 1
        if slice_weights is None:
            slice_weights = [2 ** (self.bits - 1 - i) for i in range(self.bits)]
        
        # Decompose into bit slices
        slices = []
        for i in range(self.bits):
            bit_slice = ((quantized >> i) & 1).float()
            slices.append(bit_slice)
        
        # Project each slice and weight-combine
        R_total = torch.zeros(self.config.rsn_dim, device=self.device)
        S_total = torch.zeros(self.config.rsn_dim, device=self.device)
        N_total = torch.zeros(self.config.rsn_dim, device=self.device)
        
        for i, (bit_slice, weight) in enumerate(zip(slices, slice_weights)):
            R_total = R_total + weight * self.R_array(bit_slice)
            S_total = S_total + weight * self.S_array(bit_slice)
            N_total = N_total + weight * self.N_array(bit_slice)
        
        # Normalize
        R_score = torch.norm(R_total)
        S_score = torch.norm(S_total)
        N_score = torch.norm(N_total)
        total = R_score + S_score + N_score + 1e-8
        
        R = R_score / total
        S = S_score / total
        N = N_score / total
        
        alpha = R
        omega = torch.tensor(1.0, device=self.device)
        quality_prior = torch.tensor(0.5, device=self.device)
        alpha_omega = omega * alpha + (1 - omega) * quality_prior
        tau = 1.0 / torch.clamp(alpha_omega, min=0.01)
        
        return {
            'R': R,
            'S': S,
            'N': N,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
            'quantization': quant_meta,
        }


# ============================================================================
# Factory Functions
# ============================================================================

def create_projection(
    embed_dim: int = 64,
    rsn_dim: int = 32,
    device: Optional[Union[str, torch.device]] = None,
    use_torch: bool = True,
) -> Union[TorchYRSNMemristorProjection, "YRSNMemristorProjection"]:
    """
    Factory function to create YRSN projection.
    
    Args:
        embed_dim: Input embedding dimension
        rsn_dim: R/S/N projection dimension
        device: Target device (e.g., 'cuda', 'cpu', 'mps')
        use_torch: If True, use torch version; else use numpy version
        
    Returns:
        Device-aware YRSN projection
    """
    if use_torch:
        config = TorchYRSNMemristorConfig(
            embed_dim=embed_dim,
            rsn_dim=rsn_dim,
        )
        return TorchYRSNMemristorProjection(config, device)
    else:
        # Fall back to numpy version
        from .memristor_projection import YRSNMemristorProjection, YRSNMemristorConfig
        config = YRSNMemristorConfig(embed_dim=embed_dim, rsn_dim=rsn_dim)
        return YRSNMemristorProjection(config)


# ============================================================================
# Test
# ============================================================================

if __name__ == "__main__":
    print("=== Torch YRSN Memristor Projection Test ===\n")
    
    # Test on available device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    
    # Create projection
    config = TorchYRSNMemristorConfig(embed_dim=64, rsn_dim=32)
    proj = TorchYRSNMemristorProjection(config, device)
    
    # Test forward
    embedding = torch.randn(64, device=device)
    result = proj(embedding)
    
    print(f"\nSingle embedding:")
    print(f"  R={result['R'].item():.4f}, S={result['S'].item():.4f}, N={result['N'].item():.4f}")
    print(f"  All tensors on {result['R'].device}")
    
    # Test batched
    batch_emb = torch.randn(8, 64, device=device)
    batch_result = proj(batch_emb)
    print(f"\nBatched (8 samples):")
    print(f"  R shape: {batch_result['R'].shape}")
    print(f"  Mean R={batch_result['R'].mean().item():.4f}")
    
    # Test learning
    print("\n Learning test...")
    proj.learn(embedding, target_R=0.7, target_S=0.2, target_N=0.1, tau=1.5)
    result_after = proj(embedding)
    print(f"  Before: R={result['R'].item():.4f}")
    print(f"  After:  R={result_after['R'].item():.4f}")
    
    print("\nAll tests passed!")
