"""
Dynamic Weighting GRPO (Group Relative Policy Optimization) with YRSN Alpha Reward

This module implements DW-GRPO training using YRSN alpha as the primary reward signal,
eliminating the need for a separate judge model (e.g., LLM-as-judge).

Key Innovation (Claim A7):
- Alpha serves as faithfulness reward in RL without external judge model
- Dynamic weighting prevents objective collapse during multi-objective optimization
- Learning velocity monitoring enables adaptive weight adjustment

Architecture:
    1. LearningVelocityMonitor: Track per-objective learning speed
    2. DWGRPOTrainer: Dynamic weighting GRPO with YRSN alpha reward
    3. RewardSignalExtractor: Extract R/S/N rewards from rotor outputs

Reference:
- DW-GRPO paper: Dynamic Weighting for Multi-Objective RL
- GRPO: Group Relative Policy Optimization (DeepSeek)
- YRSN alpha: Quality signal from RSN decomposition

Created: 2026-01-22
DOE Reference: series_004/expS4_151_dw_grpo_training_doe.md
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Callable
from collections import deque
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


# =============================================================================
# LEARNING VELOCITY MONITOR
# =============================================================================

@dataclass
class VelocityStats:
    """Statistics for learning velocity tracking."""
    mean_velocity: float
    velocity_std: float
    trend: str  # "increasing", "decreasing", "stable"
    should_increase_weight: bool
    window_size: int
    n_samples: int


class LearningVelocityMonitor:
    """
    Track per-objective learning velocity for dynamic weighting.

    Velocity = rate of improvement in objective over recent steps.
    High velocity -> objective learning well, may reduce weight.
    Low velocity -> objective stagnating, may increase weight.

    From DW-GRPO: Dynamic weights prevent collapse by redistributing
    focus to slow-learning objectives.

    Example:
        >>> monitor = LearningVelocityMonitor(window=50)
        >>> for step in range(1000):
        ...     loss = train_step()
        ...     monitor.update(loss)
        ...     if monitor.should_increase_weight(threshold=0.01):
        ...         weight *= 1.1  # Boost slow-learning objective
    """

    def __init__(
        self,
        window_size: int = 50,
        smoothing: float = 0.1,
        velocity_threshold: float = 0.01,
    ):
        """
        Initialize velocity monitor.

        Args:
            window_size: Number of steps to track for velocity computation
            smoothing: EMA smoothing factor for velocity
            velocity_threshold: Below this = slow learning = increase weight
        """
        self.window_size = window_size
        self.smoothing = smoothing
        self.velocity_threshold = velocity_threshold

        self.history: deque = deque(maxlen=window_size)
        self.ema_velocity: float = 0.0
        self.step_count: int = 0

    def update(self, value: float) -> None:
        """
        Update with new objective value (loss or negative reward).

        Args:
            value: Objective value at current step (lower is better for loss)
        """
        self.history.append(value)
        self.step_count += 1

        if len(self.history) >= 2:
            # Compute instantaneous velocity (improvement rate)
            current_velocity = self.history[-2] - self.history[-1]  # Positive = improving

            # EMA update
            self.ema_velocity = (
                self.smoothing * current_velocity +
                (1 - self.smoothing) * self.ema_velocity
            )

    def compute_velocity(
        self,
        history: Optional[List[float]] = None,
        window: Optional[int] = None,
    ) -> float:
        """
        Compute learning velocity over window.

        Velocity = (start_value - end_value) / window_size
        Positive velocity = objective improving (loss decreasing).

        Args:
            history: Optional external history (uses internal if None)
            window: Optional window size override

        Returns:
            Learning velocity (positive = improving)
        """
        h = list(history) if history is not None else list(self.history)
        w = window if window is not None else self.window_size

        if len(h) < 2:
            return 0.0

        # Use available data up to window size
        effective_window = min(len(h), w)
        start_val = h[-effective_window]
        end_val = h[-1]

        # Velocity = improvement rate
        velocity = (start_val - end_val) / effective_window
        return velocity

    def should_increase_weight(
        self,
        velocity: Optional[float] = None,
        threshold: Optional[float] = None,
    ) -> bool:
        """
        Determine if objective weight should be increased.

        Low velocity indicates the objective is not learning well,
        suggesting we should increase its weight in the loss function.

        Args:
            velocity: Optional explicit velocity (uses EMA if None)
            threshold: Optional threshold override

        Returns:
            True if weight should be increased
        """
        v = velocity if velocity is not None else self.ema_velocity
        t = threshold if threshold is not None else self.velocity_threshold

        # Increase weight if velocity is below threshold
        return v < t

    def get_stats(self) -> VelocityStats:
        """Get comprehensive velocity statistics."""
        velocities = []
        h = list(self.history)

        for i in range(1, len(h)):
            velocities.append(h[i-1] - h[i])

        if not velocities:
            return VelocityStats(
                mean_velocity=0.0,
                velocity_std=0.0,
                trend="stable",
                should_increase_weight=True,
                window_size=self.window_size,
                n_samples=len(h),
            )

        mean_vel = np.mean(velocities)
        std_vel = np.std(velocities)

        # Determine trend
        if len(velocities) >= 10:
            first_half = np.mean(velocities[:len(velocities)//2])
            second_half = np.mean(velocities[len(velocities)//2:])
            if second_half > first_half * 1.1:
                trend = "increasing"
            elif second_half < first_half * 0.9:
                trend = "decreasing"
            else:
                trend = "stable"
        else:
            trend = "stable"

        return VelocityStats(
            mean_velocity=float(mean_vel),
            velocity_std=float(std_vel),
            trend=trend,
            should_increase_weight=self.should_increase_weight(),
            window_size=self.window_size,
            n_samples=len(h),
        )

    def reset(self) -> None:
        """Reset monitor state."""
        self.history.clear()
        self.ema_velocity = 0.0
        self.step_count = 0


# =============================================================================
# REWARD SIGNAL EXTRACTOR
# =============================================================================

@dataclass
class RewardComponents:
    """Reward components extracted from YRSN rotor output."""
    alpha: torch.Tensor      # Quality/faithfulness reward
    relevance: torch.Tensor  # R component (relevance)
    conciseness: torch.Tensor  # 1 - S component (inverse superfluous)
    faithfulness: torch.Tensor  # 1 - N component (inverse noise)
    composite: torch.Tensor  # Weighted combination

    def to_dict(self) -> Dict[str, float]:
        """Export as dictionary of mean values."""
        return {
            'alpha': float(self.alpha.mean()),
            'relevance': float(self.relevance.mean()),
            'conciseness': float(self.conciseness.mean()),
            'faithfulness': float(self.faithfulness.mean()),
            'composite': float(self.composite.mean()),
        }


class RewardSignalExtractor:
    """
    Extract reward signals from YRSN rotor outputs.

    Maps RSN decomposition to RL reward components:
    - R (Relevance) -> Relevance reward
    - S (Superfluous) -> Conciseness reward (1 - S)
    - N (Noise) -> Faithfulness reward (1 - N)
    - Alpha = R / (R + S + N) = R (since R+S+N=1)

    This enables using YRSN for RL training without external judge models.

    Example:
        >>> extractor = RewardSignalExtractor()
        >>> rewards = extractor.extract({'R': R, 'S': S, 'N': N})
        >>> loss = -rewards.composite.mean()  # Maximize reward
    """

    def __init__(
        self,
        alpha_weight: float = 1.0,
        relevance_weight: float = 1.0,
        conciseness_weight: float = 1.0,
        faithfulness_weight: float = 1.0,
        normalize_rewards: bool = True,
    ):
        """
        Initialize reward extractor.

        Args:
            alpha_weight: Weight for alpha (quality) reward
            relevance_weight: Weight for R (relevance) component
            conciseness_weight: Weight for conciseness (1-S)
            faithfulness_weight: Weight for faithfulness (1-N)
            normalize_rewards: Whether to normalize rewards to [0, 1]
        """
        self.alpha_weight = alpha_weight
        self.relevance_weight = relevance_weight
        self.conciseness_weight = conciseness_weight
        self.faithfulness_weight = faithfulness_weight
        self.normalize_rewards = normalize_rewards

    def extract(
        self,
        rotor_output: Dict[str, torch.Tensor],
        return_components: bool = True,
    ) -> RewardComponents:
        """
        Extract reward components from rotor output.

        Args:
            rotor_output: Dictionary with 'R', 'S', 'N' tensors from rotor
            return_components: Whether to return individual components

        Returns:
            RewardComponents with all reward signals
        """
        R = rotor_output['R']
        S = rotor_output['S']
        N = rotor_output['N']

        # Alpha = quality signal = R (since R+S+N=1)
        # Higher R -> higher quality
        alpha = R

        # Relevance reward = R directly
        relevance = R

        # Conciseness reward = 1 - S (penalize superfluous content)
        conciseness = 1.0 - S

        # Faithfulness reward = 1 - N (penalize noise)
        faithfulness = 1.0 - N

        # Composite reward with weights
        total_weight = (
            self.alpha_weight +
            self.relevance_weight +
            self.conciseness_weight +
            self.faithfulness_weight
        )

        composite = (
            self.alpha_weight * alpha +
            self.relevance_weight * relevance +
            self.conciseness_weight * conciseness +
            self.faithfulness_weight * faithfulness
        ) / total_weight

        if self.normalize_rewards:
            # Rewards are already in [0, 1] range due to simplex constraint
            pass

        return RewardComponents(
            alpha=alpha,
            relevance=relevance,
            conciseness=conciseness,
            faithfulness=faithfulness,
            composite=composite,
        )

    def compute_grpo_advantage(
        self,
        rewards: RewardComponents,
        baseline: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute GRPO-style advantage for policy gradient.

        GRPO uses group-relative advantages instead of absolute rewards.

        Args:
            rewards: RewardComponents from extract()
            baseline: Optional baseline reward (uses group mean if None)

        Returns:
            Advantage tensor for policy gradient
        """
        composite = rewards.composite

        if baseline is None:
            # Use group mean as baseline (GRPO style)
            baseline = composite.mean()

        advantage = composite - baseline

        # Optionally normalize advantages
        if advantage.std() > 1e-6:
            advantage = (advantage - advantage.mean()) / (advantage.std() + 1e-8)

        return advantage


# =============================================================================
# DW-GRPO TRAINER
# =============================================================================

@dataclass
class TrainingMetrics:
    """Metrics from a training step."""
    total_loss: float
    alpha_loss: float
    relevance_loss: float
    conciseness_loss: float
    weights: Dict[str, float]
    velocities: Dict[str, float]
    step: int


class DWGRPOTrainer:
    """
    Dynamic Weighting GRPO trainer using YRSN alpha as reward.

    Key Features (Claim A7):
    1. Alpha as faithfulness reward without external judge
    2. Dynamic weighting prevents collapse of any objective
    3. Learning velocity monitoring for adaptive weight adjustment

    The trainer dynamically adjusts weights for each objective based on
    learning velocity. Slow-learning objectives get higher weights,
    preventing collapse where one objective dominates.

    Example:
        >>> from yrsn.core.decomposition.hybrid_rotor import HybridSimplexRotor
        >>> rotor = HybridSimplexRotor(embed_dim=768)
        >>> trainer = DWGRPOTrainer(rotor, lr=1e-4)
        >>> for batch in dataloader:
        ...     metrics = trainer.train_step(batch)
        ...     print(f"Step {metrics.step}: loss={metrics.total_loss:.4f}")
    """

    def __init__(
        self,
        rotor: nn.Module,
        lr: float = 1e-4,
        velocity_window: int = 50,
        weight_update_freq: int = 100,
        min_weight: float = 0.1,
        max_weight: float = 5.0,
        weight_adjust_rate: float = 0.1,
        device: Optional[torch.device] = None,
    ):
        """
        Initialize DW-GRPO trainer.

        Args:
            rotor: YRSN rotor model (HybridSimplexRotor or similar)
            lr: Learning rate
            velocity_window: Window for velocity computation
            weight_update_freq: Steps between weight updates
            min_weight: Minimum objective weight
            max_weight: Maximum objective weight
            weight_adjust_rate: Rate of weight adjustment
            device: Torch device (auto-detect if None)
        """
        self.rotor = rotor
        self.lr = lr
        self.velocity_window = velocity_window
        self.weight_update_freq = weight_update_freq
        self.min_weight = min_weight
        self.max_weight = max_weight
        self.weight_adjust_rate = weight_adjust_rate

        self.device = device or (
            torch.device('cuda') if torch.cuda.is_available()
            else torch.device('cpu')
        )
        self.rotor.to(self.device)

        # Optimizer
        self.optimizer = torch.optim.AdamW(
            self.rotor.parameters(),
            lr=lr,
            betas=(0.9, 0.999),
            weight_decay=0.01,
        )

        # Velocity monitors for each objective
        self.velocity_monitors = {
            'alpha': LearningVelocityMonitor(window_size=velocity_window),
            'relevance': LearningVelocityMonitor(window_size=velocity_window),
            'conciseness': LearningVelocityMonitor(window_size=velocity_window),
        }

        # Dynamic weights (start equal)
        self.weights = {
            'alpha': 1.0,
            'relevance': 1.0,
            'conciseness': 1.0,
        }

        # Reward extractor
        self.reward_extractor = RewardSignalExtractor()

        # Training state
        self.step_count = 0
        self.loss_history: List[float] = []

    def compute_rewards(
        self,
        embeddings: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute reward signals from embeddings.

        Args:
            embeddings: [B, D] input embeddings

        Returns:
            Dictionary with alpha, relevance, conciseness rewards
        """
        # Forward through rotor
        rotor_output = self.rotor(embeddings)

        # Extract rewards
        rewards = self.reward_extractor.extract(rotor_output)

        return {
            'alpha': rewards.alpha,
            'relevance': rewards.relevance,
            'conciseness': rewards.conciseness,
            'composite': rewards.composite,
            'R': rotor_output['R'],
            'S': rotor_output['S'],
            'N': rotor_output['N'],
            'theta': rotor_output.get('theta'),
            'scale': rotor_output.get('scale'),
        }

    def update_weights(
        self,
        velocities: Dict[str, float],
    ) -> Tuple[float, float, float]:
        """
        Update objective weights based on learning velocities.

        Low velocity -> increase weight (objective needs more focus).
        High velocity -> decrease weight (objective learning well).

        Args:
            velocities: Dictionary of objective velocities

        Returns:
            Tuple of (w_alpha, w_relevance, w_conciseness)
        """
        for name, velocity in velocities.items():
            if name not in self.weights:
                continue

            monitor = self.velocity_monitors.get(name)
            if monitor is None:
                continue

            # Adjust weight based on velocity
            if monitor.should_increase_weight(velocity):
                # Slow learning -> increase weight
                self.weights[name] = min(
                    self.max_weight,
                    self.weights[name] * (1 + self.weight_adjust_rate)
                )
            else:
                # Fast learning -> decrease weight
                self.weights[name] = max(
                    self.min_weight,
                    self.weights[name] * (1 - self.weight_adjust_rate * 0.5)
                )

        # Normalize weights to sum to 3 (maintain scale)
        total = sum(self.weights.values())
        if total > 0:
            scale_factor = 3.0 / total
            for name in self.weights:
                self.weights[name] *= scale_factor

        return (
            self.weights['alpha'],
            self.weights['relevance'],
            self.weights['conciseness'],
        )

    def train_step(
        self,
        batch: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
    ) -> TrainingMetrics:
        """
        Execute one training step with dynamic weighting.

        Args:
            batch: [B, D] embeddings
            labels: Optional [B] labels for supervised component

        Returns:
            TrainingMetrics with losses and weights
        """
        self.rotor.train()
        self.optimizer.zero_grad()

        # Move to device
        batch = batch.to(self.device)
        if labels is not None:
            labels = labels.to(self.device)

        # Compute rewards
        rewards = self.compute_rewards(batch)

        # Compute losses (negative rewards)
        alpha_loss = -rewards['alpha'].mean()
        relevance_loss = -rewards['relevance'].mean()
        conciseness_loss = -rewards['conciseness'].mean()

        # Weighted total loss
        total_loss = (
            self.weights['alpha'] * alpha_loss +
            self.weights['relevance'] * relevance_loss +
            self.weights['conciseness'] * conciseness_loss
        )

        # Backward pass
        total_loss.backward()

        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(self.rotor.parameters(), max_norm=1.0)

        # Optimizer step
        self.optimizer.step()

        # Update velocity monitors
        self.velocity_monitors['alpha'].update(float(alpha_loss))
        self.velocity_monitors['relevance'].update(float(relevance_loss))
        self.velocity_monitors['conciseness'].update(float(conciseness_loss))

        # Periodically update weights
        self.step_count += 1
        if self.step_count % self.weight_update_freq == 0:
            velocities = {
                name: monitor.ema_velocity
                for name, monitor in self.velocity_monitors.items()
            }
            self.update_weights(velocities)

        # Get current velocities
        current_velocities = {
            name: monitor.ema_velocity
            for name, monitor in self.velocity_monitors.items()
        }

        return TrainingMetrics(
            total_loss=float(total_loss),
            alpha_loss=float(alpha_loss),
            relevance_loss=float(relevance_loss),
            conciseness_loss=float(conciseness_loss),
            weights=dict(self.weights),
            velocities=current_velocities,
            step=self.step_count,
        )

    def validate(
        self,
        val_loader: Any,
        n_batches: Optional[int] = None,
    ) -> Dict[str, float]:
        """
        Validate model on validation set.

        Args:
            val_loader: Validation data loader
            n_batches: Optional limit on number of batches

        Returns:
            Dictionary of validation metrics
        """
        self.rotor.eval()

        total_alpha = 0.0
        total_relevance = 0.0
        total_conciseness = 0.0
        n_samples = 0

        with torch.no_grad():
            for i, batch in enumerate(val_loader):
                if n_batches is not None and i >= n_batches:
                    break

                if isinstance(batch, (tuple, list)):
                    batch = batch[0]

                batch = batch.to(self.device)
                rewards = self.compute_rewards(batch)

                batch_size = batch.shape[0]
                total_alpha += float(rewards['alpha'].sum())
                total_relevance += float(rewards['relevance'].sum())
                total_conciseness += float(rewards['conciseness'].sum())
                n_samples += batch_size

        return {
            'val_alpha': total_alpha / max(n_samples, 1),
            'val_relevance': total_relevance / max(n_samples, 1),
            'val_conciseness': total_conciseness / max(n_samples, 1),
            'n_samples': n_samples,
        }

    def get_state(self) -> Dict[str, Any]:
        """Get trainer state for checkpointing."""
        return {
            'step_count': self.step_count,
            'weights': dict(self.weights),
            'rotor_state_dict': self.rotor.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load trainer state from checkpoint."""
        self.step_count = state['step_count']
        self.weights = dict(state['weights'])
        self.rotor.load_state_dict(state['rotor_state_dict'])
        self.optimizer.load_state_dict(state['optimizer_state_dict'])


# =============================================================================
# MULTI-OBJECTIVE RSN TRAINER (Claim A7 extension)
# =============================================================================

class MultiObjectiveRSNTrainer(DWGRPOTrainer):
    """
    Extended DW-GRPO trainer mapping RSN to Relevance/Conciseness/Faithfulness.

    This trainer implements the mapping:
    - R -> Relevance (answer correctness)
    - S -> Conciseness (inverse: less superfluous content)
    - N -> Faithfulness (inverse: less hallucination/noise)

    Used for expS4_152 to validate RSN as unified multi-objective reward.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Add faithfulness weight
        self.weights['faithfulness'] = 1.0
        self.velocity_monitors['faithfulness'] = LearningVelocityMonitor(
            window_size=self.velocity_window
        )

    def compute_rsn_rewards(
        self,
        embeddings: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute RSN-mapped rewards.

        Args:
            embeddings: [B, D] input embeddings

        Returns:
            Dictionary with Relevance, Conciseness, Faithfulness
        """
        rotor_output = self.rotor(embeddings)

        R = rotor_output['R']
        S = rotor_output['S']
        N = rotor_output['N']

        return {
            'relevance': R,
            'conciseness': 1.0 - S,
            'faithfulness': 1.0 - N,
            'rsn_invariant': R + S + N,  # Should be ~1.0
            'R': R, 'S': S, 'N': N,
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'VelocityStats',
    'LearningVelocityMonitor',
    'RewardComponents',
    'RewardSignalExtractor',
    'TrainingMetrics',
    'DWGRPOTrainer',
    'MultiObjectiveRSNTrainer',
]
