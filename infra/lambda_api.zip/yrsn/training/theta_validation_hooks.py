"""
Theta Validation Hooks for Training Scripts

Provides hooks to validate theta usage during training to ensure:
1. Correct theta type is being used
2. Values are in expected ranges
3. No units errors (degrees vs radians)
4. Best practices are followed (simplex_theta for domain classification)

Usage:
    from yrsn.training.theta_validation_hooks import (
        ThetaValidationHook,
        validate_rotor_output,
        validate_domain_classification,
    )

    # In training loop
    hook = ThetaValidationHook(strict=False)  # Warning mode
    hook.validate_forward_pass(out, batch_size=32)

    # Before domain classification
    validate_domain_classification(theta, use_simplex=True)
"""

import warnings
from typing import Dict, Any, Optional
import torch
import numpy as np

from yrsn.core.decomposition.theta_type_checker import (
    ThetaType,
    ThetaTypeChecker,
    validate_theta,
    get_theta_info,
)


class ThetaValidationHook:
    """
    Validation hook for theta in training loops.

    Validates theta values from rotor forward passes and provides
    warnings/errors for common issues.
    """

    def __init__(
        self,
        strict: bool = False,
        check_domains: bool = True,
        recommend_simplex: bool = True,
    ):
        """
        Initialize validation hook.

        Args:
            strict: If True, raise errors; if False, emit warnings
            check_domains: If True, validate domain classification usage
            recommend_simplex: If True, recommend simplex_theta for domains
        """
        self.strict = strict
        self.check_domains = check_domains
        self.recommend_simplex = recommend_simplex
        self.checker = ThetaTypeChecker(strict=strict, warn_on_issues=not strict)

        # Statistics
        self.validation_count = 0
        self.error_count = 0
        self.warning_count = 0

    def validate_forward_pass(
        self,
        rotor_output: Dict[str, torch.Tensor],
        batch_size: int,
        check_rsn: bool = True,
    ) -> bool:
        """
        Validate theta from rotor forward pass.

        Args:
            rotor_output: Dictionary from rotor forward pass
            batch_size: Expected batch size
            check_rsn: If True, also validate RSN components

        Returns:
            True if validation passes
        """
        self.validation_count += 1
        all_valid = True

        # Check for sample_theta
        if 'sample_theta' in rotor_output:
            sample_theta = rotor_output['sample_theta']

            result = self.checker.validate_theta(
                sample_theta,
                theta_type=ThetaType.SAMPLE,
                batch_size=batch_size,
            )

            if not result.is_valid:
                self.error_count += 1
                all_valid = False
                msg = f"sample_theta validation failed: {', '.join(result.errors)}"
                if self.strict:
                    raise ValueError(msg)
                else:
                    warnings.warn(msg)

        # Check RSN components if requested
        if check_rsn:
            for component in ['R', 'S', 'N']:
                if component in rotor_output:
                    values = rotor_output[component]

                    # Check shape
                    if values.shape[0] != batch_size:
                        self.error_count += 1
                        all_valid = False
                        msg = f"{component} shape mismatch: expected ({batch_size},), got {values.shape}"
                        if self.strict:
                            raise ValueError(msg)
                        else:
                            warnings.warn(msg)

                    # Check range [0, 1]
                    if torch.any(values < 0) or torch.any(values > 1):
                        self.error_count += 1
                        all_valid = False
                        msg = f"{component} values out of range [0,1]: [{values.min():.3f}, {values.max():.3f}]"
                        if self.strict:
                            raise ValueError(msg)
                        else:
                            warnings.warn(msg)

            # Check simplex constraint R+S+N=1
            if all(c in rotor_output for c in ['R', 'S', 'N']):
                R, S, N = rotor_output['R'], rotor_output['S'], rotor_output['N']
                simplex_sum = R + S + N
                violation = torch.abs(simplex_sum - 1.0)
                max_violation = violation.max().item()

                if max_violation > 1e-4:  # Tolerance
                    self.warning_count += 1
                    warnings.warn(
                        f"Simplex constraint violation: max |R+S+N-1| = {max_violation:.6f}"
                    )

        return all_valid

    def validate_domain_classification_usage(
        self,
        theta: Any,
        theta_source: str = "unknown",
    ) -> bool:
        """
        Validate theta being used for domain classification.

        Args:
            theta: Theta value being used
            theta_source: Source of theta (for warning messages)

        Returns:
            True if usage is optimal
        """
        if not self.check_domains:
            return True

        # Detect theta type
        info = get_theta_info(theta)
        theta_type = info['type']

        # Check if using simplex_theta (recommended)
        if theta_type == 'sample_theta' and self.recommend_simplex:
            self.warning_count += 1
            msg = (
                f"Using sample_theta for domain classification from {theta_source}. "
                f"Consider switching to simplex_theta (EXP-S4-158b: sharper boundaries, "
                f"EXP-S4-101b: 3.7x better for ADC extraction)"
            )
            warnings.warn(msg)
            return False

        # Check for linear approximation (broken)
        if theta_source == "linear_approximation":
            self.error_count += 1
            msg = (
                f"Using linear approximation (theta = -30*(N-0.33)) for domain classification. "
                f"This is BROKEN with ~40° constant error. Use simplex_theta instead."
            )
            if self.strict:
                raise ValueError(msg)
            else:
                warnings.warn(msg)
            return False

        return True

    def get_statistics(self) -> Dict[str, int]:
        """Get validation statistics."""
        return {
            'validation_count': self.validation_count,
            'error_count': self.error_count,
            'warning_count': self.warning_count,
        }

    def reset_statistics(self):
        """Reset validation statistics."""
        self.validation_count = 0
        self.error_count = 0
        self.warning_count = 0


# Convenience functions

def validate_rotor_output(
    rotor_output: Dict[str, torch.Tensor],
    batch_size: int,
    strict: bool = False,
) -> bool:
    """
    Validate rotor output dictionary.

    Convenience function for one-off validation without creating a hook.

    Args:
        rotor_output: Dictionary from rotor forward pass
        batch_size: Expected batch size
        strict: If True, raise errors; if False, emit warnings

    Returns:
        True if validation passes
    """
    hook = ThetaValidationHook(strict=strict)
    return hook.validate_forward_pass(rotor_output, batch_size)


def validate_domain_classification(
    theta: Any,
    use_simplex: bool = True,
    strict: bool = False,
) -> bool:
    """
    Validate theta usage for domain classification.

    Args:
        theta: Theta value being used
        use_simplex: If True, recommend simplex_theta
        strict: If True, raise errors on suboptimal usage

    Returns:
        True if usage is optimal

    Raises:
        ValueError: If strict=True and usage is broken
    """
    hook = ThetaValidationHook(strict=strict, recommend_simplex=use_simplex)
    theta_source = "provided_theta"

    # Try to detect source from value characteristics
    if isinstance(theta, np.ndarray):
        theta_source = "numpy_array (likely simplex_theta)"
    elif isinstance(theta, torch.Tensor):
        theta_source = "torch_tensor (likely sample_theta)"

    return hook.validate_domain_classification_usage(theta, theta_source)


def compute_simplex_theta_safe(
    R: torch.Tensor,
    S: torch.Tensor,
    N: torch.Tensor,
    validate: bool = True,
) -> np.ndarray:
    """
    Safely compute simplex_theta with validation.

    Args:
        R, S, N: RSN components from rotor
        validate: If True, validate inputs

    Returns:
        Simplex theta in degrees [-180, 180]

    Raises:
        ValueError: If validation fails
    """
    if validate:
        # Check shapes match
        if R.shape != S.shape or S.shape != N.shape:
            raise ValueError(f"Shape mismatch: R{R.shape}, S{S.shape}, N{N.shape}")

        # Check simplex constraint
        simplex_sum = R + S + N
        violation = torch.abs(simplex_sum - 1.0)
        max_violation = violation.max().item()

        if max_violation > 1e-4:
            raise ValueError(
                f"Simplex constraint violated: max |R+S+N-1| = {max_violation:.6f}. "
                f"Ensure rotor output is normalized."
            )

    # Convert to numpy
    R_np = R.detach().cpu().numpy()
    S_np = S.detach().cpu().numpy()
    N_np = N.detach().cpu().numpy()

    # Compute simplex theta
    x = R_np - (S_np + N_np) / 2
    y = (S_np - N_np) * np.sqrt(3) / 2
    theta_simplex = np.arctan2(y, x) * 180 / np.pi

    return theta_simplex


# Export all
__all__ = [
    'ThetaValidationHook',
    'validate_rotor_output',
    'validate_domain_classification',
    'compute_simplex_theta_safe',
]
