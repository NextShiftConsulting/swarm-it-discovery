#!/usr/bin/env python3
"""
Train Universal Rotor for Architecture-Independent RSN Decomposition

This script trains a HybridSimplexRotor on features from multiple neural network
architectures, enabling architecture-independent RSN decomposition.

The key insight: by training on features from ResNet, CNN, MLP, and potentially
external models, the rotor learns a universal projection that works across
different feature manifolds.

Usage:
    # Train on local models
    python -m yrsn.training.train_universal_rotor \\
        --models resnet20 simplecnn simplemlp \\
        --output checkpoints/trained_rotor_universal64.pt

    # With specific checkpoints
    python -m yrsn.training.train_universal_rotor \\
        --models resnet20 simplecnn simplemlp \\
        --cnn-checkpoint checkpoints/simple_cnn_cifar10.pt \\
        --mlp-checkpoint checkpoints/simple_mlp_cifar10.pt \\
        --output checkpoints/trained_rotor_universal64.pt

Reference: docs/UNIVERSAL_ROTOR_ARCHITECTURE.md
"""

import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple, Optional
import json

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.stats import spearmanr

import sys
PROJECT_ROOT = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from yrsn.ports.feature_extraction import IFeatureExtractor
from yrsn.core.normalize import standardize_features
from yrsn.core.decomposition import (
    HybridSimplexRotor,
    create_rotor,
)
from yrsn.training.theta_validation_hooks import (
    ThetaValidationHook,
    compute_simplex_theta_safe,
)


def load_extractors(
    model_names: List[str],
    cnn_checkpoint: Optional[str] = None,
    mlp_checkpoint: Optional[str] = None,
    device: str = 'cpu'
) -> List[IFeatureExtractor]:
    """
    Load feature extractors for the specified models.

    Args:
        model_names: List of model names ('resnet20', 'simplecnn', 'simplemlp')
        cnn_checkpoint: Path to SimpleCNN checkpoint (optional)
        mlp_checkpoint: Path to SimpleMLP checkpoint (optional)
        device: Device to load models on

    Returns:
        List of IFeatureExtractor instances
    """
    from yrsn.adapters.models import (
        ResNet20Extractor,
        SimpleCNNExtractor,
        SimpleMLPExtractor,
    )

    extractors = []

    for name in model_names:
        name = name.lower()

        if name == 'resnet20':
            extractors.append(ResNet20Extractor(device=device))
            print(f"  Loaded: ResNet20Extractor (dim={extractors[-1].feature_dim})")

        elif name == 'simplecnn':
            if cnn_checkpoint and Path(cnn_checkpoint).exists():
                extractor = SimpleCNNExtractor.from_checkpoint(cnn_checkpoint, device=device)
                print(f"  Loaded: SimpleCNNExtractor from {cnn_checkpoint}")
            else:
                extractor = SimpleCNNExtractor(device=device)
                print(f"  Loaded: SimpleCNNExtractor (random weights)")
            extractors.append(extractor)

        elif name == 'simplemlp':
            if mlp_checkpoint and Path(mlp_checkpoint).exists():
                extractor = SimpleMLPExtractor.from_checkpoint(mlp_checkpoint, device=device)
                print(f"  Loaded: SimpleMLPExtractor from {mlp_checkpoint}")
            else:
                extractor = SimpleMLPExtractor(device=device)
                print(f"  Loaded: SimpleMLPExtractor (random weights)")
            extractors.append(extractor)

        else:
            raise ValueError(f"Unknown model: {name}. Use 'resnet20', 'simplecnn', or 'simplemlp'")

    return extractors


def extract_features(
    extractors: List[IFeatureExtractor],
    data_loader: torch.utils.data.DataLoader,
    n_samples: int = 5000,
    normalize: bool = True,
    device: str = 'cpu'
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Extract features from all extractors on the same data.

    Args:
        extractors: List of feature extractors
        data_loader: DataLoader with input images
        n_samples: Maximum samples to extract per extractor
        normalize: Whether to L2 normalize features
        device: Device for extraction

    Returns:
        combined_features: [total_samples, feature_dim]
        model_ids: [total_samples] index of which model produced each sample
        is_error: [total_samples] boolean if sample was misclassified
    """
    all_features = []
    all_model_ids = []
    all_errors = []

    # Collect images and labels
    images_list = []
    labels_list = []
    count = 0

    for images, labels in data_loader:
        images_list.append(images)
        labels_list.append(labels)
        count += len(images)
        if count >= n_samples:
            break

    images = torch.cat(images_list)[:n_samples].to(device)
    labels = torch.cat(labels_list)[:n_samples]

    print(f"  Extracting from {len(images)} samples...")

    for idx, extractor in enumerate(extractors):
        print(f"    [{extractor.model_name}] Extracting features...")

        # Extract features
        features = extractor.extract(images.cpu().numpy())

        # Check for errors (simple heuristic: high-entropy predictions)
        # For universal training, we use synthetic error labels
        # based on feature outliers within each model
        from sklearn.neighbors import LocalOutlierFactor
        lof = LocalOutlierFactor(n_neighbors=20, contamination=0.1)
        is_outlier = lof.fit_predict(features) == -1

        all_features.append(features)
        all_model_ids.append(np.full(len(features), idx))
        all_errors.append(is_outlier)

        print(f"      Shape: {features.shape}, Outlier rate: {is_outlier.mean():.1%}")

    # Combine
    combined = np.vstack(all_features)
    model_ids = np.concatenate(all_model_ids)
    is_error = np.concatenate(all_errors)

    # Standardize if requested
    if normalize:
        combined = standardize_features(combined, method='l2')
        print(f"  Standardized features (L2 norm)")

    print(f"  Combined: {combined.shape}")
    return combined, model_ids, is_error


def train_universal_rotor(
    extractors: List[IFeatureExtractor],
    data_loader: torch.utils.data.DataLoader,
    output_path: str,
    epochs: int = 200,
    lr: float = 0.001,
    n_samples: int = 5000,
    variant: str = 'large',
    device: str = 'cpu',
    theta_consistency_weight: float = 0.1,
    theta_diversity_weight: float = 0.01,
) -> Dict:
    """
    Train a universal rotor on features from multiple architectures.

    Args:
        extractors: List of IFeatureExtractor instances
        data_loader: DataLoader for input images
        output_path: Where to save the trained checkpoint
        epochs: Training epochs
        lr: Learning rate
        n_samples: Samples per architecture
        variant: Rotor variant ('large', 'compact', etc.)
        device: Device for training

    Returns:
        Dict with training results and metrics
    """
    print("\n" + "=" * 70)
    print("UNIVERSAL ROTOR TRAINING")
    print("=" * 70)

    # Extract features from all models
    print("\n[Phase 1] Feature Extraction")
    features, model_ids, is_error = extract_features(
        extractors, data_loader, n_samples=n_samples, normalize=True, device=device
    )

    # Convert to tensors
    embeddings = torch.from_numpy(features).float()
    is_error_tensor = torch.from_numpy(is_error)

    # Get feature dimension
    feature_dim = features.shape[1]
    print(f"\n[Phase 2] Model Setup")
    print(f"  Feature dim: {feature_dim}")
    print(f"  Variant: {variant}")

    # Create rotor
    rotor = create_rotor(embed_dim=feature_dim, variant=variant)
    print(f"  Rotor: {type(rotor).__name__}")
    print(f"  Parameters: {rotor.param_count:,}")
    print(f"  Initial theta: {rotor.get_angle_degrees():.1f} degrees")

    # Training
    print(f"\n[Phase 3] Training ({epochs} epochs)")
    rotor = rotor.to(device)
    embeddings = embeddings.to(device)
    is_error_tensor = is_error_tensor.to(device)

    # Initialize validation hook
    theta_hook = ThetaValidationHook(strict=False, recommend_simplex=True)
    print(f"  Theta validation: enabled (recommend simplex_theta)")

    optimizer = torch.optim.Adam(rotor.parameters(), lr=lr)

    # Target: errors should have high N, non-errors high R
    N_target = is_error_tensor.float()
    R_target = 1.0 - N_target
    S_target = torch.zeros_like(N_target) + 0.1
    total = R_target + S_target + N_target
    targets = torch.stack([R_target / total, S_target / total, N_target / total], dim=-1)

    history = {'loss': [], 'rsn_loss': [], 'theta_loss': [], 'correlation': [], 'per_model_correlation': {}}

    # Number of models and samples per model for theta consistency
    n_models = len(extractors)
    samples_per_model = n_samples

    for epoch in range(epochs):
        optimizer.zero_grad()
        out = rotor(embeddings)
        pred = torch.stack([out['R'], out['S'], out['N']], dim=-1)

        # Validate rotor output (only on first epoch to check setup)
        if epoch == 0:
            theta_hook.validate_forward_pass(out, batch_size=len(embeddings))

        # Primary RSN loss
        rsn_loss = F.mse_loss(pred, targets)

        # Cross-architecture domain agreement loss (rotation-based regularization)
        # Only penalize when thetas cross domain boundaries (±5°)
        # This preserves N variance while encouraging domain agreement
        # Use simplex_theta per EXP-S4-158b recommendation (sharper boundaries)
        theta_loss = torch.tensor(0.0, device=device)
        if theta_consistency_weight > 0 and n_models > 1:
            # Compute simplex_theta from RSN (recommended for domain classification)
            simplex_theta = compute_simplex_theta_safe(
                out['R'], out['S'], out['N'], validate=False
            )
            simplex_theta_tensor = torch.from_numpy(simplex_theta).float().to(device)
            # Reshape to [n_models, samples_per_model]
            theta_by_model = simplex_theta_tensor.view(n_models, samples_per_model)

            # Domain boundaries at -5 and +5 degrees
            compression_boundary = -5.0
            expansion_boundary = 5.0

            # For each pair of models, penalize domain disagreement
            domain_penalties = []
            for i in range(n_models):
                for j in range(i+1, n_models):
                    theta_i = theta_by_model[i]  # [samples_per_model]
                    theta_j = theta_by_model[j]  # [samples_per_model]

                    # Check for domain crossing (soft penalty)
                    # Penalty = 0 if same domain, increases with distance when crossing
                    # Using soft indicators for differentiability

                    # Domain indicators (soft via sigmoid)
                    compress_i = torch.sigmoid(-(theta_i - compression_boundary) * 2)  # High if compression
                    compress_j = torch.sigmoid(-(theta_j - compression_boundary) * 2)
                    expand_i = torch.sigmoid((theta_i - expansion_boundary) * 2)  # High if expansion
                    expand_j = torch.sigmoid((theta_j - expansion_boundary) * 2)
                    neutral_i = 1 - compress_i - expand_i  # Neutral region
                    neutral_j = 1 - compress_j - expand_j

                    # Domain agreement score (sum of pairwise domain matches)
                    agreement = (compress_i * compress_j +
                                neutral_i * neutral_j +
                                expand_i * expand_j)

                    # Penalty for disagreement
                    domain_penalties.append((1 - agreement).mean())

            theta_loss = torch.stack(domain_penalties).mean() if domain_penalties else torch.tensor(0.0, device=device)

        # Within-architecture domain diversity loss
        # Key insight: H5 needs diversity WITHIN each architecture, not across
        # So we compute diversity loss separately for each model's samples
        # Use simplex_theta per EXP-S4-158b recommendation (sharper boundaries)
        diversity_loss = torch.tensor(0.0, device=device)
        if theta_diversity_weight > 0:
            # Compute simplex_theta from RSN (recommended for domain classification)
            simplex_theta = compute_simplex_theta_safe(
                out['R'], out['S'], out['N'], validate=False
            )
            simplex_theta_tensor = torch.from_numpy(simplex_theta).float().to(device)
            theta_by_model = simplex_theta_tensor.view(n_models, samples_per_model)
            N_by_model = N_target.view(n_models, samples_per_model)

            model_diversity_losses = []
            for m in range(n_models):
                model_theta = theta_by_model[m]  # [samples_per_model]
                model_N = N_by_model[m]  # [samples_per_model]

                error_mask = model_N > 0.5
                normal_mask = ~error_mask

                if error_mask.sum() > 5 and normal_mask.sum() > 5:
                    error_theta = model_theta[error_mask]
                    normal_theta = model_theta[normal_mask]

                    compression_boundary = -5.0
                    expansion_boundary = 5.0

                    # Push normal samples below compression boundary (COMPRESSION domain)
                    normal_violation = F.relu(normal_theta - compression_boundary)
                    # Push error samples above expansion boundary (EXPANSION domain)
                    error_violation = F.relu(expansion_boundary - error_theta)

                    model_loss = normal_violation.mean() + error_violation.mean()
                    model_diversity_losses.append(model_loss)

            if model_diversity_losses:
                diversity_loss = torch.stack(model_diversity_losses).mean()

        loss = rsn_loss + theta_consistency_weight * theta_loss + theta_diversity_weight * diversity_loss
        loss.backward()
        optimizer.step()

        history['loss'].append(loss.item())
        history['rsn_loss'].append(rsn_loss.item())
        history['theta_loss'].append(theta_loss.item() if isinstance(theta_loss, torch.Tensor) else theta_loss)
        history['diversity_loss'] = history.get('diversity_loss', [])
        history['diversity_loss'].append(diversity_loss.item() if isinstance(diversity_loss, torch.Tensor) else diversity_loss)

        # Log periodically
        if (epoch + 1) % 20 == 0 or epoch == epochs - 1:
            with torch.no_grad():
                N_pred = out['N'].cpu().numpy()
                is_err = is_error.astype(float)
                corr, _ = spearmanr(N_pred, is_err)
                history['correlation'].append(corr)

                # Per-model correlation
                for idx, extractor in enumerate(extractors):
                    mask = model_ids == idx
                    if mask.sum() > 10:
                        model_corr, _ = spearmanr(N_pred[mask], is_err[mask])
                        if extractor.model_name not in history['per_model_correlation']:
                            history['per_model_correlation'][extractor.model_name] = []
                        history['per_model_correlation'][extractor.model_name].append(model_corr)

            theta = rotor.get_angle_degrees()
            theta_loss_val = theta_loss.item() if isinstance(theta_loss, torch.Tensor) else theta_loss
            div_loss_val = diversity_loss.item() if isinstance(diversity_loss, torch.Tensor) else diversity_loss
            print(f"  Epoch {epoch+1}/{epochs}: loss={loss.item():.4f} "
                  f"(rsn={rsn_loss.item():.4f}, cons={theta_loss_val:.4f}, div={div_loss_val:.4f}), "
                  f"corr={corr:.3f}, angle={theta:.1f}deg")

    # Evaluation
    print(f"\n[Phase 4] Evaluation")
    rotor.eval()

    with torch.no_grad():
        out = rotor(embeddings)
        R = out['R'].cpu().numpy()
        S = out['S'].cpu().numpy()
        N = out['N'].cpu().numpy()

    final_corr, _ = spearmanr(N, is_error.astype(float))
    print(f"  Overall correlation: {final_corr:.3f}")

    # Per-model metrics
    per_model_metrics = {}
    for idx, extractor in enumerate(extractors):
        mask = model_ids == idx
        if mask.sum() > 10:
            model_corr, _ = spearmanr(N[mask], is_error[mask].astype(float))
            n_std = np.std(N[mask])
            r_mean = np.mean(R[mask])
            per_model_metrics[extractor.model_name] = {
                'correlation': float(model_corr),
                'N_std': float(n_std),
                'R_mean': float(r_mean),
                'samples': int(mask.sum()),
            }
            print(f"  [{extractor.model_name}] corr={model_corr:.3f}, N_std={n_std:.4f}")

    # Cross-architecture theta agreement (domain classification)
    # Use simplex_theta per EXP-S4-158b recommendation (sharper boundaries)
    simplex_theta = compute_simplex_theta_safe(
        torch.from_numpy(R), torch.from_numpy(S), torch.from_numpy(N), validate=True
    )
    n_models = len(extractors)
    samples_per_model = n_samples

    if n_models > 1:
        theta_by_model = simplex_theta.reshape(n_models, samples_per_model)

        # Classify domains for each model
        def classify_domain(theta):
            if theta < -5.0:
                return 'COMPRESSION'
            elif theta > 5.0:
                return 'EXPANSION'
            else:
                return 'NEUTRAL'

        domain_agreement = {}
        model_names = [e.model_name for e in extractors]
        for i in range(n_models):
            for j in range(i+1, n_models):
                domains_i = [classify_domain(t) for t in theta_by_model[i]]
                domains_j = [classify_domain(t) for t in theta_by_model[j]]
                agreement = sum(d1 == d2 for d1, d2 in zip(domains_i, domains_j)) / samples_per_model
                pair = f"{model_names[i]}-{model_names[j]}"
                domain_agreement[pair] = agreement
                print(f"  Domain agreement ({pair}): {agreement*100:.1f}%")

        min_agreement = min(domain_agreement.values())
        print(f"  Min domain agreement: {min_agreement*100:.1f}%")

    # Save checkpoint
    print(f"\n[Phase 5] Saving Checkpoint")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    checkpoint = {
        'model_state_dict': rotor.state_dict(),
        'embed_dim': feature_dim,
        'rotor_variant': variant,
        'theta': rotor.theta.item(),
        'scale': rotor.scale.item(),
        'config': {
            'embed_dim': feature_dim,
            'hidden_dim': feature_dim,  # For compatibility
            'variant': variant,
        },
        'metadata': {
            'is_universal': True,
            'trained_on': [e.model_name for e in extractors],
            'samples_per_model': n_samples,
            'epochs': epochs,
            'theta_consistency_weight': theta_consistency_weight,
            'theta_diversity_weight': theta_diversity_weight,
            'final_correlation': float(final_corr),
            'per_model_metrics': per_model_metrics,
        },
        'history': history,
        'timestamp': datetime.now().isoformat(),
    }

    torch.save(checkpoint, output_path)
    print(f"  Saved: {output_path}")

    return {
        'checkpoint_path': str(output_path),
        'final_correlation': final_corr,
        'per_model_metrics': per_model_metrics,
        'history': history,
    }


def main():
    parser = argparse.ArgumentParser(description='Train Universal Rotor')
    parser.add_argument('--models', nargs='+', default=['resnet20', 'simplecnn', 'simplemlp'],
                        help='Models to train on')
    parser.add_argument('--output', type=str, default='checkpoints/trained_rotor_universal64.pt',
                        help='Output checkpoint path')
    parser.add_argument('--epochs', type=int, default=200, help='Training epochs')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--n-samples', type=int, default=5000, help='Samples per model')
    parser.add_argument('--variant', type=str, default='large',
                        choices=['large', 'compact', 'tiny', 'pure'])
    parser.add_argument('--cnn-checkpoint', type=str, default='checkpoints/simple_cnn_cifar10.pt',
                        help='SimpleCNN checkpoint path')
    parser.add_argument('--mlp-checkpoint', type=str, default='checkpoints/simple_mlp_cifar10.pt',
                        help='SimpleMLP checkpoint path')
    parser.add_argument('--device', type=str, default='cpu', help='Device')
    parser.add_argument('--theta-consistency', type=float, default=0.1,
                        help='Weight for cross-architecture theta consistency loss (0=disabled)')
    parser.add_argument('--theta-diversity', type=float, default=0.01,
                        help='Weight for within-architecture theta diversity loss (0=disabled)')
    args = parser.parse_args()

    print("=" * 70)
    print("Universal Rotor Training")
    print("=" * 70)
    print(f"\nModels: {args.models}")
    print(f"Output: {args.output}")
    print(f"Epochs: {args.epochs}")
    print(f"Samples per model: {args.n_samples}")
    print(f"Theta consistency weight: {args.theta_consistency}")
    print(f"Theta diversity weight: {args.theta_diversity}")

    # Load data
    print("\n[Setup] Loading CIFAR-10...")
    from torchvision import datasets, transforms
    from yrsn.utils.data_loading import CIFAR10_MEAN, CIFAR10_STD

    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD)
    ])

    train_dataset = datasets.CIFAR10(
        root='./data', train=True, download=True, transform=transform
    )
    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=256, shuffle=True, num_workers=0
    )

    # Load extractors
    print("\n[Setup] Loading Feature Extractors...")
    extractors = load_extractors(
        args.models,
        cnn_checkpoint=args.cnn_checkpoint,
        mlp_checkpoint=args.mlp_checkpoint,
        device=args.device
    )

    # Train
    results = train_universal_rotor(
        extractors=extractors,
        data_loader=train_loader,
        output_path=args.output,
        epochs=args.epochs,
        lr=args.lr,
        n_samples=args.n_samples,
        variant=args.variant,
        device=args.device,
        theta_consistency_weight=args.theta_consistency,
        theta_diversity_weight=args.theta_diversity,
    )

    print("\n" + "=" * 70)
    print("TRAINING COMPLETE")
    print("=" * 70)
    print(f"\nCheckpoint: {results['checkpoint_path']}")
    print(f"Final correlation: {results['final_correlation']:.3f}")
    print("\nPer-model metrics:")
    for model, metrics in results['per_model_metrics'].items():
        print(f"  {model}: corr={metrics['correlation']:.3f}, N_std={metrics['N_std']:.4f}")


if __name__ == '__main__':
    main()
