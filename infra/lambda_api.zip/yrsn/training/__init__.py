"""
YRSN Training Utilities

Scripts and utilities for training RSN components.

Modules:
    - train_universal_rotor: Train architecture-agnostic rotor
    - federated: Federated learning for distributed training
"""

from yrsn.training.train_universal_rotor import train_universal_rotor

# Federated training
from yrsn.training.federated import (
    FederatedConfig,
    FederatedTrainer,
    FederatedAggregator,
    LocalFederatedClient,
)

__all__ = [
    "train_universal_rotor",
    # Federated
    "FederatedConfig",
    "FederatedTrainer",
    "FederatedAggregator",
    "LocalFederatedClient",
]
