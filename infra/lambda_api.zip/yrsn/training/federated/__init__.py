"""
YRSN Federated Training Framework

Enables training Universal Rotor across distributed data sources
without centralizing sensitive data.

Hexagonal Architecture:
    PORTS (Interfaces):
    - IFederatedClient: Client-side training interface
    - IFederatedServer: Server-side aggregation interface
    - IModelSerializer: Model serialization interface

    ADAPTERS (Implementations):
    - LocalFederatedClient: In-process simulation
    - FederatedAggregator: FedAvg aggregation
    - TorchModelSerializer: PyTorch serialization

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 9)
    - docs/principles/FIRST_PRINCIPLES.md (P15: Universal Rotor)

Usage:
    >>> from yrsn.federated import FederatedTrainer, FederatedConfig
    >>>
    >>> # Create federated trainer
    >>> trainer = FederatedTrainer(config=FederatedConfig(n_clients=5))
    >>>
    >>> # Simulate federated training round
    >>> global_model = trainer.train_round(client_data_loaders)
"""

from .base import (
    IFederatedClient,
    IFederatedServer,
    IModelSerializer,
    FederatedConfig,
    ClientUpdate,
)
from .aggregator import FederatedAggregator
from .client import LocalFederatedClient
from .trainer import FederatedTrainer

__all__ = [
    # Ports
    'IFederatedClient',
    'IFederatedServer',
    'IModelSerializer',
    # Types
    'FederatedConfig',
    'ClientUpdate',
    # Adapters
    'FederatedAggregator',
    'LocalFederatedClient',
    'FederatedTrainer',
]
