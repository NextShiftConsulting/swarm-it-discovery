"""
Federated Training Base Types and Ports

Defines interfaces (ports) for federated learning components,
following hexagonal architecture principles.

Reference:
    - docs/principles/FIRST_PRINCIPLES.md
    - P15: Universal Rotor (what we're training)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, Tuple, runtime_checkable
import numpy as np


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class FederatedConfig:
    """
    Configuration for federated training.

    Attributes:
        n_clients: Number of federated clients
        rounds: Number of training rounds
        local_epochs: Epochs per client per round
        learning_rate: Client learning rate
        batch_size: Client batch size
        aggregation_method: 'fedavg', 'fedprox', 'scaffold'
        client_fraction: Fraction of clients per round
        differential_privacy: Enable DP
        dp_epsilon: DP epsilon parameter
        secure_aggregation: Enable secure aggregation
    """
    n_clients: int = 5
    rounds: int = 10
    local_epochs: int = 3
    learning_rate: float = 0.01
    batch_size: int = 32

    aggregation_method: str = "fedavg"
    client_fraction: float = 1.0  # Fraction of clients per round

    # Privacy settings
    differential_privacy: bool = False
    dp_epsilon: float = 1.0
    dp_delta: float = 1e-5
    clip_norm: float = 1.0

    # Security settings
    secure_aggregation: bool = False

    # Model settings
    embed_dim: int = 64
    rotor_checkpoint: Optional[str] = None


@dataclass
class ClientUpdate:
    """
    Update from a federated client after local training.

    Contains model delta (not full weights) for efficiency.
    """
    client_id: str
    round_id: int
    model_delta: Dict[str, np.ndarray]  # Parameter name -> delta
    n_samples: int
    local_loss: float
    metrics: Dict[str, float] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_weight(self) -> float:
        """Get weighting factor based on sample count."""
        return float(self.n_samples)


@dataclass
class AggregatedUpdate:
    """Result of aggregating client updates."""
    round_id: int
    aggregated_delta: Dict[str, np.ndarray]
    n_clients: int
    total_samples: int
    avg_loss: float
    metrics: Dict[str, float] = field(default_factory=dict)


# =============================================================================
# PORTS (Interfaces)
# =============================================================================

@runtime_checkable
class IFederatedClient(Protocol):
    """
    Port: Federated learning client interface.

    A client trains locally on private data and returns
    model updates (deltas) to the server.
    """

    @property
    def client_id(self) -> str:
        """Unique client identifier."""
        ...

    def train_local(
        self,
        global_model_state: Dict[str, np.ndarray],
        round_id: int,
    ) -> ClientUpdate:
        """
        Perform local training and return update.

        Args:
            global_model_state: Current global model parameters
            round_id: Current training round

        Returns:
            ClientUpdate with model delta and metrics
        """
        ...

    def evaluate_local(
        self,
        model_state: Dict[str, np.ndarray],
    ) -> Dict[str, float]:
        """
        Evaluate model on local validation data.

        Args:
            model_state: Model parameters to evaluate

        Returns:
            Dict of metric name -> value
        """
        ...


@runtime_checkable
class IFederatedServer(Protocol):
    """
    Port: Federated learning server interface.

    The server aggregates client updates and manages
    the global model.
    """

    def aggregate(
        self,
        updates: List[ClientUpdate],
    ) -> AggregatedUpdate:
        """
        Aggregate client updates into global update.

        Args:
            updates: List of client updates

        Returns:
            AggregatedUpdate with combined model delta
        """
        ...

    def apply_update(
        self,
        model_state: Dict[str, np.ndarray],
        update: AggregatedUpdate,
    ) -> Dict[str, np.ndarray]:
        """
        Apply aggregated update to global model.

        Args:
            model_state: Current global model
            update: Aggregated update to apply

        Returns:
            Updated model state
        """
        ...


@runtime_checkable
class IModelSerializer(Protocol):
    """
    Port: Model serialization interface.

    Handles conversion between PyTorch models and
    numpy arrays for federation.
    """

    def serialize(self, model: Any) -> Dict[str, np.ndarray]:
        """Serialize model to numpy arrays."""
        ...

    def deserialize(self, state: Dict[str, np.ndarray], model: Any) -> Any:
        """Deserialize numpy arrays back to model."""
        ...

    def compute_delta(
        self,
        state_before: Dict[str, np.ndarray],
        state_after: Dict[str, np.ndarray],
    ) -> Dict[str, np.ndarray]:
        """Compute parameter delta."""
        ...

    def apply_delta(
        self,
        state: Dict[str, np.ndarray],
        delta: Dict[str, np.ndarray],
    ) -> Dict[str, np.ndarray]:
        """Apply delta to state."""
        ...


# =============================================================================
# Privacy Utilities
# =============================================================================

def clip_gradients(
    gradients: Dict[str, np.ndarray],
    clip_norm: float,
) -> Tuple[Dict[str, np.ndarray], float]:
    """
    Clip gradients to bounded L2 norm for differential privacy.

    Args:
        gradients: Dict of parameter gradients
        clip_norm: Maximum L2 norm

    Returns:
        (clipped_gradients, scale_factor)
    """
    # Compute total L2 norm
    total_norm = 0.0
    for g in gradients.values():
        total_norm += np.sum(g ** 2)
    total_norm = np.sqrt(total_norm)

    # Compute scale factor
    scale = min(1.0, clip_norm / (total_norm + 1e-8))

    # Clip gradients
    clipped = {k: v * scale for k, v in gradients.items()}

    return clipped, scale


def add_gaussian_noise(
    gradients: Dict[str, np.ndarray],
    noise_scale: float,
    clip_norm: float,
) -> Dict[str, np.ndarray]:
    """
    Add Gaussian noise for differential privacy.

    Args:
        gradients: Dict of parameter gradients
        noise_scale: Noise multiplier (sigma / clip_norm)
        clip_norm: Gradient clipping norm

    Returns:
        Noisy gradients
    """
    sigma = noise_scale * clip_norm
    noisy = {}

    for k, v in gradients.items():
        noise = np.random.normal(0, sigma, v.shape)
        noisy[k] = v + noise

    return noisy
