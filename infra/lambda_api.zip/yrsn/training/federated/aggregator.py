"""
Federated Aggregator (Server-Side)

Implements IFederatedServer port for aggregating client updates.

Aggregation Methods:
- FedAvg: Weighted average by sample count
- FedProx: FedAvg with proximal term (not implemented)
- Scaffold: Variance reduction (not implemented)

Reference:
    - McMahan et al., "Communication-Efficient Learning of Deep Networks
      from Decentralized Data" (FedAvg)
"""

from typing import Dict, List, Optional
import numpy as np

from .base import (
    IFederatedServer,
    ClientUpdate,
    AggregatedUpdate,
    FederatedConfig,
    add_gaussian_noise,
)


class FederatedAggregator:
    """
    Federated learning aggregator (server).

    Implements FedAvg aggregation with optional differential privacy.
    """

    def __init__(self, config: Optional[FederatedConfig] = None):
        self.config = config or FederatedConfig()

    def aggregate(self, updates: List[ClientUpdate]) -> AggregatedUpdate:
        """
        Aggregate client updates using FedAvg.

        FedAvg formula:
            delta_global = sum(n_i * delta_i) / sum(n_i)

        Where n_i is the number of samples at client i.
        """
        if not updates:
            raise ValueError("No updates to aggregate")

        round_id = updates[0].round_id

        # Collect weights (sample counts)
        weights = np.array([u.get_weight() for u in updates])
        total_weight = weights.sum()
        normalized_weights = weights / total_weight

        # Get parameter keys from first update
        param_keys = list(updates[0].model_delta.keys())

        # Weighted average of deltas
        aggregated_delta = {}
        for key in param_keys:
            weighted_sum = sum(
                w * u.model_delta[key]
                for w, u in zip(normalized_weights, updates)
            )
            aggregated_delta[key] = weighted_sum

        # Apply differential privacy noise if enabled
        if self.config.differential_privacy:
            noise_scale = self._compute_noise_scale()
            aggregated_delta = add_gaussian_noise(
                aggregated_delta,
                noise_scale,
                self.config.clip_norm,
            )

        # Compute average loss
        avg_loss = sum(u.local_loss * w for u, w in zip(updates, normalized_weights))

        return AggregatedUpdate(
            round_id=round_id,
            aggregated_delta=aggregated_delta,
            n_clients=len(updates),
            total_samples=int(total_weight),
            avg_loss=avg_loss,
        )

    def apply_update(
        self,
        model_state: Dict[str, np.ndarray],
        update: AggregatedUpdate,
    ) -> Dict[str, np.ndarray]:
        """
        Apply aggregated update to global model.

        new_state = old_state + delta
        """
        new_state = {}
        for key in model_state:
            if key in update.aggregated_delta:
                new_state[key] = model_state[key] + update.aggregated_delta[key]
            else:
                new_state[key] = model_state[key]
        return new_state

    def _compute_noise_scale(self) -> float:
        """
        Compute noise scale for (epsilon, delta)-DP.

        Using simple Gaussian mechanism for now.
        For tighter bounds, use moments accountant.
        """
        epsilon = self.config.dp_epsilon
        delta = self.config.dp_delta
        n_clients = self.config.n_clients

        # Simple Gaussian mechanism noise scale
        # sigma = sqrt(2 * ln(1.25/delta)) / epsilon
        import math
        noise_scale = math.sqrt(2 * math.log(1.25 / delta)) / epsilon

        # Scale by number of clients (composition)
        noise_scale *= math.sqrt(n_clients)

        return noise_scale


class SecureAggregator(FederatedAggregator):
    """
    Secure aggregation variant.

    Uses secret sharing so server only sees aggregate,
    not individual client updates.

    Note: This is a simplified placeholder. Production secure
    aggregation requires cryptographic protocols (e.g., SPDZ).
    """

    def __init__(self, config: Optional[FederatedConfig] = None):
        super().__init__(config)
        self._shares: Dict[str, List] = {}

    def collect_share(self, client_id: str, share: Dict[str, np.ndarray]) -> None:
        """Collect a secret share from a client."""
        if client_id not in self._shares:
            self._shares[client_id] = []
        self._shares[client_id].append(share)

    def aggregate_secure(self) -> AggregatedUpdate:
        """
        Aggregate using collected shares.

        In real secure aggregation:
        1. Clients split updates into shares
        2. Shares are distributed to other clients
        3. Server collects reconstructed aggregates
        4. Individual updates are never revealed

        This placeholder just sums the shares.
        """
        if not self._shares:
            raise ValueError("No shares collected")

        # Placeholder: Simple sum (not actually secure)
        all_shares = list(self._shares.values())
        param_keys = list(all_shares[0][0].keys())

        aggregated = {}
        for key in param_keys:
            total = sum(
                share[key]
                for client_shares in all_shares
                for share in client_shares
            )
            aggregated[key] = total / len(self._shares)

        self._shares.clear()

        return AggregatedUpdate(
            round_id=0,
            aggregated_delta=aggregated,
            n_clients=len(all_shares),
            total_samples=0,
            avg_loss=0.0,
        )
