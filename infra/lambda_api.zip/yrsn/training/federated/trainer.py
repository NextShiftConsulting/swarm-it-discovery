"""
Federated Training Orchestrator

Coordinates federated training rounds across clients.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 9)
    - docs/principles/FIRST_PRINCIPLES.md (P15: Universal Rotor)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np
import random

from .base import FederatedConfig, ClientUpdate, AggregatedUpdate
from .aggregator import FederatedAggregator
from .client import LocalFederatedClient, TorchModelSerializer


@dataclass
class RoundResult:
    """Result of a federated training round."""
    round_id: int
    n_clients: int
    total_samples: int
    avg_loss: float
    aggregated_metrics: Dict[str, float] = field(default_factory=dict)


@dataclass
class TrainingResult:
    """Result of complete federated training."""
    n_rounds: int
    final_loss: float
    round_results: List[RoundResult]
    final_model_state: Dict[str, np.ndarray]


class FederatedTrainer:
    """
    Federated training orchestrator.

    Manages the training loop:
    1. Select clients for round
    2. Distribute global model
    3. Collect client updates
    4. Aggregate updates
    5. Update global model
    6. Repeat
    """

    def __init__(
        self,
        clients: Optional[List[LocalFederatedClient]] = None,
        config: Optional[FederatedConfig] = None,
    ):
        self.clients = clients or []
        self.config = config or FederatedConfig()

        self._aggregator = FederatedAggregator(self.config)
        self._serializer = TorchModelSerializer()

        self._global_model = None
        self._global_state: Dict[str, np.ndarray] = {}
        self._round_id = 0

    def add_client(self, client: LocalFederatedClient) -> None:
        """Add a client to the federation."""
        self.clients.append(client)

    def initialize_global_model(self, model: Optional[Any] = None) -> None:
        """
        Initialize the global model.

        If no model provided, creates HybridSimplexRotor per P15.
        """
        if model is not None:
            self._global_model = model
        else:
            from yrsn.core.decomposition import HybridSimplexRotor
            self._global_model = HybridSimplexRotor(embed_dim=self.config.embed_dim)

            # Load checkpoint if specified
            if self.config.rotor_checkpoint:
                import torch
                try:
                    checkpoint = torch.load(
                        self.config.rotor_checkpoint,
                        map_location='cpu',
                    )
                    self._global_model.load_state_dict(checkpoint)
                except FileNotFoundError:
                    pass

        self._global_state = self._serializer.serialize(self._global_model)

    def train_round(
        self,
        client_fraction: Optional[float] = None,
    ) -> RoundResult:
        """
        Execute one federated training round.

        Args:
            client_fraction: Override fraction of clients to use

        Returns:
            RoundResult with round metrics
        """
        if not self.clients:
            raise ValueError("No clients in federation")

        if not self._global_state:
            self.initialize_global_model()

        self._round_id += 1
        fraction = client_fraction or self.config.client_fraction

        # Select clients for this round
        n_selected = max(1, int(len(self.clients) * fraction))
        selected_clients = random.sample(self.clients, n_selected)

        # Collect updates from selected clients
        updates = []
        for client in selected_clients:
            update = client.train_local(self._global_state, self._round_id)
            updates.append(update)

        # Aggregate updates
        aggregated = self._aggregator.aggregate(updates)

        # Update global model
        self._global_state = self._aggregator.apply_update(
            self._global_state,
            aggregated,
        )

        return RoundResult(
            round_id=self._round_id,
            n_clients=len(selected_clients),
            total_samples=aggregated.total_samples,
            avg_loss=aggregated.avg_loss,
        )

    def train(
        self,
        n_rounds: Optional[int] = None,
        callback: Optional[callable] = None,
    ) -> TrainingResult:
        """
        Execute full federated training.

        Args:
            n_rounds: Number of rounds (overrides config)
            callback: Optional callback(round_result) after each round

        Returns:
            TrainingResult with all round results
        """
        rounds = n_rounds or self.config.rounds
        round_results = []

        for _ in range(rounds):
            result = self.train_round()
            round_results.append(result)

            if callback:
                callback(result)

        return TrainingResult(
            n_rounds=len(round_results),
            final_loss=round_results[-1].avg_loss if round_results else 0.0,
            round_results=round_results,
            final_model_state=self._global_state.copy(),
        )

    def evaluate_global(self) -> Dict[str, float]:
        """
        Evaluate global model on all clients' validation data.

        Returns aggregate metrics.
        """
        if not self._global_state:
            return {}

        all_metrics = []
        for client in self.clients:
            metrics = client.evaluate_local(self._global_state)
            if metrics:
                all_metrics.append(metrics)

        if not all_metrics:
            return {}

        # Aggregate metrics
        aggregated = {}
        for key in all_metrics[0]:
            values = [m[key] for m in all_metrics if key in m]
            aggregated[f"avg_{key}"] = np.mean(values)
            aggregated[f"std_{key}"] = np.std(values)

        return aggregated

    def save_global_model(self, path: str) -> None:
        """Save global model to checkpoint."""
        import torch

        if self._global_model is None:
            raise ValueError("No global model initialized")

        # Update model with current state
        self._serializer.deserialize(self._global_state, self._global_model)

        # Save
        torch.save(self._global_model.state_dict(), path)

    def load_global_model(self, path: str) -> None:
        """Load global model from checkpoint."""
        import torch

        if self._global_model is None:
            self.initialize_global_model()

        checkpoint = torch.load(path, map_location='cpu')
        self._global_model.load_state_dict(checkpoint)
        self._global_state = self._serializer.serialize(self._global_model)

    @property
    def global_model_state(self) -> Dict[str, np.ndarray]:
        """Get current global model state."""
        return self._global_state.copy()

    @property
    def n_clients(self) -> int:
        """Number of clients in federation."""
        return len(self.clients)


# =============================================================================
# Convenience Functions
# =============================================================================

def run_federated_simulation(
    n_clients: int = 5,
    n_rounds: int = 10,
    data_per_client: int = 100,
    embed_dim: int = 64,
    verbose: bool = True,
) -> TrainingResult:
    """
    Run a simulated federated training session.

    Useful for testing and demonstration.
    """
    from .client import create_simulated_clients

    # Configuration
    config = FederatedConfig(
        n_clients=n_clients,
        rounds=n_rounds,
        local_epochs=2,
        learning_rate=0.01,
        batch_size=32,
        embed_dim=embed_dim,
    )

    # Create simulated clients
    clients = create_simulated_clients(
        n_clients=n_clients,
        data_per_client=data_per_client,
        embed_dim=embed_dim,
        config=config,
    )

    # Create trainer
    trainer = FederatedTrainer(clients=clients, config=config)
    trainer.initialize_global_model()

    # Training callback
    def log_round(result: RoundResult):
        if verbose:
            print(f"Round {result.round_id}: loss={result.avg_loss:.4f}, "
                  f"clients={result.n_clients}, samples={result.total_samples}")

    # Run training
    result = trainer.train(callback=log_round)

    if verbose:
        print(f"\nTraining complete: {result.n_rounds} rounds, "
              f"final_loss={result.final_loss:.4f}")

    return result
