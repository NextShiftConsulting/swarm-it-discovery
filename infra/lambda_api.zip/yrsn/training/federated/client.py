"""
Federated Client Implementation

Implements IFederatedClient port for local training.

Reference:
    - docs/principles/FIRST_PRINCIPLES.md (P15: Universal Rotor)
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np

from .base import (
    IFederatedClient,
    ClientUpdate,
    FederatedConfig,
    clip_gradients,
)


class TorchModelSerializer:
    """
    Serializer for PyTorch models.

    Converts between torch tensors and numpy arrays.
    """

    def serialize(self, model: Any) -> Dict[str, np.ndarray]:
        """Serialize model to numpy arrays."""
        import torch
        state = {}
        for name, param in model.state_dict().items():
            state[name] = param.cpu().numpy()
        return state

    def deserialize(self, state: Dict[str, np.ndarray], model: Any) -> Any:
        """Deserialize numpy arrays back to model."""
        import torch
        torch_state = {}
        for name, arr in state.items():
            torch_state[name] = torch.from_numpy(arr)
        model.load_state_dict(torch_state)
        return model

    def compute_delta(
        self,
        state_before: Dict[str, np.ndarray],
        state_after: Dict[str, np.ndarray],
    ) -> Dict[str, np.ndarray]:
        """Compute parameter delta."""
        delta = {}
        for key in state_before:
            delta[key] = state_after[key] - state_before[key]
        return delta

    def apply_delta(
        self,
        state: Dict[str, np.ndarray],
        delta: Dict[str, np.ndarray],
    ) -> Dict[str, np.ndarray]:
        """Apply delta to state."""
        new_state = {}
        for key in state:
            if key in delta:
                new_state[key] = state[key] + delta[key]
            else:
                new_state[key] = state[key]
        return new_state


class LocalFederatedClient:
    """
    Federated client for local training.

    This client:
    1. Receives global model from server
    2. Trains locally on private data
    3. Returns model delta (not full weights)
    """

    def __init__(
        self,
        client_id: str,
        data_loader: Any,  # PyTorch DataLoader
        config: Optional[FederatedConfig] = None,
        val_loader: Optional[Any] = None,
    ):
        self._client_id = client_id
        self._data_loader = data_loader
        self._val_loader = val_loader
        self._config = config or FederatedConfig()
        self._serializer = TorchModelSerializer()

        self._model = None
        self._optimizer = None

    @property
    def client_id(self) -> str:
        return self._client_id

    def train_local(
        self,
        global_model_state: Dict[str, np.ndarray],
        round_id: int,
    ) -> ClientUpdate:
        """
        Perform local training and return update.

        Training follows P15 (Universal Rotor):
        - Uses HybridSimplexRotor architecture
        - Trains on local quality-labeled data
        - Returns delta for federation
        """
        import torch
        import torch.nn as nn

        # Initialize or update local model
        if self._model is None:
            self._init_model()

        # Load global state
        state_before = global_model_state.copy()
        self._serializer.deserialize(global_model_state, self._model)

        # Create optimizer
        optimizer = torch.optim.SGD(
            self._model.parameters(),
            lr=self._config.learning_rate,
        )

        # Local training
        self._model.train()
        total_loss = 0.0
        n_batches = 0
        n_samples = 0

        for epoch in range(self._config.local_epochs):
            for batch in self._data_loader:
                # Unpack batch (assuming features, labels format)
                if isinstance(batch, (list, tuple)):
                    features = batch[0]
                    # labels = batch[1] if len(batch) > 1 else None
                else:
                    features = batch

                # Forward pass
                optimizer.zero_grad()
                output = self._model(features)

                # Compute loss (self-supervised for rotor)
                loss = self._compute_loss(output, features)

                # Backward pass
                loss.backward()

                # Gradient clipping for DP
                if self._config.differential_privacy:
                    torch.nn.utils.clip_grad_norm_(
                        self._model.parameters(),
                        self._config.clip_norm,
                    )

                optimizer.step()

                total_loss += loss.item()
                n_batches += 1
                n_samples += features.shape[0]

        # Get state after training
        state_after = self._serializer.serialize(self._model)

        # Compute delta
        delta = self._serializer.compute_delta(state_before, state_after)

        # Clip delta for DP
        if self._config.differential_privacy:
            delta, _ = clip_gradients(delta, self._config.clip_norm)

        avg_loss = total_loss / n_batches if n_batches > 0 else 0.0

        return ClientUpdate(
            client_id=self._client_id,
            round_id=round_id,
            model_delta=delta,
            n_samples=n_samples,
            local_loss=avg_loss,
            metrics={
                'epochs': self._config.local_epochs,
                'batches': n_batches,
            },
        )

    def evaluate_local(
        self,
        model_state: Dict[str, np.ndarray],
    ) -> Dict[str, float]:
        """Evaluate model on local validation data."""
        if self._val_loader is None:
            return {}

        import torch

        # Load state
        self._serializer.deserialize(model_state, self._model)
        self._model.eval()

        total_loss = 0.0
        n_batches = 0

        with torch.no_grad():
            for batch in self._val_loader:
                if isinstance(batch, (list, tuple)):
                    features = batch[0]
                else:
                    features = batch

                output = self._model(features)
                loss = self._compute_loss(output, features)

                total_loss += loss.item()
                n_batches += 1

        return {
            'val_loss': total_loss / n_batches if n_batches > 0 else 0.0,
        }

    def _init_model(self) -> None:
        """Initialize the local model (HybridSimplexRotor per P15)."""
        from yrsn.core.decomposition import HybridSimplexRotor

        self._model = HybridSimplexRotor(embed_dim=self._config.embed_dim)

        # Load checkpoint if specified
        if self._config.rotor_checkpoint:
            import torch
            try:
                checkpoint = torch.load(
                    self._config.rotor_checkpoint,
                    map_location='cpu',
                )
                self._model.load_state_dict(checkpoint)
            except FileNotFoundError:
                pass

    def _compute_loss(self, output: Dict, features: Any) -> Any:
        """
        Compute training loss.

        For rotor training, we use:
        - Simplex constraint loss (R + S + N = 1)
        - Reconstruction loss (optional)
        """
        import torch
        import torch.nn.functional as F

        R = output['R']
        S = output['S']
        N = output['N']

        # Simplex constraint: R + S + N should = 1
        simplex_sum = R + S + N
        simplex_loss = F.mse_loss(simplex_sum, torch.ones_like(simplex_sum))

        # Variance encouragement: Prevent collapse to uniform
        rsn = torch.stack([R, S, N], dim=-1)
        variance = rsn.var(dim=-1).mean()
        variance_loss = 1.0 / (variance + 0.01)  # Encourage variance

        # Combined loss
        loss = simplex_loss + 0.1 * variance_loss

        return loss


def create_simulated_clients(
    n_clients: int,
    data_per_client: int = 100,
    embed_dim: int = 64,
    config: Optional[FederatedConfig] = None,
) -> List[LocalFederatedClient]:
    """
    Create simulated federated clients with synthetic data.

    Useful for testing federation without real data.
    """
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    clients = []

    for i in range(n_clients):
        # Generate synthetic data
        features = torch.randn(data_per_client, embed_dim)

        # Create DataLoader
        dataset = TensorDataset(features)
        loader = DataLoader(dataset, batch_size=config.batch_size if config else 32)

        client = LocalFederatedClient(
            client_id=f"client_{i}",
            data_loader=loader,
            config=config,
        )
        clients.append(client)

    return clients
