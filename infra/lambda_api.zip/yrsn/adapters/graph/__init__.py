"""
Graph Adapters for YRSN Integration

This module provides adapters for graph-structured data, enabling YRSN
to work with graph embeddings from systems like GraphRAG, Knowledge Graphs,
and Graph Neural Networks.

Key Components:
- GraphEmbeddingExtractor: Adapter implementing IFeatureExtractor for graph embeddings
- SyntheticGraphGenerator: Generate test graph embeddings for validation

Created: 2026-01-22
Claims Supported: A7, A8, B5
"""

from .graph_extractor import (
    GraphEmbeddingExtractor,
    SyntheticGraphGenerator,
    GraphNode,
    GraphLevel,
    HierarchicalGraphEmbeddings,
)

__all__ = [
    'GraphEmbeddingExtractor',
    'SyntheticGraphGenerator',
    'GraphNode',
    'GraphLevel',
    'HierarchicalGraphEmbeddings',
]
