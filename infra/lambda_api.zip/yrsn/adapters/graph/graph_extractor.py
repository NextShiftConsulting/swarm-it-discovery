"""
Graph Embedding Extractor - Adapter for Graph-Based Features

This module provides adapters for extracting and normalizing graph embeddings
for use with YRSN rotor models. It follows the IFeatureExtractor protocol
to ensure compatibility with the YRSN decomposition pipeline.

Key Classes:
- GraphEmbeddingExtractor: Adapter implementing IFeatureExtractor for graphs
- SyntheticGraphGenerator: Generate synthetic graph embeddings for testing
- HierarchicalGraphEmbeddings: Multi-level graph embeddings (macro/meso/micro)

Claims Supported:
- A8: Hierarchical Quality Propagation (certificates at macro/meso/micro levels)
- B5: Quality-Gated Beam Search (alpha-weighted path scoring)

Reference: docs/init20260116/D_GraphRL_Claims_Defense.md
Created: 2026-01-22
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any, Protocol, runtime_checkable
import numpy as np


# =============================================================================
# GRAPH LEVEL DEFINITIONS
# =============================================================================

class GraphLevel(str, Enum):
    """
    Hierarchical levels in graph structure (Claim A8).

    GraphRAG typically has:
    - MACRO: Community-level summaries
    - MESO: Subcluster groupings
    - MICRO: Individual entity nodes
    """
    MACRO = "macro"      # Communities (highest level)
    MESO = "meso"        # Subclusters (intermediate)
    MICRO = "micro"      # Entities (lowest level)


@dataclass
class GraphNode:
    """
    Representation of a graph node with embedding.

    Attributes:
        node_id: Unique identifier
        embedding: L2-normalized embedding vector
        level: Hierarchy level (macro/meso/micro)
        parent_id: Optional parent node ID for hierarchy
        metadata: Additional node metadata
    """
    node_id: str
    embedding: np.ndarray  # [D] L2-normalized
    level: GraphLevel = GraphLevel.MICRO
    parent_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def dim(self) -> int:
        """Embedding dimension."""
        return self.embedding.shape[0]

    def __post_init__(self):
        """Ensure embedding is L2 normalized."""
        norm = np.linalg.norm(self.embedding)
        if norm > 0:
            self.embedding = self.embedding / norm


@dataclass
class HierarchicalGraphEmbeddings:
    """
    Multi-level graph embeddings for hierarchical quality propagation.

    Supports quality certificate propagation across levels (Claim A8):
    - Quality at micro level propagates to meso/macro
    - Different aggregation strategies (min, mean, weighted)

    Attributes:
        macro_nodes: Community-level nodes
        meso_nodes: Subcluster-level nodes
        micro_nodes: Entity-level nodes
        level_embeddings: Pre-computed level-wise embedding matrices
    """
    macro_nodes: List[GraphNode] = field(default_factory=list)
    meso_nodes: List[GraphNode] = field(default_factory=list)
    micro_nodes: List[GraphNode] = field(default_factory=list)

    @property
    def feature_dim(self) -> int:
        """Common embedding dimension across levels."""
        for nodes in [self.micro_nodes, self.meso_nodes, self.macro_nodes]:
            if nodes:
                return nodes[0].dim
        return 0

    def get_level_embeddings(self, level: GraphLevel) -> np.ndarray:
        """
        Get embedding matrix for a level.

        Args:
            level: Graph hierarchy level

        Returns:
            [N, D] embedding matrix for that level
        """
        if level == GraphLevel.MACRO:
            nodes = self.macro_nodes
        elif level == GraphLevel.MESO:
            nodes = self.meso_nodes
        else:
            nodes = self.micro_nodes

        if not nodes:
            return np.array([]).reshape(0, self.feature_dim)

        return np.stack([n.embedding for n in nodes], axis=0)

    def get_children(self, parent_id: str) -> List[GraphNode]:
        """Get child nodes of a parent."""
        children = []
        for node in self.meso_nodes + self.micro_nodes:
            if node.parent_id == parent_id:
                children.append(node)
        return children

    def propagate_quality(
        self,
        micro_qualities: Dict[str, float],
        aggregation: str = "min",
    ) -> Dict[str, Dict[str, float]]:
        """
        Propagate quality scores from micro to macro levels.

        Claim A8: Quality certificates propagate across graph levels.

        Args:
            micro_qualities: {node_id: alpha} at micro level
            aggregation: "min" (conservative), "mean", or "weighted"

        Returns:
            {level: {node_id: quality}} for all levels
        """
        qualities = {
            GraphLevel.MICRO.value: micro_qualities,
            GraphLevel.MESO.value: {},
            GraphLevel.MACRO.value: {},
        }

        # Propagate micro -> meso
        for meso_node in self.meso_nodes:
            child_qualities = []
            for micro_node in self.micro_nodes:
                if micro_node.parent_id == meso_node.node_id:
                    if micro_node.node_id in micro_qualities:
                        child_qualities.append(micro_qualities[micro_node.node_id])

            if child_qualities:
                if aggregation == "min":
                    qualities[GraphLevel.MESO.value][meso_node.node_id] = min(child_qualities)
                elif aggregation == "mean":
                    qualities[GraphLevel.MESO.value][meso_node.node_id] = np.mean(child_qualities)
                elif aggregation == "weighted":
                    # Weight by inverse variance (more consistent = higher weight)
                    weights = 1.0 / (np.var(child_qualities) + 1e-6)
                    qualities[GraphLevel.MESO.value][meso_node.node_id] = np.average(
                        child_qualities, weights=np.full(len(child_qualities), weights)
                    )

        # Propagate meso -> macro
        meso_qualities = qualities[GraphLevel.MESO.value]
        for macro_node in self.macro_nodes:
            child_qualities = []
            for meso_node in self.meso_nodes:
                if meso_node.parent_id == macro_node.node_id:
                    if meso_node.node_id in meso_qualities:
                        child_qualities.append(meso_qualities[meso_node.node_id])

            if child_qualities:
                if aggregation == "min":
                    qualities[GraphLevel.MACRO.value][macro_node.node_id] = min(child_qualities)
                elif aggregation == "mean":
                    qualities[GraphLevel.MACRO.value][macro_node.node_id] = np.mean(child_qualities)
                elif aggregation == "weighted":
                    weights = 1.0 / (np.var(child_qualities) + 1e-6)
                    qualities[GraphLevel.MACRO.value][macro_node.node_id] = np.average(
                        child_qualities, weights=np.full(len(child_qualities), weights)
                    )

        return qualities


# =============================================================================
# GRAPH EMBEDDING EXTRACTOR
# =============================================================================

class GraphEmbeddingExtractor:
    """
    Adapter for graph embeddings following IFeatureExtractor protocol.

    This adapter enables YRSN rotor models to work with graph-structured data
    from GraphRAG, Knowledge Graphs, or GNN outputs.

    Protocol Compliance:
    - feature_dim: Returns embedding dimension
    - model_name: Returns graph model identifier
    - extract(): Returns L2-normalized embeddings

    Example:
        >>> extractor = GraphEmbeddingExtractor(dim=768, model_name="graphrag_v1")
        >>> embeddings = extractor.extract(node_ids, graph_context)
        >>> # embeddings are L2 normalized, ready for YRSN rotor
    """

    def __init__(
        self,
        feature_dim: int = 768,
        model_name: str = "graph_embedding_extractor",
        normalize: bool = True,
        cache_embeddings: bool = True,
    ):
        """
        Initialize graph embedding extractor.

        Args:
            feature_dim: Output embedding dimension
            model_name: Identifier for this graph model
            normalize: Whether to L2 normalize outputs
            cache_embeddings: Whether to cache extracted embeddings
        """
        self._feature_dim = feature_dim
        self._model_name = model_name
        self._normalize = normalize
        self._cache_embeddings = cache_embeddings
        self._cache: Dict[str, np.ndarray] = {}

    @property
    def feature_dim(self) -> int:
        """Dimension of extracted features."""
        return self._feature_dim

    @property
    def model_name(self) -> str:
        """Unique identifier for this model type."""
        return self._model_name

    def extract(
        self,
        data: np.ndarray,
        graph_context: Optional[HierarchicalGraphEmbeddings] = None,
        node_ids: Optional[List[str]] = None,
    ) -> np.ndarray:
        """
        Extract features from input data.

        If graph_context is provided, extracts embeddings from graph nodes.
        Otherwise, assumes data is already embeddings and normalizes them.

        Args:
            data: [B, D] embeddings or [B] node indices
            graph_context: Optional hierarchical graph with node embeddings
            node_ids: Optional list of node IDs to extract

        Returns:
            [B, feature_dim] L2-normalized embeddings
        """
        if graph_context is not None and node_ids is not None:
            # Extract from graph by node IDs
            embeddings = []
            all_nodes = (
                graph_context.micro_nodes +
                graph_context.meso_nodes +
                graph_context.macro_nodes
            )
            node_map = {n.node_id: n.embedding for n in all_nodes}

            for node_id in node_ids:
                if node_id in node_map:
                    embeddings.append(node_map[node_id])
                else:
                    # Return zero embedding for unknown nodes
                    embeddings.append(np.zeros(self._feature_dim))

            result = np.stack(embeddings, axis=0)
        else:
            # Assume data is already embeddings
            result = np.asarray(data, dtype=np.float32)

        # Ensure correct dimension
        if result.ndim == 1:
            result = result.reshape(1, -1)

        # L2 normalize if enabled
        if self._normalize:
            norms = np.linalg.norm(result, axis=1, keepdims=True)
            norms = np.maximum(norms, 1e-8)
            result = result / norms

        return result

    def extract_hierarchical(
        self,
        graph: HierarchicalGraphEmbeddings,
        level: Optional[GraphLevel] = None,
    ) -> Dict[str, np.ndarray]:
        """
        Extract embeddings from all hierarchy levels.

        Args:
            graph: Hierarchical graph embeddings
            level: Optional specific level (extracts all if None)

        Returns:
            {level_name: [N, D] embeddings} for each level
        """
        result = {}

        if level is None:
            levels = [GraphLevel.MACRO, GraphLevel.MESO, GraphLevel.MICRO]
        else:
            levels = [level]

        for lvl in levels:
            embeddings = graph.get_level_embeddings(lvl)
            if self._normalize and embeddings.shape[0] > 0:
                norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
                norms = np.maximum(norms, 1e-8)
                embeddings = embeddings / norms
            result[lvl.value] = embeddings

        return result


# =============================================================================
# SYNTHETIC GRAPH GENERATOR
# =============================================================================

class SyntheticGraphGenerator:
    """
    Generate synthetic graph embeddings for testing YRSN on graphs.

    Supports multiple embedding styles:
    - Node2Vec: Clustered embeddings with random walk structure
    - TransE: Translation-based relationship embeddings
    - Sentence Transformer: Semantic cluster embeddings

    Used for validation experiments (expS4_153, expS4_154, expS4_155).
    """

    def __init__(
        self,
        dim: int = 768,
        seed: Optional[int] = None,
    ):
        """
        Initialize generator.

        Args:
            dim: Embedding dimension
            seed: Random seed for reproducibility
        """
        self.dim = dim
        self.rng = np.random.default_rng(seed)

    def generate_node2vec_style(
        self,
        n_nodes: int,
        n_clusters: int = 10,
        cluster_tightness: float = 0.3,
    ) -> np.ndarray:
        """
        Generate Node2Vec-style clustered embeddings.

        Args:
            n_nodes: Number of nodes
            n_clusters: Number of clusters
            cluster_tightness: Standard deviation within clusters

        Returns:
            [n_nodes, dim] L2-normalized embeddings
        """
        embeddings = []

        # Generate cluster centers
        centers = self.rng.standard_normal((n_clusters, self.dim))
        centers = centers / np.linalg.norm(centers, axis=1, keepdims=True)

        # Assign nodes to clusters
        cluster_assignments = self.rng.integers(0, n_clusters, size=n_nodes)

        for i in range(n_nodes):
            cluster_id = cluster_assignments[i]
            center = centers[cluster_id]

            # Add noise around cluster center
            noise = self.rng.standard_normal(self.dim) * cluster_tightness
            embedding = center + noise

            # L2 normalize
            embedding = embedding / (np.linalg.norm(embedding) + 1e-8)
            embeddings.append(embedding)

        return np.stack(embeddings, axis=0).astype(np.float32)

    def generate_transe_style(
        self,
        n_entities: int,
        n_relations: int = 20,
        translation_scale: float = 0.5,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate TransE-style translation embeddings.

        TransE models relations as translations: head + relation ≈ tail

        Args:
            n_entities: Number of entities
            n_relations: Number of relation types
            translation_scale: Scale of translation vectors

        Returns:
            Tuple of (entity_embeddings, relation_embeddings)
        """
        # Entity embeddings
        entities = self.rng.standard_normal((n_entities, self.dim))
        entities = entities / np.linalg.norm(entities, axis=1, keepdims=True)

        # Relation embeddings (translations)
        relations = self.rng.standard_normal((n_relations, self.dim)) * translation_scale
        relations = relations / np.linalg.norm(relations, axis=1, keepdims=True)

        return entities.astype(np.float32), relations.astype(np.float32)

    def generate_semantic_clusters(
        self,
        n_nodes: int,
        n_topics: int = 5,
        topic_overlap: float = 0.2,
    ) -> np.ndarray:
        """
        Generate semantic cluster embeddings (sentence transformer style).

        Args:
            n_nodes: Number of nodes
            n_topics: Number of semantic topics
            topic_overlap: Amount of topic mixing

        Returns:
            [n_nodes, dim] L2-normalized embeddings
        """
        embeddings = []

        # Generate topic vectors
        topics = self.rng.standard_normal((n_topics, self.dim))
        topics = topics / np.linalg.norm(topics, axis=1, keepdims=True)

        for _ in range(n_nodes):
            # Primary topic
            primary_topic = self.rng.integers(0, n_topics)
            embedding = topics[primary_topic].copy()

            # Add secondary topic influence
            if self.rng.random() < topic_overlap:
                secondary_topic = self.rng.integers(0, n_topics)
                mix_weight = self.rng.uniform(0.1, 0.3)
                embedding = (1 - mix_weight) * embedding + mix_weight * topics[secondary_topic]

            # Add noise
            noise = self.rng.standard_normal(self.dim) * 0.1
            embedding = embedding + noise

            # L2 normalize
            embedding = embedding / (np.linalg.norm(embedding) + 1e-8)
            embeddings.append(embedding)

        return np.stack(embeddings, axis=0).astype(np.float32)

    def generate_hierarchical_graph(
        self,
        n_communities: int = 5,
        subclusters_per_community: int = 4,
        entities_per_subcluster: int = 10,
        cluster_tightness: float = 0.2,
    ) -> HierarchicalGraphEmbeddings:
        """
        Generate hierarchical graph with macro/meso/micro levels.

        Structure:
        - Macro: Community summaries
        - Meso: Subcluster within communities
        - Micro: Individual entities

        Args:
            n_communities: Number of top-level communities
            subclusters_per_community: Subclusters in each community
            entities_per_subcluster: Entities in each subcluster
            cluster_tightness: Embedding variance within clusters

        Returns:
            HierarchicalGraphEmbeddings with all levels populated
        """
        macro_nodes = []
        meso_nodes = []
        micro_nodes = []

        for comm_idx in range(n_communities):
            # Generate community center (macro)
            comm_center = self.rng.standard_normal(self.dim)
            comm_center = comm_center / np.linalg.norm(comm_center)

            macro_node = GraphNode(
                node_id=f"macro_{comm_idx}",
                embedding=comm_center.astype(np.float32),
                level=GraphLevel.MACRO,
                metadata={'community_idx': comm_idx},
            )
            macro_nodes.append(macro_node)

            for sub_idx in range(subclusters_per_community):
                # Generate subcluster center (meso)
                sub_offset = self.rng.standard_normal(self.dim) * cluster_tightness
                sub_center = comm_center + sub_offset
                sub_center = sub_center / np.linalg.norm(sub_center)

                meso_node = GraphNode(
                    node_id=f"meso_{comm_idx}_{sub_idx}",
                    embedding=sub_center.astype(np.float32),
                    level=GraphLevel.MESO,
                    parent_id=f"macro_{comm_idx}",
                    metadata={'community_idx': comm_idx, 'subcluster_idx': sub_idx},
                )
                meso_nodes.append(meso_node)

                for ent_idx in range(entities_per_subcluster):
                    # Generate entity embedding (micro)
                    ent_offset = self.rng.standard_normal(self.dim) * cluster_tightness * 0.5
                    ent_embedding = sub_center + ent_offset
                    ent_embedding = ent_embedding / np.linalg.norm(ent_embedding)

                    micro_node = GraphNode(
                        node_id=f"micro_{comm_idx}_{sub_idx}_{ent_idx}",
                        embedding=ent_embedding.astype(np.float32),
                        level=GraphLevel.MICRO,
                        parent_id=f"meso_{comm_idx}_{sub_idx}",
                        metadata={
                            'community_idx': comm_idx,
                            'subcluster_idx': sub_idx,
                            'entity_idx': ent_idx,
                        },
                    )
                    micro_nodes.append(micro_node)

        return HierarchicalGraphEmbeddings(
            macro_nodes=macro_nodes,
            meso_nodes=meso_nodes,
            micro_nodes=micro_nodes,
        )


# =============================================================================
# QUALITY-GATED BEAM SEARCH (Claim B5)
# =============================================================================

@dataclass
class BeamCandidate:
    """Candidate in quality-gated beam search."""
    path: List[str]           # Node IDs in path
    score: float              # Cumulative score
    alpha_score: float        # Quality score from YRSN
    retrieval_score: float    # Base retrieval score
    domain: str               # Geometric domain (for pruning)


class QualityGatedBeamSearch:
    """
    Alpha-weighted beam search for graph retrieval (Claim B5).

    Combines retrieval relevance with YRSN quality for path scoring:
    - score = retrieval_score * alpha_weight + alpha_score * quality_weight

    Supports domain-based pruning:
    - COMPRESSION domain paths may be pruned (high error risk)
    - EXPANSION domain paths prioritized (reliable)
    """

    def __init__(
        self,
        beam_width: int = 10,
        alpha_weight: float = 0.3,
        retrieval_weight: float = 0.7,
        prune_compression: bool = True,
        compression_penalty: float = 0.5,
    ):
        """
        Initialize quality-gated beam search.

        Args:
            beam_width: Maximum candidates to keep per step
            alpha_weight: Weight for YRSN alpha score
            retrieval_weight: Weight for retrieval relevance
            prune_compression: Whether to penalize COMPRESSION domain
            compression_penalty: Penalty multiplier for COMPRESSION
        """
        self.beam_width = beam_width
        self.alpha_weight = alpha_weight
        self.retrieval_weight = retrieval_weight
        self.prune_compression = prune_compression
        self.compression_penalty = compression_penalty

    def score_candidate(
        self,
        retrieval_score: float,
        alpha_score: float,
        domain: str,
    ) -> float:
        """
        Compute combined score for a candidate.

        Args:
            retrieval_score: Base retrieval relevance [0, 1]
            alpha_score: YRSN quality score [0, 1]
            domain: Geometric domain ("COMPRESSION", "NEUTRAL", "EXPANSION")

        Returns:
            Combined score
        """
        # Base combined score
        score = (
            self.retrieval_weight * retrieval_score +
            self.alpha_weight * alpha_score
        )

        # Apply domain penalty
        if self.prune_compression and domain == "COMPRESSION":
            score *= self.compression_penalty

        return score

    def search(
        self,
        start_nodes: List[str],
        get_neighbors: Any,  # Callable[[str], List[Tuple[str, float]]]
        get_alpha: Any,  # Callable[[str], Tuple[float, str]]
        max_depth: int = 5,
    ) -> List[BeamCandidate]:
        """
        Execute quality-gated beam search.

        Args:
            start_nodes: Starting node IDs
            get_neighbors: Function returning [(neighbor_id, retrieval_score)]
            get_alpha: Function returning (alpha_score, domain) for a node
            max_depth: Maximum path depth

        Returns:
            Top beam_width candidates after search
        """
        # Initialize beam with start nodes
        beam = []
        for node_id in start_nodes:
            alpha, domain = get_alpha(node_id)
            beam.append(BeamCandidate(
                path=[node_id],
                score=alpha,
                alpha_score=alpha,
                retrieval_score=1.0,
                domain=domain,
            ))

        # Beam search loop
        for _ in range(max_depth):
            candidates = []

            for candidate in beam:
                current_node = candidate.path[-1]
                neighbors = get_neighbors(current_node)

                for neighbor_id, retrieval_score in neighbors:
                    if neighbor_id in candidate.path:
                        continue  # Avoid cycles

                    alpha, domain = get_alpha(neighbor_id)
                    combined_score = self.score_candidate(retrieval_score, alpha, domain)

                    new_candidate = BeamCandidate(
                        path=candidate.path + [neighbor_id],
                        score=candidate.score + combined_score,
                        alpha_score=(candidate.alpha_score + alpha) / 2,
                        retrieval_score=(candidate.retrieval_score + retrieval_score) / 2,
                        domain=domain,
                    )
                    candidates.append(new_candidate)

            # Keep top beam_width candidates
            candidates.sort(key=lambda c: c.score, reverse=True)
            beam = candidates[:self.beam_width]

            if not beam:
                break

        return beam


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'GraphLevel',
    'GraphNode',
    'HierarchicalGraphEmbeddings',
    'GraphEmbeddingExtractor',
    'SyntheticGraphGenerator',
    'BeamCandidate',
    'QualityGatedBeamSearch',
]
