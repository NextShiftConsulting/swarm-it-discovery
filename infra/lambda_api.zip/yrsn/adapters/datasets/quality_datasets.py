"""
Quality Dataset Adapters
=========================

Implementations of IQualityDataset for conference-grade benchmarks.

Architecture:
- Each adapter implements IQualityDataset port
- Handles dataset-specific loading and normalization
- Uses separate downloader utilities (keeping concerns separated)
"""

from pathlib import Path
from typing import Tuple, List, Optional
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from yrsn.ports.quality_dataset import (
    IQualityDataset,
    QualityDatasetMetadata,
    QualityDatasetSplit
)


class ASAPAESDataset(IQualityDataset):
    """
    ASAP Automated Essay Scoring Dataset

    Source: Kaggle ASAP-AES competition
    Size: ~13K essays across 8 prompts
    Quality: Holistic scores (prompt-dependent ranges)
    """

    def __init__(self, data_dir: str, prompt_id: Optional[int] = None):
        """
        Args:
            data_dir: Directory containing training_set_rel3.tsv
            prompt_id: Optional prompt to filter (1-8). If None, uses all prompts.
        """
        self.data_dir = Path(data_dir)
        self.prompt_id = prompt_id
        self._data = None

    def _load_raw_data(self) -> pd.DataFrame:
        """Load raw data from Parquet (kagglehub) or TSV (original competition)"""
        if self._data is not None:
            return self._data

        # Try Parquet first (kagglehub format)
        parquet_path = self.data_dir / 'ASAP.parquet'
        if parquet_path.exists():
            df = pd.read_parquet(parquet_path)

            # Map columns to expected format
            column_mapping = {}
            if 'text' in df.columns and 'essay' not in df.columns:
                column_mapping['text'] = 'essay'
            if 'prompt' in df.columns and 'essay_set' not in df.columns:
                column_mapping['prompt'] = 'essay_set'
            if 'score' in df.columns and 'domain1_score' not in df.columns:
                # Use raw score, not norm_score (we normalize later)
                column_mapping['score'] = 'domain1_score'

            if column_mapping:
                df = df.rename(columns=column_mapping)

            self._data = df
        else:
            # Fallback to TSV (original Kaggle competition format)
            tsv_path = self.data_dir / 'training_set_rel3.tsv'

            if not tsv_path.exists():
                raise FileNotFoundError(
                    f"ASAP-AES data not found. Expected:\n"
                    f"  {parquet_path} (kagglehub format) OR\n"
                    f"  {tsv_path} (original format)\n"
                    f"Download with: python exp/series_005/download_benchmarks.py --dataset asap"
                )

            self._data = pd.read_csv(tsv_path, sep='\t', encoding='ISO-8859-1')

        # Filter by prompt if specified
        if self.prompt_id is not None:
            self._data = self._data[self._data['essay_set'] == self.prompt_id]

        return self._data

    def load(self) -> Tuple[List[str], np.ndarray]:
        """Load essays and normalized scores"""
        df = self._load_raw_data()

        texts = df['essay'].tolist()
        raw_scores = df['domain1_score'].values

        # Normalize to [0, 1]
        normalized_scores = self.normalize_labels(raw_scores)

        return texts, normalized_scores

    def get_splits(self,
                   test_size: float = 0.2,
                   random_state: int = 42) -> Tuple[QualityDatasetSplit, QualityDatasetSplit]:
        """Get train/test splits stratified by score"""
        texts, labels = self.load()
        df = self._load_raw_data()

        X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
            texts, labels, range(len(texts)),
            test_size=test_size,
            random_state=random_state,
            stratify=np.digitize(labels, bins=[0.33, 0.67])  # Stratify by quality bins
        )

        # Get metadata for each split
        train_metadata = {'prompt_ids': df.iloc[list(idx_train)]['essay_set'].tolist()}
        test_metadata = {'prompt_ids': df.iloc[list(idx_test)]['essay_set'].tolist()}

        train_split = QualityDatasetSplit(
            texts=X_train,
            labels=y_train,
            raw_labels=df.iloc[list(idx_train)]['domain1_score'].values,
            metadata=train_metadata
        )

        test_split = QualityDatasetSplit(
            texts=X_test,
            labels=y_test,
            raw_labels=df.iloc[list(idx_test)]['domain1_score'].values,
            metadata=test_metadata
        )

        return train_split, test_split

    def get_metadata(self) -> QualityDatasetMetadata:
        """Get dataset metadata"""
        df = self._load_raw_data()

        prompt_info = "All prompts" if self.prompt_id is None else f"Prompt {self.prompt_id}"

        return QualityDatasetMetadata(
            name=f"ASAP-AES ({prompt_info})",
            size=len(df),
            source="Kaggle ASAP Automated Essay Scoring Competition",
            quality_scale=(df['domain1_score'].min(), df['domain1_score'].max()),
            quality_dimensions=["overall_quality"],
            description=f"Student essays with holistic quality scores. {prompt_info}.",
            citation="https://www.kaggle.com/c/asap-aes"
        )


class IBMDebaterDataset(IQualityDataset):
    """
    IBM Debater Argument Quality Dataset

    Source: IBM Research
    Size: ~6K arguments
    Quality: Quality scores (1-3 or continuous)
    """

    def __init__(self, data_dir: str):
        """
        Args:
            data_dir: Directory containing arg_quality_rank_30k.csv
        """
        self.data_dir = Path(data_dir)
        self._data = None

    def _load_raw_data(self) -> pd.DataFrame:
        """Load raw CSV data"""
        if self._data is not None:
            return self._data

        csv_path = self.data_dir / 'arg_quality_rank_30k.csv'

        if not csv_path.exists():
            raise FileNotFoundError(
                f"IBM Debater data not found at {csv_path}. "
                f"Download from: https://research.ibm.com/haifa/dept/vst/debating_data.shtml"
            )

        self._data = pd.read_csv(csv_path)
        return self._data

    def load(self) -> Tuple[List[str], np.ndarray]:
        """Load arguments and normalized quality scores"""
        df = self._load_raw_data()

        texts = df['argument'].tolist()

        # Use WA (Weighted Average) score if available, else use majority label
        if 'WA' in df.columns:
            raw_scores = df['WA'].values
        else:
            raw_scores = df['label'].values

        normalized_scores = self.normalize_labels(raw_scores)

        return texts, normalized_scores

    def get_splits(self,
                   test_size: float = 0.2,
                   random_state: int = 42) -> Tuple[QualityDatasetSplit, QualityDatasetSplit]:
        """Get train/test splits"""
        texts, labels = self.load()

        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels,
            test_size=test_size,
            random_state=random_state,
            stratify=np.digitize(labels, bins=[0.33, 0.67])
        )

        train_split = QualityDatasetSplit(texts=X_train, labels=y_train)
        test_split = QualityDatasetSplit(texts=X_test, labels=y_test)

        return train_split, test_split

    def get_metadata(self) -> QualityDatasetMetadata:
        """Get dataset metadata"""
        df = self._load_raw_data()

        return QualityDatasetMetadata(
            name="IBM Debater Argument Quality",
            size=len(df),
            source="IBM Research Debater",
            quality_scale=(1.0, 3.0),  # Typically 1-3
            quality_dimensions=["argument_quality"],
            description="Debate arguments with quality annotations",
            citation="https://research.ibm.com/haifa/dept/vst/debating_data.shtml"
        )


class GCDCDataset(IQualityDataset):
    """
    Grammarly Corpus of Discourse Coherence (GCDC)

    Source: Grammarly
    Size: ~3K documents from 3 domains
    Quality: Coherence scores (1-3)
    """

    def __init__(self, data_dir: str, domain: Optional[str] = None):
        """
        Args:
            data_dir: Directory containing GCDC data
            domain: Optional domain filter ('Clinton', 'Enron', 'Yahoo'). None = all.
        """
        self.data_dir = Path(data_dir)
        self.domain = domain
        self._data = None

    def _load_raw_data(self) -> pd.DataFrame:
        """Load GCDC data (structure varies, adapt as needed)"""
        if self._data is not None:
            return self._data

        # GCDC structure: domain_split.csv files
        domain_files = list(self.data_dir.glob('*.csv'))

        if not domain_files:
            raise FileNotFoundError(
                f"GCDC data not found in {self.data_dir}. "
                f"Download from: https://github.com/aylai/GCDC-corpus"
            )

        dfs = []
        for file in domain_files:
            df = pd.read_csv(file)
            dfs.append(df)

        self._data = pd.concat(dfs, ignore_index=True)

        # Filter by domain if specified
        if self.domain is not None:
            self._data = self._data[self._data['domain'] == self.domain]

        return self._data

    def load(self) -> Tuple[List[str], np.ndarray]:
        """Load documents and coherence scores"""
        df = self._load_raw_data()

        texts = df['text'].tolist()
        raw_scores = df['labelA'].values  # Coherence label

        normalized_scores = self.normalize_labels(raw_scores)

        return texts, normalized_scores

    def get_splits(self,
                   test_size: float = 0.2,
                   random_state: int = 42) -> Tuple[QualityDatasetSplit, QualityDatasetSplit]:
        """Get train/test splits"""
        texts, labels = self.load()

        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels,
            test_size=test_size,
            random_state=random_state
        )

        train_split = QualityDatasetSplit(texts=X_train, labels=y_train)
        test_split = QualityDatasetSplit(texts=X_test, labels=y_test)

        return train_split, test_split

    def get_metadata(self) -> QualityDatasetMetadata:
        """Get dataset metadata"""
        df = self._load_raw_data()

        domain_info = "All domains" if self.domain is None else self.domain

        return QualityDatasetMetadata(
            name=f"GCDC ({domain_info})",
            size=len(df),
            source="Grammarly",
            quality_scale=(1.0, 3.0),
            quality_dimensions=["coherence"],
            description=f"Documents with coherence ratings. Domain: {domain_info}.",
            citation="https://github.com/aylai/GCDC-corpus"
        )


class CommonLitDataset(IQualityDataset):
    """
    CommonLit Readability Dataset

    Source: Kaggle CommonLit competition
    Size: ~2.8K passages
    Quality: Readability scores (-4 to +4)
    """

    def __init__(self, data_dir: str):
        """
        Args:
            data_dir: Directory containing train.csv
        """
        self.data_dir = Path(data_dir)
        self._data = None

    def _load_raw_data(self) -> pd.DataFrame:
        """Load raw CSV data"""
        if self._data is not None:
            return self._data

        csv_path = self.data_dir / 'train.csv'

        if not csv_path.exists():
            raise FileNotFoundError(
                f"CommonLit data not found at {csv_path}. "
                f"Download from: https://www.kaggle.com/c/commonlitreadabilityprize"
            )

        self._data = pd.read_csv(csv_path)
        return self._data

    def load(self) -> Tuple[List[str], np.ndarray]:
        """Load passages and readability scores"""
        df = self._load_raw_data()

        texts = df['excerpt'].tolist()
        raw_scores = df['target'].values  # Readability score

        # Note: Higher readability = easier (inverse of quality in some contexts)
        # Normalize to [0, 1] where 1 = most readable
        normalized_scores = self.normalize_labels(raw_scores)

        return texts, normalized_scores

    def get_splits(self,
                   test_size: float = 0.2,
                   random_state: int = 42) -> Tuple[QualityDatasetSplit, QualityDatasetSplit]:
        """Get train/test splits"""
        texts, labels = self.load()

        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels,
            test_size=test_size,
            random_state=random_state
        )

        train_split = QualityDatasetSplit(texts=X_train, labels=y_train)
        test_split = QualityDatasetSplit(texts=X_test, labels=y_test)

        return train_split, test_split

    def get_metadata(self) -> QualityDatasetMetadata:
        """Get dataset metadata"""
        df = self._load_raw_data()

        return QualityDatasetMetadata(
            name="CommonLit Readability",
            size=len(df),
            source="Kaggle CommonLit Readability Prize",
            quality_scale=(-4.0, 4.0),
            quality_dimensions=["readability"],
            description="K-12 passages with readability scores",
            citation="https://www.kaggle.com/c/commonlitreadabilityprize"
        )
