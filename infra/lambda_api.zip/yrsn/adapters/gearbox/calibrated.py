"""
Calibrated Gearbox - Adaptive tau threshold calibration wrapper.

Wraps an existing AdaptiveGearbox and adds automatic calibration of
tau→gear boundaries based on observed data distribution.

Problem:
    Hardcoded tau thresholds don't match actual rotor output.
    Result: all samples end up in the same gear.

Solution:
    During warmup, observe tau distribution.
    After warmup, compute percentile-based thresholds.
    Use calibrated thresholds for tau→gear mapping.

Usage:
    from yrsn.adapters.gearbox.calibrated import CalibratedGearbox

    # Wrap existing gearbox
    gearbox = CalibratedGearbox(
        mode=DrivingMode.SPORT,
        calibration_enabled=True,
        warmup_samples=512,
    )

    # During warmup, feed certificates
    for cert in certificates:
        result = gearbox.auto_shift_with_calibration(
            quality=QualitySignals(alpha=cert.alpha, tau=cert.tau),
            tau=cert.tau,  # explicit tau for calibration
        )

    # Check calibration status
    if gearbox.is_calibrated:
        print(f"Boundaries: {gearbox.get_calibration_result().boundaries}")

Reference:
    Follows patterns from:
    - core/decomposition/calibration_manager.py
    - hardware/adaptive_calibration.py
"""

from typing import Optional, Tuple
from dataclasses import dataclass

from yrsn.core.gearbox.gear import Gear, get_gear_for_tau
from yrsn.core.gearbox.driving_mode import DrivingMode
from yrsn.core.gearbox.shifter import QualitySignals
from yrsn.core.gearbox.gearbox_calibrator import (
    GearboxCalibrator,
    GearboxCalibrationConfig,
    GearboxCalibrationResult,
)
from yrsn.adapters.gearbox.adaptive import AdaptiveGearbox
from yrsn.ports.gearbox import GearboxState


@dataclass
class CalibratedGearboxConfig:
    """Configuration for calibrated gearbox."""
    # Calibration
    calibration_enabled: bool = True
    warmup_samples: int = 512
    quantiles: Tuple[float, float, float] = (0.25, 0.50, 0.75)
    winsor_limits: Tuple[float, float] = (0.01, 0.99)
    min_gap: float = 1e-6

    # Gearbox
    initial_gear: Gear = Gear.THIRD
    driving_mode: DrivingMode = DrivingMode.SPORT


class CalibratedGearbox:
    """
    Gearbox with automatic tau threshold calibration.

    Wraps AdaptiveGearbox and adds:
    - Warmup phase to observe tau distribution
    - Percentile-based threshold calibration
    - Calibrated tau→gear mapping

    Lifecycle:
        1. WARMUP: Collects tau values, uses default gearbox behavior
        2. CALIBRATED: Uses calibrated boundaries for gear selection

    Attributes:
        _gearbox: Underlying AdaptiveGearbox
        _calibrator: GearboxCalibrator for threshold discovery
        _boundaries: Calibrated (b1, b2, b3) or None
    """

    def __init__(
        self,
        mode: DrivingMode = DrivingMode.SPORT,
        initial_gear: Gear = Gear.THIRD,
        calibration_enabled: bool = True,
        warmup_samples: int = 512,
        quantiles: Tuple[float, float, float] = (0.25, 0.50, 0.75),
        winsor_limits: Tuple[float, float] = (0.01, 0.99),
        min_gap: float = 1e-6,
    ):
        """
        Initialize calibrated gearbox.

        Args:
            mode: Driving mode (SPORT/ECO/MANUAL)
            initial_gear: Starting gear
            calibration_enabled: Whether to enable adaptive calibration
            warmup_samples: Samples before calibration
            quantiles: Percentile boundaries (b1, b2, b3)
            winsor_limits: Outlier clipping percentiles
            min_gap: Minimum boundary separation
        """
        # Create underlying gearbox
        self._gearbox = AdaptiveGearbox(
            initial_gear=initial_gear,
            mode=mode,
        )

        # Create calibrator
        self._calibrator = GearboxCalibrator(
            GearboxCalibrationConfig(
                enabled=calibration_enabled,
                warmup_samples=warmup_samples,
                quantiles=quantiles,
                winsor_limits=winsor_limits,
                min_gap=min_gap,
            )
        )

        # Calibrated boundaries (None until calibrated)
        self._boundaries: Optional[Tuple[float, float, float]] = None

    # =========================================================================
    # Properties (delegate to underlying gearbox)
    # =========================================================================

    @property
    def current_gear(self) -> Gear:
        """Get current gear."""
        return self._gearbox.current_gear

    @property
    def driving_mode(self) -> DrivingMode:
        """Get driving mode."""
        return self._gearbox.driving_mode

    @property
    def is_calibrated(self) -> bool:
        """Whether calibration is complete."""
        return self._boundaries is not None

    @property
    def calibration_progress(self) -> float:
        """Progress toward calibration (0.0 to 1.0)."""
        if self.is_calibrated:
            return 1.0
        target = self._calibrator.cfg.warmup_samples
        return min(1.0, self._calibrator.n_seen / target)

    # =========================================================================
    # Calibration Methods
    # =========================================================================

    def get_calibration_result(self) -> Optional[GearboxCalibrationResult]:
        """Get calibration result (None if not calibrated)."""
        return self._calibrator.get_result()

    def _tau_to_gear_calibrated(self, tau: float) -> Gear:
        """
        Map tau to gear using calibrated boundaries.

        Boundaries define:
            - 1st gear: (-inf, b1]
            - 2nd gear: (b1, b2]
            - 3rd gear: (b2, b3]
            - 4th gear: (b3, +inf)
        """
        if self._boundaries is None:
            # Fallback to default mapping
            return get_gear_for_tau(tau, exclude_reverse=True)

        b1, b2, b3 = self._boundaries

        if tau <= b1:
            return Gear.FIRST
        elif tau <= b2:
            return Gear.SECOND
        elif tau <= b3:
            return Gear.THIRD
        else:
            return Gear.FOURTH

    def _maybe_calibrate(self) -> bool:
        """
        Check if ready to calibrate and perform calibration.

        Returns:
            True if calibration was performed
        """
        if self._boundaries is not None:
            return False  # Already calibrated

        if self._calibrator.ready():
            result = self._calibrator.calibrate()
            self._boundaries = result.boundaries
            print(f"[CalibratedGearbox] Calibrated: {result.describe()}")
            return True

        return False

    # =========================================================================
    # Shifting Methods
    # =========================================================================

    def auto_shift_with_calibration(
        self,
        quality: QualitySignals,
        tau: Optional[float] = None,
    ) -> Optional[Gear]:
        """
        Auto-shift with calibration support.

        During warmup: observes tau, uses default gearbox behavior.
        After calibration: uses calibrated tau→gear mapping.

        Args:
            quality: Quality signals for shifting decision
            tau: Explicit tau value (uses quality.tau if None)

        Returns:
            New gear if shifted, None otherwise
        """
        # Get tau from quality if not provided
        effective_tau = tau if tau is not None else quality.tau

        # Observe tau for calibration
        if effective_tau is not None:
            self._calibrator.observe_tau(effective_tau)

        # Check if ready to calibrate
        self._maybe_calibrate()

        # If calibrated, determine recommended gear from calibrated boundaries
        if self._boundaries is not None and effective_tau is not None:
            recommended = self._tau_to_gear_calibrated(effective_tau)

            # If recommended gear differs from current, try to shift
            if recommended != self._gearbox.current_gear:
                # Use the underlying gearbox's shift mechanism
                # (respects hysteresis, driving mode, etc.)
                success = self._gearbox.shift(recommended)
                if success:
                    return recommended

            return None

        # Not calibrated yet - use default behavior
        return self._gearbox.auto_shift(quality)

    def shift(self, target: Gear) -> bool:
        """Manual shift (delegates to underlying gearbox)."""
        return self._gearbox.shift(target)

    def get_state(self) -> GearboxState:
        """Get gearbox state (delegates to underlying gearbox)."""
        return self._gearbox.get_state()

    def get_shift_count(self) -> int:
        """Get total shift count."""
        return self._gearbox.get_shift_count()

    def reset(self) -> None:
        """Reset gearbox and calibration."""
        self._gearbox.reset()
        self._calibrator.reset()
        self._boundaries = None

    # =========================================================================
    # Diagnostic Methods
    # =========================================================================

    def get_calibration_stats(self) -> dict:
        """Get calibration statistics for diagnostics."""
        result = self.get_calibration_result()
        return {
            'is_calibrated': self.is_calibrated,
            'progress': self.calibration_progress,
            'n_seen': self._calibrator.n_seen,
            'boundaries': self._boundaries,
            'result': result.to_dict() if result else None,
        }


__all__ = [
    "CalibratedGearbox",
    "CalibratedGearboxConfig",
]
