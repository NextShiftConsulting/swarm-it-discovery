"""
Adaptive Gearbox - Auto-shifting implementation of IGearbox.

This adapter implements the full Dimensional Gearbox with:
- Auto-shifting based on quality signals
- Hysteresis to prevent oscillation ("gear hunting")
- Driving mode configurations (Sport/Eco/Manual)
- Shift history tracking

The AdaptiveGearbox is the primary implementation for production use.

Usage:
    from yrsn.adapters.gearbox import AdaptiveGearbox
    from yrsn.core.gearbox import DrivingMode, QualitySignals, Gear

    # Create gearbox in Sport mode
    gearbox = AdaptiveGearbox(mode=DrivingMode.SPORT)

    # Auto-shift based on quality
    quality = QualitySignals(alpha=0.6)
    new_gear = gearbox.auto_shift(quality)

    # Project coordinates
    projected = gearbox.project(t4_coords)

    # Manual override
    gearbox.shift(Gear.REVERSE)  # Emergency recovery

Reference:
    docs/CIP_03_PLATFORM_ARCHITECTURE.md
"""

import time
from typing import Optional, List, Tuple
import numpy as np

from yrsn.core.gearbox.gear import (
    Gear,
    GearSpec,
    DimensionalView,
    GEAR_SPECS,
    get_gear_spec,
)
from yrsn.core.gearbox.driving_mode import (
    DrivingMode,
    DrivingModeConfig,
    DRIVING_MODE_CONFIGS,
    get_driving_mode_config,
    is_auto_shift_enabled,
)
from yrsn.core.gearbox.views import ViewProjector
from yrsn.core.gearbox.shifter import (
    QualitySignals,
    ShiftDecision,
    GearShifter,
)
from yrsn.ports.gearbox import GearboxState, IGearbox


class AdaptiveGearbox:
    """
    Auto-shifting gearbox that responds to quality signals.

    This is the primary implementation of IGearbox for production use.
    It supports:
    - Three driving modes (Sport, Eco, Manual)
    - Hysteresis-based shifting to prevent oscillation
    - Upshift delays and downshift aggression controls
    - Full shift history for diagnostics

    Attributes:
        _gear: Current gear
        _mode: Current driving mode
        _mode_config: Configuration for current mode
        _tau: Current temperature estimate
        _shift_history: List of (timestamp, from_gear, to_gear) tuples
        _last_shift_time: Time of last shift (for upshift delay)

    Example:
        gearbox = AdaptiveGearbox(mode=DrivingMode.SPORT)
        quality = QualitySignals(alpha=0.8)

        # This may shift to 1st gear due to high alpha
        gearbox.auto_shift(quality)

        print(gearbox.current_gear)  # Gear.FIRST
    """

    def __init__(
        self,
        initial_gear: Gear = Gear.THIRD,
        mode: DrivingMode = DrivingMode.SPORT,
        initial_tau: Optional[float] = None,
    ):
        """
        Initialize the adaptive gearbox.

        Args:
            initial_gear: Starting gear (default: 3rd for balanced exploration)
            mode: Driving mode (default: SPORT)
            initial_tau: Initial temperature estimate (default: midpoint of gear range)
        """
        self._gear = initial_gear
        self._mode = mode
        self._mode_config = get_driving_mode_config(mode)

        # Initialize tau to midpoint of initial gear's range
        spec = get_gear_spec(initial_gear)
        if initial_tau is not None:
            self._tau = initial_tau
        elif spec.tau_max == float('inf'):
            self._tau = spec.tau_min + 0.5
        else:
            self._tau = (spec.tau_min + spec.tau_max) / 2

        # Shift tracking
        self._shift_history: List[Tuple[float, Gear, Gear]] = []
        self._last_shift_time = time.time()

        # Components
        self._shifter = GearShifter()
        self._projector = ViewProjector()

    @property
    def current_gear(self) -> Gear:
        """Get the current gear."""
        return self._gear

    @property
    def driving_mode(self) -> DrivingMode:
        """Get the current driving mode."""
        return self._mode

    def get_state(self) -> GearboxState:
        """Get the complete gearbox state."""
        spec = get_gear_spec(self._gear)
        return GearboxState(
            current_gear=self._gear,
            engine_name=spec.engine,
            view=spec.view,
            tau=self._tau,
            driving_mode=self._mode,
            shift_history=self._shift_history[-10:],  # Last 10 shifts
            time_in_gear=time.time() - self._last_shift_time,
        )

    def shift(self, target: Gear) -> bool:
        """
        Manually shift to a specific gear.

        Args:
            target: Target gear

        Returns:
            True if shift succeeded, False if blocked
        """
        can_shift, reason = self._shifter.can_shift(self._gear, target)
        if not can_shift:
            return False

        self._execute_shift(target)
        return True

    def auto_shift(self, quality: QualitySignals) -> Optional[Gear]:
        """
        Auto-select gear based on quality signals.

        Args:
            quality: Current quality signals

        Returns:
            New Gear if shifted, None otherwise
        """
        if not is_auto_shift_enabled(self._mode):
            return None

        # Update tau from quality
        self._tau = quality.tau

        # Get shift decision
        time_in_gear = time.time() - self._last_shift_time
        decision = self._shifter.decide_shift(
            current_gear=self._gear,
            quality=quality,
            mode_config=self._mode_config,
            time_in_gear=time_in_gear,
            collapse_detected=quality.collapse_risk > 0.8,
        )

        if decision.should_shift:
            self._execute_shift(decision.to_gear)
            return decision.to_gear

        return None

    def _execute_shift(self, target: Gear) -> None:
        """Execute the actual gear shift."""
        old_gear = self._gear
        self._gear = target

        # Adjust tau to target range
        self._tau = self._shifter.compute_shift_tau(old_gear, target, self._tau)

        # Record shift
        self._shift_history.append((time.time(), old_gear, target))
        self._last_shift_time = time.time()

        # Keep history bounded
        if len(self._shift_history) > 100:
            self._shift_history = self._shift_history[-100:]

    def get_engine_name(self) -> str:
        """Get the name of the current optimization backend."""
        spec = get_gear_spec(self._gear)
        return spec.engine

    def get_view(self) -> DimensionalView:
        """Get the current dimensional view specification."""
        spec = get_gear_spec(self._gear)
        return spec.view

    def project(self, t4_coords: np.ndarray) -> np.ndarray:
        """
        Project T⁴ coordinates through the current view.

        Args:
            t4_coords: [N, 4] T⁴ coordinates

        Returns:
            [N, k] projected coordinates
        """
        view = self.get_view()
        return self._projector.project(t4_coords, view)

    def set_driving_mode(self, mode: DrivingMode) -> None:
        """Change the driving mode."""
        self._mode = mode
        self._mode_config = get_driving_mode_config(mode)

    def reset(self) -> None:
        """Reset gearbox to initial state."""
        self._gear = Gear.THIRD
        spec = get_gear_spec(self._gear)
        self._tau = (spec.tau_min + spec.tau_max) / 2 if spec.tau_max != float('inf') else spec.tau_min + 0.5
        self._shift_history.clear()
        self._last_shift_time = time.time()

    # =========================================================================
    # Diagnostic Methods
    # =========================================================================

    def get_shift_count(self) -> int:
        """Get total number of shifts."""
        return len(self._shift_history)

    def get_recent_shifts(self, n: int = 5) -> List[Tuple[float, Gear, Gear]]:
        """Get the N most recent shifts."""
        return self._shift_history[-n:]

    def get_gear_distribution(self) -> dict:
        """
        Get distribution of time spent in each gear.

        Returns:
            Dict mapping gear name to shift count
        """
        distribution = {g.value: 0 for g in Gear}
        for _, from_gear, to_gear in self._shift_history:
            distribution[to_gear.value] += 1
        return distribution


__all__ = ["AdaptiveGearbox"]
