"""
YRSN Gearbox Adapters

Implementations of the IGearbox port for different use cases:
- AdaptiveGearbox: Full auto-shifting with hysteresis (production)

Usage:
    from yrsn.adapters.gearbox import AdaptiveGearbox
    from yrsn.core.gearbox import DrivingMode

    gearbox = AdaptiveGearbox(mode=DrivingMode.SPORT)
"""

from yrsn.adapters.gearbox.adaptive import AdaptiveGearbox

__all__ = ["AdaptiveGearbox"]
