"""
Visualization Adapters

Implementations of VisualizationPort for different rendering backends.

LAYER: Adapters (implements ports using infrastructure)
DEPENDENCIES: ports/, infrastructure/rendering/
"""

from .matplotlib_adapter import MatplotlibAdapter

__all__ = [
    'MatplotlibAdapter',
]
