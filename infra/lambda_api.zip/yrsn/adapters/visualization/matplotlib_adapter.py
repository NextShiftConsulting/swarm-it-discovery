"""
Matplotlib Adapter - Implements VisualizationPort

Concrete implementation of VisualizationPort using matplotlib as the rendering backend.

LAYER: Adapters (implements port interface)
DEPENDENCIES: ports/visualization, infrastructure/rendering/matplotlib
IMPLEMENTS: VisualizationPort

ARCHITECTURE FLOW:
-----------------
Domain → Application → Port Interface ← THIS ADAPTER ← Matplotlib Infrastructure

Application code uses VisualizationPort interface, this adapter bridges to matplotlib.
"""

from typing import Optional, Any
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from matplotlib.figure import Figure

from yrsn.ports.visualization import (
    VisualizationPort,
    CircleDistanceData,
    PhasorDiagramData,
    RSNTernaryData,
    T4ProjectionData,
    ComparisonPlotData,
)
from yrsn.infrastructure.rendering.matplotlib import (
    DEFAULT_THEME,
    YRSNColors,
    save_figure_dual,
)


class MatplotlibAdapter(VisualizationPort):
    """
    Matplotlib implementation of VisualizationPort.

    Usage:
        >>> from yrsn.adapters.visualization import MatplotlibAdapter
        >>> from yrsn.ports.visualization import CircleDistanceData
        >>>
        >>> adapter = MatplotlibAdapter()
        >>> data = CircleDistanceData(...)
        >>> fig = adapter.render_circle_distance(data)
        >>> adapter.save_figure(fig, 'results/plot.png')

    Auto-applies YRSN theme on initialization.
    """

    def __init__(self, auto_apply_theme: bool = True):
        """
        Initialize matplotlib adapter.

        Args:
            auto_apply_theme: Whether to apply DEFAULT_THEME automatically
        """
        if auto_apply_theme:
            DEFAULT_THEME.apply()

    def render_circle_distance(
        self,
        data: CircleDistanceData,
        title: Optional[str] = None
    ) -> Figure:
        """
        Render wrapped vs Euclidean distance on circle.

        Creates visualization showing:
        - Unit circle
        - Two points (theta1, theta2)
        - Euclidean distance (straight line - WRONG)
        - Wrapped distance (arc - CORRECT)

        Args:
            data: CircleDistanceData object
            title: Optional plot title

        Returns:
            matplotlib Figure object
        """
        fig, ax = plt.subplots(figsize=(6, 6))

        # Draw unit circle
        circle = Circle((0, 0), 1.0, fill=False, edgecolor='black', linewidth=2)
        ax.add_patch(circle)

        # Convert angles to radians
        theta1_rad = np.deg2rad(data.theta1)
        theta2_rad = np.deg2rad(data.theta2)

        # Points on circle
        x1, y1 = np.cos(theta1_rad), np.sin(theta1_rad)
        x2, y2 = np.cos(theta2_rad), np.sin(theta2_rad)

        # Plot points
        ax.plot(x1, y1, 'o', color=YRSNColors.BLUE, markersize=12,
                label=f'θ₁={data.theta1:.0f}°', zorder=5)
        ax.plot(x2, y2, 'o', color=YRSNColors.GREEN, markersize=12,
                label=f'θ₂={data.theta2:.0f}°', zorder=5)

        # Euclidean distance (straight line - WRONG!)
        ax.plot([x1, x2], [y1, y2], '--', color=YRSNColors.RED,
                linewidth=2, alpha=0.6,
                label=f'Euclidean: {data.euclidean_distance:.1f}° (WRONG)')

        # Wrapped distance (arc - CORRECT!)
        if data.arc_points:
            arc_x = [p[0] for p in data.arc_points]
            arc_y = [p[1] for p in data.arc_points]
            ax.plot(arc_x, arc_y, '-', color=YRSNColors.GREEN,
                    linewidth=3, label=f'Wrapped: {data.wrapped_distance:.0f}° (CORRECT)')

        # Formatting
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.5, 1.5)
        ax.set_aspect('equal')
        ax.legend(loc='upper right', fontsize=9)
        ax.set_title(title or 'Wrapped vs Euclidean Distance on Circle')
        ax.axis('off')

        plt.tight_layout()
        return fig

    def render_phasor_diagram(
        self,
        data: PhasorDiagramData,
        title: Optional[str] = None
    ) -> Figure:
        """
        Render phasor coherence diagram (polar plot).

        Creates polar plot showing:
        - Individual source phasors (arrows)
        - Resultant phasor (black arrow)
        - Coherence score
        - Conflicting pairs highlighted

        Args:
            data: PhasorDiagramData object
            title: Optional plot title

        Returns:
            matplotlib Figure object
        """
        fig = plt.figure(figsize=(8, 8))
        ax = fig.add_subplot(111, projection='polar')

        # Plot individual sources
        for i, source in enumerate(data.sources):
            amp = source['amplitude']
            phase_deg = source['phase']
            label = source['label']
            phase_rad = np.deg2rad(phase_deg)

            color = YRSNColors.COLORBLIND_SAFE[i % len(YRSNColors.COLORBLIND_SAFE)]

            # Draw arrow from origin
            ax.arrow(0, 0, phase_rad, amp,
                    head_width=0.1, head_length=0.05,
                    fc=color, ec=color, linewidth=2,
                    label=label, alpha=0.7)

        # Plot resultant
        resultant_rad = np.deg2rad(data.resultant_phase)
        ax.arrow(0, 0, resultant_rad, data.resultant_amplitude,
                head_width=0.15, head_length=0.08,
                fc='black', ec='black', linewidth=3,
                label=f'Resultant (coherence={data.coherence:.2f})',
                alpha=0.9, zorder=10)

        # Formatting
        ax.set_ylim(0, 1.2)
        ax.set_title(title or f'Phasor Diagram (Coherence: {data.coherence:.3f})',
                    fontsize=DEFAULT_THEME.fonts.TITLE, pad=20)
        ax.legend(loc='upper left', bbox_to_anchor=(1.1, 1.0),
                 fontsize=DEFAULT_THEME.fonts.LEGEND)

        plt.tight_layout()
        return fig

    def render_rsn_ternary(
        self,
        data: RSNTernaryData,
        title: Optional[str] = None
    ) -> Figure:
        """
        Render RSN values on ternary diagram.

        NOTE: For full ternary plot, consider using mpltern library.
        This provides a simplified 2D projection for now.

        Args:
            data: RSNTernaryData object
            title: Optional plot title

        Returns:
            matplotlib Figure object
        """
        from yrsn.core.decomposition.rsn_constraints import barycentric_to_cartesian

        fig, ax = plt.subplots(figsize=(8, 7))

        # Convert RSN to 2D Cartesian
        points_2d = []
        for R, S, N in zip(data.R_values, data.S_values, data.N_values):
            x, y = barycentric_to_cartesian(R, S, N)
            points_2d.append((x, y))

        points_2d = np.array(points_2d)

        # Draw triangle outline
        sqrt3_2 = np.sqrt(3.0) / 2.0
        triangle = np.array([
            [0.0, 0.0],      # R corner
            [1.0, 0.0],      # S corner
            [0.5, sqrt3_2],  # N corner
            [0.0, 0.0],      # Close
        ])
        ax.plot(triangle[:, 0], triangle[:, 1], 'k-', linewidth=2)

        # Label corners
        ax.text(-0.1, -0.1, 'R\n(Relevant)', ha='right', va='top',
               fontsize=12, color=YRSNColors.RELEVANT, fontweight='bold')
        ax.text(1.1, -0.1, 'S\n(Spurious)', ha='left', va='top',
               fontsize=12, color=YRSNColors.SPURIOUS, fontweight='bold')
        ax.text(0.5, sqrt3_2 + 0.1, 'N\n(Noise)', ha='center', va='bottom',
               fontsize=12, color=YRSNColors.NOISE, fontweight='bold')

        # Plot points
        colors = data.colors if data.colors is not None else YRSNColors.BLUE
        ax.scatter(points_2d[:, 0], points_2d[:, 1],
                  c=colors, s=50, alpha=0.7, edgecolors='black', linewidth=0.5)

        # Labels if provided
        if data.labels:
            for i, (x, y) in enumerate(points_2d[:min(len(data.labels), 10)]):
                ax.annotate(data.labels[i], (x, y), fontsize=8,
                           xytext=(5, 5), textcoords='offset points')

        # Formatting
        ax.set_xlim(-0.2, 1.2)
        ax.set_ylim(-0.2, sqrt3_2 + 0.2)
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_title(title or 'RSN Ternary Plot', fontsize=DEFAULT_THEME.fonts.TITLE)

        plt.tight_layout()
        return fig

    def render_t4_projection(
        self,
        data: T4ProjectionData,
        title: Optional[str] = None
    ) -> Figure:
        """
        Render 4D torus projection to 3D.

        Creates 3D scatter plot of points projected from T⁴.

        Args:
            data: T4ProjectionData object
            title: Optional plot title

        Returns:
            matplotlib Figure object
        """
        from mpl_toolkits.mplot3d import Axes3D

        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')

        # Plot points
        colors = data.colors if data.colors is not None else YRSNColors.BLUE
        scatter = ax.scatter(
            data.points_3d[:, 0],
            data.points_3d[:, 1],
            data.points_3d[:, 2],
            c=colors,
            s=20,
            alpha=0.6,
            edgecolors='black',
            linewidth=0.5
        )

        # Formatting
        ax.set_xlabel('X', fontsize=DEFAULT_THEME.fonts.LABEL)
        ax.set_ylabel('Y', fontsize=DEFAULT_THEME.fonts.LABEL)
        ax.set_zlabel('Z', fontsize=DEFAULT_THEME.fonts.LABEL)
        ax.set_title(
            title or f'T⁴ Projection (w={data.w_slice:.2f})',
            fontsize=DEFAULT_THEME.fonts.TITLE
        )

        plt.tight_layout()
        return fig

    def render_comparison(
        self,
        data: ComparisonPlotData,
        title: Optional[str] = None
    ) -> Figure:
        """
        Render before/after comparison plot.

        Creates side-by-side bar charts showing improvement.

        Args:
            data: ComparisonPlotData object
            title: Optional plot title

        Returns:
            matplotlib Figure object
        """
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

        x = np.arange(len(data.labels))
        width = 0.6

        # Before
        ax1.bar(x, data.before_values, width, color=YRSNColors.RED, alpha=0.7)
        ax1.set_ylabel(data.metric_name, fontsize=DEFAULT_THEME.fonts.LABEL)
        ax1.set_title('Before (Baseline)', fontsize=DEFAULT_THEME.fonts.TITLE)
        ax1.set_xticks(x)
        ax1.set_xticklabels(data.labels, rotation=45, ha='right')
        ax1.grid(True, alpha=0.3, axis='y')

        # After
        ax2.bar(x, data.after_values, width, color=YRSNColors.GREEN, alpha=0.7)
        ax2.set_ylabel(data.metric_name, fontsize=DEFAULT_THEME.fonts.LABEL)
        ax2.set_title('After (YRSN)', fontsize=DEFAULT_THEME.fonts.TITLE)
        ax2.set_xticks(x)
        ax2.set_xticklabels(data.labels, rotation=45, ha='right')
        ax2.grid(True, alpha=0.3, axis='y')

        # Overall title with improvement ratio
        if data.improvement_ratio:
            fig.suptitle(
                f'{title or "Before/After Comparison"} (Improvement: {data.improvement_ratio:.1f}x)',
                fontsize=DEFAULT_THEME.fonts.TITLE + 2,
                fontweight='bold'
            )
        else:
            fig.suptitle(title or 'Before/After Comparison',
                        fontsize=DEFAULT_THEME.fonts.TITLE + 2)

        plt.tight_layout()
        return fig

    def save_figure(
        self,
        figure: Figure,
        path: str,
        **kwargs
    ) -> None:
        """
        Save matplotlib figure using infrastructure save_figure_dual.

        Args:
            figure: matplotlib Figure object
            path: Output file path
            **kwargs: Passed to save_figure_dual (caption, dpi, close)

        Example:
            >>> adapter.save_figure(fig, 'results/plot.png', dpi=300)
            # Saves plot.png and plot.pdf
        """
        save_figure_dual(figure, path, **kwargs)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'MatplotlibAdapter',
]
