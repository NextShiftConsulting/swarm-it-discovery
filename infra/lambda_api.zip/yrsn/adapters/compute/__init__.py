"""
YRSN Compute Adapters

Hardware acceleration adapters for YRSN decomposition:
- Quantum computing (IBM Quantum, AWS Braket) - Claims 26-36
- GPU acceleration (CUDA, ROCm, MPS) - Claim 37
- TPU acceleration (XLA/JAX) - Claim 46
- FPGA acceleration (Xilinx, Intel, AWS F1) - Claim 39
- Edge devices (Jetson, Coral, OpenVINO) - Claim 38

Supported Hardware:
- GPU: NVIDIA CUDA, AMD ROCm, Apple MPS (42K dec/sec)
- TPU: Google Cloud TPU v2-v5 (55K dec/sec)
- FPGA: Xilinx Alveo, Intel, AWS F1 (<1μs latency)
- Edge: Jetson, Coral, OpenVINO, TFLite (<500mW)
- Quantum: IBM, AWS Braket, Azure, Google

Usage:
    from yrsn.adapters.compute import get_gpu_adapter, get_edge_adapter

    # GPU acceleration
    gpu = get_gpu_adapter(backend="cuda")
    result = gpu.decompose_batch(embeddings)

    # Edge deployment
    edge = get_edge_adapter(device="jetson", precision="int8")
    result = edge.decompose(embedding)
"""

from yrsn.adapters.compute.quantum import (
    IBMQuantumAdapter,
    AWSBraketAdapter,
    AzureQuantumAdapter,
    GoogleCirqAdapter,
    QuantumSimulatorAdapter,
    QuantumDecompositionResult,
    get_quantum_adapter,
    QUANTUM_DEVICES,
)

from yrsn.adapters.compute.gpu import (
    CUDAAdapter,
    ROCmAdapter,
    MPSAdapter,
    GPUDecompositionResult,
    BatchGPUResult,
    get_gpu_adapter,
)

from yrsn.adapters.compute.tpu import (
    TPUAdapter,
    XLAAdapter,
    TPUDecompositionResult,
    BatchTPUResult,
)

from yrsn.adapters.compute.fpga import (
    FPGAAdapter,
    XilinxAlveoAdapter,
    AWSF1Adapter,
    FPGADecompositionResult,
)

from yrsn.adapters.compute.edge import (
    EdgeAdapter,
    JetsonAdapter,
    CoralAdapter,
    OpenVINOAdapter,
    TFLiteAdapter,
    QualcommSNPEAdapter,
    EdgeDecompositionResult,
    get_edge_adapter,
)

__all__ = [
    # Quantum (Claims 26-36)
    "IBMQuantumAdapter",
    "AWSBraketAdapter",
    "AzureQuantumAdapter",
    "GoogleCirqAdapter",
    "QuantumSimulatorAdapter",
    "QuantumDecompositionResult",
    "get_quantum_adapter",
    "QUANTUM_DEVICES",
    # GPU (Claim 37)
    "CUDAAdapter",
    "ROCmAdapter",
    "MPSAdapter",
    "GPUDecompositionResult",
    "BatchGPUResult",
    "get_gpu_adapter",
    # TPU (Claim 46)
    "TPUAdapter",
    "XLAAdapter",
    "TPUDecompositionResult",
    "BatchTPUResult",
    # FPGA (Claim 39)
    "FPGAAdapter",
    "XilinxAlveoAdapter",
    "AWSF1Adapter",
    "FPGADecompositionResult",
    # Edge (Claim 38)
    "EdgeAdapter",
    "JetsonAdapter",
    "CoralAdapter",
    "OpenVINOAdapter",
    "TFLiteAdapter",
    "QualcommSNPEAdapter",
    "EdgeDecompositionResult",
    "get_edge_adapter",
]
