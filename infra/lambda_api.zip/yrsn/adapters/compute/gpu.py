"""
GPU Compute Adapters - CUDA and ROCm acceleration for YRSN.

Implements GPU-accelerated decomposition (Patent Claim 37).

Supported Platforms:
- NVIDIA CUDA (via PyTorch, CuPy)
- AMD ROCm (via PyTorch)
- Apple Metal (via PyTorch MPS)

Performance Targets (from patent):
- 42,000 decompositions/second on A100
- Batch processing for throughput
- Mixed precision (FP16/BF16) support

Usage:
    from yrsn.adapters.compute.gpu import CUDAAdapter

    adapter = CUDAAdapter(device="cuda:0")
    signals = adapter.decompose_batch(embeddings)
"""

from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass
import logging
import time

logger = logging.getLogger(__name__)


@dataclass
class GPUDecompositionResult:
    """
    Result from GPU-accelerated decomposition.
    """
    relevant: float
    superfluous: float
    noise: float
    epsilon: float
    device: str
    processing_time_ms: float
    throughput: float                    # decompositions/second
    memory_used_mb: float
    precision: str                       # fp32, fp16, bf16


@dataclass
class BatchGPUResult:
    """
    Batch result from GPU decomposition.
    """
    results: List[GPUDecompositionResult]
    total_time_ms: float
    avg_throughput: float
    peak_memory_mb: float
    batch_size: int


class CUDAAdapter:
    """
    NVIDIA CUDA adapter for GPU-accelerated decomposition.

    Implements Claim 37: GPU tensor operations for YRSN.

    Args:
        device: CUDA device (e.g., "cuda:0", "cuda:1")
        precision: Compute precision ("fp32", "fp16", "bf16")
        max_batch_size: Maximum batch size for memory management
    """

    def __init__(
        self,
        device: str = "cuda:0",
        precision: str = "fp16",
        max_batch_size: int = 1024,
    ):
        self.device_str = device
        self.precision = precision
        self.max_batch_size = max_batch_size
        self._device = None
        self._dtype = None

    def _get_device(self):
        """Initialize CUDA device."""
        if self._device is not None:
            return self._device

        try:
            import torch

            if not torch.cuda.is_available():
                raise RuntimeError("CUDA not available")

            self._device = torch.device(self.device_str)

            # Set precision
            if self.precision == "fp16":
                self._dtype = torch.float16
            elif self.precision == "bf16":
                self._dtype = torch.bfloat16
            else:
                self._dtype = torch.float32

            device_name = torch.cuda.get_device_name(self._device)
            logger.info(f"CUDA adapter initialized: {device_name}")
            return self._device

        except ImportError:
            raise ImportError(
                "PyTorch not installed. Install with: pip install torch"
            )

    def decompose(
        self,
        embedding: Any,
    ) -> GPUDecompositionResult:
        """
        Decompose single embedding on GPU.

        Args:
            embedding: Context embedding (numpy array or torch tensor)

        Returns:
            GPUDecompositionResult
        """
        import torch

        device = self._get_device()
        start_time = time.time()

        # Convert to tensor
        if not isinstance(embedding, torch.Tensor):
            embedding = torch.tensor(embedding, dtype=self._dtype, device=device)
        else:
            embedding = embedding.to(device=device, dtype=self._dtype)

        # GPU decomposition (simplified - actual uses learned projections)
        with torch.no_grad():
            # Normalize
            embedding = embedding / (embedding.norm() + 1e-8)

            # Project to R, S, N components
            dim = embedding.shape[-1]
            third = dim // 3

            # ⚠️ IMPORTANT: Use L2 norm, NOT mean() for tensor→scalar reduction
            # 
            # WHY: Norm preserves "energy" information (vector magnitude), while mean()
            #      destroys directional information (signs cancel out). This is consistent
            #      with YRSN design principles used in yrsn_pipeline.py, crosssim_adapter.py
            #
            # ❌ BAD:  r_proj = embedding[..., :third].mean().item()  # WRONG - loses info
            # ✅ GOOD: r_proj = torch.norm(embedding[..., :third]).item()  # CORRECT
            r_proj_tensor = embedding[..., :third]
            s_proj_tensor = embedding[..., third:2*third]
            n_proj_tensor = embedding[..., 2*third:]

            # Compute L2 norm (handles any number of dimensions)
            r_proj = torch.norm(r_proj_tensor).item()
            s_proj = torch.norm(s_proj_tensor).item()
            n_proj = torch.norm(n_proj_tensor).item()

            # Normalize to simplex (R + S + N = 1)
            total = r_proj + s_proj + n_proj + 1e-8
            relevant = r_proj / total
            superfluous = s_proj / total
            noise = n_proj / total

        processing_time = (time.time() - start_time) * 1000
        memory_used = torch.cuda.memory_allocated(device) / 1e6

        return GPUDecompositionResult(
            relevant=relevant,
            superfluous=superfluous,
            noise=noise,
            epsilon=0.001,
            device=self.device_str,
            processing_time_ms=processing_time,
            throughput=1000 / processing_time if processing_time > 0 else 0,
            memory_used_mb=memory_used,
            precision=self.precision,
        )

    def decompose_batch(
        self,
        embeddings: Any,
        batch_size: Optional[int] = None,
    ) -> BatchGPUResult:
        """
        Decompose batch of embeddings on GPU.

        Args:
            embeddings: Batch of embeddings [N, D]
            batch_size: Sub-batch size (default: max_batch_size)

        Returns:
            BatchGPUResult with all decompositions
        """
        import torch

        device = self._get_device()
        batch_size = batch_size or self.max_batch_size
        start_time = time.time()

        # Convert to tensor
        if not isinstance(embeddings, torch.Tensor):
            embeddings = torch.tensor(embeddings, dtype=self._dtype, device=device)
        else:
            embeddings = embeddings.to(device=device, dtype=self._dtype)

        n_samples = embeddings.shape[0]
        results = []

        with torch.no_grad():
            for i in range(0, n_samples, batch_size):
                batch = embeddings[i:i + batch_size]

                # Normalize
                batch = batch / (batch.norm(dim=-1, keepdim=True) + 1e-8)

                # Project to R, S, N
                dim = batch.shape[-1]
                third = dim // 3

                r_proj = batch[..., :third].mean(dim=-1)
                s_proj = batch[..., third:2*third].mean(dim=-1)
                n_proj = batch[..., 2*third:].mean(dim=-1)

                # Softmax normalization
                total = r_proj.abs() + s_proj.abs() + n_proj.abs() + 1e-8
                r_vals = (r_proj.abs() / total).cpu().numpy()
                s_vals = (s_proj.abs() / total).cpu().numpy()
                n_vals = (n_proj.abs() / total).cpu().numpy()

                for j in range(len(batch)):
                    results.append(GPUDecompositionResult(
                        relevant=float(r_vals[j]),
                        superfluous=float(s_vals[j]),
                        noise=float(n_vals[j]),
                        epsilon=0.001,
                        device=self.device_str,
                        processing_time_ms=0,
                        throughput=0,
                        memory_used_mb=0,
                        precision=self.precision,
                    ))

        total_time = (time.time() - start_time) * 1000
        peak_memory = torch.cuda.max_memory_allocated(device) / 1e6

        return BatchGPUResult(
            results=results,
            total_time_ms=total_time,
            avg_throughput=n_samples / (total_time / 1000) if total_time > 0 else 0,
            peak_memory_mb=peak_memory,
            batch_size=n_samples,
        )

    def get_device_info(self) -> Dict[str, Any]:
        """Get CUDA device information."""
        import torch

        device = self._get_device()
        props = torch.cuda.get_device_properties(device)

        return {
            "name": props.name,
            "compute_capability": f"{props.major}.{props.minor}",
            "total_memory_gb": props.total_memory / 1e9,
            "multiprocessors": props.multi_processor_count,
            "cuda_version": torch.version.cuda,
        }


class ROCmAdapter(CUDAAdapter):
    """
    AMD ROCm adapter for GPU-accelerated decomposition.

    Uses PyTorch with ROCm backend.
    """

    def __init__(
        self,
        device: str = "cuda:0",  # ROCm uses cuda device string
        precision: str = "fp16",
        max_batch_size: int = 1024,
    ):
        super().__init__(device, precision, max_batch_size)

    def _get_device(self):
        """Initialize ROCm device."""
        try:
            import torch

            if not torch.cuda.is_available():
                raise RuntimeError("ROCm/HIP not available")

            # Check if this is ROCm
            if "rocm" not in torch.__version__.lower() and not hasattr(torch.version, 'hip'):
                logger.warning("PyTorch may not be built with ROCm support")

            self._device = torch.device(self.device_str)
            self._dtype = torch.float16 if self.precision == "fp16" else torch.float32

            logger.info(f"ROCm adapter initialized: {self.device_str}")
            return self._device

        except ImportError:
            raise ImportError("PyTorch with ROCm not installed")


class MPSAdapter:
    """
    Apple Metal Performance Shaders adapter.

    For M1/M2/M3 Mac GPU acceleration.
    """

    def __init__(self, precision: str = "fp32"):
        self.precision = precision
        self._device = None

    def _get_device(self):
        """Initialize MPS device."""
        if self._device is not None:
            return self._device

        try:
            import torch

            if not torch.backends.mps.is_available():
                raise RuntimeError("MPS not available")

            self._device = torch.device("mps")
            logger.info("MPS adapter initialized (Apple Silicon)")
            return self._device

        except ImportError:
            raise ImportError("PyTorch not installed")

    def decompose(self, embedding: Any) -> GPUDecompositionResult:
        """Decompose on Apple GPU."""
        import torch

        device = self._get_device()
        start_time = time.time()

        if not isinstance(embedding, torch.Tensor):
            embedding = torch.tensor(embedding, dtype=torch.float32, device=device)
        else:
            embedding = embedding.to(device=device)

        with torch.no_grad():
            embedding = embedding / (embedding.norm() + 1e-8)
            dim = embedding.shape[-1]
            third = dim // 3

            r = embedding[..., :third].mean().item()
            s = embedding[..., third:2*third].mean().item()
            n = embedding[..., 2*third:].mean().item()

            total = abs(r) + abs(s) + abs(n) + 1e-8

        processing_time = (time.time() - start_time) * 1000

        return GPUDecompositionResult(
            relevant=abs(r) / total,
            superfluous=abs(s) / total,
            noise=abs(n) / total,
            epsilon=0.001,
            device="mps",
            processing_time_ms=processing_time,
            throughput=1000 / processing_time if processing_time > 0 else 0,
            memory_used_mb=0,
            precision=self.precision,
        )


def get_gpu_adapter(
    backend: str = "auto",
    device: Optional[str] = None,
    precision: str = "fp16",
) -> Union[CUDAAdapter, ROCmAdapter, MPSAdapter]:
    """
    Factory function to get appropriate GPU adapter.

    Args:
        backend: "cuda", "rocm", "mps", or "auto"
        device: Device string (optional)
        precision: Compute precision

    Returns:
        GPU adapter instance
    """
    try:
        import torch

        if backend == "auto":
            if torch.cuda.is_available():
                backend = "cuda"
            elif torch.backends.mps.is_available():
                backend = "mps"
            else:
                raise RuntimeError("No GPU backend available")

        if backend == "cuda":
            return CUDAAdapter(device=device or "cuda:0", precision=precision)
        elif backend == "rocm":
            return ROCmAdapter(device=device or "cuda:0", precision=precision)
        elif backend == "mps":
            return MPSAdapter(precision=precision)
        else:
            raise ValueError(f"Unknown backend: {backend}")

    except ImportError:
        raise ImportError("PyTorch not installed")
