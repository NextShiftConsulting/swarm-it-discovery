"""
🔓 OPEN ADAPTERS

This folder contains plug-in implementations that connect to YRSN ports.
These adapters are OPEN for customers to use, modify, or replace.

What you CAN do:
✅ Use these adapters as-is
✅ Modify them for your needs
✅ Write your own adapters from scratch
✅ Share with the community (if you want)
✅ Keep private (if you want)

What you CANNOT change:
❌ The port interfaces (those are patent boundaries 🔒)
❌ The core rotor logic (that's licensed 💼)

Simple explanation:
    Adapters are like apps on your phone.
    - Anyone can write them
    - You can modify them
    - You can share them
    - You own your adapters

Examples:
    - Text extractors: Connect text models (BERT, SentenceTransformers, etc.)
    - Vision extractors: Connect vision models (ResNet, ViT, etc.)
    - LLM adapters: Connect to LLM providers (Claude, GPT, etc.)
    - Control adapters: Quality gates, routing, logging

How to write your own:
    1. Find the port interface in src/yrsn/ports/
    2. Implement all required methods
    3. Test it matches the contract
    4. Plug it into the system

---

YRSN Adapters - Optional Control Layer

This package contains ADAPTERS that provide OPTIONAL CONTROL based on YRSN signals.

┌─────────────────────────────────────────────────────────────────┐
│                   HEXAGONAL ARCHITECTURE                         │
├─────────────────────────────────────────────────────────────────┤
│ CORE (yrsn.core):                                                │
│   • Pure measurement (R, S, N, α, ω)                            │
│   • Emits signals (collapse_type, severity, recommended_action) │
│   • NO CONTROL - signals are DATA                               │
├─────────────────────────────────────────────────────────────────┤
│ ADAPTERS (yrsn.adapters): ← YOU ARE HERE                        │
│   • Optional control layer                                       │
│   • Consumers CHOOSE whether to gate, route, log, or ignore     │
│   • Control is localized, not in core                           │
└─────────────────────────────────────────────────────────────────┘

FIRST PRINCIPLES:
----------------
1. YRSN = Signal, Not Control (core emits, adapters MAY enforce)
2. recommended_action = Data (adapters interpret, don't have to obey)
3. Control is Optional (consumers choose their policy)

ADAPTER TYPES:
-------------
- experiment/    Experimental control (gating, energy tracking)
- inbound/       Receive context from sources
- outbound/      Deliver signals to consumers
- compute/       Hardware acceleration
- models/        Feature extractors (text, vision, etc.)

See: docs/core/YRSN_FIRST_PRINCIPLES.md
"""

# Experiment adapters (optional control for research)
# Note: QualityGate is in adapters because it ENFORCES control
# Core should only emit signals, adapters MAY apply control

# Checkpoint loading (infrastructure concern, not core domain)
from yrsn.adapters.checkpoint_loader import CheckpointLoader, load_checkpoint

# Dual-steering CAA → κ_H adapter (experimental, for research integration)
from yrsn.adapters.dual_steering_kappa_h import (
    CAAVector,
    GeodesicFidelity,
    compute_caa_vectors,
    geodesic_fidelity,
    compute_kl_divergence,
    estimate_kappa_H_from_caa,
)

__all__ = [
    # Infrastructure
    'CheckpointLoader',
    'load_checkpoint',
    # Dual-steering research bridge
    'CAAVector',
    'GeodesicFidelity',
    'compute_caa_vectors',
    'geodesic_fidelity',
    'compute_kl_divergence',
    'estimate_kappa_H_from_caa',
]
