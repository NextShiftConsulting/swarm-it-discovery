"""
Inbound Adapters - Input adapters for YRSN pipeline.

These adapters implement input ports, allowing YRSN to receive
context from various sources:

- sql.py: SQL databases (Teradata, Snowflake, PostgreSQL, etc.)
- grpc.py: gRPC streaming input
- ros.py: ROS2 topic subscription
- rest.py: REST API input

Supported Databases:
- PostgreSQL (psycopg2)
- Teradata (teradatasql)
- Snowflake (snowflake-connector-python)
- Google BigQuery (google-cloud-bigquery)
- AWS Redshift (redshift-connector)
- AWS Athena (boto3)
- Azure Synapse Analytics (pyodbc)
- Azure SQL Database (pyodbc)
- IBM DB2 (ibm_db)
- IBM Cloud Databases (psycopg2 / mysql-connector)
- MySQL (mysql-connector-python)
- SQLite (sqlite3)

Usage:
    from yrsn.adapters.inbound.sql import SQLInputAdapter

    adapter = SQLInputAdapter(connection_string="...")
    contexts = adapter.read_batch(table="documents", ...)
"""

from yrsn.adapters.inbound.sql import (
    SQLInputAdapter,
    TeradataInputAdapter,
    PostgresInputAdapter,
    SnowflakeInputAdapter,
    BigQueryInputAdapter,
    RedshiftInputAdapter,
    AthenaInputAdapter,
    AzureSynapseInputAdapter,
    AzureSQLInputAdapter,
    DB2InputAdapter,
    IBMCloudSQLInputAdapter,
    DatabricksInputAdapter,
)

from yrsn.adapters.inbound.ros import (
    ROS2InputAdapter,
    ROS2OutputAdapter,
    ROS2ActionAdapter,
    ROS2ServiceAdapter,
    ROSContextMessage,
    YRSNSignalMessage,
    create_ros2_yrsn_stack,
)

from yrsn.adapters.inbound.grpc import (
    GRPCInputAdapter,
    GRPCOutputAdapter,
    GRPCStreamingAdapter,
    GRPCContextRequest,
    GRPCSignalResponse,
)

from yrsn.adapters.inbound.storage import (
    S3InputAdapter,
    GCSInputAdapter,
    AzureBlobInputAdapter,
    MinIOInputAdapter,
    IBMCOSInputAdapter,
    StorageObject,
)

from yrsn.adapters.inbound.rest import (
    FastAPIAdapter,
    FlaskAdapter,
    WebhookAdapter,
    RESTContextRequest,
    RESTSignalResponse,
)

from yrsn.adapters.inbound.mock_humanoid import (
    MockHumanoidAdapter,
)

__all__ = [
    # Generic SQL
    "SQLInputAdapter",
    # On-premise / Traditional
    "TeradataInputAdapter",
    "PostgresInputAdapter",
    "SnowflakeInputAdapter",
    # GCP
    "BigQueryInputAdapter",
    # AWS
    "RedshiftInputAdapter",
    "AthenaInputAdapter",
    # Azure
    "AzureSynapseInputAdapter",
    "AzureSQLInputAdapter",
    # IBM
    "DB2InputAdapter",
    "IBMCloudSQLInputAdapter",
    # Databricks
    "DatabricksInputAdapter",
    # ROS2 (Robotics - Claims 54-57)
    "ROS2InputAdapter",
    "ROS2OutputAdapter",
    "ROS2ActionAdapter",
    "ROS2ServiceAdapter",
    "ROSContextMessage",
    "YRSNSignalMessage",
    "create_ros2_yrsn_stack",
    # gRPC (Streaming)
    "GRPCInputAdapter",
    "GRPCOutputAdapter",
    "GRPCStreamingAdapter",
    "GRPCContextRequest",
    "GRPCSignalResponse",
    # Object Storage (S3, GCS, Azure, MinIO, IBM COS)
    "S3InputAdapter",
    "GCSInputAdapter",
    "AzureBlobInputAdapter",
    "MinIOInputAdapter",
    "IBMCOSInputAdapter",
    "StorageObject",
    # REST API
    "FastAPIAdapter",
    "FlaskAdapter",
    "WebhookAdapter",
    "RESTContextRequest",
    "RESTSignalResponse",
    # Humanoid (Simulation/Testing)
    "MockHumanoidAdapter",
]
