"""
REST API Input Adapters - HTTP endpoints for YRSN.

Implements REST API integration for YRSN decomposition.

Supported Frameworks:
- FastAPI (async, OpenAPI docs)
- Flask (traditional)
- Starlette (lightweight async)

Usage:
    from yrsn.adapters.inbound.rest import FastAPIAdapter

    adapter = FastAPIAdapter()
    app = adapter.create_app()

    # Run with: uvicorn app:app
"""

from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
import logging
import json

logger = logging.getLogger(__name__)


@dataclass
class RESTContextRequest:
    """
    Context request from REST API.
    """
    id: str
    context: str
    query: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class RESTSignalResponse:
    """
    Signal response for REST API.

    Field names aligned with YRSN v2.0 spec (yrsn_response.schema.json).
    """
    id: str
    # Decomposition (Y = R + S + N + ε)
    R: float  # Relevant
    S: float  # Superfluous
    N: float  # Noise
    epsilon: float  # Reconstruction error
    # Quality
    alpha: float
    omega: float
    alpha_omega: float
    # Temperature
    tau: float
    beta: float
    phase: str  # EXPLOIT, EXPLORE, TRANSITION
    # Collapse
    collapse_detected: bool
    collapse_type: str
    collapse_domain: str
    collapse_severity: str
    collapse_action: str
    # Metadata
    processing_time_ms: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    # Backward compatibility aliases
    @property
    def relevant(self) -> float:
        return self.R

    @property
    def superfluous(self) -> float:
        return self.S

    @property
    def noise(self) -> float:
        return self.N

    @property
    def temperature(self) -> float:
        return self.tau


class FastAPIAdapter:
    """
    FastAPI adapter for REST endpoints.

    Creates OpenAPI-documented endpoints for:
    - POST /decompose: Single decomposition
    - POST /decompose/batch: Batch decomposition
    - GET /health: Health check
    - GET /metrics: Prometheus metrics

    Args:
        title: API title
        version: API version
        decompose_handler: Callback for decomposition
    """

    def __init__(
        self,
        title: str = "YRSN API",
        version: str = "1.0.0",
        decompose_handler: Optional[Callable] = None,
    ):
        self.title = title
        self.version = version
        self.decompose_handler = decompose_handler
        self._app = None

    def create_app(self):
        """Create FastAPI application."""
        try:
            from fastapi import FastAPI, HTTPException
            from fastapi.middleware.cors import CORSMiddleware
            from pydantic import BaseModel
            from typing import List as TypingList

            app = FastAPI(
                title=self.title,
                version=self.version,
                description="YRSN Context Quality Decomposition API",
            )

            # CORS
            app.add_middleware(
                CORSMiddleware,
                allow_origins=["*"],
                allow_methods=["*"],
                allow_headers=["*"],
            )

            # Pydantic models (aligned with v2.0 spec)
            class ContextRequest(BaseModel):
                id: str
                context: str
                query: Optional[str] = None
                metadata: Optional[Dict[str, Any]] = None

            class SignalResponse(BaseModel):
                """Response aligned with YRSN v2.0 spec."""
                id: str
                # Decomposition (Y = R + S + N + ε)
                R: float
                S: float
                N: float
                epsilon: float
                # Quality
                alpha: float
                omega: float
                alpha_omega: float
                # Temperature
                tau: float
                beta: float
                phase: str
                # Collapse
                collapse_detected: bool
                collapse_type: str
                collapse_domain: str
                collapse_severity: str
                collapse_action: str
                # Metadata
                processing_time_ms: float

            class BatchRequest(BaseModel):
                contexts: TypingList[ContextRequest]

            class BatchResponse(BaseModel):
                signals: TypingList[SignalResponse]
                total_time_ms: float
                success_count: int
                failure_count: int

            class HealthResponse(BaseModel):
                status: str
                version: str
                timestamp: str

            # Routes
            @app.get("/health", response_model=HealthResponse)
            async def health():
                return HealthResponse(
                    status="healthy",
                    version=self.version,
                    timestamp=datetime.now().isoformat(),
                )

            @app.post("/decompose", response_model=SignalResponse)
            async def decompose(request: ContextRequest):
                import time
                start_time = time.time()

                if self.decompose_handler:
                    result = self.decompose_handler(request.context, request.query)
                else:
                    # Stub response (v2.0 spec aligned)
                    R, S, N = 0.6, 0.25, 0.15
                    epsilon = 0.02
                    alpha = R / (R + S + N)
                    omega = 0.85
                    alpha_omega = omega * alpha + (1 - omega) * 0.5
                    tau = 1.0 / max(alpha_omega, 0.01)
                    beta = alpha_omega
                    phase = "EXPLOIT" if tau < 1.43 else ("TRANSITION" if tau < 2.50 else "EXPLORE")

                    result = {
                        "R": R,
                        "S": S,
                        "N": N,
                        "epsilon": epsilon,
                        "alpha": alpha,
                        "omega": omega,
                        "alpha_omega": alpha_omega,
                        "tau": tau,
                        "beta": beta,
                        "phase": phase,
                        "collapse_detected": False,
                        "collapse_type": "NONE",
                        "collapse_domain": "quality",
                        "collapse_severity": "none",
                        "collapse_action": "PROCEED",
                    }

                processing_time = (time.time() - start_time) * 1000

                return SignalResponse(
                    id=request.id,
                    processing_time_ms=processing_time,
                    **result,
                )

            @app.post("/decompose/batch", response_model=BatchResponse)
            async def decompose_batch(request: BatchRequest):
                import time
                start_time = time.time()

                signals = []
                for ctx in request.contexts:
                    if self.decompose_handler:
                        result = self.decompose_handler(ctx.context, ctx.query)
                    else:
                        # Stub response (v2.0 spec aligned)
                        R, S, N = 0.6, 0.25, 0.15
                        epsilon = 0.02
                        alpha = R / (R + S + N)
                        omega = 0.85
                        alpha_omega = omega * alpha + (1 - omega) * 0.5
                        tau = 1.0 / max(alpha_omega, 0.01)
                        beta = alpha_omega
                        phase = "EXPLOIT" if tau < 1.43 else ("TRANSITION" if tau < 2.50 else "EXPLORE")

                        result = {
                            "R": R,
                            "S": S,
                            "N": N,
                            "epsilon": epsilon,
                            "alpha": alpha,
                            "omega": omega,
                            "alpha_omega": alpha_omega,
                            "tau": tau,
                            "beta": beta,
                            "phase": phase,
                            "collapse_detected": False,
                            "collapse_type": "NONE",
                            "collapse_domain": "quality",
                            "collapse_severity": "none",
                            "collapse_action": "PROCEED",
                        }

                    signals.append(SignalResponse(
                        id=ctx.id,
                        processing_time_ms=0,
                        **result,
                    ))

                total_time = (time.time() - start_time) * 1000

                return BatchResponse(
                    signals=signals,
                    total_time_ms=total_time,
                    success_count=len(signals),
                    failure_count=0,
                )

            self._app = app
            logger.info(f"FastAPI app created: {self.title} v{self.version}")
            return app

        except ImportError:
            raise ImportError(
                "fastapi not installed. Install with: pip install fastapi uvicorn"
            )

    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the API server."""
        try:
            import uvicorn

            if self._app is None:
                self.create_app()

            uvicorn.run(self._app, host=host, port=port)

        except ImportError:
            raise ImportError("uvicorn not installed. Install with: pip install uvicorn")


class FlaskAdapter:
    """
    Flask adapter for REST endpoints.

    Traditional synchronous Flask API.
    """

    def __init__(
        self,
        name: str = "yrsn",
        decompose_handler: Optional[Callable] = None,
    ):
        self.name = name
        self.decompose_handler = decompose_handler
        self._app = None

    def create_app(self):
        """Create Flask application."""
        try:
            from flask import Flask, request, jsonify

            app = Flask(self.name)

            @app.route("/health", methods=["GET"])
            def health():
                return jsonify({
                    "status": "healthy",
                    "timestamp": datetime.now().isoformat(),
                })

            @app.route("/decompose", methods=["POST"])
            def decompose():
                import time
                start_time = time.time()

                data = request.get_json()

                if self.decompose_handler:
                    result = self.decompose_handler(
                        data.get("context", ""),
                        data.get("query"),
                    )
                else:
                    # Stub response (v2.0 spec aligned)
                    R, S, N = 0.6, 0.25, 0.15
                    epsilon = 0.02
                    alpha = R / (R + S + N)
                    omega = 0.85
                    alpha_omega = omega * alpha + (1 - omega) * 0.5
                    tau = 1.0 / max(alpha_omega, 0.01)
                    beta = alpha_omega
                    phase = "EXPLOIT" if tau < 1.43 else ("TRANSITION" if tau < 2.50 else "EXPLORE")

                    result = {
                        "R": R,
                        "S": S,
                        "N": N,
                        "epsilon": epsilon,
                        "alpha": alpha,
                        "omega": omega,
                        "alpha_omega": alpha_omega,
                        "tau": tau,
                        "beta": beta,
                        "phase": phase,
                        "collapse_detected": False,
                        "collapse_type": "NONE",
                        "collapse_domain": "quality",
                        "collapse_severity": "none",
                        "collapse_action": "PROCEED",
                    }

                result["id"] = data.get("id", "")
                result["processing_time_ms"] = (time.time() - start_time) * 1000

                return jsonify(result)

            self._app = app
            logger.info(f"Flask app created: {self.name}")
            return app

        except ImportError:
            raise ImportError(
                "flask not installed. Install with: pip install flask"
            )

    def run(self, host: str = "0.0.0.0", port: int = 8000, debug: bool = False):
        """Run the Flask server."""
        if self._app is None:
            self.create_app()

        self._app.run(host=host, port=port, debug=debug)


class WebhookAdapter:
    """
    Webhook adapter for push-based integration.

    Sends YRSN signals to configured webhook endpoints.
    """

    def __init__(
        self,
        webhook_url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
    ):
        self.webhook_url = webhook_url
        self.headers = headers or {"Content-Type": "application/json"}
        self.timeout = timeout

    def send_signal(self, signal: RESTSignalResponse) -> bool:
        """Send signal to webhook endpoint."""
        try:
            import requests

            response = requests.post(
                self.webhook_url,
                json=signal.to_dict(),
                headers=self.headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
            logger.debug(f"Webhook sent: {signal.id}")
            return True

        except ImportError:
            raise ImportError("requests not installed. Install with: pip install requests")
        except Exception as e:
            logger.error(f"Webhook failed: {e}")
            return False

    def send_batch(self, signals: List[RESTSignalResponse]) -> int:
        """Send batch of signals to webhook."""
        success_count = 0
        for signal in signals:
            if self.send_signal(signal):
                success_count += 1
        return success_count
