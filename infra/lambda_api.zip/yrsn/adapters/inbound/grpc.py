"""
gRPC Input Adapters - Streaming context input via gRPC.

Implements high-performance streaming for YRSN decomposition.

Supports:
- Unary RPC for single context decomposition
- Server streaming for batch results
- Client streaming for continuous context input
- Bidirectional streaming for real-time processing

Usage:
    from yrsn.adapters.inbound.grpc import GRPCInputAdapter

    # Create server
    server = GRPCInputAdapter(port=50051)

    # Register decomposition handler
    server.register_handler(decompose_callback)

    # Start serving
    server.serve()
"""

from typing import Optional, Callable, Iterator, List, Any, Dict
from dataclasses import dataclass
from datetime import datetime
import logging
from concurrent import futures
import threading

logger = logging.getLogger(__name__)


@dataclass
class GRPCContextRequest:
    """
    Context request received via gRPC.

    Maps to YRSN ContextRecord for processing.
    """
    id: str                              # Request UUID
    context: str                         # Context text
    query: Optional[str] = None          # Optional query
    metadata: Optional[Dict[str, str]] = None  # gRPC metadata
    priority: int = 0                    # Request priority


@dataclass
class GRPCSignalResponse:
    """
    YRSN signal response for gRPC.
    """
    id: str
    relevant: float
    superfluous: float
    noise: float
    epsilon: float
    alpha: float
    omega: float
    alpha_omega: float
    temperature: float
    collapse_type: str
    collapse_axis: str
    severity: str
    action: str                          # PROCEED, WARN, HALT
    processing_time_ms: float = 0.0


class GRPCInputAdapter:
    """
    gRPC input adapter for receiving context streams.

    Provides high-performance RPC interface for YRSN decomposition.

    Args:
        host: Server host (default: localhost)
        port: Server port (default: 50051)
        max_workers: Thread pool size (default: 10)
        max_message_size: Max message size in bytes (default: 4MB)
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        max_workers: int = 10,
        max_message_size: int = 4 * 1024 * 1024,
    ):
        self.host = host
        self.port = port
        self.max_workers = max_workers
        self.max_message_size = max_message_size
        self._server = None
        self._handler: Optional[Callable] = None
        self._running = False

    def register_handler(
        self,
        handler: Callable[[GRPCContextRequest], GRPCSignalResponse],
    ) -> None:
        """
        Register decomposition handler.

        Args:
            handler: Function that takes GRPCContextRequest and returns GRPCSignalResponse
        """
        self._handler = handler
        logger.info("Registered decomposition handler")

    def serve(self, blocking: bool = True) -> None:
        """
        Start the gRPC server.

        Args:
            blocking: Whether to block on serve (default: True)
        """
        try:
            import grpc

            self._server = grpc.server(
                futures.ThreadPoolExecutor(max_workers=self.max_workers),
                options=[
                    ("grpc.max_receive_message_length", self.max_message_size),
                    ("grpc.max_send_message_length", self.max_message_size),
                ],
            )

            # Add generic service (full implementation needs proto definitions)
            self._add_yrsn_service()

            self._server.add_insecure_port(f"{self.host}:{self.port}")
            self._server.start()
            self._running = True

            logger.info(f"gRPC server started on {self.host}:{self.port}")

            if blocking:
                self._server.wait_for_termination()

        except ImportError:
            raise ImportError(
                "grpcio not installed. Install with: pip install grpcio"
            )

    def _add_yrsn_service(self) -> None:
        """Add YRSN decomposition service to server."""
        # This is a stub - full implementation requires proto definitions
        logger.info("YRSN service added (stub - requires proto definitions)")

    def serve_async(self) -> None:
        """Start server in background thread."""
        thread = threading.Thread(target=self.serve, kwargs={"blocking": True})
        thread.daemon = True
        thread.start()
        logger.info("gRPC server started in background")

    def stop(self, grace: float = 5.0) -> None:
        """Stop the gRPC server."""
        if self._server:
            self._server.stop(grace)
            self._running = False
            logger.info("gRPC server stopped")


class GRPCOutputAdapter:
    """
    gRPC client adapter for sending signals to downstream services.

    Args:
        host: Target host
        port: Target port
        use_ssl: Whether to use SSL/TLS
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50051,
        use_ssl: bool = False,
        ssl_cert_path: Optional[str] = None,
    ):
        self.host = host
        self.port = port
        self.use_ssl = use_ssl
        self.ssl_cert_path = ssl_cert_path
        self._channel = None
        self._stub = None

    def connect(self) -> None:
        """Establish connection to gRPC server."""
        try:
            import grpc

            target = f"{self.host}:{self.port}"

            if self.use_ssl:
                if self.ssl_cert_path:
                    with open(self.ssl_cert_path, "rb") as f:
                        credentials = grpc.ssl_channel_credentials(f.read())
                else:
                    credentials = grpc.ssl_channel_credentials()

                self._channel = grpc.secure_channel(target, credentials)
            else:
                self._channel = grpc.insecure_channel(target)

            logger.info(f"Connected to gRPC server at {target}")

        except ImportError:
            raise ImportError("grpcio not installed.")

    def send_signal(self, signal: GRPCSignalResponse) -> bool:
        """Send signal to connected server."""
        if not self._channel:
            self.connect()

        # Stub implementation - needs proto stubs
        logger.debug(f"Sending signal {signal.id}")
        return True

    def close(self) -> None:
        """Close the connection."""
        if self._channel:
            self._channel.close()
            self._channel = None
            logger.info("gRPC connection closed")


class GRPCStreamingAdapter:
    """
    Bidirectional streaming adapter for real-time YRSN processing.

    Supports continuous context streaming with immediate signal responses.
    Optimal for high-frequency robotics or trading applications.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 50052,
        buffer_size: int = 100,
    ):
        self.host = host
        self.port = port
        self.buffer_size = buffer_size
        self._channel = None
        self._stream = None
        self._input_queue: List[GRPCContextRequest] = []
        self._output_queue: List[GRPCSignalResponse] = []

    def connect(self) -> None:
        """Connect to streaming server."""
        try:
            import grpc

            self._channel = grpc.insecure_channel(f"{self.host}:{self.port}")
            logger.info(f"Connected to streaming server at {self.host}:{self.port}")

        except ImportError:
            raise ImportError("grpcio not installed.")

    def send_context(self, request: GRPCContextRequest) -> None:
        """Queue context for streaming."""
        if len(self._input_queue) < self.buffer_size:
            self._input_queue.append(request)
        else:
            logger.warning("Input buffer full, dropping request")

    def receive_signal(self) -> Optional[GRPCSignalResponse]:
        """Receive next signal from stream."""
        if self._output_queue:
            return self._output_queue.pop(0)
        return None

    def stream_contexts(
        self,
        contexts: Iterator[GRPCContextRequest],
    ) -> Iterator[GRPCSignalResponse]:
        """
        Stream contexts and yield signals.

        Bidirectional streaming for real-time processing.
        """
        # Stub implementation
        for ctx in contexts:
            yield GRPCSignalResponse(
                id=ctx.id,
                relevant=0.0,
                superfluous=0.0,
                noise=0.0,
                epsilon=0.0,
                alpha=0.5,
                omega=1.0,
                alpha_omega=0.5,
                temperature=2.0,
                collapse_type="NONE",
                collapse_axis="NONE",
                severity="none",
                action="PROCEED",
            )

    def close(self) -> None:
        """Close streaming connection."""
        if self._channel:
            self._channel.close()
            self._channel = None


class GRPCHealthCheck:
    """
    gRPC health check service for YRSN.

    Implements gRPC health checking protocol.
    """

    def __init__(self, adapter: GRPCInputAdapter):
        self.adapter = adapter
        self._status = "SERVING"

    def check(self, service: str = "") -> str:
        """
        Check health status.

        Returns: SERVING, NOT_SERVING, or UNKNOWN
        """
        if self.adapter._running:
            return "SERVING"
        return "NOT_SERVING"

    def set_status(self, status: str) -> None:
        """Set service status."""
        self._status = status


# Proto message definitions (for documentation)
PROTO_DEFINITION = """
// yrsn_service.proto

syntax = "proto3";

package yrsn;

service YRSNService {
    // Unary RPC - single context decomposition
    rpc Decompose(ContextRequest) returns (SignalResponse);

    // Server streaming - batch decomposition
    rpc DecomposeBatch(BatchRequest) returns (stream SignalResponse);

    // Client streaming - continuous context input
    rpc StreamContexts(stream ContextRequest) returns (BatchResult);

    // Bidirectional streaming - real-time processing
    rpc ProcessStream(stream ContextRequest) returns (stream SignalResponse);
}

message ContextRequest {
    string id = 1;
    string context = 2;
    string query = 3;
    int32 priority = 4;
    map<string, string> metadata = 5;
}

message SignalResponse {
    string id = 1;
    float relevant = 2;
    float superfluous = 3;
    float noise = 4;
    float epsilon = 5;
    float alpha = 6;
    float omega = 7;
    float alpha_omega = 8;
    float temperature = 9;
    string collapse_type = 10;
    string collapse_axis = 11;
    string severity = 12;
    string action = 13;
    float processing_time_ms = 14;
}

message BatchRequest {
    repeated ContextRequest contexts = 1;
}

message BatchResult {
    int32 success_count = 1;
    int32 failure_count = 2;
    float total_time_ms = 3;
}
"""


def generate_proto_stubs() -> str:
    """
    Generate Python stubs from proto definition.

    Run with:
        python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. yrsn_service.proto
    """
    return PROTO_DEFINITION
