"""
Mock Humanoid Adapter - For testing without real robot/simulation.

Provides a simple mock implementation of IHumanoidController
for unit testing and development.
"""

from typing import List, Dict, Optional, Any
import time
import math
import random

from yrsn.ports.humanoid import (
    IHumanoidController,
    HumanoidState,
    HumanoidCommand,
    BodyPart,
    UNITREE_H1_JOINTS,
    UNITREE_G1_JOINTS,
)


class MockHumanoidAdapter(IHumanoidController):
    """
    Mock humanoid robot for testing.

    Simulates basic robot physics:
    - Joints move toward targets
    - Forces respond to contacts
    - COM tracks joint positions
    """

    ROBOT_CONFIGS = {
        "h1": {
            "joints": UNITREE_H1_JOINTS,
            "dof": 19,
            "mass": 47.0,
            "height": 1.8,
        },
        "g1": {
            "joints": UNITREE_G1_JOINTS,
            "dof": 23,
            "mass": 35.0,
            "height": 1.3,
        },
    }

    def __init__(
        self,
        robot_type: str = "h1",
        simulate_noise: bool = True,
        noise_level: float = 0.01,
    ):
        """
        Initialize mock humanoid.

        Args:
            robot_type: "h1" or "g1"
            simulate_noise: Add realistic sensor noise
            noise_level: Standard deviation of noise
        """
        self.robot_type = robot_type
        self.config = self.ROBOT_CONFIGS.get(robot_type, self.ROBOT_CONFIGS["h1"])
        self.simulate_noise = simulate_noise
        self.noise_level = noise_level

        # Build joint list
        self._joint_names: List[str] = []
        for body_part in [BodyPart.LEGS, BodyPart.TORSO, BodyPart.ARMS]:
            self._joint_names.extend(self.config["joints"].get(body_part, []))

        # State
        self._joint_positions: Dict[str, float] = {j: 0.0 for j in self._joint_names}
        self._joint_velocities: Dict[str, float] = {j: 0.0 for j in self._joint_names}
        self._joint_torques: Dict[str, float] = {j: 0.0 for j in self._joint_names}

        # External state
        self._force_torque: Dict[str, tuple] = {
            "left_foot": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            "right_foot": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            "left_hand": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            "right_hand": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        }

        # Contact simulation
        self._contact_active = False
        self._contact_force = 0.0

        # Time tracking
        self._time = 0.0
        self._dt = 0.01  # 100Hz

        # Emergency stop flag
        self._stopped = False

    @property
    def name(self) -> str:
        return f"mock_{self.robot_type}"

    @property
    def dof(self) -> int:
        return len(self._joint_names)

    @property
    def joint_names(self) -> List[str]:
        return self._joint_names.copy()

    def get_state(self) -> HumanoidState:
        """Get current (simulated) robot state."""
        # Add noise if enabled
        positions = self._joint_positions.copy()
        velocities = self._joint_velocities.copy()

        if self.simulate_noise:
            for j in positions:
                positions[j] += random.gauss(0, self.noise_level)
                velocities[j] += random.gauss(0, self.noise_level * 10)

        # Compute approximate COM (simplified - assume at hip height)
        com_z = self.config["height"] * 0.55  # Approximate COM height ratio

        # Support polygon (feet positions - simplified)
        support_polygon = [
            (-0.1, -0.1),
            (0.1, -0.1),
            (0.1, 0.1),
            (-0.1, 0.1),
        ]

        return HumanoidState(
            joint_positions=positions,
            joint_velocities=velocities,
            joint_torques=self._joint_torques.copy(),
            force_torque=self._force_torque.copy(),
            com=(0.0, 0.0, com_z),
            com_velocity=(0.0, 0.0, 0.0),
            support_polygon=support_polygon,
            zmp=(0.0, 0.0),
            base_orientation=(1.0, 0.0, 0.0, 0.0),
            base_angular_velocity=(0.0, 0.0, 0.0),
            end_effector_positions={
                "left_hand": (0.3, 0.3, 1.0),
                "right_hand": (0.3, -0.3, 1.0),
            },
            timestamp=self._time,
        )

    def send_command(self, cmd: HumanoidCommand) -> bool:
        """
        Apply command to mock robot.

        Simulates joint motion toward targets.
        """
        if self._stopped:
            return False

        # Simple P control to move joints toward targets
        for joint, target in cmd.joint_targets.items():
            if joint in self._joint_positions:
                current = self._joint_positions[joint]
                error = target - current

                # Apply velocity limit
                max_vel = cmd.joint_velocities.get(joint, 1.0)
                velocity = max(-max_vel, min(max_vel, error * 10.0))

                # Update position
                self._joint_positions[joint] += velocity * self._dt
                self._joint_velocities[joint] = velocity

                # Compute torque (impedance control)
                K = cmd.impedance_K.get(joint, 100.0)
                D = cmd.impedance_D.get(joint, 10.0)
                torque = K * error - D * velocity
                self._joint_torques[joint] = torque

        self._time += self._dt
        return True

    def emergency_stop(self) -> None:
        """Stop all motion."""
        self._stopped = True
        self._joint_velocities = {j: 0.0 for j in self._joint_names}

    def reset(self) -> None:
        """Reset to initial state."""
        self._joint_positions = {j: 0.0 for j in self._joint_names}
        self._joint_velocities = {j: 0.0 for j in self._joint_names}
        self._joint_torques = {j: 0.0 for j in self._joint_names}
        self._stopped = False
        self._time = 0.0

    def get_subsystem_joints(self, body_part: BodyPart) -> List[str]:
        """Get joints for a body subsystem."""
        return self.config["joints"].get(body_part, [])

    # =========================================================================
    # Test Helpers
    # =========================================================================

    def simulate_contact(self, force: float = 10.0):
        """Simulate contact with object (for testing)."""
        self._contact_active = True
        self._contact_force = force

        # Update hand F/T sensors
        self._force_torque["right_hand"] = (0.0, 0.0, force, 0.0, 0.0, 0.0)

    def clear_contact(self):
        """Clear contact simulation."""
        self._contact_active = False
        self._contact_force = 0.0
        self._force_torque["right_hand"] = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

    def get_contact_force(self) -> float:
        """Get simulated contact force."""
        return self._contact_force

    def step(self, dt: float = 0.01):
        """Step simulation time."""
        self._time += dt
        self._dt = dt

    def get_camera_image(self) -> Any:
        """Return mock camera image (zeros)."""
        try:
            import numpy as np
            return np.zeros((224, 224, 3), dtype=np.uint8)
        except ImportError:
            return None


__all__ = ["MockHumanoidAdapter"]
