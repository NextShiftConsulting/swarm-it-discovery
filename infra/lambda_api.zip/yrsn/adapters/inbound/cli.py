"""
YRSN Command Line Interface Adapter

Provides CLI access to YRSN functionality:
- yrsn analyze <file>         - Analyze context quality from text file
- yrsn decompose <file>       - Run Robust PCA on CSV/NumPy matrix
- yrsn detect --r --s --n     - Detect collapse from ratios
- yrsn test --suite <name>    - Run test suites (basic, stress, safety)
- yrsn info                   - Show package info

Examples:
    yrsn test --suite basic
    yrsn test --suite safety
    yrsn test --suite stress --dataset imagenet-c
"""

import argparse
import sys
import json
from typing import Optional, Dict, Any
from pathlib import Path


class CLIAdapter:
    """CLI adapter for YRSN package."""

    def __init__(self):
        self.parser = self._create_parser()

    def _create_parser(self) -> argparse.ArgumentParser:
        """Create argument parser with all commands."""
        parser = argparse.ArgumentParser(
            prog="yrsn",
            description="YRSN Context Engineering Framework CLI",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  yrsn analyze document.txt
  yrsn decompose data.csv --method godec
  yrsn detect --r 0.3 --s 0.4 --n 0.3
  yrsn test --suite basic
  yrsn test --suite safety --verbose
  yrsn info
            """
        )

        subparsers = parser.add_subparsers(dest='command', help='Commands')

        # analyze command
        analyze_p = subparsers.add_parser('analyze', help='Analyze context quality from text file')
        analyze_p.add_argument('file', help='Text file to analyze')
        analyze_p.add_argument('-v', '--verbose', action='store_true', help='Verbose output')

        # decompose command
        decompose_p = subparsers.add_parser('decompose', help='Decompose matrix using Robust PCA')
        decompose_p.add_argument('file', help='Matrix file (CSV or NPY)')
        decompose_p.add_argument('--method', choices=['ialm', 'pcp', 'godec'], default='ialm',
                                 help='RPCA method (default: ialm)')
        decompose_p.add_argument('-o', '--output', help='Save L/S/N to NPZ file')

        # detect command
        detect_p = subparsers.add_parser('detect', help='Detect collapse from R/S/N ratios')
        detect_p.add_argument('--r', type=float, required=True, help='R (Relevant) ratio')
        detect_p.add_argument('--s', type=float, required=True, help='S (Superfluous) ratio')
        detect_p.add_argument('--n', type=float, required=True, help='N (Noise) ratio')
        detect_p.add_argument('--omega', type=float, help='Omega (OOD) score (0-1)')
        detect_p.add_argument('--epistemic', type=float, help='Epistemic uncertainty')
        detect_p.add_argument('--aleatoric', type=float, help='Aleatoric uncertainty')

        # test command (NEW)
        test_p = subparsers.add_parser('test', help='Run YRSN test suites')
        test_p.add_argument('--suite', choices=['basic', 'yrsn16', 'safety', 'stress', 'adversarial', 'all'],
                           required=True, help='Test suite to run')
        test_p.add_argument('--dataset', help='Optional dataset for stress tests')
        test_p.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
        test_p.add_argument('--json', action='store_true', help='Output results as JSON')
        test_p.add_argument('-o', '--output', help='Save results to file')

        # info command
        subparsers.add_parser('info', help='Show package information')

        return parser

    def run(self, args=None) -> int:
        """Run CLI with given arguments."""
        parsed = self.parser.parse_args(args)

        if parsed.command is None:
            self.parser.print_help()
            return 0

        try:
            if parsed.command == 'analyze':
                return self._cmd_analyze(parsed)
            elif parsed.command == 'decompose':
                return self._cmd_decompose(parsed)
            elif parsed.command == 'detect':
                return self._cmd_detect(parsed)
            elif parsed.command == 'test':
                return self._cmd_test(parsed)
            elif parsed.command == 'info':
                return self._cmd_info(parsed)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

        return 0

    def _cmd_analyze(self, args) -> int:
        """Run analyze command."""
        import numpy as np
        from yrsn.core.decomposition import robust_pca
        from yrsn.core.decomposition.collapse import detect_collapse

        print(f"Analyzing: {args.file}")

        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}")
            return 1

        # Convert text to features
        words = text.lower().split()
        unique_words = list(set(words))[:100]
        n_chunks = max(1, len(words) // 100)
        chunk_size = len(words) // n_chunks

        matrix = np.zeros((n_chunks, len(unique_words)))
        for i in range(n_chunks):
            chunk = words[i * chunk_size:(i + 1) * chunk_size]
            for j, word in enumerate(unique_words):
                matrix[i, j] = chunk.count(word)

        if args.verbose:
            print(f"  Created {n_chunks}x{len(unique_words)} word-chunk matrix")

        result = robust_pca(matrix)
        R, S, N = result.to_yrsn()
        analysis = detect_collapse(R=R, S=S, N=N)

        self._print_analysis_results(args.file, len(text), len(words), R, S, N, analysis)
        return 0

    def _cmd_decompose(self, args) -> int:
        """Run decompose command."""
        import numpy as np
        from yrsn.core.decomposition import robust_pca

        print(f"Decomposing: {args.file}")

        try:
            if args.file.endswith('.csv'):
                matrix = np.loadtxt(args.file, delimiter=',')
            elif args.file.endswith('.npy'):
                matrix = np.load(args.file)
            else:
                matrix = np.loadtxt(args.file, delimiter=',')
        except Exception as e:
            print(f"Error loading matrix: {e}")
            return 1

        result = robust_pca(matrix, method=args.method)
        R, S, N = result.to_yrsn()

        self._print_decomposition_results(result, R, S, N)

        if args.output:
            np.savez(args.output, L=result.L, S=result.S, N=result.N)
            print(f"\nSaved to: {args.output}")

        return 0

    def _cmd_detect(self, args) -> int:
        """Run detect command."""
        from yrsn.core.decomposition.collapse import detect_collapse

        r, s, n = args.r, args.s, args.n
        total = r + s + n
        if abs(total - 1.0) > 0.01:
            print(f"Note: Normalizing ratios (sum = {total:.2f})")
            r, s, n = r/total, s/total, n/total

        kwargs = {'R': r, 'S': s, 'N': n}
        if args.omega is not None:
            kwargs['omega'] = args.omega
        if args.epistemic is not None:
            kwargs['epistemic'] = args.epistemic
        if args.aleatoric is not None:
            kwargs['aleatoric'] = args.aleatoric

        analysis = detect_collapse(**kwargs)
        self._print_detection_results(r, s, n, analysis)
        return 0

    def _cmd_test(self, args) -> int:
        """Run test suite command."""
        from yrsn.testing import TestRunner

        runner = TestRunner(verbose=args.verbose)

        suite = args.suite
        if suite == 'all':
            suites = ['basic', 'yrsn16', 'safety', 'adversarial']
        else:
            suites = [suite]

        all_results = {}
        total_passed = 0
        total_tests = 0

        for s in suites:
            print(f"\n{'='*60}")
            print(f"Running {s.upper()} test suite...")
            print('='*60)

            if s == 'basic':
                results = runner.run_basic_tests()
            elif s == 'yrsn16':
                results = runner.run_yrsn16_tests()
            elif s == 'safety':
                results = runner.run_safety_tests()
            elif s == 'stress':
                results = runner.run_stress_tests(dataset=args.dataset)
            elif s == 'adversarial':
                results = runner.run_adversarial_tests()
            else:
                print(f"Unknown suite: {s}")
                continue

            all_results[s] = results
            total_passed += results.get('passed', 0)
            total_tests += results.get('total', 0)

            # Print suite summary
            pct = (results['passed'] / results['total'] * 100) if results['total'] > 0 else 0
            status = "PASS" if pct >= 100 else "FAIL" if pct < 80 else "WARN"
            print(f"\n{s.upper()}: {results['passed']}/{results['total']} ({pct:.1f}%) [{status}]")

        # Print overall summary
        print(f"\n{'='*60}")
        print("OVERALL SUMMARY")
        print('='*60)
        overall_pct = (total_passed / total_tests * 100) if total_tests > 0 else 0
        print(f"Total: {total_passed}/{total_tests} ({overall_pct:.1f}%)")

        if args.json:
            print("\nJSON Output:")
            print(json.dumps(all_results, indent=2, default=str))

        if args.output:
            with open(args.output, 'w') as f:
                json.dump(all_results, f, indent=2, default=str)
            print(f"\nResults saved to: {args.output}")

        return 0 if overall_pct >= 100 else 1

    def _cmd_info(self, args) -> int:
        """Show package info."""
        print("\n" + "="*50)
        print("YRSN Context Engineering Framework")
        print("="*50)

        try:
            import yrsn
            print(f"\nVersion: {getattr(yrsn, '__version__', '1.0.0')}")
        except:
            print("\nVersion: 1.0.0")

        print("\nY = R + S + N")
        print("  Y (Yield)       - Total output")
        print("  R (Relevant)    - Useful signal")
        print("  S (Superfluous) - Redundant but harmless")
        print("  N (Noise)       - Harmful interference")

        print("\nAvailable Commands:")
        print("  yrsn analyze <file>     - Analyze text file")
        print("  yrsn decompose <file>   - Decompose matrix (CSV/NPY)")
        print("  yrsn detect --r --s --n - Detect collapse from ratios")
        print("  yrsn test --suite <name>- Run test suites")
        print("  yrsn info               - Show this info")

        print("\nTest Suites:")
        print("  basic       - Basic functionality tests")
        print("  yrsn16      - All 16 collapse type tests")
        print("  safety      - Safety band + dual tracking tests")
        print("  stress      - Stress tests with external datasets")
        print("  adversarial - Adversarial boundary tests")
        print("  all         - Run all test suites")

        print("\nOptional Components:")
        self._check_optional("torch", "Neural (PyTorch)")
        self._check_optional("pennylane", "Quantum (PennyLane)")
        self._check_optional("CrossSim", "Hardware (CrossSim)")

        print("\nDocumentation:")
        print("  https://github.com/NextShiftConsulting/yrsn")
        print("="*50)
        return 0

    def _check_optional(self, module: str, name: str):
        """Check if optional module is available."""
        try:
            mod = __import__(module)
            ver = getattr(mod, '__version__', 'unknown')
            print(f"  {name}: Available (v{ver})")
        except ImportError:
            print(f"  {name}: Not installed")

    def _print_analysis_results(self, file_path, char_count, word_count, R, S, N, analysis):
        """Print analysis results."""
        print("\n" + "="*50)
        print("YRSN DECOMPOSITION RESULTS")
        print("="*50)
        print(f"\nFile: {file_path}")
        print(f"Text length: {char_count:,} characters, {word_count:,} words")
        print(f"\nY = R + S + N decomposition:")
        print(f"  R (Relevant):    {R:.1%}")
        print(f"  S (Superfluous): {S:.1%}")
        print(f"  N (Noise):       {N:.1%}")
        print(f"\nCollapse Analysis:")
        print(f"  Type:     {analysis.collapse_type.name}")
        print(f"  Severity: {analysis.severity.value}")
        print("="*50)

    def _print_decomposition_results(self, result, R, S, N):
        """Print decomposition results."""
        print("\n" + "="*50)
        print("ROBUST PCA RESULTS")
        print("="*50)
        print(f"\nDecomposition: M = L + S + N")
        print(f"  L (Low-rank):  rank = {result.rank}")
        print(f"  S (Sparse):    sparsity = {result.sparsity:.1%}")
        print(f"  N (Noise):     error = {result.reconstruction_error:.2e}")
        print(f"\nYRSN Ratios:")
        print(f"  R = {R:.1%}")
        print(f"  S = {S:.1%}")
        print(f"  N = {N:.1%}")
        print("="*50)

    def _print_detection_results(self, r, s, n, analysis):
        """Print detection results."""
        print("\n" + "="*50)
        print("COLLAPSE DETECTION")
        print("="*50)
        print(f"\nInput:")
        print(f"  R = {r:.1%}")
        print(f"  S = {s:.1%}")
        print(f"  N = {n:.1%}")
        print(f"\nResult:")
        print(f"  Collapse Type: {analysis.collapse_type.name}")
        print(f"  Severity:      {analysis.severity.value}")
        print(f"  Confidence:    {analysis.confidence:.1%}")
        print("="*50)


def main():
    """CLI entry point."""
    adapter = CLIAdapter()
    sys.exit(adapter.run())


if __name__ == '__main__':
    main()
