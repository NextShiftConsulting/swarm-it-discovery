# Dual-Steering CAA → κ_H Adapter

Bridge between Contrastive Activation Addition (CAA) steering vectors and RSCT κ_H (encoding-solver compatibility) estimation.

## Overview

This adapter connects interpretability research (CAA vectors) with production quality control (RSCT gatekeeper):

```
External CAA Implementation → dual_steering_kappa_h.py → RSCT Gatekeeper
(Rimsky/Park repos)            (This adapter)            (Quality control)
```

## Key Insight

When CAA steering preserves model behavior (low KL divergence), it indicates high encoding-solver compatibility (high κ_H). This allows RSCT gatekeeper to make informed control decisions based on geometric properties of the steering space.

## Quick Start

### 1. Install CAA Library

Choose one:

```bash
# Option A: Official Python package (if available)
pip install contrastive-activation-addition

# Option B: Clone research repo
git clone https://github.com/nrimsky/CAA
cd CAA && pip install -e .

# Option C: Use Kiho Park's theory implementation
git clone https://github.com/KihoPark/linear_rep_geometry
```

### 2. Import YRSN Adapter

```python
from yrsn.adapters import (
    CAAVector,              # Type-safe steering vector
    GeodesicFidelity,       # κ_H estimate with CI
    geodesic_fidelity,      # KL → κ_H mapping
    compute_kl_divergence,  # Measure behavior change
    estimate_kappa_H_from_caa,  # Full pipeline (placeholder)
)
```

### 3. Compute CAA Vectors (User Implementation Required)

You must implement CAA vector computation using one of the external repos:

```python
# Example using official CAA repo (Rimsky et al., 2024)
from caa import CAA  # Your implementation

# Positive examples (desired behavior)
positive_prompts = [
    "Be factual and accurate when answering questions.",
    "Provide truthful information based on verified sources.",
]

# Negative examples (undesired behavior)
negative_prompts = [
    "Make up plausible-sounding but false information.",
    "Hallucinate facts that sound convincing.",
]

# Compute steering vectors at multiple layers
caa_model = CAA(model, tokenizer)
raw_vectors = caa_model.generate_vectors(
    positive_prompts,
    negative_prompts,
    layers=[8, 12, 16],
)

# Wrap in YRSN type-safe interface
from yrsn.adapters import CAAVector
import torch

caa_vectors = []
for layer_idx, vec in zip([8, 12, 16], raw_vectors):
    caa_vectors.append(
        CAAVector(
            vector=vec,
            layer_idx=layer_idx,
            magnitude=torch.norm(vec).item(),
            behavior_label="factual_vs_hallucination",
            positive_samples=len(positive_prompts),
            negative_samples=len(negative_prompts),
        )
    )
```

### 4. Estimate κ_H from Steering Fidelity

```python
from yrsn.adapters import estimate_kappa_H_from_caa

# Test prompts to measure fidelity
test_prompts = [
    "What is the capital of France?",
    "When did World War II end?",
    "Who wrote Romeo and Juliet?",
]

# Estimate κ_H (requires implementing _apply_steering hook)
fidelity = estimate_kappa_H_from_caa(
    model=model,
    caa_vector=caa_vectors[1],  # Use middle layer
    test_prompts=test_prompts,
    tokenizer=tokenizer,
    steering_coefficient=1.5,  # Moderate steering strength
    scale=1.0,                 # KL → κ_H sensitivity
    method="exponential",      # Geodesic mapping
)

print(f"κ_H = {fidelity.kappa_H:.3f}")
print(f"95% CI: {fidelity.confidence_interval}")
print(f"KL divergence: {fidelity.kl_divergence:.4f} nats")
```

### 5. Integrate with RSCT Gatekeeper

```python
from exp.series_006.expS6_204_rsct_multiagent_gatekeeper import (
    RSCTGatekeeper,
    RSCTCertificate,
)

# Create RSCT certificate with CAA-derived κ_H
cert = RSCTCertificate(
    agent_id="caa_steering_agent",
    step=1,
    R=0.7, S=0.2, N=0.1,        # From YRSN measurement
    alpha=0.875, omega=0.8,
    kappa_gate=fidelity.kappa_H,  # Use κ_H from CAA
    sigma=0.15,
    kappa_A=0.6,
    kappa_E=0.7,
    kappa_T=fidelity.kappa_H,   # Tractability = κ_H from steering
    bottleneck='T' if fidelity.kappa_H < 0.5 else 'balanced',
    coherence=0.85,
    content="Paris is the capital of France.",
    tokens=10,
)

# Gatekeeper validates and makes decision
gatekeeper = RSCTGatekeeper(k_base=0.5, lambda_turb=0.4)
decision = gatekeeper.validate_handoff(cert)

if decision.action == 'EXECUTE':
    print("✓ High compatibility - proceed")
elif decision.action == 'RE_ENCODE':
    print("⚠ Low compatibility - try different steering")
elif decision.action == 'REPAIR':
    print("✗ Very low compatibility - repair encoding")
```

## Architecture

```
┌────────────────────────────────────────────────────────────┐
│  External Research Repos (User-Provided)                   │
│  - github.com/nrimsky/CAA (Rimsky et al., 2024)            │
│  - github.com/KihoPark/linear_rep_geometry (Park, 2023)    │
└────────────────┬───────────────────────────────────────────┘
                 │ compute_caa_vectors() - USER IMPLEMENTS
                 v
┌────────────────────────────────────────────────────────────┐
│  dual_steering_kappa_h.py (YRSN ADAPTER)                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ CAAVector: Type-safe steering vector interface     │    │
│  │ compute_kl_divergence(): Measure behavior change   │    │
│  │ geodesic_fidelity(): KL → κ_H mapping             │    │
│  │ estimate_kappa_H_from_caa(): Full pipeline         │    │
│  └────────────────────────────────────────────────────┘    │
└────────────────┬───────────────────────────────────────────┘
                 │ κ_H ∈ [0,1]
                 v
┌────────────────────────────────────────────────────────────┐
│  RSCT Gatekeeper (PRODUCTION)                              │
│  - RSCTCertificate(kappa_gate=κ_H, kappa_T=κ_H, ...)      │
│  - RSCTGatekeeper.validate_handoff() → decision            │
│  - Actions: EXECUTE / RE_ENCODE / REJECT / BLOCK / REPAIR  │
└────────────────────────────────────────────────────────────┘
```

## API Reference

### Core Functions

#### `geodesic_fidelity(kl_divergence, scale=1.0, method="exponential") -> float`

Convert KL divergence to κ_H ∈ [0,1]:

- **Exponential**: κ_H = exp(-λ·KL)
- **Rational**: κ_H = 1 / (1 + λ·KL)

**Example:**
```python
kappa_h = geodesic_fidelity(kl_divergence=0.5, scale=1.0)
# Result: κ_H ≈ 0.607
```

#### `compute_kl_divergence(logits_baseline, logits_steered, temperature=1.0) -> float`

Measure behavior change from steering:

```python
baseline = model(input_ids).logits
steered = model_with_steering(input_ids).logits
kl = compute_kl_divergence(baseline, steered)
# Result: KL divergence in nats (avg over batch/sequence)
```

### Data Types

#### `CAAVector`

Type-safe steering vector:

```python
@dataclass(frozen=True)
class CAAVector:
    vector: torch.Tensor        # [d_model]
    layer_idx: int              # 0-indexed layer
    magnitude: float            # L2 norm
    behavior_label: str         # e.g., "factual_vs_hallucination"
    positive_samples: int       # N+
    negative_samples: int       # N-
```

#### `GeodesicFidelity`

κ_H estimate with confidence interval:

```python
@dataclass(frozen=True)
class GeodesicFidelity:
    kappa_H: float                     # [0, 1]
    kl_divergence: float               # nats
    behavior_label: str                # Matches CAAVector
    layer_idx: int                     # Matches CAAVector
    num_samples: int                   # Test prompts
    confidence_interval: Tuple[float, float]  # (lower, upper)
```

## Implementation Requirements

### Required: CAA Vector Computation Hook

You must implement the activation collection hook:

```python
def apply_steering_hook(model, input_ids, caa_vector, coefficient):
    """
    Hook mechanism to inject steering vector during forward pass.

    Steps:
    1. Register forward hook on target layer
    2. In hook: hidden_states += coefficient * caa_vector.vector
    3. Run forward pass
    4. Remove hook
    5. Return logits
    """
    # See: https://github.com/nrimsky/CAA/blob/main/caa/caa.py
    raise NotImplementedError("User must implement steering hook")
```

### Required: Full Pipeline Integration

Replace placeholder in `estimate_kappa_H_from_caa()`:

```python
# PLACEHOLDER in adapter - you must implement
def _apply_steering(model, input_ids, caa_vector, coefficient):
    # Your hook-based steering implementation
    pass
```

## Interpretation Guide

### κ_H Mapping to Gatekeeper Decisions

| κ_H Range | KL Range | Gatekeeper Decision | Meaning |
|-----------|----------|---------------------|---------|
| [0.9, 1.0] | [0.0, 0.1] | EXECUTE | Excellent compatibility |
| [0.6, 0.9) | (0.1, 0.5] | EXECUTE | Good compatibility |
| [0.3, 0.6) | (0.5, 1.2] | RE_ENCODE* | Moderate compatibility |
| [0.0, 0.3) | (1.2, ∞) | REPAIR | Poor compatibility |

*RE_ENCODE triggered if turbulence σ > 0.5

### Steering Coefficient Guidelines

- **α = 0.5-1.0**: Gentle steering (high κ_H)
- **α = 1.0-1.5**: Moderate steering (medium κ_H) ← Recommended
- **α = 1.5-2.0**: Aggressive steering (low κ_H)
- **α > 2.0**: Destructive steering (very low κ_H)

## References

### Papers

- **Rimsky et al. (2024)**: "Steering Llama 2 via Contrastive Activation Addition"
  - Paper: https://arxiv.org/abs/2312.06681
  - Code: https://github.com/nrimsky/CAA
  - Published: ACL 2024

- **Park et al. (2023)**: "The Linear Representation Hypothesis and the Geometry of LLMs"
  - Paper: https://arxiv.org/abs/2311.03658
  - Code: https://github.com/KihoPark/linear_rep_geometry
  - Published: ICML 2024

### YRSN Documentation

- **Adapter Implementation**: `src/yrsn/adapters/dual_steering_kappa_h.py`
- **RSCT Gatekeeper**: `exp/series_006/expS6_204_rsct_multiagent_gatekeeper.py`
- **Integration Example**: `exp/series_006/example_dual_steering_integration.py`
- **RSCT Theory**: `docs/primary/RSCT_YRSN_canonical_reference_v2.tex`

## Examples

See `exp/series_006/example_dual_steering_integration.py` for full working demo showing:
1. CAA vector computation (template)
2. κ_H estimation from steering fidelity
3. RSCT gatekeeper integration
4. Decision mapping across steering strengths

Run demo:
```bash
cd exp/series_006
python example_dual_steering_integration.py
```

## Support

For questions about:
- **CAA implementation**: See official repos (Rimsky/Park)
- **YRSN adapter**: Check docstrings in `dual_steering_kappa_h.py`
- **RSCT gatekeeper**: See `expS6_204_rsct_multiagent_gatekeeper.py`

## License

Proprietary - Next Shift Consulting LLC
