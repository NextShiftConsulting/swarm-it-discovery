"""
In-Memory Stream Connector for Testing

Provides a simple in-memory queue implementation for:
- Unit testing
- CI/CD pipelines
- Local development without external dependencies

Usage:
    >>> connector = MemoryStreamConnector()
    >>> await connector.connect()
    >>>
    >>> # Produce messages
    >>> await connector.produce(StreamMessage(id="1", payload="test data"))
    >>>
    >>> # Consume messages
    >>> async for msg in connector.consume():
    ...     print(f"Received: {msg.payload}")
"""

import asyncio
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from typing import AsyncIterator, Dict, List, Optional
import time

from .base import (
    IStreamConnector,
    StreamMessage,
    StreamConfig,
    MessageStatus,
)


class MemoryStreamConnector:
    """
    In-memory stream connector for testing.

    Features:
    - Thread-safe async queues per topic
    - Simulated latency (optional)
    - Message persistence within session
    - Dead letter queue support
    """

    def __init__(
        self,
        config: Optional[StreamConfig] = None,
        simulate_latency_ms: float = 0.0,
    ):
        """
        Initialize in-memory connector.

        Args:
            config: Stream configuration
            simulate_latency_ms: Optional latency simulation (for testing)
        """
        self._config = config or StreamConfig()
        self._simulate_latency_ms = simulate_latency_ms

        # Topic -> Queue mapping
        self._queues: Dict[str, asyncio.Queue] = defaultdict(asyncio.Queue)

        # Message history (for testing/debugging)
        self._produced: Dict[str, List[StreamMessage]] = defaultdict(list)
        self._consumed: Dict[str, List[StreamMessage]] = defaultdict(list)
        self._dlq: List[StreamMessage] = []

        self._connected = False

    async def connect(self) -> None:
        """Connect (no-op for memory connector)."""
        self._connected = True

    async def disconnect(self) -> None:
        """Disconnect and clear queues."""
        self._connected = False
        self._queues.clear()

    async def consume(
        self,
        topic: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> AsyncIterator[StreamMessage]:
        """
        Consume messages from the in-memory queue.

        Args:
            topic: Topic to consume from
            timeout: Optional timeout in seconds (None = wait forever)

        Yields:
            StreamMessage instances
        """
        topic = topic or self._config.topic
        queue = self._queues[topic]

        while self._connected:
            try:
                if timeout:
                    msg = await asyncio.wait_for(queue.get(), timeout=timeout)
                else:
                    msg = await asyncio.wait_for(queue.get(), timeout=0.1)

                # Simulate latency if configured
                if self._simulate_latency_ms > 0:
                    await asyncio.sleep(self._simulate_latency_ms / 1000)

                msg.status = MessageStatus.PROCESSING
                self._consumed[topic].append(msg)
                yield msg

            except asyncio.TimeoutError:
                if timeout:
                    break
                continue

    async def produce(
        self,
        message: StreamMessage,
        topic: Optional[str] = None,
    ) -> bool:
        """
        Produce a message to the in-memory queue.

        Args:
            message: Message to send
            topic: Target topic

        Returns:
            True if successful
        """
        if not self._connected:
            return False

        topic = topic or message.topic or self._config.topic
        message.topic = topic

        # Generate ID if not set
        if not message.id:
            message.id = str(uuid.uuid4())

        # Add to queue
        await self._queues[topic].put(message)
        self._produced[topic].append(message)

        return True

    async def produce_batch(
        self,
        messages: List[StreamMessage],
        topic: Optional[str] = None,
    ) -> int:
        """
        Produce multiple messages.

        Args:
            messages: Messages to send
            topic: Target topic

        Returns:
            Number of messages sent
        """
        count = 0
        for msg in messages:
            if await self.produce(msg, topic):
                count += 1
        return count

    async def acknowledge(self, message: StreamMessage) -> None:
        """Acknowledge a processed message (no-op for memory connector)."""
        pass  # Memory connector doesn't need acks

    async def send_to_dlq(self, message: StreamMessage, reason: str) -> None:
        """Send failed message to dead letter queue."""
        message.status = MessageStatus.ERROR
        message.rejection_reason = reason
        self._dlq.append(message)

        # Also send to DLQ topic if configured
        if self._config.dead_letter_topic:
            dlq_msg = StreamMessage(
                id=f"dlq_{message.id}",
                payload=message.to_dict(),
                topic=self._config.dead_letter_topic,
                headers={'original_topic': message.topic, 'reason': reason},
            )
            await self._queues[self._config.dead_letter_topic].put(dlq_msg)

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected

    @property
    def config(self) -> StreamConfig:
        """Get connector configuration."""
        return self._config

    # =========================================================================
    # Testing Utilities
    # =========================================================================

    def get_queue_size(self, topic: Optional[str] = None) -> int:
        """Get number of pending messages in queue."""
        topic = topic or self._config.topic
        return self._queues[topic].qsize()

    def get_produced_count(self, topic: Optional[str] = None) -> int:
        """Get total messages produced to topic."""
        topic = topic or self._config.topic
        return len(self._produced[topic])

    def get_consumed_count(self, topic: Optional[str] = None) -> int:
        """Get total messages consumed from topic."""
        topic = topic or self._config.topic
        return len(self._consumed[topic])

    def get_dlq_messages(self) -> List[StreamMessage]:
        """Get all dead letter queue messages."""
        return self._dlq.copy()

    def clear(self) -> None:
        """Clear all queues and history."""
        self._queues.clear()
        self._produced.clear()
        self._consumed.clear()
        self._dlq.clear()

    async def drain(self, topic: Optional[str] = None, max_messages: int = 1000) -> List[StreamMessage]:
        """
        Drain all messages from a queue (testing utility).

        Args:
            topic: Topic to drain
            max_messages: Maximum messages to retrieve

        Returns:
            List of drained messages
        """
        topic = topic or self._config.topic
        queue = self._queues[topic]
        messages = []

        while not queue.empty() and len(messages) < max_messages:
            try:
                msg = queue.get_nowait()
                messages.append(msg)
            except asyncio.QueueEmpty:
                break

        return messages


# =============================================================================
# Test Fixtures
# =============================================================================

def create_test_messages(
    n: int,
    topic: str = "test",
    payload_prefix: str = "test_payload_",
) -> List[StreamMessage]:
    """
    Create test messages for unit testing.

    Args:
        n: Number of messages to create
        topic: Topic name
        payload_prefix: Payload prefix

    Returns:
        List of StreamMessage instances
    """
    return [
        StreamMessage(
            id=f"msg_{i}",
            payload=f"{payload_prefix}{i}",
            topic=topic,
            timestamp=time.time() + i * 0.001,
        )
        for i in range(n)
    ]


async def run_producer_consumer_test(
    connector: MemoryStreamConnector,
    n_messages: int = 100,
    topic: str = "test",
) -> Dict[str, int]:
    """
    Run a simple producer-consumer test.

    Args:
        connector: Memory connector to test
        n_messages: Number of messages
        topic: Topic name

    Returns:
        Dict with produced/consumed counts
    """
    await connector.connect()

    # Produce messages
    messages = create_test_messages(n_messages, topic)
    produced = await connector.produce_batch(messages, topic)

    # Consume messages
    consumed = 0
    async for msg in connector.consume(topic, timeout=1.0):
        consumed += 1
        if consumed >= n_messages:
            break

    await connector.disconnect()

    return {
        'produced': produced,
        'consumed': consumed,
        'queue_remaining': connector.get_queue_size(topic),
    }
