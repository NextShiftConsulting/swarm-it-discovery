"""
YRSN Streaming Adapters for Real-Time Certificate Validation

Adapter implementations for IStreamConnector port.

Hexagonal Architecture:
    PORT: yrsn.ports.streaming.IStreamConnector
    ADAPTERS:
    - MemoryStreamConnector (testing/CI)
    - RedisStreamConnector (lightweight production)
    - KafkaStreamConnector (enterprise production)

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 11)

Usage:
    >>> from yrsn.adapters.streaming import StreamingGateway, MemoryStreamConnector
    >>>
    >>> # Create streaming gateway with in-memory backend (testing)
    >>> connector = MemoryStreamConnector()
    >>> gateway = StreamingGateway(connector, modality='text')
    >>>
    >>> # Process messages
    >>> async for cert, accepted in gateway.process_stream():
    ...     if accepted:
    ...         print(f"Accepted: R={cert['R']:.3f}")
"""

# Import types from base (adapters have their own types for backward compat)
from .base import (
    IStreamConnector,
    StreamMessage,
    StreamConfig,
    StreamMetrics,
)
from .memory_stream import MemoryStreamConnector
from .gateway import StreamingGateway, StreamingGatewayConfig
from .batch_processor import BatchProcessor, BatchConfig

__all__ = [
    # Base types
    'IStreamConnector',
    'StreamMessage',
    'StreamConfig',
    'StreamMetrics',
    # Connectors
    'MemoryStreamConnector',
    # Gateway
    'StreamingGateway',
    'StreamingGatewayConfig',
    # Batch processing
    'BatchProcessor',
    'BatchConfig',
]

# Optional imports (require external dependencies)
try:
    from .redis_stream import RedisStreamConnector
    __all__.append('RedisStreamConnector')
except ImportError:
    pass  # redis not installed

try:
    from .kafka_stream import KafkaStreamConnector
    __all__.append('KafkaStreamConnector')
except ImportError:
    pass  # kafka-python not installed
