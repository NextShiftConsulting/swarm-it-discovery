"""
Batch Processor for High-Throughput Streaming

Optimizes throughput by:
- Micro-batching for GPU efficiency
- Pipelining feature extraction and validation
- Result caching

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 11)
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np


@dataclass
class BatchConfig:
    """Configuration for batch processing."""
    batch_size: int = 32
    batch_timeout_ms: int = 100
    max_concurrent_batches: int = 4
    enable_pipelining: bool = True


@dataclass
class BatchResult:
    """Result of batch processing."""
    batch_id: int
    items_processed: int
    items_accepted: int
    items_rejected: int
    total_latency_ms: float
    avg_latency_ms: float
    throughput: float  # items/second


class BatchProcessor:
    """
    High-throughput batch processor.

    Features:
    - Micro-batching for efficient GPU usage
    - Async pipelining
    - Automatic batch sizing
    """

    def __init__(
        self,
        process_fn: Callable,
        config: Optional[BatchConfig] = None,
    ):
        """
        Initialize batch processor.

        Args:
            process_fn: Function to process a batch of items
            config: Batch configuration
        """
        self._process_fn = process_fn
        self._config = config or BatchConfig()

        self._buffer: List[Any] = []
        self._buffer_lock = asyncio.Lock()
        self._last_flush_time = time.time()

        self._batch_count = 0
        self._total_processed = 0

    async def add(self, item: Any) -> Optional[BatchResult]:
        """
        Add an item to the batch buffer.

        Returns BatchResult if batch was processed, None otherwise.
        """
        async with self._buffer_lock:
            self._buffer.append(item)

            # Check if we should flush
            should_flush = (
                len(self._buffer) >= self._config.batch_size or
                self._time_since_last_flush_ms() >= self._config.batch_timeout_ms
            )

            if should_flush:
                return await self._flush()

        return None

    async def add_batch(self, items: List[Any]) -> List[BatchResult]:
        """Add multiple items, processing full batches."""
        results = []

        for item in items:
            result = await self.add(item)
            if result:
                results.append(result)

        return results

    async def flush(self) -> Optional[BatchResult]:
        """Force flush the current buffer."""
        async with self._buffer_lock:
            if self._buffer:
                return await self._flush()
        return None

    async def _flush(self) -> BatchResult:
        """Process and clear the buffer."""
        batch = self._buffer.copy()
        self._buffer.clear()
        self._last_flush_time = time.time()

        # Process batch
        start_time = time.perf_counter()

        try:
            results = self._process_fn(batch)
            if asyncio.iscoroutine(results):
                results = await results
        except Exception as e:
            # Return error result
            return BatchResult(
                batch_id=self._batch_count,
                items_processed=len(batch),
                items_accepted=0,
                items_rejected=len(batch),
                total_latency_ms=(time.perf_counter() - start_time) * 1000,
                avg_latency_ms=0,
                throughput=0,
            )

        elapsed_ms = (time.perf_counter() - start_time) * 1000

        # Count accepted/rejected
        if isinstance(results, list):
            accepted = sum(1 for r in results if getattr(r, 'accepted', True))
        else:
            accepted = len(batch)

        self._batch_count += 1
        self._total_processed += len(batch)

        return BatchResult(
            batch_id=self._batch_count,
            items_processed=len(batch),
            items_accepted=accepted,
            items_rejected=len(batch) - accepted,
            total_latency_ms=elapsed_ms,
            avg_latency_ms=elapsed_ms / len(batch) if batch else 0,
            throughput=len(batch) / (elapsed_ms / 1000) if elapsed_ms > 0 else 0,
        )

    def _time_since_last_flush_ms(self) -> float:
        """Time since last flush in milliseconds."""
        return (time.time() - self._last_flush_time) * 1000

    @property
    def buffer_size(self) -> int:
        """Current buffer size."""
        return len(self._buffer)

    @property
    def total_processed(self) -> int:
        """Total items processed."""
        return self._total_processed

    @property
    def batch_count(self) -> int:
        """Total batches processed."""
        return self._batch_count


async def run_batch_benchmark(
    processor: BatchProcessor,
    n_items: int = 10000,
    item_factory: Optional[Callable] = None,
) -> Dict[str, Any]:
    """
    Run a batch processing benchmark.

    Args:
        processor: BatchProcessor to benchmark
        n_items: Number of items to process
        item_factory: Optional factory for creating test items

    Returns:
        Benchmark results
    """
    if item_factory is None:
        item_factory = lambda i: f"test_item_{i}"

    items = [item_factory(i) for i in range(n_items)]

    start_time = time.time()
    results = await processor.add_batch(items)

    # Flush remaining
    final_result = await processor.flush()
    if final_result:
        results.append(final_result)

    elapsed = time.time() - start_time

    # Aggregate results
    total_accepted = sum(r.items_accepted for r in results)
    total_latency = sum(r.total_latency_ms for r in results)

    return {
        'n_items': n_items,
        'n_batches': len(results),
        'elapsed_seconds': elapsed,
        'throughput': n_items / elapsed,
        'total_accepted': total_accepted,
        'total_rejected': n_items - total_accepted,
        'avg_batch_latency_ms': total_latency / len(results) if results else 0,
        'items_per_batch': n_items / len(results) if results else 0,
    }
