"""
Base Types for YRSN Streaming

Defines the streaming abstraction layer with:
- IStreamConnector: Protocol for stream backends
- StreamMessage: Message wrapper with metadata
- StreamConfig: Configuration for streams
- StreamMetrics: Monitoring metrics
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    Any, AsyncIterator, Dict, List, Optional,
    Protocol, Tuple, Union, runtime_checkable
)
from enum import Enum
import time


class MessageStatus(Enum):
    """Message processing status."""
    PENDING = "pending"
    PROCESSING = "processing"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ERROR = "error"


@dataclass
class StreamMessage:
    """
    Wrapper for stream messages with metadata.

    Attributes:
        id: Unique message identifier
        payload: Raw message content (bytes or dict)
        topic: Stream/topic name
        timestamp: Message timestamp (epoch seconds)
        headers: Optional headers/metadata
        status: Processing status
        certificate: Optional attached certificate (after processing)
    """
    id: str
    payload: Union[bytes, Dict[str, Any], str]
    topic: str = "default"
    timestamp: float = field(default_factory=time.time)
    headers: Dict[str, str] = field(default_factory=dict)
    status: MessageStatus = MessageStatus.PENDING
    certificate: Optional[Dict[str, Any]] = None
    rejection_reason: Optional[str] = None

    def get_content(self) -> str:
        """Get payload as string."""
        if isinstance(self.payload, bytes):
            return self.payload.decode('utf-8')
        elif isinstance(self.payload, dict):
            return str(self.payload)
        return str(self.payload)

    def set_certificate(self, cert: Dict[str, Any], accepted: bool, reason: Optional[str] = None):
        """Attach certificate and update status."""
        self.certificate = cert
        self.status = MessageStatus.ACCEPTED if accepted else MessageStatus.REJECTED
        self.rejection_reason = reason

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'payload': self.payload if isinstance(self.payload, (dict, str)) else self.payload.decode('utf-8'),
            'topic': self.topic,
            'timestamp': self.timestamp,
            'headers': self.headers,
            'status': self.status.value,
            'certificate': self.certificate,
            'rejection_reason': self.rejection_reason,
        }


@dataclass
class StreamConfig:
    """
    Configuration for stream connectors.

    Attributes:
        topic: Default topic/stream name
        consumer_group: Consumer group ID
        batch_size: Messages to buffer before processing
        batch_timeout_ms: Max wait time for batch
        auto_commit: Auto-commit offsets after processing
        retry_on_error: Retry failed messages
        max_retries: Maximum retry attempts
        dead_letter_topic: Topic for rejected/failed messages
    """
    topic: str = "yrsn_input"
    consumer_group: str = "yrsn_gateway"
    batch_size: int = 32
    batch_timeout_ms: int = 100
    auto_commit: bool = True
    retry_on_error: bool = True
    max_retries: int = 3
    dead_letter_topic: Optional[str] = "yrsn_dlq"

    # Connection settings (backend-specific)
    host: str = "localhost"
    port: int = 6379  # Default Redis port
    password: Optional[str] = None
    ssl: bool = False


@dataclass
class StreamMetrics:
    """
    Metrics for stream processing.

    Tracks throughput, latency, and quality metrics.
    """
    messages_received: int = 0
    messages_accepted: int = 0
    messages_rejected: int = 0
    messages_error: int = 0

    total_latency_ms: float = 0.0
    min_latency_ms: float = float('inf')
    max_latency_ms: float = 0.0

    # Quality metrics
    total_R: float = 0.0
    total_S: float = 0.0
    total_N: float = 0.0

    start_time: float = field(default_factory=time.time)

    def record_message(
        self,
        accepted: bool,
        latency_ms: float,
        r_score: float = 0.0,
        s_score: float = 0.0,
        n_score: float = 0.0,
    ):
        """Record a processed message."""
        self.messages_received += 1
        if accepted:
            self.messages_accepted += 1
        else:
            self.messages_rejected += 1

        self.total_latency_ms += latency_ms
        self.min_latency_ms = min(self.min_latency_ms, latency_ms)
        self.max_latency_ms = max(self.max_latency_ms, latency_ms)

        self.total_R += r_score
        self.total_S += s_score
        self.total_N += n_score

    def record_error(self):
        """Record an error."""
        self.messages_error += 1

    @property
    def throughput(self) -> float:
        """Messages per second."""
        elapsed = time.time() - self.start_time
        return self.messages_received / elapsed if elapsed > 0 else 0

    @property
    def avg_latency_ms(self) -> float:
        """Average latency in milliseconds."""
        return self.total_latency_ms / self.messages_received if self.messages_received > 0 else 0

    @property
    def accept_rate(self) -> float:
        """Fraction of messages accepted."""
        return self.messages_accepted / self.messages_received if self.messages_received > 0 else 0

    @property
    def avg_R(self) -> float:
        """Average R score."""
        return self.total_R / self.messages_received if self.messages_received > 0 else 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'messages_received': self.messages_received,
            'messages_accepted': self.messages_accepted,
            'messages_rejected': self.messages_rejected,
            'messages_error': self.messages_error,
            'throughput': self.throughput,
            'avg_latency_ms': self.avg_latency_ms,
            'min_latency_ms': self.min_latency_ms if self.min_latency_ms != float('inf') else 0,
            'max_latency_ms': self.max_latency_ms,
            'accept_rate': self.accept_rate,
            'avg_R': self.avg_R,
            'uptime_seconds': time.time() - self.start_time,
        }

    def reset(self):
        """Reset metrics."""
        self.messages_received = 0
        self.messages_accepted = 0
        self.messages_rejected = 0
        self.messages_error = 0
        self.total_latency_ms = 0.0
        self.min_latency_ms = float('inf')
        self.max_latency_ms = 0.0
        self.total_R = 0.0
        self.total_S = 0.0
        self.total_N = 0.0
        self.start_time = time.time()


@runtime_checkable
class IStreamConnector(Protocol):
    """
    Protocol for stream connectors.

    Implementations must provide:
    - connect/disconnect lifecycle
    - consume messages (async iterator)
    - produce messages
    - acknowledge processed messages
    """

    async def connect(self) -> None:
        """Connect to the stream backend."""
        ...

    async def disconnect(self) -> None:
        """Disconnect from the stream backend."""
        ...

    async def consume(self, topic: Optional[str] = None) -> AsyncIterator[StreamMessage]:
        """
        Consume messages from stream.

        Args:
            topic: Topic to consume from (uses config default if None)

        Yields:
            StreamMessage instances
        """
        ...

    async def produce(self, message: StreamMessage, topic: Optional[str] = None) -> bool:
        """
        Produce a message to stream.

        Args:
            message: Message to send
            topic: Topic to send to (uses config default if None)

        Returns:
            True if successful
        """
        ...

    async def acknowledge(self, message: StreamMessage) -> None:
        """Acknowledge a processed message."""
        ...

    async def send_to_dlq(self, message: StreamMessage, reason: str) -> None:
        """Send failed message to dead letter queue."""
        ...

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        ...

    @property
    def config(self) -> StreamConfig:
        """Get connector configuration."""
        ...
