"""
Streaming Gateway for Real-Time Certificate Validation

Integrates stream connectors with YRSN quality validation:
- Consumes messages from input stream
- Extracts features and computes R/S/N
- Validates against modality-specific thresholds
- Routes accepted/rejected messages to output streams

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 11)

Usage:
    >>> from yrsn.streaming import StreamingGateway, MemoryStreamConnector
    >>>
    >>> connector = MemoryStreamConnector()
    >>> gateway = StreamingGateway(connector, modality='text')
    >>>
    >>> await gateway.start()
    >>>
    >>> # Messages flow through: input -> validate -> accepted/rejected
    >>> async for result in gateway.process_stream():
    ...     print(f"Message {result.message.id}: {'ACCEPTED' if result.accepted else 'REJECTED'}")
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import (
    Any, AsyncIterator, Callable, Dict, List, Optional, Tuple, Union
)

import numpy as np

from .base import (
    IStreamConnector,
    StreamMessage,
    StreamConfig,
    StreamMetrics,
    MessageStatus,
)


@dataclass
class StreamingGatewayConfig:
    """
    Configuration for streaming gateway.

    Attributes:
        modality: Default modality for feature extraction
        input_topic: Topic to consume from
        accepted_topic: Topic for accepted messages
        rejected_topic: Topic for rejected messages
        batch_size: Messages to process in batch
        batch_timeout_ms: Max wait time for batch
        enable_caching: Cache feature extraction results
        cache_ttl_seconds: Cache TTL
        enable_metrics: Track processing metrics
        enable_passthrough: Pass original message with certificate
    """
    modality: str = "text"
    input_topic: str = "yrsn_input"
    accepted_topic: str = "yrsn_accepted"
    rejected_topic: str = "yrsn_rejected"

    batch_size: int = 32
    batch_timeout_ms: int = 100

    enable_caching: bool = True
    cache_ttl_seconds: float = 300.0
    cache_max_size: int = 10000

    enable_metrics: bool = True
    enable_passthrough: bool = True

    # Feature extraction settings
    feature_extractor_id: Optional[str] = None
    rotor_checkpoint: str = "checkpoints/trained_rotor_universal64.pt"


@dataclass
class ValidationResult:
    """Result of stream message validation."""
    message: StreamMessage
    accepted: bool
    certificate: Optional[Dict[str, Any]] = None
    rejection_reason: Optional[str] = None
    latency_ms: float = 0.0


class StreamingGateway:
    """
    Real-time streaming gateway with YRSN validation.

    Features:
    - Batched feature extraction for throughput
    - Modality-aware threshold selection
    - Result caching for repeated content
    - Metrics tracking
    - Automatic DLQ routing
    """

    def __init__(
        self,
        connector: IStreamConnector,
        config: Optional[StreamingGatewayConfig] = None,
        feature_extractor: Optional[Callable] = None,
        rotor: Optional[Any] = None,
    ):
        """
        Initialize streaming gateway.

        Args:
            connector: Stream connector (memory, Redis, Kafka)
            config: Gateway configuration
            feature_extractor: Optional custom feature extractor function
            rotor: Optional pre-loaded rotor model
        """
        self._connector = connector
        self._config = config or StreamingGatewayConfig()
        self._feature_extractor = feature_extractor
        self._rotor = rotor

        self._metrics = StreamMetrics()
        self._cache: Dict[str, Tuple[Dict, float]] = {}  # hash -> (cert, timestamp)

        self._gateway = None  # CQC_MAS Gateway (lazy loaded)
        self._running = False

    async def start(self) -> None:
        """Start the streaming gateway."""
        await self._connector.connect()
        self._load_models()
        self._running = True

    async def stop(self) -> None:
        """Stop the streaming gateway."""
        self._running = False
        await self._connector.disconnect()

    def _load_models(self) -> None:
        """Load feature extractor and rotor models."""
        # Lazy load gateway
        from yrsn.adapters.cqc_mas.gateway import CQC_MAS_Gateway, GatewayConfig

        gateway_config = GatewayConfig()
        self._gateway = CQC_MAS_Gateway(gateway_config)

        # Load rotor if not provided
        if self._rotor is None:
            try:
                from yrsn.core.decomposition import HybridSimplexRotor
                import torch

                self._rotor = HybridSimplexRotor(embed_dim=64)
                checkpoint = torch.load(
                    self._config.rotor_checkpoint,
                    map_location='cpu'
                )
                self._rotor.load_state_dict(checkpoint)
                self._rotor.eval()
            except Exception as e:
                print(f"Warning: Could not load rotor: {e}")
                self._rotor = None

    async def process_stream(
        self,
        timeout: Optional[float] = None,
    ) -> AsyncIterator[ValidationResult]:
        """
        Process messages from the input stream.

        Args:
            timeout: Optional timeout in seconds

        Yields:
            ValidationResult for each processed message
        """
        if not self._running:
            await self.start()

        async for message in self._connector.consume(
            topic=self._config.input_topic,
            timeout=timeout,
        ):
            result = await self._validate_message(message)
            yield result

            # Route to output topic
            await self._route_result(result)

    async def process_batch(
        self,
        messages: List[StreamMessage],
    ) -> List[ValidationResult]:
        """
        Process a batch of messages.

        Args:
            messages: Messages to process

        Returns:
            List of ValidationResult
        """
        results = []
        for msg in messages:
            result = await self._validate_message(msg)
            results.append(result)
            await self._route_result(result)
        return results

    async def _validate_message(self, message: StreamMessage) -> ValidationResult:
        """Validate a single message."""
        start_time = time.perf_counter()

        try:
            # Check cache
            content_hash = self._compute_hash(message.payload)
            if self._config.enable_caching and content_hash in self._cache:
                cached_cert, cached_time = self._cache[content_hash]
                if time.time() - cached_time < self._config.cache_ttl_seconds:
                    # Use cached result
                    latency_ms = (time.perf_counter() - start_time) * 1000
                    accepted = self._evaluate_certificate(cached_cert)
                    return ValidationResult(
                        message=message,
                        accepted=accepted,
                        certificate=cached_cert,
                        latency_ms=latency_ms,
                    )

            # Extract features
            features = await self._extract_features(message)

            # Compute R/S/N
            certificate = self._compute_rsn(features)

            # Validate against thresholds
            accepted, rejection_reason = self._validate_certificate(
                certificate,
                message,
            )

            # Update cache
            if self._config.enable_caching:
                self._update_cache(content_hash, certificate)

            # Update message
            message.set_certificate(certificate, accepted, rejection_reason)

            latency_ms = (time.perf_counter() - start_time) * 1000

            # Record metrics
            if self._config.enable_metrics:
                self._metrics.record_message(
                    accepted=accepted,
                    latency_ms=latency_ms,
                    r_score=certificate.get('R', 0),
                    s_score=certificate.get('S', 0),
                    n_score=certificate.get('N', 0),
                )

            return ValidationResult(
                message=message,
                accepted=accepted,
                certificate=certificate,
                rejection_reason=rejection_reason,
                latency_ms=latency_ms,
            )

        except Exception as e:
            latency_ms = (time.perf_counter() - start_time) * 1000
            self._metrics.record_error()

            return ValidationResult(
                message=message,
                accepted=False,
                rejection_reason=f"Processing error: {str(e)}",
                latency_ms=latency_ms,
            )

    async def _extract_features(self, message: StreamMessage) -> np.ndarray:
        """Extract features from message content."""
        content = message.get_content()

        # Use custom extractor if provided
        if self._feature_extractor:
            features = self._feature_extractor(content)
            if asyncio.iscoroutine(features):
                features = await features
            return np.array(features)

        # Default: random features (placeholder)
        # In production, use actual feature extractor
        return np.random.randn(64).astype(np.float32)

    def _compute_rsn(self, features: np.ndarray) -> Dict[str, Any]:
        """Compute R/S/N using rotor."""
        if self._rotor is None:
            # Fallback: heuristic R/S/N
            r = 0.5 + 0.1 * np.random.randn()
            s = 0.25 + 0.05 * np.random.randn()
            n = 0.25 + 0.05 * np.random.randn()
            total = r + s + n
            return {
                'R': r / total,
                'S': s / total,
                'N': n / total,
                'alpha': r / total,
            }

        import torch

        with torch.no_grad():
            features_tensor = torch.from_numpy(features).unsqueeze(0).float()
            output = self._rotor(features_tensor)

            return {
                'R': float(output['R'].item()),
                'S': float(output['S'].item()),
                'N': float(output['N'].item()),
                'alpha': float(output.get('alpha', output['R']).item()),
            }

    def _validate_certificate(
        self,
        certificate: Dict[str, Any],
        message: StreamMessage,
    ) -> Tuple[bool, Optional[str]]:
        """Validate certificate against thresholds."""
        if self._gateway is None:
            # Fallback validation
            if certificate['R'] >= 0.55 and certificate['N'] <= 0.25:
                return True, None
            return False, f"R={certificate['R']:.3f}, N={certificate['N']:.3f}"

        # Use CQC_MAS Gateway with modality
        modality = message.headers.get('modality', self._config.modality)
        accepted, reason, _ = self._gateway.validate(
            certificate,
            agent_id=message.headers.get('agent_id', 'stream'),
            modality=modality,
        )

        return accepted, reason.value if not accepted else None

    def _evaluate_certificate(self, certificate: Dict[str, Any]) -> bool:
        """Simple evaluation for cached certificates."""
        return certificate.get('R', 0) >= 0.55 and certificate.get('N', 1) <= 0.25

    async def _route_result(self, result: ValidationResult) -> None:
        """Route result to appropriate output topic."""
        if result.accepted:
            # Send to accepted topic
            if self._config.accepted_topic:
                output_msg = StreamMessage(
                    id=f"out_{result.message.id}",
                    payload=result.message.payload if self._config.enable_passthrough else result.certificate,
                    topic=self._config.accepted_topic,
                    headers={
                        **result.message.headers,
                        'original_id': result.message.id,
                        'R': str(result.certificate.get('R', 0)),
                        'latency_ms': str(result.latency_ms),
                    },
                )
                await self._connector.produce(output_msg)
        else:
            # Send to rejected topic
            if self._config.rejected_topic:
                await self._connector.send_to_dlq(
                    result.message,
                    result.rejection_reason or "Validation failed",
                )

    def _compute_hash(self, payload: Any) -> str:
        """Compute hash of payload for caching."""
        import hashlib
        content = str(payload).encode('utf-8')
        return hashlib.md5(content).hexdigest()

    def _update_cache(self, content_hash: str, certificate: Dict[str, Any]) -> None:
        """Update certificate cache."""
        # Evict if cache is full
        if len(self._cache) >= self._config.cache_max_size:
            # Remove oldest entries
            oldest = sorted(self._cache.items(), key=lambda x: x[1][1])[:100]
            for key, _ in oldest:
                del self._cache[key]

        self._cache[content_hash] = (certificate, time.time())

    @property
    def metrics(self) -> StreamMetrics:
        """Get current metrics."""
        return self._metrics

    def reset_metrics(self) -> None:
        """Reset metrics."""
        self._metrics.reset()

    @property
    def is_running(self) -> bool:
        """Check if gateway is running."""
        return self._running


# =============================================================================
# Convenience Functions
# =============================================================================

async def create_text_streaming_gateway(
    connector: IStreamConnector,
    rotor_path: str = "checkpoints/trained_rotor_universal64.pt",
) -> StreamingGateway:
    """
    Create a streaming gateway for text processing.

    Args:
        connector: Stream connector
        rotor_path: Path to rotor checkpoint

    Returns:
        Configured StreamingGateway
    """
    config = StreamingGatewayConfig(
        modality="text",
        rotor_checkpoint=rotor_path,
    )

    gateway = StreamingGateway(connector, config)
    await gateway.start()

    return gateway


async def run_streaming_benchmark(
    gateway: StreamingGateway,
    n_messages: int = 1000,
    message_size: int = 100,
) -> Dict[str, Any]:
    """
    Run a streaming benchmark.

    Args:
        gateway: Gateway to benchmark
        n_messages: Number of messages to process
        message_size: Size of each message payload

    Returns:
        Benchmark results
    """
    from .memory_stream import create_test_messages

    # Create test messages
    messages = create_test_messages(n_messages)

    # Process all messages
    start_time = time.time()
    results = await gateway.process_batch(messages)
    elapsed = time.time() - start_time

    # Compute statistics
    accepted = sum(1 for r in results if r.accepted)
    latencies = [r.latency_ms for r in results]

    return {
        'n_messages': n_messages,
        'elapsed_seconds': elapsed,
        'throughput': n_messages / elapsed,
        'accepted': accepted,
        'rejected': n_messages - accepted,
        'accept_rate': accepted / n_messages,
        'avg_latency_ms': np.mean(latencies),
        'p50_latency_ms': np.percentile(latencies, 50),
        'p99_latency_ms': np.percentile(latencies, 99),
    }
