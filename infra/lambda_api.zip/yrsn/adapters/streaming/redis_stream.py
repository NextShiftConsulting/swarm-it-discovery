"""
Redis Streams Connector for Production Deployment

Provides Redis Streams integration for:
- Lightweight production deployments
- Local development with persistence
- Horizontal scaling via consumer groups

Requirements:
    pip install redis

Usage:
    >>> from yrsn.streaming import RedisStreamConnector, StreamConfig
    >>>
    >>> config = StreamConfig(host="localhost", port=6379, topic="yrsn_input")
    >>> connector = RedisStreamConnector(config)
    >>> await connector.connect()
    >>>
    >>> async for msg in connector.consume():
    ...     print(f"Received: {msg.payload}")
"""

import asyncio
import json
import uuid
from typing import AsyncIterator, Dict, List, Optional, Any
import time

from .base import (
    IStreamConnector,
    StreamMessage,
    StreamConfig,
    MessageStatus,
)

# Redis import with graceful fallback
try:
    import redis.asyncio as aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    aioredis = None


class RedisStreamConnector:
    """
    Redis Streams connector for production deployments.

    Features:
    - Consumer groups for horizontal scaling
    - Message persistence
    - Automatic reconnection
    - Dead letter queue support
    - Batch consumption

    Redis Streams Commands Used:
    - XADD: Produce messages
    - XREADGROUP: Consume with consumer groups
    - XACK: Acknowledge processed messages
    - XPENDING: Check pending messages
    """

    def __init__(self, config: Optional[StreamConfig] = None):
        """
        Initialize Redis connector.

        Args:
            config: Stream configuration with Redis connection details
        """
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis package not installed. Install with: pip install redis"
            )

        self._config = config or StreamConfig()
        self._client: Optional[aioredis.Redis] = None
        self._consumer_name = f"consumer_{uuid.uuid4().hex[:8]}"

    async def connect(self) -> None:
        """Connect to Redis and create consumer group."""
        self._client = aioredis.Redis(
            host=self._config.host,
            port=self._config.port,
            password=self._config.password,
            ssl=self._config.ssl,
            decode_responses=True,
        )

        # Create consumer group if it doesn't exist
        try:
            await self._client.xgroup_create(
                name=self._config.topic,
                groupname=self._config.consumer_group,
                id='0',
                mkstream=True,
            )
        except aioredis.ResponseError as e:
            if "BUSYGROUP" not in str(e):
                raise

        # Create DLQ stream if configured
        if self._config.dead_letter_topic:
            try:
                await self._client.xgroup_create(
                    name=self._config.dead_letter_topic,
                    groupname=f"{self._config.consumer_group}_dlq",
                    id='0',
                    mkstream=True,
                )
            except aioredis.ResponseError:
                pass

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._client:
            await self._client.close()
            self._client = None

    async def consume(
        self,
        topic: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> AsyncIterator[StreamMessage]:
        """
        Consume messages from Redis Stream.

        Args:
            topic: Stream name (uses config default if None)
            timeout: Block timeout in seconds (None = 5s default)

        Yields:
            StreamMessage instances
        """
        if not self._client:
            raise RuntimeError("Not connected to Redis")

        topic = topic or self._config.topic
        block_ms = int((timeout or 5.0) * 1000)

        while True:
            try:
                # Read messages from consumer group
                messages = await self._client.xreadgroup(
                    groupname=self._config.consumer_group,
                    consumername=self._consumer_name,
                    streams={topic: '>'},
                    count=self._config.batch_size,
                    block=block_ms,
                )

                if not messages:
                    if timeout:
                        break
                    continue

                # Process each message
                for stream_name, stream_messages in messages:
                    for msg_id, msg_data in stream_messages:
                        yield self._parse_message(msg_id, msg_data, topic)

            except asyncio.CancelledError:
                break
            except Exception as e:
                # Log error and continue
                print(f"Redis consume error: {e}")
                await asyncio.sleep(1)

    async def produce(
        self,
        message: StreamMessage,
        topic: Optional[str] = None,
    ) -> bool:
        """
        Produce a message to Redis Stream.

        Args:
            message: Message to send
            topic: Target stream

        Returns:
            True if successful
        """
        if not self._client:
            return False

        topic = topic or message.topic or self._config.topic

        try:
            # Prepare message data
            data = {
                'payload': self._serialize_payload(message.payload),
                'timestamp': str(message.timestamp),
                'headers': json.dumps(message.headers),
            }

            # Add to stream
            msg_id = await self._client.xadd(
                name=topic,
                fields=data,
                id='*',  # Auto-generate ID
            )

            message.id = msg_id
            return True

        except Exception as e:
            print(f"Redis produce error: {e}")
            return False

    async def acknowledge(self, message: StreamMessage) -> None:
        """Acknowledge a processed message."""
        if not self._client:
            return

        try:
            await self._client.xack(
                message.topic,
                self._config.consumer_group,
                message.id,
            )
        except Exception as e:
            print(f"Redis ack error: {e}")

    async def send_to_dlq(self, message: StreamMessage, reason: str) -> None:
        """Send failed message to dead letter queue."""
        if not self._client or not self._config.dead_letter_topic:
            return

        try:
            dlq_data = {
                'original_id': message.id,
                'original_topic': message.topic,
                'payload': self._serialize_payload(message.payload),
                'reason': reason,
                'timestamp': str(time.time()),
            }

            await self._client.xadd(
                name=self._config.dead_letter_topic,
                fields=dlq_data,
                id='*',
            )

            # Acknowledge original message
            await self.acknowledge(message)

        except Exception as e:
            print(f"Redis DLQ error: {e}")

    @property
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._client is not None

    @property
    def config(self) -> StreamConfig:
        """Get connector configuration."""
        return self._config

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def _parse_message(
        self,
        msg_id: str,
        msg_data: Dict[str, str],
        topic: str,
    ) -> StreamMessage:
        """Parse Redis message into StreamMessage."""
        payload = msg_data.get('payload', '')

        # Try to deserialize JSON payload
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            pass

        headers = {}
        try:
            headers = json.loads(msg_data.get('headers', '{}'))
        except (json.JSONDecodeError, TypeError):
            pass

        timestamp = float(msg_data.get('timestamp', time.time()))

        return StreamMessage(
            id=msg_id,
            payload=payload,
            topic=topic,
            timestamp=timestamp,
            headers=headers,
            status=MessageStatus.PROCESSING,
        )

    def _serialize_payload(self, payload: Any) -> str:
        """Serialize payload to string."""
        if isinstance(payload, bytes):
            return payload.decode('utf-8')
        elif isinstance(payload, (dict, list)):
            return json.dumps(payload)
        return str(payload)

    # =========================================================================
    # Admin Methods
    # =========================================================================

    async def get_stream_info(self, topic: Optional[str] = None) -> Dict[str, Any]:
        """Get stream information."""
        if not self._client:
            return {}

        topic = topic or self._config.topic

        try:
            info = await self._client.xinfo_stream(topic)
            return {
                'length': info.get('length', 0),
                'first_entry': info.get('first-entry'),
                'last_entry': info.get('last-entry'),
                'groups': info.get('groups', 0),
            }
        except Exception:
            return {}

    async def get_pending_count(self, topic: Optional[str] = None) -> int:
        """Get number of pending (unacknowledged) messages."""
        if not self._client:
            return 0

        topic = topic or self._config.topic

        try:
            pending = await self._client.xpending(
                topic,
                self._config.consumer_group,
            )
            return pending.get('pending', 0) if pending else 0
        except Exception:
            return 0

    async def trim_stream(
        self,
        topic: Optional[str] = None,
        maxlen: int = 10000,
    ) -> int:
        """
        Trim stream to maximum length.

        Args:
            topic: Stream name
            maxlen: Maximum entries to keep

        Returns:
            Number of entries removed
        """
        if not self._client:
            return 0

        topic = topic or self._config.topic

        try:
            return await self._client.xtrim(topic, maxlen=maxlen)
        except Exception:
            return 0
