"""
LangGraph Adapter for CQC_MAS Certificate Gating

Provides LangGraph-compatible nodes for certificate-gated multi-agent coordination.

Installation:
    pip install langgraph langchain-core

Usage:
    from yrsn.adapters.langgraph import (
        CertificateGateNode,
        create_certified_agent_graph,
        CertifiedState,
    )

    # Option 1: Use pre-built graph
    graph = create_certified_agent_graph(agent_a, agent_b)
    result = graph.invoke({"task": "Collaborate on feature X"})

    # Option 2: Add certificate node to existing graph
    from langgraph.graph import StateGraph
    graph = StateGraph(CertifiedState)
    graph.add_node("certify", CertificateGateNode())
    graph.add_edge("agent", "certify")

Reference:
    - docs/analysis/CQC_MAS-Reversing-Coordination-Curse.md
    - exp/series_006/README.md
"""

from .certificate_node import (
    CertificateGateNode,
    CertifiedState,
    CertificateResult,
)
from .certified_graph import (
    create_certified_agent_graph,
    create_two_agent_certified_graph,
)

__all__ = [
    "CertificateGateNode",
    "CertifiedState",
    "CertificateResult",
    "create_certified_agent_graph",
    "create_two_agent_certified_graph",
]
