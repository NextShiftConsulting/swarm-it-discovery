"""
Pre-built LangGraph Graphs with CQC_MAS Certificate Gating

Provides ready-to-use graph configurations for common multi-agent patterns.

Usage:
    from yrsn.adapters.langgraph import create_two_agent_certified_graph

    # Create graph with certificate gating
    graph = create_two_agent_certified_graph(
        agent_a_fn=my_agent_a,
        agent_b_fn=my_agent_b,
    )

    # Run coordination
    result = graph.invoke({
        "task": "Implement feature X",
        "sender": "agent_a",
    })
"""

from typing import Callable, Dict, Any, Optional, List
from .certificate_node import CertificateGateNode, CertifiedState, GateDecision


def _mock_agent(name: str) -> Callable:
    """Create a mock agent for testing."""
    def agent_fn(state: CertifiedState) -> CertifiedState:
        task = state.get("task", "unknown task")
        state["message"] = f"Agent {name} working on: {task}. I will implement the feature carefully."
        state["sender"] = name
        return state
    return agent_fn


def _noisy_agent(name: str, noise_level: float = 0.3) -> Callable:
    """Create a noisy agent that sometimes produces low-quality messages."""
    import random

    def agent_fn(state: CertifiedState) -> CertifiedState:
        task = state.get("task", "unknown task")

        if random.random() < noise_level:
            # Noisy message (should be rejected)
            state["message"] = f"Um, maybe {name} could possibly try to do something... not sure really, perhaps {task}?"
        else:
            # Clean message (should pass)
            state["message"] = f"Agent {name} will implement {task}. Creating function with proper error handling."

        state["sender"] = name
        return state
    return agent_fn


def create_certified_agent_graph(
    agent_fn: Callable[[CertifiedState], CertifiedState],
    gate_config: Optional[Dict[str, float]] = None,
) -> Any:
    """
    Create a single-agent graph with certificate gating.

    The graph structure:
        agent -> certify -> [accept/reject]

    Args:
        agent_fn: Function that produces agent output
        gate_config: Optional gateway configuration

    Returns:
        Compiled LangGraph
    """
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        raise ImportError(
            "LangGraph not installed. Run: pip install langgraph langchain-core"
        )

    # Create gate node
    config = gate_config or {}
    gate = CertificateGateNode(**config)

    # Build graph
    graph = StateGraph(CertifiedState)

    graph.add_node("agent", agent_fn)
    graph.add_node("certify", gate)

    # Edges
    graph.set_entry_point("agent")
    graph.add_edge("agent", "certify")

    # Conditional routing based on acceptance
    def route_decision(state: CertifiedState) -> str:
        if state.get("decision") == GateDecision.ACCEPT.value:
            return "accept"
        return "reject"

    graph.add_conditional_edges(
        "certify",
        route_decision,
        {
            "accept": END,
            "reject": END,
        }
    )

    return graph.compile()


def create_two_agent_certified_graph(
    agent_a_fn: Optional[Callable] = None,
    agent_b_fn: Optional[Callable] = None,
    gate_config: Optional[Dict[str, float]] = None,
    max_rounds: int = 3,
) -> Any:
    """
    Create a two-agent coordination graph with certificate gating.

    The graph structure:
        agent_a -> certify_a -> agent_b -> certify_b -> [loop or end]

    Each message between agents must pass through certificate validation.

    Args:
        agent_a_fn: Agent A function (uses mock if None)
        agent_b_fn: Agent B function (uses mock if None)
        gate_config: Gateway configuration
        max_rounds: Maximum coordination rounds

    Returns:
        Compiled LangGraph
    """
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        raise ImportError(
            "LangGraph not installed. Run: pip install langgraph langchain-core"
        )

    # Use mock agents if not provided
    agent_a = agent_a_fn or _mock_agent("A")
    agent_b = agent_b_fn or _mock_agent("B")

    # Create gate nodes
    config = gate_config or {}
    gate_a = CertificateGateNode(**config)
    gate_b = CertificateGateNode(**config)

    # Build graph
    graph = StateGraph(CertifiedState)

    # Add nodes
    graph.add_node("agent_a", agent_a)
    graph.add_node("certify_a", gate_a)
    graph.add_node("agent_b", agent_b)
    graph.add_node("certify_b", gate_b)

    # Track rounds
    def increment_round(state: CertifiedState) -> CertifiedState:
        state["round"] = state.get("round", 0) + 1
        return state

    graph.add_node("track_round", increment_round)

    # Entry point
    graph.set_entry_point("agent_a")

    # Edges: A -> certify_a
    graph.add_edge("agent_a", "certify_a")

    # Conditional: certify_a -> agent_b (if accepted) or retry/end (if rejected)
    def route_a(state: CertifiedState) -> str:
        if state.get("decision") == GateDecision.ACCEPT.value:
            return "to_b"
        return "retry_a"

    graph.add_conditional_edges(
        "certify_a",
        route_a,
        {
            "to_b": "agent_b",
            "retry_a": END,  # For simplicity, end on rejection
        }
    )

    # Edges: B -> certify_b
    graph.add_edge("agent_b", "certify_b")

    # Conditional: certify_b -> track_round -> check if done
    def route_b(state: CertifiedState) -> str:
        if state.get("decision") == GateDecision.ACCEPT.value:
            return "track"
        return "retry_b"

    graph.add_conditional_edges(
        "certify_b",
        route_b,
        {
            "track": "track_round",
            "retry_b": END,
        }
    )

    # After tracking, check if more rounds needed
    def check_rounds(state: CertifiedState) -> str:
        current_round = state.get("round", 0)
        if current_round >= max_rounds:
            return "done"
        return "continue"

    graph.add_conditional_edges(
        "track_round",
        check_rounds,
        {
            "done": END,
            "continue": "agent_a",  # Loop back
        }
    )

    return graph.compile()


def create_noisy_coordination_graph(
    noise_level: float = 0.3,
    gate_config: Optional[Dict[str, float]] = None,
    max_rounds: int = 5,
) -> Any:
    """
    Create a two-agent graph with controllable noise for testing.

    This is useful for demonstrating how certificate gating filters noise.

    Args:
        noise_level: Probability of noisy message (0.0 to 1.0)
        gate_config: Gateway configuration
        max_rounds: Maximum rounds

    Returns:
        Compiled LangGraph
    """
    return create_two_agent_certified_graph(
        agent_a_fn=_noisy_agent("A", noise_level),
        agent_b_fn=_noisy_agent("B", noise_level),
        gate_config=gate_config,
        max_rounds=max_rounds,
    )
