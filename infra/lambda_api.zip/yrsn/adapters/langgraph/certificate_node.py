"""
CQC_MAS Certificate Gate Node for LangGraph

Implements certificate validation as a LangGraph node that can be inserted
into any agent communication graph.

The node:
1. Receives a message from an agent
2. Computes RSN certificate using decomposition
3. Validates through three-stage gateway
4. Either passes or rejects the message

Usage:
    from langgraph.graph import StateGraph
    from yrsn.adapters.langgraph import CertificateGateNode, CertifiedState

    graph = StateGraph(CertifiedState)
    graph.add_node("certify", CertificateGateNode())
"""

from dataclasses import dataclass, field
from typing import TypedDict, Optional, List, Dict, Any, Callable
from enum import Enum
import numpy as np


class GateDecision(str, Enum):
    """Gateway decision outcomes."""
    ACCEPT = "accept"
    REJECT_NOISE = "reject_noise"
    REJECT_RELEVANCE = "reject_relevance"
    REJECT_SUPERFLUOUSNESS = "reject_superfluousness"
    REJECT_GEODESIC = "reject_geodesic"
    REJECT_DRIFT = "reject_drift"
    REJECT_INSTABILITY = "reject_instability"


class CertifiedState(TypedDict, total=False):
    """
    LangGraph state for certificate-gated communication.

    This state flows through the graph, carrying messages and certificates.
    """
    # Input
    sender: str
    receiver: str
    message: str
    task: str

    # Certificate (computed by gate node)
    R: float
    S: float
    N: float
    alpha: float
    sigma: float
    kappa: float

    # Gateway decision
    decision: str
    rejection_reason: Optional[str]
    gate_stage: int

    # Trajectory (for multi-step coordination)
    message_history: List[Dict[str, Any]]
    certificate_history: List[Dict[str, float]]

    # Metrics
    messages_accepted: int
    messages_rejected: int
    rejection_rate: float


@dataclass
class CertificateResult:
    """Result of certificate computation and validation."""
    R: float
    S: float
    N: float
    alpha: float = 0.5
    sigma: float = 0.0
    kappa: float = 0.5
    accepted: bool = True
    rejection_reason: Optional[str] = None
    gate_stage: int = 0  # 0 = passed all, 1-4 = rejected at stage

    def to_dict(self) -> Dict[str, Any]:
        return {
            "R": self.R,
            "S": self.S,
            "N": self.N,
            "alpha": self.alpha,
            "sigma": self.sigma,
            "kappa": self.kappa,
            "accepted": self.accepted,
            "rejection_reason": self.rejection_reason,
            "gate_stage": self.gate_stage,
        }


class CertificateGateNode:
    """
    LangGraph node that gates messages through CQC_MAS certificate validation.

    Implements four-stage gateway:
        Stage 1: Threshold (R, S, N)
        Stage 2: Geodesic jump (trajectory coherence)
        Stage 3: Drift rate (state stability)
        Stage 4: Instability (sigma check)

    Usage:
        gate = CertificateGateNode(tau_R=0.6, tau_S=0.2, tau_N=0.15)
        new_state = gate(state)
    """

    def __init__(
        self,
        # Stage 1: Thresholds
        tau_R: float = 0.55,
        tau_S: float = 0.25,
        tau_N: float = 0.20,
        # Stage 2: Geodesic
        max_geodesic_jump: float = 0.785,  # pi/4
        # Stage 3: Drift
        max_drift_rate: float = 0.1,
        # Stage 4: Instability
        sigma_threshold: float = 0.5,
        # Decomposer (optional - uses mock if not provided)
        decomposer: Optional[Callable[[str], tuple]] = None,
    ):
        self.tau_R = tau_R
        self.tau_S = tau_S
        self.tau_N = tau_N
        self.max_geodesic_jump = max_geodesic_jump
        self.max_drift_rate = max_drift_rate
        self.sigma_threshold = sigma_threshold
        self._decomposer = decomposer

    def _compute_rsn(self, message: str) -> tuple:
        """
        Compute RSN decomposition for a message.

        If a decomposer is provided, uses it. Otherwise uses heuristic.
        """
        if self._decomposer is not None:
            return self._decomposer(message)

        # Heuristic decomposition (for demo/testing)
        # In production, use HybridSimplexRotor with sentence embeddings
        words = message.lower().split()
        word_count = len(words)

        # Heuristic signals
        # R: relevance - task-related words (higher base for clean messages)
        task_keywords = {
            'implement', 'create', 'build', 'fix', 'update', 'add', 'change',
            'feature', 'function', 'code', 'test', 'api', 'database', 'schema',
            'refactor', 'validation', 'error', 'handling', 'async', 'pipeline',
            'documentation', 'integration', 'caching', 'unit', 'endpoint',
            'creating', 'adding', 'building', 'setting', 'proper', 'automated'
        }
        task_word_count = sum(1 for w in words if w in task_keywords)
        R = min(0.85, 0.45 + 0.05 * task_word_count)  # Higher base

        # S: superfluousness - repetition, filler words
        filler_words = {'um', 'uh', 'like', 'basically', 'actually', 'just', 'really', 'very'}
        filler_count = sum(1 for w in words if w in filler_words)
        unique_ratio = len(set(words)) / max(word_count, 1)
        S = min(0.4, 0.08 + 0.04 * filler_count + 0.1 * (1 - unique_ratio))

        # N: noise - uncertainty, hedging (key discriminator)
        noise_words = {'maybe', 'perhaps', 'might', 'could', 'possibly', 'uncertain',
                       'sure', 'think', 'guess', 'know', 'confusing', 'random'}
        noise_phrases = ['not sure', 'i think', "don't know", 'not really', 'not certain']

        noise_count = sum(1 for w in words if w in noise_words)
        phrase_count = sum(1 for phrase in noise_phrases if phrase in message.lower())
        N = min(0.5, 0.05 + 0.06 * noise_count + 0.1 * phrase_count)

        # Normalize to simplex
        total = R + S + N
        if total > 0:
            R, S, N = R / total, S / total, N / total
        else:
            R, S, N = 0.6, 0.2, 0.2

        return R, S, N

    def _compute_sigma(self, R: float, S: float, N: float) -> float:
        """
        Compute instability from RSN.

        Uses RSN proxy method from instability_computation.py
        """
        # Instability increases with:
        # - High N (noise)
        # - Low R (lack of relevance)
        # - Imbalanced simplex
        entropy = -sum(x * np.log(x + 1e-10) for x in [R, S, N])
        max_entropy = -np.log(1/3)  # Maximum for uniform distribution

        sigma = 0.3 * N + 0.3 * (1 - R) + 0.4 * (entropy / max_entropy)
        return min(1.0, max(0.0, sigma))

    def _compute_alpha(self, R: float, S: float, N: float) -> float:
        """Compute quality signal alpha."""
        return R - 0.5 * S - N

    def _compute_kappa(self, message: str, R: float) -> float:
        """Compute compatibility kappa (simplified)."""
        # In production, this would use D* estimation
        word_count = len(message.split())
        efficiency = min(1.0, 50 / max(word_count, 1))  # Shorter = more efficient
        return 0.5 * R + 0.5 * efficiency

    def _stage1_threshold(self, R: float, S: float, N: float) -> tuple:
        """Stage 1: Check R/S/N thresholds."""
        if R < self.tau_R:
            return False, GateDecision.REJECT_RELEVANCE, f"R={R:.3f} < {self.tau_R}"
        if S > self.tau_S:
            return False, GateDecision.REJECT_SUPERFLUOUSNESS, f"S={S:.3f} > {self.tau_S}"
        if N > self.tau_N:
            return False, GateDecision.REJECT_NOISE, f"N={N:.3f} > {self.tau_N}"
        return True, None, None

    def _stage2_geodesic(self, state: CertifiedState, R: float, S: float, N: float) -> tuple:
        """Stage 2: Check geodesic jump from previous certificate."""
        history = state.get("certificate_history", [])
        if not history:
            return True, None, None  # First message, no history

        prev = history[-1]
        # Chordal distance on simplex
        dist = np.sqrt(
            (R - prev["R"])**2 +
            (S - prev["S"])**2 +
            (N - prev["N"])**2
        )

        if dist > self.max_geodesic_jump:
            return False, GateDecision.REJECT_GEODESIC, f"geodesic_jump={dist:.3f} > {self.max_geodesic_jump}"
        return True, None, None

    def _stage3_drift(self, state: CertifiedState, R: float, S: float, N: float) -> tuple:
        """Stage 3: Check drift rate (requires 2+ history points)."""
        history = state.get("certificate_history", [])
        if len(history) < 2:
            return True, None, None  # Need history for drift

        # Compute velocity (change per step)
        prev = history[-1]
        prev_prev = history[-2]

        velocity = np.sqrt(
            ((R - prev["R"]) - (prev["R"] - prev_prev["R"]))**2 +
            ((S - prev["S"]) - (prev["S"] - prev_prev["S"]))**2 +
            ((N - prev["N"]) - (prev["N"] - prev_prev["N"]))**2
        )

        if velocity > self.max_drift_rate:
            return False, GateDecision.REJECT_DRIFT, f"drift_rate={velocity:.3f} > {self.max_drift_rate}"
        return True, None, None

    def _stage4_instability(self, sigma: float) -> tuple:
        """Stage 4: Check instability (sigma)."""
        if sigma > self.sigma_threshold:
            return False, GateDecision.REJECT_INSTABILITY, f"sigma={sigma:.3f} > {self.sigma_threshold}"
        return True, None, None

    def __call__(self, state: CertifiedState) -> CertifiedState:
        """
        Process state through certificate gateway.

        This is the main LangGraph node function.
        """
        message = state.get("message", "")

        # Compute RSN
        R, S, N = self._compute_rsn(message)
        sigma = self._compute_sigma(R, S, N)
        alpha = self._compute_alpha(R, S, N)
        kappa = self._compute_kappa(message, R)

        # Update state with certificate
        state["R"] = R
        state["S"] = S
        state["N"] = N
        state["alpha"] = alpha
        state["sigma"] = sigma
        state["kappa"] = kappa

        # Stage 1: Threshold
        passed, decision, reason = self._stage1_threshold(R, S, N)
        if not passed:
            state["decision"] = decision.value
            state["rejection_reason"] = reason
            state["gate_stage"] = 1
            state["messages_rejected"] = state.get("messages_rejected", 0) + 1
            return state

        # Stage 2: Geodesic
        passed, decision, reason = self._stage2_geodesic(state, R, S, N)
        if not passed:
            state["decision"] = decision.value
            state["rejection_reason"] = reason
            state["gate_stage"] = 2
            state["messages_rejected"] = state.get("messages_rejected", 0) + 1
            return state

        # Stage 3: Drift
        passed, decision, reason = self._stage3_drift(state, R, S, N)
        if not passed:
            state["decision"] = decision.value
            state["rejection_reason"] = reason
            state["gate_stage"] = 3
            state["messages_rejected"] = state.get("messages_rejected", 0) + 1
            return state

        # Stage 4: Instability
        passed, decision, reason = self._stage4_instability(sigma)
        if not passed:
            state["decision"] = decision.value
            state["rejection_reason"] = reason
            state["gate_stage"] = 4
            state["messages_rejected"] = state.get("messages_rejected", 0) + 1
            return state

        # All stages passed
        state["decision"] = GateDecision.ACCEPT.value
        state["rejection_reason"] = None
        state["gate_stage"] = 0
        state["messages_accepted"] = state.get("messages_accepted", 0) + 1

        # Update history
        history = state.get("certificate_history", [])
        history.append({"R": R, "S": S, "N": N, "sigma": sigma})
        state["certificate_history"] = history

        # Update rejection rate
        total = state.get("messages_accepted", 0) + state.get("messages_rejected", 0)
        if total > 0:
            state["rejection_rate"] = state.get("messages_rejected", 0) / total

        return state
