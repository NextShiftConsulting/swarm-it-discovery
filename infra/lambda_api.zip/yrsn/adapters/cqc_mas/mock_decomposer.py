"""
Mock Text Decomposer for Multi-Agent Testing

Provides simple heuristic R/S/N decomposition for text messages during
multi-agent coordination experiments. NOT production quality - for testing only.

Heuristic Rules:
- R (relevance): Based on task keywords present (boosted to pass tau_R=0.60)
- S (spurious): Based on text length (kept below tau_S=0.20)
- N (noise): Low baseline + small random variation (kept below tau_N=0.15)

Reference: exp/series_006/WIRING_STATUS_SUMMARY.md § Step 3
"""

import re
from typing import Tuple
import numpy as np


class MockTextDecomposer:
    """
    Mock decomposer: text → (R, S, N) for multi-agent testing.

    Usage:
        >>> decomposer = MockTextDecomposer(
        ...     task_keywords=['task', 'complete', 'done']
        ... )
        >>> R, S, N = decomposer.decompose("Task complete!")
        >>> print(f"R={R:.2f}, S={S:.2f}, N={N:.2f}")
        R=0.65, S=0.25, N=0.10

    WARNING: This is a MOCK for testing. Do NOT use in production.
    For production, use TrainedRSNProjection or FrequencyBasedRSN.
    """

    def __init__(
        self,
        task_keywords: list = None,
        base_noise: float = 0.06,
        noise_std: float = 0.02
    ):
        """
        Initialize mock decomposer.

        Args:
            task_keywords: Keywords indicating relevant content
            base_noise: Baseline noise level
            noise_std: Standard deviation for noise variation
        """
        self.task_keywords = task_keywords or [
            'task', 'complete', 'done', 'success', 'result',
            'action', 'execute', 'implement', 'solve'
        ]
        self.base_noise = base_noise
        self.noise_std = noise_std

    def decompose(self, text: str) -> Tuple[float, float, float]:
        """
        Decompose text into (R, S, N).

        Heuristic:
        - R increases with task keyword matches
        - S increases with text length (more filler)
        - N is base noise + random variation

        Returns:
            (R, S, N) tuple where R + S + N ≈ 1.0
        """
        if not text or not text.strip():
            # Empty text = pure noise
            return 0.0, 0.0, 1.0

        text_lower = text.lower()

        # R: Relevance from keyword matching
        keyword_matches = sum(
            1 for kw in self.task_keywords
            if re.search(r'\b' + re.escape(kw) + r'\b', text_lower)
        )
        # Boost R to pass gateway threshold (tau_R = 0.60)
        R_raw = min(0.9, 0.5 + 0.1 * keyword_matches)

        # S: Spurious from text length (longer = more filler)
        word_count = len(text.split())
        S_raw = min(0.5, 0.1 + 0.02 * (word_count - 5) if word_count > 5 else 0.1)

        # N: Noise (fixed + random variation, capped to prevent gateway rejection)
        N_raw = max(0.03, min(0.12, np.random.normal(self.base_noise, self.noise_std)))

        # Normalize to sum to 1
        total = R_raw + S_raw + N_raw
        R = R_raw / total
        S = S_raw / total
        N = N_raw / total

        # Enforce simplex constraint (should already be satisfied, but ensure)
        assert abs(R + S + N - 1.0) < 1e-6, f"Simplex violation: R+S+N={R+S+N}"

        return R, S, N


# Convenience function
def mock_decompose_text(text: str, task_keywords: list = None) -> Tuple[float, float, float]:
    """
    Quick decomposition without creating decomposer instance.

    Args:
        text: Input text to decompose
        task_keywords: Optional task-specific keywords

    Returns:
        (R, S, N) tuple

    Example:
        >>> R, S, N = mock_decompose_text("Task complete successfully!")
        >>> print(f"Quality: {R/(R+S+N):.2f}")
    """
    decomposer = MockTextDecomposer(task_keywords=task_keywords)
    return decomposer.decompose(text)
