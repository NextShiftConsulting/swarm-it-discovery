"""
CQC_MAS (Context Quality Certificate - Multi-Agent Systems) Adapters

This module provides certificate-gated multi-agent coordination infrastructure:
- Gateway: Three-stage validation (threshold → geodesic → drift)
- Mock decomposers: Text → (R, S, N) for testing
- Agent wrappers: Certificate generation for agent outputs

Reference:
    - exp/series_006/WIRING_WALKTHROUGH.md
    - exp/series_006/T4_COORDINATE_CLARIFICATION.md
"""

from .gateway import CQC_MAS_Gateway, GatewayConfig, GatewayStage, RejectionReason
from .mock_decomposer import MockTextDecomposer

__all__ = [
    'CQC_MAS_Gateway',
    'GatewayConfig',
    'GatewayStage',
    'RejectionReason',
    'MockTextDecomposer',
]
