"""
🔓 OPEN ADAPTER - CQC_MAS Gateway

Multi-agent certificate validation gateway.
Implements ICQCMASPort for certificate-gated coordination.

What you CAN do:
✅ Use this adapter as-is
✅ Modify validation logic for your needs
✅ Write your own gateway following ICQCMASPort
✅ Share your custom gateway with others

Simple explanation:
    This gateway validates quality certificates from agents:
    - Stage 1: Check R/S/N thresholds
    - Stage 2: Check T⁴ geodesic distance
    - Stage 3: Check drift velocity

    Like a bouncer at a club - checks if agents meet quality standards
    before allowing them to communicate with each other.

---

CQC_MAS Three-Stage Gateway

Implements certificate validation cascade from exp/series_006/WIRING_WALKTHROUGH.md:
- Stage 1 (Threshold Gate): R/S/N thresholds
- Stage 2 (Geodesic Jump Gate): T⁴ chordal distance
- Stage 3 (Drift Rate Gate): Angular velocity

Reference:
    - exp/series_006/expS6_001_cer_two_agent_doe.md
    - exp/series_006/expS6_100_gateway_effectiveness_doe.md
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Tuple, Optional
import numpy as np


# =============================================================================
# MODALITY-AWARE THRESHOLDS (Universal Rotor v2)
# =============================================================================

@dataclass
class ModalityThresholds:
    """
    Per-modality R/S/N thresholds.

    Different modalities have different quality characteristics:
    - Vision: Higher R threshold (image quality is binary)
    - Text: Lower R threshold (text quality is gradual)
    - Audio: Medium thresholds (depends on SNR)

    Reference: docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md
    """
    tau_R: float = 0.55  # Minimum relevance
    tau_S: float = 0.25  # Maximum spurious
    tau_N: float = 0.20  # Maximum noise


# Default thresholds per modality (can be customized)
DEFAULT_MODALITY_THRESHOLDS: Dict[str, ModalityThresholds] = {
    'vision': ModalityThresholds(tau_R=0.60, tau_S=0.20, tau_N=0.15),
    'text': ModalityThresholds(tau_R=0.45, tau_S=0.30, tau_N=0.25),  # Relaxed for truncated embeddings
    'audio': ModalityThresholds(tau_R=0.50, tau_S=0.25, tau_N=0.25),
    'multimodal': ModalityThresholds(tau_R=0.55, tau_S=0.25, tau_N=0.20),
    'default': ModalityThresholds(tau_R=0.55, tau_S=0.25, tau_N=0.20),
}


class GatewayStage(Enum):
    """Three validation stages."""
    THRESHOLD = 1      # Stage 1: R/S/N thresholds
    GEODESIC_JUMP = 2  # Stage 2: T⁴ distance
    DRIFT_RATE = 3     # Stage 3: Angular velocity


class RejectionReason(Enum):
    """Rejection reasons at each stage."""
    # Stage 1: Threshold failures
    UNRESPONSIVE = "R < tau_R (unresponsive)"
    REPETITION = "S > tau_S (repetitive)"
    HALLUCINATION = "N > tau_N (hallucination)"

    # Stage 2: Geodesic failures
    GEODESIC_JUMP = "delta > max_jump (geodesic jump)"

    # Stage 3: Drift failures
    EXCESSIVE_DRIFT = "velocity > max_velocity (drift rate)"

    # Success
    ACCEPTED = "passed all gates"


@dataclass
class GatewayConfig:
    """
    Configuration for three-stage gateway.

    Default thresholds from WIRING_WALKTHROUGH.md:
    - tau_R = 0.60 (minimum relevance)
    - tau_S = 0.20 (maximum spurious)
    - tau_N = 0.15 (maximum noise)
    - max_geodesic_jump = π/4 (45° on T⁴ manifold)
    - max_angular_velocity = 0.1 rad/s

    Universal Rotor v2 Enhancement:
    - Per-modality thresholds via modality_thresholds dict
    - Fallback to default thresholds if modality not specified
    """
    # Stage enables
    stage1_enabled: bool = True
    stage2_enabled: bool = True
    stage3_enabled: bool = True

    # Stage 1 thresholds (default, used when modality not specified)
    tau_R: float = 0.60
    tau_S: float = 0.20
    tau_N: float = 0.15

    # Per-modality thresholds (Universal Rotor v2)
    modality_thresholds: Dict[str, ModalityThresholds] = field(
        default_factory=lambda: DEFAULT_MODALITY_THRESHOLDS.copy()
    )

    # Stage 2 threshold (π/4 radians)
    max_geodesic_jump: float = 0.785398  # π/4

    # Stage 3 threshold
    max_angular_velocity: float = 0.1  # rad/s

    def get_thresholds(self, modality: Optional[str] = None) -> ModalityThresholds:
        """Get thresholds for a specific modality."""
        if modality and modality in self.modality_thresholds:
            return self.modality_thresholds[modality]
        elif 'default' in self.modality_thresholds:
            return self.modality_thresholds['default']
        else:
            # Fallback to instance-level thresholds
            return ModalityThresholds(
                tau_R=self.tau_R,
                tau_S=self.tau_S,
                tau_N=self.tau_N
            )


class CQC_MAS_Gateway:
    """
    Three-stage certificate validation gateway.

    Usage:
        >>> config = GatewayConfig()
        >>> gateway = CQC_MAS_Gateway(config)
        >>>
        >>> # Agent A sends certificate
        >>> cert_a = {'R': 0.7, 'S': 0.2, 'N': 0.1, 'simplex_theta': 240, ...}
        >>> accepted, reason, stage = gateway.validate(cert_a, 'agent_A')
        >>> print(accepted, reason)
        True RejectionReason.ACCEPTED

    Reference: exp/series_006/WIRING_WALKTHROUGH.md § Step 5
    """

    def __init__(self, config: GatewayConfig):
        self.config = config
        self.previous_state: Dict[str, Dict] = {}  # agent_id → previous cert

    def validate(
        self,
        cert: Dict,
        consumer_id: str,
        modality: Optional[str] = None
    ) -> Tuple[bool, RejectionReason, GatewayStage]:
        """
        Perform ordered validation of Context Quality Certificate through three-stage cascade.

        Patent Compliance: Uses canonical terminology per Legal-vocabulary_20260127.md
        - "Consumer" not "agent" (canonical per Method A1(a), System B1)
        - "Ordered validation" per Method A1(e), System B2

        Args:
            cert: Context Quality Certificate dict with R, S, N, simplex_theta, phi_simplex, etc.
            consumer_id: Identifier of the consumer (canonical: not agent_id)
            modality: Optional modality for threshold selection ('text', 'vision', 'audio')
                      If not provided, uses cert.get('modality') or default thresholds.

        Returns:
            (enforcement_approved, suppression_reason, validation_stage):
                enforcement_approved: True if pre-task semantic enforcement approves
                suppression_reason: Reason for suppression if not approved
                validation_stage: Stage where decision was made

        Example:
            >>> enforcement_approved, reason, stage = gateway.validate(cert, 'consumer_A', modality='text')
            >>> if not enforcement_approved:
            ...     print(f"Execution suppressed at {stage.name}: {reason.value}")
        """
        # Resolve modality: parameter > cert field > default
        effective_modality = modality or cert.get('modality')

        # Stage 1: Threshold Gate (modality-aware)
        if self.config.stage1_enabled:
            passed, reason = self._stage1_threshold(cert, effective_modality)
            if not passed:
                return False, reason, GatewayStage.THRESHOLD

        # Stage 2: Geodesic Jump Gate (requires previous state)
        if self.config.stage2_enabled and consumer_id in self.previous_state:
            passed, reason = self._stage2_geodesic_jump(cert, consumer_id)
            if not passed:
                return False, reason, GatewayStage.GEODESIC_JUMP

        # Stage 3: Drift Rate Gate (requires previous state)
        if self.config.stage3_enabled and consumer_id in self.previous_state:
            passed, reason = self._stage3_drift_rate(cert, consumer_id)
            if not passed:
                return False, reason, GatewayStage.DRIFT_RATE

        # Store current state for next validation
        self.previous_state[consumer_id] = cert

        return True, RejectionReason.ACCEPTED, GatewayStage.DRIFT_RATE

    def _stage1_threshold(
        self,
        cert: Dict,
        modality: Optional[str] = None
    ) -> Tuple[bool, RejectionReason]:
        """
        Stage 1: Check R/S/N against modality-specific thresholds.

        Args:
            cert: Certificate dict with R, S, N
            modality: Optional modality for threshold selection

        Returns:
            (passed, reason): Validation result
        """
        R, S, N = cert['R'], cert['S'], cert['N']

        # Get modality-specific thresholds
        thresholds = self.config.get_thresholds(modality)

        if R < thresholds.tau_R:
            return False, RejectionReason.UNRESPONSIVE

        if S > thresholds.tau_S:
            return False, RejectionReason.REPETITION

        if N > thresholds.tau_N:
            return False, RejectionReason.HALLUCINATION

        return True, RejectionReason.ACCEPTED

    def _stage2_geodesic_jump(
        self,
        cert: Dict,
        consumer_id: str
    ) -> Tuple[bool, RejectionReason]:
        """Stage 2: Check T⁴ geodesic distance from previous state."""
        prev_cert = self.previous_state[consumer_id]

        # Extract T⁴ coordinates
        t4_curr = {
            'simplex_theta': cert['simplex_theta'],
            'phi_simplex': cert['phi_simplex'],
            'alpha': cert['alpha_t4'],
            'omega': cert['omega_t4']
        }

        t4_prev = {
            'simplex_theta': prev_cert['simplex_theta'],
            'phi_simplex': prev_cert['phi_simplex'],
            'alpha': prev_cert['alpha_t4'],
            'omega': prev_cert['omega_t4']
        }

        # Compute T⁴ chordal distance
        from yrsn.core.decomposition.geometric_utils import t4_chordal_distance
        delta = t4_chordal_distance(t4_curr, t4_prev)

        if delta > self.config.max_geodesic_jump:
            return False, RejectionReason.GEODESIC_JUMP

        return True, RejectionReason.ACCEPTED

    def _stage3_drift_rate(
        self,
        cert: Dict,
        consumer_id: str
    ) -> Tuple[bool, RejectionReason]:
        """Stage 3: Check angular velocity (drift rate)."""
        prev_cert = self.previous_state[consumer_id]

        # Compute time delta
        dt = cert['timestamp'] - prev_cert['timestamp']
        if dt <= 0:
            # Time went backwards or no change - reject
            return False, RejectionReason.EXCESSIVE_DRIFT

        # Recompute geodesic distance (same as Stage 2)
        t4_curr = {
            'simplex_theta': cert['simplex_theta'],
            'phi_simplex': cert['phi_simplex'],
            'alpha': cert['alpha_t4'],
            'omega': cert['omega_t4']
        }

        t4_prev = {
            'simplex_theta': prev_cert['simplex_theta'],
            'phi_simplex': prev_cert['phi_simplex'],
            'alpha': prev_cert['alpha_t4'],
            'omega': prev_cert['omega_t4']
        }

        from yrsn.core.decomposition.geometric_utils import t4_chordal_distance
        delta = t4_chordal_distance(t4_curr, t4_prev)

        # Compute angular velocity
        angular_velocity = delta / dt  # radians per second

        if angular_velocity > self.config.max_angular_velocity:
            return False, RejectionReason.EXCESSIVE_DRIFT

        return True, RejectionReason.ACCEPTED

    def reset(self, agent_id: Optional[str] = None):
        """Reset gateway state (clear previous certificates)."""
        if agent_id is None:
            self.previous_state.clear()
        elif agent_id in self.previous_state:
            del self.previous_state[agent_id]
