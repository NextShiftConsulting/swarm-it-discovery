"""
dual_steering_kappa_h.py
========================

Bridge between dual-steering CAA vectors (Kiho Park's Linear Representation Hypothesis)
and RSCT κ_H (encoding-solver compatibility) estimation.

This adapter provides a clean interface for computing geodesic fidelity from
Contrastive Activation Addition (CAA) steering vectors, mapping KL divergence
to κ_H ∈ [0,1] for RSCT gatekeeper decisions.

Theoretical Foundation:
----------------------
- CAA vectors (Rimsky et al., 2024): Steering vectors computed from activation
  differences between positive/negative behavior pairs
- Linear Representation Hypothesis (Park et al., 2023): High-level concepts
  represented linearly as directions in representation space
- RSCT κ_H: Geodesic fidelity measuring encoding-solver compatibility

Key Insight:
-----------
When CAA steering preserves model behavior (low KL divergence), it indicates
high encoding-solver compatibility (high κ_H). This bridges interpretability
research (CAA) with production quality control (RSCT).

Architecture:
------------
    ┌────────────────────────────────────────────────────────────┐
    │  External Research Repos (User-Provided)                   │
    │  - github.com/nrimsky/CAA (Rimsky et al., 2024)            │
    │  - github.com/KihoPark/linear_rep_geometry (Park, 2023)    │
    └────────────────┬───────────────────────────────────────────┘
                     │ User implements compute_caa_vectors()
                     v
    ┌────────────────────────────────────────────────────────────┐
    │  dual_steering_kappa_h.py (THIS ADAPTER)                   │
    │  ┌────────────────────────────────────────────────────┐    │
    │  │ CAAVector: Type-safe steering vector interface     │    │
    │  │ compute_kl_divergence(): Measure behavior change   │    │
    │  │ geodesic_fidelity(): KL → κ_H mapping             │    │
    │  │ estimate_kappa_H_from_caa(): Full pipeline         │    │
    │  └────────────────────────────────────────────────────┘    │
    └────────────────┬───────────────────────────────────────────┘
                     │ κ_H ∈ [0,1]
                     v
    ┌────────────────────────────────────────────────────────────┐
    │  RSCT Gatekeeper (Production)                              │
    │  - exp/series_006/expS6_204_rsct_multiagent_gatekeeper.py  │
    │  - RSCTCertificate(kappa_gate=κ_H, kappa_T=κ_H, ...)      │
    │  - RSCTGatekeeper.validate_handoff() → EXECUTE/RE_ENCODE   │
    └────────────────────────────────────────────────────────────┘

Usage Pattern:
-------------
1. User computes CAA vectors using external repo (Rimsky/Park)
2. Wrap vectors in CAAVector type for safety
3. Call estimate_kappa_H_from_caa() to get GeodesicFidelity
4. Inject κ_H into RSCTCertificate
5. RSCTGatekeeper makes control decision (EXECUTE/RE_ENCODE/REJECT)

This creates a clean separation:
- External repos: CAA computation (research code)
- This adapter: Type-safe bridge with validation
- RSCT gatekeeper: Production quality control

References:
----------
- Rimsky et al. (2024): "Steering Llama 2 via Contrastive Activation Addition"
  https://arxiv.org/abs/2312.06681
- Park et al. (2023): "The Linear Representation Hypothesis and the Geometry of LLMs"
  https://arxiv.org/abs/2311.03658
- RSCT Theory: docs/primary/RSCT_YRSN_canonical_reference_v2.tex

Author: Rudolph A. Martin, Next Shift Consulting LLC
License: Proprietary
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

import torch
import torch.nn.functional as F


# =============================================================================
# TYPE DEFINITIONS
# =============================================================================

@dataclass(frozen=True)
class CAAVector:
    """
    Contrastive Activation Addition steering vector.

    Computed as average difference in residual stream activations between
    positive and negative examples of a behavior.

    Attributes:
        vector: Steering direction in activation space [d_model]
        layer_idx: Transformer layer index where vector is applied
        magnitude: L2 norm of steering vector (indicates strength)
        behavior_label: Human-readable label (e.g., "factual", "concise")
        positive_samples: Number of positive examples used
        negative_samples: Number of negative examples used

    Example:
        >>> caa = CAAVector(
        ...     vector=torch.randn(768),
        ...     layer_idx=15,
        ...     magnitude=2.3,
        ...     behavior_label="factual_vs_hallucination",
        ...     positive_samples=100,
        ...     negative_samples=100,
        ... )
        >>> print(f"Steering vector at layer {caa.layer_idx}: ||v||={caa.magnitude:.2f}")
    """
    vector: torch.Tensor  # Shape: [d_model]
    layer_idx: int  # Which transformer layer (0-indexed)
    magnitude: float  # L2 norm
    behavior_label: str  # e.g., "factual_vs_hallucination"
    positive_samples: int  # N+ in paper
    negative_samples: int  # N- in paper

    def __post_init__(self):
        """Validate CAA vector constraints."""
        if self.vector.ndim != 1:
            raise ValueError(f"CAA vector must be 1D, got shape {self.vector.shape}")
        if self.layer_idx < 0:
            raise ValueError(f"Layer index must be non-negative, got {self.layer_idx}")
        if self.magnitude < 0:
            raise ValueError(f"Magnitude must be non-negative, got {self.magnitude}")
        if self.positive_samples <= 0 or self.negative_samples <= 0:
            raise ValueError(
                f"Sample counts must be positive, got pos={self.positive_samples}, "
                f"neg={self.negative_samples}"
            )


@dataclass(frozen=True)
class GeodesicFidelity:
    """
    Geodesic fidelity measurement for RSCT κ_H estimation.

    Measures how well a steering intervention preserves model behavior on
    a probability manifold. Low KL divergence → high fidelity → high κ_H.

    Attributes:
        kappa_H: Encoding-solver compatibility [0,1]
        kl_divergence: Average KL(P_steered || P_baseline) in nats
        behavior_label: Which CAA behavior was measured
        layer_idx: Which layer was perturbed
        num_samples: Number of test prompts used
        confidence_interval: 95% CI for κ_H estimate

    Example:
        >>> fidelity = GeodesicFidelity(
        ...     kappa_H=0.87,
        ...     kl_divergence=0.14,
        ...     behavior_label="factual_vs_hallucination",
        ...     layer_idx=15,
        ...     num_samples=50,
        ...     confidence_interval=(0.83, 0.91)
        ... )
        >>> print(f"κ_H = {fidelity.kappa_H:.3f} (95% CI: {fidelity.confidence_interval})")
    """
    kappa_H: float  # [0, 1]
    kl_divergence: float  # nats (average over samples)
    behavior_label: str  # Matches CAAVector.behavior_label
    layer_idx: int  # Matches CAAVector.layer_idx
    num_samples: int  # Number of test prompts
    confidence_interval: Tuple[float, float]  # (lower, upper) for κ_H

    def __post_init__(self):
        """Validate geodesic fidelity constraints."""
        if not (0.0 <= self.kappa_H <= 1.0):
            raise ValueError(f"κ_H must be in [0,1], got {self.kappa_H}")
        if self.kl_divergence < 0:
            raise ValueError(f"KL divergence must be non-negative, got {self.kl_divergence}")
        if self.num_samples <= 0:
            raise ValueError(f"Number of samples must be positive, got {self.num_samples}")
        ci_low, ci_high = self.confidence_interval
        if not (0.0 <= ci_low <= ci_high <= 1.0):
            raise ValueError(
                f"Confidence interval must satisfy 0 ≤ low ≤ high ≤ 1, "
                f"got ({ci_low}, {ci_high})"
            )


# =============================================================================
# CORE COMPUTATION
# =============================================================================

def geodesic_fidelity(
    kl_divergence: float,
    scale: float = 1.0,
    method: str = "exponential",
) -> float:
    """
    Convert KL divergence to κ_H ∈ [0,1] using geodesic distance mapping.

    Theory:
    ------
    On a probability manifold with Fisher information metric, geodesic distance
    is approximated by √(2·KL). For RSCT, we map this to compatibility:

    κ_H = exp(-scale · KL)  (exponential decay, default)
    κ_H = 1 / (1 + scale · KL)  (rational decay, more robust to outliers)

    Intuition:
    ---------
    - KL ≈ 0: Steering preserves behavior → high compatibility (κ_H → 1)
    - KL >> 1: Steering destroys behavior → low compatibility (κ_H → 0)

    Args:
        kl_divergence: KL(P_steered || P_baseline) in nats
        scale: Sensitivity parameter (higher = faster decay)
        method: Mapping function ("exponential" or "rational")

    Returns:
        κ_H ∈ [0, 1]: Encoding-solver compatibility

    Example:
        >>> # High fidelity (small perturbation)
        >>> geodesic_fidelity(kl_divergence=0.1)
        0.905

        >>> # Low fidelity (large perturbation)
        >>> geodesic_fidelity(kl_divergence=5.0)
        0.007

        >>> # Robust to outliers
        >>> geodesic_fidelity(kl_divergence=100.0, method="rational")
        0.010

    Notes:
    -----
    - Default scale=1.0 gives κ_H=0.37 at KL=1.0 (exponential)
    - For rational method, κ_H=0.5 at KL=1.0
    - Use exponential for smooth decay, rational for heavy-tailed distributions
    """
    if kl_divergence < 0:
        raise ValueError(f"KL divergence must be non-negative, got {kl_divergence}")
    if scale <= 0:
        raise ValueError(f"Scale must be positive, got {scale}")

    if method == "exponential":
        # κ_H = exp(-λ·KL)
        kappa_H = torch.exp(-scale * torch.tensor(kl_divergence)).item()
    elif method == "rational":
        # κ_H = 1 / (1 + λ·KL)
        kappa_H = 1.0 / (1.0 + scale * kl_divergence)
    else:
        raise ValueError(f"Unknown method: {method}. Use 'exponential' or 'rational'")

    return float(kappa_H)


def compute_kl_divergence(
    logits_baseline: torch.Tensor,
    logits_steered: torch.Tensor,
    temperature: float = 1.0,
) -> float:
    """
    Compute KL divergence between baseline and steered model distributions.

    KL(P_steered || P_baseline) = Σ P_steered(x) log[P_steered(x) / P_baseline(x)]

    Args:
        logits_baseline: Unsteered model logits [batch, seq_len, vocab_size]
        logits_steered: Steered model logits [batch, seq_len, vocab_size]
        temperature: Softmax temperature (default 1.0)

    Returns:
        Average KL divergence in nats (averaged over batch and sequence)

    Example:
        >>> baseline = torch.randn(2, 10, 50000)  # batch=2, seq=10, vocab=50k
        >>> steered = baseline + 0.1 * torch.randn_like(baseline)  # Small perturbation
        >>> kl = compute_kl_divergence(baseline, steered)
        >>> print(f"KL divergence: {kl:.4f} nats")

    Notes:
    -----
    - Returns average over all positions (typical for language modeling)
    - Temperature scaling: Use T > 1 for smoother distributions
    - Clamps probabilities to avoid log(0)
    """
    if logits_baseline.shape != logits_steered.shape:
        raise ValueError(
            f"Shape mismatch: baseline {logits_baseline.shape} vs "
            f"steered {logits_steered.shape}"
        )

    # Apply temperature scaling
    logits_baseline = logits_baseline / temperature
    logits_steered = logits_steered / temperature

    # Convert to probabilities
    log_probs_baseline = F.log_softmax(logits_baseline, dim=-1)
    log_probs_steered = F.log_softmax(logits_steered, dim=-1)

    # KL(P_steered || P_baseline) = Σ P_steered log(P_steered / P_baseline)
    kl = F.kl_div(
        log_probs_baseline,  # Target (what we measure against)
        log_probs_steered,   # Input (what was modified)
        reduction='batchmean',
        log_target=True,
    )

    return kl.item()


# =============================================================================
# PLACEHOLDER: USER-PROVIDED CAA COMPUTATION
# =============================================================================

def compute_caa_vectors(
    model: torch.nn.Module,
    positive_prompts: List[str],
    negative_prompts: List[str],
    layer_indices: List[int],
    tokenizer: Optional[Callable] = None,
) -> List[CAAVector]:
    """
    Compute CAA steering vectors from contrastive prompt pairs.

    **THIS IS A PLACEHOLDER INTERFACE.**

    Users should plug in their own implementation from:
    - https://github.com/nrimsky/CAA (official implementation)
    - https://github.com/KihoPark/linear_rep_geometry (theory)
    - Custom implementation following Rimsky et al. (2024)

    Algorithm (from paper):
    ----------------------
    1. For each layer L in layer_indices:
       a. Run positive prompts, collect activations A+ at layer L
       b. Run negative prompts, collect activations A- at layer L
       c. Compute steering vector: v_L = mean(A+) - mean(A-)
    2. Return list of CAAVector objects

    Args:
        model: PyTorch model (e.g., LlamaForCausalLM)
        positive_prompts: Desired behavior examples (e.g., factual responses)
        negative_prompts: Undesired behavior examples (e.g., hallucinations)
        layer_indices: Which transformer layers to compute vectors for
        tokenizer: Optional tokenizer (if None, user must preprocess)

    Returns:
        List of CAAVector objects, one per layer

    Example Integration:
    -------------------
    ```python
    # Option 1: Use official CAA repo
    from caa import CAA  # pip install contrastive-activation-addition
    caa_model = CAA(model, tokenizer)
    vectors = caa_model.generate_vectors(positive_prompts, negative_prompts, layers)

    # Convert to YRSN format
    yrsn_vectors = []
    for layer_idx, vec in zip(layers, vectors):
        yrsn_vectors.append(CAAVector(
            vector=vec,
            layer_idx=layer_idx,
            magnitude=torch.norm(vec).item(),
            behavior_label="factual_vs_hallucination",
            positive_samples=len(positive_prompts),
            negative_samples=len(negative_prompts),
        ))

    # Option 2: Custom implementation
    def my_compute_caa_vectors(model, pos_prompts, neg_prompts, layers, tokenizer):
        # Your implementation here
        pass

    vectors = my_compute_caa_vectors(model, pos, neg, layers, tok)
    ```

    Raises:
        NotImplementedError: Always (users must provide their own implementation)
    """
    raise NotImplementedError(
        "Users must provide their own CAA vector computation.\n"
        "\n"
        "See official implementations:\n"
        "- https://github.com/nrimsky/CAA (Rimsky et al., 2024)\n"
        "- https://github.com/KihoPark/linear_rep_geometry (Park et al., 2023)\n"
        "\n"
        "This function defines the INTERFACE. Replace with your implementation:\n"
        "1. Hook into model layers\n"
        "2. Collect activations for positive/negative prompts\n"
        "3. Compute mean difference at each layer\n"
        "4. Return List[CAAVector]\n"
    )


# =============================================================================
# RSCT GATEKEEPER INTEGRATION
# =============================================================================

def estimate_kappa_H_from_caa(
    model: torch.nn.Module,
    caa_vector: CAAVector,
    test_prompts: List[str],
    tokenizer: Callable,
    steering_coefficient: float = 1.0,
    temperature: float = 1.0,
    scale: float = 1.0,
    method: str = "exponential",
) -> GeodesicFidelity:
    """
    Estimate κ_H from CAA steering vector using geodesic fidelity.

    Pipeline:
    --------
    1. Generate baseline predictions (no steering)
    2. Generate steered predictions (with CAA vector applied)
    3. Compute KL divergence between distributions
    4. Map KL → κ_H via geodesic distance
    5. Return GeodesicFidelity with confidence interval

    Args:
        model: PyTorch model to steer
        caa_vector: Steering vector from compute_caa_vectors()
        test_prompts: List of prompts to measure fidelity on
        tokenizer: Tokenizer for preprocessing prompts
        steering_coefficient: Multiplier for CAA vector (α in paper)
        temperature: Softmax temperature for probability computation
        scale: Sensitivity for KL → κ_H mapping
        method: Geodesic mapping ("exponential" or "rational")

    Returns:
        GeodesicFidelity with κ_H estimate and confidence interval

    Example:
        >>> from transformers import AutoModelForCausalLM, AutoTokenizer
        >>>
        >>> # 1. Load model
        >>> model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-hf")
        >>> tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-hf")
        >>>
        >>> # 2. Compute CAA vector (user provides implementation)
        >>> caa_vec = my_compute_caa_vectors(
        ...     model, positive_prompts, negative_prompts, [15], tokenizer
        ... )[0]
        >>>
        >>> # 3. Estimate κ_H
        >>> test_prompts = ["What is the capital of France?", ...]
        >>> fidelity = estimate_kappa_H_from_caa(
        ...     model, caa_vec, test_prompts, tokenizer, steering_coefficient=1.5
        ... )
        >>>
        >>> # 4. Use in RSCT gatekeeper
        >>> if fidelity.kappa_H < gatekeeper.k_base:
        ...     print("LOW COMPATIBILITY: Re-encode required")
        >>> else:
        ...     print("HIGH COMPATIBILITY: Proceed with execution")

    Integration with RSCTGatekeeper:
    -------------------------------
    ```python
    from exp.series_006.expS6_204_rsct_multiagent_gatekeeper import RSCTGatekeeper

    # Initialize gatekeeper
    gatekeeper = RSCTGatekeeper(k_base=0.5, lambda_turb=0.4)

    # Estimate κ_H from CAA
    fidelity = estimate_kappa_H_from_caa(model, caa_vec, test_prompts, tokenizer)

    # Create RSCT certificate with κ_H
    from exp.series_006.expS6_204_rsct_multiagent_gatekeeper import RSCTCertificate
    cert = RSCTCertificate(
        agent_id="dual_steering_agent",
        step=1,
        R=0.7, S=0.2, N=0.1,  # From YRSN measurement
        alpha=0.875, omega=0.8,
        kappa_gate=fidelity.kappa_H,  # Use κ_H from CAA
        sigma=0.15,
        kappa_A=0.6, kappa_E=0.7, kappa_T=fidelity.kappa_H,  # κ_H maps to tractability
        bottleneck='T' if fidelity.kappa_H < 0.5 else 'balanced',
        coherence=0.85,
        content="Agent output here",
        tokens=100,
    )

    # Validate with gatekeeper
    decision = gatekeeper.validate_handoff(cert)
    print(f"Decision: {decision.action} - {decision.reason}")
    ```

    Notes:
    -----
    - Steering coefficient α: Use 0.5-2.0 range (paper recommends 1.0-1.5)
    - Higher α → stronger steering → higher KL → lower κ_H
    - κ_H < 0.3: Encoding incompatible (REPAIR action)
    - 0.3 ≤ κ_H < 0.5: Gray zone (RE_ENCODE if turbulent)
    - κ_H ≥ 0.5: Compatible (EXECUTE action)
    """
    if not test_prompts:
        raise ValueError("Must provide at least one test prompt")
    if steering_coefficient < 0:
        raise ValueError(f"Steering coefficient must be non-negative, got {steering_coefficient}")

    # Collect KL divergences for all test prompts
    kl_values = []

    with torch.no_grad():
        for prompt in test_prompts:
            # Tokenize prompt
            inputs = tokenizer(prompt, return_tensors="pt")
            input_ids = inputs["input_ids"].to(model.device)

            # Baseline forward pass (no steering)
            logits_baseline = model(input_ids).logits

            # Steered forward pass (with CAA vector applied)
            # NOTE: This is a PLACEHOLDER - users must implement hook mechanism
            # See https://github.com/nrimsky/CAA for reference implementation
            logits_steered = _apply_steering(
                model, input_ids, caa_vector, steering_coefficient
            )

            # Compute KL divergence for this prompt
            kl = compute_kl_divergence(logits_baseline, logits_steered, temperature)
            kl_values.append(kl)

    # Average KL across test prompts
    mean_kl = sum(kl_values) / len(kl_values)

    # Compute κ_H from KL
    kappa_H = geodesic_fidelity(mean_kl, scale=scale, method=method)

    # Bootstrap confidence interval (95%)
    import numpy as np
    bootstrap_samples = []
    n_bootstrap = 1000
    for _ in range(n_bootstrap):
        sample = np.random.choice(kl_values, size=len(kl_values), replace=True)
        sample_kl = float(np.mean(sample))
        sample_kappa = geodesic_fidelity(sample_kl, scale=scale, method=method)
        bootstrap_samples.append(sample_kappa)

    ci_lower = float(np.percentile(bootstrap_samples, 2.5))
    ci_upper = float(np.percentile(bootstrap_samples, 97.5))

    return GeodesicFidelity(
        kappa_H=kappa_H,
        kl_divergence=mean_kl,
        behavior_label=caa_vector.behavior_label,
        layer_idx=caa_vector.layer_idx,
        num_samples=len(test_prompts),
        confidence_interval=(ci_lower, ci_upper),
    )


def _apply_steering(
    model: torch.nn.Module,
    input_ids: torch.Tensor,
    caa_vector: CAAVector,
    coefficient: float,
) -> torch.Tensor:
    """
    Apply CAA steering vector during forward pass.

    **THIS IS A PLACEHOLDER.**

    Users must implement hook mechanism to inject steering vector at target layer.
    See https://github.com/nrimsky/CAA for reference implementation.

    Pseudocode:
    ----------
    1. Register forward hook on target layer
    2. In hook: activations += coefficient * caa_vector
    3. Run forward pass
    4. Remove hook
    5. Return logits

    Args:
        model: PyTorch model
        input_ids: Tokenized input [batch, seq_len]
        caa_vector: Steering vector to apply
        coefficient: Scaling factor (α in paper)

    Returns:
        Logits after steering [batch, seq_len, vocab_size]

    Raises:
        NotImplementedError: Always (users must provide implementation)
    """
    raise NotImplementedError(
        "Users must implement steering hook mechanism.\n"
        "\n"
        "See reference implementation:\n"
        "https://github.com/nrimsky/CAA/blob/main/caa/caa.py\n"
        "\n"
        "Key steps:\n"
        "1. Register forward hook on model.layers[caa_vector.layer_idx]\n"
        "2. In hook: hidden_states += coefficient * caa_vector.vector\n"
        "3. Run model(input_ids)\n"
        "4. Remove hook\n"
        "5. Return logits\n"
    )


# =============================================================================
# EXAMPLE USAGE
# =============================================================================

if __name__ == "__main__":
    # Handle Windows console encoding
    import sys
    import io
    if sys.stdout.encoding != 'utf-8':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    print("Dual-Steering kappa_H Adapter - Example Usage")
    print("=" * 80)

    # Example 1: Geodesic fidelity from KL divergence
    print("\nExample 1: Convert KL divergence to kappa_H")
    print("-" * 40)
    kl_values = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0]
    print(f"{'KL (nats)':<12} {'kappa_H (exp)':<12} {'kappa_H (rat)':<12}")
    for kl in kl_values:
        kappa_exp = geodesic_fidelity(kl, scale=1.0, method="exponential")
        kappa_rat = geodesic_fidelity(kl, scale=1.0, method="rational")
        print(f"{kl:<12.2f} {kappa_exp:<12.3f} {kappa_rat:<12.3f}")

    # Example 2: Compute KL divergence
    print("\nExample 2: Compute KL divergence between distributions")
    print("-" * 40)
    baseline_logits = torch.randn(2, 5, 100)  # batch=2, seq=5, vocab=100

    # Small perturbation (high compatibility)
    steered_small = baseline_logits + 0.1 * torch.randn_like(baseline_logits)
    kl_small = compute_kl_divergence(baseline_logits, steered_small)
    kappa_small = geodesic_fidelity(kl_small)
    print(f"Small perturbation: KL={kl_small:.4f} -> kappa_H={kappa_small:.3f}")

    # Large perturbation (low compatibility)
    steered_large = baseline_logits + 2.0 * torch.randn_like(baseline_logits)
    kl_large = compute_kl_divergence(baseline_logits, steered_large)
    kappa_large = geodesic_fidelity(kl_large)
    print(f"Large perturbation: KL={kl_large:.4f} -> kappa_H={kappa_large:.3f}")

    # Example 3: Integration pattern
    print("\nExample 3: Integration with RSCTGatekeeper")
    print("-" * 40)
    print("""
# Step 1: Compute CAA vectors (user implementation)
caa_vectors = compute_caa_vectors(
    model=my_model,
    positive_prompts=["Be factual and accurate..."],
    negative_prompts=["Make up plausible-sounding facts..."],
    layer_indices=[8, 12, 16],
    tokenizer=my_tokenizer,
)

# Step 2: Estimate κ_H from steering fidelity
fidelity = estimate_kappa_H_from_caa(
    model=my_model,
    caa_vector=caa_vectors[1],  # Use layer 12
    test_prompts=["What is the capital of France?", ...],
    tokenizer=my_tokenizer,
    steering_coefficient=1.5,  # Moderate steering
)

# Step 3: Create RSCT certificate with κ_H
from exp.series_006.expS6_204_rsct_multiagent_gatekeeper import RSCTCertificate
cert = RSCTCertificate(
    agent_id="factual_agent",
    step=1,
    R=0.7, S=0.2, N=0.1,
    alpha=0.875, omega=0.8,
    kappa_gate=fidelity.kappa_H,  # Use κ_H from CAA
    sigma=0.15,
    kappa_A=0.6, kappa_E=0.7, kappa_T=fidelity.kappa_H,
    bottleneck='T' if fidelity.kappa_H < 0.5 else 'balanced',
    coherence=0.85,
    content="Paris is the capital of France.",
    tokens=10,
)

# Step 4: Validate with gatekeeper
from exp.series_006.expS6_204_rsct_multiagent_gatekeeper import RSCTGatekeeper
gatekeeper = RSCTGatekeeper(k_base=0.5, lambda_turb=0.4)
decision = gatekeeper.validate_handoff(cert)

if decision.action == 'EXECUTE':
    print("[OK] High compatibility - proceed")
elif decision.action == 'RE_ENCODE':
    print("[WARN] Low compatibility - try different steering")
elif decision.action == 'REPAIR':
    print("[ERROR] Very low compatibility - repair encoding")
    """)

    print("\n" + "=" * 80)
    print("See docstrings for detailed API documentation.")
    print("\nKey Integration Points:")
    print("1. compute_caa_vectors() - Plug in your CAA implementation")
    print("2. estimate_kappa_H_from_caa() - Get κ_H for gatekeeper")
    print("3. RSCTGatekeeper.validate_handoff() - Make control decisions")
