"""
Checkpoint Loader Adapter

Adapter for loading RSN projection checkpoints. This adapter handles the
complexity of checkpoint formats and provides a clean interface for the
core domain.

Usage:
    from yrsn.adapters.checkpoint_loader import CheckpointLoader

    loader = CheckpointLoader()
    projection = loader.load('checkpoints/trained_rotor_universal64.pt')

    # Check if checkpoint is universal
    if loader.is_universal(projection):
        print("Universal checkpoint - works with any architecture")
"""

from pathlib import Path
from typing import Union, Optional, Dict, Any
import warnings
import torch


class CheckpointLoader:
    """
    Adapter for loading RSN checkpoints.

    This adapter encapsulates checkpoint loading logic, which was previously
    embedded in the core TrainedRSNProjection class. By moving this to an
    adapter, we achieve proper hexagonal architecture separation.

    Features:
        - Automatic detection of checkpoint type (rotor vs MLP, universal vs legacy)
        - Deprecation warnings for legacy checkpoints
        - Validation of checkpoint compatibility
        - Clean error messages
    """

    def __init__(self, device: Union[str, torch.device] = 'cpu'):
        """
        Initialize the checkpoint loader.

        Args:
            device: Device to load checkpoints on
        """
        self.device = torch.device(device)

    def load(
        self,
        checkpoint_path: Union[str, Path],
        validate: bool = True
    ):
        """
        Load a checkpoint and return a configured TrainedRSNProjection.

        Args:
            checkpoint_path: Path to the checkpoint file
            validate: Whether to validate checkpoint structure

        Returns:
            TrainedRSNProjection instance

        Raises:
            FileNotFoundError: If checkpoint doesn't exist
            ValueError: If checkpoint is invalid
        """
        from yrsn.core.decomposition import TrainedRSNProjection

        checkpoint_path = Path(checkpoint_path)
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

        # Load checkpoint
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        if validate:
            self._validate_checkpoint(checkpoint, checkpoint_path)

        # Check for universal vs legacy
        metadata = checkpoint.get('metadata', {})
        is_universal = metadata.get('is_universal', False)

        if not is_universal:
            # Legacy checkpoint - warn the user
            trained_on = metadata.get('trained_on', ['unknown'])
            if isinstance(trained_on, list):
                trained_on = trained_on[0] if trained_on else 'unknown'

            warnings.warn(
                f"Loading legacy checkpoint trained on '{trained_on}'. "
                f"This checkpoint may not work well with other architectures. "
                f"Consider training a universal checkpoint with "
                f"'python -m yrsn.training.train_universal_rotor'",
                UserWarning,
                stacklevel=2
            )

        # Use the from_checkpoint method
        projection = TrainedRSNProjection.from_checkpoint(
            checkpoint_path,
            device=self.device
        )

        return projection

    def _validate_checkpoint(self, checkpoint: Dict[str, Any], path: Path) -> None:
        """Validate checkpoint structure."""
        required_keys = {'model_state_dict'}
        missing = required_keys - set(checkpoint.keys())

        if missing:
            raise ValueError(
                f"Invalid checkpoint at {path}: missing keys {missing}"
            )

        # Check for old format
        if 'rotor_variant' not in checkpoint and 'config' not in checkpoint:
            warnings.warn(
                f"Checkpoint {path.name} uses old format. "
                f"Consider re-training with current version.",
                DeprecationWarning,
                stacklevel=3
            )

    def get_metadata(
        self,
        checkpoint_path: Union[str, Path]
    ) -> Dict[str, Any]:
        """
        Get checkpoint metadata without loading the full model.

        Args:
            checkpoint_path: Path to checkpoint

        Returns:
            Dict with checkpoint metadata
        """
        checkpoint_path = Path(checkpoint_path)
        checkpoint = torch.load(checkpoint_path, map_location='cpu')

        return {
            'embed_dim': checkpoint.get('embed_dim', checkpoint.get('config', {}).get('embed_dim')),
            'rotor_variant': checkpoint.get('rotor_variant'),
            'is_universal': checkpoint.get('metadata', {}).get('is_universal', False),
            'trained_on': checkpoint.get('metadata', {}).get('trained_on', []),
            'timestamp': checkpoint.get('timestamp'),
            'metrics': checkpoint.get('metrics', {}),
        }

    def is_universal(
        self,
        checkpoint_or_path: Union[str, Path, Any]
    ) -> bool:
        """
        Check if a checkpoint or projection is universal.

        Args:
            checkpoint_or_path: Path to checkpoint or loaded projection

        Returns:
            True if the checkpoint is universal (trained on multiple architectures)
        """
        if isinstance(checkpoint_or_path, (str, Path)):
            metadata = self.get_metadata(checkpoint_or_path)
            return metadata.get('is_universal', False)
        else:
            # Assume it's a loaded projection - check internal metadata
            if hasattr(checkpoint_or_path, '_metadata'):
                return checkpoint_or_path._metadata.get('is_universal', False)
            return False

    def list_checkpoints(
        self,
        checkpoint_dir: Union[str, Path] = 'checkpoints'
    ) -> Dict[str, Dict[str, Any]]:
        """
        List all available checkpoints with their metadata.

        Args:
            checkpoint_dir: Directory to scan for checkpoints

        Returns:
            Dict mapping checkpoint names to their metadata
        """
        checkpoint_dir = Path(checkpoint_dir)
        if not checkpoint_dir.exists():
            return {}

        results = {}
        for path in checkpoint_dir.glob('*.pt'):
            try:
                results[path.name] = self.get_metadata(path)
            except Exception as e:
                results[path.name] = {'error': str(e)}

        return results


# Convenience function
def load_checkpoint(
    checkpoint_path: Union[str, Path],
    device: Union[str, torch.device] = 'cpu'
):
    """
    Convenience function to load a checkpoint.

    Args:
        checkpoint_path: Path to checkpoint
        device: Device to load on

    Returns:
        TrainedRSNProjection instance
    """
    loader = CheckpointLoader(device=device)
    return loader.load(checkpoint_path)


__all__ = ['CheckpointLoader', 'load_checkpoint']
