"""
Simplex-Ready Text Extractor for YRSN
======================================

T4-native extractor that outputs explicit R/S/N-like coordinates.

Architecture:
- R proxy: Semantic relevance (entity density, concept coherence)
- S proxy: Superfluousness (redundancy, repetition, low novelty)
- N proxy: Noise (perplexity spikes, incoherence, entity jumps)

Output: 3D simplex coordinates [R, S, N] where R + S + N = 1.0
"""

import numpy as np
from typing import List, Union, Dict, Optional
from collections import Counter
import re
from yrsn.ports.feature_extraction import IFeatureExtractor


class SimplexReadyExtractor(IFeatureExtractor):
    """
    Outputs explicit R/S/N-like coordinates that naturally align with T4 rotor.

    This extractor pre-computes the quality decomposition that the rotor
    would otherwise need to discover, making the downstream task easier.
    """

    def __init__(self,
                 output_dim: int = 64,
                 normalize: bool = True,
                 expand_basis: bool = True):
        """
        Args:
            output_dim: Target dimension (64 for rotor compatibility)
            normalize: Whether to normalize coordinates to simplex
            expand_basis: Whether to expand 3D coordinates to output_dim
        """
        self._output_dim = output_dim
        self.normalize = normalize
        self.expand_basis = expand_basis
        self._is_initialized = False

    def _lazy_init(self):
        """Lazy initialization of heavy dependencies"""
        if self._is_initialized:
            return

        # Try to import spacy (optional but recommended)
        try:
            import spacy
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except OSError:
                print("Warning: spacy model 'en_core_web_sm' not found. Install with: python -m spacy download en_core_web_sm")
                self.nlp = None
        except ImportError:
            print("Warning: spacy not installed. Install with: pip install spacy")
            self.nlp = None

        # Try to import transformers for perplexity (optional)
        try:
            from transformers import GPT2LMHeadModel, GPT2TokenizerFast
            import torch
            self.perplexity_model = GPT2LMHeadModel.from_pretrained("distilgpt2")
            self.perplexity_tokenizer = GPT2TokenizerFast.from_pretrained("distilgpt2")
            self.perplexity_model.eval()
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.perplexity_model.to(self.device)
        except ImportError:
            print("Warning: transformers not installed. Perplexity will use heuristic.")
            self.perplexity_model = None

        self._is_initialized = True

    def extract(self, texts: Union[List[str], np.ndarray]) -> np.ndarray:
        """
        Extract simplex coordinates for texts.

        Args:
            texts: List of text strings

        Returns:
            numpy array of shape (n_texts, output_dim) with simplex coordinates
        """
        self._lazy_init()

        if isinstance(texts, np.ndarray):
            texts = texts.tolist()

        # Compute R/S/N coordinates for each text
        coords = []
        for text in texts:
            r_score = self.compute_relevance_proxy(text)
            s_score = self.compute_superfluousness_proxy(text)
            n_score = self.compute_noise_proxy(text)

            if self.normalize:
                # Normalize to simplex (sum to 1)
                total = r_score + s_score + n_score
                if total > 0:
                    r_score /= total
                    s_score /= total
                    n_score /= total
                else:
                    # Default to pure noise if all zeros
                    r_score, s_score, n_score = 0.0, 0.0, 1.0

            # Base coordinates
            base_coords = np.array([r_score, s_score, n_score], dtype=np.float32)

            if self.expand_basis and self._output_dim > 3:
                # Expand to output_dim using simple basis expansion
                expanded = self._expand_to_dim(base_coords, text)
                coords.append(expanded)
            else:
                coords.append(base_coords)

        return np.array(coords, dtype=np.float32)

    def compute_relevance_proxy(self, text: str) -> float:
        """
        Compute R proxy: Semantic relevance/density

        High R = focused, entity-rich, semantically dense content
        """
        if not text or len(text.strip()) == 0:
            return 0.0

        words = text.split()
        word_count = len(words)
        if word_count == 0:
            return 0.0

        score = 0.0

        # Component 1: Entity density (if spacy available)
        if self.nlp is not None:
            doc = self.nlp(text[:1000])  # Limit to first 1000 chars for speed
            entities = [ent for ent in doc.ents]
            entity_density = len(entities) / max(word_count, 1)
            score += entity_density * 10.0  # Scale to ~0-1 range
        else:
            # Fallback: capital word ratio (rough entity proxy)
            capital_words = sum(1 for w in words if w and w[0].isupper())
            score += (capital_words / word_count) * 5.0

        # Component 2: Lexical diversity (unique words / total words)
        unique_words = len(set(w.lower() for w in words))
        lexical_diversity = unique_words / word_count
        score += lexical_diversity * 2.0

        # Component 3: Average word length (longer words = more specific/technical)
        avg_word_length = np.mean([len(w) for w in words if w])
        score += (avg_word_length - 4.0) / 2.0  # Normalize around 4-char average

        # Component 4: Sentence completeness (periods, questions, exclamations)
        sentence_endings = text.count('.') + text.count('?') + text.count('!')
        completeness = min(sentence_endings / max(word_count / 20, 1), 2.0)
        score += completeness

        return max(0.0, score)  # Ensure non-negative

    def compute_superfluousness_proxy(self, text: str) -> float:
        """
        Compute S proxy: Superfluousness/redundancy

        High S = repetitive, redundant, low novelty
        """
        if not text or len(text.strip()) == 0:
            return 0.0

        words = text.split()
        word_count = len(words)
        if word_count == 0:
            return 0.0

        score = 0.0

        # Component 1: N-gram repetition (trigrams)
        trigrams = []
        for i in range(len(words) - 2):
            trigram = ' '.join(words[i:i+3]).lower()
            trigrams.append(trigram)

        if trigrams:
            trigram_counts = Counter(trigrams)
            repeated_trigrams = sum(count - 1 for count in trigram_counts.values() if count > 1)
            repetition_rate = repeated_trigrams / len(trigrams)
            score += repetition_rate * 5.0

        # Component 2: Bigram repetition
        bigrams = []
        for i in range(len(words) - 1):
            bigram = ' '.join(words[i:i+2]).lower()
            bigrams.append(bigram)

        if bigrams:
            bigram_counts = Counter(bigrams)
            repeated_bigrams = sum(count - 1 for count in bigram_counts.values() if count > 1)
            repetition_rate = repeated_bigrams / len(bigrams)
            score += repetition_rate * 3.0

        # Component 3: Word repetition (unigrams)
        word_counts = Counter(w.lower() for w in words)
        repeated_words = sum(count - 1 for count in word_counts.values() if count > 1)
        word_repetition_rate = repeated_words / word_count
        score += word_repetition_rate * 2.0

        # Component 4: Filler words (common, low-information words)
        filler_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
            'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'should', 'could', 'may', 'might', 'must', 'can', 'that', 'this',
            'these', 'those', 'it', 'its', 'very', 'really', 'just', 'like'
        }
        filler_count = sum(1 for w in words if w.lower() in filler_words)
        filler_ratio = filler_count / word_count
        score += filler_ratio * 3.0

        return max(0.0, score)

    def compute_noise_proxy(self, text: str) -> float:
        """
        Compute N proxy: Noise/incoherence

        High N = incoherent, off-topic, perplexity spikes, entity jumps
        """
        if not text or len(text.strip()) == 0:
            return 1.0  # Empty text is pure noise

        words = text.split()
        word_count = len(words)
        if word_count == 0:
            return 1.0

        score = 0.0

        # Component 1: Perplexity (if model available)
        if self.perplexity_model is not None:
            try:
                import torch
                # Compute perplexity
                encodings = self.perplexity_tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
                encodings = {k: v.to(self.device) for k, v in encodings.items()}

                with torch.no_grad():
                    outputs = self.perplexity_model(**encodings, labels=encodings["input_ids"])
                    loss = outputs.loss
                    perplexity = torch.exp(loss).item()

                # Normalize perplexity (typical range: 10-200)
                # Low perplexity = coherent (low noise)
                # High perplexity = incoherent (high noise)
                normalized_ppl = min((perplexity - 10) / 100, 2.0)
                score += max(0.0, normalized_ppl * 3.0)
            except Exception as e:
                # Fallback to heuristic if perplexity computation fails
                pass

        # Component 2: Punctuation chaos (excessive or missing)
        punct_count = sum(text.count(p) for p in '!?.,;:')
        punct_ratio = punct_count / word_count
        # Too much or too little punctuation = noise
        punct_deviation = abs(punct_ratio - 0.15)  # Assume ~15% is normal
        score += punct_deviation * 5.0

        # Component 3: Case inconsistency (random caps)
        if self.nlp is None:
            # Simple heuristic: mid-sentence capitals that aren't at sentence starts
            sentences = re.split(r'[.!?]+', text)
            mid_caps = 0
            for sent in sentences:
                words_in_sent = sent.strip().split()
                if len(words_in_sent) > 1:
                    # Count capitals after first word
                    mid_caps += sum(1 for w in words_in_sent[1:] if w and w[0].isupper() and w.lower() not in {'i'})
            case_noise = mid_caps / max(word_count, 1)
            score += case_noise * 3.0

        # Component 4: Short sentences/fragments (incomplete thoughts)
        sentences = re.split(r'[.!?]+', text)
        short_sentences = sum(1 for s in sentences if 0 < len(s.split()) < 3)
        if len(sentences) > 0:
            fragment_ratio = short_sentences / len(sentences)
            score += fragment_ratio * 2.0

        # Component 5: Numbers/special characters (can indicate spam/noise)
        digit_count = sum(c.isdigit() for c in text)
        special_count = sum(1 for c in text if not c.isalnum() and not c.isspace() and c not in '.!?,;:-')
        noise_char_ratio = (digit_count + special_count) / max(len(text), 1)
        score += noise_char_ratio * 2.0

        return max(0.0, score)

    def _expand_to_dim(self, base_coords: np.ndarray, text: str) -> np.ndarray:
        """
        Expand 3D simplex coordinates to output_dim using basis expansion.

        Strategy:
        - First 3 dims: base R/S/N coordinates
        - Remaining dims: interaction features + text statistics
        """
        expanded = np.zeros(self._output_dim, dtype=np.float32)

        # First 3 dimensions: base coordinates
        expanded[0] = base_coords[0]  # R
        expanded[1] = base_coords[1]  # S
        expanded[2] = base_coords[2]  # N

        if self._output_dim > 3:
            # Compute additional features for remaining dimensions
            words = text.split()
            word_count = len(words)

            features = []

            # Interaction features (R×S, R×N, S×N)
            features.append(base_coords[0] * base_coords[1])  # R×S
            features.append(base_coords[0] * base_coords[2])  # R×N
            features.append(base_coords[1] * base_coords[2])  # S×N

            # Second-order interactions
            features.append(base_coords[0]**2)  # R²
            features.append(base_coords[1]**2)  # S²
            features.append(base_coords[2]**2)  # N²

            # Text statistics (normalized to 0-1 range)
            features.append(min(word_count / 100, 1.0))  # Length (normalized)
            features.append(len(set(w.lower() for w in words)) / max(word_count, 1))  # Lexical diversity
            features.append(min(np.mean([len(w) for w in words if w]) / 10, 1.0))  # Avg word length

            # Sentence-level features
            sentences = re.split(r'[.!?]+', text)
            features.append(min(len(sentences) / 20, 1.0))  # Sentence count
            if sentences:
                avg_sent_len = np.mean([len(s.split()) for s in sentences if s.strip()])
                features.append(min(avg_sent_len / 30, 1.0))  # Avg sentence length
            else:
                features.append(0.0)

            # Punctuation features
            features.append(min(text.count('.') / max(word_count / 10, 1), 1.0))  # Period density
            features.append(min(text.count(',') / max(word_count / 5, 1), 1.0))   # Comma density

            # Fill remaining dimensions with random projections of base coords
            # This preserves geometric relationships while expanding dimension
            np.random.seed(42)  # Deterministic
            projection_matrix = np.random.randn(3, self._output_dim - 3 - len(features))
            projection_matrix /= np.linalg.norm(projection_matrix, axis=0)  # Normalize columns
            projected = base_coords @ projection_matrix

            # Concatenate all features
            expanded[3:3+len(features)] = features[:min(len(features), self._output_dim-3)]
            if 3 + len(features) < self._output_dim:
                expanded[3+len(features):] = projected[:self._output_dim - 3 - len(features)]

        return expanded

    @property
    def modality(self) -> str:
        return "text"

    @property
    def output_dim(self) -> int:
        return self._output_dim if hasattr(self, '_output_dim') else 64
