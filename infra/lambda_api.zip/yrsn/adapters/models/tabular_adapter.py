"""
Tabular Feature Extractors - Adapters for Tabular Data

Implements IFeatureExtractor for tabular/structured data:
- TabularMLPExtractor: MLP encoder for numeric features
- TabularAutoEncoder: Autoencoder-based features

Usage:
    from yrsn.adapters.models.tabular_adapter import TabularMLPExtractor

    extractor = TabularMLPExtractor(input_dim=4)  # e.g., Iris has 4 features
    features = extractor.extract(data)  # [B, 64]
"""

import numpy as np
from typing import Optional
from pathlib import Path

import torch
import torch.nn as nn


class TabularMLPExtractor:
    """
    MLP-based feature extractor for tabular data.

    Encodes numeric features into a fixed-dimensional representation.
    Includes batch normalization for feature standardization.
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int = 64,
        hidden_dims: tuple = (128, 64),
        checkpoint_path: Optional[str] = None,
        device: str = 'cpu',
    ):
        """
        Args:
            input_dim: Number of input features
            output_dim: Output embedding dimension
            hidden_dims: Hidden layer dimensions
            checkpoint_path: Path to trained checkpoint
            device: torch device
        """
        self._device = device
        self._input_dim = input_dim
        self._output_dim = output_dim

        # Build MLP
        layers = []
        prev_dim = input_dim

        # Add batch norm for input standardization
        layers.append(nn.BatchNorm1d(input_dim))

        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
            ])
            prev_dim = hidden_dim

        layers.append(nn.Linear(prev_dim, output_dim))

        self._model = nn.Sequential(*layers).to(device)

        if checkpoint_path and Path(checkpoint_path).exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            self._model.load_state_dict(checkpoint['model_state_dict'])

        self._model.eval()

    @property
    def feature_dim(self) -> int:
        return self._output_dim

    @property
    def model_name(self) -> str:
        return f"tabular_mlp_{self._input_dim}d"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from tabular data.

        Args:
            data: Numeric features [B, input_dim]

        Returns:
            np.ndarray: Features [B, output_dim]
        """
        with torch.no_grad():
            inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
            # Handle single sample (add batch dim)
            if inputs.dim() == 1:
                inputs = inputs.unsqueeze(0)
            outputs = self._model(inputs)
        return outputs.cpu().numpy().astype(np.float32)

    def train_on_data(
        self,
        data: np.ndarray,
        labels: np.ndarray,
        epochs: int = 100,
        lr: float = 0.001,
    ):
        """
        Train the MLP on labeled data (optional supervised training).

        Args:
            data: Features [N, input_dim]
            labels: Quality labels [N] (0=low, 1=medium, 2=high)
            epochs: Training epochs
            lr: Learning rate
        """
        self._model.train()
        optimizer = torch.optim.Adam(self._model.parameters(), lr=lr)
        criterion = nn.CrossEntropyLoss()

        # Add classification head
        classifier = nn.Linear(self._output_dim, 3).to(self._device)

        inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
        targets = torch.tensor(labels, dtype=torch.long).to(self._device)

        for epoch in range(epochs):
            optimizer.zero_grad()
            features = self._model(inputs)
            logits = classifier(features)
            loss = criterion(logits, targets)
            loss.backward()
            optimizer.step()

            if (epoch + 1) % 20 == 0:
                acc = (logits.argmax(1) == targets).float().mean()
                print(f"Epoch {epoch+1}/{epochs}: loss={loss.item():.4f}, acc={acc:.3f}")

        self._model.eval()


class TabularAutoEncoder:
    """
    Autoencoder-based feature extractor for tabular data.

    Learns compressed representations through reconstruction.
    Good for unsupervised feature learning.
    """

    def __init__(
        self,
        input_dim: int,
        latent_dim: int = 64,
        hidden_dim: int = 128,
        checkpoint_path: Optional[str] = None,
        device: str = 'cpu',
    ):
        """
        Args:
            input_dim: Number of input features
            latent_dim: Latent (output) dimension
            hidden_dim: Hidden layer dimension
            checkpoint_path: Path to trained checkpoint
            device: torch device
        """
        self._device = device
        self._input_dim = input_dim
        self._latent_dim = latent_dim

        # Encoder
        self._encoder = nn.Sequential(
            nn.BatchNorm1d(input_dim),
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim),
        ).to(device)

        # Decoder
        self._decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        ).to(device)

        if checkpoint_path and Path(checkpoint_path).exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            self._encoder.load_state_dict(checkpoint['encoder_state_dict'])
            self._decoder.load_state_dict(checkpoint['decoder_state_dict'])

        self._encoder.eval()
        self._decoder.eval()

    @property
    def feature_dim(self) -> int:
        return self._latent_dim

    @property
    def model_name(self) -> str:
        return f"tabular_ae_{self._input_dim}d"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract latent features from tabular data.

        Args:
            data: Numeric features [B, input_dim]

        Returns:
            np.ndarray: Latent features [B, latent_dim]
        """
        with torch.no_grad():
            inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
            if inputs.dim() == 1:
                inputs = inputs.unsqueeze(0)
            latent = self._encoder(inputs)
        return latent.cpu().numpy().astype(np.float32)

    def train_on_data(
        self,
        data: np.ndarray,
        epochs: int = 100,
        lr: float = 0.001,
    ):
        """
        Train autoencoder on data (unsupervised).

        Args:
            data: Features [N, input_dim]
            epochs: Training epochs
            lr: Learning rate
        """
        self._encoder.train()
        self._decoder.train()

        params = list(self._encoder.parameters()) + list(self._decoder.parameters())
        optimizer = torch.optim.Adam(params, lr=lr)
        criterion = nn.MSELoss()

        inputs = torch.tensor(data, dtype=torch.float32).to(self._device)

        for epoch in range(epochs):
            optimizer.zero_grad()
            latent = self._encoder(inputs)
            recon = self._decoder(latent)
            loss = criterion(recon, inputs)
            loss.backward()
            optimizer.step()

            if (epoch + 1) % 20 == 0:
                print(f"Epoch {epoch+1}/{epochs}: recon_loss={loss.item():.4f}")

        self._encoder.eval()
        self._decoder.eval()


__all__ = [
    "TabularMLPExtractor",
    "TabularAutoEncoder",
]
