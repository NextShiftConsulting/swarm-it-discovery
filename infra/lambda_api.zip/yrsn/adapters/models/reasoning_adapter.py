"""
Reasoning Feature Extractors - Adapters for Logical/Puzzle Data

Implements IFeatureExtractor for reasoning tasks:
- SudokuExtractor: CNN encoder for Sudoku grids
- ConstraintExtractor: Generic constraint satisfaction encoder

Usage:
    from yrsn.adapters.models.reasoning_adapter import SudokuExtractor

    extractor = SudokuExtractor()
    features = extractor.extract(puzzles)  # [B, 64]
"""

import numpy as np
from typing import Optional
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


class SudokuExtractor:
    """
    CNN-based feature extractor for Sudoku puzzles.

    Treats 9x9 Sudoku grid as a single-channel image.
    Encodes constraint structure into embeddings.
    """

    def __init__(
        self,
        output_dim: int = 64,
        checkpoint_path: Optional[str] = None,
        device: str = 'cpu',
    ):
        """
        Args:
            output_dim: Output embedding dimension
            checkpoint_path: Path to trained checkpoint
            device: torch device
        """
        self._device = device
        self._output_dim = output_dim

        # CNN for 9x9 grid (treat as 1-channel image)
        self._model = nn.Sequential(
            # Conv block 1: 9x9 → 7x7
            nn.Conv2d(1, 32, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.BatchNorm2d(32),

            # Conv block 2: 7x7 → 5x5
            nn.Conv2d(32, 64, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.BatchNorm2d(64),

            # Conv block 3: 5x5 → 3x3
            nn.Conv2d(64, 128, kernel_size=3, padding=0),
            nn.ReLU(),
            nn.BatchNorm2d(128),

            # Flatten: 128 * 3 * 3 = 1152
            nn.Flatten(),

            # MLP
            nn.Linear(128 * 3 * 3, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, output_dim),
        ).to(device)

        if checkpoint_path and Path(checkpoint_path).exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            self._model.load_state_dict(checkpoint['model_state_dict'])

        self._model.eval()

    @property
    def feature_dim(self) -> int:
        return self._output_dim

    @property
    def model_name(self) -> str:
        return "sudoku_cnn"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from Sudoku puzzles.

        Args:
            data: Sudoku grids [B, 9, 9] with values 0-9 (0=empty)

        Returns:
            np.ndarray: Features [B, output_dim]
        """
        with torch.no_grad():
            # Normalize: 0-9 → 0-1
            inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
            inputs = inputs / 9.0

            # Add channel dimension if needed
            if inputs.dim() == 2:
                inputs = inputs.unsqueeze(0)
            if inputs.dim() == 3:
                inputs = inputs.unsqueeze(1)  # [B, 1, 9, 9]

            outputs = self._model(inputs)
        return outputs.cpu().numpy().astype(np.float32)

    def train_on_puzzles(
        self,
        puzzles: np.ndarray,
        difficulty_labels: np.ndarray,
        epochs: int = 100,
        lr: float = 0.001,
    ):
        """
        Train on difficulty classification task.

        Args:
            puzzles: Sudoku grids [N, 9, 9]
            difficulty_labels: 0=easy, 1=medium, 2=hard, 3=expert
            epochs: Training epochs
            lr: Learning rate
        """
        self._model.train()

        # Add classification head
        classifier = nn.Linear(self._output_dim, 4).to(self._device)

        params = list(self._model.parameters()) + list(classifier.parameters())
        optimizer = torch.optim.Adam(params, lr=lr)
        criterion = nn.CrossEntropyLoss()

        inputs = torch.tensor(puzzles, dtype=torch.float32).to(self._device) / 9.0
        inputs = inputs.unsqueeze(1)  # [N, 1, 9, 9]
        targets = torch.tensor(difficulty_labels, dtype=torch.long).to(self._device)

        for epoch in range(epochs):
            optimizer.zero_grad()
            features = self._model(inputs)
            logits = classifier(features)
            loss = criterion(logits, targets)
            loss.backward()
            optimizer.step()

            if (epoch + 1) % 20 == 0:
                acc = (logits.argmax(1) == targets).float().mean()
                print(f"Epoch {epoch+1}/{epochs}: loss={loss.item():.4f}, acc={acc:.3f}")

        self._model.eval()


class ConstraintExtractor:
    """
    Generic constraint satisfaction feature extractor.

    Encodes constraint satisfaction problems into embeddings.
    Works with any fixed-size constraint structure.
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int = 64,
        checkpoint_path: Optional[str] = None,
        device: str = 'cpu',
    ):
        """
        Args:
            input_dim: Flattened input dimension
            output_dim: Output embedding dimension
            checkpoint_path: Path to trained checkpoint
            device: torch device
        """
        self._device = device
        self._input_dim = input_dim
        self._output_dim = output_dim

        self._model = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.Dropout(0.1),

            nn.Linear(256, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.1),

            nn.Linear(128, output_dim),
        ).to(device)

        if checkpoint_path and Path(checkpoint_path).exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            self._model.load_state_dict(checkpoint['model_state_dict'])

        self._model.eval()

    @property
    def feature_dim(self) -> int:
        return self._output_dim

    @property
    def model_name(self) -> str:
        return f"constraint_mlp_{self._input_dim}d"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from constraint problems.

        Args:
            data: Flattened constraint data [B, input_dim]

        Returns:
            np.ndarray: Features [B, output_dim]
        """
        with torch.no_grad():
            inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
            if inputs.dim() == 1:
                inputs = inputs.unsqueeze(0)
            outputs = self._model(inputs)
        return outputs.cpu().numpy().astype(np.float32)


class LogicPuzzleExtractor:
    """
    Feature extractor for logic puzzles (syllogisms, etc.).

    Uses an MLP on one-hot encoded premise/question pairs.
    """

    def __init__(
        self,
        vocab_size: int = 100,
        max_length: int = 50,
        embed_dim: int = 32,
        output_dim: int = 64,
        device: str = 'cpu',
    ):
        """
        Args:
            vocab_size: Vocabulary size for tokenization
            max_length: Maximum sequence length
            embed_dim: Embedding dimension
            output_dim: Output feature dimension
            device: torch device
        """
        self._device = device
        self._vocab_size = vocab_size
        self._max_length = max_length
        self._output_dim = output_dim

        self._embedding = nn.Embedding(vocab_size, embed_dim).to(device)

        self._model = nn.Sequential(
            nn.Linear(max_length * embed_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(128, output_dim),
        ).to(device)

        self._model.eval()

    @property
    def feature_dim(self) -> int:
        return self._output_dim

    @property
    def model_name(self) -> str:
        return "logic_puzzle_mlp"

    def tokenize(self, text: str) -> np.ndarray:
        """Simple character-level tokenization."""
        tokens = [ord(c) % self._vocab_size for c in text[:self._max_length]]
        # Pad to max_length
        tokens = tokens + [0] * (self._max_length - len(tokens))
        return np.array(tokens, dtype=np.int64)

    def extract(self, data: list) -> np.ndarray:
        """
        Extract features from logic puzzles.

        Args:
            data: List of puzzle strings or dicts

        Returns:
            np.ndarray: Features [B, output_dim]
        """
        # Convert to token sequences
        if isinstance(data[0], dict):
            texts = [str(d.get('premises', '')) + str(d.get('question', '')) for d in data]
        else:
            texts = [str(d) for d in data]

        tokens = np.array([self.tokenize(t) for t in texts])

        with torch.no_grad():
            inputs = torch.tensor(tokens, dtype=torch.long).to(self._device)
            embedded = self._embedding(inputs)  # [B, L, E]
            flattened = embedded.view(embedded.size(0), -1)  # [B, L*E]
            outputs = self._model(flattened)

        return outputs.cpu().numpy().astype(np.float32)


__all__ = [
    "SudokuExtractor",
    "ConstraintExtractor",
    "LogicPuzzleExtractor",
]
