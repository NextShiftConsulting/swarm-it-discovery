"""
Model Feature Extractor Adapters

Adapters implementing IFeatureExtractor for various neural network architectures.
These adapters enable the Universal Rotor to work with any model.

P15 COMPLIANCE: All extractors feed into the Universal Rotor (HybridSimplexRotor).
See docs/principles/FIRST_PRINCIPLES.md for architecture requirements.

Available Adapters:
    Vision:
        - ResNet20Extractor: For ResNet20 CIFAR-10 model
        - SimpleCNNExtractor: For simple 3-layer CNN
        - SimpleMLPExtractor: For simple MLP

    Text:
        - SentenceTransformerExtractor: sentence-transformers (384-dim)
        - DistilBERTExtractor: HuggingFace DistilBERT (768-dim)
        - TextMLPExtractor: Lightweight MLP projection

    Tabular:
        - TabularMLPExtractor: MLP for numeric features
        - TabularAutoEncoder: Autoencoder-based features

    Reasoning:
        - SudokuExtractor: CNN for Sudoku grids
        - ConstraintExtractor: Generic constraint encoder
        - LogicPuzzleExtractor: Logic puzzle encoder

Usage:
    from yrsn.adapters.models import ResNet20Extractor, SentenceTransformerExtractor

    # Vision
    resnet = ResNet20Extractor(device='cuda')
    features = resnet.extract(images)  # [B, 64]

    # Text
    text_ext = SentenceTransformerExtractor()
    features = text_ext.extract(texts)  # [B, 384]
"""

# Vision extractors
from yrsn.adapters.models.resnet_adapter import ResNet20Extractor
from yrsn.adapters.models.simplecnn_adapter import SimpleCNNExtractor
from yrsn.adapters.models.simplemlp_adapter import SimpleMLPExtractor

# Text extractors
from yrsn.adapters.models.text_adapter import (
    SentenceTransformerExtractor,
    DistilBERTExtractor,
    TextMLPExtractor,
)

# Tabular extractors
from yrsn.adapters.models.tabular_adapter import (
    TabularMLPExtractor,
    TabularAutoEncoder,
)

# Reasoning extractors
from yrsn.adapters.models.reasoning_adapter import (
    SudokuExtractor,
    ConstraintExtractor,
    LogicPuzzleExtractor,
)

__all__ = [
    # Vision
    "ResNet20Extractor",
    "SimpleCNNExtractor",
    "SimpleMLPExtractor",
    # Text
    "SentenceTransformerExtractor",
    "DistilBERTExtractor",
    "TextMLPExtractor",
    # Tabular
    "TabularMLPExtractor",
    "TabularAutoEncoder",
    # Reasoning
    "SudokuExtractor",
    "ConstraintExtractor",
    "LogicPuzzleExtractor",
]
