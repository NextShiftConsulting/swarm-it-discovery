"""
ResNet20 Feature Extractor Adapter

Implements IFeatureExtractor for the ResNet20 CIFAR-10 model.
"""

from typing import Union
import numpy as np
import torch

from yrsn.ports.feature_extraction import IFeatureExtractor


class ResNet20Extractor:
    """
    Adapter implementing IFeatureExtractor for ResNet20 CIFAR-10.

    This is the reference extractor - the original rotor was trained
    on features from this model.

    Args:
        device: Device to run model on ('cpu', 'cuda', etc.)
        pretrained: Whether to load pretrained weights (default: True)

    Example:
        extractor = ResNet20Extractor(device='cuda')
        features = extractor.extract(images)  # [B, 64]
    """

    def __init__(
        self,
        device: Union[str, torch.device] = 'cpu',
        pretrained: bool = True
    ):
        self._device = torch.device(device)

        # Late import to avoid circular dependency
        from yrsn.models.resnet_cifar import resnet20_cifar10

        self._model = resnet20_cifar10(pretrained=pretrained, device=str(self._device))
        self._model.eval()

    @property
    def feature_dim(self) -> int:
        """ResNet20 CIFAR-10 produces 64-dimensional features."""
        return 64

    @property
    def model_name(self) -> str:
        """Unique identifier for this model."""
        return "resnet20_cifar10"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from input images.

        Args:
            data: Images as numpy array [B, C, H, W] or torch tensor
                  Expected: CIFAR-10 format (32x32 RGB, normalized)

        Returns:
            np.ndarray: Features [B, 64] on CPU
        """
        # Convert to tensor if needed
        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data).float()

        # Move to device
        data = data.to(self._device)

        # Extract features
        with torch.no_grad():
            features = self._model(data, return_features=True)

        return features.cpu().numpy()

    def to(self, device: Union[str, torch.device]) -> 'ResNet20Extractor':
        """Move model to a different device."""
        self._device = torch.device(device)
        self._model = self._model.to(self._device)
        return self


# Verify protocol compliance
def _check_protocol():
    """Runtime check that ResNet20Extractor implements IFeatureExtractor."""
    assert isinstance(ResNet20Extractor('cpu'), IFeatureExtractor)


_check_protocol()
