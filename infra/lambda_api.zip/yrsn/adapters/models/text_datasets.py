"""
🔓 OPEN ADAPTER - Text Dataset Adapters

Text Dataset Adapters with R/S/N Label Mapping

These adapters load open-source text datasets and map their labels
to R/S/N ground truth for training the Universal Rotor.

Datasets:
- FEVER: Fact verification (SUPPORTS/REFUTES/NOT_ENOUGH_INFO)
- SQuAD v2: Question answering (answerable/unanswerable)
- MS MARCO: Passage ranking (relevance scores 0-3)

Usage:
    from yrsn.adapters.models.text_datasets import FEVERDatasetAdapter

    adapter = FEVERDatasetAdapter()
    samples = adapter.load_samples(num_samples=5000)
    # Returns: List[dict] with 'text', 'R', 'S', 'N' keys
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import json


@dataclass
class RSNSample:
    """Single text sample with R/S/N ground truth labels."""
    text: str
    R: float  # Relevance (0-1)
    S: float  # Superfluous (0-1)
    N: float  # Noise (0-1)
    source_label: str  # Original label from dataset
    dataset: str  # Source dataset name

    def __post_init__(self):
        """Validate simplex constraint: R + S + N = 1"""
        total = self.R + self.S + self.N
        if not (0.99 <= total <= 1.01):
            raise ValueError(f"R+S+N must equal 1.0, got {total}")


class FEVERDatasetAdapter:
    """
    🔓 OPEN - FEVER (Fact Extraction and VERification) Dataset Adapter

    Maps FEVER labels to R/S/N:
    - SUPPORTS: High R (0.8), Low S (0.15), Low N (0.05)
      → Claim is supported by evidence, highly relevant

    - REFUTES: Low R (0.1), Low S (0.1), High N (0.8)
      → Claim contradicted by evidence, high noise/error

    - NOT_ENOUGH_INFO: Low R (0.2), High S (0.7), Low N (0.1)
      → Evidence exists but doesn't answer claim, superfluous info

    Dataset: 185K samples, human-annotated
    Source: HuggingFace 'fever' dataset
    Paper: https://fever.ai/
    """

    def __init__(self, cache_dir: Optional[str] = None):
        """
        Args:
            cache_dir: Optional directory to cache downloaded dataset
        """
        self.cache_dir = cache_dir
        self._dataset = None

        # R/S/N mapping for FEVER labels
        self.label_mapping = {
            'SUPPORTS': {'R': 0.8, 'S': 0.15, 'N': 0.05},
            'REFUTES': {'R': 0.1, 'S': 0.1, 'N': 0.8},
            'NOT ENOUGH INFO': {'R': 0.2, 'S': 0.7, 'N': 0.1},
        }

    def _load_dataset(self):
        """Lazy load FEVER dataset from HuggingFace."""
        if self._dataset is not None:
            return

        try:
            from datasets import load_dataset
            print('Loading FEVER dataset from HuggingFace...')
            # Load train split (contains labeled data)
            self._dataset = load_dataset(
                'fever',
                'v1.0',
                split='train',
                cache_dir=self.cache_dir,
                trust_remote_code=True
            )
            print(f'[OK] Loaded {len(self._dataset)} FEVER samples')
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install: pip install datasets"
            )

    def load_samples(
        self,
        num_samples: int = 5000,
        balanced: bool = True,
        seed: int = 42
    ) -> List[RSNSample]:
        """
        Load FEVER samples with R/S/N labels.

        Args:
            num_samples: Number of samples to load
            balanced: If True, balance across label classes
            seed: Random seed for reproducibility

        Returns:
            List of RSNSample objects
        """
        self._load_dataset()

        # Set random seed
        np.random.seed(seed)

        samples = []

        if balanced:
            # Get equal samples from each label class
            samples_per_class = num_samples // 3

            for label in ['SUPPORTS', 'REFUTES', 'NOT ENOUGH INFO']:
                # Filter dataset by label
                label_indices = [
                    i for i, ex in enumerate(self._dataset)
                    if ex['label'] == label
                ]

                # Sample randomly
                selected = np.random.choice(
                    label_indices,
                    size=min(samples_per_class, len(label_indices)),
                    replace=False
                )

                for idx in selected:
                    example = self._dataset[int(idx)]
                    rsn = self.label_mapping[label]

                    # Combine claim + evidence as text
                    text = f"Claim: {example['claim']}"
                    if example.get('evidence'):
                        text += f" Evidence: {example['evidence']}"

                    samples.append(RSNSample(
                        text=text,
                        R=rsn['R'],
                        S=rsn['S'],
                        N=rsn['N'],
                        source_label=label,
                        dataset='FEVER'
                    ))
        else:
            # Sample uniformly from entire dataset
            indices = np.random.choice(
                len(self._dataset),
                size=min(num_samples, len(self._dataset)),
                replace=False
            )

            for idx in indices:
                example = self._dataset[int(idx)]
                label = example['label']

                if label not in self.label_mapping:
                    continue  # Skip unknown labels

                rsn = self.label_mapping[label]
                text = f"Claim: {example['claim']}"
                if example.get('evidence'):
                    text += f" Evidence: {example['evidence']}"

                samples.append(RSNSample(
                    text=text,
                    R=rsn['R'],
                    S=rsn['S'],
                    N=rsn['N'],
                    source_label=label,
                    dataset='FEVER'
                ))

        print(f'[OK] Loaded {len(samples)} FEVER samples')
        return samples


class SQuADDatasetAdapter:
    """
    🔓 OPEN - SQuAD v2.0 (Stanford Question Answering Dataset) Adapter

    Maps SQuAD labels to R/S/N:
    - Answerable (has answer): High R (0.85), Low S (0.1), Low N (0.05)
      → Context contains answer, highly relevant

    - Unanswerable: Low R (0.1), Low S (0.2), High N (0.7)
      → Context doesn't contain answer, high noise

    - Plausible answer (wrong): Low R (0.2), High S (0.65), Low N (0.15)
      → Context has related info but not the answer, superfluous

    Dataset: 150K questions, human-annotated
    Source: HuggingFace 'squad_v2' dataset
    """

    def __init__(self, cache_dir: Optional[str] = None):
        self.cache_dir = cache_dir
        self._dataset = None

        # R/S/N mapping
        self.label_mapping = {
            'answerable': {'R': 0.85, 'S': 0.1, 'N': 0.05},
            'unanswerable': {'R': 0.1, 'S': 0.2, 'N': 0.7},
        }

    def _load_dataset(self):
        """Lazy load SQuAD v2 from HuggingFace."""
        if self._dataset is not None:
            return

        try:
            from datasets import load_dataset
            print('Loading SQuAD v2 dataset from HuggingFace...')
            self._dataset = load_dataset(
                'squad_v2',
                split='train',
                cache_dir=self.cache_dir
            )
            print(f'[OK] Loaded {len(self._dataset)} SQuAD samples')
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install: pip install datasets"
            )

    def load_samples(
        self,
        num_samples: int = 5000,
        balanced: bool = True,
        seed: int = 42
    ) -> List[RSNSample]:
        """Load SQuAD samples with R/S/N labels."""
        self._load_dataset()
        np.random.seed(seed)

        samples = []

        if balanced:
            samples_per_class = num_samples // 2

            # Separate answerable vs unanswerable
            answerable_indices = [
                i for i, ex in enumerate(self._dataset)
                if len(ex['answers']['text']) > 0
            ]
            unanswerable_indices = [
                i for i, ex in enumerate(self._dataset)
                if len(ex['answers']['text']) == 0
            ]

            # Sample answerable
            selected = np.random.choice(
                answerable_indices,
                size=min(samples_per_class, len(answerable_indices)),
                replace=False
            )

            for idx in selected:
                example = self._dataset[int(idx)]
                rsn = self.label_mapping['answerable']

                text = f"Question: {example['question']} Context: {example['context']}"

                samples.append(RSNSample(
                    text=text,
                    R=rsn['R'],
                    S=rsn['S'],
                    N=rsn['N'],
                    source_label='answerable',
                    dataset='SQuAD_v2'
                ))

            # Sample unanswerable
            selected = np.random.choice(
                unanswerable_indices,
                size=min(samples_per_class, len(unanswerable_indices)),
                replace=False
            )

            for idx in selected:
                example = self._dataset[int(idx)]
                rsn = self.label_mapping['unanswerable']

                text = f"Question: {example['question']} Context: {example['context']}"

                samples.append(RSNSample(
                    text=text,
                    R=rsn['R'],
                    S=rsn['S'],
                    N=rsn['N'],
                    source_label='unanswerable',
                    dataset='SQuAD_v2'
                ))
        else:
            # Uniform sampling
            indices = np.random.choice(
                len(self._dataset),
                size=min(num_samples, len(self._dataset)),
                replace=False
            )

            for idx in indices:
                example = self._dataset[int(idx)]
                label = 'answerable' if len(example['answers']['text']) > 0 else 'unanswerable'
                rsn = self.label_mapping[label]

                text = f"Question: {example['question']} Context: {example['context']}"

                samples.append(RSNSample(
                    text=text,
                    R=rsn['R'],
                    S=rsn['S'],
                    N=rsn['N'],
                    source_label=label,
                    dataset='SQuAD_v2'
                ))

        print(f'[OK] Loaded {len(samples)} SQuAD samples')
        return samples


class MSMARCODatasetAdapter:
    """
    🔓 OPEN - MS MARCO (Microsoft MAchine Reading COmprehension) Adapter

    Maps relevance scores to R/S/N:
    - Score 3 (highly relevant): High R (0.9), Low S (0.08), Low N (0.02)
    - Score 2 (relevant): High R (0.7), Medium S (0.25), Low N (0.05)
    - Score 1 (somewhat relevant): Low R (0.3), High S (0.6), Low N (0.1)
    - Score 0 (not relevant): Low R (0.05), Low S (0.15), High N (0.8)

    Dataset: 8.8M passages with relevance judgments
    Source: HuggingFace 'ms_marco' dataset
    """

    def __init__(self, cache_dir: Optional[str] = None):
        self.cache_dir = cache_dir
        self._dataset = None

        # R/S/N mapping for relevance scores
        self.label_mapping = {
            3: {'R': 0.9, 'S': 0.08, 'N': 0.02},  # Highly relevant
            2: {'R': 0.7, 'S': 0.25, 'N': 0.05},  # Relevant
            1: {'R': 0.3, 'S': 0.6, 'N': 0.1},    # Somewhat relevant
            0: {'R': 0.05, 'S': 0.15, 'N': 0.8},  # Not relevant
        }

    def _load_dataset(self):
        """Lazy load MS MARCO from HuggingFace."""
        if self._dataset is not None:
            return

        try:
            from datasets import load_dataset
            print('Loading MS MARCO dataset from HuggingFace...')
            # Use 'v1.1' passage ranking task
            self._dataset = load_dataset(
                'ms_marco',
                'v1.1',
                split='train',
                cache_dir=self.cache_dir
            )
            print(f'[OK] Loaded {len(self._dataset)} MS MARCO samples')
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install: pip install datasets"
            )

    def load_samples(
        self,
        num_samples: int = 5000,
        balanced: bool = True,
        seed: int = 42
    ) -> List[RSNSample]:
        """Load MS MARCO samples with R/S/N labels."""
        self._load_dataset()
        np.random.seed(seed)

        samples = []

        if balanced:
            samples_per_score = num_samples // 4

            for score in [0, 1, 2, 3]:
                # Filter by relevance score
                score_indices = [
                    i for i, ex in enumerate(self._dataset)
                    if self._get_relevance_score(ex) == score
                ]

                if len(score_indices) == 0:
                    continue

                selected = np.random.choice(
                    score_indices,
                    size=min(samples_per_score, len(score_indices)),
                    replace=False
                )

                for idx in selected:
                    example = self._dataset[int(idx)]
                    rsn = self.label_mapping[score]

                    text = f"Query: {example['query']} Passage: {example['passages']['passage_text'][0]}"

                    samples.append(RSNSample(
                        text=text,
                        R=rsn['R'],
                        S=rsn['S'],
                        N=rsn['N'],
                        source_label=f'score_{score}',
                        dataset='MS_MARCO'
                    ))
        else:
            indices = np.random.choice(
                len(self._dataset),
                size=min(num_samples, len(self._dataset)),
                replace=False
            )

            for idx in indices:
                example = self._dataset[int(idx)]
                score = self._get_relevance_score(example)

                if score not in self.label_mapping:
                    continue

                rsn = self.label_mapping[score]
                text = f"Query: {example['query']} Passage: {example['passages']['passage_text'][0]}"

                samples.append(RSNSample(
                    text=text,
                    R=rsn['R'],
                    S=rsn['S'],
                    N=rsn['N'],
                    source_label=f'score_{score}',
                    dataset='MS_MARCO'
                ))

        print(f'[OK] Loaded {len(samples)} MS MARCO samples')
        return samples

    def _get_relevance_score(self, example: Dict) -> int:
        """Extract relevance score from MS MARCO example."""
        # MS MARCO labels passages as 0 (not selected) or 1 (selected)
        # Map binary to 4-level scale based on additional features
        is_selected = example['passages']['is_selected'][0]

        if is_selected == 1:
            # Selected passages are relevant (score 2-3)
            # Use passage rank as proxy for score
            return 3 if example['passages']['passage_text'][0][:100] in example['query'] else 2
        else:
            # Not selected (score 0-1)
            return 0


__all__ = [
    'RSNSample',
    'FEVERDatasetAdapter',
    'SQuADDatasetAdapter',
    'MSMARCODatasetAdapter',
]
