"""
Text RSN Adapter - Text Embeddings → RSN Extraction (STUB)

Hexagonal Architecture Implementation:
- Port: IRSNEncoder protocol (domain boundary)
- Adapter: TextRSNAdapter (text embedding integration)

This adapter extracts RSN from text embeddings using:
1. SentenceTransformerExtractor (384-dim embeddings)
2. Projection head (384 → 64, requires trained checkpoint)
3. HybridSimplexRotor (64 → RSN, P15 compliant)

CRITICAL: This adapter is ONLY functional when a trained projection
checkpoint exists. Without training, projection creates random weights
leading to non-deterministic RSN.

Usage:
    # Only use if you have a trained projection checkpoint
    checkpoint_path = "trained_projections/text_to_rsn.pt"
    if os.path.exists(checkpoint_path):
        adapter = TextRSNAdapter(checkpoint_path=checkpoint_path)
        rsn = adapter.encode_rsn("Analyze this text...")
    else:
        # Use MIMO adapter instead
        adapter = MIMORSNAdapter()

Status: STUB - Projection training not implemented yet
"""

import os
import time
import logging
from typing import Dict, Optional
import numpy as np

logger = logging.getLogger(__name__)

# Version
TEXT_RSN_ADAPTER_VERSION = "1.0.0-stub"


class TextRSNAdapter:
    """
    Text-based RSN encoder implementing IRSNEncoder protocol.

    STUB IMPLEMENTATION: Requires trained projection checkpoint.
    Falls back to warning until projection training implemented.

    Architecture:
    - SentenceTransformer → 384-dim embedding
    - Projection head → 64-dim features (REQUIRES TRAINING)
    - HybridSimplexRotor → RSN (P15 compliant)
    """

    def __init__(
        self,
        checkpoint_path: Optional[str] = None,
        rotor_checkpoint: Optional[str] = None,
        device: str = "cpu",
    ):
        """
        Initialize text RSN adapter.

        Parameters
        ----------
        checkpoint_path : Optional[str]
            Path to trained projection checkpoint (384→64)
            If None, uses TEXT_PROJECTION_CHECKPOINT env var
        rotor_checkpoint : Optional[str]
            Path to HybridSimplexRotor checkpoint
            If None, uses ROTOR_CHECKPOINT env var
        device : str
            Device for computation (cpu/cuda)
        """
        self.checkpoint_path = checkpoint_path or os.environ.get(
            "TEXT_PROJECTION_CHECKPOINT"
        )
        self.rotor_checkpoint = rotor_checkpoint or os.environ.get(
            "ROTOR_CHECKPOINT",
            "trained_rotor_universal64.pt"
        )
        self.device = device

        # Check if functional
        self._is_functional = (
            self.checkpoint_path is not None
            and os.path.exists(self.checkpoint_path)
        )

        if not self._is_functional:
            logger.warning(
                "TextRSNAdapter is NOT functional: "
                "No trained projection checkpoint found. "
                "Set TEXT_PROJECTION_CHECKPOINT env var or use MIMORSNAdapter. "
                "Untrained projection creates random weights → non-deterministic RSN."
            )

        # Lazy initialization
        self._extractor = None
        self._projection = None
        self._rotor = None

    def _init_components(self):
        """Lazy initialization of components."""
        if self._extractor is not None:
            return  # Already initialized

        # Import here to avoid dependency if not used
        try:
            from yrsn.adapters.models.text_adapter import SentenceTransformerExtractor
            from yrsn.core.decomposition import HybridSimplexRotor
            import torch
            import torch.nn as nn

            # Text extractor (384-dim)
            self._extractor = SentenceTransformerExtractor(device=self.device)

            # Projection head (384 → 64)
            self._projection = nn.Linear(384, 64).to(self.device)

            if self._is_functional:
                # Load trained weights
                checkpoint = torch.load(self.checkpoint_path, map_location=self.device)
                self._projection.load_state_dict(checkpoint)
                logger.info(f"Loaded projection from {self.checkpoint_path}")
            else:
                logger.warning(
                    "Using UNTRAINED projection - RSN will be non-deterministic!"
                )

            # HybridSimplexRotor (64 → RSN)
            self._rotor = HybridSimplexRotor(embed_dim=64)
            if os.path.exists(self.rotor_checkpoint):
                self._rotor.load_state_dict(
                    torch.load(self.rotor_checkpoint, map_location=self.device)
                )
                logger.info(f"Loaded rotor from {self.rotor_checkpoint}")
            else:
                logger.warning(
                    f"Rotor checkpoint not found: {self.rotor_checkpoint}"
                )

        except ImportError as e:
            raise ImportError(
                f"Text RSN adapter dependencies missing: {e}. "
                "Install with: pip install sentence-transformers torch"
            )

    def encode_rsn(self, context: str) -> Dict[str, float]:
        """
        Extract RSN from text context.

        WARNING: This is a STUB. Only use if checkpoint_path exists.

        Parameters
        ----------
        context : str
            Input text to analyze

        Returns
        -------
        Dict[str, float]
            RSN decomposition with metadata
        """
        if not self._is_functional:
            raise RuntimeError(
                "TextRSNAdapter is not functional: No trained projection checkpoint. "
                "Use MIMORSNAdapter instead or train projection head first."
            )

        start_time = time.time()

        # Initialize components
        self._init_components()

        # Extract text embedding (384-dim)
        import torch
        embedding_384 = self._extractor.extract([context])  # [1, 384]
        embedding_tensor = torch.tensor(embedding_384, dtype=torch.float32).to(self.device)

        # Project to 64-dim
        with torch.no_grad():
            embedding_64 = self._projection(embedding_tensor)  # [1, 64]

        # Rotor decomposition (64 → RSN)
        with torch.no_grad():
            output = self._rotor(embedding_64)

        # Build result
        latency_ms = (time.time() - start_time) * 1000

        return {
            # Core RSN
            "R": float(output["R"].item()),
            "S": float(output["S"].item()),
            "N": float(output["N"].item()),
            # Derived metrics
            "alpha": float(output.get("alpha", torch.tensor(0.0)).item()),
            "kappa": float(output.get("kappa", torch.tensor(0.5)).item()),
            "sigma": float(output.get("sigma", torch.tensor(0.1)).item()),
            # Metadata
            "_source": "text_rsn_adapter",
            "_p15_compliant": self._is_functional,  # Only if trained projection
            "_version": TEXT_RSN_ADAPTER_VERSION,
            "_latency_ms": latency_ms,
            "_checkpoint": self.checkpoint_path if self._is_functional else None,
        }

    def validate_semantic(self, context: str, rsn: Dict[str, float]) -> bool:
        """
        Validate RSN extraction.

        For text adapter, semantic validation is LIMITED:
        - Can check simplex constraint
        - Can check P15 compliance
        - CANNOT prove I(encoding, problem) > 0 as strongly as MIMO
          (no reasoning trace to validate)

        Parameters
        ----------
        context : str
            Original context
        rsn : Dict[str, float]
            Extracted RSN

        Returns
        -------
        bool
            True if valid (but weaker guarantee than MIMO)
        """
        # Check simplex
        simplex_sum = rsn.get("R", 0) + rsn.get("S", 0) + rsn.get("N", 0)
        if abs(simplex_sum - 1.0) > 0.01:
            logger.warning(f"RSN not on simplex: R+S+N={simplex_sum}")
            return False

        # Check source
        if rsn.get("_source") != "text_rsn_adapter":
            logger.warning(f"RSN source mismatch: {rsn.get('_source')}")
            return False

        # Check P15 compliance (requires trained checkpoint)
        if not rsn.get("_p15_compliant"):
            logger.warning("RSN not P15 compliant (untrained projection)")
            return False

        # NOTE: We CANNOT validate I(encoding, problem) > 0 without reasoning
        # This is why MIMO is preferred for production

        return True

    @property
    def dim(self) -> int:
        """Dimension of output (N/A for RSN encoder)."""
        return 0  # RSN is 3-dim simplex, but returns dict not vector

    @property
    def is_functional(self) -> bool:
        """Check if adapter has trained checkpoint."""
        return self._is_functional


__all__ = ["TextRSNAdapter"]
