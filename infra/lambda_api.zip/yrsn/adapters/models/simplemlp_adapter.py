"""
SimpleMLP Feature Extractor Adapter

Implements IFeatureExtractor for a simple MLP.
"""

from typing import Union, Optional
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn

from yrsn.ports.feature_extraction import IFeatureExtractor


class SimpleMLP(nn.Module):
    """
    Simple MLP for architecture comparison.

    Architecture:
        Flatten
        Linear(3072, 512) -> BN -> ReLU -> Dropout
        Linear(512, 256) -> BN -> ReLU -> Dropout
        Linear(256, output_dim)
        Linear(output_dim, 10)  # classifier
    """

    def __init__(self, input_dim: int = 3072, output_dim: int = 64):
        super().__init__()
        self.features = nn.Sequential(
            nn.Flatten(),
            nn.Linear(input_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, output_dim),
        )
        self.classifier = nn.Linear(output_dim, 10)

    def forward(self, x, return_features: bool = False):
        feat = self.features(x)
        if return_features:
            return feat
        return self.classifier(feat)


class SimpleMLPExtractor:
    """
    Adapter implementing IFeatureExtractor for SimpleMLP.

    Args:
        device: Device to run model on
        input_dim: Input dimension (default: 3072 for CIFAR-10 flattened)
        output_dim: Feature dimension (default: 64 for compatibility)

    Example:
        # From checkpoint
        extractor = SimpleMLPExtractor.from_checkpoint('checkpoints/simple_mlp.pt')

        # Fresh model (random weights)
        extractor = SimpleMLPExtractor(device='cuda')
    """

    def __init__(
        self,
        device: Union[str, torch.device] = 'cpu',
        input_dim: int = 3072,
        output_dim: int = 64
    ):
        self._device = torch.device(device)
        self._input_dim = input_dim
        self._output_dim = output_dim
        self._model = SimpleMLP(input_dim=input_dim, output_dim=output_dim).to(self._device)
        self._model.eval()

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Union[str, Path],
        device: Union[str, torch.device] = 'cpu'
    ) -> 'SimpleMLPExtractor':
        """
        Create extractor from a trained checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file
            device: Device to load model on

        Returns:
            SimpleMLPExtractor with loaded weights
        """
        device = torch.device(device)
        checkpoint = torch.load(checkpoint_path, map_location=device)

        # Create extractor
        extractor = cls(device=device, output_dim=64)

        # Load weights
        extractor._model.load_state_dict(checkpoint['model_state_dict'])
        extractor._model.eval()

        return extractor

    @property
    def feature_dim(self) -> int:
        """SimpleMLP feature dimension."""
        return self._output_dim

    @property
    def model_name(self) -> str:
        """Unique identifier for this model."""
        return "simple_mlp"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from input images.

        Args:
            data: Images [B, C, H, W] or flattened [B, 3072]

        Returns:
            np.ndarray: Features [B, feature_dim]
        """
        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data).float()

        data = data.to(self._device)

        with torch.no_grad():
            features = self._model(data, return_features=True)

        return features.cpu().numpy()

    def to(self, device: Union[str, torch.device]) -> 'SimpleMLPExtractor':
        """Move model to a different device."""
        self._device = torch.device(device)
        self._model = self._model.to(self._device)
        return self


# Verify protocol compliance
def _check_protocol():
    """Runtime check that SimpleMLPExtractor implements IFeatureExtractor."""
    assert isinstance(SimpleMLPExtractor('cpu'), IFeatureExtractor)


_check_protocol()
