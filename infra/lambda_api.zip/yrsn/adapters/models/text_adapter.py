"""
🔓 OPEN ADAPTER - Anyone can implement/modify

Text Feature Extractors - Adapters for Text Embeddings

This adapter connects text models to the YRSN system.
Implements the IFeatureExtractor port (patent boundary).

What you CAN do:
✅ Use this adapter as-is
✅ Modify it for your text model
✅ Write your own text adapter following IFeatureExtractor
✅ Share your adapter with others
✅ Keep your custom adapter private

Implements IFeatureExtractor for text models:
- SentenceTransformerExtractor: Uses sentence-transformers (lightweight)
- DistilBERTExtractor: Uses HuggingFace DistilBERT

Usage:
    from yrsn.adapters.models.text_adapter import SentenceTransformerExtractor

    extractor = SentenceTransformerExtractor()
    features = extractor.extract(texts)  # [B, 384]
"""

import numpy as np
from typing import List, Union, Optional
from pathlib import Path

import torch
import torch.nn as nn


class SentenceTransformerExtractor:
    """
    🔓 OPEN - Text feature extractor using SentenceTransformers

    Simple explanation:
        - Takes text (e.g., "Hello world")
        - Converts to 384 numbers
        - Normalizes to unit length
        - Passes to rotor for quality scoring

    What it does:
        Input: "The quick brown fox"
        Output: [0.012, -0.034, 0.056, ...] (384 numbers)

    Lightweight alternative to full BERT models. Uses all-MiniLM-L6-v2
    by default (384-dim embeddings, ~80MB).

    Implements IFeatureExtractor port (🔒 patent boundary).
    """

    def __init__(
        self,
        model_name: str = 'all-MiniLM-L6-v2',
        device: str = 'cpu',
    ):
        """
        Args:
            model_name: sentence-transformers model name
            device: torch device
        """
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(model_name, device=device)
            self._device = device
            self._model_name_str = model_name
        except ImportError:
            raise ImportError(
                "sentence-transformers required. Install with: "
                "pip install sentence-transformers"
            )

    @property
    def feature_dim(self) -> int:
        return self._model.get_sentence_embedding_dimension()

    @property
    def model_name(self) -> str:
        return f"sentence_transformer_{self._model_name_str}"

    def extract(self, data: Union[List[str], np.ndarray]) -> np.ndarray:
        """
        Extract features from text.

        Args:
            data: List of strings or array of strings

        Returns:
            np.ndarray: Features [B, feature_dim]
        """
        if isinstance(data, np.ndarray):
            data = data.tolist()

        embeddings = self._model.encode(
            data,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return embeddings.astype(np.float32)


class DistilBERTExtractor:
    """
    Feature extractor using HuggingFace DistilBERT.

    Uses [CLS] token embedding (768-dim).
    """

    def __init__(
        self,
        model_name: str = 'distilbert-base-uncased',
        device: str = 'cpu',
        max_length: int = 128,
    ):
        """
        Args:
            model_name: HuggingFace model name
            device: torch device
            max_length: Maximum sequence length
        """
        try:
            from transformers import DistilBertModel, DistilBertTokenizer
            self._tokenizer = DistilBertTokenizer.from_pretrained(model_name)
            self._model = DistilBertModel.from_pretrained(model_name)
            self._model.to(device)
            self._model.eval()
            self._device = device
            self._max_length = max_length
            self._model_name_str = model_name
        except ImportError:
            raise ImportError(
                "transformers required. Install with: pip install transformers"
            )

    @property
    def feature_dim(self) -> int:
        return 768  # DistilBERT hidden size

    @property
    def model_name(self) -> str:
        return f"distilbert_{self._model_name_str}"

    def extract(self, data: Union[List[str], np.ndarray]) -> np.ndarray:
        """
        Extract features from text using [CLS] token.

        Args:
            data: List of strings or array of strings

        Returns:
            np.ndarray: Features [B, 768]
        """
        if isinstance(data, np.ndarray):
            data = data.tolist()

        # Tokenize
        inputs = self._tokenizer(
            data,
            padding=True,
            truncation=True,
            max_length=self._max_length,
            return_tensors='pt',
        )

        # Move to device
        inputs = {k: v.to(self._device) for k, v in inputs.items()}

        # Extract features
        with torch.no_grad():
            outputs = self._model(**inputs)
            # Use [CLS] token (first token)
            cls_embeddings = outputs.last_hidden_state[:, 0, :]

        return cls_embeddings.cpu().numpy().astype(np.float32)


class TextMLPExtractor:
    """
    Lightweight MLP-based text feature extractor.

    Projects pre-computed embeddings to a standard dimension.
    Useful when sentence-transformers/BERT is too heavy.
    """

    def __init__(
        self,
        input_dim: int = 384,
        output_dim: int = 64,
        checkpoint_path: Optional[str] = None,
        device: str = 'cpu',
    ):
        """
        Args:
            input_dim: Input embedding dimension
            output_dim: Output feature dimension
            checkpoint_path: Path to trained MLP checkpoint
            device: torch device
        """
        self._device = device
        self._input_dim = input_dim
        self._output_dim = output_dim

        self._model = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(128, output_dim),
        ).to(device)

        if checkpoint_path and Path(checkpoint_path).exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            self._model.load_state_dict(checkpoint['model_state_dict'])

        self._model.eval()

    @property
    def feature_dim(self) -> int:
        return self._output_dim

    @property
    def model_name(self) -> str:
        return f"text_mlp_{self._input_dim}to{self._output_dim}"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from pre-computed embeddings.

        Args:
            data: Pre-computed embeddings [B, input_dim]

        Returns:
            np.ndarray: Features [B, output_dim]
        """
        with torch.no_grad():
            inputs = torch.tensor(data, dtype=torch.float32).to(self._device)
            outputs = self._model(inputs)
        return outputs.cpu().numpy().astype(np.float32)


__all__ = [
    "SentenceTransformerExtractor",
    "DistilBERTExtractor",
    "TextMLPExtractor",
]
