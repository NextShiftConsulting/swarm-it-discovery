"""
SimpleCNN Feature Extractor Adapter

Implements IFeatureExtractor for a simple 3-layer CNN.
"""

from typing import Union, Optional
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn

from yrsn.ports.feature_extraction import IFeatureExtractor


class SimpleCNN(nn.Module):
    """
    Simple 3-layer CNN for architecture comparison.

    Architecture:
        Conv2d(3, 32) -> BN -> ReLU -> MaxPool
        Conv2d(32, 64) -> BN -> ReLU -> MaxPool
        Conv2d(64, 128) -> BN -> ReLU -> AdaptiveAvgPool
        Linear(128, output_dim)
        Linear(output_dim, 10)  # classifier
    """

    def __init__(self, output_dim: int = 64):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Linear(128, output_dim)
        self.classifier = nn.Linear(output_dim, 10)

    def forward(self, x, return_features: bool = False):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        feat = self.fc(x)
        if return_features:
            return feat
        return self.classifier(feat)


class SimpleCNNExtractor:
    """
    Adapter implementing IFeatureExtractor for SimpleCNN.

    Args:
        device: Device to run model on
        output_dim: Feature dimension (default: 64 for compatibility)

    Example:
        # From checkpoint
        extractor = SimpleCNNExtractor.from_checkpoint('checkpoints/simple_cnn.pt')

        # Fresh model (random weights)
        extractor = SimpleCNNExtractor(device='cuda')
    """

    def __init__(
        self,
        device: Union[str, torch.device] = 'cpu',
        output_dim: int = 64
    ):
        self._device = torch.device(device)
        self._output_dim = output_dim
        self._model = SimpleCNN(output_dim=output_dim).to(self._device)
        self._model.eval()

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Union[str, Path],
        device: Union[str, torch.device] = 'cpu'
    ) -> 'SimpleCNNExtractor':
        """
        Create extractor from a trained checkpoint.

        Args:
            checkpoint_path: Path to checkpoint file
            device: Device to load model on

        Returns:
            SimpleCNNExtractor with loaded weights
        """
        device = torch.device(device)
        checkpoint = torch.load(checkpoint_path, map_location=device)

        # Create extractor
        extractor = cls(device=device, output_dim=64)

        # Load weights
        extractor._model.load_state_dict(checkpoint['model_state_dict'])
        extractor._model.eval()

        return extractor

    @property
    def feature_dim(self) -> int:
        """SimpleCNN feature dimension."""
        return self._output_dim

    @property
    def model_name(self) -> str:
        """Unique identifier for this model."""
        return "simple_cnn"

    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from input images.

        Args:
            data: Images [B, C, H, W] as numpy or tensor

        Returns:
            np.ndarray: Features [B, feature_dim]
        """
        if isinstance(data, np.ndarray):
            data = torch.from_numpy(data).float()

        data = data.to(self._device)

        with torch.no_grad():
            features = self._model(data, return_features=True)

        return features.cpu().numpy()

    def to(self, device: Union[str, torch.device]) -> 'SimpleCNNExtractor':
        """Move model to a different device."""
        self._device = torch.device(device)
        self._model = self._model.to(self._device)
        return self


# Verify protocol compliance
def _check_protocol():
    """Runtime check that SimpleCNNExtractor implements IFeatureExtractor."""
    assert isinstance(SimpleCNNExtractor('cpu'), IFeatureExtractor)


_check_protocol()
