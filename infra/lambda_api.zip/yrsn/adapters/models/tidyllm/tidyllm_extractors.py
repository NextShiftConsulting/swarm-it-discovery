"""
TidyLLM Feature Extractors for YRSN
====================================

Adapts tidyllm function-based extractors to YRSN's IFeatureExtractor interface.
"""

import numpy as np
from typing import List, Optional, Any, Union
from yrsn.ports.feature_extraction import IFeatureExtractor
from . import tfidf, lsa, transformer, word_avg, ngram


class TidyLLMExtractor(IFeatureExtractor):
    """
    Adapter: tidyllm function API → YRSN IFeatureExtractor interface

    Handles fit/transform pattern and converts to stateful .extract() method.
    """

    EXTRACTORS = {
        'tfidf': tfidf,
        'lsa': lsa,
        'transformer': transformer,
        'word_avg': word_avg,
        'ngram': ngram,
    }

    # Some modules use prefix naming (transformer_fit_transform, transformer_transform)
    PREFIXED_MODULES = {'transformer', 'word_avg', 'ngram'}

    def __init__(self, extractor_name: str, **kwargs):
        if extractor_name not in self.EXTRACTORS:
            raise ValueError(f"Unknown extractor: {extractor_name}. Choose from {list(self.EXTRACTORS.keys())}")

        self.extractor_name = extractor_name
        self.module = self.EXTRACTORS[extractor_name]
        self.kwargs = kwargs
        self.model = None
        self._is_fit = False
        self._output_dim = None

        # Determine function names based on module naming convention
        if extractor_name in self.PREFIXED_MODULES:
            self._fit_transform_fn = getattr(self.module, f'{extractor_name}_fit_transform')
            self._transform_fn = getattr(self.module, f'{extractor_name}_transform')
        else:
            self._fit_transform_fn = self.module.fit_transform
            self._transform_fn = self.module.transform

    def fit(self, texts: Union[List[str], np.ndarray]) -> np.ndarray:
        """Fit extractor on training texts and return embeddings"""
        # Convert to list if needed
        if isinstance(texts, np.ndarray):
            texts = texts.tolist()

        embeddings, self.model = self._fit_transform_fn(texts, **self.kwargs)
        self._is_fit = True

        # Convert to numpy array
        embeddings_arr = np.array(embeddings, dtype=np.float32)
        self._output_dim = embeddings_arr.shape[1] if len(embeddings_arr.shape) > 1 else len(embeddings_arr[0])

        return embeddings_arr

    def extract(self, texts: Union[List[str], np.ndarray]) -> np.ndarray:
        """
        IFeatureExtractor interface

        Auto-fits on first call if not already fit.
        """
        # Convert to list if needed
        if isinstance(texts, np.ndarray):
            texts = texts.tolist()

        if not self._is_fit:
            return self.fit(texts)

        # Transform using fitted model
        embeddings = self._transform_fn(texts, self.model)
        return np.array(embeddings, dtype=np.float32)

    @property
    def modality(self) -> str:
        return "text"

    @property
    def output_dim(self) -> Optional[int]:
        return self._output_dim if self._is_fit else None


# Convenience classes for each extractor type
class TFIDFExtractor(TidyLLMExtractor):
    """TF-IDF text extractor (fast, interpretable)"""
    def __init__(self, **kwargs):
        super().__init__('tfidf', **kwargs)


class LSAExtractor(TidyLLMExtractor):
    """LSA text extractor (dimensionality reduction)"""
    def __init__(self, n_components: int = 100, **kwargs):
        super().__init__('lsa', n_components=n_components, **kwargs)


class TransformerTFIDFExtractor(TidyLLMExtractor):
    """Transformer-enhanced TF-IDF (context-aware)"""
    def __init__(self, attention_heads: int = 4, max_seq_len: int = 64, **kwargs):
        super().__init__('transformer', attention_heads=attention_heads, max_seq_len=max_seq_len, **kwargs)


class WordAvgExtractor(TidyLLMExtractor):
    """Word averaging with IDF weighting"""
    def __init__(self, embedding_dim: int = 100, use_idf: bool = True, **kwargs):
        super().__init__('word_avg', embedding_dim=embedding_dim, use_idf=use_idf, **kwargs)


class NGramExtractor(TidyLLMExtractor):
    """N-gram character/word embeddings"""
    def __init__(self, n: int = 3, ngram_type: str = 'char', **kwargs):
        super().__init__('ngram', n=n, ngram_type=ngram_type, **kwargs)
