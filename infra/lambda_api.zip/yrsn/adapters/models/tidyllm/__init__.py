"""
YRSN-TidyLLM Unified Module
===========================

Bundles tidyllm repos (tlm, tidyllm-sentence) as a single YRSN-compatible module.

Usage:
    from yrsn.adapters.models.tidyllm import TidyLLMExtractor, tlm

    # Use tlm for ML operations
    similarity = tlm.cosine_similarity(vec1, vec2)

    # Use extractors for text embeddings
    extractor = TidyLLMExtractor('tfidf')
    embeddings = extractor.extract(texts)
"""

import sys
from pathlib import Path

# Add tidyllm dependencies to Python path
_tlm_path = Path(r'C:\Users\marti\github\tlm')
_tidyllm_sentence_path = Path(r'C:\Users\marti\github\tidyllm-sentence')

if _tlm_path.exists():
    sys.path.insert(0, str(_tlm_path))
else:
    raise ImportError(f"tlm not found at {_tlm_path}")

if _tidyllm_sentence_path.exists():
    sys.path.insert(0, str(_tidyllm_sentence_path))
else:
    raise ImportError(f"tidyllm-sentence not found at {_tidyllm_sentence_path}")

# Import core dependencies
try:
    import tlm
except ImportError as e:
    raise ImportError(
        f"Failed to import tlm. Ensure tlm is installed at {_tlm_path}. "
        f"Error: {e}"
    )

try:
    from tidyllm_sentence.tfidf import embeddings as tfidf
    from tidyllm_sentence.lsa import embeddings as lsa
    from tidyllm_sentence.transformer import embeddings as transformer
    from tidyllm_sentence.word_avg import embeddings as word_avg
    from tidyllm_sentence.ngram import embeddings as ngram
except ImportError as e:
    raise ImportError(
        f"Failed to import tidyllm_sentence. Ensure tidyllm-sentence is installed at {_tidyllm_sentence_path}. "
        f"Error: {e}"
    )

# Import extractor adapters
from .tidyllm_extractors import (
    TidyLLMExtractor,
    TFIDFExtractor,
    LSAExtractor,
    TransformerTFIDFExtractor,
    WordAvgExtractor,
    NGramExtractor,
)

# Export main components
__all__ = [
    'tlm',
    'tfidf',
    'lsa',
    'transformer',
    'word_avg',
    'ngram',
    'TidyLLMExtractor',
    'TFIDFExtractor',
    'LSAExtractor',
    'TransformerTFIDFExtractor',
    'WordAvgExtractor',
    'NGramExtractor',
]
