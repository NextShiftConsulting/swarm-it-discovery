"""
PubMed Adapter for Medical Privacy Dataset

Fetches medical abstracts from PubMed (NCBI) for zkMEM privacy experiments.

Data Source: PubMed (35M medical abstracts)
API: NCBI Entrez E-utilities (free, no key required for <3 requests/second)
Privacy Risk: R/S/N decomposition reveals patient diagnosis (HIPAA violation)

Example:
    adapter = PubMedAdapter(email="researcher@example.com")
    queries = adapter.fetch_queries(n_queries=1000)
    result = adapter.execute_query(queries[0])
    print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
"""

import time
import json
import re
from typing import List, Optional, Dict, Any
from collections import Counter
import random

from yrsn.ports.zkp_data_source import (
    ZKPDataSource,
    PrivacyQuery,
    RetrievedDocument,
    SensitivityLevel
)


class PubMedAdapter(ZKPDataSource):
    """
    PubMed adapter for medical privacy queries.

    Uses NCBI Entrez E-utilities API (free, no key required).
    Rate limit: 3 requests/second without API key, 10 requests/second with key.
    """

    # Medical condition templates by sensitivity
    CONDITION_TEMPLATES = {
        SensitivityLevel.HIGH: [
            # Terminal/highly sensitive
            ("stage 3 lung cancer", "lung_cancer"),
            ("stage 4 pancreatic cancer", "pancreatic_cancer"),
            ("HIV antiretroviral therapy", "HIV"),
            ("AIDS opportunistic infections", "AIDS"),
            ("BRCA1 mutation breast cancer", "BRCA1_mutation"),
            ("BRCA2 mutation ovarian cancer", "BRCA2_mutation"),
            ("metastatic melanoma", "melanoma"),
            ("glioblastoma multiforme", "glioblastoma"),
            ("acute lymphoblastic leukemia", "leukemia"),
            ("Huntington disease progression", "huntingtons"),
            ("amyotrophic lateral sclerosis", "ALS"),
            ("Creutzfeldt-Jakob disease", "CJD"),
            ("hepatitis C cirrhosis", "hepatitis_C"),
            ("opioid addiction treatment", "opioid_addiction"),
            ("severe bipolar disorder", "bipolar"),
            ("schizophrenia treatment-resistant", "schizophrenia"),
        ],
        SensitivityLevel.MEDIUM: [
            # Chronic but not terminal
            ("type 2 diabetes management", "diabetes_T2"),
            ("type 1 diabetes insulin therapy", "diabetes_T1"),
            ("hypertension treatment guidelines", "hypertension"),
            ("rheumatoid arthritis biologics", "rheumatoid_arthritis"),
            ("multiple sclerosis disease-modifying", "multiple_sclerosis"),
            ("Parkinson disease dopamine", "parkinsons"),
            ("asthma inhaled corticosteroids", "asthma"),
            ("chronic obstructive pulmonary disease", "COPD"),
            ("heart failure ACE inhibitors", "heart_failure"),
            ("atrial fibrillation anticoagulation", "atrial_fibrillation"),
            ("Crohn disease anti-TNF", "crohns"),
            ("ulcerative colitis", "ulcerative_colitis"),
            ("chronic kidney disease", "CKD"),
            ("epilepsy antiepileptic drugs", "epilepsy"),
            ("major depressive disorder", "depression"),
            ("generalized anxiety disorder", "anxiety"),
        ],
        SensitivityLevel.LOW: [
            # Minor/common conditions
            ("common cold symptomatic treatment", "common_cold"),
            ("seasonal allergic rhinitis", "allergies"),
            ("vitamin D deficiency", "vitamin_D"),
            ("acute sinusitis antibiotics", "sinusitis"),
            ("acute bronchitis", "bronchitis"),
            ("gastroesophageal reflux disease", "GERD"),
            ("migraine headache prophylaxis", "migraine"),
            ("lower back pain", "back_pain"),
            ("osteoarthritis knee", "osteoarthritis"),
            ("insomnia cognitive behavioral", "insomnia"),
        ]
    }

    def __init__(self, email: Optional[str] = None, api_key: Optional[str] = None, api_keys: Optional[Dict[str, str]] = None):
        """
        Initialize PubMed adapter.

        Args:
            email: Required by NCBI (for tracking, not authentication)
            api_key: Optional NCBI API key (increases rate limit to 10 req/s)
            api_keys: Optional dict with 'ncbi_email' and 'ncbi_api_key'
        """
        # Handle api_keys dict from factory
        if api_keys:
            self.email = api_keys.get('ncbi_email', 'researcher@example.com')
            self.api_key = api_keys.get('ncbi_api_key', None)
        else:
            self.email = email or 'researcher@example.com'
            self.api_key = api_key

        self.base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
        self.rate_limit = 0.34 if self.api_key else 0.34  # 3 req/s without key, 10 req/s with key

        # Try to import biopython (optional)
        try:
            from Bio import Entrez
            Entrez.email = self.email
            if self.api_key:
                Entrez.api_key = self.api_key
            self.entrez = Entrez
            self.use_biopython = True
        except ImportError:
            print("WARNING: Biopython not installed. Falling back to direct HTTP requests.")
            self.use_biopython = False

    def fetch_queries(
        self,
        n_queries: int,
        sensitivity_distribution: Optional[Dict[SensitivityLevel, float]] = None
    ) -> List[PrivacyQuery]:
        """
        Generate medical queries from templates.

        Args:
            n_queries: Number of queries to generate
            sensitivity_distribution: Distribution over sensitivity levels
                                     (default: 50% high, 40% medium, 10% low)

        Returns:
            List of PrivacyQuery objects with medical diagnosis labels
        """
        if sensitivity_distribution is None:
            sensitivity_distribution = {
                SensitivityLevel.HIGH: 0.50,
                SensitivityLevel.MEDIUM: 0.40,
                SensitivityLevel.LOW: 0.10
            }

        # Compute counts per sensitivity level
        sensitivity_counts = {
            level: int(n_queries * prob)
            for level, prob in sensitivity_distribution.items()
        }

        # Adjust for rounding
        total_assigned = sum(sensitivity_counts.values())
        if total_assigned < n_queries:
            sensitivity_counts[SensitivityLevel.HIGH] += (n_queries - total_assigned)

        queries = []
        for sensitivity, count in sensitivity_counts.items():
            templates = self.CONDITION_TEMPLATES[sensitivity]

            # Sample with replacement if count > available templates
            sampled_templates = random.choices(templates, k=count)

            for query_text, label in sampled_templates:
                query = PrivacyQuery(
                    query=query_text,
                    label=label,
                    sensitivity=sensitivity,
                    domain="medical",
                    metadata={'source': 'pubmed'}
                )
                queries.append(query)

        # Shuffle queries
        random.shuffle(queries)
        return queries

    def retrieve_documents(
        self,
        query: PrivacyQuery,
        top_k: int = 100
    ) -> List[RetrievedDocument]:
        """
        Retrieve PubMed abstracts for a medical query.

        Args:
            query: PrivacyQuery object
            top_k: Number of abstracts to retrieve

        Returns:
            List of RetrievedDocument objects
        """
        if self.use_biopython:
            return self._retrieve_with_biopython(query, top_k)
        else:
            return self._retrieve_with_http(query, top_k)

    def _retrieve_with_biopython(self, query: PrivacyQuery, top_k: int) -> List[RetrievedDocument]:
        """Retrieve using Biopython Entrez"""
        from Bio import Entrez

        # Search PubMed
        time.sleep(self.rate_limit)
        search_handle = Entrez.esearch(
            db="pubmed",
            term=query.query,
            retmax=top_k,
            sort="relevance"
        )
        search_results = Entrez.read(search_handle)
        search_handle.close()
        pmids = search_results['IdList']

        if not pmids:
            return []

        # Fetch abstracts
        time.sleep(self.rate_limit)
        fetch_handle = Entrez.efetch(
            db="pubmed",
            id=pmids,
            rettype="abstract",
            retmode="xml"
        )
        records = Entrez.read(fetch_handle)
        fetch_handle.close()

        documents = []
        for i, record in enumerate(records['PubmedArticle']):
            try:
                article = record['MedlineCitation']['Article']
                pmid = str(record['MedlineCitation']['PMID'])

                title = article.get('ArticleTitle', '')
                abstract_sections = article.get('Abstract', {}).get('AbstractText', [])

                # Combine abstract sections
                if isinstance(abstract_sections, list):
                    abstract = ' '.join([str(section) for section in abstract_sections])
                else:
                    abstract = str(abstract_sections)

                # Compute relevance score (simple: position-based)
                relevance_score = 1.0 - (i / top_k)

                doc = RetrievedDocument(
                    doc_id=f"PMID:{pmid}",
                    title=title,
                    abstract=abstract,
                    relevance_score=relevance_score,
                    source="PubMed",
                    metadata={'pmid': pmid, 'rank': i}
                )
                documents.append(doc)
            except (KeyError, IndexError) as e:
                # Skip malformed records
                continue

        return documents

    def _retrieve_with_http(self, query: PrivacyQuery, top_k: int) -> List[RetrievedDocument]:
        """Fallback: Retrieve using direct HTTP requests"""
        import requests
        import xml.etree.ElementTree as ET

        # Search
        search_url = f"{self.base_url}/esearch.fcgi"
        search_params = {
            'db': 'pubmed',
            'term': query.query,
            'retmax': top_k,
            'retmode': 'json',
            'email': self.email
        }
        if self.api_key:
            search_params['api_key'] = self.api_key

        time.sleep(self.rate_limit)
        search_response = requests.get(search_url, params=search_params)
        search_data = search_response.json()
        pmids = search_data.get('esearchresult', {}).get('idlist', [])

        if not pmids:
            return []

        # Fetch abstracts
        fetch_url = f"{self.base_url}/efetch.fcgi"
        fetch_params = {
            'db': 'pubmed',
            'id': ','.join(pmids),
            'rettype': 'abstract',
            'retmode': 'xml',
            'email': self.email
        }
        if self.api_key:
            fetch_params['api_key'] = self.api_key

        time.sleep(self.rate_limit)
        fetch_response = requests.get(fetch_url, params=fetch_params)

        # Parse XML
        root = ET.fromstring(fetch_response.content)
        documents = []

        for i, article in enumerate(root.findall('.//PubmedArticle')):
            try:
                pmid_elem = article.find('.//PMID')
                pmid = pmid_elem.text if pmid_elem is not None else f"UNKNOWN_{i}"

                title_elem = article.find('.//ArticleTitle')
                title = title_elem.text if title_elem is not None else ""

                abstract_elems = article.findall('.//AbstractText')
                abstract = ' '.join([elem.text for elem in abstract_elems if elem.text])

                relevance_score = 1.0 - (i / top_k)

                doc = RetrievedDocument(
                    doc_id=f"PMID:{pmid}",
                    title=title,
                    abstract=abstract,
                    relevance_score=relevance_score,
                    source="PubMed",
                    metadata={'pmid': pmid, 'rank': i}
                )
                documents.append(doc)
            except Exception as e:
                continue

        return documents

    def compute_rsn_decomposition(
        self,
        query: PrivacyQuery,
        documents: List[RetrievedDocument],
        relevance_threshold: float = 0.7,
        noise_threshold: float = 0.3
    ) -> tuple[int, int, int]:
        """
        Decompose documents into R/S/N based on relevance scores.

        Args:
            query: PrivacyQuery object
            documents: Retrieved documents
            relevance_threshold: Threshold for relevant (>= threshold)
            noise_threshold: Threshold for noise (<= threshold)

        Returns:
            (R, S, N) tuple
        """
        R = sum(1 for doc in documents if doc.relevance_score >= relevance_threshold)
        N = sum(1 for doc in documents if doc.relevance_score <= noise_threshold)
        S = len(documents) - R - N

        return R, S, N

    def get_dataset_info(self) -> Dict[str, Any]:
        """Get PubMed dataset metadata"""
        return {
            'name': 'PubMed',
            'size': '35M+ abstracts',
            'license': 'Public domain (NCBI)',
            'domain': 'medical',
            'n_classes': 50,  # Number of unique diagnosis labels
            'sensitivity_levels': ['low', 'medium', 'high'],
            'privacy_risk': 'HIPAA violation (diagnosis leakage)',
            'api': 'NCBI Entrez E-utilities',
            'rate_limit': '3 req/s (10 req/s with API key)',
            'url': 'https://pubmed.ncbi.nlm.nih.gov/'
        }
