"""
Financial Adapter for Financial Privacy Dataset

Generates synthetic financial news queries for zkMEM privacy experiments.

Data Source: Synthetic financial news (mimics Reuters/Bloomberg)
Privacy Risk: R/S/N decomposition reveals trading strategy (proprietary algorithm)

Example:
    adapter = FinancialAdapter()
    queries = adapter.fetch_queries(n_queries=500)
    result = adapter.execute_query(queries[0])
    print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
"""

import random
from typing import List, Optional, Dict, Any

from yrsn.ports.zkp_data_source import (
    ZKPDataSource,
    PrivacyQuery,
    RetrievedDocument,
    SensitivityLevel
)


class FinancialAdapter(ZKPDataSource):
    """
    Financial news adapter for trading privacy queries.

    Uses synthetic data (real financial APIs require expensive subscriptions).
    For production: could integrate with Alpha Vantage, IEX Cloud, or Bloomberg API.
    """

    # Financial query templates by sensitivity
    QUERY_TEMPLATES = {
        SensitivityLevel.HIGH: [
            ("Fed rate hikes impact emerging market bonds", "em_bonds"),
            ("quantitative easing taper equity volatility", "qe_taper"),
            ("OPEC production cuts oil prices", "oil_opec"),
            ("semiconductor shortage automotive sector", "semiconductor_shortage"),
            ("ESG investing renewable energy", "esg_renewables"),
        ],
        SensitivityLevel.MEDIUM: [
            ("Tesla competitor analysis EV market", "ev_competition"),
            ("Amazon cloud computing market share", "cloud_aws"),
            ("vaccine development pharmaceutical stocks", "pharma_vaccines"),
            ("inflation expectations Treasury yields", "inflation_treasuries"),
            ("cryptocurrency regulation Bitcoin", "crypto_regulation"),
        ],
        SensitivityLevel.LOW: [
            ("earnings season financial sector", "earnings_financials"),
            ("dividend aristocrats retirement portfolio", "dividend_stocks"),
            ("S&P 500 index fund performance", "sp500_index"),
            ("gold prices inflation hedge", "gold_inflation"),
        ]
    }

    # Synthetic trading positions (labels)
    TRADING_POSITIONS = [
        "long_equity", "short_equity", "long_bonds", "short_bonds",
        "long_commodities", "short_commodities", "long_fx", "short_fx",
        "sector_rotation", "market_neutral"
    ]

    def __init__(self, api_keys: Optional[Dict[str, str]] = None):
        """
        Initialize Financial adapter.

        Args:
            api_keys: Optional dict (unused, for compatibility)
        """
        pass

    def fetch_queries(
        self,
        n_queries: int,
        sensitivity_distribution: Optional[Dict[SensitivityLevel, float]] = None
    ) -> List[PrivacyQuery]:
        """Generate financial queries from templates"""
        if sensitivity_distribution is None:
            sensitivity_distribution = {
                SensitivityLevel.HIGH: 0.50,
                SensitivityLevel.MEDIUM: 0.40,
                SensitivityLevel.LOW: 0.10
            }

        sensitivity_counts = {
            level: int(n_queries * prob)
            for level, prob in sensitivity_distribution.items()
        }

        total_assigned = sum(sensitivity_counts.values())
        if total_assigned < n_queries:
            sensitivity_counts[SensitivityLevel.HIGH] += (n_queries - total_assigned)

        queries = []
        for sensitivity, count in sensitivity_counts.items():
            templates = self.QUERY_TEMPLATES[sensitivity]
            sampled_templates = random.choices(templates, k=count)

            for query_text, base_label in sampled_templates:
                # Assign random trading position as label
                label = random.choice(self.TRADING_POSITIONS)

                query = PrivacyQuery(
                    query=query_text,
                    label=label,
                    sensitivity=sensitivity,
                    domain="financial",
                    metadata={'source': 'synthetic_financial', 'topic': base_label}
                )
                queries.append(query)

        random.shuffle(queries)
        return queries

    def retrieve_documents(
        self,
        query: PrivacyQuery,
        top_k: int = 100
    ) -> List[RetrievedDocument]:
        """
        Retrieve synthetic financial news documents.

        Note: Real implementation would use Reuters API, Bloomberg API, or Alpha Vantage.
        """
        documents = []
        for i in range(top_k):
            # Synthetic relevance: decays with position + noise
            relevance_score = max(0.0, 1.0 - (i / top_k) + random.gauss(0, 0.15))
            relevance_score = min(1.0, max(0.0, relevance_score))

            doc = RetrievedDocument(
                doc_id=f"SYNTHETIC_FIN_{i}",
                title=f"Financial News {i}: {query.query}",
                abstract=f"Synthetic financial article discussing {query.query}. "
                         f"Relevance: {relevance_score:.2f}. Trading implication: {query.label}.",
                relevance_score=relevance_score,
                source="Synthetic Financial News",
                metadata={'synthetic': True, 'rank': i, 'topic': query.metadata.get('topic')}
            )
            documents.append(doc)

        return documents

    def compute_rsn_decomposition(
        self,
        query: PrivacyQuery,
        documents: List[RetrievedDocument],
        relevance_threshold: float = 0.7,
        noise_threshold: float = 0.3
    ) -> tuple[int, int, int]:
        """Decompose documents into R/S/N"""
        R = sum(1 for doc in documents if doc.relevance_score >= relevance_threshold)
        N = sum(1 for doc in documents if doc.relevance_score <= noise_threshold)
        S = len(documents) - R - N
        return R, S, N

    def get_dataset_info(self) -> Dict[str, Any]:
        """Get Financial dataset metadata"""
        return {
            'name': 'Synthetic Financial News',
            'size': 'Generated on-demand',
            'license': 'Synthetic (for development)',
            'domain': 'financial',
            'n_classes': 10,
            'sensitivity_levels': ['low', 'medium', 'high'],
            'privacy_risk': 'Proprietary trading strategy leakage',
            'api': 'Synthetic (real: Reuters, Bloomberg, Alpha Vantage)',
            'rate_limit': 'N/A (synthetic)',
            'url': 'N/A'
        }
