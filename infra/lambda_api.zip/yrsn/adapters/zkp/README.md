# ZKP Data Source Adapters (Hexagonal Architecture)

**Purpose**: Privacy-sensitive dataset retrieval for zkMEM experiments (expZKP_200, expZKP_201)

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  zkMEM Experiments                  │
│         (expZKP_200, expZKP_201)                    │
└──────────────────────┬──────────────────────────────┘
                       │
                       │ depends on
                       ▼
┌─────────────────────────────────────────────────────┐
│            Port: ZKPDataSource                      │
│  (src/yrsn/ports/zkp_data_source.py)               │
│                                                     │
│  - fetch_queries()                                  │
│  - retrieve_documents()                             │
│  - compute_rsn_decomposition()                      │
│  - execute_query()                                  │
└──────────────────────┬──────────────────────────────┘
                       │
                       │ implemented by
                       ▼
┌─────────────────────────────────────────────────────┐
│         Adapters (this directory)                   │
│                                                     │
│  - PubMedAdapter (medical, HIPAA)                   │
│  - CaselawAdapter (legal, attorney-client)          │
│  - FinancialAdapter (financial, proprietary)        │
└─────────────────────────────────────────────────────┘
                       │
                       │ accesses
                       ▼
┌─────────────────────────────────────────────────────┐
│         External Data Sources                       │
│                                                     │
│  - PubMed (NCBI Entrez API)                         │
│  - Caselaw Access Project (CAP API)                 │
│  - Synthetic Financial News                         │
└─────────────────────────────────────────────────────┘
```

---

## Adapters

### PubMedAdapter

**Data Source**: PubMed (35M medical abstracts)
**API**: NCBI Entrez E-utilities (free, no key required for <3 req/s)
**Privacy Risk**: R/S/N reveals patient diagnosis → HIPAA violation

**Usage**:
```python
from yrsn.adapters.zkp import PubMedAdapter

adapter = PubMedAdapter(email="researcher@example.com")
queries = adapter.fetch_queries(n_queries=1000)

# Execute query
result = adapter.execute_query(queries[0])
print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
```

**API Key** (optional):
- Get from: https://www.ncbi.nlm.nih.gov/account/settings/
- Increases rate limit: 3 req/s → 10 req/s
- Add to `keys/zkp_api_keys.json`

---

### CaselawAdapter

**Data Source**: Caselaw Access Project (6.7M court cases)
**API**: CAP API (free, requires registration)
**Privacy Risk**: R/S/N reveals litigation strategy → attorney-client privilege breach

**Usage**:
```python
from yrsn.adapters.zkp import CaselawAdapter

adapter = CaselawAdapter(api_key="your_cap_api_key")
queries = adapter.fetch_queries(n_queries=500)

result = adapter.execute_query(queries[0])
print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
```

**API Key** (required for real data):
- Get from: https://case.law/api/
- Free registration
- Without key: falls back to synthetic data

---

### FinancialAdapter

**Data Source**: Synthetic financial news (mimics Reuters/Bloomberg)
**API**: Synthetic (no external API)
**Privacy Risk**: R/S/N reveals trading strategy → proprietary algorithm leakage

**Usage**:
```python
from yrsn.adapters.zkp import FinancialAdapter

adapter = FinancialAdapter()
queries = adapter.fetch_queries(n_queries=500)

result = adapter.execute_query(queries[0])
print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
```

**Note**: Uses synthetic data. For real financial data, integrate:
- Alpha Vantage (https://www.alphavantage.co/)
- IEX Cloud (https://iexcloud.io/)
- Bloomberg API (expensive)

---

## Factory Pattern

**ZKPDataSourceFactory** creates adapters dynamically:

```python
from yrsn.ports.zkp_data_source import ZKPDataSourceFactory

# Load API keys
import json
with open('keys/zkp_api_keys.json') as f:
    api_keys = json.load(f)

# Create adapter
adapter = ZKPDataSourceFactory.create('pubmed', api_keys=api_keys)
```

**Supported types**: `"pubmed"`, `"caselaw"`, `"financial"`

---

## API Keys Setup

### 1. Copy template:
```bash
cp keys/zkp_api_keys.template.json keys/zkp_api_keys.json
```

### 2. Edit `keys/zkp_api_keys.json`:
```json
{
  "ncbi_email": "your_email@example.com",
  "ncbi_api_key": "abc123...",
  "caselaw_api_key": "def456..."
}
```

### 3. Verify `.gitignore`:
```bash
# Should contain:
keys/zkp_api_keys.json
```

**NEVER commit `zkp_api_keys.json` to git!**

---

## Scripts

### Fetch Privacy Datasets

```bash
# Generate queries only (fast)
python scripts/zkp/fetch_privacy_datasets.py --domains medical legal financial

# Generate queries + execute retrieval (slow, requires API keys)
python scripts/zkp/fetch_privacy_datasets.py --domains medical --execute_retrieval

# Custom query counts
python scripts/zkp/fetch_privacy_datasets.py --domains medical legal financial --n_queries 1000 500 500
```

**Output**: `data/zkp/medical_queries.json`, `legal_queries.json`, `financial_queries.json`

---

## Data Flow

```
1. Fetch Queries
   └─> fetch_queries(n_queries=1000)
       └─> Returns: List[PrivacyQuery] with labels

2. Retrieve Documents
   └─> retrieve_documents(query, top_k=100)
       └─> Returns: List[RetrievedDocument] with relevance scores

3. Compute R/S/N
   └─> compute_rsn_decomposition(query, documents)
       └─> Returns: (R, S, N) tuple

4. Complete Pipeline
   └─> execute_query(query)
       └─> Returns: QueryResult with R/S/N + α
```

---

## Privacy Sensitivity Levels

```python
class SensitivityLevel(Enum):
    LOW = "low"       # Common cold, public info
    MEDIUM = "medium" # Chronic disease, general financial
    HIGH = "high"     # Cancer, HIV, trade secrets
```

**Distribution** (default):
- 50% high sensitivity
- 40% medium sensitivity
- 10% low sensitivity

---

## Testing

```python
import pytest
from yrsn.adapters.zkp import PubMedAdapter

def test_pubmed_fetch_queries():
    adapter = PubMedAdapter(email="test@example.com")
    queries = adapter.fetch_queries(n_queries=10)
    assert len(queries) == 10
    assert all(q.domain == "medical" for q in queries)

def test_pubmed_execute_query():
    adapter = PubMedAdapter(email="test@example.com")
    queries = adapter.fetch_queries(n_queries=1)
    result = adapter.execute_query(queries[0], top_k=10)

    assert result.R + result.S + result.N <= 10
    assert 0 <= result.alpha <= 1
```

---

## Troubleshooting

### PubMed rate limit errors
- **Error**: `HTTP 429 Too Many Requests`
- **Fix**: Add NCBI API key to `keys/zkp_api_keys.json`
- **Or**: Reduce request rate (increase `rate_limit` in adapter)

### Caselaw API errors
- **Error**: `401 Unauthorized`
- **Fix**: Register for CAP API key at https://case.law/api/
- **Fallback**: Adapter uses synthetic data if no key

### Import errors
- **Error**: `ModuleNotFoundError: No module named 'Bio'`
- **Fix**: Install biopython: `pip install biopython`
- **Note**: PubMed adapter falls back to HTTP if biopython unavailable

---

## For Experiments

### expZKP_200: Information Leakage

```python
# Train adversarial classifier on R/S/N values
from yrsn.ports.zkp_data_source import ZKPDataSourceFactory

adapter = ZKPDataSourceFactory.create('pubmed', api_keys)
queries = adapter.fetch_queries(n_queries=1000)

# Execute queries
results = [adapter.execute_query(q) for q in queries]

# Extract features (R, S, N) and labels
X = [[r.R, r.S, r.N] for r in results]
y = [r.query.label for r in results]

# Train classifier
from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier()
clf.fit(X, y)
accuracy = clf.score(X_test, y_test)  # Expected: 68%
```

### expZKP_201: zkMEM Zero-Knowledge

```python
# Generate zkMEM proofs
from zkp_proof_generator import generate_zkquality_proof

proofs = []
for result in results:
    proof = generate_zkquality_proof(result.R, result.S, result.N, alpha_min=0.75)
    proofs.append(proof)

# Train adversarial classifier on proof bytes
X = [extract_proof_features(p) for p in proofs]
y = [r.query.label for r in results]

clf.fit(X, y)
accuracy = clf.score(X_test, y_test)  # Expected: 2% (random)
```

---

## License

See `LICENSE` file in project root.

**Data Sources**:
- PubMed: Public domain (NCBI)
- Caselaw: Free for research (CAP license)
- Financial: Synthetic (for development)
