"""
ZKP Data Source Adapters

Concrete implementations for privacy-sensitive dataset retrieval.
"""

from .pubmed_adapter import PubMedAdapter
from .caselaw_adapter import CaselawAdapter
from .financial_adapter import FinancialAdapter

__all__ = ['PubMedAdapter', 'CaselawAdapter', 'FinancialAdapter']
