"""
Caselaw Adapter for Legal Privacy Dataset

Fetches legal cases from Caselaw Access Project for zkMEM privacy experiments.

Data Source: Caselaw Access Project (6.7M court cases)
API: CAP API (free, requires registration)
Privacy Risk: R/S/N decomposition reveals litigation strategy (attorney-client privilege)

Example:
    adapter = CaselawAdapter(api_key="your_cap_api_key")
    queries = adapter.fetch_queries(n_queries=500)
    result = adapter.execute_query(queries[0])
    print(f"R={result.R}, S={result.S}, N={result.N}, α={result.alpha}")
"""

import time
import random
from typing import List, Optional, Dict, Any

from yrsn.ports.zkp_data_source import (
    ZKPDataSource,
    PrivacyQuery,
    RetrievedDocument,
    SensitivityLevel
)


class CaselawAdapter(ZKPDataSource):
    """
    Caselaw Access Project adapter for legal privacy queries.

    Uses CAP API (requires free registration at case.law).
    """

    # Legal case templates by sensitivity
    CASE_TEMPLATES = {
        SensitivityLevel.HIGH: [
            ("patent infringement semiconductor industry", "patent_infringement"),
            ("employment discrimination tech companies", "employment_discrimination"),
            ("trade secret misappropriation", "trade_secret"),
            ("merger antitrust pharmaceutical", "merger_antitrust"),
            ("securities fraud insider trading", "securities_fraud"),
            ("class action data breach", "data_breach"),
            ("wrongful termination whistleblower", "wrongful_termination"),
            ("shareholder derivative lawsuit", "shareholder_derivative"),
        ],
        SensitivityLevel.MEDIUM: [
            ("contract breach software license", "contract_breach"),
            ("copyright infringement software", "copyright_infringement"),
            ("trademark dispute domain name", "trademark"),
            ("negligence medical malpractice", "malpractice"),
            ("breach of fiduciary duty", "fiduciary_duty"),
            ("qui tam False Claims Act", "qui_tam"),
        ],
        SensitivityLevel.LOW: [
            ("real estate boundary dispute", "real_estate"),
            ("landlord tenant eviction", "landlord_tenant"),
            ("traffic accident personal injury", "personal_injury"),
            ("small claims contract", "small_claims"),
        ]
    }

    def __init__(self, api_key: Optional[str] = None, api_keys: Optional[Dict[str, str]] = None):
        """
        Initialize Caselaw adapter.

        Args:
            api_key: CAP API key (get from https://case.law/api/)
            api_keys: Optional dict with 'caselaw_api_key'
        """
        if api_keys:
            self.api_key = api_keys.get('caselaw_api_key', None)
        else:
            self.api_key = api_key

        self.base_url = "https://api.case.law/v1"
        self.rate_limit = 0.5  # 2 requests/second (CAP limit)

    def fetch_queries(
        self,
        n_queries: int,
        sensitivity_distribution: Optional[Dict[SensitivityLevel, float]] = None
    ) -> List[PrivacyQuery]:
        """Generate legal queries from templates"""
        if sensitivity_distribution is None:
            sensitivity_distribution = {
                SensitivityLevel.HIGH: 0.60,
                SensitivityLevel.MEDIUM: 0.30,
                SensitivityLevel.LOW: 0.10
            }

        sensitivity_counts = {
            level: int(n_queries * prob)
            for level, prob in sensitivity_distribution.items()
        }

        total_assigned = sum(sensitivity_counts.values())
        if total_assigned < n_queries:
            sensitivity_counts[SensitivityLevel.HIGH] += (n_queries - total_assigned)

        queries = []
        for sensitivity, count in sensitivity_counts.items():
            templates = self.CASE_TEMPLATES[sensitivity]
            sampled_templates = random.choices(templates, k=count)

            for query_text, label in sampled_templates:
                query = PrivacyQuery(
                    query=query_text,
                    label=label,
                    sensitivity=sensitivity,
                    domain="legal",
                    metadata={'source': 'caselaw'}
                )
                queries.append(query)

        random.shuffle(queries)
        return queries

    def retrieve_documents(
        self,
        query: PrivacyQuery,
        top_k: int = 100
    ) -> List[RetrievedDocument]:
        """
        Retrieve case law documents.

        Note: If API key is not available, returns synthetic documents.
        """
        if not self.api_key:
            return self._retrieve_synthetic(query, top_k)

        import requests

        # Search cases
        search_url = f"{self.base_url}/cases/"
        headers = {'Authorization': f'Token {self.api_key}'}
        params = {
            'search': query.query,
            'page_size': top_k,
            'ordering': 'relevance'
        }

        time.sleep(self.rate_limit)
        try:
            response = requests.get(search_url, headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            print(f"WARNING: CAP API error: {e}. Falling back to synthetic data.")
            return self._retrieve_synthetic(query, top_k)

        documents = []
        for i, case in enumerate(data.get('results', [])):
            case_id = str(case.get('id', f'CASE_{i}'))
            name = case.get('name_abbreviation', case.get('name', ''))
            decision_date = case.get('decision_date', '')
            court = case.get('court', {}).get('name', '')

            # CAP doesn't return full text in search, just metadata
            # For real implementation, would need separate fetch
            abstract = f"Case: {name}. Court: {court}. Date: {decision_date}."

            relevance_score = 1.0 - (i / top_k)

            doc = RetrievedDocument(
                doc_id=f"CAP:{case_id}",
                title=name,
                abstract=abstract,
                relevance_score=relevance_score,
                source="Caselaw Access Project",
                metadata={'case_id': case_id, 'court': court, 'date': decision_date}
            )
            documents.append(doc)

        return documents

    def _retrieve_synthetic(self, query: PrivacyQuery, top_k: int) -> List[RetrievedDocument]:
        """Generate synthetic legal documents (for development/testing)"""
        documents = []
        for i in range(top_k):
            relevance_score = max(0.0, 1.0 - (i / top_k) + random.gauss(0, 0.1))
            relevance_score = min(1.0, max(0.0, relevance_score))

            doc = RetrievedDocument(
                doc_id=f"SYNTHETIC_CASE_{i}",
                title=f"Case {i}: {query.query}",
                abstract=f"Synthetic case discussing {query.label}. Relevance: {relevance_score:.2f}",
                relevance_score=relevance_score,
                source="Synthetic (CAP API key not provided)",
                metadata={'synthetic': True, 'rank': i}
            )
            documents.append(doc)

        return documents

    def compute_rsn_decomposition(
        self,
        query: PrivacyQuery,
        documents: List[RetrievedDocument],
        relevance_threshold: float = 0.7,
        noise_threshold: float = 0.3
    ) -> tuple[int, int, int]:
        """Decompose documents into R/S/N"""
        R = sum(1 for doc in documents if doc.relevance_score >= relevance_threshold)
        N = sum(1 for doc in documents if doc.relevance_score <= noise_threshold)
        S = len(documents) - R - N
        return R, S, N

    def get_dataset_info(self) -> Dict[str, Any]:
        """Get Caselaw dataset metadata"""
        return {
            'name': 'Caselaw Access Project',
            'size': '6.7M court cases',
            'license': 'Free for research (requires registration)',
            'domain': 'legal',
            'n_classes': 20,
            'sensitivity_levels': ['low', 'medium', 'high'],
            'privacy_risk': 'Attorney-client privilege breach (litigation strategy leakage)',
            'api': 'CAP API',
            'rate_limit': '2 req/s',
            'url': 'https://case.law/'
        }
