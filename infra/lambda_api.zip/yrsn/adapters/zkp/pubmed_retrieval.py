"""
Real PubMed Abstract Retrieval for P11 Phase 4 Compliance

This module fetches real PubMed abstracts via NCBI Entrez API to replace
synthetic document generation in expZKP_200.

P11 Phase 4 Requirement: "Synthetic-only evidence is NOT patent-valid"
- This adapter provides real external validation dataset (PubMed)
- Implements rate limiting (NCBI: 3 requests/second max without API key)
- Caches results to avoid redundant API calls

Usage:
    from yrsn.adapters.zkp.pubmed_retrieval import PubMedRetriever

    retriever = PubMedRetriever(email="researcher@example.com", cache_dir="cache/pubmed")
    abstracts = retriever.retrieve_abstracts("lung cancer treatment", top_k=100)
"""

import time
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass
import xml.etree.ElementTree as ET

from Bio import Entrez


@dataclass
class PubMedAbstract:
    """Single PubMed abstract"""
    pmid: str
    title: str
    abstract: str
    year: Optional[int] = None
    journal: Optional[str] = None


class PubMedRetriever:
    """
    Retrieves real PubMed abstracts via NCBI Entrez API.

    Implements:
    - Rate limiting (3 requests/second without API key, 10 with key)
    - Caching (disk-based to avoid redundant API calls)
    - Error handling (retries, missing abstracts)

    P11 Phase 4 Compliance: Provides real external validation dataset.
    """

    def __init__(
        self,
        email: str = "yrsn-research@example.com",
        api_key: Optional[str] = None,
        cache_dir: Optional[Path] = None,
        rate_limit_delay: float = 0.34  # 3 requests/second = 0.34s between requests
    ):
        """
        Initialize PubMed retriever.

        Args:
            email: Email for NCBI (required by Entrez API)
            api_key: Optional NCBI API key (increases rate limit to 10/sec)
            cache_dir: Directory for caching results (default: data/zkp/pubmed_cache)
            rate_limit_delay: Seconds between requests (default: 0.34s = 3/sec)
        """
        Entrez.email = email
        if api_key:
            Entrez.api_key = api_key
            self.rate_limit_delay = 0.1  # 10 requests/second with API key
        else:
            self.rate_limit_delay = rate_limit_delay

        self.cache_dir = cache_dir or Path("data/zkp/pubmed_cache")
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.last_request_time = 0

    def _rate_limit(self):
        """Enforce NCBI rate limiting"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - time_since_last)
        self.last_request_time = time.time()

    def _get_cache_key(self, query: str, top_k: int) -> str:
        """Generate cache key for query"""
        cache_str = f"{query}_{top_k}"
        return hashlib.md5(cache_str.encode()).hexdigest()

    def _load_from_cache(self, cache_key: str) -> Optional[List[PubMedAbstract]]:
        """Load results from cache"""
        cache_file = self.cache_dir / f"{cache_key}.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return [PubMedAbstract(**item) for item in data]
            except Exception as e:
                print(f"[WARNING] Cache load failed for {cache_key}: {e}")
                return None
        return None

    def _save_to_cache(self, cache_key: str, abstracts: List[PubMedAbstract]):
        """Save results to cache"""
        cache_file = self.cache_dir / f"{cache_key}.json"
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                data = [
                    {
                        'pmid': a.pmid,
                        'title': a.title,
                        'abstract': a.abstract,
                        'year': a.year,
                        'journal': a.journal
                    }
                    for a in abstracts
                ]
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[WARNING] Cache save failed for {cache_key}: {e}")

    def retrieve_abstracts(
        self,
        query: str,
        top_k: int = 100,
        use_cache: bool = True
    ) -> List[PubMedAbstract]:
        """
        Retrieve PubMed abstracts for a query.

        Args:
            query: Search query (e.g., "lung cancer treatment")
            top_k: Number of abstracts to retrieve
            use_cache: Use cached results if available

        Returns:
            List of PubMedAbstract objects
        """
        # Check cache
        cache_key = self._get_cache_key(query, top_k)
        if use_cache:
            cached = self._load_from_cache(cache_key)
            if cached is not None:
                return cached

        # Search PubMed
        self._rate_limit()
        try:
            search_handle = Entrez.esearch(
                db="pubmed",
                term=query,
                retmax=top_k,
                sort="relevance"
            )
            search_results = Entrez.read(search_handle)
            search_handle.close()
            pmids = search_results['IdList']
        except Exception as e:
            print(f"[ERROR] PubMed search failed for '{query}': {e}")
            return []

        if not pmids:
            print(f"[WARNING] No results found for query: '{query}'")
            return []

        # Fetch abstracts
        abstracts = []
        batch_size = 100  # Fetch in batches to avoid timeout

        for i in range(0, len(pmids), batch_size):
            batch_pmids = pmids[i:i+batch_size]

            self._rate_limit()
            try:
                fetch_handle = Entrez.efetch(
                    db="pubmed",
                    id=batch_pmids,
                    rettype="abstract",
                    retmode="xml"
                )
                fetch_results = fetch_handle.read()
                fetch_handle.close()

                # Parse XML
                root = ET.fromstring(fetch_results)
                for article in root.findall('.//PubmedArticle'):
                    try:
                        pmid = article.find('.//PMID').text

                        # Title
                        title_elem = article.find('.//ArticleTitle')
                        title = title_elem.text if title_elem is not None else ""

                        # Abstract
                        abstract_texts = article.findall('.//AbstractText')
                        if abstract_texts:
                            abstract = " ".join([
                                elem.text for elem in abstract_texts if elem.text
                            ])
                        else:
                            abstract = ""

                        # Skip if no abstract
                        if not abstract:
                            continue

                        # Year
                        year_elem = article.find('.//PubDate/Year')
                        year = int(year_elem.text) if year_elem is not None else None

                        # Journal
                        journal_elem = article.find('.//Journal/Title')
                        journal = journal_elem.text if journal_elem is not None else None

                        abstracts.append(PubMedAbstract(
                            pmid=pmid,
                            title=title,
                            abstract=abstract,
                            year=year,
                            journal=journal
                        ))
                    except Exception as e:
                        print(f"[WARNING] Failed to parse article: {e}")
                        continue

            except Exception as e:
                print(f"[ERROR] PubMed fetch failed for batch {i}-{i+batch_size}: {e}")
                continue

        # Save to cache
        if use_cache and abstracts:
            self._save_to_cache(cache_key, abstracts)

        return abstracts

    def get_cache_stats(self) -> Dict[str, int]:
        """Get cache statistics"""
        cache_files = list(self.cache_dir.glob("*.json"))
        total_abstracts = 0

        for cache_file in cache_files:
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    total_abstracts += len(data)
            except:
                continue

        return {
            'cache_files': len(cache_files),
            'total_abstracts': total_abstracts,
            'cache_dir': str(self.cache_dir)
        }
