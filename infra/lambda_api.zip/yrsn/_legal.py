"""
YRSN Legal Notice
=================

This software includes material that is the subject of one or more
pending patent applications.

See PATENT_NOTICE.md for details.

Copyright (c) Next Shift Consulting LLC. All rights reserved.
"""

PATENT_NOTICE = (
    "Patent Notice: This software includes material that is the subject of one or more "
    "pending patent applications. See PATENT_NOTICE.md for details."
)

__all__ = ["PATENT_NOTICE"]
