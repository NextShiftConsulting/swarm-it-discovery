"""
YRSN Consistency Tool

Argument consistency analysis with contradiction detection,
logical structure scoring, and review scope determination.
"""

from typing import Dict, Any, List, Tuple
import re


def analyze_consistency(
    content: str,
    domain: str = "finance"
) -> Dict[str, Any]:
    """
    Analyze content for argument consistency and determine review scope.

    Args:
        content: Document text to analyze
        domain: Domain profile for context

    Returns:
        Dict with:
            - consistency_score: Overall consistency (0.0-1.0)
            - logical_structure_score: Argument structure quality
            - contradictions: List of detected contradictions
            - review_scope: Recommended review level
            - priority: Review priority (low/medium/high/critical)

    Example:
        >>> result = analyze_consistency("Revenue always increases but may sometimes decrease")
        >>> print(result['contradictions'])
        ['Potential contradiction: always vs sometimes']
    """
    text_lower = content.lower()

    # =================================================================
    # Step 1: Analyze logical structure
    # Check for premise, conclusion, evidence, and qualification markers
    # =================================================================
    structure_score = score_logical_structure(text_lower)

    # =================================================================
    # Step 2: Detect internal contradictions
    # Look for opposing absolute/relative terms
    # =================================================================
    contradictions = detect_contradictions(text_lower)

    # =================================================================
    # Step 3: Analyze scope determination factors
    # Check for materiality, risk, regulatory, and financial indicators
    # =================================================================
    scope_factors = _analyze_scope_factors(text_lower)

    # =================================================================
    # Step 4: Check quantitative consistency
    # Look for conflicting numbers or percentages
    # =================================================================
    quant_issues = check_quantitative_consistency(content)

    # =================================================================
    # Step 5: Determine review scope based on all factors
    # =================================================================
    scope_result = determine_review_scope(
        scope_factors,
        contradictions,
        structure_score
    )

    # =================================================================
    # Step 6: Calculate overall consistency score
    # Penalize for contradictions, reward for good structure
    # =================================================================
    contradiction_penalty = min(len(contradictions) * 0.1, 0.5)  # Max 50% penalty
    consistency_score = max(0, structure_score - contradiction_penalty)

    return {
        "consistency_score": round(consistency_score, 3),
        "logical_structure_score": round(structure_score, 3),
        "contradictions": contradictions,
        "quantitative_issues": quant_issues,
        "scope_factors": scope_factors,
        "review_scope": scope_result["recommendation"],
        "priority": scope_result["priority"],
        "summary": {
            "total_issues": len(contradictions) + len(quant_issues),
            "needs_review": len(contradictions) > 0 or scope_result["priority"] in ["high", "critical"]
        }
    }


def detect_contradictions(
    text: str
) -> List[str]:
    """
    Detect potential internal contradictions.

    Args:
        text: Text to analyze (should be lowercase)

    Returns:
        List of contradiction descriptions

    Example:
        >>> detect_contradictions("we always do this but never do that")
        ['Potential contradiction: always vs never']
    """
    contradictions = []

    # =================================================================
    # Contradiction patterns: pairs of opposing terms
    # If both appear in text, flag as potential contradiction
    # =================================================================
    contradiction_patterns = [
        # Absolute vs relative
        (r'\balways\b', r'\bsometimes\b', 'always', 'sometimes'),
        (r'\bnever\b', r'\bsometimes\b', 'never', 'sometimes'),
        (r'\ball\b', r'\bsome\b', 'all', 'some'),
        (r'\bnone\b', r'\bsome\b', 'none', 'some'),
        (r'\balways\b', r'\bnever\b', 'always', 'never'),

        # Direction contradictions
        (r'\bincrease[sd]?\b', r'\bdecrease[sd]?\b', 'increase', 'decrease'),
        (r'\bgrow[sn]?\b', r'\bshrink[s]?\b', 'grow', 'shrink'),
        (r'\bexpand[sed]?\b', r'\breduce[sd]?\b', 'expand', 'reduce'),
        (r'\bimprove[sd]?\b', r'\bdecline[sd]?\b', 'improve', 'decline'),

        # Approval contradictions
        (r'\bapprove[sd]?\b', r'\breject[sed]?\b', 'approve', 'reject'),
        (r'\baccept[sed]?\b', r'\bdeny\b', 'accept', 'deny'),
        (r'\bendorse[sd]?\b', r'\boppose[sd]?\b', 'endorse', 'oppose'),

        # Certainty contradictions
        (r'\bmust\b', r'\bmay\b', 'must', 'may'),
        (r'\brequired\b', r'\boptional\b', 'required', 'optional'),
        (r'\bmandatory\b', r'\bvoluntary\b', 'mandatory', 'voluntary'),
    ]

    for pos_pattern, neg_pattern, pos_word, neg_word in contradiction_patterns:
        if re.search(pos_pattern, text) and re.search(neg_pattern, text):
            contradictions.append(f"Potential contradiction: {pos_word} vs {neg_word}")

    return contradictions


def score_logical_structure(
    text: str
) -> float:
    """
    Score the logical structure of arguments.

    Args:
        text: Text to analyze (should be lowercase)

    Returns:
        Score from 0.0 to 1.0

    Example:
        >>> score_logical_structure("because of X, therefore Y")
        0.5
    """
    # =================================================================
    # Logical structure indicators
    # Good arguments have premises, conclusions, evidence, qualifications
    # =================================================================
    structure_patterns = {
        'premise_indicators': r'\b(?:because|since|given that|assuming|based on|due to)\b',
        'conclusion_indicators': r'\b(?:therefore|thus|hence|consequently|as a result|accordingly)\b',
        'evidence_indicators': r'\b(?:evidence shows|data indicates|research demonstrates|studies show|analysis reveals)\b',
        'qualification_indicators': r'\b(?:however|although|despite|nevertheless|on the other hand|while)\b'
    }

    structure_elements = 0
    total_expected = len(structure_patterns)

    for element_type, pattern in structure_patterns.items():
        if re.search(pattern, text, re.IGNORECASE):
            structure_elements += 1

    return structure_elements / total_expected


def check_quantitative_consistency(
    text: str
) -> List[str]:
    """
    Check for quantitative consistency issues.

    Args:
        text: Text to analyze

    Returns:
        List of quantitative issues found

    Example:
        >>> check_quantitative_consistency("Revenue grew 50% but declined 30%")
        ['Conflicting direction indicators with percentages']
    """
    issues = []

    # Extract percentages
    percentages = re.findall(r'\d+(?:\.\d+)?%', text)

    # Extract monetary amounts
    amounts = re.findall(r'\$[\d,]+(?:\.\d{2})?', text)

    # Check for conflicting directions with numbers
    text_lower = text.lower()
    has_increase = bool(re.search(r'\b(?:increase|grow|rise|up)\b', text_lower))
    has_decrease = bool(re.search(r'\b(?:decrease|decline|fall|down)\b', text_lower))

    if has_increase and has_decrease:
        if percentages:
            issues.append("Conflicting direction indicators with percentages")
        if amounts:
            issues.append("Conflicting direction indicators with monetary amounts")

    # Check for multiple different percentages that might conflict
    if len(set(percentages)) > 3:
        issues.append(f"Multiple percentages ({len(percentages)}) - verify consistency")

    return issues


def determine_review_scope(
    scope_factors: Dict[str, Any],
    contradictions: List[str],
    structure_score: float
) -> Dict[str, str]:
    """
    Determine recommended review scope based on analysis.

    Args:
        scope_factors: Scope determination factors
        contradictions: List of contradictions found
        structure_score: Logical structure score

    Returns:
        Dict with recommendation and priority

    Example:
        >>> result = determine_review_scope(factors, [], 0.8)
        >>> print(result['recommendation'])
        'standard_review'
    """
    # =================================================================
    # Count high-priority triggers
    # More triggers = more comprehensive review needed
    # =================================================================
    high_priority_triggers = 0

    if scope_factors.get('materiality_indicators', {}).get('found', False):
        high_priority_triggers += 1
    if scope_factors.get('risk_level_indicators', {}).get('found', False):
        high_priority_triggers += 1
    if scope_factors.get('regulatory_indicators', {}).get('found', False):
        high_priority_triggers += 1
    if len(contradictions) > 2:
        high_priority_triggers += 1
    if structure_score < 0.3:
        high_priority_triggers += 1

    # =================================================================
    # Determine scope and priority based on trigger count
    # =================================================================
    if high_priority_triggers >= 3:
        return {
            'recommendation': 'full_review_required',
            'priority': 'critical'
        }
    elif high_priority_triggers >= 2:
        return {
            'recommendation': 'comprehensive_review',
            'priority': 'high'
        }
    elif high_priority_triggers >= 1 or len(contradictions) > 0:
        return {
            'recommendation': 'focused_review',
            'priority': 'medium'
        }
    else:
        return {
            'recommendation': 'standard_review',
            'priority': 'low'
        }


def _analyze_scope_factors(text: str) -> Dict[str, Any]:
    """Analyze factors that determine review scope."""
    scope_criteria = {
        'materiality_indicators': r'\b(?:material|significant|substantial|major impact)\b',
        'risk_level_indicators': r'\b(?:high risk|critical|urgent|immediate attention)\b',
        'regulatory_indicators': r'\b(?:regulatory|compliance|legal requirement|mandatory)\b',
        'financial_impact_indicators': r'(?:\$[\d,]+|[\d]+%|material impact|financial exposure)'
    }

    scope_factors = {}

    for factor_type, pattern in scope_criteria.items():
        matches = re.findall(pattern, text, re.IGNORECASE)
        scope_factors[factor_type] = {
            'found': len(matches) > 0,
            'count': len(matches),
            'examples': matches[:3] if matches else []
        }

    return scope_factors


def get_analysis_framework() -> Dict[str, Any]:
    """
    Get summary of analysis framework used.

    Returns:
        Dict describing the analysis framework
    """
    return {
        'logical_structure_patterns': [
            'premise_indicators',
            'conclusion_indicators',
            'evidence_indicators',
            'qualification_indicators'
        ],
        'scope_criteria': [
            'materiality_indicators',
            'risk_level_indicators',
            'regulatory_indicators',
            'financial_impact_indicators'
        ],
        'contradiction_types': [
            'absolute_vs_relative',
            'direction_contradictions',
            'approval_contradictions',
            'certainty_contradictions'
        ],
        'review_scope_options': [
            'standard_review',
            'focused_review',
            'comprehensive_review',
            'full_review_required'
        ],
        'priority_levels': ['low', 'medium', 'high', 'critical']
    }


class ConsistencyChecker:
    """Consistency checker class for analyzing document consistency."""

    def __init__(self, domain: str = "finance"):
        self.domain = domain
        self.results = []

    def check(self, content: str) -> Dict[str, Any]:
        """Check content for consistency."""
        result = analyze_consistency(content, self.domain)
        self.results.append(result)
        return result

    def get_history(self) -> List[Dict[str, Any]]:
        """Get check history."""
        return self.results

    def clear(self):
        """Clear history."""
        self.results = []


def check_consistency(
    content: str,
    domain: str = "finance"
) -> Dict[str, Any]:
    """
    Check content for argument consistency.

    Args:
        content: Text content to check
        domain: Domain profile

    Returns:
        Consistency analysis results

    Example:
        >>> result = check_consistency("Model must be validated quarterly")
        >>> print(result['consistency_score'])
        0.85
    """
    return analyze_consistency(content, domain)
