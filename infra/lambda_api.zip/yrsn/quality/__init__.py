"""
YRSN Context Quality Module

Provides consistency checking, logical structure analysis,
and adversarial robustness testing for context validation.

Modules:
    - consistency: Logical consistency checking
    - adversarial: Adversarial robustness testing
"""

from yrsn.quality.consistency import (
    analyze_consistency,
    detect_contradictions,
    score_logical_structure,
    check_quantitative_consistency,
    determine_review_scope,
    get_analysis_framework,
    ConsistencyChecker,
    check_consistency,
)

# Adversarial robustness
from yrsn.quality.adversarial import (
    FGSMAttacker,
    PGDAttacker,
    NoiseAttacker,
    InputSmoother,
    AdversarialTrainer,
    evaluate_robustness,
    RobustnessResult,
)

# Threshold optimization
from yrsn.quality.threshold_optimizer import (
    ThresholdOptimizer,
    ThresholdConfig,
    OptimizationResult,
    analyze_threshold_sensitivity,
    recommend_thresholds_for_domain,
)

__all__ = [
    # Consistency
    "analyze_consistency",
    "detect_contradictions",
    "score_logical_structure",
    "check_quantitative_consistency",
    "determine_review_scope",
    "get_analysis_framework",
    "ConsistencyChecker",
    "check_consistency",
    # Adversarial
    "FGSMAttacker",
    "PGDAttacker",
    "NoiseAttacker",
    "InputSmoother",
    "AdversarialTrainer",
    "evaluate_robustness",
    "RobustnessResult",
    # Threshold optimization
    "ThresholdOptimizer",
    "ThresholdConfig",
    "OptimizationResult",
    "analyze_threshold_sensitivity",
    "recommend_thresholds_for_domain",
]
