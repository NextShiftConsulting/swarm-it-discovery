"""
Threshold Optimizer for Domain-Specific Calibration

Automatically optimizes R/S/N thresholds (tau_R, tau_S, tau_N) for
specific domains and modalities using validation data.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Modes 3, 4, 7)

Use Cases:
    1. Customer onboarding: Find optimal thresholds for their domain
    2. Periodic recalibration: Adjust thresholds as data distribution shifts
    3. A/B testing: Compare threshold configurations

Usage:
    >>> from yrsn.tools.threshold_optimizer import ThresholdOptimizer
    >>>
    >>> optimizer = ThresholdOptimizer()
    >>> result = optimizer.optimize(
    ...     certificates=validation_certs,  # List of Certificate dicts with R/S/N
    ...     labels=quality_labels,          # Ground truth: 1=good, 0=bad
    ...     metric='f1',                    # Optimization target
    ...     modality='text'
    ... )
    >>>
    >>> print(f"Optimal thresholds: tau_R={result.tau_R}, tau_S={result.tau_S}, tau_N={result.tau_N}")
    >>> print(f"Best {result.metric}: {result.best_score:.3f}")
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Any, Callable
import numpy as np
from enum import Enum


class OptimizationMetric(Enum):
    """Metrics for threshold optimization."""
    F1 = "f1"
    ACCURACY = "accuracy"
    PRECISION = "precision"
    RECALL = "recall"
    MCC = "mcc"  # Matthews Correlation Coefficient
    BALANCED_ACCURACY = "balanced_accuracy"


@dataclass
class ThresholdConfig:
    """Configuration for threshold optimization."""
    # Search ranges
    tau_R_range: Tuple[float, float] = (0.40, 0.75)
    tau_S_range: Tuple[float, float] = (0.15, 0.40)
    tau_N_range: Tuple[float, float] = (0.10, 0.30)

    # Search resolution
    tau_R_steps: int = 20
    tau_S_steps: int = 15
    tau_N_steps: int = 15

    # Constraints
    min_pass_rate: float = 0.10  # Minimum fraction that passes
    max_pass_rate: float = 0.95  # Maximum fraction that passes

    # Optimization
    metric: OptimizationMetric = OptimizationMetric.F1
    use_cross_validation: bool = False
    cv_folds: int = 5


@dataclass
class OptimizationResult:
    """Result of threshold optimization."""
    tau_R: float
    tau_S: float
    tau_N: float
    metric: str
    best_score: float
    pass_rate: float
    confusion_matrix: Dict[str, int]
    all_metrics: Dict[str, float]
    search_history: List[Dict[str, Any]] = field(default_factory=list)
    modality: Optional[str] = None
    n_samples: int = 0


class ThresholdOptimizer:
    """
    Optimizer for R/S/N validation thresholds.

    Supports multiple optimization strategies:
    - Grid search (exhaustive)
    - Bayesian optimization (efficient)
    - Cross-validated search (robust)
    """

    def __init__(self, config: Optional[ThresholdConfig] = None):
        self.config = config or ThresholdConfig()

    def optimize(
        self,
        certificates: List[Dict[str, float]],
        labels: List[int],
        metric: Optional[str] = None,
        modality: Optional[str] = None,
    ) -> OptimizationResult:
        """
        Find optimal thresholds using grid search.

        Args:
            certificates: List of certificate dicts with 'R', 'S', 'N' keys
            labels: Ground truth quality labels (1=good, 0=bad)
            metric: Optimization metric (overrides config)
            modality: Optional modality identifier

        Returns:
            OptimizationResult with optimal thresholds and metrics
        """
        # Extract R/S/N arrays
        R = np.array([c['R'] for c in certificates])
        S = np.array([c['S'] for c in certificates])
        N = np.array([c['N'] for c in certificates])
        y_true = np.array(labels)

        # Determine metric
        opt_metric = OptimizationMetric(metric) if metric else self.config.metric

        # Generate search grid
        tau_R_vals = np.linspace(
            self.config.tau_R_range[0],
            self.config.tau_R_range[1],
            self.config.tau_R_steps
        )
        tau_S_vals = np.linspace(
            self.config.tau_S_range[0],
            self.config.tau_S_range[1],
            self.config.tau_S_steps
        )
        tau_N_vals = np.linspace(
            self.config.tau_N_range[0],
            self.config.tau_N_range[1],
            self.config.tau_N_steps
        )

        best_score = -1
        best_thresholds = (0.55, 0.25, 0.20)
        best_metrics = {}
        best_cm = {}
        search_history = []

        # Grid search
        for tau_R in tau_R_vals:
            for tau_S in tau_S_vals:
                for tau_N in tau_N_vals:
                    # Apply thresholds
                    y_pred = self._apply_thresholds(R, S, N, tau_R, tau_S, tau_N)

                    # Check pass rate constraints
                    pass_rate = np.mean(y_pred)
                    if pass_rate < self.config.min_pass_rate or pass_rate > self.config.max_pass_rate:
                        continue

                    # Compute metrics
                    metrics = self._compute_metrics(y_true, y_pred)
                    score = metrics[opt_metric.value]

                    # Track history
                    search_history.append({
                        'tau_R': tau_R,
                        'tau_S': tau_S,
                        'tau_N': tau_N,
                        'score': score,
                        'pass_rate': pass_rate,
                    })

                    # Update best
                    if score > best_score:
                        best_score = score
                        best_thresholds = (tau_R, tau_S, tau_N)
                        best_metrics = metrics
                        best_cm = self._confusion_matrix(y_true, y_pred)

        return OptimizationResult(
            tau_R=best_thresholds[0],
            tau_S=best_thresholds[1],
            tau_N=best_thresholds[2],
            metric=opt_metric.value,
            best_score=best_score,
            pass_rate=float(np.mean(self._apply_thresholds(
                R, S, N, *best_thresholds
            ))),
            confusion_matrix=best_cm,
            all_metrics=best_metrics,
            search_history=search_history,
            modality=modality,
            n_samples=len(labels),
        )

    def optimize_joint(
        self,
        certificates: List[Dict[str, float]],
        labels: List[int],
        modality: Optional[str] = None,
        weights: Optional[Dict[str, float]] = None,
    ) -> OptimizationResult:
        """
        Optimize thresholds using joint objective.

        Combines multiple metrics with weights:
            score = w_f1 * f1 + w_precision * precision + w_recall * recall

        Args:
            certificates: List of certificate dicts
            labels: Ground truth labels
            modality: Optional modality identifier
            weights: Metric weights (default: equal weights)

        Returns:
            OptimizationResult
        """
        weights = weights or {'f1': 0.5, 'precision': 0.25, 'recall': 0.25}

        # Extract R/S/N
        R = np.array([c['R'] for c in certificates])
        S = np.array([c['S'] for c in certificates])
        N = np.array([c['N'] for c in certificates])
        y_true = np.array(labels)

        # Grid search
        tau_R_vals = np.linspace(*self.config.tau_R_range, self.config.tau_R_steps)
        tau_S_vals = np.linspace(*self.config.tau_S_range, self.config.tau_S_steps)
        tau_N_vals = np.linspace(*self.config.tau_N_range, self.config.tau_N_steps)

        best_score = -1
        best_thresholds = (0.55, 0.25, 0.20)
        best_metrics = {}
        best_cm = {}

        for tau_R in tau_R_vals:
            for tau_S in tau_S_vals:
                for tau_N in tau_N_vals:
                    y_pred = self._apply_thresholds(R, S, N, tau_R, tau_S, tau_N)

                    # Check constraints
                    pass_rate = np.mean(y_pred)
                    if pass_rate < self.config.min_pass_rate or pass_rate > self.config.max_pass_rate:
                        continue

                    metrics = self._compute_metrics(y_true, y_pred)

                    # Joint score
                    score = sum(weights.get(k, 0) * v for k, v in metrics.items())

                    if score > best_score:
                        best_score = score
                        best_thresholds = (tau_R, tau_S, tau_N)
                        best_metrics = metrics
                        best_cm = self._confusion_matrix(y_true, y_pred)

        return OptimizationResult(
            tau_R=best_thresholds[0],
            tau_S=best_thresholds[1],
            tau_N=best_thresholds[2],
            metric="joint",
            best_score=best_score,
            pass_rate=float(np.mean(self._apply_thresholds(R, S, N, *best_thresholds))),
            confusion_matrix=best_cm,
            all_metrics=best_metrics,
            search_history=[],
            modality=modality,
            n_samples=len(labels),
        )

    def evaluate(
        self,
        certificates: List[Dict[str, float]],
        labels: List[int],
        tau_R: float,
        tau_S: float,
        tau_N: float,
    ) -> Dict[str, Any]:
        """
        Evaluate a specific threshold configuration.

        Args:
            certificates: List of certificate dicts
            labels: Ground truth labels
            tau_R, tau_S, tau_N: Thresholds to evaluate

        Returns:
            Dict with all metrics and confusion matrix
        """
        R = np.array([c['R'] for c in certificates])
        S = np.array([c['S'] for c in certificates])
        N = np.array([c['N'] for c in certificates])
        y_true = np.array(labels)

        y_pred = self._apply_thresholds(R, S, N, tau_R, tau_S, tau_N)

        metrics = self._compute_metrics(y_true, y_pred)
        cm = self._confusion_matrix(y_true, y_pred)

        return {
            'thresholds': {'tau_R': tau_R, 'tau_S': tau_S, 'tau_N': tau_N},
            'metrics': metrics,
            'confusion_matrix': cm,
            'pass_rate': float(np.mean(y_pred)),
            'n_samples': len(labels),
        }

    def _apply_thresholds(
        self,
        R: np.ndarray,
        S: np.ndarray,
        N: np.ndarray,
        tau_R: float,
        tau_S: float,
        tau_N: float,
    ) -> np.ndarray:
        """Apply thresholds to get predictions (1=pass, 0=fail)."""
        return ((R >= tau_R) & (S <= tau_S) & (N <= tau_N)).astype(int)

    def _compute_metrics(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> Dict[str, float]:
        """Compute all classification metrics."""
        cm = self._confusion_matrix(y_true, y_pred)
        tp, fp, tn, fn = cm['TP'], cm['FP'], cm['TN'], cm['FN']

        # Precision
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0

        # Recall
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0

        # F1
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        # Accuracy
        total = tp + fp + tn + fn
        accuracy = (tp + tn) / total if total > 0 else 0.0

        # Specificity
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0

        # Balanced accuracy
        balanced_accuracy = (recall + specificity) / 2

        # MCC
        denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        mcc = (tp * tn - fp * fn) / denom if denom > 0 else 0.0

        return {
            'f1': f1,
            'precision': precision,
            'recall': recall,
            'accuracy': accuracy,
            'specificity': specificity,
            'balanced_accuracy': balanced_accuracy,
            'mcc': mcc,
        }

    def _confusion_matrix(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> Dict[str, int]:
        """Compute confusion matrix."""
        tp = int(np.sum((y_pred == 1) & (y_true == 1)))
        fp = int(np.sum((y_pred == 1) & (y_true == 0)))
        tn = int(np.sum((y_pred == 0) & (y_true == 0)))
        fn = int(np.sum((y_pred == 0) & (y_true == 1)))
        return {'TP': tp, 'FP': fp, 'TN': tn, 'FN': fn}


def analyze_threshold_sensitivity(
    certificates: List[Dict[str, float]],
    labels: List[int],
    base_tau_R: float = 0.55,
    base_tau_S: float = 0.25,
    base_tau_N: float = 0.20,
    delta_range: float = 0.10,
    n_steps: int = 20,
) -> Dict[str, List[Dict[str, float]]]:
    """
    Analyze sensitivity of metrics to threshold changes.

    Useful for understanding:
    - Which threshold has most impact
    - Safe operating ranges
    - Risk of threshold drift

    Args:
        certificates: Certificate dicts
        labels: Ground truth labels
        base_tau_*: Base threshold values
        delta_range: Range to vary thresholds
        n_steps: Number of steps per threshold

    Returns:
        Dict with sensitivity curves for each threshold
    """
    optimizer = ThresholdOptimizer()

    R = np.array([c['R'] for c in certificates])
    S = np.array([c['S'] for c in certificates])
    N = np.array([c['N'] for c in certificates])
    y_true = np.array(labels)

    sensitivity = {'tau_R': [], 'tau_S': [], 'tau_N': []}

    # Vary tau_R
    for delta in np.linspace(-delta_range, delta_range, n_steps):
        tau_R = base_tau_R + delta
        y_pred = optimizer._apply_thresholds(R, S, N, tau_R, base_tau_S, base_tau_N)
        metrics = optimizer._compute_metrics(y_true, y_pred)
        sensitivity['tau_R'].append({
            'tau_R': tau_R,
            'delta': delta,
            'f1': metrics['f1'],
            'pass_rate': float(np.mean(y_pred)),
        })

    # Vary tau_S
    for delta in np.linspace(-delta_range, delta_range, n_steps):
        tau_S = base_tau_S + delta
        y_pred = optimizer._apply_thresholds(R, S, N, base_tau_R, tau_S, base_tau_N)
        metrics = optimizer._compute_metrics(y_true, y_pred)
        sensitivity['tau_S'].append({
            'tau_S': tau_S,
            'delta': delta,
            'f1': metrics['f1'],
            'pass_rate': float(np.mean(y_pred)),
        })

    # Vary tau_N
    for delta in np.linspace(-delta_range, delta_range, n_steps):
        tau_N = base_tau_N + delta
        y_pred = optimizer._apply_thresholds(R, S, N, base_tau_R, base_tau_S, tau_N)
        metrics = optimizer._compute_metrics(y_true, y_pred)
        sensitivity['tau_N'].append({
            'tau_N': tau_N,
            'delta': delta,
            'f1': metrics['f1'],
            'pass_rate': float(np.mean(y_pred)),
        })

    return sensitivity


def recommend_thresholds_for_domain(
    domain: str,
    risk_tolerance: str = "medium",
) -> Dict[str, float]:
    """
    Get recommended threshold starting points for common domains.

    Args:
        domain: Domain identifier ('medical', 'legal', 'financial', 'general')
        risk_tolerance: 'low' (strict), 'medium', 'high' (permissive)

    Returns:
        Dict with recommended tau_R, tau_S, tau_N
    """
    # Base thresholds by domain
    domain_defaults = {
        'medical': {'tau_R': 0.65, 'tau_S': 0.20, 'tau_N': 0.12},
        'legal': {'tau_R': 0.60, 'tau_S': 0.25, 'tau_N': 0.15},
        'financial': {'tau_R': 0.60, 'tau_S': 0.22, 'tau_N': 0.15},
        'industrial': {'tau_R': 0.70, 'tau_S': 0.15, 'tau_N': 0.10},
        'general': {'tau_R': 0.55, 'tau_S': 0.25, 'tau_N': 0.20},
    }

    # Get base thresholds
    base = domain_defaults.get(domain, domain_defaults['general'])

    # Adjust for risk tolerance
    if risk_tolerance == "low":
        # Stricter thresholds
        return {
            'tau_R': base['tau_R'] + 0.05,
            'tau_S': base['tau_S'] - 0.05,
            'tau_N': base['tau_N'] - 0.03,
        }
    elif risk_tolerance == "high":
        # More permissive
        return {
            'tau_R': base['tau_R'] - 0.05,
            'tau_S': base['tau_S'] + 0.05,
            'tau_N': base['tau_N'] + 0.05,
        }
    else:
        return base
