"""
Adversarial Attack Implementations

Provides attacks for testing rotor robustness:
- FGSM: Fast Gradient Sign Method (fast, single-step)
- PGD: Projected Gradient Descent (stronger, iterative)
- Noise: Random noise baseline

Reference:
    - Goodfellow et al., "Explaining and Harnessing Adversarial Examples" (FGSM)
    - Madry et al., "Towards Deep Learning Models Resistant to Adversarial Attacks" (PGD)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol, runtime_checkable
import numpy as np


# =============================================================================
# PORT (Interface)
# =============================================================================

@runtime_checkable
class IAttacker(Protocol):
    """Port: Adversarial attack interface."""

    @property
    def name(self) -> str:
        """Attack name."""
        ...

    @property
    def epsilon(self) -> float:
        """Perturbation budget."""
        ...

    def attack(
        self,
        model: Any,
        features: Any,
        target: Optional[Any] = None,
    ) -> Any:
        """
        Generate adversarial examples.

        Args:
            model: Model to attack
            features: Clean input features
            target: Optional target for targeted attacks

        Returns:
            Adversarial features
        """
        ...


# =============================================================================
# ATTACKS
# =============================================================================

@dataclass
class AttackConfig:
    """Configuration for adversarial attacks."""
    epsilon: float = 0.1  # Perturbation budget (L-inf)
    targeted: bool = False  # Targeted vs untargeted
    clip_min: float = -float('inf')
    clip_max: float = float('inf')


class FGSMAttacker:
    """
    Fast Gradient Sign Method (FGSM) attack.

    Single-step attack that perturbs in the direction of the gradient sign:
        x_adv = x + epsilon * sign(grad_x(L(x, y)))

    Fast but less effective than iterative attacks.
    """

    def __init__(
        self,
        epsilon: float = 0.1,
        targeted: bool = False,
        clip_min: float = -float('inf'),
        clip_max: float = float('inf'),
    ):
        self._epsilon = epsilon
        self._targeted = targeted
        self._clip_min = clip_min
        self._clip_max = clip_max

    @property
    def name(self) -> str:
        return "FGSM"

    @property
    def epsilon(self) -> float:
        return self._epsilon

    def attack(
        self,
        model: Any,
        features: Any,
        target: Optional[Any] = None,
    ) -> Any:
        """Generate FGSM adversarial examples."""
        import torch

        # Ensure features require grad
        features = features.clone().detach().requires_grad_(True)

        # Forward pass
        output = model(features)

        # Compute loss (maximize N for untargeted, minimize for targeted)
        if self._targeted and target is not None:
            # Targeted: minimize distance to target
            loss = -torch.mean((output['R'] - target) ** 2)
        else:
            # Untargeted: maximize N (noise component)
            loss = -output['N'].mean()

        # Backward pass
        loss.backward()

        # FGSM perturbation
        grad_sign = features.grad.sign()

        if self._targeted:
            # Move toward target
            adv_features = features - self._epsilon * grad_sign
        else:
            # Move away from clean
            adv_features = features + self._epsilon * grad_sign

        # Clip to valid range
        adv_features = torch.clamp(adv_features, self._clip_min, self._clip_max)

        return adv_features.detach()


class PGDAttacker:
    """
    Projected Gradient Descent (PGD) attack.

    Iterative attack that takes multiple small steps:
        x_0 = x + random_noise
        x_{t+1} = project(x_t + alpha * sign(grad_x(L(x_t, y))))

    Stronger than FGSM but slower.
    """

    def __init__(
        self,
        epsilon: float = 0.1,
        alpha: float = 0.01,
        n_steps: int = 10,
        random_start: bool = True,
        targeted: bool = False,
        clip_min: float = -float('inf'),
        clip_max: float = float('inf'),
    ):
        self._epsilon = epsilon
        self._alpha = alpha
        self._n_steps = n_steps
        self._random_start = random_start
        self._targeted = targeted
        self._clip_min = clip_min
        self._clip_max = clip_max

    @property
    def name(self) -> str:
        return f"PGD-{self._n_steps}"

    @property
    def epsilon(self) -> float:
        return self._epsilon

    def attack(
        self,
        model: Any,
        features: Any,
        target: Optional[Any] = None,
    ) -> Any:
        """Generate PGD adversarial examples."""
        import torch

        # Start with random perturbation if enabled
        if self._random_start:
            adv_features = features + torch.empty_like(features).uniform_(
                -self._epsilon, self._epsilon
            )
            adv_features = torch.clamp(adv_features, self._clip_min, self._clip_max)
        else:
            adv_features = features.clone()

        # Iterative attack
        for _ in range(self._n_steps):
            adv_features = adv_features.clone().detach().requires_grad_(True)

            # Forward pass
            output = model(adv_features)

            # Compute loss
            if self._targeted and target is not None:
                loss = -torch.mean((output['R'] - target) ** 2)
            else:
                loss = -output['N'].mean()

            # Backward pass
            loss.backward()

            # PGD step
            grad_sign = adv_features.grad.sign()

            if self._targeted:
                adv_features = adv_features - self._alpha * grad_sign
            else:
                adv_features = adv_features + self._alpha * grad_sign

            # Project back to epsilon ball
            perturbation = adv_features - features
            perturbation = torch.clamp(perturbation, -self._epsilon, self._epsilon)
            adv_features = features + perturbation

            # Clip to valid range
            adv_features = torch.clamp(adv_features, self._clip_min, self._clip_max)

        return adv_features.detach()


class NoiseAttacker:
    """
    Random noise attack (baseline).

    Simply adds random noise within epsilon budget:
        x_adv = x + uniform(-epsilon, epsilon)

    Used as a baseline to compare against gradient-based attacks.
    """

    def __init__(
        self,
        epsilon: float = 0.1,
        noise_type: str = "uniform",  # "uniform" or "gaussian"
        clip_min: float = -float('inf'),
        clip_max: float = float('inf'),
    ):
        self._epsilon = epsilon
        self._noise_type = noise_type
        self._clip_min = clip_min
        self._clip_max = clip_max

    @property
    def name(self) -> str:
        return f"Noise-{self._noise_type}"

    @property
    def epsilon(self) -> float:
        return self._epsilon

    def attack(
        self,
        model: Any,
        features: Any,
        target: Optional[Any] = None,
    ) -> Any:
        """Generate random noise adversarial examples."""
        import torch

        if self._noise_type == "uniform":
            noise = torch.empty_like(features).uniform_(
                -self._epsilon, self._epsilon
            )
        else:  # gaussian
            noise = torch.randn_like(features) * self._epsilon

        adv_features = features + noise
        adv_features = torch.clamp(adv_features, self._clip_min, self._clip_max)

        return adv_features


# =============================================================================
# Utility Functions
# =============================================================================

def compute_perturbation_norm(
    original: Any,
    adversarial: Any,
    norm: str = "linf",
) -> float:
    """
    Compute perturbation norm.

    Args:
        original: Original features
        adversarial: Adversarial features
        norm: Norm type ("l2", "linf")

    Returns:
        Perturbation norm
    """
    import torch

    diff = adversarial - original

    if norm == "linf":
        return diff.abs().max().item()
    elif norm == "l2":
        return diff.norm(p=2).item() / diff.numel() ** 0.5
    else:
        raise ValueError(f"Unknown norm: {norm}")
