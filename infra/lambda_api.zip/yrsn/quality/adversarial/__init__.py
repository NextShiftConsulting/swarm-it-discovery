"""
YRSN Adversarial Robustness Module

Provides tools for testing and improving rotor robustness against
adversarial perturbations.

Hexagonal Architecture:
    PORTS (Interfaces):
    - IAttacker: Adversarial attack interface
    - IDefender: Defense mechanism interface

    ADAPTERS (Implementations):
    - FGSMAttacker: Fast Gradient Sign Method
    - PGDAttacker: Projected Gradient Descent
    - InputSmoother: Randomized smoothing defense
    - AdversarialTrainer: Adversarial training

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 12)
    - docs/principles/FIRST_PRINCIPLES.md (P15: Universal Rotor)

Usage:
    >>> from yrsn.adversarial import FGSMAttacker, evaluate_robustness
    >>>
    >>> # Create attacker
    >>> attacker = FGSMAttacker(epsilon=0.1)
    >>>
    >>> # Generate adversarial examples
    >>> adv_features = attacker.attack(model, features)
    >>>
    >>> # Evaluate robustness
    >>> results = evaluate_robustness(model, test_loader, [attacker])
"""

from .attacks import (
    IAttacker,
    FGSMAttacker,
    PGDAttacker,
    NoiseAttacker,
)
from .defenses import (
    IDefender,
    InputSmoother,
    AdversarialTrainer,
)
from .evaluation import (
    evaluate_robustness,
    RobustnessResult,
)

__all__ = [
    # Ports
    'IAttacker',
    'IDefender',
    # Attacks
    'FGSMAttacker',
    'PGDAttacker',
    'NoiseAttacker',
    # Defenses
    'InputSmoother',
    'AdversarialTrainer',
    # Evaluation
    'evaluate_robustness',
    'RobustnessResult',
]
