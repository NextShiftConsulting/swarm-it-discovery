"""
Adversarial Defense Implementations

Provides defenses for improving rotor robustness:
- InputSmoother: Randomized smoothing
- AdversarialTrainer: Adversarial training

Reference:
    - Cohen et al., "Certified Adversarial Robustness via Randomized Smoothing"
    - Madry et al., "Towards Deep Learning Models Resistant to Adversarial Attacks"
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable, Callable
import numpy as np


# =============================================================================
# PORT (Interface)
# =============================================================================

@runtime_checkable
class IDefender(Protocol):
    """Port: Defense mechanism interface."""

    @property
    def name(self) -> str:
        """Defense name."""
        ...

    def defend(self, model: Any, features: Any) -> Any:
        """
        Apply defense to input features.

        Args:
            model: Model to defend
            features: Input features

        Returns:
            Defended prediction
        """
        ...


# =============================================================================
# DEFENSES
# =============================================================================

class InputSmoother:
    """
    Randomized smoothing defense.

    Adds noise to inputs and averages predictions:
        f_smooth(x) = E[f(x + noise)]

    Provides certified robustness guarantees.
    """

    def __init__(
        self,
        sigma: float = 0.1,
        n_samples: int = 100,
        aggregation: str = "mean",  # "mean" or "vote"
    ):
        self._sigma = sigma
        self._n_samples = n_samples
        self._aggregation = aggregation

    @property
    def name(self) -> str:
        return f"Smoothing-{self._sigma}"

    def defend(self, model: Any, features: Any) -> Dict[str, Any]:
        """Apply randomized smoothing defense."""
        import torch

        all_R = []
        all_S = []
        all_N = []

        model.eval()
        with torch.no_grad():
            for _ in range(self._n_samples):
                # Add Gaussian noise
                noise = torch.randn_like(features) * self._sigma
                noisy_features = features + noise

                # Get prediction
                output = model(noisy_features)
                all_R.append(output['R'])
                all_S.append(output['S'])
                all_N.append(output['N'])

        # Aggregate predictions
        R = torch.stack(all_R).mean(dim=0)
        S = torch.stack(all_S).mean(dim=0)
        N = torch.stack(all_N).mean(dim=0)

        # Normalize to simplex
        total = R + S + N
        R = R / total
        S = S / total
        N = N / total

        return {
            'R': R,
            'S': S,
            'N': N,
            'alpha': R,
            'smoothed': True,
            'n_samples': self._n_samples,
        }

    def certify(
        self,
        model: Any,
        features: Any,
        n_samples: int = 1000,
        alpha: float = 0.001,
    ) -> Dict[str, float]:
        """
        Certify robustness radius.

        Uses Neyman-Pearson to compute certified radius.
        """
        import torch
        from scipy import stats

        model.eval()
        predictions = []

        with torch.no_grad():
            for _ in range(n_samples):
                noise = torch.randn_like(features) * self._sigma
                noisy_features = features + noise
                output = model(noisy_features)

                # Get dominant class (R, S, or N)
                rsn = torch.stack([output['R'], output['S'], output['N']], dim=-1)
                pred = rsn.argmax(dim=-1).cpu().numpy()
                predictions.extend(pred.tolist())

        # Count predictions
        counts = np.bincount(predictions, minlength=3)
        n_A = counts.max()  # Top class count
        p_A = n_A / n_samples

        # Certified radius (using normal CDF)
        if p_A > 0.5:
            radius = self._sigma * stats.norm.ppf(p_A)
        else:
            radius = 0.0

        return {
            'certified_radius': radius,
            'top_class_prob': p_A,
            'n_samples': n_samples,
        }


class AdversarialTrainer:
    """
    Adversarial training defense.

    Trains model on both clean and adversarial examples:
        L_robust = L(x, y) + lambda * L(x_adv, y)

    Improves robustness at the cost of some clean accuracy.
    """

    def __init__(
        self,
        attacker: Any,  # IAttacker
        lambda_adv: float = 0.5,
        mix_ratio: float = 0.5,  # Ratio of adversarial examples
    ):
        self._attacker = attacker
        self._lambda_adv = lambda_adv
        self._mix_ratio = mix_ratio

    @property
    def name(self) -> str:
        return f"AdvTrain-{self._attacker.name}"

    def defend(self, model: Any, features: Any) -> Dict[str, Any]:
        """At inference, just run the model normally."""
        model.eval()
        with torch.no_grad():
            return model(features)

    def train_step(
        self,
        model: Any,
        optimizer: Any,
        features: Any,
        loss_fn: Callable,
    ) -> Dict[str, float]:
        """
        Perform one adversarial training step.

        Args:
            model: Model to train
            optimizer: Optimizer
            features: Clean input features
            loss_fn: Loss function

        Returns:
            Dict with loss values
        """
        import torch

        model.train()
        optimizer.zero_grad()

        # Clean forward pass
        clean_output = model(features)
        clean_loss = loss_fn(clean_output, features)

        # Generate adversarial examples
        model.eval()
        adv_features = self._attacker.attack(model, features)
        model.train()

        # Adversarial forward pass
        adv_output = model(adv_features)
        adv_loss = loss_fn(adv_output, adv_features)

        # Combined loss
        total_loss = clean_loss + self._lambda_adv * adv_loss

        # Backward pass
        total_loss.backward()
        optimizer.step()

        return {
            'clean_loss': clean_loss.item(),
            'adv_loss': adv_loss.item(),
            'total_loss': total_loss.item(),
        }

    def train_epoch(
        self,
        model: Any,
        optimizer: Any,
        data_loader: Any,
        loss_fn: Callable,
    ) -> Dict[str, float]:
        """
        Train for one epoch with adversarial training.

        Args:
            model: Model to train
            optimizer: Optimizer
            data_loader: Training data loader
            loss_fn: Loss function

        Returns:
            Dict with average losses
        """
        import torch

        total_clean = 0.0
        total_adv = 0.0
        n_batches = 0

        for batch in data_loader:
            if isinstance(batch, (list, tuple)):
                features = batch[0]
            else:
                features = batch

            losses = self.train_step(model, optimizer, features, loss_fn)

            total_clean += losses['clean_loss']
            total_adv += losses['adv_loss']
            n_batches += 1

        return {
            'avg_clean_loss': total_clean / n_batches,
            'avg_adv_loss': total_adv / n_batches,
        }


# Need to import torch for type hints
try:
    import torch
except ImportError:
    pass
