"""
Adversarial Robustness Evaluation

Provides tools for evaluating model robustness against adversarial attacks.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 12)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np


@dataclass
class AttackResult:
    """Result of a single attack on a batch."""
    attack_name: str
    epsilon: float
    clean_R: float
    adv_R: float
    R_drop: float  # clean_R - adv_R
    clean_N: float
    adv_N: float
    N_increase: float  # adv_N - clean_N
    success_rate: float  # Fraction where R dropped significantly
    avg_perturbation: float


@dataclass
class RobustnessResult:
    """Complete robustness evaluation result."""
    model_name: str
    n_samples: int
    attack_results: List[AttackResult]
    overall_robustness_score: float  # 0-1, higher = more robust
    weakest_attack: str
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'model_name': self.model_name,
            'n_samples': self.n_samples,
            'overall_robustness_score': self.overall_robustness_score,
            'weakest_attack': self.weakest_attack,
            'attacks': [
                {
                    'name': ar.attack_name,
                    'epsilon': ar.epsilon,
                    'R_drop': ar.R_drop,
                    'N_increase': ar.N_increase,
                    'success_rate': ar.success_rate,
                }
                for ar in self.attack_results
            ],
            'recommendations': self.recommendations,
        }


def evaluate_robustness(
    model: Any,
    data_loader: Any,
    attackers: List[Any],
    model_name: str = "model",
    success_threshold: float = 0.1,  # R drop to count as successful attack
) -> RobustnessResult:
    """
    Evaluate model robustness against multiple attacks.

    Args:
        model: Model to evaluate
        data_loader: Test data loader
        attackers: List of IAttacker instances
        model_name: Name for reporting
        success_threshold: R drop threshold for attack success

    Returns:
        RobustnessResult with detailed metrics
    """
    import torch

    model.eval()
    attack_results = []

    for attacker in attackers:
        clean_Rs = []
        adv_Rs = []
        clean_Ns = []
        adv_Ns = []
        perturbations = []
        successes = 0

        for batch in data_loader:
            if isinstance(batch, (list, tuple)):
                features = batch[0]
            else:
                features = batch

            # Clean predictions
            with torch.no_grad():
                clean_output = model(features)
                clean_R = clean_output['R'].cpu().numpy()
                clean_N = clean_output['N'].cpu().numpy()

            # Generate adversarial examples
            adv_features = attacker.attack(model, features)

            # Adversarial predictions
            with torch.no_grad():
                adv_output = model(adv_features)
                adv_R = adv_output['R'].cpu().numpy()
                adv_N = adv_output['N'].cpu().numpy()

            # Compute perturbation
            pert = (adv_features - features).abs().max().item()

            # Collect metrics
            clean_Rs.extend(clean_R.flatten().tolist())
            adv_Rs.extend(adv_R.flatten().tolist())
            clean_Ns.extend(clean_N.flatten().tolist())
            adv_Ns.extend(adv_N.flatten().tolist())
            perturbations.append(pert)

            # Count successes (R dropped significantly)
            successes += np.sum(clean_R - adv_R > success_threshold)

        # Compute attack result
        n_samples = len(clean_Rs)
        result = AttackResult(
            attack_name=attacker.name,
            epsilon=attacker.epsilon,
            clean_R=np.mean(clean_Rs),
            adv_R=np.mean(adv_Rs),
            R_drop=np.mean(clean_Rs) - np.mean(adv_Rs),
            clean_N=np.mean(clean_Ns),
            adv_N=np.mean(adv_Ns),
            N_increase=np.mean(adv_Ns) - np.mean(clean_Ns),
            success_rate=successes / n_samples if n_samples > 0 else 0,
            avg_perturbation=np.mean(perturbations),
        )
        attack_results.append(result)

    # Compute overall robustness score
    # Higher score = more robust (less R drop across attacks)
    if attack_results:
        max_R_drop = max(ar.R_drop for ar in attack_results)
        robustness_score = max(0, 1.0 - max_R_drop * 2)  # Scale to [0,1]
        weakest_attack = max(attack_results, key=lambda ar: ar.R_drop).attack_name
    else:
        robustness_score = 1.0
        weakest_attack = "none"

    # Generate recommendations
    recommendations = _generate_recommendations(attack_results, robustness_score)

    return RobustnessResult(
        model_name=model_name,
        n_samples=len(clean_Rs) if attack_results else 0,
        attack_results=attack_results,
        overall_robustness_score=robustness_score,
        weakest_attack=weakest_attack,
        recommendations=recommendations,
    )


def _generate_recommendations(
    attack_results: List[AttackResult],
    robustness_score: float,
) -> List[str]:
    """Generate recommendations based on evaluation results."""
    recommendations = []

    if robustness_score < 0.5:
        recommendations.append(
            "Model is vulnerable. Consider adversarial training or input smoothing."
        )

    for ar in attack_results:
        if ar.R_drop > 0.2:
            recommendations.append(
                f"Vulnerable to {ar.attack_name}: R drops by {ar.R_drop:.2f}. "
                f"Consider training with this attack."
            )

        if ar.N_increase > 0.15:
            recommendations.append(
                f"{ar.attack_name} increases N by {ar.N_increase:.2f}. "
                f"This may cause false alarms."
            )

    if not recommendations:
        recommendations.append(
            "Model shows good robustness. Consider testing with stronger attacks."
        )

    return recommendations


def quick_robustness_test(
    model: Any,
    n_samples: int = 100,
    embed_dim: int = 64,
    epsilons: List[float] = [0.05, 0.1, 0.2],
) -> RobustnessResult:
    """
    Quick robustness test with synthetic data.

    Useful for sanity checks and CI/CD.
    """
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    from .attacks import FGSMAttacker, PGDAttacker, NoiseAttacker

    # Create synthetic data
    features = torch.randn(n_samples, embed_dim)
    dataset = TensorDataset(features)
    loader = DataLoader(dataset, batch_size=32)

    # Create attackers
    attackers = []
    for eps in epsilons:
        attackers.append(FGSMAttacker(epsilon=eps))
        attackers.append(PGDAttacker(epsilon=eps, n_steps=5))
        attackers.append(NoiseAttacker(epsilon=eps))

    # Evaluate
    return evaluate_robustness(
        model=model,
        data_loader=loader,
        attackers=attackers,
        model_name="quick_test",
    )
