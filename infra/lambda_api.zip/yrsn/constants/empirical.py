"""
Empirically-Validated Physical Constants
=========================================

These are MEASURED values from S4 experimental series, NOT tunable parameters.
DO NOT MAKE THESE CONFIGURABLE without re-running full S4 calibration suite.

References:
- S4-000: Phase transition analysis
- S4-002b: Domain calibration measurements
- S4-033: Overconfidence measurements
- S4-003: Severity threshold calibration

CRITICAL: These constants are frozen using `typing.Final` to prevent reassignment.
Changing these values breaks the adaptive control loop calibration.
"""

from typing import Final, Dict

# =============================================================================
# QUALITY PHASE THRESHOLDS (S4-000)
# =============================================================================

# Phase transition thresholds from S4-000
# These are MEASURED phase transition points, not hyperparameters
ALPHA_HIGH_THRESHOLD: Final[float] = 0.70
"""
High → Medium quality phase transition (S4-000).

Phase boundary at τ_c1 = 1.43 ≈ 1/0.70.
Above this threshold: High quality, deterministic reasoning appropriate.
"""

ALPHA_LOW_THRESHOLD: Final[float] = 0.40
"""
Medium → Low quality phase transition (S4-000).

Phase boundary at τ_c2 = 2.50 = 1/0.40.
Below this threshold: Low quality, stochastic exploration needed.
"""

# =============================================================================
# DOMAIN CALIBRATION (S4-002b, S4-033)
# =============================================================================

# COMPRESSION domain calibration (theta < -5°)
COMPRESSION_ERROR_RATE: Final[float] = 0.226
"""Error rate for COMPRESSION domain: 22.6% (measured in S4-002b)."""

COMPRESSION_OVERCONFIDENCE: Final[float] = 0.131
"""Overconfidence rate for COMPRESSION domain: 13.1% (measured in S4-033)."""

COMPRESSION_ECE: Final[float] = 0.128
"""Expected Calibration Error for COMPRESSION domain (measured)."""

# NEUTRAL domain calibration (-5° ≤ theta ≤ +5°)
NEUTRAL_ERROR_RATE: Final[float] = 0.10
"""Error rate for NEUTRAL domain: ~10% (measured)."""

NEUTRAL_OVERCONFIDENCE: Final[float] = 0.10
"""Overconfidence rate for NEUTRAL domain: ~10% (measured)."""

NEUTRAL_ECE: Final[float] = 0.144
"""Expected Calibration Error for NEUTRAL domain (measured)."""

# EXPANSION domain calibration (theta > +5°)
EXPANSION_ERROR_RATE: Final[float] = 0.030
"""Error rate for EXPANSION domain: 3.0% (measured in S4-002b)."""

EXPANSION_OVERCONFIDENCE: Final[float] = 0.020
"""Overconfidence rate for EXPANSION domain: 2.0% (measured)."""

EXPANSION_ECE: Final[float] = 0.017
"""Expected Calibration Error for EXPANSION domain - well-calibrated (measured)."""

# =============================================================================
# DOMAIN CALIBRATION REGISTRY (Frozen)
# =============================================================================

DOMAIN_CALIBRATION: Final[Dict[str, Dict[str, float]]] = {
    'COMPRESSION': {
        'error_rate': COMPRESSION_ERROR_RATE,
        'overconfidence': COMPRESSION_OVERCONFIDENCE,
        'ece': COMPRESSION_ECE,
        'action': 'SCRUTINIZE',  # Requires validation
    },
    'NEUTRAL': {
        'error_rate': NEUTRAL_ERROR_RATE,
        'overconfidence': NEUTRAL_OVERCONFIDENCE,
        'ece': NEUTRAL_ECE,
        'action': 'MONITOR',
    },
    'EXPANSION': {
        'error_rate': EXPANSION_ERROR_RATE,
        'overconfidence': EXPANSION_OVERCONFIDENCE,
        'ece': EXPANSION_ECE,
        'action': 'TRUST',  # Reliable predictions
    },
}
"""
Domain calibration statistics from S4-002b and S4-033.

CRITICAL: This is MEASURED data, not configuration.
- COMPRESSION: Overconfident, high error rate (22.6%)
- EXPANSION: Well-calibrated, low error rate (3.0%)
- NEUTRAL: Intermediate calibration

These values determine enforcement actions and should NOT be modified
without re-running full S4 calibration experiments.
"""

# =============================================================================
# DRIFT THRESHOLDS (Lyapunov Analysis)
# =============================================================================

DRIFT_PHASE_SLIP: Final[float] = 0.2
"""
Nominal → Jitter transition (E201).

Chordal distance threshold marking phase slip.
Mathematically derived from Lyapunov stability analysis.
"""

DRIFT_BOUNDARY: Final[float] = 0.5
"""
Jitter → Drift transition (E203).

Chordal distance threshold marking boundary crossing.
Mathematically derived from Lyapunov stability analysis.
"""

DRIFT_COLLAPSE: Final[float] = 1.5
"""
Drift → Collapse transition (E204).

Chordal distance threshold marking collapse.
Mathematically derived from Lyapunov stability analysis.
THIS IS A PHYSICAL CONSTANT like the speed of light in a physics engine.
"""

# =============================================================================
# VALIDATION TOLERANCES
# =============================================================================

SIMPLEX_EPS: Final[float] = 1e-6
"""
Simplex constraint tolerance for R+S+N=1 validation.

Used in E301 (simplex violation) detection.
Empirically determined from numerical stability analysis.
"""

COHERENCE_FLOOR: Final[float] = 0.3
"""
Minimum coherence (omega) threshold for E302 detection.

Below this threshold, phasor coherence is too low for reliable decomposition.
Empirically determined from phasor analysis.
"""

GENUS_TARGET: Final[int] = 4
"""
Target genus for T⁴ topology (4-torus).

This defines the fundamental topological structure of the context space.
"""

# =============================================================================
# TEMPERATURE MAPPING CRITICAL TEMPERATURES
# =============================================================================

TAU_C1: Final[float] = 1.43
"""
First critical temperature (High → Medium phase transition).

Approximately 1/ALPHA_HIGH_THRESHOLD = 1/0.70 ≈ 1.43
"""

TAU_C2: Final[float] = 2.50
"""
Second critical temperature (Medium → Low phase transition).

Exactly 1/ALPHA_LOW_THRESHOLD = 1/0.40 = 2.50
"""
