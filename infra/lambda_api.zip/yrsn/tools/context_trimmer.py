"""
Context Trimmer: Quality-aware context compression.

Problem: Context windows fill up, but much content is noise/filler.
Solution: Trim low-quality content, keep high-R sentences.

Usage:
    from yrsn.tools import context_trimmer

    trimmed = context_trimmer.trim(
        context="Long document with noise...",
        query="What is the main point?",
        target_words=200
    )
"""

from typing import Any, Dict, List
import re

from yrsn.core import compute_yrsn
from yrsn.core.tool import tool


@tool(category="quality", tags=["context", "compression"])
def trim(
    context: str,
    query: str = "",
    target_words: int = 500,
    min_quality: float = 0.3,
) -> Dict[str, Any]:
    """
    Trim context to target size while preserving quality.

    Args:
        context: The context to trim
        query: Query for relevance scoring
        target_words: Target word count
        min_quality: Minimum quality to keep

    Returns:
        Trimmed context with metrics
    """
    sentences = _split_sentences(context)
    original_words = len(context.split())

    if original_words <= target_words:
        return {
            "trimmed_context": context,
            "original_words": original_words,
            "final_words": original_words,
            "words_saved": 0,
            "compression_ratio": 1.0,
            "message": "Context already under target size",
        }

    # Score each sentence
    scored = []
    for sent in sentences:
        if len(sent.split()) < 3:
            continue
        yrsn = compute_yrsn(sent, query)
        scored.append({
            "text": sent,
            "quality": yrsn.quality,
            "word_count": len(sent.split()),
        })

    # Filter by quality and sort
    filtered = [s for s in scored if s["quality"] >= min_quality]
    filtered.sort(key=lambda x: x["quality"], reverse=True)

    # Select sentences up to target
    selected = []
    current_words = 0

    for sent in filtered:
        if current_words + sent["word_count"] <= target_words:
            selected.append(sent)
            current_words += sent["word_count"]

    # Restore original order
    original_order = {s["text"]: i for i, s in enumerate(scored)}
    selected.sort(key=lambda x: original_order.get(x["text"], 999))

    trimmed = " ".join(s["text"] for s in selected)
    final_words = len(trimmed.split())

    # Quality improvement
    original_yrsn = compute_yrsn(context, query)
    trimmed_yrsn = compute_yrsn(trimmed, query) if trimmed else original_yrsn

    return {
        "trimmed_context": trimmed,
        "original_words": original_words,
        "final_words": final_words,
        "words_saved": original_words - final_words,
        "compression_ratio": round(final_words / original_words, 3) if original_words > 0 else 1,
        "quality_before": original_yrsn.quality,
        "quality_after": trimmed_yrsn.quality,
        "quality_improvement": round(trimmed_yrsn.quality - original_yrsn.quality, 3),
        "sentences_kept": len(selected),
        "sentences_removed": len(scored) - len(selected),
    }


@tool(category="quality", tags=["context", "noise"])
def remove_noise(
    context: str,
    aggressive: bool = False,
) -> Dict[str, Any]:
    """
    Remove noise patterns from context.

    Args:
        context: Context to clean
        aggressive: Use aggressive noise removal

    Returns:
        Cleaned context with removal stats
    """
    original = context
    removed = []

    # Noise patterns to remove
    patterns = [
        (r'(click here|buy now|subscribe|limited time|special offer)', "promotional"),
        (r'(advertisement|sponsored|ad:)', "advertising"),
        (r'https?://[^\s]+', "urls"),
        (r'\[.*?\]\(.*?\)', "markdown_links"),
        (r'<[^>]+>', "html_tags"),
    ]

    if aggressive:
        patterns.extend([
            (r'\(.*?\)', "parentheticals"),
            (r'e\.g\.,.*?(?=[.!?])', "examples"),
            (r'for example,.*?(?=[.!?])', "examples"),
        ])

    for pattern, category in patterns:
        matches = re.findall(pattern, context, re.IGNORECASE)
        if matches:
            removed.append({"category": category, "count": len(matches)})
            context = re.sub(pattern, '', context, flags=re.IGNORECASE)

    # Clean up whitespace
    context = re.sub(r'\s+', ' ', context).strip()

    original_words = len(original.split())
    final_words = len(context.split())

    return {
        "cleaned_context": context,
        "original_words": original_words,
        "final_words": final_words,
        "removed": removed,
        "total_removed": sum(r["count"] for r in removed),
    }


@tool(category="quality", tags=["context", "extraction"])
def extract_key_content(
    context: str,
    query: str = "",
    top_k: int = 5,
) -> Dict[str, Any]:
    """
    Extract the most relevant sentences.

    Args:
        context: Source context
        query: Query for relevance
        top_k: Number of sentences to extract

    Returns:
        Top sentences by quality
    """
    sentences = _split_sentences(context)

    scored = []
    for sent in sentences:
        if len(sent.split()) < 5:
            continue
        yrsn = compute_yrsn(sent, query)
        scored.append({
            "text": sent,
            "quality": yrsn.quality,
            "R": yrsn.R,
            "S": yrsn.S,
            "N": yrsn.N,
        })

    scored.sort(key=lambda x: x["quality"], reverse=True)
    top = scored[:top_k]

    return {
        "query": query or "none",
        "total_sentences": len(sentences),
        "extracted_count": len(top),
        "key_sentences": [
            {"rank": i + 1, "text": s["text"], "quality": s["quality"]}
            for i, s in enumerate(top)
        ],
        "avg_quality": round(sum(s["quality"] for s in top) / len(top), 3) if top else 0,
    }


def _split_sentences(text: str) -> List[str]:
    """Split text into sentences."""
    # Simple sentence splitting
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if s.strip()]
