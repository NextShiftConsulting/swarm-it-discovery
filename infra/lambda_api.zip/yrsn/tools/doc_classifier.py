"""
Document Classifier: Multi-document relevance classification.

Problem: Need to classify/rank documents for a query.
Solution: Score documents using YRSN, classify by relevance tiers.

Usage:
    from yrsn.tools import doc_classifier

    docs = [
        {"title": "Python Guide", "content": "..."},
        {"title": "Spam Doc", "content": "Buy now!"},
    ]
    classified = doc_classifier.classify(docs, query="Python programming")
"""

from typing import Any, Dict, List, Optional
import re

from yrsn.core import compute_yrsn
from yrsn.core.tool import tool


@tool(category="retrieval", tags=["documents", "classification"])
def classify(
    documents: List[Dict[str, Any]],
    query: str,
    min_quality: float = 0.2,
) -> Dict[str, Any]:
    """
    Classify documents into relevance tiers.

    Tiers:
        - highly_relevant: quality >= 0.7
        - relevant: quality >= 0.5
        - marginally_relevant: quality >= 0.3
        - not_relevant: quality < 0.3

    Args:
        documents: Documents with 'title' and 'content'
        query: Query for relevance scoring
        min_quality: Minimum quality to include

    Returns:
        Classified documents by tier
    """
    scored = []
    for i, doc in enumerate(documents):
        content = doc.get("content", doc.get("text", ""))
        title = doc.get("title", f"Document {i+1}")

        result = _score_document(content, query, title)
        result["original_index"] = i
        scored.append(result)

    # Group by tier
    tiers = {
        "highly_relevant": [],
        "relevant": [],
        "marginally_relevant": [],
        "not_relevant": [],
    }

    for doc in scored:
        if doc["quality"] >= min_quality:
            tiers[doc["tier"]].append(doc)

    # Sort each tier
    for tier in tiers:
        tiers[tier].sort(key=lambda x: x["quality"], reverse=True)

    return {
        "query": query,
        "total_documents": len(documents),
        "tier_counts": {tier: len(docs) for tier, docs in tiers.items()},
        "avg_quality": round(sum(d["quality"] for d in scored) / len(scored), 3) if scored else 0,
        "tiers": {
            tier: [{"title": d["title"], "quality": d["quality"]} for d in docs]
            for tier, docs in tiers.items()
        },
    }


@tool(category="retrieval", tags=["documents", "ranking"])
def rank(
    documents: List[Dict[str, Any]],
    query: str,
    top_k: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Rank documents by YRSN quality.

    Args:
        documents: Documents to rank
        query: Query for relevance
        top_k: Return top K documents

    Returns:
        Ranked documents
    """
    scored = []
    for i, doc in enumerate(documents):
        content = doc.get("content", doc.get("text", ""))
        title = doc.get("title", f"Document {i+1}")

        result = _score_document(content, query, title)
        result["original_rank"] = i + 1
        scored.append(result)

    # Sort by quality
    ranked = sorted(scored, key=lambda x: x["quality"], reverse=True)

    if top_k:
        ranked = ranked[:top_k]

    # Add new ranks
    for new_rank, doc in enumerate(ranked, 1):
        doc["new_rank"] = new_rank
        doc["rank_change"] = doc["original_rank"] - new_rank

    return {
        "query": query,
        "total_documents": len(documents),
        "returned_documents": len(ranked),
        "results": [
            {
                "rank": d["new_rank"],
                "title": d["title"],
                "quality": d["quality"],
                "tier": d["tier"],
                "rank_change": d["rank_change"],
            }
            for d in ranked
        ],
    }


@tool(category="retrieval", tags=["documents", "selection"])
def find_best(
    documents: List[Dict[str, Any]],
    query: str,
    count: int = 3,
    min_quality: float = 0.5,
    diverse: bool = True,
) -> Dict[str, Any]:
    """
    Find the best documents for a query.

    Args:
        documents: Document pool
        query: The query
        count: Number to return
        min_quality: Minimum quality
        diverse: Ensure source diversity

    Returns:
        Best documents
    """
    scored = []
    for i, doc in enumerate(documents):
        content = doc.get("content", doc.get("text", ""))
        title = doc.get("title", f"Document {i+1}")
        source = doc.get("source", "")

        result = _score_document(content, query, title)
        result["source"] = source
        result["content_preview"] = content[:200] + "..." if len(content) > 200 else content
        scored.append(result)

    # Filter by quality
    qualified = [d for d in scored if d["quality"] >= min_quality]
    qualified.sort(key=lambda x: x["quality"], reverse=True)

    if diverse:
        selected = []
        seen_sources = set()
        for doc in qualified:
            if doc["source"] and doc["source"] in seen_sources:
                continue
            selected.append(doc)
            if doc["source"]:
                seen_sources.add(doc["source"])
            if len(selected) >= count:
                break
    else:
        selected = qualified[:count]

    return {
        "query": query,
        "total_candidates": len(documents),
        "qualified_count": len(qualified),
        "selected_count": len(selected),
        "documents": [
            {
                "title": d["title"],
                "quality": d["quality"],
                "tier": d["tier"],
                "preview": d["content_preview"],
            }
            for d in selected
        ],
    }


def _score_document(content: str, query: str, title: str = "") -> Dict[str, Any]:
    """Score a single document."""
    combined = f"{title}\n{content}"
    yrsn = compute_yrsn(combined, query)

    # Determine tier
    if yrsn.quality >= 0.7:
        tier = "highly_relevant"
    elif yrsn.quality >= 0.5:
        tier = "relevant"
    elif yrsn.quality >= 0.3:
        tier = "marginally_relevant"
    else:
        tier = "not_relevant"

    return {
        "title": title,
        "word_count": len(content.split()),
        "R": yrsn.R,
        "S": yrsn.S,
        "N": yrsn.N,
        "quality": yrsn.quality,
        "tier": tier,
    }
