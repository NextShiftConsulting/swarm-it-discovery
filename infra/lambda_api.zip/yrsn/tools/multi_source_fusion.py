"""
Multi-Source Fusion: Merge sources with conflict detection.

Problem: Multiple sources may have overlapping or conflicting information.
Solution: Use YRSN to fuse sources while detecting CONFLICT collapse.

Usage:
    from yrsn.tools import multi_source_fusion

    sources = [
        {"content": "Python was created in 1991", "source": "wiki"},
        {"content": "Python was released in 1989", "source": "blog"},
    ]
    result = multi_source_fusion.detect_conflicts(sources)
    # Returns: conflicts_detected=1, collapse_type="CONFLICT"
"""

from typing import Any, Dict, List, Tuple
import re

from yrsn.core import compute_yrsn
from yrsn.core.tool import tool


@tool(category="quality", tags=["fusion", "conflicts"])
def detect_conflicts(
    sources: List[Dict[str, Any]],
    query: str = "",
) -> Dict[str, Any]:
    """
    Detect conflicts between sources.

    Args:
        sources: Sources with 'content'
        query: Query context

    Returns:
        Conflict analysis with collapse detection
    """
    # Extract facts from each source
    all_facts: Dict[str, List[Tuple[str, str]]] = {}

    for i, source in enumerate(sources):
        content = source.get("content", source.get("text", ""))
        name = source.get("source", f"Source {i+1}")

        facts = _extract_facts(content)
        for fact in facts:
            topic = _extract_topic(fact)
            if topic not in all_facts:
                all_facts[topic] = []
            all_facts[topic].append((fact, name))

    # Detect conflicts
    conflicts = []
    for topic, claims in all_facts.items():
        if len(claims) < 2:
            continue

        conflict = _check_conflict([c[0] for c in claims])
        if conflict["is_conflict"]:
            conflicts.append({
                "topic": topic,
                "claims": [{"claim": c[0], "source": c[1]} for c in claims],
                "conflict_type": conflict["type"],
                "severity": conflict["severity"],
            })

    # Collapse detection
    total_topics = len(all_facts)
    conflicting = len(conflicts)

    if conflicting > total_topics * 0.3:
        collapse_type = "CONFLICT"
        severity = "high"
    elif conflicting > 0:
        collapse_type = "CONFLICT"
        severity = "medium"
    else:
        collapse_type = "NONE"
        severity = "none"

    return {
        "sources_analyzed": len(sources),
        "topics_found": total_topics,
        "conflicts_detected": len(conflicts),
        "conflict_ratio": round(conflicting / max(total_topics, 1), 3),
        "collapse": {
            "type": collapse_type,
            "severity": severity,
        },
        "conflicts": conflicts[:10],
        "recommendation": _get_recommendation(severity),
    }


@tool(category="quality", tags=["fusion", "merge"])
def fuse(
    sources: List[Dict[str, Any]],
    query: str = "",
    max_length: int = 1000,
    strategy: str = "quality_weighted",
) -> Dict[str, Any]:
    """
    Fuse multiple sources into unified context.

    Strategies:
        - quality_weighted: Prioritize by YRSN quality
        - consensus: Avoid conflicting sources
        - simple: Concatenate by order

    Args:
        sources: Sources to fuse
        query: Query for relevance
        max_length: Max words in output
        strategy: Fusion strategy

    Returns:
        Fused content with quality metrics
    """
    # Score sources
    scored = []
    for i, source in enumerate(sources):
        content = source.get("content", source.get("text", ""))
        name = source.get("source", f"Source {i+1}")

        yrsn = compute_yrsn(content, query) if query else compute_yrsn(content)
        scored.append({
            "source": name,
            "content": content,
            "relevance": yrsn.quality,
            "words": len(content.split()),
        })

    # Sort by relevance
    scored.sort(key=lambda x: x["relevance"], reverse=True)

    # Check conflicts
    conflict_result = detect_conflicts(sources, query)

    # Build fused content
    if strategy == "consensus" and conflict_result["conflicts_detected"] > 0:
        # Avoid conflicting sources
        conflicting_sources = set()
        for conflict in conflict_result["conflicts"]:
            for claim in conflict["claims"]:
                conflicting_sources.add(claim["source"])

        scored = [s for s in scored if s["source"] not in conflicting_sources] + \
                 [s for s in scored if s["source"] in conflicting_sources]

    # Select up to max_length
    selected = []
    current_words = 0
    for source in scored:
        if current_words + source["words"] <= max_length:
            selected.append(source)
            current_words += source["words"]

    fused = "\n\n".join(s["content"] for s in selected)

    # Quality metrics
    R = sum(s["relevance"] for s in selected) / max(len(selected), 1)
    N = conflict_result["conflict_ratio"] * 0.5
    quality = R / (R + N + 0.1) if (R + N + 0.1) > 0 else 0.5

    return {
        "fused_content": fused,
        "word_count": len(fused.split()),
        "sources_used": len(selected),
        "sources_total": len(sources),
        "strategy": strategy,
        "quality": round(quality, 3),
        "conflicts_in_fusion": conflict_result["conflicts_detected"],
        "source_contributions": [
            {"source": s["source"], "relevance": round(s["relevance"], 3)}
            for s in selected
        ],
    }


@tool(category="quality", tags=["fusion", "agreement"])
def compute_agreement(
    sources: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Compute agreement level between sources.

    Args:
        sources: Sources to compare

    Returns:
        Agreement metrics
    """
    if len(sources) < 2:
        return {"error": "Need at least 2 sources"}

    # Extract facts from each
    source_facts = []
    for i, source in enumerate(sources):
        content = source.get("content", source.get("text", ""))
        name = source.get("source", f"Source {i+1}")
        facts = set(f.lower() for f in _extract_facts(content))
        source_facts.append({"source": name, "facts": facts})

    # Pairwise agreement (Jaccard similarity)
    agreements = []
    for i in range(len(source_facts)):
        for j in range(i + 1, len(source_facts)):
            s1, s2 = source_facts[i], source_facts[j]
            intersection = len(s1["facts"] & s2["facts"])
            union = len(s1["facts"] | s2["facts"])
            similarity = intersection / max(union, 1)

            agreements.append({
                "sources": [s1["source"], s2["source"]],
                "similarity": round(similarity, 3),
            })

    avg_agreement = sum(a["similarity"] for a in agreements) / max(len(agreements), 1)

    if avg_agreement > 0.7:
        level = "high"
    elif avg_agreement > 0.4:
        level = "moderate"
    else:
        level = "low"

    return {
        "sources_compared": len(sources),
        "average_agreement": round(avg_agreement, 3),
        "agreement_level": level,
        "pairwise_agreements": agreements,
        "recommendation": f"Sources show {level} agreement - {'safe to merge' if level != 'low' else 'review conflicts'}",
    }


def _extract_facts(text: str) -> List[str]:
    """Extract factual claims."""
    sentences = re.split(r'[.!?]+', text)
    facts = []

    for sent in sentences:
        sent = sent.strip()
        if len(sent.split()) < 4:
            continue
        if re.search(r'(is|are|was|were|has|have|created|founded|released)', sent.lower()):
            facts.append(sent)

    return facts[:15]


def _extract_topic(fact: str) -> str:
    """Extract topic from fact."""
    words = [w for w in fact.split()[:4] if len(w) > 2]
    return " ".join(words).lower()


def _check_conflict(claims: List[str]) -> Dict[str, Any]:
    """Check for conflicts between claims."""
    if len(claims) < 2:
        return {"is_conflict": False, "type": None, "severity": 0}

    # Check for different numbers
    numbers = [set(re.findall(r'\b\d+\b', c)) for c in claims]
    if len(numbers) >= 2 and numbers[0] and numbers[1]:
        if numbers[0] != numbers[1]:
            return {"is_conflict": True, "type": "NUMERIC_DISAGREEMENT", "severity": 0.7}

    # Check for negation
    combined = " ".join(claims).lower()
    if re.search(r'not|never|false|incorrect', combined):
        return {"is_conflict": True, "type": "NEGATION_CONFLICT", "severity": 0.8}

    return {"is_conflict": False, "type": None, "severity": 0}


def _get_recommendation(severity: str) -> str:
    """Get recommendation based on severity."""
    if severity == "high":
        return "HIGH CONFLICT: Review sources manually before using"
    elif severity == "medium":
        return "Some conflicts - use consensus strategy"
    else:
        return "Low/no conflicts - safe to merge"
