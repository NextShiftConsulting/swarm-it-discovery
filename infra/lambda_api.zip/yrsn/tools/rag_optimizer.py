"""
RAG Optimizer: Quality-based RAG result optimization.

Problem: RAG returns chunks by similarity, not quality.
Solution: Score and re-rank by YRSN quality (R > S > N).

Usage:
    from yrsn.tools import rag_optimizer

    chunks = [
        {"text": "Python is a programming language...", "score": 0.9},
        {"text": "Click here to subscribe!", "score": 0.85},
    ]
    optimized = rag_optimizer.optimize(chunks, query="What is Python?")
"""

from typing import Any, Dict, List, Optional
import re

from yrsn.core import compute_yrsn, YRSNScore
from yrsn.core.tool import tool


@tool(category="retrieval", tags=["rag", "optimization", "chunks"])
def score_chunk(
    text: str,
    query: str,
    source: str = "",
) -> Dict[str, Any]:
    """
    Score a RAG chunk for YRSN quality.

    Args:
        text: Chunk text content
        query: The query this chunk should answer
        source: Source identifier for tracking

    Returns:
        YRSN scores and quality assessment
    """
    yrsn = compute_yrsn(text, query)

    # Additional chunk-specific signals
    word_count = len(text.split())
    is_stub = word_count < 20
    is_verbose = word_count > 500

    return {
        "text_preview": text[:100] + "..." if len(text) > 100 else text,
        "source": source,
        "word_count": word_count,
        "R": yrsn.R,
        "S": yrsn.S,
        "N": yrsn.N,
        "quality": yrsn.quality,
        "temperature": yrsn.temperature,
        "flags": {
            "is_stub": is_stub,
            "is_verbose": is_verbose,
        },
    }


@tool(category="retrieval", tags=["rag", "optimization", "batch"])
def optimize(
    chunks: List[Dict[str, Any]],
    query: str,
    top_k: int = 5,
    min_quality: float = 0.3,
    diversity_penalty: float = 0.1,
) -> Dict[str, Any]:
    """
    Optimize RAG results by YRSN quality.

    Args:
        chunks: RAG chunks with 'text' and optionally 'score', 'source'
        query: The query being answered
        top_k: Number of chunks to return
        min_quality: Minimum YRSN quality threshold
        diversity_penalty: Penalty for same-source chunks

    Returns:
        Optimized chunks ranked by quality
    """
    scored = []
    for i, chunk in enumerate(chunks):
        text = chunk.get("text", chunk.get("content", ""))
        source = chunk.get("source", f"chunk_{i}")
        original_score = chunk.get("score", 0.5)

        result = score_chunk(text, query, source)
        result["original_rank"] = i + 1
        result["original_score"] = original_score
        result["full_text"] = text
        scored.append(result)

    # Filter by quality
    filtered = [c for c in scored if c["quality"] >= min_quality]

    # Sort by quality (with diversity penalty)
    seen_sources = set()
    reranked = []

    for chunk in sorted(filtered, key=lambda x: x["quality"], reverse=True):
        adjusted_quality = chunk["quality"]
        if chunk["source"] in seen_sources:
            adjusted_quality -= diversity_penalty
        chunk["adjusted_quality"] = round(adjusted_quality, 3)
        reranked.append(chunk)
        seen_sources.add(chunk["source"])

    # Re-sort by adjusted quality and take top_k
    reranked.sort(key=lambda x: x["adjusted_quality"], reverse=True)
    selected = reranked[:top_k]

    # Compute improvement metrics
    original_avg = sum(c["original_score"] for c in scored) / len(scored) if scored else 0
    optimized_avg = sum(c["quality"] for c in selected) / len(selected) if selected else 0

    return {
        "query": query,
        "input_chunks": len(chunks),
        "filtered_chunks": len(filtered),
        "output_chunks": len(selected),
        "metrics": {
            "original_avg_score": round(original_avg, 3),
            "optimized_avg_quality": round(optimized_avg, 3),
            "improvement": round(optimized_avg - original_avg, 3),
        },
        "chunks": [
            {
                "rank": i + 1,
                "text": c["full_text"],
                "quality": c["quality"],
                "source": c["source"],
                "original_rank": c["original_rank"],
            }
            for i, c in enumerate(selected)
        ],
    }


@tool(category="retrieval", tags=["rag", "analysis"])
def analyze(
    chunks: List[Dict[str, Any]],
    query: str,
) -> Dict[str, Any]:
    """
    Analyze RAG result quality distribution.

    Args:
        chunks: RAG chunks to analyze
        query: The query context

    Returns:
        Quality distribution analysis
    """
    scored = []
    for chunk in chunks:
        text = chunk.get("text", chunk.get("content", ""))
        yrsn = compute_yrsn(text, query)
        scored.append({
            "R": yrsn.R,
            "S": yrsn.S,
            "N": yrsn.N,
            "quality": yrsn.quality,
        })

    if not scored:
        return {"error": "No chunks to analyze"}

    qualities = [s["quality"] for s in scored]

    return {
        "chunk_count": len(chunks),
        "quality_stats": {
            "mean": round(sum(qualities) / len(qualities), 3),
            "min": round(min(qualities), 3),
            "max": round(max(qualities), 3),
        },
        "yrsn_composition": {
            "avg_R": round(sum(s["R"] for s in scored) / len(scored), 3),
            "avg_S": round(sum(s["S"] for s in scored) / len(scored), 3),
            "avg_N": round(sum(s["N"] for s in scored) / len(scored), 3),
        },
        "quality_distribution": {
            "high": sum(1 for q in qualities if q >= 0.7),
            "medium": sum(1 for q in qualities if 0.4 <= q < 0.7),
            "low": sum(1 for q in qualities if q < 0.4),
        },
        "recommendation": _get_recommendation(qualities),
    }


def _get_recommendation(qualities: List[float]) -> str:
    """Generate recommendation based on quality distribution."""
    avg = sum(qualities) / len(qualities) if qualities else 0
    low_count = sum(1 for q in qualities if q < 0.4)
    low_ratio = low_count / len(qualities) if qualities else 0

    if avg >= 0.7:
        return "High quality RAG results - safe to use as-is"
    elif low_ratio > 0.5:
        return "Most chunks are low quality - consider better retrieval or more specific query"
    elif avg >= 0.5:
        return "Mixed quality - use optimize() to filter and rerank"
    else:
        return "Low overall quality - expand search or improve document corpus"
