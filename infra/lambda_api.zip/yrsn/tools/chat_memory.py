"""
Chat Memory: Quality-aware conversation history management.

Problem: Chat history grows, fills context, old messages become noise.
Solution: Score messages by quality, decay old messages, prune low-value history.

Usage:
    from yrsn.tools import chat_memory

    messages = [
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi! How can I help?"},
        {"role": "user", "content": "Tell me about Python"},
    ]
    optimized = chat_memory.optimize(messages, query="Python")
"""

from typing import Any, Dict, List, Optional
import re
import time

from yrsn.core import compute_yrsn
from yrsn.core.tool import tool


@tool(category="quality", tags=["chat", "memory", "optimization"])
def optimize(
    messages: List[Dict[str, Any]],
    query: str = "",
    target_messages: Optional[int] = None,
    min_quality: float = 0.25,
    preserve_recent: int = 2,
) -> Dict[str, Any]:
    """
    Optimize chat history by removing low-quality messages.

    Args:
        messages: Chat messages with 'role' and 'content'
        query: Current topic for relevance
        target_messages: Target message count (default: half)
        min_quality: Minimum quality threshold
        preserve_recent: Always keep N most recent messages

    Returns:
        Optimized message history
    """
    total = len(messages)
    if target_messages is None:
        target_messages = max(total // 2, 5)

    # Score all messages
    scored = []
    for i, msg in enumerate(messages):
        score = _score_message(
            content=msg.get("content", ""),
            role=msg.get("role", "user"),
            query=query,
            position=i,
            total=total,
        )
        score["original_index"] = i
        score["message"] = msg
        scored.append(score)

    # Separate protected messages
    system_msgs = [s for s in scored if s["role"] == "system"]
    recent_msgs = scored[-preserve_recent:] if preserve_recent > 0 else []
    other_msgs = [s for s in scored if s not in system_msgs and s not in recent_msgs]

    # Filter by quality
    filtered = [s for s in other_msgs if s["quality"] >= min_quality]
    filtered.sort(key=lambda x: x["quality"], reverse=True)

    # Select top messages
    slots = target_messages - len(system_msgs) - len(recent_msgs)
    selected = filtered[:max(slots, 0)]

    # Combine and restore order
    all_selected = system_msgs + selected + recent_msgs
    all_selected.sort(key=lambda x: x["original_index"])

    optimized = [s["message"] for s in all_selected]

    # Calculate metrics
    original_words = sum(len(m.get("content", "").split()) for m in messages)
    optimized_words = sum(len(m.get("content", "").split()) for m in optimized)

    return {
        "original_count": total,
        "optimized_count": len(optimized),
        "messages_removed": total - len(optimized),
        "original_words": original_words,
        "optimized_words": optimized_words,
        "words_saved": original_words - optimized_words,
        "compression_ratio": round(len(optimized) / total, 3) if total > 0 else 1,
        "messages": optimized,
    }


@tool(category="quality", tags=["chat", "analysis"])
def detect_bloat(
    messages: List[Dict[str, Any]],
    bloat_threshold: float = 0.3,
) -> Dict[str, Any]:
    """
    Detect if chat history is bloated.

    Args:
        messages: Chat messages
        bloat_threshold: Threshold for bloat detection

    Returns:
        Bloat analysis with recommendations
    """
    total = len(messages)

    scored = []
    for i, msg in enumerate(messages):
        score = _score_message(
            content=msg.get("content", ""),
            role=msg.get("role", "user"),
            position=i,
            total=total,
        )
        scored.append(score)

    # Calculate bloat metrics
    low_quality = sum(1 for s in scored if s["quality"] < bloat_threshold)
    avg_S = sum(s["S"] for s in scored) / len(scored) if scored else 0
    avg_N = sum(s["N"] for s in scored) / len(scored) if scored else 0

    bloat_ratio = (avg_S + avg_N) / 2
    is_bloated = bloat_ratio > 0.4 or low_quality / total > 0.5

    return {
        "total_messages": total,
        "is_bloated": is_bloated,
        "bloat_severity": "high" if bloat_ratio > 0.6 else "medium" if bloat_ratio > 0.4 else "low",
        "low_quality_count": low_quality,
        "bloat_ratio": round(bloat_ratio, 3),
        "recommendation": "Run optimize() to reduce bloat" if is_bloated else "History is healthy",
    }


@tool(category="quality", tags=["chat", "summary"])
def summarize(
    messages: List[Dict[str, Any]],
    query: str = "",
) -> Dict[str, Any]:
    """
    Summarize chat history quality.

    Args:
        messages: Chat messages
        query: Current topic

    Returns:
        Summary with key messages identified
    """
    total = len(messages)

    scored = []
    for i, msg in enumerate(messages):
        score = _score_message(
            content=msg.get("content", ""),
            role=msg.get("role", "user"),
            query=query,
            position=i,
            total=total,
        )
        score["message"] = msg
        scored.append(score)

    # Find key messages
    sorted_by_quality = sorted(scored, key=lambda x: x["quality"], reverse=True)
    key_messages = sorted_by_quality[:5]

    # Role breakdown
    user_msgs = [s for s in scored if s["role"] == "user"]
    assistant_msgs = [s for s in scored if s["role"] == "assistant"]

    return {
        "total_messages": total,
        "message_breakdown": {
            "user": len(user_msgs),
            "assistant": len(assistant_msgs),
            "system": total - len(user_msgs) - len(assistant_msgs),
        },
        "avg_quality": round(sum(s["quality"] for s in scored) / total, 3) if total > 0 else 0,
        "key_messages": [
            {"role": m["role"], "preview": m["preview"], "quality": m["quality"]}
            for m in key_messages
        ],
        "filler_count": sum(1 for s in scored if s.get("is_filler", False)),
    }


def _score_message(
    content: str,
    role: str,
    query: str = "",
    position: int = 0,
    total: int = 1,
) -> Dict[str, Any]:
    """Score a single message."""
    content_lower = content.lower()

    # YRSN quality
    yrsn = compute_yrsn(content, query)

    # Role weight
    role_weight = {"system": 1.2, "user": 1.0, "assistant": 0.9}.get(role, 1.0)

    # Filler detection
    is_filler = bool(re.search(
        r'^(hi|hello|hey|thanks|ok|okay|sure|got it)',
        content_lower
    ))

    # Recency decay
    recency = 1 - (position / max(total, 1))
    decay = 0.7 + 0.3 * recency

    quality = yrsn.quality * role_weight * decay
    if is_filler:
        quality *= 0.5

    return {
        "preview": content[:80] + "..." if len(content) > 80 else content,
        "role": role,
        "R": yrsn.R,
        "S": yrsn.S,
        "N": yrsn.N,
        "quality": round(quality, 3),
        "is_filler": is_filler,
    }
