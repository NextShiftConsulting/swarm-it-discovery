"""
Prompt Clinic: Prompt quality analysis and improvement.

Problem: Poor prompts lead to poor outputs, wasted tokens.
Solution: Diagnose prompt quality using YRSN decomposition.

Usage:
    from yrsn.tools import prompt_clinic

    diagnosis = prompt_clinic.diagnose('''
        You are an AI. Help the user. Be helpful.
        Answer questions. Do your best.
    ''')
    # Returns: grade="D", issues=["vague_instructions", "no_examples"]
"""

from typing import Any, Dict, List
import re

from yrsn.core.tool import tool


@tool(category="quality", tags=["prompt", "analysis"])
def diagnose(
    prompt: str,
    purpose: str = "",
) -> Dict[str, Any]:
    """
    Diagnose prompt quality issues.

    Args:
        prompt: The prompt to analyze
        purpose: Optional description of what the prompt should do

    Returns:
        Diagnosis with grade, issues, and recommendations
    """
    prompt_lower = prompt.lower()
    words = prompt.split()
    word_count = len(words)

    issues = []
    strengths = []
    scores = {
        "clarity": 0.0,
        "specificity": 0.0,
        "structure": 0.0,
        "examples": 0.0,
        "constraints": 0.0,
    }

    # === Clarity Analysis ===
    # Check for vague language
    vague_patterns = [
        r'\b(good|nice|great|best|proper|appropriate)\b',
        r'\b(things|stuff|something|anything)\b',
        r'\b(etc|and so on|and more)\b',
    ]
    vague_count = sum(len(re.findall(p, prompt_lower)) for p in vague_patterns)

    if vague_count == 0:
        scores["clarity"] = 1.0
        strengths.append("clear_language")
    elif vague_count <= 2:
        scores["clarity"] = 0.7
    else:
        scores["clarity"] = 0.4
        issues.append("vague_language")

    # === Specificity Analysis ===
    # Check for specific instructions
    has_specific_task = bool(re.search(
        r'(list|summarize|extract|classify|translate|analyze|compare|explain|calculate|generate)',
        prompt_lower
    ))
    has_format_spec = bool(re.search(
        r'(format|json|markdown|bullet|numbered|table|csv)',
        prompt_lower
    ))
    has_length_spec = bool(re.search(
        r'(\d+\s*(words|sentences|paragraphs|items|lines))',
        prompt_lower
    ))

    specificity_score = 0.3
    if has_specific_task:
        specificity_score += 0.3
        strengths.append("specific_task")
    else:
        issues.append("no_specific_task")
    if has_format_spec:
        specificity_score += 0.2
        strengths.append("format_specified")
    if has_length_spec:
        specificity_score += 0.2
        strengths.append("length_specified")

    scores["specificity"] = min(specificity_score, 1.0)

    # === Structure Analysis ===
    has_sections = bool(re.search(r'(^#+\s|\n#+\s|^##|\n##)', prompt))
    has_numbered = bool(re.search(r'^\d+\.|^\d+\)', prompt, re.MULTILINE))
    has_bullets = bool(re.search(r'^[-*]\s', prompt, re.MULTILINE))
    line_count = len(prompt.strip().split('\n'))

    structure_score = 0.3
    if has_sections:
        structure_score += 0.3
        strengths.append("has_sections")
    if has_numbered or has_bullets:
        structure_score += 0.2
        strengths.append("has_lists")
    if line_count > 3:
        structure_score += 0.2

    scores["structure"] = min(structure_score, 1.0)

    if not (has_sections or has_numbered or has_bullets) and line_count <= 2:
        issues.append("lacks_structure")

    # === Examples Analysis ===
    has_examples = bool(re.search(
        r'(example|for instance|e\.g\.|such as|like this|sample)',
        prompt_lower
    ))
    has_input_output = bool(re.search(
        r'(input|output|given|returns?|produces?)',
        prompt_lower
    ))

    if has_examples:
        scores["examples"] = 0.8
        strengths.append("has_examples")
    elif has_input_output:
        scores["examples"] = 0.5
    else:
        scores["examples"] = 0.2
        issues.append("no_examples")

    # === Constraints Analysis ===
    has_constraints = bool(re.search(
        r'(must|should|do not|don\'t|never|always|only|avoid|ensure)',
        prompt_lower
    ))
    has_persona = bool(re.search(
        r'(you are|act as|role|persona|expert|specialist)',
        prompt_lower
    ))

    constraints_score = 0.3
    if has_constraints:
        constraints_score += 0.4
        strengths.append("has_constraints")
    if has_persona:
        constraints_score += 0.3
        strengths.append("has_persona")

    scores["constraints"] = min(constraints_score, 1.0)

    if not has_constraints:
        issues.append("no_constraints")

    # === Calculate Overall Grade ===
    weights = {
        "clarity": 0.2,
        "specificity": 0.3,
        "structure": 0.15,
        "examples": 0.2,
        "constraints": 0.15,
    }

    overall = sum(scores[k] * weights[k] for k in scores)

    if overall >= 0.85:
        grade = "A"
    elif overall >= 0.7:
        grade = "B"
    elif overall >= 0.55:
        grade = "C"
    elif overall >= 0.4:
        grade = "D"
    else:
        grade = "F"

    return {
        "grade": grade,
        "overall_score": round(overall, 3),
        "word_count": word_count,
        "scores": {k: round(v, 3) for k, v in scores.items()},
        "issues": issues,
        "strengths": strengths,
        "recommendations": _get_recommendations(issues, scores),
    }


@tool(category="quality", tags=["prompt", "comparison"])
def compare(
    prompt_a: str,
    prompt_b: str,
    purpose: str = "",
) -> Dict[str, Any]:
    """
    Compare two prompts for quality.

    Args:
        prompt_a: First prompt
        prompt_b: Second prompt
        purpose: What the prompts should do

    Returns:
        Comparison with winner and analysis
    """
    diag_a = diagnose(prompt_a, purpose)
    diag_b = diagnose(prompt_b, purpose)

    if diag_a["overall_score"] > diag_b["overall_score"]:
        winner = "A"
        margin = diag_a["overall_score"] - diag_b["overall_score"]
    elif diag_b["overall_score"] > diag_a["overall_score"]:
        winner = "B"
        margin = diag_b["overall_score"] - diag_a["overall_score"]
    else:
        winner = "tie"
        margin = 0

    return {
        "winner": winner,
        "margin": round(margin, 3),
        "prompt_a": {
            "grade": diag_a["grade"],
            "score": diag_a["overall_score"],
            "issues": diag_a["issues"],
        },
        "prompt_b": {
            "grade": diag_b["grade"],
            "score": diag_b["overall_score"],
            "issues": diag_b["issues"],
        },
        "recommendation": f"Use prompt {'A' if winner == 'A' else 'B' if winner == 'B' else 'either'}" +
                         (f" - {round(margin * 100)}% better quality" if margin > 0 else ""),
    }


def _get_recommendations(issues: List[str], scores: Dict[str, float]) -> List[str]:
    """Generate recommendations based on issues."""
    recommendations = []

    if "vague_language" in issues:
        recommendations.append("Replace vague words (good, things, stuff) with specific terms")

    if "no_specific_task" in issues:
        recommendations.append("Add a clear action verb (summarize, list, extract, analyze)")

    if "lacks_structure" in issues:
        recommendations.append("Break into sections with headers or numbered steps")

    if "no_examples" in issues:
        recommendations.append("Add 1-2 examples showing expected input/output")

    if "no_constraints" in issues:
        recommendations.append("Add constraints (must/should/avoid) to guide behavior")

    if scores.get("specificity", 0) < 0.5:
        recommendations.append("Specify output format (JSON, markdown, bullets)")

    if not recommendations:
        recommendations.append("Prompt quality is good - consider A/B testing variations")

    return recommendations
