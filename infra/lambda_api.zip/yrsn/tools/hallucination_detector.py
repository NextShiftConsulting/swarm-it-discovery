"""
Hallucination Detector: Flag potential LLM hallucinations.

Problem: LLMs generate plausible but incorrect information.
Solution: Use YRSN collapse detection to identify low-grounding responses.

Usage:
    from yrsn.tools import hallucination_detector

    result = hallucination_detector.check(
        response="The capital of France is Lyon.",
        context="Paris is the capital of France.",
        query="What is the capital of France?"
    )
    # Returns: is_hallucination=True, type="ENTITY_CONFLICT"
"""

from typing import Any, Dict, List
import re

from yrsn.core import compute_yrsn, detect_collapse, CollapseType
from yrsn.core.tool import tool


@tool(category="quality", tags=["hallucination", "detection"])
def check(
    response: str,
    context: str,
    query: str = "",
    strict: bool = False,
) -> Dict[str, Any]:
    """
    Check if a response is grounded in context.

    Args:
        response: The LLM response to check
        context: The source context
        query: Original query
        strict: Use stricter thresholds

    Returns:
        Hallucination analysis
    """
    # Extract and check claims
    claims = _extract_claims(response)
    grounded = []
    ungrounded = []

    context_lower = context.lower()
    context_terms = set(context_lower.split())

    for claim in claims:
        claim_terms = set(claim.lower().split())
        overlap = len(claim_terms & context_terms) / max(len(claim_terms), 1)

        if overlap > 0.3:
            grounded.append({"claim": claim, "confidence": round(overlap + 0.3, 3)})
        else:
            ungrounded.append({"claim": claim, "overlap": round(overlap, 3)})

    # Calculate grounding score
    total_claims = len(claims)
    grounding_score = len(grounded) / total_claims if total_claims > 0 else 1.0

    # Detect collapse
    collapse = detect_collapse(response, context, query)

    # Classify hallucination type
    hallucination_type = _classify_type(response, context, ungrounded, grounding_score)

    # Risk assessment
    threshold = 0.7 if strict else 0.5
    is_hallucination = grounding_score < threshold or hallucination_type != "NONE"
    risk_level = "high" if grounding_score < 0.3 else "medium" if grounding_score < 0.5 else "low"

    return {
        "is_hallucination": is_hallucination,
        "risk_level": risk_level,
        "grounding_score": round(grounding_score, 3),
        "hallucination_type": hallucination_type,
        "collapse": {
            "detected": collapse.detected,
            "type": collapse.collapse_type.value,
            "severity": collapse.severity,
        },
        "claims": {
            "total": total_claims,
            "grounded": len(grounded),
            "ungrounded": len(ungrounded),
        },
        "ungrounded_claims": ungrounded[:5],
        "recommendation": _get_recommendation(hallucination_type, risk_level),
    }


@tool(category="quality", tags=["hallucination", "sources"])
def check_against_sources(
    response: str,
    sources: List[Dict[str, Any]],
    query: str = "",
) -> Dict[str, Any]:
    """
    Check response against multiple sources.

    Args:
        response: LLM response
        sources: Source documents with 'content'
        query: Original query

    Returns:
        Multi-source grounding analysis
    """
    source_results = []

    for i, source in enumerate(sources):
        content = source.get("content", source.get("text", ""))
        title = source.get("title", f"Source {i+1}")

        result = check(response, content, query)
        source_results.append({
            "source": title,
            "grounding_score": result["grounding_score"],
            "supports": result["grounding_score"] > 0.5,
        })

    # Consensus
    supporting = sum(1 for s in source_results if s["supports"])
    scores = [s["grounding_score"] for s in source_results]

    if supporting == 0:
        consensus = "NO_SUPPORT"
        risk = "high"
    elif supporting < len(sources) / 2:
        consensus = "PARTIAL_SUPPORT"
        risk = "medium"
    else:
        consensus = "SUPPORTED"
        risk = "low"

    return {
        "sources_checked": len(sources),
        "supporting_sources": supporting,
        "consensus": consensus,
        "risk_level": risk,
        "grounding": {
            "max": round(max(scores), 3) if scores else 0,
            "min": round(min(scores), 3) if scores else 0,
            "avg": round(sum(scores) / len(scores), 3) if scores else 0,
        },
        "source_results": source_results,
    }


@tool(category="quality", tags=["confidence", "calibration"])
def analyze_confidence(
    response: str,
    context: str,
) -> Dict[str, Any]:
    """
    Analyze if confidence matches grounding.

    Args:
        response: LLM response
        context: Source context

    Returns:
        Confidence calibration analysis
    """
    response_lower = response.lower()

    # Detect confidence level
    high_markers = ['definitely', 'certainly', 'absolutely', 'clearly', 'obviously', 'always', 'never']
    medium_markers = ['likely', 'probably', 'should be', 'appears to', 'seems like']
    low_markers = ['might', 'could', 'possibly', 'perhaps', 'may be', 'not sure']

    high_count = sum(1 for m in high_markers if m in response_lower)
    medium_count = sum(1 for m in medium_markers if m in response_lower)
    low_count = sum(1 for m in low_markers if m in response_lower)

    if high_count > medium_count and high_count > low_count:
        expressed = "high"
        confidence_score = 0.9
    elif low_count > high_count:
        expressed = "low"
        confidence_score = 0.3
    else:
        expressed = "medium"
        confidence_score = 0.6

    # Get grounding
    result = check(response, context)
    grounding_score = result["grounding_score"]

    # Calibration
    error = abs(confidence_score - grounding_score)

    if error > 0.3:
        if confidence_score > grounding_score:
            calibration = "OVERCONFIDENT"
            recommendation = "Response expresses more certainty than evidence supports"
        else:
            calibration = "UNDERCONFIDENT"
            recommendation = "Response is more hedged than necessary"
    else:
        calibration = "WELL_CALIBRATED"
        recommendation = "Confidence matches grounding"

    return {
        "expressed_confidence": expressed,
        "confidence_score": round(confidence_score, 3),
        "grounding_score": round(grounding_score, 3),
        "calibration": calibration,
        "calibration_error": round(error, 3),
        "recommendation": recommendation,
        "risk": "high" if calibration == "OVERCONFIDENT" and grounding_score < 0.4 else "low",
    }


def _extract_claims(text: str) -> List[str]:
    """Extract factual claims from text."""
    sentences = re.split(r'[.!?]+', text)
    claims = []

    for sent in sentences:
        sent = sent.strip()
        if len(sent.split()) < 3:
            continue
        if re.search(r'(is|are|was|were|has|have|means|equals|located|founded|created)', sent.lower()):
            claims.append(sent)

    return claims[:10]


def _classify_type(response: str, context: str, ungrounded: List, grounding: float) -> str:
    """Classify hallucination type."""
    if grounding > 0.7:
        return "NONE"

    # Check for fabricated numbers
    response_nums = set(re.findall(r'\b\d+\b', response))
    context_nums = set(re.findall(r'\b\d+\b', context))
    fabricated = response_nums - context_nums

    if len(fabricated) > 2:
        return "FABRICATION"

    if grounding < 0.3:
        return "CONFABULATION"

    if ungrounded and grounding > 0.3:
        return "ENTITY_CONFLICT"

    return "UNSUPPORTED_CLAIMS"


def _get_recommendation(hall_type: str, risk: str) -> str:
    """Get recommendation based on analysis."""
    recs = {
        "NONE": "Response appears well-grounded",
        "FABRICATION": "Response contains fabricated facts - verify numbers and entities",
        "CONFABULATION": "Response is largely ungrounded - regenerate with better context",
        "ENTITY_CONFLICT": "Response may confuse entities - verify specific claims",
        "UNSUPPORTED_CLAIMS": "Some claims lack support - add citations or qualify",
    }

    rec = recs.get(hall_type, "Review for accuracy")
    if risk == "high":
        rec = f"HIGH RISK: {rec}"

    return rec
