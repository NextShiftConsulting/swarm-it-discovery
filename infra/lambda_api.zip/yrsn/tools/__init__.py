"""
YRSN Pre-built Tools.

Ready-to-use YRSN-powered tools for common LLM tasks:

Tier 1 - Core YRSN:
    - rag_optimizer: RAG result optimization with YRSN scoring
    - prompt_clinic: Prompt quality analysis and improvement
    - context_trimmer: Context compression and noise removal

Tier 2 - Information Management:
    - search_reranker: Search result reranking with source weighting
    - chat_memory: Chat history optimization with recency decay
    - doc_classifier: Document classification by relevance tiers

Tier 3 - Advanced:
    - hallucination_detector: LLM hallucination detection via grounding
    - multi_source_fusion: Multi-source merging with conflict detection
    - adaptive_router: Temperature-based task routing (τ = 1/α)

For deployment/calibration tools, see:
    - yrsn.infrastructure.model_export (ONNX, quantization)
    - yrsn.quality.threshold_optimizer (threshold calibration)

Usage:
    from yrsn.tools import rag_optimizer

    # Use tool functions directly
    result = rag_optimizer.optimize(chunks, query)
"""

# Import tool infrastructure from tools_base.py
from yrsn.tools_base import (
    ToolCategory,
    ToolParameter,
    ToolSchema,
    ToolRegistry,
    tool_registry,
    YRSNTool,
)

from yrsn.tools import rag_optimizer
from yrsn.tools import prompt_clinic
from yrsn.tools import context_trimmer
from yrsn.tools import search_reranker
from yrsn.tools import chat_memory
from yrsn.tools import doc_classifier
from yrsn.tools import hallucination_detector
from yrsn.tools import multi_source_fusion
from yrsn.tools import adaptive_router

__all__ = [
    # Tool infrastructure
    "ToolCategory",
    "ToolParameter",
    "ToolSchema",
    "ToolRegistry",
    "tool_registry",
    "YRSNTool",
    # Pre-built tools
    "rag_optimizer",
    "prompt_clinic",
    "context_trimmer",
    "search_reranker",
    "chat_memory",
    "doc_classifier",
    "hallucination_detector",
    "multi_source_fusion",
    "adaptive_router",
]
