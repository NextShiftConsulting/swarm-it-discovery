"""
Adaptive Router: Temperature-based task routing.

Problem: Same LLM settings for all tasks wastes resources or quality.
Solution: Route to fast/cheap vs slow/quality models based on τ = 1/α.

Usage:
    from yrsn.tools import adaptive_router

    decision = adaptive_router.route(
        query="What is 2+2?",
        context="",
        available_models=["gpt-3.5-turbo", "gpt-4"]
    )
    # Returns: tier="fast", model="gpt-3.5-turbo", temperature=0.5
"""

from typing import Any, Dict, List, Optional

from yrsn.core import (
    route_request,
    compute_temperature,
    select_model_tier,
    ModelTier,
    compute_yrsn,
    compute_quality,
)
from yrsn.core.tool import tool


# Model tier configurations
MODEL_TIERS = {
    ModelTier.FAST: {
        "models": ["gpt-3.5-turbo", "claude-3-haiku", "gemini-flash"],
        "use_cases": ["simple queries", "factual lookups", "classification"],
    },
    ModelTier.BALANCED: {
        "models": ["gpt-4-turbo", "claude-3-sonnet", "gemini-pro"],
        "use_cases": ["coding assistance", "analysis", "summarization"],
    },
    ModelTier.QUALITY: {
        "models": ["gpt-4", "claude-3-opus", "gemini-ultra"],
        "use_cases": ["complex reasoning", "creative writing", "research"],
    },
}


@tool(category="routing", tags=["model", "selection"])
def route(
    query: str,
    context: str = "",
    available_models: Optional[List[str]] = None,
    prefer_cost: bool = False,
    prefer_quality: bool = False,
) -> Dict[str, Any]:
    """
    Route request to appropriate model tier with temperature.

    Args:
        query: The user query
        context: Available context
        available_models: Available models
        prefer_cost: Prefer cheaper models
        prefer_quality: Prefer quality models

    Returns:
        Routing decision with model and temperature
    """
    # Get YRSN score for context
    yrsn = compute_yrsn(context, query=query) if context else None
    quality = yrsn.alpha_omega if yrsn else 0.5

    # Adjust quality based on preferences
    if prefer_cost:
        quality = min(quality + 0.2, 1.0)  # Shift toward fast tier
    if prefer_quality:
        quality = max(quality - 0.2, 0.0)  # Shift toward quality tier

    # Get tier and temperature
    tier = select_model_tier(quality)
    temperature = compute_temperature(quality)

    # Select specific model
    tier_config = MODEL_TIERS[tier]
    if available_models:
        selected = None
        for model in tier_config["models"]:
            if any(model in am or am in model for am in available_models):
                selected = model
                break
        if not selected:
            selected = available_models[0]
    else:
        selected = tier_config["models"][0]

    return {
        "tier": tier.value,
        "model": selected,
        "temperature": round(temperature, 3),
        "reasoning": {
            "context_quality": round(quality, 3),
            "yrsn": {
                "R": yrsn.R if yrsn else None,
                "S": yrsn.S if yrsn else None,
                "N": yrsn.N if yrsn else None,
            } if yrsn else None,
        },
        "tier_info": {
            "models": tier_config["models"],
            "use_cases": tier_config["use_cases"],
        },
    }


@tool(category="routing", tags=["analysis"])
def analyze(
    query: str,
    context: str = "",
) -> Dict[str, Any]:
    """
    Analyze a request for routing requirements.

    Args:
        query: The query to analyze
        context: Available context

    Returns:
        Request analysis with complexity and signals
    """
    yrsn = compute_yrsn(context, query=query) if context else None
    quality = yrsn.alpha_omega if yrsn else 0.5
    tier = select_model_tier(quality)

    # Determine complexity based on quality
    if quality >= 0.7:
        complexity = "low"
    elif quality >= 0.4:
        complexity = "medium"
    else:
        complexity = "high"

    return {
        "query_preview": query[:80] + "..." if len(query) > 80 else query,
        "complexity": complexity,
        "recommended_tier": tier.value,
        "context_yrsn": {
            "R": yrsn.R if yrsn else None,
            "S": yrsn.S if yrsn else None,
            "N": yrsn.N if yrsn else None,
            "quality": yrsn.quality if yrsn else None,
        } if context else None,
    }


@tool(category="routing", tags=["temperature"])
def get_temperature(
    context_quality: float,
) -> Dict[str, Any]:
    """
    Compute optimal temperature from context quality.

    Uses τ = 1/α relationship.

    Args:
        context_quality: Quality score α (0-1)

    Returns:
        Temperature recommendation
    """
    temp = compute_temperature(context_quality)

    # Interpretation
    if temp < 0.5:
        interpretation = "Very precise - best for factual/deterministic tasks"
    elif temp < 1.0:
        interpretation = "Focused - good for coding and analytical tasks"
    elif temp < 1.5:
        interpretation = "Balanced - suitable for most tasks"
    else:
        interpretation = "Exploratory - maximum creativity and variation"

    return {
        "input_quality": context_quality,
        "temperature": round(temp, 3),
        "interpretation": interpretation,
    }


@tool(category="routing", tags=["batch", "optimization"])
def batch_route(
    requests: List[Dict[str, Any]],
    available_models: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Route multiple requests efficiently.

    Args:
        requests: List of requests with 'query' and optional 'context'
        available_models: Available models

    Returns:
        Batch routing decisions with optimization suggestions
    """
    routed = []
    tier_counts = {"fast": 0, "balanced": 0, "quality": 0}

    for req in requests:
        query = req.get("query", "")
        context = req.get("context", "")

        result = route(query, context, available_models)
        routed.append({
            "query_preview": query[:50] + "...",
            "tier": result["tier"],
            "model": result["model"],
            "temperature": result["temperature"],
        })
        tier_counts[result["tier"]] += 1

    # Optimization suggestions
    suggestions = []
    total = len(requests)
    if tier_counts["fast"] > total * 0.7:
        suggestions.append("Most requests can use fast tier - batch for efficiency")
    if tier_counts["quality"] > total * 0.5:
        suggestions.append("Many requests need quality tier - consider parallelizing")

    return {
        "total_requests": total,
        "tier_distribution": tier_counts,
        "routed_requests": routed,
        "suggestions": suggestions or ["No specific optimizations needed"],
    }


@tool(category="routing", tags=["cost", "estimation"])
def estimate_cost(
    requests: List[Dict[str, Any]],
    tokens_per_request: int = 500,
) -> Dict[str, Any]:
    """
    Estimate cost based on routing decisions.

    Args:
        requests: Requests to estimate
        tokens_per_request: Estimated tokens per request

    Returns:
        Cost estimation with tier breakdown
    """
    # Approximate pricing (per 1K tokens)
    PRICING = {
        "fast": {"input": 0.0005, "output": 0.0015},
        "balanced": {"input": 0.003, "output": 0.006},
        "quality": {"input": 0.01, "output": 0.03},
    }

    tier_counts = {"fast": 0, "balanced": 0, "quality": 0}

    for req in requests:
        result = route(req.get("query", ""), req.get("context", ""))
        tier_counts[result["tier"]] += 1

    # Calculate costs
    costs = {}
    total_cost = 0

    for tier, count in tier_counts.items():
        tokens = count * tokens_per_request
        pricing = PRICING[tier]
        tier_cost = (tokens / 1000) * (pricing["input"] + pricing["output"])
        costs[tier] = {"requests": count, "cost": round(tier_cost, 4)}
        total_cost += tier_cost

    # Compare to all-quality
    all_quality = (len(requests) * tokens_per_request / 1000) * (PRICING["quality"]["input"] + PRICING["quality"]["output"])
    savings = all_quality - total_cost

    return {
        "total_requests": len(requests),
        "estimated_cost": round(total_cost, 4),
        "tier_breakdown": costs,
        "comparison": {
            "all_quality_cost": round(all_quality, 4),
            "savings": round(savings, 4),
            "savings_percent": round(savings / all_quality * 100, 1) if all_quality > 0 else 0,
        },
    }
