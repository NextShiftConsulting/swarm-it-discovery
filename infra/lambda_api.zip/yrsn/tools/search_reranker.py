"""
Search Reranker: Quality-weighted search result reranking.

Problem: Search returns results by similarity, not quality.
Solution: Rerank by YRSN quality with source trust weighting.

Usage:
    from yrsn.tools import search_reranker

    results = [
        {"title": "Python Guide", "snippet": "...", "url": "docs.python.org/..."},
        {"title": "Buy Python", "snippet": "...", "url": "spam.com/..."},
    ]
    reranked = search_reranker.rerank(results, query="Python tutorial")
"""

from typing import Any, Dict, List, Optional
import re

from yrsn.core import compute_yrsn
from yrsn.core.tool import tool


# Default source trust scores
DEFAULT_TRUST_SCORES = {
    # High trust (official/authoritative)
    ".gov": 0.95,
    ".edu": 0.9,
    "wikipedia.org": 0.85,
    "stackoverflow.com": 0.8,
    "github.com": 0.8,
    "docs.": 0.85,
    "official": 0.85,

    # Medium trust
    "medium.com": 0.6,
    "dev.to": 0.65,

    # Low trust
    "spam": 0.1,
    "buy": 0.2,
    "discount": 0.2,
}


@tool(category="retrieval", tags=["search", "reranking"])
def rerank(
    results: List[Dict[str, Any]],
    query: str,
    top_k: Optional[int] = None,
    trust_scores: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """
    Rerank search results by YRSN quality with source trust.

    Args:
        results: Search results with title, snippet, url
        query: The search query
        top_k: Number of results to return (default: all)
        trust_scores: Custom source trust scores

    Returns:
        Reranked results with quality scores
    """
    trust = {**DEFAULT_TRUST_SCORES, **(trust_scores or {})}

    scored = []
    for i, result in enumerate(results):
        title = result.get("title", "")
        snippet = result.get("snippet", result.get("content", ""))
        url = result.get("url", "")
        source = result.get("source", _extract_domain(url))

        # Compute YRSN quality
        content = f"{title}\n{snippet}"
        yrsn = compute_yrsn(content, query)

        # Get source trust
        source_trust = 0.5  # Default
        for pattern, score in trust.items():
            if pattern in url.lower() or pattern in source.lower():
                source_trust = max(source_trust, score)

        # Combined score
        combined_score = yrsn.quality * 0.7 + source_trust * 0.3

        scored.append({
            "original_rank": i + 1,
            "title": title,
            "snippet": snippet[:200] + "..." if len(snippet) > 200 else snippet,
            "url": url,
            "source": source,
            "yrsn_quality": yrsn.quality,
            "source_trust": round(source_trust, 3),
            "combined_score": round(combined_score, 3),
            "yrsn": {"R": yrsn.R, "S": yrsn.S, "N": yrsn.N},
        })

    # Sort by combined score
    scored.sort(key=lambda x: x["combined_score"], reverse=True)

    # Add new ranks
    for new_rank, result in enumerate(scored, 1):
        result["new_rank"] = new_rank
        result["rank_change"] = result["original_rank"] - new_rank

    if top_k:
        scored = scored[:top_k]

    return {
        "query": query,
        "total_results": len(results),
        "returned_results": len(scored),
        "results": scored,
        "reranking_summary": _summarize_reranking(scored),
    }


@tool(category="retrieval", tags=["search", "diversity"])
def diversify(
    results: List[Dict[str, Any]],
    query: str,
    top_k: int = 5,
    max_per_source: int = 2,
) -> Dict[str, Any]:
    """
    Diversify search results by source.

    Args:
        results: Search results
        query: Search query
        top_k: Number of results to return
        max_per_source: Maximum results per source

    Returns:
        Diversified results
    """
    reranked = rerank(results, query)["results"]

    selected = []
    source_counts: Dict[str, int] = {}

    for result in reranked:
        source = result["source"]
        if source_counts.get(source, 0) < max_per_source:
            selected.append(result)
            source_counts[source] = source_counts.get(source, 0) + 1

        if len(selected) >= top_k:
            break

    return {
        "query": query,
        "total_results": len(results),
        "diversified_count": len(selected),
        "sources_represented": len(source_counts),
        "results": selected,
    }


def _extract_domain(url: str) -> str:
    """Extract domain from URL."""
    match = re.search(r'https?://([^/]+)', url)
    return match.group(1) if match else url


def _summarize_reranking(results: List[Dict]) -> Dict[str, Any]:
    """Summarize reranking changes."""
    if not results:
        return {}

    promoted = sum(1 for r in results if r["rank_change"] > 0)
    demoted = sum(1 for r in results if r["rank_change"] < 0)
    unchanged = sum(1 for r in results if r["rank_change"] == 0)

    return {
        "promoted": promoted,
        "demoted": demoted,
        "unchanged": unchanged,
        "max_promotion": max((r["rank_change"] for r in results), default=0),
        "max_demotion": min((r["rank_change"] for r in results), default=0),
    }
