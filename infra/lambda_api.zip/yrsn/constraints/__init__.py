"""
YRSN Constraints - Things that REASON (domain-agnostic).

Generic constraint reasoning primitives that work for any constrained system:
Sudoku, compliance workflows, dependency graphs, scheduling, etc.

Modules:
    algebra  - Core primitives (Entity, Constraint, Event, SystemState)
    order    - Reasoning complexity classification (Order 1-4+)
    sparse   - Find what matters (break-in detection, sparse sets)
    temporal - Event sequencing and parallelization

Example:
    from yrsn.constraints import (
        Entity, Constraint, find_sparse_set,
        classify_reasoning_order, ReasoningOrder
    )

    # Define entities
    cells = [Entity(id=f"cell_{i}") for i in range(81)]

    # Find break-in point
    breakin = find_sparse_set(cells, constraints)

    # Classify complexity
    order = classify_reasoning_order(constraints)
    if order == ReasoningOrder.ORDER_3:
        print("Needs hypothetical reasoning")
"""

# Constraint Algebra - Core primitives
try:
    from yrsn_context.reasoning.constraint_algebra import (
        # Core types
        Entity,
        EntityState,
        Constraint,
        ConstraintType,
        Event,
        EventType,
        # State management
        SystemState,
        StateTransition,
        # Results
        ConstraintResult,
        PropagationResult,
        # Operations
        ReasoningOp,
        # Factory functions
        create_entity,
        create_uniqueness_constraint,
        create_sum_constraint,
        create_ordering_constraint,
        create_inclusion_constraint,
    )
    HAS_ALGEBRA = True
except ImportError:
    HAS_ALGEBRA = False
    Entity = None
    EntityState = None
    Constraint = None
    ConstraintType = None
    Event = None
    EventType = None
    SystemState = None
    StateTransition = None
    ConstraintResult = None
    PropagationResult = None
    ReasoningOp = None
    create_entity = None
    create_uniqueness_constraint = None
    create_sum_constraint = None
    create_ordering_constraint = None
    create_inclusion_constraint = None

# Reasoning Order - Complexity classification
try:
    from yrsn_context.reasoning.reasoning_order import (
        ReasoningOrder,
        ComputationType,
        TransformationType,
        OrderClassification,
        ReasoningStrategy,
        classify_reasoning_order,
        classify_single_constraint,
        classify_constraint_interaction,
        detect_representation_change,
        get_required_computations,
        select_strategy,
    )
    HAS_ORDER = True
except ImportError:
    HAS_ORDER = False
    ReasoningOrder = None
    ComputationType = None
    TransformationType = None
    OrderClassification = None
    ReasoningStrategy = None
    classify_reasoning_order = None
    classify_single_constraint = None
    classify_constraint_interaction = None
    detect_representation_change = None
    get_required_computations = None
    select_strategy = None

# Sparse Set - Break-in detection
try:
    from yrsn_context.reasoning.sparse_set import (
        SparseSet,
        EntityImportance,
        ConstraintTightness,
        InteractionPoint,
        find_sparse_set,
        compute_entity_importance,
        compute_constraint_tightness,
        find_interaction_points,
        compute_degrees_of_freedom,
    )
    HAS_SPARSE = True
except ImportError:
    HAS_SPARSE = False
    SparseSet = None
    EntityImportance = None
    ConstraintTightness = None
    InteractionPoint = None
    find_sparse_set = None
    compute_entity_importance = None
    compute_constraint_tightness = None
    find_interaction_points = None
    compute_degrees_of_freedom = None

# Temporal Reasoner - Event graphs
try:
    from yrsn_context.reasoning.temporal_reasoner import (
        EventGraph,
        EventAnalysis,
        BlockerAnalysis,
        Blocker,
        BlockerType,
        CriticalPath,
        ParallelGroup,
        build_event_graph,
        analyze_event_dependencies,
        analyze_blockers,
        find_critical_path,
        identify_parallelizable,
    )
    HAS_TEMPORAL = True
except ImportError:
    HAS_TEMPORAL = False
    EventGraph = None
    EventAnalysis = None
    BlockerAnalysis = None
    Blocker = None
    BlockerType = None
    CriticalPath = None
    ParallelGroup = None
    build_event_graph = None
    analyze_event_dependencies = None
    analyze_blockers = None
    find_critical_path = None
    identify_parallelizable = None


def list_constraints():
    """List available constraint components."""
    available = []
    if HAS_ALGEBRA:
        available.extend(["Entity", "Constraint", "SystemState"])
    if HAS_ORDER:
        available.extend(["ReasoningOrder", "classify_reasoning_order"])
    if HAS_SPARSE:
        available.extend(["SparseSet", "find_sparse_set"])
    if HAS_TEMPORAL:
        available.extend(["EventGraph", "find_critical_path"])
    return available


__all__ = [
    # Utils
    "list_constraints",
    # Constraint Algebra
    "Entity",
    "EntityState",
    "Constraint",
    "ConstraintType",
    "Event",
    "EventType",
    "SystemState",
    "StateTransition",
    "ConstraintResult",
    "PropagationResult",
    "ReasoningOp",
    "create_entity",
    "create_uniqueness_constraint",
    "create_sum_constraint",
    "create_ordering_constraint",
    "create_inclusion_constraint",
    # Reasoning Order
    "ReasoningOrder",
    "ComputationType",
    "TransformationType",
    "OrderClassification",
    "ReasoningStrategy",
    "classify_reasoning_order",
    "classify_single_constraint",
    "classify_constraint_interaction",
    "detect_representation_change",
    "get_required_computations",
    "select_strategy",
    # Sparse Set
    "SparseSet",
    "EntityImportance",
    "ConstraintTightness",
    "InteractionPoint",
    "find_sparse_set",
    "compute_entity_importance",
    "compute_constraint_tightness",
    "find_interaction_points",
    "compute_degrees_of_freedom",
    # Temporal Reasoner
    "EventGraph",
    "EventAnalysis",
    "BlockerAnalysis",
    "Blocker",
    "BlockerType",
    "CriticalPath",
    "ParallelGroup",
    "build_event_graph",
    "analyze_event_dependencies",
    "analyze_blockers",
    "find_critical_path",
    "identify_parallelizable",
    # Availability flags
    "HAS_ALGEBRA",
    "HAS_ORDER",
    "HAS_SPARSE",
    "HAS_TEMPORAL",
]
