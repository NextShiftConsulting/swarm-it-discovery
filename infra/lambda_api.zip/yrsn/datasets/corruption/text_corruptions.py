"""
Text Corruption Generator for Training Data Augmentation

Generates corrupted text samples for training domain-specific
feature extractors with known R/S/N targets.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 4, 10)
    - exp/series_005/expS5_211 (text feature extraction)

Corruption Types:
    - truncation: Remove portions of text -> increases N
    - noise_injection: Add random characters/words -> increases N
    - repetition: Duplicate phrases/sentences -> increases S
    - shuffle: Reorder sentences -> increases S
    - substitution: Replace words with synonyms/antonyms -> varies
    - contradiction: Insert contradictory statements -> increases N
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Callable
import random
import re


@dataclass
class CorruptionTemplate:
    """
    Template for a specific corruption type.

    Attributes:
        name: Corruption identifier
        description: Human-readable description
        corruption_fn: Function that applies corruption
        severity_range: Valid severity levels (1-5 typical)
        target_rsn_delta: Expected change in R/S/N per severity
        applicable_domains: Domains where this corruption is relevant
    """
    name: str
    description: str
    corruption_fn: Optional[Callable] = None
    severity_range: Tuple[int, int] = (1, 5)
    target_rsn_delta: Dict[str, float] = field(default_factory=dict)
    applicable_domains: List[str] = field(default_factory=list)

    def get_target_rsn(
        self,
        severity: int,
        base_rsn: Tuple[float, float, float] = (0.80, 0.10, 0.10)
    ) -> Tuple[float, float, float]:
        """
        Get target R/S/N for this corruption at given severity.

        Args:
            severity: Corruption severity (1-5)
            base_rsn: Base R/S/N for clean text

        Returns:
            Target (R, S, N) tuple
        """
        # Normalize severity to 0-1 range
        sev_norm = (severity - self.severity_range[0]) / (
            self.severity_range[1] - self.severity_range[0]
        )

        # Apply delta scaled by severity
        delta_r = self.target_rsn_delta.get('R', 0) * sev_norm
        delta_s = self.target_rsn_delta.get('S', 0) * sev_norm
        delta_n = self.target_rsn_delta.get('N', 0) * sev_norm

        new_r = max(0, min(1, base_rsn[0] + delta_r))
        new_s = max(0, min(1, base_rsn[1] + delta_s))
        new_n = max(0, min(1, base_rsn[2] + delta_n))

        # Normalize to simplex
        total = new_r + new_s + new_n
        if total > 0:
            new_r /= total
            new_s /= total
            new_n /= total

        return (new_r, new_s, new_n)


class TextCorruptionGenerator:
    """
    Generator for text corruptions with configurable severity.

    Usage:
        >>> generator = TextCorruptionGenerator(seed=42)
        >>> corrupted = generator.corrupt(
        ...     text="The patient should take 500mg daily.",
        ...     corruption_type="truncation",
        ...     severity=3
        ... )
        >>> print(corrupted)
        "The patient should take"
    """

    def __init__(self, seed: Optional[int] = None):
        if seed is not None:
            random.seed(seed)

        self._register_corruptions()

    def _register_corruptions(self):
        """Register built-in corruption functions."""
        self._corruptions = {
            'truncation': self._truncate,
            'noise_injection': self._inject_noise,
            'repetition': self._add_repetition,
            'shuffle': self._shuffle_sentences,
            'substitution': self._substitute_words,
            'contradiction': self._add_contradiction,
            'typo': self._add_typos,
            'missing_context': self._remove_context,
        }

    def corrupt(
        self,
        text: str,
        corruption_type: str,
        severity: int = 3,
    ) -> str:
        """
        Apply corruption to text.

        Args:
            text: Input text
            corruption_type: Type of corruption to apply
            severity: Severity level (1-5, higher = more corruption)

        Returns:
            Corrupted text
        """
        if corruption_type not in self._corruptions:
            raise ValueError(f"Unknown corruption type: {corruption_type}")

        return self._corruptions[corruption_type](text, severity)

    def corrupt_batch(
        self,
        texts: List[str],
        corruption_type: str,
        severity: int = 3,
    ) -> List[str]:
        """Apply corruption to a batch of texts."""
        return [self.corrupt(t, corruption_type, severity) for t in texts]

    def generate_training_sample(
        self,
        text: str,
        corruption_type: str,
        severity: int,
        template: Optional[CorruptionTemplate] = None,
    ) -> Dict[str, Any]:
        """
        Generate a training sample with corrupted text and target RSN.

        Args:
            text: Input text
            corruption_type: Type of corruption
            severity: Severity level
            template: Optional template for target RSN calculation

        Returns:
            Dict with 'text', 'corrupted_text', 'corruption_type', 'severity', 'target_rsn'
        """
        corrupted = self.corrupt(text, corruption_type, severity)

        if template:
            target_rsn = template.get_target_rsn(severity)
        else:
            # Default target based on corruption type
            target_rsn = self._default_target_rsn(corruption_type, severity)

        return {
            'text': text,
            'corrupted_text': corrupted,
            'corruption_type': corruption_type,
            'severity': severity,
            'target_rsn': target_rsn,
        }

    def _default_target_rsn(
        self,
        corruption_type: str,
        severity: int
    ) -> Tuple[float, float, float]:
        """Get default target RSN for corruption type and severity."""
        # Severity factor (0.2 to 1.0)
        sev_factor = 0.2 + (severity - 1) * 0.2

        defaults = {
            'truncation': (0.5 - 0.15 * sev_factor, 0.15, 0.35 + 0.15 * sev_factor),
            'noise_injection': (0.4 - 0.1 * sev_factor, 0.2, 0.4 + 0.2 * sev_factor),
            'repetition': (0.5, 0.35 + 0.15 * sev_factor, 0.15),
            'shuffle': (0.5, 0.3 + 0.1 * sev_factor, 0.2),
            'substitution': (0.55 - 0.1 * sev_factor, 0.25, 0.2 + 0.1 * sev_factor),
            'contradiction': (0.3, 0.2, 0.5 + 0.2 * sev_factor),
            'typo': (0.6 - 0.1 * sev_factor, 0.2, 0.2 + 0.1 * sev_factor),
            'missing_context': (0.4, 0.15, 0.45 + 0.15 * sev_factor),
        }

        rsn = defaults.get(corruption_type, (0.5, 0.25, 0.25))

        # Normalize to simplex
        total = sum(rsn)
        return tuple(v / total for v in rsn)

    # =========================================================================
    # CORRUPTION FUNCTIONS
    # =========================================================================

    def _truncate(self, text: str, severity: int) -> str:
        """Truncate text based on severity."""
        # Keep 90% at severity 1, down to 30% at severity 5
        keep_ratio = 0.9 - (severity - 1) * 0.15
        keep_chars = int(len(text) * keep_ratio)
        return text[:keep_chars]

    def _inject_noise(self, text: str, severity: int) -> str:
        """Inject random characters/words into text."""
        words = text.split()
        noise_words = ['[UNK]', '###', '???', 'ERROR', 'NULL']

        # Insert noise at random positions
        n_insertions = severity * 2
        for _ in range(n_insertions):
            if words:
                pos = random.randint(0, len(words))
                words.insert(pos, random.choice(noise_words))

        return ' '.join(words)

    def _add_repetition(self, text: str, severity: int) -> str:
        """Add repetitive content."""
        sentences = re.split(r'(?<=[.!?])\s+', text)

        if not sentences:
            return text

        # Repeat random sentences
        n_repeats = severity
        for _ in range(n_repeats):
            if sentences:
                sent = random.choice(sentences)
                pos = random.randint(0, len(sentences))
                sentences.insert(pos, sent)

        return ' '.join(sentences)

    def _shuffle_sentences(self, text: str, severity: int) -> str:
        """Shuffle sentence order."""
        sentences = re.split(r'(?<=[.!?])\s+', text)

        if len(sentences) < 2:
            return text

        # Number of swaps based on severity
        n_swaps = min(severity, len(sentences) - 1)

        for _ in range(n_swaps):
            i = random.randint(0, len(sentences) - 2)
            sentences[i], sentences[i + 1] = sentences[i + 1], sentences[i]

        return ' '.join(sentences)

    def _substitute_words(self, text: str, severity: int) -> str:
        """Substitute words with alternatives."""
        words = text.split()

        # Common substitutions (not always semantic preserving)
        substitutions = {
            'the': ['a', 'that', 'this'],
            'is': ['was', 'will be', 'might be'],
            'and': ['or', 'but', 'yet'],
            'good': ['bad', 'great', 'poor'],
            'high': ['low', 'extreme', 'moderate'],
        }

        # Number of substitutions based on severity
        n_subs = severity * 2

        for _ in range(n_subs):
            for i, word in enumerate(words):
                word_lower = word.lower()
                if word_lower in substitutions:
                    words[i] = random.choice(substitutions[word_lower])
                    break

        return ' '.join(words)

    def _add_contradiction(self, text: str, severity: int) -> str:
        """Add contradictory statements."""
        contradictions = [
            " However, this is completely false.",
            " On the contrary, the opposite is true.",
            " This contradicts previous statements.",
            " Note: This information may be incorrect.",
            " WARNING: Data integrity compromised.",
        ]

        # Add contradictions based on severity
        result = text
        for _ in range(severity):
            result += random.choice(contradictions)

        return result

    def _add_typos(self, text: str, severity: int) -> str:
        """Add typographical errors."""
        chars = list(text)

        # Number of typos based on severity
        n_typos = int(len(text) * severity * 0.02)

        for _ in range(n_typos):
            if chars:
                pos = random.randint(0, len(chars) - 1)
                if chars[pos].isalpha():
                    # Random character swap
                    chars[pos] = random.choice('abcdefghijklmnopqrstuvwxyz')

        return ''.join(chars)

    def _remove_context(self, text: str, severity: int) -> str:
        """Remove contextual information (middle section)."""
        if len(text) < 50:
            return text

        # Remove middle portion based on severity
        remove_ratio = 0.1 + (severity - 1) * 0.1
        start_keep = int(len(text) * 0.3)
        end_keep = int(len(text) * (1 - 0.3))
        remove_chars = int((end_keep - start_keep) * remove_ratio)

        remove_start = start_keep + random.randint(0, max(0, end_keep - start_keep - remove_chars))
        remove_end = remove_start + remove_chars

        return text[:remove_start] + " [...] " + text[remove_end:]


# =============================================================================
# DOMAIN-SPECIFIC TEMPLATES
# =============================================================================

CORRUPTION_TEMPLATES: Dict[str, Dict[str, CorruptionTemplate]] = {
    'general': {
        'truncation': CorruptionTemplate(
            name='truncation',
            description='Remove end of text',
            target_rsn_delta={'R': -0.30, 'S': 0.05, 'N': 0.25},
            applicable_domains=['general', 'medical', 'legal', 'financial'],
        ),
        'noise_injection': CorruptionTemplate(
            name='noise_injection',
            description='Add random noise words',
            target_rsn_delta={'R': -0.25, 'S': 0.10, 'N': 0.35},
            applicable_domains=['general'],
        ),
        'repetition': CorruptionTemplate(
            name='repetition',
            description='Duplicate sentences',
            target_rsn_delta={'R': -0.10, 'S': 0.35, 'N': 0.05},
            applicable_domains=['general'],
        ),
    },
    'medical': {
        'dosage_ambiguity': CorruptionTemplate(
            name='dosage_ambiguity',
            description='Remove or corrupt dosage information',
            target_rsn_delta={'R': -0.35, 'S': 0.05, 'N': 0.40},
            applicable_domains=['medical'],
        ),
        'contraindication_omission': CorruptionTemplate(
            name='contraindication_omission',
            description='Remove contraindication warnings',
            target_rsn_delta={'R': -0.30, 'S': 0.05, 'N': 0.35},
            applicable_domains=['medical'],
        ),
        'diagnosis_uncertainty': CorruptionTemplate(
            name='diagnosis_uncertainty',
            description='Add uncertainty markers to diagnosis',
            target_rsn_delta={'R': -0.20, 'S': 0.15, 'N': 0.25},
            applicable_domains=['medical'],
        ),
    },
    'legal': {
        'clause_removal': CorruptionTemplate(
            name='clause_removal',
            description='Remove critical legal clauses',
            target_rsn_delta={'R': -0.35, 'S': 0.05, 'N': 0.40},
            applicable_domains=['legal'],
        ),
        'contradictory_terms': CorruptionTemplate(
            name='contradictory_terms',
            description='Insert contradictory legal terms',
            target_rsn_delta={'R': -0.25, 'S': 0.10, 'N': 0.45},
            applicable_domains=['legal'],
        ),
        'ambiguous_liability': CorruptionTemplate(
            name='ambiguous_liability',
            description='Make liability terms ambiguous',
            target_rsn_delta={'R': -0.20, 'S': 0.20, 'N': 0.30},
            applicable_domains=['legal'],
        ),
    },
    'financial': {
        'calculation_error': CorruptionTemplate(
            name='calculation_error',
            description='Introduce numerical inconsistencies',
            target_rsn_delta={'R': -0.30, 'S': 0.05, 'N': 0.45},
            applicable_domains=['financial'],
        ),
        'missing_disclosure': CorruptionTemplate(
            name='missing_disclosure',
            description='Remove required disclosures',
            target_rsn_delta={'R': -0.25, 'S': 0.10, 'N': 0.35},
            applicable_domains=['financial'],
        ),
        'date_inconsistency': CorruptionTemplate(
            name='date_inconsistency',
            description='Create date/timeline inconsistencies',
            target_rsn_delta={'R': -0.20, 'S': 0.15, 'N': 0.25},
            applicable_domains=['financial'],
        ),
    },
}


def get_domain_templates(domain: str) -> Dict[str, CorruptionTemplate]:
    """
    Get corruption templates for a specific domain.

    Args:
        domain: Domain identifier ('general', 'medical', 'legal', 'financial')

    Returns:
        Dict of corruption templates for the domain
    """
    templates = {}

    # Always include general templates
    templates.update(CORRUPTION_TEMPLATES.get('general', {}))

    # Add domain-specific templates
    if domain in CORRUPTION_TEMPLATES:
        templates.update(CORRUPTION_TEMPLATES[domain])

    return templates


def list_all_corruptions() -> List[str]:
    """List all available corruption types across all domains."""
    corruptions = set()
    for domain_templates in CORRUPTION_TEMPLATES.values():
        corruptions.update(domain_templates.keys())
    return sorted(list(corruptions))
