"""
Corruption Template Library for Domain-Specific Training

Provides domain-specific corruption patterns for training custom
feature extractors and fine-tuning quality thresholds.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Modes 4, 10)

Domains Supported:
    - text: General text corruptions (truncation, noise, repetition)
    - medical: Medical-specific corruptions (dosage, contraindication)
    - legal: Legal document corruptions (clause removal, contradictions)
    - financial: Financial corruptions (calculation errors, missing disclosures)
    - vision: Image corruptions (blur, noise, occlusion)

Usage:
    >>> from yrsn.datasets.corruption import TextCorruptionGenerator, get_domain_templates
    >>>
    >>> # Generate corrupted training data
    >>> generator = TextCorruptionGenerator()
    >>> corrupted_text = generator.corrupt(
    ...     text="The quick brown fox...",
    ...     corruption_type="truncation",
    ...     severity=3
    ... )
    >>>
    >>> # Get domain-specific templates
    >>> templates = get_domain_templates("medical")
    >>> print(templates['dosage_ambiguity'])
"""

from .text_corruptions import (
    TextCorruptionGenerator,
    CorruptionTemplate,
    get_domain_templates,
    CORRUPTION_TEMPLATES,
)

__all__ = [
    'TextCorruptionGenerator',
    'CorruptionTemplate',
    'get_domain_templates',
    'CORRUPTION_TEMPLATES',
]
