"""
YRSN Dataset Loaders

Provides sample data for learning Y=R+S+N decomposition concepts.
Similar to sklearn.datasets pattern.
"""

import numpy as np
from typing import Dict, Tuple, Optional
from dataclasses import dataclass


@dataclass
class SignalDataset:
    """Container for signal decomposition examples."""
    data: np.ndarray  # The signal(s)
    name: str
    description: str
    true_R: Optional[float] = None  # Ground truth if known
    true_S: Optional[float] = None
    true_N: Optional[float] = None


@dataclass
class MatrixDataset:
    """Container for matrix decomposition examples."""
    data: np.ndarray  # The matrix
    name: str
    description: str
    true_rank: Optional[int] = None
    true_sparsity: Optional[float] = None


def load_sample_signals(return_X_y: bool = False) -> Dict[str, SignalDataset]:
    """
    Load sample signals for YRSN decomposition learning.

    Returns dictionary of named signal examples:
    - 'pure_sine': Clean periodic signal (high R)
    - 'noisy_sine': Sine + Gaussian noise (R + N)
    - 'mixed_frequencies': Multiple frequencies (R + S)
    - 'pure_noise': Random noise (high N)
    - 'trend_with_noise': Linear trend + noise (R + S + N)

    Parameters
    ----------
    return_X_y : bool, default=False
        If True, returns (signals_array, names) instead of dict

    Returns
    -------
    dict or tuple
        Signal datasets for learning

    Example
    -------
    >>> from yrsn.datasets import load_sample_signals
    >>> signals = load_sample_signals()
    >>> pure = signals['pure_sine']
    >>> print(pure.description)
    """
    np.random.seed(42)
    t = np.linspace(0, 4 * np.pi, 200)

    datasets = {
        'pure_sine': SignalDataset(
            data=np.sin(t),
            name='Pure Sine Wave',
            description='Clean periodic signal - should decompose to high R (relevant)',
            true_R=0.95,
            true_S=0.05,
            true_N=0.0
        ),
        'noisy_sine': SignalDataset(
            data=np.sin(t) + 0.3 * np.random.randn(200),
            name='Noisy Sine Wave',
            description='Sine + Gaussian noise - demonstrates R + N separation',
            true_R=0.7,
            true_S=0.0,
            true_N=0.3
        ),
        'mixed_frequencies': SignalDataset(
            data=np.sin(t) + 0.5 * np.sin(5*t) + 0.25 * np.sin(13*t),
            name='Mixed Frequencies',
            description='Multiple sine waves - some frequencies may be superfluous (S)',
            true_R=0.6,
            true_S=0.4,
            true_N=0.0
        ),
        'pure_noise': SignalDataset(
            data=np.random.randn(200),
            name='Pure Noise',
            description='Random Gaussian noise - should decompose to high N',
            true_R=0.0,
            true_S=0.0,
            true_N=1.0
        ),
        'trend_with_noise': SignalDataset(
            data=0.1 * t + np.sin(t) + 0.2 * np.random.randn(200),
            name='Trend + Signal + Noise',
            description='Linear trend + sine + noise - full Y=R+S+N example',
            true_R=0.5,
            true_S=0.3,
            true_N=0.2
        ),
    }

    if return_X_y:
        X = np.array([d.data for d in datasets.values()])
        y = list(datasets.keys())
        return X, y

    return datasets


def load_sample_matrices(return_X_y: bool = False) -> Dict[str, MatrixDataset]:
    """
    Load sample matrices for Robust PCA / YRSN decomposition.

    Returns dictionary of named matrix examples:
    - 'low_rank': Clean low-rank matrix (high R)
    - 'sparse_corrupted': Low-rank + sparse outliers (R + S)
    - 'noisy_low_rank': Low-rank + dense noise (R + N)
    - 'full_decomposition': Low-rank + sparse + noise (R + S + N)

    Parameters
    ----------
    return_X_y : bool, default=False
        If True, returns (matrices_array, names) instead of dict

    Returns
    -------
    dict or tuple
        Matrix datasets for learning

    Example
    -------
    >>> from yrsn.datasets import load_sample_matrices
    >>> matrices = load_sample_matrices()
    >>> M = matrices['low_rank']
    >>> print(f"Shape: {M.data.shape}, True rank: {M.true_rank}")
    """
    np.random.seed(42)
    m, n = 50, 40

    # Base low-rank component (rank 3)
    U = np.random.randn(m, 3)
    V = np.random.randn(3, n)
    L = U @ V

    # Sparse component (5% outliers)
    S = np.zeros((m, n))
    n_sparse = int(0.05 * m * n)
    idx = np.random.choice(m * n, n_sparse, replace=False)
    S.flat[idx] = np.random.randn(n_sparse) * 10

    # Noise component
    N = np.random.randn(m, n) * 0.1

    datasets = {
        'low_rank': MatrixDataset(
            data=L,
            name='Low-Rank Matrix',
            description='Clean rank-3 matrix - should decompose to high R',
            true_rank=3,
            true_sparsity=0.0
        ),
        'sparse_corrupted': MatrixDataset(
            data=L + S,
            name='Sparse Corrupted',
            description='Low-rank + sparse outliers - demonstrates R + S separation',
            true_rank=3,
            true_sparsity=0.05
        ),
        'noisy_low_rank': MatrixDataset(
            data=L + N,
            name='Noisy Low-Rank',
            description='Low-rank + dense noise - demonstrates R + N separation',
            true_rank=3,
            true_sparsity=0.0
        ),
        'full_decomposition': MatrixDataset(
            data=L + S + N,
            name='Full Y=R+S+N',
            description='Low-rank + sparse + noise - complete decomposition example',
            true_rank=3,
            true_sparsity=0.05
        ),
    }

    if return_X_y:
        X = np.array([d.data for d in datasets.values()])
        y = list(datasets.keys())
        return X, y

    return datasets


def load_yrsn_examples() -> Dict[str, dict]:
    """
    Load pre-computed YRSN decomposition examples with ground truth.

    Returns examples showing different collapse types and quality levels.

    Returns
    -------
    dict
        Examples with R, S, N values and expected collapse type

    Example
    -------
    >>> from yrsn.datasets import load_yrsn_examples
    >>> examples = load_yrsn_examples()
    >>> print(examples['healthy']['description'])
    """
    return {
        'healthy': {
            'R': 0.8, 'S': 0.15, 'N': 0.05,
            'collapse_type': 'NONE',
            'description': 'Healthy context - high relevance, low noise'
        },
        'poisoning': {
            'R': 0.3, 'S': 0.2, 'N': 0.5,
            'collapse_type': 'POISONING',
            'description': 'Noise-dominated context - model may hallucinate'
        },
        'distraction': {
            'R': 0.3, 'S': 0.6, 'N': 0.1,
            'collapse_type': 'DISTRACTION',
            'description': 'Superfluous-dominated - model loses focus'
        },
        'confusion': {
            'R': 0.2, 'S': 0.4, 'N': 0.4,
            'collapse_type': 'CONFLICT',
            'description': 'High S and N together - model is confused'
        },
        'borderline': {
            'R': 0.5, 'S': 0.3, 'N': 0.2,
            'collapse_type': 'NONE',
            'description': 'Borderline quality - monitor closely'
        },
    }


def make_noisy_signal(
    n_samples: int = 200,
    noise_level: float = 0.3,
    frequencies: Tuple[float, ...] = (1.0,),
    random_state: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a synthetic signal with known R, S, N components.

    Parameters
    ----------
    n_samples : int
        Number of samples
    noise_level : float
        Standard deviation of noise (0 to 1)
    frequencies : tuple of float
        Frequencies for signal components
    random_state : int, optional
        Random seed for reproducibility

    Returns
    -------
    signal : ndarray
        Combined signal (Y)
    clean_signal : ndarray
        Signal without noise (R)
    noise : ndarray
        Noise component (N)

    Example
    -------
    >>> Y, R, N = make_noisy_signal(noise_level=0.2)
    >>> print(f"SNR: {np.std(R)/np.std(N):.2f}")
    """
    if random_state is not None:
        np.random.seed(random_state)

    t = np.linspace(0, 4 * np.pi, n_samples)

    # Build clean signal from frequencies
    clean_signal = np.zeros(n_samples)
    for i, freq in enumerate(frequencies):
        amplitude = 1.0 / (i + 1)  # Decreasing amplitude
        clean_signal += amplitude * np.sin(freq * t)

    # Add noise
    noise = noise_level * np.random.randn(n_samples)
    signal = clean_signal + noise

    return signal, clean_signal, noise


def make_low_rank_matrix(
    n_rows: int = 50,
    n_cols: int = 40,
    rank: int = 3,
    sparse_fraction: float = 0.0,
    noise_std: float = 0.0,
    random_state: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate a synthetic matrix with known L, S, N components.

    Parameters
    ----------
    n_rows, n_cols : int
        Matrix dimensions
    rank : int
        Rank of low-rank component
    sparse_fraction : float
        Fraction of entries that are sparse outliers (0 to 1)
    noise_std : float
        Standard deviation of dense noise
    random_state : int, optional
        Random seed for reproducibility

    Returns
    -------
    M : ndarray
        Combined matrix (Y = L + S + N)
    L : ndarray
        Low-rank component (R)
    S : ndarray
        Sparse component (S)
    N : ndarray
        Noise component (N)

    Example
    -------
    >>> M, L, S, N = make_low_rank_matrix(rank=2, sparse_fraction=0.05)
    >>> print(f"True rank: {np.linalg.matrix_rank(L)}")
    """
    if random_state is not None:
        np.random.seed(random_state)

    # Low-rank component
    U = np.random.randn(n_rows, rank)
    V = np.random.randn(rank, n_cols)
    L = U @ V

    # Sparse component
    S = np.zeros((n_rows, n_cols))
    if sparse_fraction > 0:
        n_sparse = int(sparse_fraction * n_rows * n_cols)
        idx = np.random.choice(n_rows * n_cols, n_sparse, replace=False)
        S.flat[idx] = np.random.randn(n_sparse) * 10

    # Noise component
    N = noise_std * np.random.randn(n_rows, n_cols)

    # Combined
    M = L + S + N

    return M, L, S, N
