"""
Sudoku Data Loader (STUB)

STATUS: INTENTIONAL STUB - Requires External Dataset Setup

This module provides interfaces for Sudoku dataset loading but is not
implemented. Users must provide their own Sudoku datasets.

Why Not Implemented:
- Sudoku datasets are widely available from external sources
- No canonical "official" Sudoku dataset to integrate
- User-specific data requirements vary

How to Use:
1. Download Sudoku datasets from external sources (e.g., kaggle)
2. Load using custom data loading code
3. Pass to YRSN decomposition methods

See: docs/datasets/SUDOKU_SETUP.md (TODO) for external dataset guide

DEPRECATION NOTICE:
- Parameters on stub functions are deprecated (ignored)
- Will be removed in v3.0 (6 months from v2.7)
"""

from typing import Dict, List, Optional, Any
from pathlib import Path
import warnings

# Constants
AVAILABLE_DATASETS = []
CHALLENGE_DATASETS = []
CHALLENGE_ALIASES = {}


def get_cache_dir() -> Path:
    """Get the cache directory for downloaded data."""
    return Path.home() / ".yrsn_context" / "data"


def get_data_path(name: str) -> Path:
    """Get the path to a specific dataset."""
    return get_cache_dir() / name


def clear_cache() -> None:
    """Clear all cached datasets."""
    pass


def list_available_datasets() -> List[str]:
    """List all available datasets."""
    return AVAILABLE_DATASETS


def list_cached_datasets() -> List[str]:
    """List all locally cached datasets."""
    return []


def fetch_sudoku_data(
    name: str = None,  # Deprecated, ignored
    force: bool = None  # Deprecated, ignored
) -> Dict[str, Any]:
    """
    Fetch Sudoku dataset from remote source.

    STATUS: STUB - Not Implemented

    This function requires external Sudoku dataset setup.
    See module docstring for details.

    DEPRECATED PARAMETERS:
    - name: Ignored (deprecated as of v2.7, removed in v3.0)
    - force: Ignored (deprecated as of v2.7, removed in v3.0)

    Raises:
        NotImplementedError: Always (requires external dataset setup)

    See Also:
        docs/datasets/SUDOKU_SETUP.md for external dataset guide
    """
    if name is not None or force is not None:
        warnings.warn(
            "Parameters 'name' and 'force' are deprecated and ignored. "
            "Will be removed in v3.0.",
            DeprecationWarning,
            stacklevel=2
        )

    raise NotImplementedError(
        "Sudoku data fetching not implemented (requires external dataset). "
        "See docs/datasets/SUDOKU_SETUP.md for instructions."
    )


def load_sudoku_puzzles(path: str = None) -> Dict[str, Any]:  # Deprecated param
    """
    Load Sudoku puzzles from local file.

    STATUS: STUB - Not Implemented

    DEPRECATED PARAMETER:
    - path: Ignored (deprecated as of v2.7, removed in v3.0)

    Raises:
        NotImplementedError: Always (requires external dataset setup)
    """
    if path is not None:
        warnings.warn(
            "Parameter 'path' is deprecated and ignored. Will be removed in v3.0.",
            DeprecationWarning,
            stacklevel=2
        )

    raise NotImplementedError(
        "Sudoku puzzle loading not implemented (requires external dataset). "
        "See docs/datasets/SUDOKU_SETUP.md for instructions."
    )


def load_test_sets() -> Dict[str, Any]:
    """
    Load standard test sets.

    STATUS: STUB - Not Implemented

    Raises:
        NotImplementedError: Always (requires external dataset setup)
    """
    raise NotImplementedError(
        "Test set loading not implemented (requires external dataset). "
        "See docs/datasets/SUDOKU_SETUP.md for instructions."
    )


def load_challenge_sets() -> Dict[str, Any]:
    """Deprecated: Use load_test_sets instead."""
    return load_test_sets()


def load_from_local(path: str = None) -> Dict[str, Any]:  # Deprecated param
    """
    Load data from local path.

    STATUS: STUB - Not Implemented

    DEPRECATED PARAMETER:
    - path: Ignored (deprecated as of v2.7, removed in v3.0)

    Raises:
        NotImplementedError: Always (requires external dataset setup)
    """
    if path is not None:
        warnings.warn(
            "Parameter 'path' is deprecated and ignored. Will be removed in v3.0.",
            DeprecationWarning,
            stacklevel=2
        )

    raise NotImplementedError(
        "Local data loading not implemented (requires external dataset). "
        "See docs/datasets/SUDOKU_SETUP.md for instructions."
    )


__all__ = [
    "fetch_sudoku_data",
    "load_sudoku_puzzles",
    "load_test_sets",
    "load_challenge_sets",
    "load_from_local",
    "get_cache_dir",
    "get_data_path",
    "clear_cache",
    "list_available_datasets",
    "list_cached_datasets",
    "AVAILABLE_DATASETS",
    "CHALLENGE_DATASETS",
    "CHALLENGE_ALIASES",
]
