"""
Graph Dataset Adapters

Provides adapters for graph/network datasets:
- SyntheticGraphAdapter: Local synthetic graph (JSON)
- CoraAdapter: Citation network (via PyG)
- CiteSeerAdapter: Citation network (via PyG)

Usage:
    from yrsn.datasets.adapters.graph import SyntheticGraphAdapter

    dataset = SyntheticGraphAdapter(root='data')
    edges, features, labels = dataset.get_graph()
"""

from pathlib import Path
from typing import Tuple, Optional, Union, List, Dict, Any
import json
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class SyntheticGraphAdapter:
    """Adapter for synthetic graph dataset (JSON format)."""

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
    ):
        """
        Args:
            root: Data directory containing graph/synthetic_graph.json
        """
        self._root = _resolve_root(root)
        self._data_path = self._root / "graph" / "synthetic_graph.json"

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Synthetic graph not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            self._data = json.load(f)

    @property
    def name(self) -> str:
        return "synthetic-graph"

    @property
    def n_nodes(self) -> int:
        return self._data['n_nodes']

    @property
    def n_edges(self) -> int:
        return self._data['n_edges']

    @property
    def n_classes(self) -> int:
        return self._data['n_classes']

    @property
    def n_features(self) -> int:
        return self._data['n_features']

    def get_graph(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Get graph as (edges, node_features, node_labels)."""
        edges = np.array(self._data['edges'])
        features = np.array(self._data['node_features'])
        labels = np.array(self._data['node_labels'])
        return edges, features, labels

    def get_edge_index(self) -> np.ndarray:
        """Get edge index in COO format [2, n_edges]."""
        edges = np.array(self._data['edges'])
        return edges.T

    def get_adjacency_list(self) -> Dict[int, List[int]]:
        """Get adjacency list representation."""
        adj = {i: [] for i in range(self.n_nodes)}
        for src, dst in self._data['edges']:
            adj[src].append(dst)
        return adj


class PlanetoidAdapter:
    """Base adapter for Planetoid datasets (Cora, CiteSeer, PubMed) via PyG."""

    def __init__(
        self,
        name: str,
        root: Optional[Union[str, Path]] = None,
    ):
        """
        Args:
            name: Dataset name ('Cora', 'CiteSeer', 'PubMed')
            root: Data directory
        """
        self._root = _resolve_root(root)
        self._name = name

        try:
            from torch_geometric.datasets import Planetoid
            self._dataset = Planetoid(
                root=str(self._root / "graph"),
                name=name,
            )
            self._data = self._dataset[0]
        except ImportError:
            raise ImportError(
                "torch_geometric required. Install with: pip install torch_geometric"
            )

    @property
    def name(self) -> str:
        return self._name.lower()

    @property
    def n_nodes(self) -> int:
        return self._data.num_nodes

    @property
    def n_edges(self) -> int:
        return self._data.num_edges

    @property
    def n_classes(self) -> int:
        return self._dataset.num_classes

    @property
    def n_features(self) -> int:
        return self._dataset.num_features

    def get_edge_index(self) -> np.ndarray:
        """Get edge index [2, n_edges]."""
        return self._data.edge_index.numpy()

    def get_features(self) -> np.ndarray:
        """Get node features [n_nodes, n_features]."""
        return self._data.x.numpy()

    def get_labels(self) -> np.ndarray:
        """Get node labels [n_nodes]."""
        return self._data.y.numpy()

    def get_masks(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Get train/val/test masks."""
        return (
            self._data.train_mask.numpy(),
            self._data.val_mask.numpy(),
            self._data.test_mask.numpy(),
        )


class CoraAdapter(PlanetoidAdapter):
    """Adapter for Cora citation network."""

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(name='Cora', root=root)


class CiteSeerAdapter(PlanetoidAdapter):
    """Adapter for CiteSeer citation network."""

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(name='CiteSeer', root=root)


class PubMedAdapter(PlanetoidAdapter):
    """Adapter for PubMed citation network."""

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(name='PubMed', root=root)


__all__ = [
    "SyntheticGraphAdapter",
    "PlanetoidAdapter",
    "CoraAdapter",
    "CiteSeerAdapter",
    "PubMedAdapter",
]
