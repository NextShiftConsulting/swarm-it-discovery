"""
Text Dataset Adapters

Provides adapters for text classification datasets:
- SampleTextsAdapter: Local sample texts (JSON)
- IMDBAdapter: IMDB sentiment (via torchtext/HuggingFace)
- AGNewsAdapter: AG News classification (via torchtext)

Usage:
    from yrsn.datasets.adapters.text import SampleTextsAdapter

    dataset = SampleTextsAdapter(root='data')
    text, label = dataset.get_sample(0)
"""

from pathlib import Path
from typing import Tuple, Optional, Union, List, Dict, Any
import json


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class SampleTextsAdapter:
    """Adapter for local sample texts dataset (JSON format)."""

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
    ):
        """
        Args:
            root: Data directory containing text/sample_texts.json
        """
        self._root = _resolve_root(root)
        self._data_path = self._root / "text" / "sample_texts.json"

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Sample texts not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            self._samples = json.load(f)

    @property
    def name(self) -> str:
        return "sample-texts"

    def __len__(self) -> int:
        return len(self._samples)

    def get_sample(self, idx: int) -> Tuple[str, str]:
        """Get text and label."""
        sample = self._samples[idx]
        return sample['text'], sample['label']

    def get_all_texts(self) -> List[str]:
        """Get all texts."""
        return [s['text'] for s in self._samples]

    def get_all_labels(self) -> List[str]:
        """Get all labels."""
        return [s['label'] for s in self._samples]

    def get_by_source(self, source: str) -> List[Dict[str, Any]]:
        """Get samples by source type."""
        return [s for s in self._samples if s.get('source') == source]


class IMDBAdapter:
    """Adapter for IMDB sentiment dataset (via HuggingFace datasets)."""

    def __init__(
        self,
        split: str = 'test',
        max_samples: Optional[int] = None,
    ):
        """
        Args:
            split: 'train' or 'test'
            max_samples: Limit number of samples (for quick testing)
        """
        try:
            from datasets import load_dataset
            dataset = load_dataset('imdb', split=split)
            if max_samples:
                dataset = dataset.select(range(min(max_samples, len(dataset))))
            self._dataset = dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install with: pip install datasets"
            )

    @property
    def name(self) -> str:
        return "imdb"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_sample(self, idx: int) -> Tuple[str, int]:
        """Get text and label (0=negative, 1=positive)."""
        item = self._dataset[idx]
        return item['text'], item['label']

    def get_all_texts(self) -> List[str]:
        """Get all texts."""
        return self._dataset['text']

    def get_all_labels(self) -> List[int]:
        """Get all labels."""
        return self._dataset['label']


class AGNewsAdapter:
    """Adapter for AG News classification dataset."""

    LABELS = ['World', 'Sports', 'Business', 'Sci/Tech']

    def __init__(
        self,
        split: str = 'test',
        max_samples: Optional[int] = None,
    ):
        """
        Args:
            split: 'train' or 'test'
            max_samples: Limit number of samples
        """
        try:
            from datasets import load_dataset
            dataset = load_dataset('ag_news', split=split)
            if max_samples:
                dataset = dataset.select(range(min(max_samples, len(dataset))))
            self._dataset = dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install with: pip install datasets"
            )

    @property
    def name(self) -> str:
        return "ag-news"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_sample(self, idx: int) -> Tuple[str, int]:
        """Get text and label (0-3)."""
        item = self._dataset[idx]
        return item['text'], item['label']

    def get_label_name(self, label: int) -> str:
        """Get human-readable label name."""
        return self.LABELS[label]


# =============================================================================
# P11 COMPLIANCE: Real datasets required for patent evidence
# =============================================================================

class GLUEAdapter:
    """Adapter for GLUE benchmark tasks (P11: Real NLP datasets).

    Tasks: cola, sst2, mrpc, qqp, stsb, mnli, qnli, rte, wnli
    """

    def __init__(
        self,
        task: str = 'sst2',
        split: str = 'validation',
        max_samples: Optional[int] = None,
    ):
        """
        Args:
            task: GLUE task name (sst2, cola, mrpc, etc.)
            split: 'train', 'validation', or 'test'
            max_samples: Limit samples
        """
        try:
            from datasets import load_dataset
            dataset = load_dataset('glue', task, split=split)
            if max_samples:
                dataset = dataset.select(range(min(max_samples, len(dataset))))
            self._dataset = dataset
            self._task = task
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install with: pip install datasets"
            )

    @property
    def name(self) -> str:
        return f"glue-{self._task}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_sample(self, idx: int) -> Dict[str, Any]:
        """Get sample as dict."""
        return self._dataset[idx]


class SQuADAdapter:
    """Adapter for SQuAD question answering (P11: Real NLP datasets)."""

    def __init__(
        self,
        version: str = '2.0',
        split: str = 'validation',
        max_samples: Optional[int] = None,
    ):
        """
        Args:
            version: '1.1' or '2.0'
            split: 'train' or 'validation'
            max_samples: Limit samples
        """
        try:
            from datasets import load_dataset
            dataset_name = 'squad' if version == '1.1' else 'squad_v2'
            dataset = load_dataset(dataset_name, split=split)
            if max_samples:
                dataset = dataset.select(range(min(max_samples, len(dataset))))
            self._dataset = dataset
            self._version = version
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install with: pip install datasets"
            )

    @property
    def name(self) -> str:
        return f"squad-v{self._version}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_sample(self, idx: int) -> Tuple[str, str, List[str]]:
        """Get (context, question, answers)."""
        item = self._dataset[idx]
        answers = item['answers']['text'] if item['answers']['text'] else ['']
        return item['context'], item['question'], answers


class FEVERAdapter:
    """Adapter for FEVER fact verification (P11: Fact-checking dataset)."""

    LABELS = ['SUPPORTS', 'REFUTES', 'NOT ENOUGH INFO']

    def __init__(
        self,
        split: str = 'labelled_dev',
        max_samples: Optional[int] = None,
    ):
        """
        Args:
            split: 'train', 'labelled_dev', etc.
            max_samples: Limit samples
        """
        try:
            from datasets import load_dataset
            dataset = load_dataset('fever', 'v1.0', split=split)
            if max_samples:
                dataset = dataset.select(range(min(max_samples, len(dataset))))
            self._dataset = dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required. Install with: pip install datasets"
            )

    @property
    def name(self) -> str:
        return "fever"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_sample(self, idx: int) -> Tuple[str, str]:
        """Get (claim, label)."""
        item = self._dataset[idx]
        return item['claim'], item['label']


__all__ = [
    "SampleTextsAdapter",
    "IMDBAdapter",
    "AGNewsAdapter",
    # P11 Compliance datasets
    "GLUEAdapter",
    "SQuADAdapter",
    "FEVERAdapter",
]
