"""
CIFAR-10 Dataset Adapters

Provides adapters for all CIFAR-10 variants:
- CIFAR10Adapter: Standard torchvision CIFAR-10
- CIFAR10_1Adapter: Temporal shift test set (2018)
- CIFAR10_2Adapter: Temporal shift test set (2021)
- CIFAR10HAdapter: Human uncertainty labels
- CIFAR10CAdapter: Corruption benchmark

Usage:
    from yrsn.datasets.adapters.cifar10 import CIFAR10Adapter, CIFAR10_1Adapter

    # Standard CIFAR-10
    dataset = CIFAR10Adapter(train=False)

    # Temporal shift variant
    dataset = CIFAR10_1Adapter()

    # Pass to model's loader (transforms applied there)
    from yrsn.models import load_cifar10_for_resnet20
    loader = load_cifar10_for_resnet20(dataset=dataset)
"""

from pathlib import Path
from typing import Tuple, Optional, Union
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path.

    HEXAGONAL ARCHITECTURE: Data location is explicitly injected.
    Falls back to ./data only if root is None.
    """
    if root is not None:
        return Path(root)
    # Fallback: look for data/ relative to cwd
    return Path.cwd() / "data"


class CIFAR10Adapter:
    """Adapter for standard CIFAR-10 dataset (torchvision).

    Wraps torchvision CIFAR10 to provide raw numpy images.
    """

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        train: bool = False,
        download: bool = True,
    ):
        """
        Args:
            root: Data directory (explicitly injected for hex-arch).
            train: If True, use training set. If False, use test set.
            download: If True, download dataset if not present.
        """
        from torchvision.datasets import CIFAR10

        self._root = _resolve_root(root)
        self._train = train
        self._dataset = CIFAR10(
            root=str(self._root),
            train=train,
            download=download,
            transform=None,  # Raw images
        )

    @property
    def name(self) -> str:
        split = "train" if self._train else "test"
        return f"cifar10-{split}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_image(self, idx: int) -> np.ndarray:
        """Get raw image as uint8 numpy array (H, W, C)."""
        img, _ = self._dataset[idx]
        return np.array(img, dtype=np.uint8)

    def get_label(self, idx: int) -> int:
        _, label = self._dataset[idx]
        return label

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        img, label = self._dataset[idx]
        return np.array(img, dtype=np.uint8), label


class CIFAR10_1Adapter:
    """Adapter for CIFAR-10.1 temporal shift dataset.

    2000 new test images collected in 2018 with distribution shift.
    Source: https://github.com/modestyachts/CIFAR-10.1
    """

    def __init__(self, root: Optional[Union[str, Path]] = None):
        """
        Args:
            root: Data directory containing cifar10.1/ subfolder (hex-arch injection).
        """
        self._root = _resolve_root(root)
        self._data_dir = self._root / "cifar10.1"

        data_path = self._data_dir / "cifar10.1_v6_data.npy"
        labels_path = self._data_dir / "cifar10.1_v6_labels.npy"

        if not data_path.exists():
            raise FileNotFoundError(
                f"CIFAR-10.1 not found at {data_path}. "
                "Run: ./scripts/download_datasets.sh cifar10.1"
            )

        self._images = np.load(data_path)  # (2000, 32, 32, 3)
        self._labels = np.load(labels_path)  # (2000,)

    @property
    def name(self) -> str:
        return "cifar10.1"

    def __len__(self) -> int:
        return len(self._labels)

    def get_image(self, idx: int) -> np.ndarray:
        return self._images[idx]

    def get_label(self, idx: int) -> int:
        return int(self._labels[idx])

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        return self._images[idx], int(self._labels[idx])


class CIFAR10_2Adapter:
    """Adapter for CIFAR-10.2 temporal shift dataset.

    2000 new test images collected in 2021.
    Source: https://github.com/modestyachts/cifar-10.2
    """

    def __init__(self, root: Optional[Union[str, Path]] = None):
        """
        Args:
            root: Data directory containing cifar10.2/ subfolder (hex-arch injection).
        """
        self._root = _resolve_root(root)
        self._data_dir = self._root / "cifar10.2"

        npz_path = self._data_dir / "cifar102_test.npz"

        if not npz_path.exists():
            raise FileNotFoundError(
                f"CIFAR-10.2 not found at {npz_path}. "
                "Run: ./scripts/download_datasets.sh cifar10.2"
            )

        data = np.load(npz_path)
        self._images = data["images"]  # (2000, 32, 32, 3)
        self._labels = data["labels"]  # (2000,)

    @property
    def name(self) -> str:
        return "cifar10.2"

    def __len__(self) -> int:
        return len(self._labels)

    def get_image(self, idx: int) -> np.ndarray:
        return self._images[idx]

    def get_label(self, idx: int) -> int:
        return int(self._labels[idx])

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        return self._images[idx], int(self._labels[idx])


class CIFAR10HAdapter:
    """Adapter for CIFAR-10H human uncertainty dataset.

    CIFAR-10 test set with soft labels from 50+ human annotators.
    Source: https://github.com/jcpeterson/cifar-10h
    """

    def __init__(self, root: Optional[Union[str, Path]] = None):
        """
        Args:
            root: Data directory containing cifar10h/ subfolder (hex-arch injection).
        """
        from torchvision.datasets import CIFAR10

        self._root = _resolve_root(root)
        self._data_dir = self._root / "cifar10h"

        probs_path = self._data_dir / "cifar10h-probs.npy"
        counts_path = self._data_dir / "cifar10h-counts.npy"

        if not probs_path.exists():
            raise FileNotFoundError(
                f"CIFAR-10H not found at {probs_path}. "
                "Run: ./scripts/download_datasets.sh cifar10h"
            )

        # Load base CIFAR-10 test set for images
        self._cifar10 = CIFAR10(
            root=str(self._root),
            train=False,
            download=True,
            transform=None,
        )

        # Load human annotations
        self._soft_labels = np.load(probs_path)  # (10000, 10)
        self._counts = np.load(counts_path)  # (10000, 10)

    @property
    def name(self) -> str:
        return "cifar10h"

    def __len__(self) -> int:
        return len(self._cifar10)

    def get_image(self, idx: int) -> np.ndarray:
        img, _ = self._cifar10[idx]
        return np.array(img, dtype=np.uint8)

    def get_label(self, idx: int) -> int:
        """Hard label (original CIFAR-10 ground truth)."""
        _, label = self._cifar10[idx]
        return label

    def get_soft_label(self, idx: int) -> np.ndarray:
        """Soft label distribution from human annotators."""
        return self._soft_labels[idx]

    def get_annotator_counts(self, idx: int) -> np.ndarray:
        """Raw vote counts per class."""
        return self._counts[idx]

    def get_human_entropy(self, idx: int) -> float:
        """Entropy of human label distribution (uncertainty measure)."""
        probs = self._soft_labels[idx]
        probs = probs[probs > 0]  # Avoid log(0)
        return -np.sum(probs * np.log(probs))

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        return self.get_image(idx), self.get_label(idx)


class CIFAR10CAdapter:
    """Adapter for CIFAR-10-C corruption benchmark.

    19 corruption types at 5 severity levels.
    Source: https://zenodo.org/record/2535967
    """

    CORRUPTION_TYPES = (
        "gaussian_noise", "shot_noise", "impulse_noise",  # Noise
        "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",  # Blur
        "snow", "frost", "fog", "brightness",  # Weather
        "contrast", "elastic_transform", "pixelate", "jpeg_compression",  # Digital
        "speckle_noise", "gaussian_blur", "spatter", "saturate",  # Extra
    )

    SEVERITY_LEVELS = (1, 2, 3, 4, 5)

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        corruption_type: str = "gaussian_noise",
        severity: int = 1,
    ):
        """
        Args:
            root: Data directory containing CIFAR-10-C/ subfolder (hex-arch injection).
            corruption_type: Type of corruption (see CORRUPTION_TYPES).
            severity: Severity level 1-5.
        """
        self._root = _resolve_root(root)
        self._data_dir = self._root / "CIFAR-10-C"

        if not self._data_dir.exists():
            raise FileNotFoundError(
                f"CIFAR-10-C not found at {self._data_dir}. "
                "Run: ./scripts/download_datasets.sh cifar10c"
            )

        # Load labels (same for all corruptions)
        labels_path = self._data_dir / "labels.npy"
        if labels_path.exists():
            self._all_labels = np.load(labels_path)
        else:
            # Labels repeat 5 times (once per severity)
            from torchvision.datasets import CIFAR10
            cifar = CIFAR10(str(self._root), train=False, download=True)
            self._all_labels = np.array([y for _, y in cifar] * 5)

        self._corruption_type = None
        self._severity = None
        self._images = None
        self._labels = None

        self.set_corruption(corruption_type, severity)

    @property
    def name(self) -> str:
        return f"cifar10c-{self._corruption_type}-s{self._severity}"

    @property
    def corruption_types(self) -> Tuple[str, ...]:
        return self.CORRUPTION_TYPES

    @property
    def severity_levels(self) -> Tuple[int, ...]:
        return self.SEVERITY_LEVELS

    def set_corruption(self, corruption_type: str, severity: int) -> None:
        """Select corruption type and severity level."""
        if corruption_type not in self.CORRUPTION_TYPES:
            raise ValueError(
                f"Unknown corruption '{corruption_type}'. "
                f"Available: {self.CORRUPTION_TYPES}"
            )
        if severity not in self.SEVERITY_LEVELS:
            raise ValueError(f"Severity must be 1-5, got {severity}")

        self._corruption_type = corruption_type
        self._severity = severity

        # Load corruption data
        corruption_path = self._data_dir / f"{corruption_type}.npy"
        if not corruption_path.exists():
            raise FileNotFoundError(f"Corruption file not found: {corruption_path}")

        all_images = np.load(corruption_path)  # (50000, 32, 32, 3) - all severities

        # Extract specific severity (10000 images per severity)
        start_idx = (severity - 1) * 10000
        end_idx = severity * 10000
        self._images = all_images[start_idx:end_idx]
        self._labels = self._all_labels[start_idx:end_idx]

    def __len__(self) -> int:
        return len(self._labels)

    def get_image(self, idx: int) -> np.ndarray:
        return self._images[idx]

    def get_label(self, idx: int) -> int:
        return int(self._labels[idx])

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        return self._images[idx], int(self._labels[idx])


def get_cifar10_adapter(
    variant: str = "standard",
    root: Optional[Union[str, Path]] = None,
    train: bool = False,
    **kwargs,
):
    """Factory function to get CIFAR-10 adapter by variant name.

    Args:
        variant: One of 'standard', '10.1', '10.2', '10h', '10c'
        root: Data directory
        train: For standard variant, whether to use training set
        **kwargs: Additional args passed to adapter

    Returns:
        Appropriate CIFAR-10 adapter instance
    """
    variant = variant.lower().replace("-", ".").replace("cifar", "")

    if variant in ("standard", "10", ""):
        return CIFAR10Adapter(root=root, train=train)
    elif variant in ("10.1", "101"):
        return CIFAR10_1Adapter(root=root)
    elif variant in ("10.2", "102"):
        return CIFAR10_2Adapter(root=root)
    elif variant in ("10h", "h"):
        return CIFAR10HAdapter(root=root)
    elif variant in ("10c", "c"):
        return CIFAR10CAdapter(root=root, **kwargs)
    else:
        raise ValueError(
            f"Unknown CIFAR-10 variant '{variant}'. "
            "Available: standard, 10.1, 10.2, 10h, 10c"
        )
