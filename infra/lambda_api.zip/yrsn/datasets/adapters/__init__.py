"""
Dataset Adapters - Hexagonal Architecture Implementation

Each adapter provides raw data from a specific source.
Transforms are applied by model loaders, not here.

P11 COMPLIANCE: Includes real datasets required for patent evidence:
- Vision: CIFAR-10/C, MNIST, FashionMNIST, SVHN
- Text: IMDB, AG News, GLUE, SQuAD, FEVER
- Tabular: Iris, Wine, Synthetic
- Graph: Cora, CiteSeer, PubMed, Synthetic
- Reasoning: Sudoku, Logic, Math, Analogies

Usage:
    from yrsn.datasets.adapters import CIFAR10Adapter, IMDBAdapter

    # Vision
    dataset = CIFAR10Adapter(train=False)

    # Text (P11 compliant)
    dataset = IMDBAdapter(split='test')

    # Reasoning
    dataset = SudokuAdapter(root='data')
"""

# Vision datasets
from .cifar10 import (
    CIFAR10Adapter,
    CIFAR10_1Adapter,
    CIFAR10_2Adapter,
    CIFAR10HAdapter,
    CIFAR10CAdapter,
    get_cifar10_adapter,
)
from .svhn import SVHNAdapter
from .mnist import MNISTAdapter, FashionMNISTAdapter

# Text datasets (P11 compliance)
from .text import (
    SampleTextsAdapter,
    IMDBAdapter,
    AGNewsAdapter,
    GLUEAdapter,
    SQuADAdapter,
    FEVERAdapter,
)

# Tabular datasets
from .tabular import (
    TabularAdapter,
    IrisAdapter,
    WineAdapter,
    SyntheticQualityAdapter,
)

# Graph datasets
from .graph import (
    SyntheticGraphAdapter,
    PlanetoidAdapter,
    CoraAdapter,
    CiteSeerAdapter,
    PubMedAdapter,
)

# Reasoning datasets
from .reasoning import (
    SudokuAdapter,
    LogicPuzzlesAdapter,
    MathProblemsAdapter,
    AnalogiesAdapter,
)

__all__ = [
    # Vision - CIFAR-10 family
    "CIFAR10Adapter",
    "CIFAR10_1Adapter",
    "CIFAR10_2Adapter",
    "CIFAR10HAdapter",
    "CIFAR10CAdapter",
    "get_cifar10_adapter",
    # Vision - other
    "SVHNAdapter",
    "MNISTAdapter",
    "FashionMNISTAdapter",
    # Text (P11 compliance)
    "SampleTextsAdapter",
    "IMDBAdapter",
    "AGNewsAdapter",
    "GLUEAdapter",
    "SQuADAdapter",
    "FEVERAdapter",
    # Tabular
    "TabularAdapter",
    "IrisAdapter",
    "WineAdapter",
    "SyntheticQualityAdapter",
    # Graph
    "SyntheticGraphAdapter",
    "PlanetoidAdapter",
    "CoraAdapter",
    "CiteSeerAdapter",
    "PubMedAdapter",
    # Reasoning
    "SudokuAdapter",
    "LogicPuzzlesAdapter",
    "MathProblemsAdapter",
    "AnalogiesAdapter",
]
