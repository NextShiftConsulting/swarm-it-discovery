"""
Tabular Dataset Adapters

Provides adapters for tabular/CSV datasets:
- IrisAdapter: UCI Iris dataset
- WineAdapter: UCI Wine dataset
- SyntheticQualityAdapter: Synthetic data with known noise levels

Usage:
    from yrsn.datasets.adapters.tabular import IrisAdapter

    dataset = IrisAdapter(root='data')
    features, label = dataset.get_sample(0)
"""

from pathlib import Path
from typing import Tuple, Optional, Union, List
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class TabularAdapter:
    """Base adapter for CSV tabular datasets."""

    def __init__(
        self,
        root: Optional[Union[str, Path]],
        filename: str,
        feature_cols: List[int],
        label_col: int,
        skip_header: bool = True,
    ):
        self._root = _resolve_root(root)
        self._data_path = self._root / "tabular" / filename

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Dataset not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        # Load CSV
        self._features = []
        self._labels = []

        with open(self._data_path) as f:
            lines = f.readlines()
            if skip_header:
                lines = lines[1:]

            for line in lines:
                parts = line.strip().split(',')
                if len(parts) > max(feature_cols + [label_col]):
                    features = [float(parts[i]) for i in feature_cols]
                    self._features.append(features)
                    self._labels.append(parts[label_col])

        self._features = np.array(self._features)

    def __len__(self) -> int:
        return len(self._features)

    def get_sample(self, idx: int) -> Tuple[np.ndarray, str]:
        """Get feature vector and label."""
        return self._features[idx], self._labels[idx]

    def get_all_features(self) -> np.ndarray:
        """Get all features as numpy array."""
        return self._features

    def get_all_labels(self) -> List[str]:
        """Get all labels."""
        return self._labels

    @property
    def n_features(self) -> int:
        return self._features.shape[1]

    @property
    def unique_labels(self) -> List[str]:
        return list(set(self._labels))


class IrisAdapter(TabularAdapter):
    """Adapter for UCI Iris dataset."""

    FEATURE_NAMES = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width']
    LABEL_NAMES = ['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(
            root=root,
            filename="iris.csv",
            feature_cols=[0, 1, 2, 3],
            label_col=4,
            skip_header=True,
        )

    @property
    def name(self) -> str:
        return "iris"


class WineAdapter(TabularAdapter):
    """Adapter for UCI Wine dataset."""

    FEATURE_NAMES = [
        'alcohol', 'malic_acid', 'ash', 'alcalinity', 'magnesium',
        'phenols', 'flavanoids', 'nonflavanoid', 'proanthocyanins',
        'color', 'hue', 'od280', 'proline'
    ]

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(
            root=root,
            filename="wine.csv",
            feature_cols=list(range(1, 14)),
            label_col=0,
            skip_header=True,
        )

    @property
    def name(self) -> str:
        return "wine"


class SyntheticQualityAdapter(TabularAdapter):
    """Adapter for synthetic quality dataset with known noise levels."""

    def __init__(self, root: Optional[Union[str, Path]] = None):
        super().__init__(
            root=root,
            filename="synthetic_quality.csv",
            feature_cols=[0, 1, 2],
            label_col=4,  # quality_label
            skip_header=True,
        )

        # Also load noise levels
        self._noise_levels = []
        with open(self._data_path) as f:
            lines = f.readlines()[1:]  # Skip header
            for line in lines:
                parts = line.strip().split(',')
                if len(parts) >= 5:
                    self._noise_levels.append(float(parts[3]))

    @property
    def name(self) -> str:
        return "synthetic-quality"

    def get_noise_level(self, idx: int) -> float:
        """Get known noise level for sample."""
        return self._noise_levels[idx]

    def get_all_noise_levels(self) -> List[float]:
        """Get all noise levels."""
        return self._noise_levels


__all__ = [
    "TabularAdapter",
    "IrisAdapter",
    "WineAdapter",
    "SyntheticQualityAdapter",
]
