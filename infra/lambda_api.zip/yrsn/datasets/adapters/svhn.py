"""
SVHN Dataset Adapter

Street View House Numbers dataset - commonly used for OOD detection
against CIFAR-10 trained models.

Usage:
    from yrsn.datasets.adapters.svhn import SVHNAdapter

    dataset = SVHNAdapter(split='test')
    loader = load_cifar10_for_resnet20(dataset=dataset)  # OOD test
"""

from pathlib import Path
from typing import Tuple, Optional, Literal, Union
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path (hex-arch: explicit injection)."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class SVHNAdapter:
    """Adapter for SVHN (Street View House Numbers) dataset.

    32x32 RGB images of house numbers from Google Street View.
    Often used as OOD dataset for CIFAR-10 models.
    """

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        split: Literal["train", "test", "extra"] = "test",
        download: bool = True,
    ):
        """
        Args:
            root: Data directory (hex-arch: explicitly injected).
            split: 'train', 'test', or 'extra'.
            download: If True, download dataset if not present.
        """
        from torchvision.datasets import SVHN

        self._root = _resolve_root(root)
        self._split = split
        self._dataset = SVHN(
            root=str(self._root),
            split=split,
            download=download,
            transform=None,
        )

    @property
    def name(self) -> str:
        return f"svhn-{self._split}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_image(self, idx: int) -> np.ndarray:
        """Get raw image as uint8 numpy array (H, W, C)."""
        img, _ = self._dataset[idx]
        # SVHN images are PIL, convert to numpy
        return np.array(img, dtype=np.uint8)

    def get_label(self, idx: int) -> int:
        _, label = self._dataset[idx]
        return label

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        img, label = self._dataset[idx]
        return np.array(img, dtype=np.uint8), label
