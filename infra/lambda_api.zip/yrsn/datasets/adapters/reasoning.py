"""
Reasoning/Puzzle Dataset Adapters

Provides adapters for logical reasoning and puzzle datasets:
- SudokuAdapter: Sudoku puzzles with solutions
- LogicPuzzlesAdapter: Syllogisms, conditionals, set theory
- MathProblemsAdapter: Arithmetic word problems
- AnalogiesAdapter: A:B::C:D word analogies

Usage:
    from yrsn.datasets.adapters.reasoning import SudokuAdapter

    dataset = SudokuAdapter(root='data')
    puzzle, solution = dataset.get_puzzle(0)
"""

from pathlib import Path
from typing import Tuple, Optional, Union, List, Dict, Any
import json
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class SudokuAdapter:
    """Adapter for Sudoku puzzle datasets.

    Supports multiple sources:
    - sudoku_kaggle.json: Real puzzles (P11 compliant)
    - sudoku17_parsed.json: Famous minimal puzzles (P11 compliant)
    - sudoku_synthetic.json: Synthetic (testing only)
    """

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        source: str = 'real',  # 'real', 'kaggle', 'sudoku17', 'synthetic'
    ):
        """
        Args:
            root: Data directory containing reasoning/*.json
            source: Dataset source - 'real' (default, 114 puzzles, P11), 'kaggle', 'synthetic'
        """
        self._root = _resolve_root(root)
        self._source = source

        # Map source to filename
        source_files = {
            'real': 'sudoku_real.json',  # Combined real puzzles (default, P11)
            'kaggle': 'sudoku_kaggle.json',
            'sudoku17': 'sudoku17_parsed.json',
            'synthetic': 'sudoku_synthetic.json',
            # Legacy support
            'puzzles': 'sudoku_puzzles.json',
        }

        filename = source_files.get(source, 'sudoku_kaggle.json')
        self._data_path = self._root / "reasoning" / filename

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Sudoku dataset '{source}' not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            data = json.load(f)
            self._puzzles = data['puzzles']
            self._metadata = {k: v for k, v in data.items() if k != 'puzzles'}

    @property
    def name(self) -> str:
        return f"sudoku-{self._source}"

    @property
    def is_p11_compliant(self) -> bool:
        """Check if this is a real dataset suitable for patent evidence."""
        return self._source in ('real', 'kaggle', 'sudoku17')

    @property
    def metadata(self) -> Dict[str, Any]:
        """Get dataset metadata."""
        return self._metadata

    def __len__(self) -> int:
        return len(self._puzzles)

    def get_puzzle(self, idx: int) -> Tuple[np.ndarray, np.ndarray]:
        """Get puzzle grid and solution as 9x9 numpy arrays."""
        puzzle = self._puzzles[idx]
        puzzle_grid = np.array(puzzle['puzzle'])
        solution_grid = np.array(puzzle.get('solution', puzzle['puzzle']))
        return puzzle_grid, solution_grid

    def get_puzzle_string(self, idx: int) -> str:
        """Get puzzle as 81-char string (0=empty)."""
        puzzle = self._puzzles[idx]
        if 'puzzle_string' in puzzle:
            return puzzle['puzzle_string']
        # Convert grid to string
        grid = puzzle['puzzle']
        return ''.join(str(grid[r][c]) for r in range(9) for c in range(9))

    def get_difficulty(self, idx: int) -> str:
        """Get puzzle difficulty (easy/medium/hard/expert)."""
        return self._puzzles[idx].get('difficulty', 'unknown')

    def get_clues(self, idx: int) -> int:
        """Get number of clues (filled cells)."""
        puzzle = self._puzzles[idx]
        if 'clues' in puzzle:
            return puzzle['clues']
        grid = puzzle['puzzle']
        return sum(1 for r in range(9) for c in range(9) if grid[r][c] != 0)

    def get_by_difficulty(self, difficulty: str) -> List[int]:
        """Get indices of puzzles with given difficulty."""
        return [
            i for i, p in enumerate(self._puzzles)
            if p.get('difficulty') == difficulty
        ]

    def validate_solution(self, idx: int, attempt: np.ndarray) -> bool:
        """Check if attempt matches solution."""
        _, solution = self.get_puzzle(idx)
        return np.array_equal(attempt, solution)

    @classmethod
    def list_sources(cls) -> List[str]:
        """List available dataset sources."""
        return ['real', 'kaggle', 'sudoku17', 'synthetic']


class LogicPuzzlesAdapter:
    """Adapter for logic puzzles (syllogisms, conditionals, etc.)."""

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
    ):
        self._root = _resolve_root(root)
        self._data_path = self._root / "reasoning" / "logic_puzzles.json"

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Logic puzzles not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            data = json.load(f)
            self._puzzles = data['puzzles']

    @property
    def name(self) -> str:
        return "logic-puzzles"

    def __len__(self) -> int:
        return len(self._puzzles)

    def get_puzzle(self, idx: int) -> Dict[str, Any]:
        """Get puzzle as dict with premises, question, answer, explanation."""
        return self._puzzles[idx]

    def get_by_type(self, puzzle_type: str) -> List[Dict[str, Any]]:
        """Get puzzles of given type (syllogism, conditional, etc.)."""
        return [p for p in self._puzzles if p['type'] == puzzle_type]

    def get_question(self, idx: int) -> Tuple[List[str], str]:
        """Get (premises, question) tuple."""
        p = self._puzzles[idx]
        return p['premises'], p['question']

    def check_answer(self, idx: int, answer: Any) -> bool:
        """Check if answer is correct."""
        return self._puzzles[idx]['answer'] == answer


class MathProblemsAdapter:
    """Adapter for math word problems."""

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
    ):
        self._root = _resolve_root(root)
        self._data_path = self._root / "reasoning" / "math_word_problems.json"

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Math problems not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            data = json.load(f)
            self._problems = data['problems']

    @property
    def name(self) -> str:
        return "math-problems"

    def __len__(self) -> int:
        return len(self._problems)

    def get_problem(self, idx: int) -> Tuple[str, Any]:
        """Get (problem_text, answer)."""
        p = self._problems[idx]
        return p['problem'], p['answer']

    def get_by_type(self, problem_type: str) -> List[Dict[str, Any]]:
        """Get problems of given type (addition, subtraction, etc.)."""
        return [p for p in self._problems if p['type'] == problem_type]

    def check_answer(self, idx: int, answer: Any) -> bool:
        """Check if answer is correct."""
        return self._problems[idx]['answer'] == answer


class AnalogiesAdapter:
    """Adapter for word analogies (A:B::C:D)."""

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
    ):
        self._root = _resolve_root(root)
        self._data_path = self._root / "reasoning" / "analogies.json"

        if not self._data_path.exists():
            raise FileNotFoundError(
                f"Analogies not found at {self._data_path}. "
                "Run: python scripts/download_test_datasets.py"
            )

        with open(self._data_path) as f:
            data = json.load(f)
            self._analogies = data['analogies']

    @property
    def name(self) -> str:
        return "analogies"

    def __len__(self) -> int:
        return len(self._analogies)

    def get_analogy(self, idx: int) -> Tuple[str, str, str, str]:
        """Get (a, b, c, d) where a:b::c:d."""
        a = self._analogies[idx]
        return a['a'], a['b'], a['c'], a['d']

    def get_relation(self, idx: int) -> str:
        """Get relation type (antonym, capital, etc.)."""
        return self._analogies[idx]['relation']

    def get_question(self, idx: int) -> Tuple[str, str, str]:
        """Get (a, b, c) for predicting d."""
        a = self._analogies[idx]
        return a['a'], a['b'], a['c']

    def check_answer(self, idx: int, answer: str) -> bool:
        """Check if answer is correct."""
        return self._analogies[idx]['d'].lower() == answer.lower()


__all__ = [
    "SudokuAdapter",
    "LogicPuzzlesAdapter",
    "MathProblemsAdapter",
    "AnalogiesAdapter",
]
