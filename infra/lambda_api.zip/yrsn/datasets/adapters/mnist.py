"""
MNIST Dataset Adapter

Handwritten digits dataset - baseline for many experiments.

Usage:
    from yrsn.datasets.adapters.mnist import MNISTAdapter

    dataset = MNISTAdapter(train=False)
"""

from pathlib import Path
from typing import Tuple, Optional, Union
import numpy as np


def _resolve_root(root: Optional[Union[str, Path]]) -> Path:
    """Resolve data root path (hex-arch: explicit injection)."""
    if root is not None:
        return Path(root)
    return Path.cwd() / "data"


class MNISTAdapter:
    """Adapter for MNIST handwritten digits dataset.

    28x28 grayscale images of handwritten digits 0-9.
    """

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        train: bool = False,
        download: bool = True,
    ):
        """
        Args:
            root: Data directory (hex-arch: explicitly injected).
            train: If True, use training set. If False, use test set.
            download: If True, download dataset if not present.
        """
        from torchvision.datasets import MNIST

        self._root = _resolve_root(root)
        self._train = train
        self._dataset = MNIST(
            root=str(self._root),
            train=train,
            download=download,
            transform=None,
        )

    @property
    def name(self) -> str:
        split = "train" if self._train else "test"
        return f"mnist-{split}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_image(self, idx: int) -> np.ndarray:
        """Get raw image as uint8 numpy array (H, W).

        Note: MNIST is grayscale, returns (28, 28) not (28, 28, 1).
        """
        img, _ = self._dataset[idx]
        return np.array(img, dtype=np.uint8)

    def get_label(self, idx: int) -> int:
        _, label = self._dataset[idx]
        return label

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        img, label = self._dataset[idx]
        return np.array(img, dtype=np.uint8), label


class FashionMNISTAdapter:
    """Adapter for Fashion-MNIST dataset.

    28x28 grayscale images of fashion items (10 classes).
    Drop-in replacement for MNIST with more challenge.
    """

    def __init__(
        self,
        root: Optional[Union[str, Path]] = None,
        train: bool = False,
        download: bool = True,
    ):
        """
        Args:
            root: Data directory (hex-arch: explicitly injected).
            train: If True, use training set. If False, use test set.
            download: If True, download dataset if not present.
        """
        from torchvision.datasets import FashionMNIST

        self._root = _resolve_root(root)
        self._train = train
        self._dataset = FashionMNIST(
            root=str(self._root),
            train=train,
            download=download,
            transform=None,
        )

    @property
    def name(self) -> str:
        split = "train" if self._train else "test"
        return f"fashion-mnist-{split}"

    def __len__(self) -> int:
        return len(self._dataset)

    def get_image(self, idx: int) -> np.ndarray:
        img, _ = self._dataset[idx]
        return np.array(img, dtype=np.uint8)

    def get_label(self, idx: int) -> int:
        _, label = self._dataset[idx]
        return label

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        img, label = self._dataset[idx]
        return np.array(img, dtype=np.uint8), label
