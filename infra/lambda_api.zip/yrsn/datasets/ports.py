"""
Dataset Ports - Hexagonal Architecture Interfaces

These protocols define what the system needs from data sources.
Adapters implement these protocols for specific data sources.

Usage:
    from yrsn.datasets.ports import ImageDatasetPort

    class MyAdapter(ImageDatasetPort):
        def __len__(self) -> int: ...
        def get_image(self, idx: int) -> np.ndarray: ...
        def get_label(self, idx: int) -> int: ...
"""

from typing import Protocol, Tuple, Optional, runtime_checkable
import numpy as np


@runtime_checkable
class ImageDatasetPort(Protocol):
    """Port for image classification datasets.

    Provides raw images and labels. Transforms are applied by the model's
    loader function, ensuring correct preprocessing for that model.

    Images should be returned as uint8 numpy arrays in HWC format.
    """

    @property
    def name(self) -> str:
        """Dataset identifier (e.g., 'cifar10', 'cifar10.1', 'svhn')."""
        ...

    def __len__(self) -> int:
        """Number of samples in the dataset."""
        ...

    def get_image(self, idx: int) -> np.ndarray:
        """Get raw image at index.

        Returns:
            uint8 numpy array, shape (H, W, C), RGB format
        """
        ...

    def get_label(self, idx: int) -> int:
        """Get label at index."""
        ...

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        """Get (image, label) tuple at index."""
        ...


@runtime_checkable
class SoftLabelDatasetPort(Protocol):
    """Port for datasets with soft labels (multiple annotators).

    Extends ImageDatasetPort with soft label support.
    Used for CIFAR-10H and similar human-annotated datasets.
    """

    @property
    def name(self) -> str:
        ...

    def __len__(self) -> int:
        ...

    def get_image(self, idx: int) -> np.ndarray:
        ...

    def get_label(self, idx: int) -> int:
        """Hard label (majority vote or ground truth)."""
        ...

    def get_soft_label(self, idx: int) -> np.ndarray:
        """Soft label distribution over classes.

        Returns:
            float array, shape (num_classes,), sums to 1.0
        """
        ...

    def get_annotator_counts(self, idx: int) -> np.ndarray:
        """Raw annotator vote counts per class.

        Returns:
            int array, shape (num_classes,)
        """
        ...

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        ...


@runtime_checkable
class CorruptedDatasetPort(Protocol):
    """Port for corruption benchmark datasets (CIFAR-10-C, ImageNet-C).

    Provides access to multiple corruption types and severity levels.
    """

    @property
    def name(self) -> str:
        ...

    @property
    def corruption_types(self) -> Tuple[str, ...]:
        """Available corruption types (e.g., 'gaussian_noise', 'fog')."""
        ...

    @property
    def severity_levels(self) -> Tuple[int, ...]:
        """Available severity levels (typically 1-5)."""
        ...

    def __len__(self) -> int:
        """Total samples for current corruption/severity."""
        ...

    def set_corruption(self, corruption_type: str, severity: int) -> None:
        """Select corruption type and severity level."""
        ...

    def get_image(self, idx: int) -> np.ndarray:
        ...

    def get_label(self, idx: int) -> int:
        ...

    def get_item(self, idx: int) -> Tuple[np.ndarray, int]:
        ...
