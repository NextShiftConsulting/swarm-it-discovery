"""
YRSN Datasets

Scikit-learn style data loading for learning and testing.

HEXAGONAL ARCHITECTURE:
    This module provides:
    1. Dataset ADAPTERS (raw data from various sources)
    2. Sample data loaders (similar to sklearn.datasets)

    Adapters provide RAW data only. Transforms are applied by model loaders
    to ensure correct preprocessing for each model.

Usage:
    # NEW: Hexagonal adapters for image datasets
    from yrsn.datasets import get_cifar10_adapter, CIFAR10_1Adapter

    dataset = get_cifar10_adapter('10.1')  # Raw data
    from yrsn.models import load_cifar10_for_resnet20
    loader = load_cifar10_for_resnet20(dataset=dataset)  # Transforms applied here

    # Signal decomposition examples
    from yrsn.datasets import load_sample_signals
    signals = load_sample_signals()

    # Sudoku training data (fetched from GitHub)
    from yrsn.datasets import fetch_sudoku_data
    data = fetch_sudoku_data()  # Downloads to ~/.yrsn_context/data/

Architecture:
    ┌─────────────┐      ┌──────────────┐      ┌──────────┐
    │  ADAPTERS   │ ──── │     PORT     │ ──── │   CORE   │
    │ (data src)  │      │ (transform)  │      │  (model) │
    └─────────────┘      └──────────────┘      └──────────┘
"""

import warnings

# Hexagonal Architecture: Ports and Adapters
from yrsn.datasets.ports import (
    ImageDatasetPort,
    SoftLabelDatasetPort,
    CorruptedDatasetPort,
)
from yrsn.datasets.adapters import (
    # CIFAR-10 family
    CIFAR10Adapter,
    CIFAR10_1Adapter,
    CIFAR10_2Adapter,
    CIFAR10HAdapter,
    CIFAR10CAdapter,
    get_cifar10_adapter,
    # Other datasets
    SVHNAdapter,
    MNISTAdapter,
    FashionMNISTAdapter,
)

# Legacy loaders
from yrsn.datasets.loaders import (
    load_sample_signals,
    load_sample_matrices,
    load_yrsn_examples,
    make_noisy_signal,
    make_low_rank_matrix,
)

from yrsn.datasets.sudoku_data import (
    fetch_sudoku_data,
    load_sudoku_puzzles,
    load_test_sets,
    load_challenge_sets,  # Deprecated alias
    load_from_local,
    get_cache_dir,
    get_data_path,
    clear_cache,
    list_available_datasets,
    list_cached_datasets,
    AVAILABLE_DATASETS,
    CHALLENGE_DATASETS,
    CHALLENGE_ALIASES,
)

# Corruption templates for training data augmentation
from yrsn.datasets.corruption import (
    TextCorruptionGenerator,
    CorruptionTemplate,
    get_domain_templates,
    CORRUPTION_TEMPLATES,
)

# ===========================================================================
# BACKWARDS COMPATIBILITY: Collapse generator moved to yrsn.benchmarks
# ===========================================================================
# These imports provide backwards compatibility but emit deprecation warnings.
# The canonical location is now: from yrsn.benchmarks import CollapseGenerator

def __getattr__(name):
    """Lazy import with deprecation warning for moved collapse generator."""
    _deprecated_names = {
        "CollapseGenerator",
        "CollapseSample",
        "CollapseType",
        "COLLAPSE_DOMAINS",
        "generate_publication_dataset",
        "load_collapse_examples",
    }

    if name in _deprecated_names:
        warnings.warn(
            f"Importing '{name}' from yrsn.datasets is deprecated. "
            f"Use 'from yrsn.benchmarks import {name}' instead. "
            f"This will be removed in a future version.",
            DeprecationWarning,
            stacklevel=2
        )
        from yrsn.benchmarks import collapse_generator
        return getattr(collapse_generator, name)

    raise AttributeError(f"module 'yrsn.datasets' has no attribute '{name}'")


__all__ = [
    # Hexagonal Architecture: Ports
    "ImageDatasetPort",
    "SoftLabelDatasetPort",
    "CorruptedDatasetPort",
    # Hexagonal Architecture: CIFAR-10 Adapters
    "CIFAR10Adapter",
    "CIFAR10_1Adapter",
    "CIFAR10_2Adapter",
    "CIFAR10HAdapter",
    "CIFAR10CAdapter",
    "get_cifar10_adapter",
    # Hexagonal Architecture: Other Adapters
    "SVHNAdapter",
    "MNISTAdapter",
    "FashionMNISTAdapter",
    # Signal/matrix loaders
    "load_sample_signals",
    "load_sample_matrices",
    "load_yrsn_examples",
    "make_noisy_signal",
    "make_low_rank_matrix",
    # Sudoku data loaders
    "fetch_sudoku_data",
    "load_sudoku_puzzles",
    "load_test_sets",
    "load_challenge_sets",  # Deprecated
    "load_from_local",
    "get_cache_dir",
    "get_data_path",
    "clear_cache",
    "list_available_datasets",
    "list_cached_datasets",
    "AVAILABLE_DATASETS",
    "CHALLENGE_DATASETS",
    "CHALLENGE_ALIASES",
    # Corruption templates (training data augmentation)
    "TextCorruptionGenerator",
    "CorruptionTemplate",
    "get_domain_templates",
    "CORRUPTION_TEMPLATES",
    # DEPRECATED - moved to yrsn.benchmarks (still exported for backwards compat)
    "CollapseGenerator",
    "CollapseSample",
    "CollapseType",
    "COLLAPSE_DOMAINS",
    "generate_publication_dataset",
    "load_collapse_examples",
]
