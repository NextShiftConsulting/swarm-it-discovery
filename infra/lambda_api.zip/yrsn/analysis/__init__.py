"""
YRSN Analysis Tools

This module provides analysis tools for evaluating YRSN performance.

Available Tools:
- BaselineComparator: Compare YRSN vs baselines with statistical rigor
- EnergyAccountant: Track energy costs in inference pipelines

Example:
    from yrsn.analysis import BaselineComparator
    
    comparator = BaselineComparator(num_seeds=10)
    result = comparator.compare(yrsn_scores, baseline_scores, 'accuracy')
    comparator.visualize_comparison(result, save_path='comparison.png')
"""

try:
    from .baseline_comparison import BaselineComparator, ComparisonResult
    HAS_BASELINE = True
except ImportError:
    HAS_BASELINE = False
    BaselineComparator = None
    ComparisonResult = None

try:
    from .energy_model import EnergyAccountant, EnergyProfile
    HAS_ENERGY = True
except ImportError:
    HAS_ENERGY = False
    EnergyAccountant = None
    EnergyProfile = None

__all__ = [
    'BaselineComparator',
    'ComparisonResult',
    'EnergyAccountant',
    'EnergyProfile',
    'HAS_BASELINE',
    'HAS_ENERGY',
]
