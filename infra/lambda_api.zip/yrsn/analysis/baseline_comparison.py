"""
Baseline Comparison Framework for YRSN

This module provides statistical comparison of YRSN vs baselines.

┌─────────────────────────────────────────────────────────────────┐
│                      WHAT THIS DOES                              │
├─────────────────────────────────────────────────────────────────┤
│ Compares YRSN performance against baselines with:               │
│   • Statistical significance tests (t-test)                     │
│   • Effect size computation (Cohen's d)                         │
│   • Publication-ready visualizations                            │
│   • Automated report generation                                 │
└─────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
--------------
- Avoid manual statistical testing in each notebook
- Ensure fair comparisons across all experiments
- Generate consistent visualizations
- Provide rigorous evidence for claims

WHAT IT COMPUTES:
----------------
1. STATISTICAL SIGNIFICANCE: p-value from t-test
   - p < 0.001: *** (highly significant)
   - p < 0.01:  ** (very significant)
   - p < 0.05:  * (significant)
   - p >= 0.05: ns (not significant)

2. EFFECT SIZE: Cohen's d
   - d > 0.8: Large effect
   - d > 0.5: Medium effect
   - d > 0.2: Small effect
   - d < 0.2: Negligible effect

3. IMPROVEMENT: (YRSN - Baseline) / Baseline
   - Percentage improvement over baseline

USAGE EXAMPLES:
--------------

Example 1: Compare Two Methods
>>> from yrsn.analysis import BaselineComparator
>>> import numpy as np
>>> 
>>> # Run YRSN 10 times
>>> yrsn_scores = np.array([0.87, 0.89, 0.88, 0.86, 0.90, 
...                         0.88, 0.87, 0.89, 0.88, 0.87])
>>> 
>>> # Run baseline 10 times  
>>> baseline_scores = np.array([0.80, 0.82, 0.81, 0.79, 0.83,
...                            0.81, 0.80, 0.82, 0.81, 0.80])
>>> 
>>> comparator = BaselineComparator(num_seeds=10)
>>> result = comparator.compare(yrsn_scores, baseline_scores, 'accuracy')
>>> 
>>> print(f"YRSN: {result.yrsn_mean:.3f} ± {result.yrsn_std:.3f}")
>>> print(f"Baseline: {result.baseline_mean:.3f} ± {result.baseline_std:.3f}")
>>> print(f"Improvement: {result.improvement:.1%}")
>>> print(f"p-value: {result.p_value:.4f} ({result.significance_marker})")
>>> print(f"Effect size: {result.effect_size:.2f} ({result.effect_interpretation})")

Example 2: Generate Visualization
>>> comparator.visualize_comparison(
...     result, 
...     save_path='results/evidence/comparison.png',
...     title='YRSN vs Baseline Accuracy'
... )

Example 3: Generate Report
>>> report = comparator.generate_report({
...     'Accuracy': accuracy_result,
...     'Energy Savings': energy_result,
...     'Latency': latency_result
... })
>>> print(report)

Example 4: Multiple Comparisons
>>> results = {}
>>> for metric in ['accuracy', 'energy', 'latency']:
...     results[metric] = comparator.compare(
...         yrsn_data[metric],
...         baseline_data[metric],
...         metric,
...         higher_is_better=(metric != 'latency')
...     )
>>> 
>>> # Generate summary visualization
>>> comparator.visualize_multi_comparison(
...     results,
...     save_path='multi_comparison.png'
... )
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from dataclasses import dataclass
from typing import Dict, Optional, List, Tuple
from pathlib import Path


@dataclass
class ComparisonResult:
    """
    Result from YRSN vs baseline comparison.
    
    INTERPRETATION GUIDE:
    --------------------
    • yrsn_mean/baseline_mean: Average performance
    • yrsn_std/baseline_std: Variability (lower is more consistent)
    • improvement: Percentage gain (positive = YRSN better)
    • p_value: Statistical significance (lower = more confident)
    • is_significant: Whether p < alpha (typically 0.05)
    • effect_size: Cohen's d (magnitude of difference)
    • significance_marker: *, **, *** or 'ns'
    
    Attributes:
        metric_name: Name of metric being compared
        yrsn_mean: Mean YRSN performance
        baseline_mean: Mean baseline performance
        yrsn_std: Standard deviation of YRSN
        baseline_std: Standard deviation of baseline
        improvement: (YRSN - Baseline) / Baseline as percentage
        p_value: Two-tailed t-test p-value
        is_significant: Whether p < alpha
        effect_size: Cohen's d effect size
        significance_marker: *, **, ***, or 'ns'
        effect_interpretation: 'large', 'medium', 'small', or 'negligible'
        winner: 'YRSN', 'Baseline', or 'Tie'
    """
    metric_name: str
    yrsn_mean: float
    baseline_mean: float
    yrsn_std: float
    baseline_std: float
    improvement: float
    p_value: float
    is_significant: bool
    effect_size: float
    significance_marker: str
    effect_interpretation: str
    winner: str


class BaselineComparator:
    """
    Compare YRSN performance against baselines with statistical rigor.
    
    CAPABILITIES:
    ------------
    ✓ Statistical significance testing (t-test)
    ✓ Effect size computation (Cohen's d)
    ✓ Publication-ready visualizations
    ✓ Automated report generation
    ✓ Multi-metric comparison support
    ✓ Error bar plotting
    
    CONFIGURATION:
    -------------
    num_seeds: int (default=10)
        Number of runs per method (for statistical power)
        
    alpha: float (default=0.05)
        Significance threshold for p-value
        
    METHODS:
    -------
    compare(yrsn_results, baseline_results, metric_name, higher_is_better) -> ComparisonResult
        Full statistical comparison
        
    visualize_comparison(result, save_path, title) -> None
        Create publication-ready bar plot
        
    visualize_multi_comparison(results, save_path) -> None
        Compare multiple metrics in one plot
        
    generate_report(results) -> str
        Generate markdown report
    """
    
    def __init__(self, num_seeds: int = 10, alpha: float = 0.05):
        """
        Initialize comparator.
        
        Args:
            num_seeds: Expected number of runs (for warnings)
            alpha: Significance threshold (typically 0.05)
        """
        self.num_seeds = num_seeds
        self.alpha = alpha
        
    def compare(
        self,
        yrsn_results: np.ndarray,
        baseline_results: np.ndarray,
        metric_name: str,
        higher_is_better: bool = True
    ) -> ComparisonResult:
        """
        Compare YRSN vs baseline with statistical testing.
        
        WHAT THIS COMPUTES:
        ------------------
        1. Mean and standard deviation for both methods
        2. Percentage improvement
        3. Statistical significance (t-test)
        4. Effect size (Cohen's d)
        5. Winner determination
        
        ASSUMPTIONS:
        -----------
        - Results are independent runs (different random seeds)
        - Approximately normally distributed (valid for n >= 5)
        - Equal variance (Welch's t-test if needed)
        
        Args:
            yrsn_results: Array of YRSN scores [num_runs]
            baseline_results: Array of baseline scores [num_runs]
            metric_name: Name of metric (e.g., 'accuracy', 'energy_savings')
            higher_is_better: Whether higher scores are better
            
        Returns:
            ComparisonResult with full statistical analysis
            
        Raises:
            ValueError: If arrays have different lengths or too few samples
            
        Example:
            >>> yrsn = np.array([0.87, 0.89, 0.88])
            >>> baseline = np.array([0.80, 0.82, 0.81])
            >>> result = comparator.compare(yrsn, baseline, 'accuracy')
            >>> print(f"YRSN wins with p={result.p_value:.4f}")
        """
        # Validate inputs
        if len(yrsn_results) != len(baseline_results):
            raise ValueError("YRSN and baseline must have same number of runs")
        if len(yrsn_results) < 3:
            raise ValueError("Need at least 3 runs for meaningful statistics")
            
        # Compute statistics
        yrsn_mean = float(np.mean(yrsn_results))
        baseline_mean = float(np.mean(baseline_results))
        yrsn_std = float(np.std(yrsn_results, ddof=1))
        baseline_std = float(np.std(baseline_results, ddof=1))
        
        # Improvement
        if baseline_mean != 0:
            improvement = (yrsn_mean - baseline_mean) / abs(baseline_mean)
        else:
            improvement = 0.0
            
        # T-test (two-tailed)
        t_stat, p_value = stats.ttest_ind(yrsn_results, baseline_results)
        is_significant = p_value < self.alpha
        
        # Effect size (Cohen's d)
        pooled_std = np.sqrt((yrsn_std**2 + baseline_std**2) / 2)
        if pooled_std > 0:
            effect_size = (yrsn_mean - baseline_mean) / pooled_std
        else:
            effect_size = 0.0
            
        # Significance marker
        if p_value < 0.001:
            marker = '***'
        elif p_value < 0.01:
            marker = '**'
        elif p_value < 0.05:
            marker = '*'
        else:
            marker = 'ns'
            
        # Effect interpretation
        abs_effect = abs(effect_size)
        if abs_effect > 0.8:
            effect_interp = 'large'
        elif abs_effect > 0.5:
            effect_interp = 'medium'
        elif abs_effect > 0.2:
            effect_interp = 'small'
        else:
            effect_interp = 'negligible'
            
        # Determine winner
        if not is_significant:
            winner = 'Tie'
        else:
            if higher_is_better:
                winner = 'YRSN' if yrsn_mean > baseline_mean else 'Baseline'
            else:
                winner = 'YRSN' if yrsn_mean < baseline_mean else 'Baseline'
                
        return ComparisonResult(
            metric_name=metric_name,
            yrsn_mean=yrsn_mean,
            baseline_mean=baseline_mean,
            yrsn_std=yrsn_std,
            baseline_std=baseline_std,
            improvement=improvement,
            p_value=float(p_value),
            is_significant=is_significant,
            effect_size=float(effect_size),
            significance_marker=marker,
            effect_interpretation=effect_interp,
            winner=winner
        )
        
    def visualize_comparison(
        self,
        result: ComparisonResult,
        save_path: Optional[Path] = None,
        title: Optional[str] = None,
        figsize: Tuple[float, float] = (6, 5)
    ) -> Optional[plt.Figure]:
        """
        Create publication-ready comparison visualization.
        
        WHAT THIS CREATES:
        -----------------
        Bar plot with:
        - Two bars (Baseline, YRSN)
        - Error bars (standard deviation)
        - Significance markers (*, **, ***)
        - Winner highlighting (green/red)
        - Grid for readability
        
        Args:
            result: ComparisonResult from compare()
            save_path: Where to save figure (if None, just show)
            title: Custom title (default: metric name)
            figsize: Figure size in inches
            
        Returns:
            Figure object if save_path is None
            
        Example:
            >>> comparator.visualize_comparison(
            ...     result,
            ...     save_path='comparison.png',
            ...     title='YRSN vs Confidence-Based Gating'
            ... )
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        # Data
        methods = ['Baseline', 'YRSN']
        means = [result.baseline_mean, result.yrsn_mean]
        stds = [result.baseline_std, result.yrsn_std]
        
        # Colors (green for winner)
        colors = ['#3498DB', '#50C878']  # Blue, Green
        if result.winner == 'Baseline':
            colors = ['#50C878', '#3498DB']
        elif result.winner == 'Tie':
            colors = ['#95A5A6', '#95A5A6']  # Gray
            
        # Bar plot with error bars
        bars = ax.bar(methods, means, yerr=stds, color=colors, 
                     capsize=5, alpha=0.8, edgecolor='black', linewidth=1.5)
        
        # Add significance marker
        if result.is_significant:
            max_y = max(means) + max(stds)
            ax.text(0.5, max_y * 1.05, result.significance_marker,
                   ha='center', fontsize=16, fontweight='bold')
            ax.text(0.5, max_y * 1.12, f'p={result.p_value:.4f}',
                   ha='center', fontsize=9)
            
        # Labels and title
        ax.set_ylabel(result.metric_name.replace('_', ' ').title(), fontsize=12)
        if title:
            ax.set_title(title, fontsize=13, fontweight='bold')
        else:
            ax.set_title(f'{result.metric_name.replace("_", " ").title()} Comparison',
                        fontsize=13, fontweight='bold')
            
        # Grid
        ax.grid(True, alpha=0.3, axis='y')
        ax.set_axisbelow(True)
        
        # Add improvement text
        imp_text = f'{result.improvement:+.1%} improvement'
        ax.text(0.5, 0.02, imp_text, transform=ax.transAxes,
               ha='center', fontsize=10,
               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            return None
        else:
            return fig
            
    def generate_report(self, results: Dict[str, ComparisonResult]) -> str:
        """
        Generate markdown report of all comparisons.
        
        WHAT THIS GENERATES:
        -------------------
        Markdown-formatted report with:
        - Summary table of all metrics
        - Statistical details for each comparison
        - Overall assessment
        
        Args:
            results: Dict mapping metric names to ComparisonResults
            
        Returns:
            Markdown-formatted report string
            
        Example:
            >>> results = {
            ...     'accuracy': accuracy_result,
            ...     'energy_savings': energy_result
            ... }
            >>> report = comparator.generate_report(results)
            >>> with open('report.md', 'w') as f:
            ...     f.write(report)
        """
        lines = []
        lines.append("# YRSN vs Baseline Comparison Report\n")
        lines.append("## Summary Table\n")
        lines.append("| Metric | Baseline | YRSN | Improvement | p-value | Significance | Winner |")
        lines.append("|--------|----------|------|-------------|---------|--------------|--------|")
        
        for name, result in results.items():
            lines.append(
                f"| {result.metric_name} | "
                f"{result.baseline_mean:.3f} ± {result.baseline_std:.3f} | "
                f"{result.yrsn_mean:.3f} ± {result.yrsn_std:.3f} | "
                f"{result.improvement:+.1%} | "
                f"{result.p_value:.4f} | "
                f"{result.significance_marker} | "
                f"**{result.winner}** |"
            )
            
        lines.append("\n## Detailed Analysis\n")
        
        for name, result in results.items():
            lines.append(f"### {result.metric_name.replace('_', ' ').title()}\n")
            lines.append(f"- **Baseline**: {result.baseline_mean:.3f} ± {result.baseline_std:.3f}")
            lines.append(f"- **YRSN**: {result.yrsn_mean:.3f} ± {result.yrsn_std:.3f}")
            lines.append(f"- **Improvement**: {result.improvement:+.1%}")
            lines.append(f"- **p-value**: {result.p_value:.4f} ({result.significance_marker})")
            lines.append(f"- **Effect Size**: {result.effect_size:.2f} ({result.effect_interpretation})")
            lines.append(f"- **Winner**: **{result.winner}**\n")
            
        # Overall assessment
        yrsn_wins = sum(1 for r in results.values() if r.winner == 'YRSN')
        baseline_wins = sum(1 for r in results.values() if r.winner == 'Baseline')
        ties = sum(1 for r in results.values() if r.winner == 'Tie')
        
        lines.append("## Overall Assessment\n")
        lines.append(f"- YRSN wins: {yrsn_wins}/{len(results)} metrics")
        lines.append(f"- Baseline wins: {baseline_wins}/{len(results)} metrics")
        lines.append(f"- Ties: {ties}/{len(results)} metrics")
        
        if yrsn_wins > baseline_wins:
            lines.append("\n**Conclusion**: YRSN outperforms baseline overall.")
        elif baseline_wins > yrsn_wins:
            lines.append("\n**Conclusion**: Baseline outperforms YRSN overall.")
        else:
            lines.append("\n**Conclusion**: YRSN and baseline are comparable.")
            
        return "\n".join(lines)


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'BaselineComparator',
    'ComparisonResult',
]
