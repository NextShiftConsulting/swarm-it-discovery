"""
Energy Accounting for Inference Pipelines

This module tracks energy costs across inference with quality gating.

┌─────────────────────────────────────────────────────────────────┐
│                      WHAT THIS DOES                              │
├─────────────────────────────────────────────────────────────────┤
│ Tracks energy consumption for:                                  │
│   • YRSN signal computation                                     │
│   • Full model inference                                        │
│   • Quality gating decisions                                    │
│   • Computes savings from skipping low-quality inputs          │
└─────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
- Quantify energy savings from quality-aware gating
- Compare baseline (no gating) vs gated inference
- Provide metrics for efficiency claims
- Avoid hardcoding energy values in experiments

HOW IT WORKS:
------------
1. Define energy profile (costs for each operation)
2. Record each operation during inference
3. Compute total energy (baseline vs gated)
4. Calculate savings percentage

ENERGY PROFILE:
--------------
- YRSN_SIGNAL_COST: Cost to compute R/S/N and alpha
- INFERENCE_COST: Cost to run full model
- SKIP_COST: Cost to skip (minimal overhead)

TYPICAL VALUES:
- YRSN: 1.0 (normalized)
- Inference: 10.0 (10x more expensive)
- Skip: 0.1 (minimal)

USAGE EXAMPLES:
--------------

Example 1: Track Energy During Inference
>>> from yrsn.analysis import EnergyAccountant, EnergyProfile
>>> 
>>> # Define costs
>>> profile = EnergyProfile(
...     yrsn_signal_cost=1.0,
...     inference_cost=10.0,
...     skip_cost=0.1
... )
>>> 
>>> # Track energy
>>> accountant = EnergyAccountant(profile)
>>> 
>>> for sample in dataset:
...     # Baseline always runs inference
...     accountant.record_baseline_inference()
...     
...     # Gated checks quality first
...     alpha = compute_alpha(sample)
...     if alpha >= 0.5:
...         accountant.record_gated_inference(did_skip=False)
...     else:
...         accountant.record_gated_inference(did_skip=True)
>>> 
>>> # Get results
>>> savings = accountant.compute_savings()
>>> print(f"Energy saved: {savings['savings_pct']:.1f}%")
>>> print(f"Skip rate: {savings['skip_rate']:.1%}")

Example 2: Compare Multiple Thresholds
>>> results = {}
>>> for threshold in [0.3, 0.5, 0.7]:
...     accountant = EnergyAccountant(profile)
...     # Run inference with this threshold
...     for sample in dataset:
...         accountant.record_baseline_inference()
...         alpha = compute_alpha(sample)
...         did_skip = alpha < threshold
...         accountant.record_gated_inference(did_skip)
...     results[threshold] = accountant.compute_savings()
>>> 
>>> # Find best threshold
>>> best = max(results.items(), key=lambda x: x[1]['savings_pct'])
>>> print(f"Best threshold: {best[0]} ({best[1]['savings_pct']:.1f}% savings)")

Example 3: Custom Energy Profile (Hardware-Based)
>>> # Measure on your hardware
>>> profile = EnergyProfile(
...     yrsn_signal_cost=0.5,  # Measured: 50ms
...     inference_cost=5.0,    # Measured: 500ms
...     skip_cost=0.05         # Measured: 5ms
... )
>>> accountant = EnergyAccountant(profile)

Example 4: Generate Report
>>> accountant = EnergyAccountant(profile)
>>> # ... run inference ...
>>> report = accountant.generate_report()
>>> print(report)
>>> # Markdown-formatted summary
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class EnergyProfile:
    """
    Energy cost profile for operations.
    
    WHAT THIS DEFINES:
    -----------------
    Relative costs of different operations.
    Units are arbitrary but consistent.
    
    TYPICAL RATIOS:
    --------------
    - YRSN: 1.0 (baseline)
    - Inference: 10.0 (10x more expensive)
    - Skip: 0.1 (10x cheaper than YRSN)
    
    CUSTOMIZATION:
    -------------
    Measure actual costs on your hardware:
    1. Time YRSN computation → yrsn_signal_cost
    2. Time full inference → inference_cost
    3. Time skip decision → skip_cost
    
    Attributes:
        yrsn_signal_cost: Cost to compute YRSN signals
        inference_cost: Cost to run full model inference
        skip_cost: Cost to skip (decision overhead)
    """
    yrsn_signal_cost: float = 1.0
    inference_cost: float = 10.0
    skip_cost: float = 0.1


class EnergyAccountant:
    """
    Track energy costs across inference pipeline.
    
    CAPABILITIES:
    ------------
    ✓ Record baseline (no gating) energy
    ✓ Record gated (with quality checking) energy
    ✓ Track skip rate
    ✓ Compute energy savings
    ✓ Generate detailed reports
    
    METRICS COMPUTED:
    ----------------
    - Total energy (baseline vs gated)
    - Energy savings (absolute and percentage)
    - Skip rate (fraction of samples skipped)
    - Cost per sample (average)
    
    METHODS:
    -------
    record_baseline_inference() -> None
        Record cost of baseline (always runs inference)
        
    record_gated_inference(did_skip) -> None
        Record cost of gated (checks quality, may skip)
        
    compute_savings() -> Dict
        Compute energy savings metrics
        
    generate_report() -> str
        Generate markdown report
        
    reset() -> None
        Reset all counters
    """
    
    def __init__(self, profile: EnergyProfile):
        """
        Initialize energy accountant.
        
        Args:
            profile: Energy cost profile
        """
        self.profile = profile
        self.reset()
        
    def reset(self):
        """
        Reset all counters.
        
        Use this to start a new experiment without creating new accountant.
        """
        self.total_baseline = 0.0
        self.total_gated = 0.0
        self.num_samples = 0
        self.num_skipped = 0
        
    def record_baseline_inference(self):
        """
        Record cost of baseline inference (no gating).
        
        BASELINE ALWAYS:
        ---------------
        - Runs full model inference
        - No quality check
        - No skipping
        
        Example:
            >>> for sample in dataset:
            ...     accountant.record_baseline_inference()
            ...     run_model(sample)
        """
        self.total_baseline += self.profile.inference_cost
        self.num_samples += 1
        
    def record_gated_inference(self, did_skip: bool):
        """
        Record cost of gated inference (with quality check).
        
        GATED ALWAYS:
        ------------
        - Computes YRSN signals (cost: yrsn_signal_cost)
        - Checks quality (alpha >= threshold)
        - If HIGH quality: runs inference (cost: inference_cost)
        - If LOW quality: skips (cost: skip_cost)
        
        Args:
            did_skip: Whether sample was skipped (alpha < threshold)
            
        Example:
            >>> alpha = compute_alpha(sample)
            >>> if alpha >= 0.5:
            ...     accountant.record_gated_inference(did_skip=False)
            ...     run_model(sample)
            ... else:
            ...     accountant.record_gated_inference(did_skip=True)
            ...     # Don't run model
        """
        # Always pay YRSN cost
        self.total_gated += self.profile.yrsn_signal_cost
        
        if did_skip:
            # Low quality - skip
            self.total_gated += self.profile.skip_cost
            self.num_skipped += 1
        else:
            # High quality - run inference
            self.total_gated += self.profile.inference_cost
            
    def compute_savings(self) -> Dict[str, float]:
        """
        Compute energy savings metrics.
        
        METRICS:
        -------
        - energy_baseline: Total energy without gating
        - energy_gated: Total energy with gating
        - savings_absolute: Absolute energy saved
        - savings_pct: Percentage energy saved
        - skip_rate: Fraction of samples skipped
        - avg_baseline: Average cost per sample (baseline)
        - avg_gated: Average cost per sample (gated)
        
        Returns:
            Dict with energy metrics
            
        Example:
            >>> savings = accountant.compute_savings()
            >>> print(f"Saved {savings['savings_pct']:.1f}% energy")
            >>> print(f"Skipped {savings['skip_rate']:.1%} samples")
        """
        if self.num_samples == 0:
            return {
                'energy_baseline': 0.0,
                'energy_gated': 0.0,
                'savings_absolute': 0.0,
                'savings_pct': 0.0,
                'skip_rate': 0.0,
                'avg_baseline': 0.0,
                'avg_gated': 0.0
            }
            
        savings_absolute = self.total_baseline - self.total_gated
        savings_pct = (savings_absolute / self.total_baseline * 100) if self.total_baseline > 0 else 0.0
        skip_rate = self.num_skipped / self.num_samples
        
        return {
            'energy_baseline': self.total_baseline,
            'energy_gated': self.total_gated,
            'savings_absolute': savings_absolute,
            'savings_pct': savings_pct,
            'skip_rate': skip_rate,
            'avg_baseline': self.total_baseline / self.num_samples,
            'avg_gated': self.total_gated / self.num_samples
        }
        
    def generate_report(self) -> str:
        """
        Generate markdown report of energy accounting.
        
        REPORT INCLUDES:
        ---------------
        - Energy profile (costs used)
        - Total samples processed
        - Samples skipped
        - Energy totals (baseline vs gated)
        - Savings (absolute and percentage)
        - Cost per sample
        
        Returns:
            Markdown-formatted report string
            
        Example:
            >>> report = accountant.generate_report()
            >>> with open('energy_report.md', 'w') as f:
            ...     f.write(report)
        """
        savings = self.compute_savings()
        
        lines = []
        lines.append("# Energy Accounting Report\n")
        
        lines.append("## Energy Profile\n")
        lines.append(f"- YRSN Signal Cost: {self.profile.yrsn_signal_cost:.2f}")
        lines.append(f"- Inference Cost: {self.profile.inference_cost:.2f}")
        lines.append(f"- Skip Cost: {self.profile.skip_cost:.2f}\n")
        
        lines.append("## Inference Statistics\n")
        lines.append(f"- Total Samples: {self.num_samples}")
        lines.append(f"- Samples Skipped: {self.num_skipped} ({savings['skip_rate']:.1%})")
        lines.append(f"- Samples Processed: {self.num_samples - self.num_skipped}\n")
        
        lines.append("## Energy Consumption\n")
        lines.append(f"- **Baseline** (no gating): {savings['energy_baseline']:.2f}")
        lines.append(f"  - Avg per sample: {savings['avg_baseline']:.2f}")
        lines.append(f"- **Gated** (with quality check): {savings['energy_gated']:.2f}")
        lines.append(f"  - Avg per sample: {savings['avg_gated']:.2f}\n")
        
        lines.append("## Energy Savings\n")
        lines.append(f"- **Absolute**: {savings['savings_absolute']:.2f}")
        lines.append(f"- **Percentage**: {savings['savings_pct']:.1f}%\n")
        
        if savings['savings_pct'] > 30:
            lines.append("**Conclusion**: ✅ Significant energy savings achieved (>30%)")
        elif savings['savings_pct'] > 10:
            lines.append("**Conclusion**: ⚠️ Moderate energy savings achieved (10-30%)")
        else:
            lines.append("**Conclusion**: ❌ Minimal energy savings achieved (<10%)")
            
        return "\n".join(lines)


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'EnergyAccountant',
    'EnergyProfile',
]
