"""
Data Wiring Validator for Production Modules

This module validates data flow between modules to catch dimension mismatches,
wrong checkpoints, and other wiring issues BEFORE they produce garbage results.

┌─────────────────────────────────────────────────────────────────┐
│                      WHAT THIS DOES                              │
├─────────────────────────────────────────────────────────────────┤
│ Validates:                                                       │
│   • Model output dim matches projection input dim               │
│   • Correct checkpoint for task                                 │
│   • Feature normalization consistency                           │
│   • Module state is clean (eval mode, no gradients)            │
└─────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
The original "GARBAGE" bug was caused by:
1. Dimension mismatch (64-dim features → 128-dim projection)
2. Wrong checkpoint (synthetic training → real features)
3. No validation

This validator catches these issues BEFORE running experiments!

USAGE EXAMPLES:
--------------

Example 1: Validate Full Pipeline
>>> from yrsn.core import DataWiringValidator
>>> from yrsn.models import resnet20_cifar10
>>> from yrsn.core.decomposition import load_trained_projection
>>> 
>>> model = resnet20_cifar10(pretrained=True)
>>> projection = load_trained_projection('checkpoints/trained_rsn_cifar64.pt')
>>> 
>>> validator = DataWiringValidator()
>>> result = validator.validate_pipeline(model, projection)
>>> 
>>> if not result['valid']:
>>>     print("❌ Validation failed!")
>>>     for check, passed in result['checks']:
>>>         print(f"  {check}: {'✅' if passed else '❌'}")

Example 2: Flush Module State
>>> # Between experiments, flush state
>>> validator.flush_modules(model, energy_accountant, baseline_comparator)
>>> print("✅ All module state flushed")

Example 3: Validate Single Dimension
>>> validator.validate_dimensions(
...     model_dim=64,
...     projection_dim=64,
...     checkpoint_path='checkpoints/trained_rsn_cifar64.pt'
... )
>>> # Raises ValueError if mismatch
"""

from typing import Any, Dict, List, Tuple, Optional
from pathlib import Path
import torch


class DataWiringValidator:
    """
    Validates data wiring between modules to prevent garbage results.
    
    CRITICAL CHECKS:
    ---------------
    1. Dimension matching: model output = projection input
    2. Checkpoint correctness: task matches training
    3. Normalization consistency: same as training
    4. Module state: eval mode, no gradients, clean cache
    
    USE THIS BEFORE EVERY EXPERIMENT!
    """
    
    def __init__(self, verbose: bool = True):
        """
        Initialize validator.
        
        Args:
            verbose: Whether to print validation progress
        """
        self.verbose = verbose
        self.checks: List[Tuple[str, bool, Optional[str]]] = []
        
    def reset(self):
        """Clear validation history."""
        self.checks = []
        
    def _log(self, message: str):
        """Log message if verbose."""
        if self.verbose:
            print(message)
            
    def _add_check(self, name: str, passed: bool, details: Optional[str] = None):
        """Record a validation check."""
        self.checks.append((name, passed, details))
        if self.verbose:
            status = "✅" if passed else "❌"
            msg = f"{status} {name}"
            if details:
                msg += f": {details}"
            print(msg)
            
    def validate_dimensions(
        self,
        model_dim: int,
        projection_dim: int,
        checkpoint_name: str = "checkpoint"
    ) -> bool:
        """
        Validate that model output matches projection input dimension.
        
        Args:
            model_dim: Model feature output dimension
            projection_dim: Projection expected input dimension
            checkpoint_name: Name for error messages
            
        Returns:
            True if dimensions match
            
        Raises:
            ValueError: If dimensions don't match
        """
        if model_dim == projection_dim:
            self._add_check(
                "dimension_match",
                True,
                f"{model_dim}-dim ✓"
            )
            return True
        else:
            details = (
                f"Model outputs {model_dim}-dim but {checkpoint_name} "
                f"expects {projection_dim}-dim"
            )
            self._add_check("dimension_match", False, details)
            raise ValueError(
                f"\n{'='*70}\n"
                f"❌ DIMENSION MISMATCH - This will produce GARBAGE!\n"
                f"{'='*70}\n"
                f"Model output:       {model_dim}-dim\n"
                f"Projection input:   {projection_dim}-dim\n"
                f"Checkpoint:         {checkpoint_name}\n"
                f"\n"
                f"Common causes:\n"
                f"  1. Using wrong checkpoint (e.g., memristor vs cifar)\n"
                f"  2. Model architecture changed\n"
                f"  3. Wrong feature extraction layer\n"
                f"\n"
                f"Fix:\n"
                f"  - Use correct checkpoint for your model\n"
                f"  - Or retrain projection with current model\n"
                f"{'='*70}\n"
            )
            
    def validate_checkpoint_task(
        self,
        checkpoint_path: Path,
        expected_task: str
    ) -> bool:
        """
        Validate checkpoint matches the task.
        
        Args:
            checkpoint_path: Path to checkpoint
            expected_task: Expected task (e.g., 'cifar10', 'imagenet')
            
        Returns:
            True if checkpoint matches task
        """
        checkpoint_name = checkpoint_path.stem.lower()
        expected_task_lower = expected_task.lower()
        
        # Check if task name is in checkpoint name
        if expected_task_lower in checkpoint_name:
            self._add_check(
                "checkpoint_task_match",
                True,
                f"{expected_task} ✓"
            )
            return True
        else:
            details = (
                f"Checkpoint '{checkpoint_path.name}' may not be "
                f"for task '{expected_task}'"
            )
            self._add_check("checkpoint_task_match", False, details)
            print(
                f"\n⚠️  WARNING: Checkpoint/task mismatch!\n"
                f"   Checkpoint: {checkpoint_path.name}\n"
                f"   Expected task: {expected_task}\n"
                f"   This may produce incorrect results!\n"
            )
            return False
            
    def validate_model_state(self, model: torch.nn.Module) -> bool:
        """
        Validate model is in correct state (eval mode, no gradients).
        
        Args:
            model: PyTorch model to validate
            
        Returns:
            True if model state is correct
        """
        # Check eval mode
        if not model.training:
            self._add_check("model_eval_mode", True)
        else:
            self._add_check("model_eval_mode", False, "Model is in training mode!")
            raise ValueError("Model must be in eval mode! Call model.eval()")
            
        # Check no gradients
        has_grad = any(p.requires_grad for p in model.parameters())
        if not has_grad:
            self._add_check("model_no_grad", True)
        else:
            self._add_check("model_no_grad", False, "Model has requires_grad=True")
            print("⚠️  Warning: Model parameters have requires_grad=True")
            print("   This is OK for experiments but wastes memory")
            
        return True
        
    def validate_pipeline(
        self,
        model: Any,
        projection: Any,
        checkpoint_path: Optional[Path] = None,
        expected_task: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Validate entire pipeline before running experiment.
        
        This is the MAIN validation method - call this before every experiment!
        
        Args:
            model: Feature extraction model (must have .feature_dim attribute)
            projection: RSN projection (must have .config.hidden_dim attribute)
            checkpoint_path: Optional path to checkpoint
            expected_task: Optional expected task name (e.g., 'cifar10')
            
        Returns:
            Dict with 'valid' (bool) and 'checks' (list) and 'summary' (str)
            
        Raises:
            ValueError: If critical checks fail (dimensions, model state)
        """
        self._log("\n" + "="*70)
        self._log("DATA WIRING VALIDATION")
        self._log("="*70)
        self.reset()
        
        # Check 1: Dimension match
        try:
            model_dim = getattr(model, 'feature_dim', None)
            if model_dim is None:
                raise AttributeError("Model missing 'feature_dim' attribute")
                
            proj_dim = getattr(projection.config, 'hidden_dim', None)
            if proj_dim is None:
                raise AttributeError("Projection config missing 'hidden_dim' attribute")
                
            checkpoint_name = checkpoint_path.name if checkpoint_path else "checkpoint"
            self.validate_dimensions(model_dim, proj_dim, checkpoint_name)
            
        except Exception as e:
            self._add_check("dimension_check", False, str(e))
            raise
            
        # Check 2: Checkpoint/task match (warning only)
        if checkpoint_path and expected_task:
            self.validate_checkpoint_task(checkpoint_path, expected_task)
            
        # Check 3: Model state
        if isinstance(model, torch.nn.Module):
            try:
                self.validate_model_state(model)
            except Exception as e:
                self._add_check("model_state", False, str(e))
                raise
        else:
            self._add_check("model_state", True, "Not a PyTorch model (skipped)")
            
        # Check 4: Feature normalization (informational)
        if hasattr(projection, 'config') and hasattr(projection.config, 'feature_normalization'):
            norm_method = projection.config.feature_normalization
            self._add_check(
                "feature_normalization",
                True,
                f"Projection expects '{norm_method}' - ensure consistency!"
            )
        else:
            self._add_check(
                "feature_normalization",
                True,
                "No normalization specified in config"
            )
            
        # Summary
        all_passed = all(passed for _, passed, _ in self.checks)
        self._log("="*70)
        if all_passed:
            self._log("✅ ALL CHECKS PASSED - Pipeline is correctly wired!")
        else:
            self._log("❌ SOME CHECKS FAILED - Review errors above!")
        self._log("="*70)
        
        return {
            "valid": all_passed,
            "checks": self.checks,
            "summary": "All checks passed" if all_passed else "Some checks failed"
        }

    def validate_fit_methodology(
        self,
        projection: Any,
        expected_strategy: str,
    ) -> Dict[str, Any]:
        """
        Validate projection fit methodology matches DOE specification (P11: Experimental Rigor).

        This is a MEASUREMENT (P1) - returns signal about fit state, caller decides action.

        Args:
            projection: TrainedRSNProjection with fit_state property
            expected_strategy: Expected strategy from FitStrategy enum values:
                - "once_on_clean": fit() called exactly once (for expS5_203)
                - "per_domain": fit() called once per domain
                - "never": fit() never called (use pre-trained)

        Returns:
            Dict with:
                valid (bool): Whether methodology is correct
                code (str): Error code ('OK', 'E601', 'E602', 'E603')
                message (str): Human-readable message
                fit_state (dict): Current fit state for diagnostics

        Example:
            >>> validator = DataWiringValidator()
            >>> projection.fit(clean_features)
            >>> result = validator.validate_fit_methodology(projection, "once_on_clean")
            >>> if not result['valid']:
            ...     print(f"❌ {result['code']}: {result['message']}")
        """
        # Get fit state (P1: measurement)
        if not hasattr(projection, 'fit_state'):
            return {
                'valid': False,
                'code': 'E603',
                'message': "Projection doesn't have fit_state property (update yrsn package)",
                'fit_state': None
            }

        fit_state = projection.fit_state

        # Validate based on expected strategy
        if expected_strategy == "once_on_clean":
            if fit_state['fit_count'] == 0:
                result = {
                    'valid': False,
                    'code': 'E601',
                    'message': "FIT_ONCE_ON_CLEAN requires fit() called exactly once, but fit_count=0",
                    'fit_state': fit_state
                }
            elif fit_state['fit_count'] == 1:
                result = {
                    'valid': True,
                    'code': 'OK',
                    'message': f"FIT_ONCE_ON_CLEAN satisfied (fit_count=1, ref_size={fit_state['reference_size']})",
                    'fit_state': fit_state
                }
            else:
                result = {
                    'valid': False,
                    'code': 'E601',
                    'message': f"FIT_ONCE_ON_CLEAN violated: fit() called {fit_state['fit_count']} times",
                    'fit_state': fit_state
                }

        elif expected_strategy == "never":
            if fit_state['fit_count'] == 0:
                result = {
                    'valid': True,
                    'code': 'OK',
                    'message': "FIT_NEVER satisfied (fit_count=0)",
                    'fit_state': fit_state
                }
            else:
                result = {
                    'valid': False,
                    'code': 'E601',
                    'message': f"FIT_NEVER violated: fit() called {fit_state['fit_count']} times",
                    'fit_state': fit_state
                }

        elif expected_strategy == "per_domain":
            # For per_domain, we just check fit was called at least once
            if fit_state['fit_count'] >= 1:
                result = {
                    'valid': True,
                    'code': 'OK',
                    'message': f"FIT_PER_DOMAIN: fit() called {fit_state['fit_count']} times",
                    'fit_state': fit_state
                }
            else:
                result = {
                    'valid': False,
                    'code': 'E601',
                    'message': "FIT_PER_DOMAIN requires at least one fit() call",
                    'fit_state': fit_state
                }

        else:
            result = {
                'valid': False,
                'code': 'E603',
                'message': f"Unknown fit strategy: {expected_strategy}",
                'fit_state': fit_state
            }

        # Log result
        self._add_check(
            "fit_methodology",
            result['valid'],
            result['message']
        )

        return result

    def flush_modules(self, *modules):
        """
        Flush state from all stateful modules.
        
        USE THIS BETWEEN EXPERIMENTS to ensure clean state!
        
        Handles:
        - PyTorch models: .eval() and .zero_grad()
        - Modules with .reset(): calls reset()
        - GPU cache: clears if available
        
        Args:
            *modules: Variable number of modules to flush
            
        Example:
            >>> validator.flush_modules(
            ...     model,
            ...     energy_accountant,
            ...     baseline_comparator
            ... )
        """
        self._log("\n🧹 Flushing module state...")
        
        for module in modules:
            module_name = type(module).__name__
            
            # PyTorch models
            if isinstance(module, torch.nn.Module):
                module.eval()
                module.zero_grad()
                self._log(f"  ✅ {module_name}: eval mode + zero_grad")
                
            # Modules with reset()
            elif hasattr(module, 'reset'):
                module.reset()
                self._log(f"  ✅ {module_name}: reset()")
                
            else:
                self._log(f"  ⏭️  {module_name}: no state to flush")
                
        # Clear GPU cache
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            self._log("  ✅ GPU cache cleared")
            
        self._log("✅ All module state flushed!\n")


def validate_experiment_setup(
    model: Any,
    projection: Any,
    checkpoint_path: Path,
    expected_task: str,
    verbose: bool = True
) -> bool:
    """
    Convenience function to validate experiment setup.
    
    Args:
        model: Feature extraction model
        projection: RSN projection
        checkpoint_path: Path to checkpoint
        expected_task: Expected task (e.g., 'cifar10')
        verbose: Whether to print progress
        
    Returns:
        True if validation passed
        
    Raises:
        ValueError: If critical checks fail
    """
    validator = DataWiringValidator(verbose=verbose)
    result = validator.validate_pipeline(model, projection, checkpoint_path, expected_task)
    return result['valid']
