"""
YRSN Filtering - Signal processing and decomposition.

Decompose signals into intrinsic components for R/S/N analysis.

Available Filters:
    FIF           - Fast Iterative Filtering (EMD-like)
    IMFClassifier - Classify Intrinsic Mode Functions
    EchoState     - Echo State Networks (reservoir computing)
    SignalSeparator - Source separation

Example:
    from yrsn.filtering import FIF, EchoState

    # Signal decomposition
    fif = FIF(num_imfs=5)
    imfs = fif.decompose(signal)

    # Reservoir computing
    esn = EchoState(input_dim=10, reservoir_size=500)
    output = esn.predict(sequence)
"""

# Fast Iterative Filtering
try:
    from yrsn_context.core.filtering.fif import (
        FastIterativeFiltering,
        FIFConfig,
    )
    # Alias
    FIF = FastIterativeFiltering
    HAS_FIF = True
except ImportError:
    HAS_FIF = False
    FastIterativeFiltering = None
    FIFConfig = None
    FIF = None

# IMF Classifier
try:
    from yrsn_context.core.filtering.imf_classifier import (
        IMFClassifier,
        IMFType,
        classify_imf,
    )
    HAS_IMF = True
except ImportError:
    HAS_IMF = False
    IMFClassifier = None
    IMFType = None
    classify_imf = None

# Multivariate FIF
try:
    from yrsn_context.core.filtering.mv_fif import (
        MultivariateIF,
        MVFIFConfig,
    )
    HAS_MVFIF = True
except ImportError:
    HAS_MVFIF = False
    MultivariateIF = None
    MVFIFConfig = None

# Multi-Dimensional FIF
try:
    from yrsn_context.core.filtering.md_fif import (
        MultiDimensionalIF,
        MDFIFConfig,
    )
    HAS_MDFIF = True
except ImportError:
    HAS_MDFIF = False
    MultiDimensionalIF = None
    MDFIFConfig = None

# Echo State Networks (Reservoir)
try:
    from yrsn_context.core.reservoir.echo_state import (
        EchoStateNetwork,
        ESNConfig,
    )
    # Alias
    EchoState = EchoStateNetwork
    HAS_ESN = True
except ImportError:
    HAS_ESN = False
    EchoStateNetwork = None
    ESNConfig = None
    EchoState = None

# Signal Separator
try:
    from yrsn_context.core.reservoir.signal_separator import (
        SignalSeparator,
        SeparatorConfig,
    )
    HAS_SEPARATOR = True
except ImportError:
    HAS_SEPARATOR = False
    SignalSeparator = None
    SeparatorConfig = None


def list_filters():
    """List available filters."""
    available = []
    if HAS_FIF:
        available.append("FIF")
    if HAS_IMF:
        available.append("IMFClassifier")
    if HAS_MVFIF:
        available.append("MultivariateIF")
    if HAS_MDFIF:
        available.append("MultiDimensionalIF")
    if HAS_ESN:
        available.append("EchoState")
    if HAS_SEPARATOR:
        available.append("SignalSeparator")
    return available


__all__ = [
    # FIF
    "FIF",
    "FastIterativeFiltering",
    "FIFConfig",
    # IMF
    "IMFClassifier",
    "IMFType",
    "classify_imf",
    # Multivariate
    "MultivariateIF",
    "MVFIFConfig",
    # Multi-dimensional
    "MultiDimensionalIF",
    "MDFIFConfig",
    # Echo State
    "EchoState",
    "EchoStateNetwork",
    "ESNConfig",
    # Signal Separator
    "SignalSeparator",
    "SeparatorConfig",
    # Utils
    "list_filters",
    # Availability flags
    "HAS_FIF",
    "HAS_IMF",
    "HAS_MVFIF",
    "HAS_MDFIF",
    "HAS_ESN",
    "HAS_SEPARATOR",
]
