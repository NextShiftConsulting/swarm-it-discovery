"""
Fast Iterative Filtering (1D)
=============================

Decomposes 1D signals into Intrinsic Mode Functions (IMFs) using
iterative convolution with low-pass filters.

FIF is an alternative to Empirical Mode Decomposition (EMD) that:
- Uses convolution instead of envelope interpolation
- Is faster and more numerically stable
- Has well-defined convergence properties

Mathematical formulation:
    m_{k+1} = L * m_k  (convolution with low-pass filter)
    IMF = x - m_K      (after K iterations)

Each IMF captures oscillations at a characteristic frequency scale.
The decomposition proceeds from high to low frequency.

Usage:
    from yrsn.core.filtering import FastIterativeFiltering

    fif = FastIterativeFiltering(num_imfs=10)
    imfs = fif.decompose(signal)

    # IMFs ordered high-freq to low-freq, last is residual

References:
- Cicone (2020). Iterative Filtering as EMD alternative
- Huang et al. (1998). Empirical Mode Decomposition
"""

import numpy as np
from typing import List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class FIFConfig:
    """Configuration for Fast Iterative Filtering."""
    num_imfs: int = 10
    filter_length: int = 32
    max_iterations: int = 100
    convergence_tol: float = 1e-8
    min_imf_energy: float = 1e-10


@dataclass
class FIFResult:
    """Result of FIF decomposition."""
    imfs: List[np.ndarray]
    residual: np.ndarray
    iterations_per_imf: List[int]
    frequencies: List[float]

    @property
    def num_imfs(self) -> int:
        """Number of IMFs extracted (excluding residual)."""
        return len(self.imfs) - 1  # Last is residual

    def reconstruct(self) -> np.ndarray:
        """Reconstruct original signal from IMFs."""
        return sum(self.imfs)

    def get_imf(self, index: int) -> np.ndarray:
        """Get IMF by index (0 = highest frequency)."""
        return self.imfs[index]


class FastIterativeFiltering:
    """
    1D Fast Iterative Filtering for IMF extraction.

    Decomposes a signal into Intrinsic Mode Functions (IMFs)
    ordered from high to low frequency. The last component
    is the residual (trend).

    Parameters
    ----------
    num_imfs : int
        Maximum number of IMFs to extract (default 10)
    filter_length : int
        Length of low-pass filter kernel (default 32)
    max_iterations : int
        Maximum iterations per IMF extraction (default 100)
    convergence_tol : float
        Convergence tolerance for local mean (default 1e-8)
    adaptive_filter : bool
        Adapt filter length based on signal (default True)

    Examples
    --------
    >>> fif = FastIterativeFiltering(num_imfs=8)
    >>> imfs = fif.decompose(noisy_signal)
    >>> high_freq = imfs[0]  # Highest frequency component
    >>> trend = imfs[-1]     # Low-frequency residual
    """

    def __init__(
        self,
        num_imfs: int = 10,
        filter_length: int = 32,
        max_iterations: int = 100,
        convergence_tol: float = 1e-8,
        adaptive_filter: bool = True
    ):
        self.num_imfs = num_imfs
        self.filter_length = filter_length
        self.max_iterations = max_iterations
        self.convergence_tol = convergence_tol
        self.adaptive_filter = adaptive_filter

    def decompose(self, x: np.ndarray) -> List[np.ndarray]:
        """
        Decompose signal into IMFs.

        Parameters
        ----------
        x : np.ndarray
            Input signal (1D array)

        Returns
        -------
        List[np.ndarray]
            List of IMFs from high to low frequency.
            Last element is the residual/trend.
        """
        x = np.asarray(x).flatten().astype(np.float64)

        imfs = []
        residual = x.copy()

        for k in range(self.num_imfs):
            # Adapt filter length if enabled
            filter_len = self._get_filter_length(residual, k)

            # Extract one IMF
            imf, iterations = self._extract_imf(residual, filter_len)

            # Check if IMF has significant energy
            if np.std(imf) < 1e-10:
                break

            imfs.append(imf)
            residual = residual - imf

            # Check if residual is negligible
            if np.std(residual) < 1e-10:
                break

        # Append residual as final component
        imfs.append(residual)

        return imfs

    def decompose_detailed(self, x: np.ndarray) -> FIFResult:
        """
        Decompose with detailed diagnostics.

        Returns FIFResult with IMFs, iteration counts, and frequencies.
        """
        x = np.asarray(x).flatten().astype(np.float64)

        imfs = []
        iterations_list = []
        residual = x.copy()

        for k in range(self.num_imfs):
            filter_len = self._get_filter_length(residual, k)
            imf, iterations = self._extract_imf(residual, filter_len)

            if np.std(imf) < 1e-10:
                break

            imfs.append(imf)
            iterations_list.append(iterations)
            residual = residual - imf

            if np.std(residual) < 1e-10:
                break

        imfs.append(residual)
        iterations_list.append(0)  # Residual has no iterations

        # Estimate frequencies
        frequencies = [self._estimate_frequency(imf) for imf in imfs]

        return FIFResult(
            imfs=imfs,
            residual=residual,
            iterations_per_imf=iterations_list,
            frequencies=frequencies
        )

    def _extract_imf(
        self,
        x: np.ndarray,
        filter_len: int
    ) -> Tuple[np.ndarray, int]:
        """
        Extract single IMF via iterative filtering.

        Parameters
        ----------
        x : np.ndarray
            Signal to decompose
        filter_len : int
            Filter length for this IMF

        Returns
        -------
        imf : np.ndarray
            Extracted IMF
        iterations : int
            Number of iterations used
        """
        m = x.copy()
        L = self._design_filter(len(x), filter_len)

        for k in range(self.max_iterations):
            # Convolve with low-pass filter
            m_new = np.convolve(m, L, mode='same')

            # Check convergence
            delta = np.max(np.abs(m_new - m))
            if delta < self.convergence_tol:
                return x - m_new, k + 1

            m = m_new

        return x - m, self.max_iterations

    def _design_filter(self, signal_len: int, filter_len: int) -> np.ndarray:
        """
        Design Fokker-Planck low-pass filter.

        The filter is a Gaussian-like kernel that estimates the local mean.

        Parameters
        ----------
        signal_len : int
            Length of signal being filtered
        filter_len : int
            Desired filter length

        Returns
        -------
        np.ndarray
            Normalized filter kernel
        """
        # Ensure filter isn't too long for signal
        w = min(filter_len, signal_len // 4)
        if w < 2:
            w = 2

        # Fokker-Planck filter (Gaussian)
        t = np.linspace(-3, 3, 2 * w + 1)
        L = np.exp(-t ** 2 / 2)

        return L / L.sum()

    def _get_filter_length(self, x: np.ndarray, imf_index: int) -> int:
        """
        Get adaptive filter length.

        Shorter filters extract higher frequencies.
        As we progress through IMFs, we use longer filters.
        """
        if not self.adaptive_filter:
            return self.filter_length

        # Start with shorter filter, increase for lower frequencies
        base = self.filter_length
        scale = 1.0 + 0.3 * imf_index  # Increase by 30% per IMF

        return min(int(base * scale), len(x) // 4)

    @staticmethod
    def _estimate_frequency(x: np.ndarray) -> float:
        """
        Estimate characteristic frequency via zero-crossing rate.

        Parameters
        ----------
        x : np.ndarray
            Signal

        Returns
        -------
        float
            Estimated frequency (cycles per sample)
        """
        if len(x) < 2:
            return 0.0

        # Count zero crossings
        signs = np.sign(x)
        zero_crossings = np.sum(np.abs(np.diff(signs)) > 0)

        # Frequency = zero_crossings / (2 * length)
        return zero_crossings / (2 * len(x))


# =============================================================================
# Convenience Functions
# =============================================================================

def fif_decompose(
    x: np.ndarray,
    num_imfs: int = 10,
    filter_length: int = 32
) -> List[np.ndarray]:
    """
    Decompose 1D signal into IMFs.

    Convenience wrapper around FastIterativeFiltering.

    Parameters
    ----------
    x : np.ndarray
        Input signal
    num_imfs : int
        Maximum IMFs to extract
    filter_length : int
        Low-pass filter length

    Returns
    -------
    List[np.ndarray]
        IMFs from high to low frequency
    """
    fif = FastIterativeFiltering(
        num_imfs=num_imfs,
        filter_length=filter_length
    )
    return fif.decompose(x)


def extract_trend(x: np.ndarray, num_imfs: int = 5) -> np.ndarray:
    """
    Extract low-frequency trend from signal.

    Parameters
    ----------
    x : np.ndarray
        Input signal
    num_imfs : int
        Number of high-frequency IMFs to remove

    Returns
    -------
    np.ndarray
        Low-frequency trend (sum of low-freq IMFs + residual)
    """
    imfs = fif_decompose(x, num_imfs=num_imfs + 1)
    return imfs[-1]  # Return residual/trend


def extract_oscillations(x: np.ndarray, num_imfs: int = 3) -> np.ndarray:
    """
    Extract high-frequency oscillations from signal.

    Parameters
    ----------
    x : np.ndarray
        Input signal
    num_imfs : int
        Number of high-frequency IMFs to extract

    Returns
    -------
    np.ndarray
        High-frequency oscillations (sum of high-freq IMFs)
    """
    imfs = fif_decompose(x, num_imfs=num_imfs + 2)
    return sum(imfs[:num_imfs])
