"""
Multivariate Fast Iterative Filtering (MvFIF)
=============================================

Extends FIF to handle multivariate (vector-valued) signals while
preserving cross-channel relationships.

For a signal x(t) ∈ ℝ^d:
    x(t) = [x_1(t), ..., x_d(t)]^T
    IMF_k(t) = [IMF_{k,1}(t), ..., IMF_{k,d}(t)]^T

Two decomposition modes:
- Joint: Uses average local mean across channels (preserves synchrony)
- Channel-wise: Independent decomposition per channel (faster)

Use cases:
- Multi-sensor data
- Multimodal signals (audio + video features)
- Financial multi-asset time series
- EEG/EMG multichannel recordings

Usage:
    from yrsn.core.filtering import MultivariateFIF

    # Joint decomposition (recommended)
    mvfif = MultivariateFIF(joint_estimation=True)
    imfs = mvfif.decompose(multichannel_data)  # shape: (channels, time)

References:
- Rehman & Mandic (2010). Multivariate EMD
- arXiv:2412.00553 - MdMvFIF algorithm
"""

import numpy as np
from typing import List, Tuple, Optional
from dataclasses import dataclass

from .fif import FastIterativeFiltering


@dataclass
class MvFIFResult:
    """Result of multivariate FIF decomposition."""
    imfs: List[np.ndarray]  # Each IMF has shape (n_channels, n_samples)
    residual: np.ndarray
    n_channels: int
    n_samples: int
    mode: str  # 'joint' or 'channel_wise'

    @property
    def num_imfs(self) -> int:
        return len(self.imfs) - 1

    def reconstruct(self) -> np.ndarray:
        return sum(self.imfs)

    def get_channel(self, channel: int) -> List[np.ndarray]:
        """Get all IMFs for a specific channel."""
        return [imf[channel] for imf in self.imfs]


class MultivariateFIF:
    """
    Multivariate Fast Iterative Filtering.

    Decomposes vector-valued signals while preserving
    cross-channel relationships.

    Parameters
    ----------
    num_imfs : int
        Maximum IMFs to extract (default 10)
    filter_length : int
        Low-pass filter length (default 32)
    max_iterations : int
        Max iterations per IMF (default 100)
    joint_estimation : bool
        If True, use average local mean across channels.
        If False, decompose each channel independently.
        (default True)
    convergence_tol : float
        Convergence tolerance (default 1e-8)

    Examples
    --------
    >>> mvfif = MultivariateFIF(joint_estimation=True)
    >>> # data shape: (3 channels, 1000 samples)
    >>> imfs = mvfif.decompose(multichannel_data)
    >>> # Each IMF has shape (3, 1000)
    """

    def __init__(
        self,
        num_imfs: int = 10,
        filter_length: int = 32,
        max_iterations: int = 100,
        joint_estimation: bool = True,
        convergence_tol: float = 1e-8
    ):
        self.num_imfs = num_imfs
        self.filter_length = filter_length
        self.max_iterations = max_iterations
        self.joint_estimation = joint_estimation
        self.convergence_tol = convergence_tol

        # 1D FIF for channel-wise decomposition
        self._fif_1d = FastIterativeFiltering(
            num_imfs=num_imfs,
            filter_length=filter_length,
            max_iterations=max_iterations,
            convergence_tol=convergence_tol
        )

    def decompose(self, X: np.ndarray) -> List[np.ndarray]:
        """
        Decompose multivariate signal into IMFs.

        Parameters
        ----------
        X : np.ndarray
            Shape (n_channels, n_samples) or (n_samples, n_channels).
            Auto-detected based on which dimension is larger.

        Returns
        -------
        List[np.ndarray]
            IMFs with shape (n_channels, n_samples).
            Last element is the residual.
        """
        X = np.asarray(X, dtype=np.float64)

        # Ensure shape is (channels, samples)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        elif X.shape[0] > X.shape[1]:
            X = X.T

        if self.joint_estimation:
            return self._joint_decompose(X)
        else:
            return self._channel_wise_decompose(X)

    def decompose_detailed(self, X: np.ndarray) -> MvFIFResult:
        """
        Decompose with detailed diagnostics.
        """
        X = np.asarray(X, dtype=np.float64)

        if X.ndim == 1:
            X = X.reshape(1, -1)
        elif X.shape[0] > X.shape[1]:
            X = X.T

        n_channels, n_samples = X.shape

        if self.joint_estimation:
            imfs = self._joint_decompose(X)
            mode = 'joint'
        else:
            imfs = self._channel_wise_decompose(X)
            mode = 'channel_wise'

        return MvFIFResult(
            imfs=imfs,
            residual=imfs[-1],
            n_channels=n_channels,
            n_samples=n_samples,
            mode=mode
        )

    def _joint_decompose(self, X: np.ndarray) -> List[np.ndarray]:
        """
        Joint decomposition preserving cross-channel structure.

        Uses average local mean across all channels to ensure
        synchronized IMF extraction.
        """
        n_channels, n_samples = X.shape
        imfs = []
        residual = X.copy()

        for k in range(self.num_imfs):
            # Adapt filter for this level
            filter_len = self._get_filter_length(n_samples, k)
            L = self._design_filter(n_samples, filter_len)

            # Extract joint IMF
            imf, converged = self._extract_joint_imf(residual, L)

            # Check if IMF has significant energy
            if np.std(imf) < 1e-10:
                break

            imfs.append(imf)
            residual = residual - imf

            if np.std(residual) < 1e-10:
                break

        imfs.append(residual)
        return imfs

    def _extract_joint_imf(
        self,
        X: np.ndarray,
        L: np.ndarray
    ) -> Tuple[np.ndarray, bool]:
        """
        Extract single IMF using joint local mean estimation.

        The local mean is computed as the average across channels
        after filtering each channel.
        """
        n_channels, n_samples = X.shape
        m = X.copy()

        for iteration in range(self.max_iterations):
            # Filter each channel
            filtered = np.array([
                np.convolve(m[c], L, mode='same')
                for c in range(n_channels)
            ])

            # Joint local mean = average across channels
            joint_mean = np.mean(filtered, axis=0)

            # Update each channel's local mean towards joint mean
            m_new = np.zeros_like(m)
            for c in range(n_channels):
                # Blend channel mean with joint mean
                channel_mean = filtered[c]
                m_new[c] = 0.7 * channel_mean + 0.3 * joint_mean

            # Check convergence
            delta = np.max(np.abs(m_new - m))
            if delta < self.convergence_tol:
                return X - m_new, True

            m = m_new

        return X - m, False

    def _channel_wise_decompose(self, X: np.ndarray) -> List[np.ndarray]:
        """
        Independent decomposition per channel.

        Faster but doesn't preserve cross-channel synchrony.
        """
        n_channels = X.shape[0]

        # Decompose each channel
        channel_imfs = [
            self._fif_1d.decompose(X[c])
            for c in range(n_channels)
        ]

        # Align IMFs across channels
        max_imfs = max(len(imfs) for imfs in channel_imfs)
        aligned = []

        for k in range(max_imfs):
            imf_k = np.array([
                channel_imfs[c][k] if k < len(channel_imfs[c])
                else np.zeros(X.shape[1])
                for c in range(n_channels)
            ])
            aligned.append(imf_k)

        return aligned

    def _design_filter(self, signal_len: int, filter_len: int) -> np.ndarray:
        """
        Design Fokker-Planck low-pass filter.
        """
        w = min(filter_len, signal_len // 4)
        if w < 2:
            w = 2

        t = np.linspace(-3, 3, 2 * w + 1)
        L = np.exp(-t ** 2 / 2)

        return L / L.sum()

    def _get_filter_length(self, n_samples: int, imf_index: int) -> int:
        """
        Get adaptive filter length for IMF level.
        """
        base = self.filter_length
        scale = 1.0 + 0.3 * imf_index

        return min(int(base * scale), n_samples // 4)


# =============================================================================
# Convenience Functions
# =============================================================================

def mvfif_decompose(
    X: np.ndarray,
    num_imfs: int = 10,
    joint: bool = True
) -> List[np.ndarray]:
    """
    Decompose multivariate signal into IMFs.

    Parameters
    ----------
    X : np.ndarray
        Multivariate signal (channels × samples)
    num_imfs : int
        Maximum IMFs
    joint : bool
        Use joint estimation

    Returns
    -------
    List[np.ndarray]
        IMFs from high to low frequency
    """
    mvfif = MultivariateFIF(
        num_imfs=num_imfs,
        joint_estimation=joint
    )
    return mvfif.decompose(X)


def multichannel_denoise(
    X: np.ndarray,
    levels_to_remove: int = 2
) -> np.ndarray:
    """
    Denoise multichannel signal by removing high-frequency IMFs.

    Parameters
    ----------
    X : np.ndarray
        Noisy multichannel signal
    levels_to_remove : int
        Number of high-freq IMFs to remove

    Returns
    -------
    np.ndarray
        Denoised signal
    """
    mvfif = MultivariateFIF(
        num_imfs=levels_to_remove + 3,
        joint_estimation=True
    )
    imfs = mvfif.decompose(X)
    return sum(imfs[levels_to_remove:])


def extract_common_mode(X: np.ndarray, num_imfs: int = 3) -> np.ndarray:
    """
    Extract common mode oscillations across channels.

    Uses joint decomposition to find synchronized components.

    Parameters
    ----------
    X : np.ndarray
        Multichannel signal
    num_imfs : int
        Number of IMF levels to consider

    Returns
    -------
    np.ndarray
        Common mode signal (average of reconstructed low-freq components)
    """
    mvfif = MultivariateFIF(num_imfs=num_imfs + 2, joint_estimation=True)
    imfs = mvfif.decompose(X)

    # Low-frequency components (last few IMFs including residual)
    low_freq = sum(imfs[-3:])

    # Return average across channels
    return np.mean(low_freq, axis=0)
