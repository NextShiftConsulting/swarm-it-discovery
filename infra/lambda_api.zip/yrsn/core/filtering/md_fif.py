"""
Multidimensional Fast Iterative Filtering (MdFIF)
=================================================

Extends FIF to handle multidimensional signals (images, volumes,
spatiotemporal data).

For a signal x(r) where r is a spatial coordinate vector:
    x(r) = Σ_k IMF_k(r) + residual(r)

The low-pass filter L becomes a multidimensional convolution kernel.
Each IMF captures oscillations at a characteristic spatial/temporal scale.

Usage:
    from yrsn.core.filtering import MultidimensionalFIF

    # 2D image decomposition
    mdfif = MultidimensionalFIF(num_imfs=8, filter_size=(5, 5))
    imfs = mdfif.decompose(image)

    # 3D volume decomposition
    mdfif_3d = MultidimensionalFIF(num_imfs=6, filter_size=(3, 3, 3))
    imfs = mdfif_3d.decompose(volume)

References:
- arXiv:2412.00553 - MdMvFIF algorithm
- Nunes et al. (2003). Image analysis by bidimensional EMD
"""

import numpy as np
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass


@dataclass
class MdFIFResult:
    """Result of multidimensional FIF decomposition."""
    imfs: List[np.ndarray]
    residual: np.ndarray
    original_shape: Tuple[int, ...]
    iterations_per_imf: List[int]

    @property
    def num_imfs(self) -> int:
        return len(self.imfs) - 1

    def reconstruct(self) -> np.ndarray:
        return sum(self.imfs)


class MultidimensionalFIF:
    """
    Multidimensional Fast Iterative Filtering.

    Handles signals varying in multiple spatial dimensions,
    with optional temporal dimension.

    Parameters
    ----------
    num_imfs : int
        Maximum IMFs to extract (default 8)
    filter_size : tuple of int
        Size of convolution kernel per dimension.
        E.g., (5, 5) for 2D, (3, 3, 3) for 3D
    max_iterations : int
        Max iterations per IMF (default 50)
    convergence_tol : float
        Convergence tolerance (default 1e-8)
    filter_type : str
        'gaussian' or 'uniform' (default 'gaussian')

    Examples
    --------
    >>> mdfif = MultidimensionalFIF(filter_size=(5, 5))
    >>> imfs = mdfif.decompose(noisy_image)
    >>> denoised = sum(imfs[2:])  # Remove high-freq IMFs
    """

    def __init__(
        self,
        num_imfs: int = 8,
        filter_size: Union[int, Tuple[int, ...]] = 5,
        max_iterations: int = 50,
        convergence_tol: float = 1e-8,
        filter_type: str = 'gaussian'
    ):
        self.num_imfs = num_imfs
        self.max_iterations = max_iterations
        self.convergence_tol = convergence_tol
        self.filter_type = filter_type

        # Handle scalar filter size
        if isinstance(filter_size, int):
            self._filter_size_scalar = filter_size
            self._filter_size = None  # Will be set per-signal
        else:
            self._filter_size = filter_size
            self._filter_size_scalar = None

    def decompose(self, x: np.ndarray) -> List[np.ndarray]:
        """
        Decompose multidimensional signal into IMFs.

        Parameters
        ----------
        x : np.ndarray
            Input signal (2D, 3D, or higher dimensional)

        Returns
        -------
        List[np.ndarray]
            IMFs from high to low frequency.
            Last element is the residual/trend.
        """
        x = np.asarray(x, dtype=np.float64)
        ndim = x.ndim

        # Determine filter size
        if self._filter_size is not None:
            filter_size = self._filter_size
            if len(filter_size) != ndim:
                raise ValueError(
                    f"Filter size dims ({len(filter_size)}) must match "
                    f"signal dims ({ndim})"
                )
        else:
            filter_size = tuple([self._filter_size_scalar] * ndim)

        imfs = []
        residual = x.copy()

        for k in range(self.num_imfs):
            # Adapt filter size for this IMF level
            current_filter = self._adapt_filter_size(filter_size, k, x.shape)

            # Extract one IMF
            imf, iterations = self._extract_imf_md(residual, current_filter)

            # Check if IMF has significant energy
            if np.std(imf) < 1e-10:
                break

            imfs.append(imf)
            residual = residual - imf

            # Check if residual is negligible
            if np.std(residual) < 1e-10:
                break

        imfs.append(residual)
        return imfs

    def decompose_detailed(self, x: np.ndarray) -> MdFIFResult:
        """
        Decompose with detailed diagnostics.
        """
        x = np.asarray(x, dtype=np.float64)
        original_shape = x.shape
        ndim = x.ndim

        if self._filter_size is not None:
            filter_size = self._filter_size
        else:
            filter_size = tuple([self._filter_size_scalar] * ndim)

        imfs = []
        iterations_list = []
        residual = x.copy()

        for k in range(self.num_imfs):
            current_filter = self._adapt_filter_size(filter_size, k, x.shape)
            imf, iterations = self._extract_imf_md(residual, current_filter)

            if np.std(imf) < 1e-10:
                break

            imfs.append(imf)
            iterations_list.append(iterations)
            residual = residual - imf

            if np.std(residual) < 1e-10:
                break

        imfs.append(residual)
        iterations_list.append(0)

        return MdFIFResult(
            imfs=imfs,
            residual=residual,
            original_shape=original_shape,
            iterations_per_imf=iterations_list
        )

    def _extract_imf_md(
        self,
        x: np.ndarray,
        filter_size: Tuple[int, ...]
    ) -> Tuple[np.ndarray, int]:
        """
        Extract single IMF using multidimensional convolution.
        """
        m = x.copy()

        for k in range(self.max_iterations):
            # Apply multidimensional filter
            m_new = self._apply_filter(m, filter_size)

            # Check convergence
            delta = np.max(np.abs(m_new - m))
            if delta < self.convergence_tol:
                return x - m_new, k + 1

            m = m_new

        return x - m, self.max_iterations

    def _apply_filter(
        self,
        x: np.ndarray,
        filter_size: Tuple[int, ...]
    ) -> np.ndarray:
        """
        Apply multidimensional low-pass filter.
        """
        if self.filter_type == 'gaussian':
            return self._gaussian_filter(x, filter_size)
        else:
            return self._uniform_filter(x, filter_size)

    def _gaussian_filter(
        self,
        x: np.ndarray,
        filter_size: Tuple[int, ...]
    ) -> np.ndarray:
        """
        Apply Gaussian filter using separable convolution.
        """
        result = x.copy()

        for axis, size in enumerate(filter_size):
            if size < 3:
                continue

            # 1D Gaussian kernel
            sigma = size / 6.0  # 3-sigma rule
            t = np.linspace(-3, 3, size)
            kernel = np.exp(-t ** 2 / 2)
            kernel = kernel / kernel.sum()

            # Apply along this axis
            result = self._convolve_axis(result, kernel, axis)

        return result

    def _uniform_filter(
        self,
        x: np.ndarray,
        filter_size: Tuple[int, ...]
    ) -> np.ndarray:
        """
        Apply uniform (box) filter.
        """
        try:
            from scipy.ndimage import uniform_filter
            return uniform_filter(x, size=filter_size, mode='reflect')
        except ImportError:
            # Fallback to manual implementation
            return self._gaussian_filter(x, filter_size)

    def _convolve_axis(
        self,
        x: np.ndarray,
        kernel: np.ndarray,
        axis: int
    ) -> np.ndarray:
        """
        Convolve array with 1D kernel along specified axis.
        """
        # Move target axis to last position
        x_moved = np.moveaxis(x, axis, -1)
        original_shape = x_moved.shape

        # Reshape to 2D for convolution
        x_flat = x_moved.reshape(-1, x_moved.shape[-1])

        # Convolve each row
        pad_width = len(kernel) // 2
        result = np.zeros_like(x_flat)

        for i in range(x_flat.shape[0]):
            padded = np.pad(x_flat[i], pad_width, mode='reflect')
            result[i] = np.convolve(padded, kernel, mode='valid')

        # Reshape back
        result = result.reshape(original_shape)
        return np.moveaxis(result, -1, axis)

    def _adapt_filter_size(
        self,
        base_size: Tuple[int, ...],
        imf_index: int,
        signal_shape: Tuple[int, ...]
    ) -> Tuple[int, ...]:
        """
        Adapt filter size for each IMF level.

        Higher IMF indices (lower frequencies) use larger filters.
        """
        scale = 1.0 + 0.2 * imf_index

        adapted = []
        for s, dim_size in zip(base_size, signal_shape):
            new_size = int(s * scale)
            # Ensure odd size and within bounds
            new_size = min(new_size, dim_size // 3)
            new_size = max(3, new_size)
            if new_size % 2 == 0:
                new_size += 1
            adapted.append(new_size)

        return tuple(adapted)


# =============================================================================
# Convenience Functions
# =============================================================================

def mdfif_decompose(
    x: np.ndarray,
    num_imfs: int = 8,
    filter_size: int = 5
) -> List[np.ndarray]:
    """
    Decompose multidimensional signal into IMFs.

    Parameters
    ----------
    x : np.ndarray
        Input signal (any dimensionality)
    num_imfs : int
        Maximum IMFs
    filter_size : int
        Filter size (same for all dimensions)

    Returns
    -------
    List[np.ndarray]
        IMFs from high to low frequency
    """
    mdfif = MultidimensionalFIF(
        num_imfs=num_imfs,
        filter_size=filter_size
    )
    return mdfif.decompose(x)


def image_decompose(
    image: np.ndarray,
    num_imfs: int = 6
) -> List[np.ndarray]:
    """
    Decompose 2D image into IMFs.

    Parameters
    ----------
    image : np.ndarray
        2D image array
    num_imfs : int
        Number of IMFs

    Returns
    -------
    List[np.ndarray]
        Image IMFs (texture scales)
    """
    mdfif = MultidimensionalFIF(
        num_imfs=num_imfs,
        filter_size=(5, 5),
        filter_type='gaussian'
    )
    return mdfif.decompose(image)


def denoise_image(
    image: np.ndarray,
    levels_to_remove: int = 2
) -> np.ndarray:
    """
    Denoise image by removing high-frequency IMFs.

    Parameters
    ----------
    image : np.ndarray
        Noisy image
    levels_to_remove : int
        Number of high-freq IMFs to remove

    Returns
    -------
    np.ndarray
        Denoised image
    """
    imfs = image_decompose(image, num_imfs=levels_to_remove + 3)
    return sum(imfs[levels_to_remove:])
