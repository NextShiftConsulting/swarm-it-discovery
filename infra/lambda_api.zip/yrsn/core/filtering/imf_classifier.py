"""
IMF to YRSN Classifier
======================

Classifies Intrinsic Mode Functions (IMFs) from FIF decomposition
into YRSN components:

- R (Relevant): Low-frequency IMFs containing main structure/trends
- S (Superfluous): Mid-frequency IMFs with contextual oscillations
- N (Noise): High-frequency IMFs with fast fluctuations/noise

Classification methods:
- frequency: Based on characteristic frequency of each IMF
- energy: Based on energy content (high energy → R)
- adaptive: Quality-aware classification using α parameter

Usage:
    from yrsn.core.filtering import FastIterativeFiltering, IMFYRSNClassifier

    fif = FastIterativeFiltering()
    imfs = fif.decompose(signal)

    classifier = IMFYRSNClassifier(method='frequency')
    result = classifier.classify(imfs)

    R, S, N = result.to_yrsn()  # Get YRSN ratios
"""

import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum


class ClassificationMethod(Enum):
    """Available classification methods."""
    FREQUENCY = 'frequency'
    ENERGY = 'energy'
    ADAPTIVE = 'adaptive'


@dataclass
class YRSNComponents:
    """
    YRSN components from IMF classification.

    Attributes
    ----------
    R : np.ndarray
        Relevant component (sum of low-frequency IMFs)
    S : np.ndarray
        Superfluous component (sum of mid-frequency IMFs)
    N : np.ndarray
        Noise component (sum of high-frequency IMFs)
    imf_assignments : List[str]
        Which component each IMF was assigned to
    frequencies : List[float]
        Estimated frequency of each IMF
    energies : List[float]
        Energy of each IMF
    """
    R: np.ndarray
    S: np.ndarray
    N: np.ndarray
    imf_assignments: List[str]
    frequencies: List[float]
    energies: List[float]

    def to_yrsn(self) -> Tuple[float, float, float]:
        """
        Convert to YRSN ratios based on energy.

        Returns
        -------
        tuple of (R, S, N)
            Where R + S + N = 1.0
        """
        r_energy = np.sum(self.R ** 2)
        s_energy = np.sum(self.S ** 2)
        n_energy = np.sum(self.N ** 2)

        total = r_energy + s_energy + n_energy
        if total == 0:
            return (0.33, 0.33, 0.34)

        return (
            r_energy / total,
            s_energy / total,
            n_energy / total
        )

    def reconstruct(self) -> np.ndarray:
        """Reconstruct original signal."""
        return self.R + self.S + self.N

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        R, S, N = self.to_yrsn()
        return {
            'yrsn_ratios': {'R': R, 'S': S, 'N': N},
            'imf_assignments': self.imf_assignments,
            'num_imfs': len(self.imf_assignments),
            'frequencies': self.frequencies,
            'energies': self.energies
        }


class IMFYRSNClassifier:
    """
    Classify IMFs into YRSN components.

    Uses frequency content, energy distribution, or adaptive
    quality-based classification to assign IMFs to R, S, or N.

    Parameters
    ----------
    method : str
        Classification method:
        - 'frequency': Based on IMF frequencies (default)
        - 'energy': Based on IMF energies
        - 'adaptive': Quality-aware using α parameter
    r_fraction : float
        Default fraction of IMFs assigned to R (default 0.5)
    n_fraction : float
        Default fraction of IMFs assigned to N (default 0.2)

    Examples
    --------
    >>> classifier = IMFYRSNClassifier(method='frequency')
    >>> result = classifier.classify(imfs, quality_hint=0.6)
    >>> R, S, N = result.to_yrsn()
    """

    def __init__(
        self,
        method: str = 'frequency',
        r_fraction: float = 0.5,
        n_fraction: float = 0.2
    ):
        self.method = ClassificationMethod(method)
        self.r_fraction = r_fraction
        self.n_fraction = n_fraction

    def classify(
        self,
        imfs: List[np.ndarray],
        quality_hint: Optional[float] = None
    ) -> YRSNComponents:
        """
        Classify IMFs into R, S, N components.

        Parameters
        ----------
        imfs : List[np.ndarray]
            IMFs from FIF decomposition (high to low frequency)
        quality_hint : float, optional
            Expected quality α ∈ [0, 1] for adaptive classification.
            Higher α → more IMFs assigned to R.

        Returns
        -------
        YRSNComponents
            Contains R, S, N arrays and diagnostics
        """
        if not imfs:
            raise ValueError("Empty IMF list")

        # Handle different shapes (1D, 2D multivariate, etc.)
        imfs = [np.asarray(imf) for imf in imfs]
        n = len(imfs)

        # Compute frequencies and energies
        frequencies = [self._estimate_frequency(imf) for imf in imfs]
        energies = [np.sum(imf ** 2) for imf in imfs]

        # Get classification based on method
        if self.method == ClassificationMethod.FREQUENCY:
            assignments = self._classify_by_frequency(
                imfs, frequencies, quality_hint
            )
        elif self.method == ClassificationMethod.ENERGY:
            assignments = self._classify_by_energy(
                imfs, energies, quality_hint
            )
        else:  # ADAPTIVE
            assignments = self._classify_adaptive(
                imfs, frequencies, energies, quality_hint
            )

        # Aggregate components
        R = self._aggregate_imfs(imfs, assignments, 'R')
        S = self._aggregate_imfs(imfs, assignments, 'S')
        N = self._aggregate_imfs(imfs, assignments, 'N')

        return YRSNComponents(
            R=R,
            S=S,
            N=N,
            imf_assignments=assignments,
            frequencies=frequencies,
            energies=energies
        )

    def _classify_by_frequency(
        self,
        imfs: List[np.ndarray],
        frequencies: List[float],
        quality_hint: Optional[float]
    ) -> List[str]:
        """
        Classify by frequency content.

        IMFs are ordered by FIF from high to low frequency.
        - Highest frequency → N (noise)
        - Middle frequency → S (superfluous)
        - Lowest frequency → R (relevant)
        """
        n = len(imfs)
        alpha = quality_hint if quality_hint is not None else self.r_fraction

        # Determine split points
        n_count = max(1, int(n * self.n_fraction))
        r_count = max(1, int(n * alpha))
        s_count = n - r_count - n_count

        if s_count < 0:
            # Adjust if we don't have enough IMFs
            s_count = 0
            r_count = n - n_count

        # Sort indices by frequency (high to low)
        sorted_idx = np.argsort(frequencies)[::-1]

        assignments = ['S'] * n  # Default

        # Assign based on sorted order
        for i, idx in enumerate(sorted_idx):
            if i < n_count:
                assignments[idx] = 'N'  # Highest freq
            elif i >= n - r_count:
                assignments[idx] = 'R'  # Lowest freq
            else:
                assignments[idx] = 'S'  # Middle

        return assignments

    def _classify_by_energy(
        self,
        imfs: List[np.ndarray],
        energies: List[float],
        quality_hint: Optional[float]
    ) -> List[str]:
        """
        Classify by energy content.

        High energy → R (main content)
        Low energy → N (noise)
        Medium energy → S (superfluous)
        """
        n = len(imfs)
        total_energy = sum(energies)

        if total_energy == 0:
            return ['S'] * n

        alpha = quality_hint if quality_hint is not None else self.r_fraction
        r_energy_target = total_energy * alpha
        n_energy_threshold = total_energy * 0.05  # 5% threshold for noise

        # Sort by energy (high to low)
        sorted_idx = np.argsort(energies)[::-1]

        assignments = ['S'] * n
        r_energy = 0

        for idx in sorted_idx:
            if r_energy < r_energy_target:
                assignments[idx] = 'R'
                r_energy += energies[idx]
            elif energies[idx] < n_energy_threshold:
                assignments[idx] = 'N'
            else:
                assignments[idx] = 'S'

        return assignments

    def _classify_adaptive(
        self,
        imfs: List[np.ndarray],
        frequencies: List[float],
        energies: List[float],
        quality_hint: Optional[float]
    ) -> List[str]:
        """
        Adaptive classification combining frequency and energy.

        Uses quality_hint to balance between frequency-based
        and energy-based classification.
        """
        n = len(imfs)
        alpha = quality_hint if quality_hint is not None else 0.5

        # Get both classifications
        freq_assignments = self._classify_by_frequency(
            imfs, frequencies, alpha
        )
        energy_assignments = self._classify_by_energy(
            imfs, energies, alpha
        )

        # Combine: use majority vote with frequency tie-breaker
        assignments = []
        for i in range(n):
            if freq_assignments[i] == energy_assignments[i]:
                assignments.append(freq_assignments[i])
            else:
                # Disagreement: weight by confidence
                # High quality → trust energy more
                # Low quality → trust frequency more
                if alpha > 0.6:
                    assignments.append(energy_assignments[i])
                else:
                    assignments.append(freq_assignments[i])

        return assignments

    def _aggregate_imfs(
        self,
        imfs: List[np.ndarray],
        assignments: List[str],
        component: str
    ) -> np.ndarray:
        """
        Aggregate IMFs assigned to a component.
        """
        selected = [
            imf for imf, a in zip(imfs, assignments)
            if a == component
        ]

        if not selected:
            return np.zeros_like(imfs[0])

        return sum(selected)

    @staticmethod
    def _estimate_frequency(x: np.ndarray) -> float:
        """
        Estimate characteristic frequency via zero-crossing rate.

        For multidimensional arrays, uses the flattened signal.
        """
        x_flat = np.asarray(x).flatten()

        if len(x_flat) < 2:
            return 0.0

        # Count zero crossings
        signs = np.sign(x_flat)
        # Handle zeros in signs
        signs[signs == 0] = 1
        zero_crossings = np.sum(np.abs(np.diff(signs)) > 0)

        return zero_crossings / (2 * len(x_flat))


# =============================================================================
# Convenience Functions
# =============================================================================

def classify_imfs_to_yrsn(
    imfs: List[np.ndarray],
    method: str = 'frequency',
    quality_hint: Optional[float] = None
) -> YRSNComponents:
    """
    Classify IMFs into YRSN components.

    Convenience wrapper around IMFYRSNClassifier.

    Parameters
    ----------
    imfs : List[np.ndarray]
        IMFs from FIF decomposition
    method : str
        'frequency', 'energy', or 'adaptive'
    quality_hint : float, optional
        Expected quality α for guidance

    Returns
    -------
    YRSNComponents
        Contains R, S, N and to_yrsn() method
    """
    classifier = IMFYRSNClassifier(method=method)
    return classifier.classify(imfs, quality_hint=quality_hint)


def imfs_to_yrsn_ratios(
    imfs: List[np.ndarray],
    method: str = 'frequency',
    quality_hint: Optional[float] = None
) -> Tuple[float, float, float]:
    """
    Get YRSN ratios directly from IMFs.

    Parameters
    ----------
    imfs : List[np.ndarray]
        IMFs from FIF decomposition
    method : str
        Classification method
    quality_hint : float, optional
        Expected quality

    Returns
    -------
    tuple of (R, S, N)
        YRSN ratios
    """
    result = classify_imfs_to_yrsn(imfs, method, quality_hint)
    return result.to_yrsn()
