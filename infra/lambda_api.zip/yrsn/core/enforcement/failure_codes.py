"""
YRSN Failure Code System - RIGOR Enforcement Layer

Defines standardized failure codes for the Context Integrity ISA:
- E1xx: Topology failures (Hard Gates) - H₁ Betti number violations
- E2xx: Drift failures (Soft Gates) - T⁴ chordal distance thresholds
- E3xx: Invariant failures (Constraint Violations) - Simplex/phasor violations
- E4xx: Certificate Structure (CQC Compliance) - Missing required fields
- E5xx: Certificate Integrity (CQC Compliance) - Mutation/tampering detection

These codes integrate with the Dimensional Gearbox to trigger appropriate
gear shifts (downshift, reverse, neutral) based on failure severity.

CQC Error codes (E4xx, E5xx) enforce Certificate as Port architecture
(ISA v0.2 §0) and protect the patent moat by ensuring certificates are
self-contained boundary objects.

Reference:
    docs/CIP_03_PLATFORM_ARCHITECTURE.md
    src/yrsn/core/monitoring/drift_monitor.py (DriftPhase integration)
    docs/principles/CQC_COMPLIANCE_CHECKLIST.md (Certificate architecture)
    docs/api/specifications/CONTEXT_QUALITY_ISA_v0.2.md (ISA §0)
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Optional, Dict, Any


class FailureCategory(Enum):
    """Failure code categories."""
    TOPOLOGY = 100      # E1xx: Hard gates (H₁ Betti violations)
    DRIFT = 200         # E2xx: Soft gates (T⁴ distance thresholds)
    INVARIANT = 300     # E3xx: Constraint violations
    CERTIFICATE = 400   # E4xx: Certificate structure (CQC compliance)
    INTEGRITY = 500     # E5xx: Certificate integrity (CQC compliance)
    METHODOLOGY = 600   # E6xx: Experimental methodology violations (P11 compliance)


class FailureCode(Enum):
    """
    Standardized failure codes for RIGOR enforcement.

    Category 100 (Topology): Hard gates requiring REVERSE gear
    Category 200 (Drift): Soft gates triggering downshift
    Category 300 (Invariant): Constraint violations requiring recalibration
    Category 400 (Certificate): Certificate structure violations (CQC)
    Category 500 (Integrity): Certificate integrity violations (CQC)
    """

    # =========================================================================
    # Category 100: Topology (Hard Gates)
    # Trigger: H₁ Betti number validation fails
    # Action: Shift to REVERSE gear, block inference
    # =========================================================================

    E101 = 101  # BETTI_COLLAPSE: H₁ < 4 loops detected
    E102 = 102  # BETTI_OVERFLOW: H₁ > 4 (noise artifacts)
    E103 = 103  # DISCONTINUITY: Empty/null input, manifold torn

    # =========================================================================
    # Category 200: Drift (Soft Gates)
    # Trigger: T⁴ chordal distance exceeds thresholds
    # Action: Downshift to exploration gear or block
    # =========================================================================

    E201 = 201  # PHASE_SLIP: d ∈ [0.2, 0.5) - JITTER phase
    E202 = 202  # DRIFT_WARNING: d ∈ [0.5, 1.0) - DRIFT start
    E203 = 203  # DRIFT_CRITICAL: d ∈ [1.0, 1.5) - DRIFT severe
    E204 = 204  # TORUS_BREAK: d ≥ 1.5 - COLLAPSE phase

    # =========================================================================
    # Category 300: Invariant (Constraint Violations)
    # Trigger: Fundamental constraints violated
    # Action: Recalibrate, downshift to stable gear
    # =========================================================================

    E301 = 301  # SIMPLEX_VIOLATION: R+S+N ≠ 1.0 (tolerance > 1e-6)
    E302 = 302  # PHASOR_CONFLICT: Coherence < 0.3 (source disagreement)
    E303 = 303  # CALIBRATION_DRIFT: |confidence - R| > 0.3

    # =========================================================================
    # Category 400: Certificate Structure (CQC Compliance)
    # Trigger: Certificate missing required context fields
    # Action: REJECT certificate at port boundary
    # Reference: ISA v0.2 §0 (Certificate as Port)
    # =========================================================================

    E401 = 401  # CERT_MISSING_CONTEXT: 'context' field not in certificate
    E402 = 402  # CERT_MISSING_DOMAIN: 'domain' not in certificate.context
    E403 = 403  # CERT_MISSING_INV_SPEC_HASH: 'inv_spec_hash' not in context
    E404 = 404  # CERT_MISSING_INV_SPEC_BLOB: 'inv_spec_blob' not in context
    E405 = 405  # CERT_MISSING_BASELINE_ID: 'baseline_id' not in context
    E406 = 406  # CERT_MISSING_SCHEMA_VERSION: 'schema_version' not in context

    # =========================================================================
    # Category 500: Certificate Integrity (CQC Compliance)
    # Trigger: Certificate mutation or cryptographic verification failure
    # Action: REJECT certificate, log security event
    # Reference: ISA v0.2 §0.9 (Cryptographic Finality)
    # =========================================================================

    E501 = 501  # CERT_MUTATION_DETECTED: Certificate hash changed post-mint
    E503 = 503  # CERT_HASH_MISMATCH: Stored hash ≠ computed hash
    E411 = 411  # CERT_INV_HASH_MISMATCH: inv_spec_hash ≠ hash(inv_spec_blob)

    # =========================================================================
    # Extended Category 200: Baseline Errors
    # Trigger: Baseline retrieval or compatibility failures
    # Action: REJECT comparison, require compatible baseline
    # =========================================================================

    E205 = 205  # BASELINE_NOT_FOUND: baseline_id does not exist
    E206 = 206  # BASELINE_INCOMPATIBLE_DOMAIN: inv_spec_hash mismatch (E_BASE_DOMAIN_MISMATCH)

    # =========================================================================
    # Category 600: Methodology (Experimental Rigor - P11)
    # Trigger: Experiment execution violates DOE specification
    # Action: WARN researcher, invalidate evidence
    # Reference: FIRST_PRINCIPLES.md §P11 (Experimental Rigor)
    # =========================================================================

    E601 = 601  # REFIT_VIOLATION: projection.fit() called wrong number of times
    E602 = 602  # REFERENCE_DRIFT: reference embeddings changed unexpectedly
    E603 = 603  # DOE_MISMATCH: execution doesn't match DOE specification

    @property
    def category(self) -> FailureCategory:
        """Get the category for this failure code."""
        code_value = self.value
        if 100 <= code_value < 200:
            return FailureCategory.TOPOLOGY
        elif 200 <= code_value < 300:
            return FailureCategory.DRIFT
        elif 300 <= code_value < 400:
            return FailureCategory.INVARIANT
        elif 400 <= code_value < 500:
            return FailureCategory.CERTIFICATE
        elif 500 <= code_value < 600:
            return FailureCategory.INTEGRITY
        else:
            return FailureCategory.METHODOLOGY

    @property
    def name_short(self) -> str:
        """Short name for logging."""
        names = {
            FailureCode.E101: "BETTI_COLLAPSE",
            FailureCode.E102: "BETTI_OVERFLOW",
            FailureCode.E103: "DISCONTINUITY",
            FailureCode.E201: "PHASE_SLIP",
            FailureCode.E202: "DRIFT_WARNING",
            FailureCode.E203: "DRIFT_CRITICAL",
            FailureCode.E204: "TORUS_BREAK",
            FailureCode.E205: "BASELINE_NOT_FOUND",
            FailureCode.E206: "BASELINE_INCOMPATIBLE_DOMAIN",
            FailureCode.E301: "SIMPLEX_VIOLATION",
            FailureCode.E302: "PHASOR_CONFLICT",
            FailureCode.E303: "CALIBRATION_DRIFT",
            FailureCode.E401: "CERT_MISSING_CONTEXT",
            FailureCode.E402: "CERT_MISSING_DOMAIN",
            FailureCode.E403: "CERT_MISSING_INV_SPEC_HASH",
            FailureCode.E404: "CERT_MISSING_INV_SPEC_BLOB",
            FailureCode.E405: "CERT_MISSING_BASELINE_ID",
            FailureCode.E406: "CERT_MISSING_SCHEMA_VERSION",
            FailureCode.E411: "CERT_INV_HASH_MISMATCH",
            FailureCode.E501: "CERT_MUTATION_DETECTED",
            FailureCode.E503: "CERT_HASH_MISMATCH",
            FailureCode.E601: "REFIT_VIOLATION",
            FailureCode.E602: "REFERENCE_DRIFT",
            FailureCode.E603: "DOE_MISMATCH",
        }
        return names.get(self, "UNKNOWN")

    @property
    def is_hard_gate(self) -> bool:
        """Returns True if this failure requires blocking inference."""
        return self.category == FailureCategory.TOPOLOGY or self == FailureCode.E204


class FailureSeverity(Enum):
    """Severity levels for failure codes."""
    INFO = "info"           # Log only, no action
    WARNING = "warning"     # Log + alert, continue
    ERROR = "error"         # Downshift gear, continue with caution
    CRITICAL = "critical"   # Block inference, shift to REVERSE


class GearboxAction(Enum):
    """Actions the gearbox should take in response to failures."""
    NONE = "none"           # No gear change
    HOLD = "hold"           # Hold current gear, log
    DOWNSHIFT = "downshift" # Shift to lower (more exploratory) gear
    REVERSE = "reverse"     # Shift to REVERSE (recovery mode)
    NEUTRAL = "neutral"     # Block inference entirely


@dataclass
class FailureResponse:
    """Response configuration for a failure code."""
    code: FailureCode
    severity: FailureSeverity
    gearbox_action: GearboxAction
    target_gear: Optional[str]  # "1st", "2nd", "3rd", "4th", "R", None
    message: str
    recommendation: str

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary for logging/serialization."""
        return {
            "code": f"E{self.code.value}",
            "name": self.code.name_short,
            "severity": self.severity.value,
            "action": self.gearbox_action.value,
            "target_gear": self.target_gear,
            "message": self.message,
            "recommendation": self.recommendation,
        }


# =============================================================================
# Failure Response Registry
# =============================================================================

FAILURE_RESPONSES: Dict[FailureCode, FailureResponse] = {
    # Category 100: Topology (Hard Gates)
    FailureCode.E101: FailureResponse(
        code=FailureCode.E101,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.REVERSE,
        target_gear="R",
        message="Topological collapse detected: H₁ < 4 loops",
        recommendation="Shift to REVERSE, explore for stable manifold region",
    ),
    FailureCode.E102: FailureResponse(
        code=FailureCode.E102,
        severity=FailureSeverity.ERROR,
        gearbox_action=GearboxAction.REVERSE,
        target_gear="R",
        message="Betti overflow detected: H₁ > 4 (noise artifacts)",
        recommendation="Shift to REVERSE, apply smoothing, revalidate topology",
    ),
    FailureCode.E103: FailureResponse(
        code=FailureCode.E103,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Manifold discontinuity: empty or null input",
        recommendation="Block inference, await valid input",
    ),

    # Category 200: Drift (Soft Gates)
    FailureCode.E201: FailureResponse(
        code=FailureCode.E201,
        severity=FailureSeverity.INFO,
        gearbox_action=GearboxAction.HOLD,
        target_gear=None,
        message="Phase slip detected: d ∈ [0.2, 0.5)",
        recommendation="Log and monitor, apply complex smoothing if persistent",
    ),
    FailureCode.E202: FailureResponse(
        code=FailureCode.E202,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.DOWNSHIFT,
        target_gear="3rd",
        message="Drift warning: d ∈ [0.5, 1.0)",
        recommendation="Downshift to 3rd gear (Explore), alert operator",
    ),
    FailureCode.E203: FailureResponse(
        code=FailureCode.E203,
        severity=FailureSeverity.ERROR,
        gearbox_action=GearboxAction.DOWNSHIFT,
        target_gear="3rd",
        message="Critical drift: d ∈ [1.0, 1.5)",
        recommendation="Downshift to 3rd gear (Explore), consider re-sync to baseline",
    ),
    FailureCode.E204: FailureResponse(
        code=FailureCode.E204,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Torus break: d ≥ 1.5 (COLLAPSE phase)",
        recommendation="Block inference, revert to last stable checkpoint",
    ),

    # Category 300: Invariant (Constraint Violations)
    FailureCode.E301: FailureResponse(
        code=FailureCode.E301,
        severity=FailureSeverity.ERROR,
        gearbox_action=GearboxAction.DOWNSHIFT,
        target_gear="2nd",
        message="Simplex violation: R+S+N ≠ 1.0",
        recommendation="Project to simplex, recalibrate decomposition",
    ),
    FailureCode.E302: FailureResponse(
        code=FailureCode.E302,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.DOWNSHIFT,
        target_gear="3rd",
        message="Phasor conflict: coherence < 0.3",
        recommendation="Sources disagree, increase exploration to resolve",
    ),
    FailureCode.E303: FailureResponse(
        code=FailureCode.E303,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.HOLD,
        target_gear=None,
        message="Calibration drift: |confidence - R| > 0.3",
        recommendation="Monitor confidence-R divergence, recalibrate if persistent",
    ),

    # Category 200 Extended: Baseline Errors
    FailureCode.E205: FailureResponse(
        code=FailureCode.E205,
        severity=FailureSeverity.ERROR,
        gearbox_action=GearboxAction.HOLD,
        target_gear=None,
        message="Baseline not found: baseline_id does not exist",
        recommendation="Verify baseline_id, create baseline if missing",
    ),
    FailureCode.E206: FailureResponse(
        code=FailureCode.E206,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Baseline incompatible: inv_spec_hash mismatch (domain mismatch)",
        recommendation="Cannot compare certificates from different domains, use matching baseline",
    ),

    # Category 400: Certificate Structure (CQC Compliance)
    FailureCode.E401: FailureResponse(
        code=FailureCode.E401,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate missing 'context' field",
        recommendation="Reject certificate at port boundary, require CQC-compliant certificate",
    ),
    FailureCode.E402: FailureResponse(
        code=FailureCode.E402,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate missing 'domain' in context",
        recommendation="Reject certificate, domain is required for validation",
    ),
    FailureCode.E403: FailureResponse(
        code=FailureCode.E403,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate missing 'inv_spec_hash' in context",
        recommendation="Reject certificate, invariant hash required for integrity",
    ),
    FailureCode.E404: FailureResponse(
        code=FailureCode.E404,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate missing 'inv_spec_blob' in context",
        recommendation="Reject certificate, invariant spec required for self-contained validation",
    ),
    FailureCode.E405: FailureResponse(
        code=FailureCode.E405,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.HOLD,
        target_gear=None,
        message="Certificate missing 'baseline_id' in context",
        recommendation="Certificate valid but cannot track drift without baseline reference",
    ),
    FailureCode.E406: FailureResponse(
        code=FailureCode.E406,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate missing 'schema_version' in context",
        recommendation="Reject certificate, schema version required for compatibility",
    ),

    # Category 500: Certificate Integrity (CQC Compliance)
    FailureCode.E411: FailureResponse(
        code=FailureCode.E411,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate inv_spec_hash mismatch: hash(inv_spec_blob) ≠ inv_spec_hash",
        recommendation="Reject certificate, invariant spec has been tampered with",
    ),
    FailureCode.E501: FailureResponse(
        code=FailureCode.E501,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate mutation detected: certificate hash changed post-mint",
        recommendation="Reject certificate, log security event, investigate tampering",
    ),
    FailureCode.E503: FailureResponse(
        code=FailureCode.E503,
        severity=FailureSeverity.CRITICAL,
        gearbox_action=GearboxAction.NEUTRAL,
        target_gear=None,
        message="Certificate hash mismatch: stored hash ≠ computed hash",
        recommendation="Reject certificate, cryptographic verification failed",
    ),

    # Category 600: Methodology (Experimental Rigor - P11)
    FailureCode.E601: FailureResponse(
        code=FailureCode.E601,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.NONE,
        target_gear=None,
        message="Projection fit methodology violation: fit() called incorrect number of times",
        recommendation="Fix experiment to match DOE specification, re-run experiment",
    ),
    FailureCode.E602: FailureResponse(
        code=FailureCode.E602,
        severity=FailureSeverity.WARNING,
        gearbox_action=GearboxAction.NONE,
        target_gear=None,
        message="Reference embeddings changed unexpectedly during experiment",
        recommendation="Ensure reference is fixed, check for accidental re-fit calls",
    ),
    FailureCode.E603: FailureResponse(
        code=FailureCode.E603,
        severity=FailureSeverity.ERROR,
        gearbox_action=GearboxAction.NONE,
        target_gear=None,
        message="Experiment execution does not match DOE specification",
        recommendation="Review DOE, fix experiment methodology, re-run",
    ),
}


def get_failure_response(code: FailureCode) -> FailureResponse:
    """
    Get the configured response for a failure code.

    Args:
        code: The failure code

    Returns:
        FailureResponse with severity, action, and recommendations
    """
    return FAILURE_RESPONSES[code]


def classify_drift_failure(distance: float) -> Optional[FailureCode]:
    """
    Classify a T⁴ chordal distance into the appropriate drift failure code.

    Args:
        distance: T⁴ chordal distance from baseline

    Returns:
        FailureCode or None if distance is nominal (< 0.2)

    Reference:
        DriftThresholds in src/yrsn/core/monitoring/drift_monitor.py
    """
    if distance < 0.2:
        return None  # NOMINAL - no failure
    elif distance < 0.5:
        return FailureCode.E201  # PHASE_SLIP (JITTER)
    elif distance < 1.0:
        return FailureCode.E202  # DRIFT_WARNING
    elif distance < 1.5:
        return FailureCode.E203  # DRIFT_CRITICAL
    else:
        return FailureCode.E204  # TORUS_BREAK (COLLAPSE)


def classify_betti_failure(h1_count: int) -> Optional[FailureCode]:
    """
    Classify H₁ Betti number into topology failure code.

    Args:
        h1_count: Number of significant H₁ loops detected

    Returns:
        FailureCode or None if h1_count == 4 (valid T⁴)

    Note:
        T⁴ = S¹ × S¹ × S¹ × S¹ should have exactly 4 H₁ generators.
    """
    if h1_count == 0:
        return FailureCode.E103  # DISCONTINUITY
    elif h1_count < 4:
        return FailureCode.E101  # BETTI_COLLAPSE
    elif h1_count > 4:
        return FailureCode.E102  # BETTI_OVERFLOW
    else:
        return None  # Valid T⁴ topology


__all__ = [
    "FailureCategory",
    "FailureCode",
    "FailureSeverity",
    "GearboxAction",
    "FailureResponse",
    "FAILURE_RESPONSES",
    "get_failure_response",
    "classify_drift_failure",
    "classify_betti_failure",
]
