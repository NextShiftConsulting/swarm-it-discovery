"""
YRSN Unified Enforcement Engine - ONE Canonical Enforcement Pipeline

Consolidates EnforcementEngine + UnifiedQualityController into a single engine.
Resolves "The incidence of misunderstanding is too great to have separate enforcements."

ARCHITECTURE:
  - 14-step unified pipeline (monitoring → decision → stability)
  - Canonical YRSNCertificate (enhanced with P14/P16)
  - Layer orthogonality: Layer 2 (κ) ⊥ Layer 4 (V̇)
  - Defense integration at Step 10
  - ABL-15: κ integration via RSCTController

PIPELINE:
  MONITORING (Steps 1-6):
    1. Simplex constraint (R+S+N=1) → E301 if fail
    2. P16 hash integrity → REVERSE_GATE if hash_valid=False
    3. Certificate verification → REJECT if verify() fails
    4. Phasor coherence → E302 advisory
    5. Drift monitoring → E201-E204 (E204 blocks)
    6. Topology validation → E101-E103 (blocks on E103)

  DECISION (Steps 7-12):
    7. σ instability override → SUPPRESS if σ ≥ 0.7
    7.5. κ compatibility check → RE_ENCODE if κ < 0.3 (ABL-15)
    8. N poisoning override → SUPPRESS if N ≥ 0.5
    9. Collapse risk override → REJECT if collapse_risk ≥ 0.8
    10. Defense layer overrides → Sybil/Goal/Rate/Pressure priority
    11. Grid selection → α×κ (if kappa) or α×ω (fallback)
    12. Gear from τ → P14 tau_to_gear(), ALWAYS τ-driven

  STABILITY (Step 13):
    13. Lyapunov monitoring → V, V̇, is_stable (ADVISORY ONLY, Layer 4)

P14/P16 COMPLIANCE:
  - Canonical α_ω = α × ω + prior × (1 - ω)
  - τ = 1 / α_ω (collapse prevention via prior)
  - Gear states: 1st, 2nd, 3rd, 4th, R (τ-driven thresholds)
  - P16 hash integrity with REVERSE_GATE
  - Defense bridge integration

Created: 2026-02-15 (UnifiedEnforcementEngine Implementation Plan)
Author: Rudolph A. Martin, Next Shift Consulting LLC
License: Proprietary
"""

from __future__ import annotations

import time
import logging
from typing import Optional
import math
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple

import numpy as np

from yrsn.core.certificate import YRSNCertificate
from yrsn.core.gearbox import Gear, DrivingMode, QualitySignals
from yrsn.ports.gearbox import IGearbox, EnforcementResult
from yrsn.core.monitoring.drift_monitor import DriftMonitor, DriftPhase, DriftThresholds
from yrsn.core.enforcement.failure_codes import (
    FailureCode,
    FailureResponse,
    get_failure_response,
    classify_drift_failure,
    classify_betti_failure,
    GearboxAction,
)
from yrsn.core.enforcement.supervisory_controller import (
    SupervisoryController,
    PolicyDecision,
    ControlAction as GridControlAction,
)

logger = logging.getLogger(__name__)


# =============================================================================
# §1  DEGRADATION TAXONOMY (Merged from UQC)
# =============================================================================

class DegradationType(Enum):
    """
    Typed degradation states from simplex geometry + P14/P16 compliance.
    Maps to actionable control responses.
    """
    HEALTHY = auto()              # High α_ω — proceed normally
    DISTRACTION = auto()          # High S — filter superfluous context
    DRIFT = auto()                # Low ω, moderate α — domain shift
    POISONING = auto()            # High N — adversarial / corruption
    HALLUCINATION = auto()        # High α, low ω — confident but unreliable
    COLLAPSE = auto()             # Very low α — reject, request reformulation
    INSTABILITY = auto()          # High σ — encoding destabilizes solver
    INCOMPATIBLE = auto()         # Low κ — representation doesn't match solver
    UNRELIABLE = auto()           # Low ω — can't trust derived signals
    DEGRADED_COMPATIBLE = auto()  # Low α but high κ — fixable via re-encoding
    INTEGRITY_VIOLATION = auto()  # P16 hash mismatch — REVERSE_GATE
    # Defense-layer degradation types
    GOAL_DRIFT = auto()           # Goal anchor integrity violation
    SYBIL_ATTACK = auto()         # Agent fingerprint clustering detected
    RATE_LIMITED = auto()         # Token bucket backpressure triggered


class ControlAction(Enum):
    """System-level responses to degradation states."""
    PROCEED = auto()           # Execute normally
    PROCEED_CAUTIOUS = auto()  # Execute with elevated monitoring
    FILTER_CONTEXT = auto()    # Prune superfluous content, re-certify
    RECALIBRATE = auto()       # Switch model or recalibrate for domain
    RE_ENCODE = auto()         # Transform representation for better κ
    GATE_ADAPTATION = auto()   # Freeze or slow learning rate
    DEFER_HUMAN = auto()       # Require human verification
    SUPPRESS = auto()          # Block execution, trigger security review
    REJECT = auto()            # Reject input entirely
    REVERSE_GATE = auto()      # P16: hash integrity failure


class GearState(Enum):
    """
    P14/P16 gear states (τ-driven thresholds).

    Gear   τ Range        Semantics
    ────   ──────────     ─────────────────────────────────
    1st    [0, 1.0)       Full autonomy — high-quality context
    2nd    [1.0, 1.43)    Normal operation — adequate quality
    3rd    [1.43, 2.5)    Caution — degraded quality, monitor
    4th    [2.5, ∞)       Maximum restriction — poor quality
    R      hash fail      Reverse gate — integrity violation
    """
    FIRST = 1     # τ ∈ [0, 1.0)
    SECOND = 2    # τ ∈ [1.0, 1.43)
    THIRD = 3     # τ ∈ [1.43, 2.5)
    FOURTH = 4    # τ ∈ [2.5, ∞)
    REVERSE = -1  # P16 hash fail


# P14 τ → Gear mapping thresholds
_TAU_GEAR_THRESHOLDS: List[Tuple[float, GearState]] = [
    (1.0,   GearState.FIRST),
    (1.43,  GearState.SECOND),
    (2.5,   GearState.THIRD),
    (float('inf'), GearState.FOURTH),
]


def tau_to_gear(tau: float) -> GearState:
    """Map τ value to gear state per P14 thresholds."""
    for threshold, gear in _TAU_GEAR_THRESHOLDS:
        if tau < threshold:
            return gear
    return GearState.FOURTH


# =============================================================================
# §2  CONTROL DECISION (P1 Compliant — data only)
# =============================================================================

@dataclass(frozen=True)
class ControlDecision:
    """Immutable record of a unified control decision."""
    degradation: DegradationType
    action: ControlAction
    gear: GearState
    tau: float
    alpha_omega: float
    grid_used: str               # "alpha_kappa", "alpha_omega", or "none"
    rationale: str
    overrides_applied: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "degradation": self.degradation.name,
            "action": self.action.name,
            "gear": self.gear.name,
            "gear_value": self.gear.value,
            "tau": round(self.tau, 4),
            "alpha_omega": round(self.alpha_omega, 4),
            "grid_used": self.grid_used,
            "rationale": self.rationale,
            "overrides": self.overrides_applied,
        }


# =============================================================================
# §3  DUAL 9-STATE GRIDS (α×κ and α×ω)
# =============================================================================

GridEntry = Tuple[DegradationType, ControlAction]

# GRID A: α × κ (when κ available from RSCT solver)
_GRID_ALPHA_KAPPA: Dict[Tuple[str, str], GridEntry] = {
    # α HIGH
    ("HIGH", "HIGH"):       (DegradationType.HEALTHY,              ControlAction.PROCEED),
    ("HIGH", "MODERATE"):   (DegradationType.HEALTHY,              ControlAction.PROCEED_CAUTIOUS),
    ("HIGH", "LOW"):        (DegradationType.INCOMPATIBLE,         ControlAction.RE_ENCODE),
    # α MODERATE
    ("MODERATE", "HIGH"):     (DegradationType.DISTRACTION,        ControlAction.FILTER_CONTEXT),
    ("MODERATE", "MODERATE"): (DegradationType.DRIFT,              ControlAction.PROCEED_CAUTIOUS),
    ("MODERATE", "LOW"):      (DegradationType.INCOMPATIBLE,       ControlAction.RE_ENCODE),
    # α LOW
    ("LOW", "HIGH"):       (DegradationType.DEGRADED_COMPATIBLE,   ControlAction.FILTER_CONTEXT),
    ("LOW", "MODERATE"):   (DegradationType.COLLAPSE,              ControlAction.DEFER_HUMAN),
    ("LOW", "LOW"):        (DegradationType.COLLAPSE,              ControlAction.REJECT),
}

# GRID B: α × ω (fallback when κ is unavailable)
_GRID_ALPHA_OMEGA: Dict[Tuple[str, str], GridEntry] = {
    # α HIGH
    ("HIGH", "HIGH"):       (DegradationType.HEALTHY,              ControlAction.PROCEED),
    ("HIGH", "MODERATE"):   (DegradationType.HALLUCINATION,        ControlAction.DEFER_HUMAN),
    ("HIGH", "LOW"):        (DegradationType.HALLUCINATION,        ControlAction.SUPPRESS),
    # α MODERATE
    ("MODERATE", "HIGH"):     (DegradationType.DISTRACTION,        ControlAction.FILTER_CONTEXT),
    ("MODERATE", "MODERATE"): (DegradationType.DRIFT,              ControlAction.RECALIBRATE),
    ("MODERATE", "LOW"):      (DegradationType.UNRELIABLE,         ControlAction.GATE_ADAPTATION),
    # α LOW
    ("LOW", "HIGH"):       (DegradationType.COLLAPSE,              ControlAction.DEFER_HUMAN),
    ("LOW", "MODERATE"):   (DegradationType.COLLAPSE,              ControlAction.REJECT),
    ("LOW", "LOW"):        (DegradationType.COLLAPSE,              ControlAction.REJECT),
}


# =============================================================================
# §4  TELEMETRY
# =============================================================================

@dataclass
class UnifiedEnforcementTelemetry:
    """Telemetry data from unified enforcement cycle."""
    # Monitoring (Steps 1-6)
    drift_distance: Optional[float] = None
    drift_phase: Optional[str] = None
    h1_count: Optional[int] = None
    coherence: Optional[float] = None

    # Decision (Steps 7-12)
    grid_used: Optional[str] = None
    degradation: Optional[str] = None
    control_action: Optional[str] = None
    overrides_applied: List[str] = field(default_factory=list)

    # Stability (Step 13)
    lyapunov_V: Optional[float] = None
    lyapunov_V_dot: Optional[float] = None
    lyapunov_stable: Optional[bool] = None
    lyapunov_margin: Optional[float] = None

    # Performance
    cycle_time_ms: float = 0.0


# =============================================================================
# §5  UNIFIED ENFORCEMENT ENGINE
# =============================================================================

class UnifiedEnforcementEngine:
    """
    ONE canonical enforcement engine combining monitoring + decision + stability.

    Replaces:
      - EnforcementEngine (monitoring path)
      - UnifiedQualityController (decision path)

    Pipeline (14 steps):
      1. Simplex constraint
      2. P16 hash integrity
      3. Certificate verification
      4. Phasor coherence
      5. Drift monitoring
      6. Topology validation
      7. σ instability override
      7.5. κ compatibility check (ABL-15) - NEW
      8. N poisoning override
      9. Collapse risk override
      10. Defense layer overrides
      11. Grid selection (α×κ or α×ω)
      12. Gear from τ (P14)
      13. Lyapunov monitoring (advisory)

    Attributes:
        gearbox: Adaptive gearbox for gear shifting
        drift_monitor: T⁴ drift monitoring
        topology_cache: Optional H₁ Betti validation (lazy load)
        enable_topology: Whether to run topology validation
    """

    # Tolerance for simplex constraint validation
    SIMPLEX_TOLERANCE = 1e-6

    # Override thresholds
    SIGMA_CRITICAL_THRESHOLD: float = 0.7
    SIGMA_WARNING_THRESHOLD: float = 0.4
    NOISE_POISONING_THRESHOLD: float = 0.5
    COLLAPSE_RISK_THRESHOLD: float = 0.8

    # Defense thresholds
    DEFENSE_PRESSURE_CRITICAL: float = 0.5
    DEFENSE_PRESSURE_WARNING: float = 0.25

    # κ compatibility thresholds (ABL-15) - DEFAULTS ONLY
    # These are overridden in __init__ to be configurable like other safety barriers
    KAPPA_CRITICAL_THRESHOLD: float = 0.3  # Default: κ < 0.3 → RE_ENCODE
    KAPPA_WARNING_THRESHOLD: float = 0.6   # Default: κ < 0.6 → suboptimal

    # Oobleck dynamic threshold parameters - DEFAULTS ONLY
    OOBLECK_BASE_THRESHOLD: float = 0.50
    OOBLECK_SENSITIVITY: float = 0.4

    # Landauer Tolerance: κ threshold "wiggle room" inspired by memristor physics
    # Creates a gray zone [threshold - tolerance, threshold] where instability (σ) decides
    # Physics analogy: Like energy_barrier in memristors preventing thermal noise updates
    # Reference: Landauer's Principle (kT energy barrier for irreversible computation)
    KAPPA_TOLERANCE: float = 0.05  # Default: ±5% Landauer tolerance zone

    def __init__(
        self,
        driving_mode: DrivingMode = DrivingMode.SPORT,
        enable_topology: bool = False,
        drift_thresholds: Optional[DriftThresholds] = None,
        sigma_critical: float = 0.7,
        noise_poison: float = 0.5,
        collapse_risk: float = 0.8,
        rsct_controller: Optional['RSCTController'] = None,  # ABL-15: κ integration
        # NEW: Configurable κ thresholds and Oobleck parameters
        kappa_critical: float = 0.3,
        kappa_warning: float = 0.6,
        kappa_composition: str = "min",  # "min" (series) or "geometric_mean" (parallel)
        kappa_tolerance: float = 0.05,  # Wiggle room (like memristor energy_barrier)
        oobleck_base: float = 0.50,
        oobleck_sensitivity: float = 0.4,
        # NEW: Multi-dimensional grid (vector-based pattern classification)
        enable_multi_dimensional_grid: bool = False,  # A/B testing flag
        asymmetric_threshold: float = 0.8,  # N > R×0.8 → NOISE_COLLAPSED
        # Hexagonal architecture: dependency injection
        gearbox: Optional[IGearbox] = None,
    ):
        """
        Initialize unified enforcement engine.

        Args:
            driving_mode: Gearbox driving mode
            enable_topology: Enable H₁ Betti validation (requires ripser)
            drift_thresholds: Custom drift thresholds (default: operational envelope)
            sigma_critical: Threshold for σ instability override
            noise_poison: Threshold for N poisoning override
            collapse_risk: Threshold for collapse risk override
            rsct_controller: Optional RSCTController for κ computation (ABL-15)
            kappa_critical: Threshold for κ critical override (static mode)
            kappa_warning: Threshold for κ warning logs
            kappa_composition: How to combine κ components: "min" (series/zero-trust)
                              or "geometric_mean" (parallel/compensatory)
            kappa_tolerance: Wiggle room around thresholds (like memristor energy_barrier)
                            Creates gray zone [threshold-tolerance, threshold] where σ decides
            oobleck_base: Base threshold for Oobleck (when σ=0)
            oobleck_sensitivity: Sensitivity to instability (slope)
            gearbox: Optional gearbox implementation (default: AdaptiveGearbox)
        """
        # Dependency injection with default factory (hexagonal architecture)
        if gearbox is None:
            from yrsn.adapters.gearbox.adaptive import AdaptiveGearbox
            self.gearbox: IGearbox = AdaptiveGearbox(mode=driving_mode)
        else:
            self.gearbox: IGearbox = gearbox
        self.drift_monitor = DriftMonitor(thresholds=drift_thresholds)
        self.enable_topology = enable_topology
        self._topology_cache = None  # Lazy load

        # ABL-15: RSCT κ integration
        self.rsct_controller = rsct_controller
        self.kappa_composition = kappa_composition

        # Multi-dimensional grid (vector-based pattern classification)
        self.enable_multi_dimensional_grid = enable_multi_dimensional_grid
        if enable_multi_dimensional_grid:
            self.supervisory_controller = SupervisoryController(
                asymmetric_threshold=asymmetric_threshold,
                kappa_weak_threshold=kappa_critical,
                sigma_high_threshold=sigma_critical
            )
            logger.info(f"Multi-dimensional grid ENABLED (asymmetric_threshold={asymmetric_threshold})")
        else:
            self.supervisory_controller = None
            logger.info("Multi-dimensional grid DISABLED (using scalar thresholds)")

        # Override thresholds (all configurable)
        self.SIGMA_CRITICAL_THRESHOLD = sigma_critical
        self.NOISE_POISONING_THRESHOLD = noise_poison
        self.COLLAPSE_RISK_THRESHOLD = collapse_risk
        self.KAPPA_CRITICAL_THRESHOLD = kappa_critical
        self.KAPPA_WARNING_THRESHOLD = kappa_warning
        self.KAPPA_TOLERANCE = kappa_tolerance  # Wiggle room
        self.OOBLECK_BASE_THRESHOLD = oobleck_base
        self.OOBLECK_SENSITIVITY = oobleck_sensitivity

        # Metrics
        self._enforcement_count = 0
        self._failure_counts: Dict[str, int] = {}
        self._current_gear = GearState.FIRST
        self._decision_history: List[ControlDecision] = []

        logger.info(
            f"UnifiedEnforcementEngine initialized: "
            f"driving_mode={driving_mode.value}, enable_topology={enable_topology}, "
            f"sigma_crit={sigma_critical}, N_poison={noise_poison}, collapse={collapse_risk}, "
            f"kappa_crit={kappa_critical}±{kappa_tolerance}, kappa_warn={kappa_warning}, "
            f"kappa_comp={kappa_composition}, oobleck=({oobleck_base}+{oobleck_sensitivity}*sigma)"
        )

    # =========================================================================
    # BASELINE MANAGEMENT
    # =========================================================================

    def set_baseline(self, baseline_score) -> None:
        """
        Set the baseline for drift monitoring.

        Args:
            baseline_score: DecompositionScore with T⁴ coordinates
        """
        self.drift_monitor.set_baseline(baseline_score)

    def set_baseline_certificate(self, certificate: YRSNCertificate) -> None:
        """
        Set baseline from a certificate (stores N baseline for drift detection).

        Args:
            certificate: YRSNCertificate to use as baseline
        """
        self._baseline_certificate = certificate

    # =========================================================================
    # MAIN ENFORCEMENT METHOD
    # =========================================================================

    def enforce_certificate(
        self,
        certificate: YRSNCertificate,
        current_score=None,
        t4_coords: Optional[np.ndarray] = None,
        coherence: Optional[float] = None,
    ) -> EnforcementResult:
        """
        Execute unified enforcement policy using a YRSNCertificate.

        This is the PRIMARY method for production use.

        FOUR-LAYER ARCHITECTURE:
        ========================
        Layer 1: RSN (R, S, N) - Content integrity decomposition
        Layer 2: κ (kappa) - Encoding-solver compatibility ⭐ CRITICAL LAYER
        Layer 3: Multimodal (κ_H, κ_L, κ_interface) - Hierarchical κ composition
        Layer 4: Lyapunov (V, V̇) - Trajectory stability verification

        THREE ORTHOGONAL STABILITY CONCEPTS:
        =====================================
        Reference: docs/analysis/Three_Stability_Concepts_Clarification.md

        1. ADMISSIBILITY (E ∈ E_adm) - BLOCKS EXECUTION ✅
           Layers: Layer 1 (RSN: α, N) + Layer 2 (κ, σ) ⭐
           Checks: RSN quality, κ compatibility, σ stability
           Decision: REJECT / RE_ENCODE / ALLOW
           Steps: 7 (σ), 7.5 (κ), 8 (N), 9 (collapse), 10 (defense)
           Type: Forward-looking authorization gate

        2. QUALITY ENVELOPE (§7.10) - DIAGNOSTIC ONLY ❌
           Layers: Layer 1-2
           Checks: Variance, coherence, boundary proximity
           Decision: Classification (informational)
           Steps: Implicit in telemetry
           Type: Diagnostic/informational

        3. LYAPUNOV STABILITY (V̇ ≤ 0) - ADVISORY ONLY ❌
           Layers: Layer 4
           Checks: V, V̇ (chordal distance, derivative)
           Decision: Advisory (never blocks)
           Steps: 13 (Lyapunov verification)
           Type: Backward-looking verification

        Only ADMISSIBILITY gates execution. Quality envelope and Lyapunov inform.
        κ (Layer 2) is THE critical check - encoding MUST match solver!

        14-Step Pipeline:
          MONITORING (1-6): Simplex, hash, verify, coherence, drift, topology
          ADMISSIBILITY (7-12): σ, κ (7.5), N, collapse, defense, grid, gear ✅ BLOCKS
          VERIFICATION (13): Lyapunov (advisory only) ❌ NEVER BLOCKS

        Layer 2 (κ) Integration (ABL-15):
          - Step 7.5: κ < 0.3 → RE_ENCODE (encoding-solver mismatch)
          - Requires rsct_controller in __init__() to populate certificate.kappa

        Args:
            certificate: YRSNCertificate with R, S, N, alpha, omega, tau
            current_score: Optional DecompositionScore with T⁴ coordinates
            t4_coords: Optional T⁴ coordinates [4] if no score
            coherence: Optional phasor coherence [0, 1]

        Returns:
            EnforcementResult with authorization and gear state

        Example:
            cert = YRSNCertificate.from_rsn_dict(rsn_result)
            result = engine.enforce_certificate(cert)
            if result.authorized:
                print(f"Gear: {result.current_gear.value}")
        """
        start_time = time.perf_counter()
        self._enforcement_count += 1

        telemetry = UnifiedEnforcementTelemetry()
        overrides: List[str] = []

        # =====================================================================
        # MONITORING PHASE (Steps 1-6)
        # =====================================================================

        # Step 1: Simplex constraint (R+S+N=1) → E301
        if not self._validate_simplex(certificate.R, certificate.S, certificate.N):
            return self._handle_failure(FailureCode.E301, telemetry, start_time)

        # Step 2: P16 hash integrity → REVERSE_GATE
        if certificate.hash_valid is False:
            decision = self._make_decision(
                DegradationType.INTEGRITY_VIOLATION,
                ControlAction.REVERSE_GATE,
                GearState.REVERSE,
                certificate.tau, certificate.alpha_omega,
                grid_used="none",
                rationale="P16 REVERSE_GATE: inv_spec_hash mismatch",
                overrides=["HASH_INTEGRITY_FAILURE"],
            )
            telemetry.grid_used = decision.grid_used
            telemetry.degradation = decision.degradation.name
            telemetry.control_action = decision.action.name
            telemetry.overrides_applied = decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
            return self._decision_to_result(decision, telemetry, authorized=False)

        # Step 3: Certificate verification → REJECT
        verification = certificate.verify()
        failed_checks = [k for k, v in verification.items() if not v]
        if failed_checks:
            structural_failures = [c for c in failed_checks if c != "hash_integrity"]
            if structural_failures:
                logger.warning(f"Certificate verification failed: {structural_failures}")
                decision = self._make_decision(
                    DegradationType.COLLAPSE, ControlAction.REJECT,
                    GearState.FOURTH,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=f"Certificate verification failed: {structural_failures}",
                    overrides=["VERIFICATION_FAILURE"],
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=False)

        # Step 4: Phasor coherence → E302 (advisory)
        if coherence is not None:
            telemetry.coherence = coherence
            if coherence < 0.3:
                result = self._handle_failure(FailureCode.E302, telemetry, start_time)
                # E302 is advisory, not blocking in this implementation
                # If you want it to block, return result here

        # Step 5: Drift monitoring → E201-E204
        if current_score is not None:
            alert = self.drift_monitor.check_drift(current_score)
            if alert:
                telemetry.drift_distance = alert.distance
                telemetry.drift_phase = alert.phase.value

                failure_code = classify_drift_failure(alert.distance)
                if failure_code:
                    result = self._handle_failure(failure_code, telemetry, start_time)
                    if failure_code == FailureCode.E204:  # COLLAPSE blocks
                        return result

        # Step 6: Topology validation → E101-E103 (optional/cached)
        if self.enable_topology and t4_coords is not None:
            h1_count = self._validate_topology(t4_coords)
            telemetry.h1_count = h1_count

            failure_code = classify_betti_failure(h1_count)
            if failure_code:
                return self._handle_failure(failure_code, telemetry, start_time)

        # =====================================================================
        # ADMISSIBILITY PHASE (Steps 7-12) - AUTHORIZATION GATE ✅ BLOCKS
        # =====================================================================
        # This phase checks if encoding is SUITABLE for execution (E ∈ E_adm).
        # Checks: σ instability, κ compatibility, N noise, collapse risk, defenses
        # Decision: REJECT / RE_ENCODE / ALLOW
        #
        # This is the ONLY phase that blocks execution. Lyapunov (Step 13) is
        # advisory/verification only and NEVER blocks.
        #
        # Reference: Three_Stability_Concepts_Clarification.md (Concept 1)
        # =====================================================================

        # =====================================================================
        # MULTI-DIMENSIONAL GRID CLASSIFICATION (Patent §V.C.6.1)
        # =====================================================================
        # If enabled, use vector-based pattern classification instead of
        # scalar threshold checks. This is the original patent architecture.
        #
        # Key difference:
        # - Scalar (Steps 7-12): Binary gates with thresholds
        # - Vector (Grid): Pattern matching on (RSN, κ-modal, σ) combinations
        #
        # Grid provides:
        # - Nuanced diagnosis (WHICH component is weak)
        # - Targeted actions (RE_ENCODE_VISION vs RE_ENCODE_TEXT)
        # - NO single gate kills (only COMBINATIONS → REJECT)
        # =====================================================================
        if self.enable_multi_dimensional_grid and self.supervisory_controller is not None:
            logger.debug("Using multi-dimensional grid for pattern classification")

            # Classify certificate pattern
            policy_decision = self.supervisory_controller.classify(certificate)

            # Map grid action to enforcement action
            grid_action_map = {
                GridControlAction.PROCEED: ControlAction.PROCEED,
                GridControlAction.PROCEED_CAUTIOUS: ControlAction.PROCEED_CAUTIOUS,
                GridControlAction.FILTER_CONTEXT: ControlAction.FILTER_CONTEXT,
                GridControlAction.RE_ENCODE: ControlAction.RE_ENCODE,
                GridControlAction.RE_ENCODE_TEXT: ControlAction.RE_ENCODE,  # Map to generic RE_ENCODE
                GridControlAction.RE_ENCODE_VISION: ControlAction.RE_ENCODE,
                GridControlAction.RE_ENCODE_FUSION: ControlAction.RE_ENCODE,
                GridControlAction.GATE_ADAPTATION: ControlAction.GATE_ADAPTATION,
                GridControlAction.DEFER_HUMAN: ControlAction.DEFER_HUMAN,
                GridControlAction.REJECT: ControlAction.REJECT,
            }

            enforcement_action = grid_action_map.get(
                policy_decision.action,
                ControlAction.PROCEED_CAUTIOUS  # Safe fallback
            )

            # Create decision
            decision = self._make_decision(
                policy_decision.degradation,
                enforcement_action,
                GearState.THIRD if enforcement_action in [ControlAction.RE_ENCODE, ControlAction.FILTER_CONTEXT] else GearState.SECOND,
                certificate.tau,
                certificate.alpha_omega,
                grid_used="multi_dimensional",
                rationale=f"Grid pattern: RSN={policy_decision.rsn_pattern.name}, "
                         f"κ={policy_decision.kappa_pattern.name}, "
                         f"σ={policy_decision.sigma_pattern.name}. "
                         f"{policy_decision.rationale}",
                overrides=overrides,
            )

            # Log micro-adjustments (for future micro-level controller)
            if policy_decision.micro_adjustments:
                logger.info(f"Grid micro-adjustments: {policy_decision.micro_adjustments}")

            # Update telemetry
            telemetry.grid_used = decision.grid_used
            telemetry.degradation = decision.degradation.name
            telemetry.control_action = decision.action.name
            telemetry.overrides_applied = decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000

            # Return immediately (bypass scalar threshold logic)
            return self._decision_to_result(decision, telemetry, authorized=True)

        # =====================================================================
        # SCALAR THRESHOLD LOGIC (Original Implementation)
        # =====================================================================
        # Used when multi_dimensional_grid=False (default for backward compat)
        # =====================================================================

        # Step 7: σ instability override → SUPPRESS
        if certificate.sigma is not None and certificate.sigma >= self.SIGMA_CRITICAL_THRESHOLD:
            overrides.append("SIGMA_CRITICAL")
            decision = self._make_decision(
                DegradationType.INSTABILITY, ControlAction.SUPPRESS,
                GearState.FOURTH,
                certificate.tau, certificate.alpha_omega,
                grid_used="none",
                rationale=f"sigma={certificate.sigma:.3f} >= {self.SIGMA_CRITICAL_THRESHOLD} (RSCT instability)",
                overrides=overrides,
            )
            telemetry.grid_used = decision.grid_used
            telemetry.degradation = decision.degradation.name
            telemetry.control_action = decision.action.name
            telemetry.overrides_applied = decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
            return self._decision_to_result(decision, telemetry, authorized=True)

        if certificate.sigma is not None and certificate.sigma >= self.SIGMA_WARNING_THRESHOLD:
            overrides.append("SIGMA_WARNING")

        # =====================================================================
        # Step 7.5: κ Compatibility Check with Landauer Tolerance
        # =====================================================================
        # Layer 2 (κ) catches encoding-solver mismatches that Layer 1 (α) misses
        #
        # HYBRID PHYSICS (Option C):
        # - certificate.kappa contains κ_critical = min(κ_A, κ_E, κ_T) [SERIES CIRCUIT]
        # - Critical threshold uses this for zero-trust blocking
        # - Warning threshold is more forgiving (buffer zone before critical)
        #
        # LANDAUER TOLERANCE (Memristor-Inspired Gray Zone):
        # Three zones prevent false rejections from measurement noise/jitter:
        #
        #   Zone 1: DEFINITELY INCOMPATIBLE
        #   ├─────────────────────────────────┐
        #   0.0                    (threshold - tolerance)
        #   Action: BLOCK immediately
        #   Physics: Below thermodynamic barrier, incompatible
        #
        #   Zone 2: GRAY ZONE (Landauer Tolerance Region)
        #   ├────────────────────────────────────────────┐
        #   (threshold - tolerance)           threshold
        #   Action: σ (instability) decides
        #   - If σ > 0.5: BLOCK (unstable + marginal → reject)
        #   - If σ ≤ 0.5: ALLOW with warning
        #   Physics: Like memristor thermal noise region (Landauer's principle)
        #
        #   Zone 3: COMPATIBLE
        #   ├─────────────────────────────────┤
        #   threshold                     1.0
        #   Action: Continue to next check
        #   Physics: Above threshold, compatible
        #
        # Analogy: Like memristor energy_barrier preventing updates from thermal noise
        # Reference: docs/design/LANDAUER_TOLERANCE_DESIGN.md
        if certificate.kappa is not None:
            # BACKWARD COMPATIBLE: Use Oobleck only if σ available, else static threshold
            if certificate.sigma is not None:
                # OOBLECK MODE: Threshold adapts based on instability (shear thickening)
                # Formula: required_κ = base + (sensitivity × σ)
                # Configurable parameters allow tuning the "hardening" response
                required_kappa_critical = self.OOBLECK_BASE_THRESHOLD + (self.OOBLECK_SENSITIVITY * certificate.sigma)
                required_kappa_warning = required_kappa_critical + 0.1  # Buffer zone
                override_tag = "OOBLECK_KAPPA_CRITICAL"
                composition_mode = "series" if self.kappa_composition == "min" else "parallel"
                rationale = (
                    f"Oobleck ({composition_mode} circuit): κ={certificate.kappa:.3f} < "
                    f"required={required_kappa_critical:.3f} (σ={certificate.sigma:.3f}, "
                    f"base={self.OOBLECK_BASE_THRESHOLD}, sens={self.OOBLECK_SENSITIVITY}). "
                    f"System hardens under instability."
                )
            else:
                # STATIC MODE: Use fixed threshold (original ABL-15 behavior)
                required_kappa_critical = self.KAPPA_CRITICAL_THRESHOLD
                required_kappa_warning = self.KAPPA_WARNING_THRESHOLD
                override_tag = "KAPPA_CRITICAL"
                composition_mode = "series" if self.kappa_composition == "min" else "parallel"
                rationale = (
                    f"κ={certificate.kappa:.3f} < {self.KAPPA_CRITICAL_THRESHOLD} "
                    f"({composition_mode} circuit): Encoding-solver mismatch (ABL-15)"
                )

            # CRITICAL CHECK (Series Circuit - Zero Trust with Wiggle Room)
            # Three zones (like memristor energy_barrier):
            # 1. κ < (threshold - tolerance): DEFINITELY reject
            # 2. κ ∈ [threshold - tolerance, threshold]: GRAY ZONE (σ decides)
            # 3. κ >= threshold: OK

            if certificate.kappa < (required_kappa_critical - self.KAPPA_TOLERANCE):
                # Zone 1: DEFINITELY INCOMPATIBLE
                overrides.append(override_tag)
                decision = self._make_decision(
                    DegradationType.INCOMPATIBLE, ControlAction.RE_ENCODE,
                    GearState.THIRD,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=rationale,
                    overrides=overrides,
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=True)

            elif certificate.kappa < required_kappa_critical:
                # Zone 2: GRAY ZONE (like memristor thermal noise region)
                # σ instability tips the scale
                if certificate.sigma is not None and certificate.sigma > 0.5:
                    # High instability in gray zone → reject (better safe than sorry)
                    overrides.append(override_tag + "_GRAY_ZONE")
                    decision = self._make_decision(
                        DegradationType.INCOMPATIBLE, ControlAction.RE_ENCODE,
                        GearState.THIRD,
                        certificate.tau, certificate.alpha_omega,
                        grid_used="none",
                        rationale=(
                            f"Gray zone + high σ: κ={certificate.kappa:.3f} in "
                            f"[{required_kappa_critical - self.KAPPA_TOLERANCE:.3f}, "
                            f"{required_kappa_critical:.3f}] with σ={certificate.sigma:.3f}>0.5"
                        ),
                        overrides=overrides,
                    )
                    telemetry.grid_used = decision.grid_used
                    telemetry.degradation = decision.degradation.name
                    telemetry.control_action = decision.action.name
                    telemetry.overrides_applied = decision.overrides_applied
                    telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                    return self._decision_to_result(decision, telemetry, authorized=True)
                else:
                    # Low/no instability in gray zone → allow with warning
                    logger.warning(
                        f"κ in gray zone: {certificate.kappa:.3f} ∈ "
                        f"[{required_kappa_critical - self.KAPPA_TOLERANCE:.3f}, "
                        f"{required_kappa_critical:.3f}], σ={certificate.sigma}, allowing"
                    )

            # WARNING CHECK (Parallel Circuit - Forgiving)
            elif certificate.kappa < required_kappa_warning:
                # WARN: Approaching critical threshold (buffer zone)
                if certificate.sigma is not None:
                    overrides.append("OOBLECK_KAPPA_WARNING")
                    logger.warning(
                        f"Oobleck Warning (Parallel Circuit): κ_critical={certificate.kappa:.3f} "
                        f"approaching critical (required={required_kappa_critical:.3f}, "
                        f"σ={certificate.sigma:.3f}). Suboptimal compatibility."
                    )
                else:
                    overrides.append("KAPPA_WARNING")
                    logger.warning(
                        f"κ_critical={certificate.kappa:.3f} < {required_kappa_warning:.3f}: "
                        f"Suboptimal encoding-solver compatibility (ABL-15)"
                    )

            # STAGE 1 ENHANCEMENT: Multi-layer detection (low κ + low α)
            # If both quality AND compatibility are suboptimal, escalate to RE_ENCODE
            if certificate.kappa < 0.5 and certificate.alpha < 0.5:
                overrides.append("MULTI_LAYER_CRITICAL")
                decision = self._make_decision(
                    DegradationType.INCOMPATIBLE, ControlAction.RE_ENCODE,
                    GearState.THIRD,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=f"Multi-layer failure: κ={certificate.kappa:.3f} < 0.5 AND α={certificate.alpha:.3f} < 0.5",
                    overrides=overrides,
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=True)

        # Step 7.6: Layer 3 Hierarchical κ Check (Multimodal)
        # Cross-modal disagreement detection
        if certificate.kappa_interface is not None:
            if certificate.kappa_interface < 0.7:
                # CRITICAL: Modality disagreement (text ≠ vision)
                overrides.append("KAPPA_INTERFACE_LOW")
                decision = self._make_decision(
                    DegradationType.INCOMPATIBLE, ControlAction.RE_ENCODE,
                    GearState.THIRD,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=f"kappa_interface={certificate.kappa_interface:.3f} < 0.7: Cross-modal disagreement detected",
                    overrides=overrides,
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=True)

        # Step 7.6b: Hierarchical Instability Check (sigma_H / sigma_L)
        # Grounding Repair: Identify which modality is unstable
        # Uses Oobleck dynamic thresholding per modality
        if certificate.sigma_H is not None and certificate.sigma_L is not None:
            # Compute Oobleck thresholds for each modality
            oobleck_threshold_H = self.OOBLECK_BASE_THRESHOLD + (self.OOBLECK_SENSITIVITY * certificate.sigma_H)
            oobleck_threshold_L = self.OOBLECK_BASE_THRESHOLD + (self.OOBLECK_SENSITIVITY * certificate.sigma_L)

            # Check H-level (text/semantic) instability
            if certificate.kappa_H is not None and certificate.kappa_H < oobleck_threshold_H:
                # Text encoding-solver mismatch OR high instability
                if certificate.sigma_H < 0.3:
                    # Low instability = compatibility issue
                    action = ControlAction.RE_ENCODE
                    reason = f"kappa_H={certificate.kappa_H:.3f} < Oobleck_H={oobleck_threshold_H:.3f}: Text encoding mismatch"
                else:
                    # High instability = turbulence (proceed cautiously instead of re-encode)
                    action = ControlAction.PROCEED_CAUTIOUS
                    reason = f"sigma_H={certificate.sigma_H:.3f} high, kappa_H={certificate.kappa_H:.3f}: Text reasoning turbulence"

                overrides.append("HIERARCHICAL_H_UNSTABLE")
                decision = self._make_decision(
                    DegradationType.INSTABILITY, action,
                    GearState.THIRD,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=reason,
                    overrides=overrides,
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.hierarchical_bottleneck = "text"  # Diagnostic
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=True)

            # Check L-level (vision/perception) instability
            if certificate.kappa_L is not None and certificate.kappa_L < oobleck_threshold_L:
                # Vision encoding-solver mismatch OR high instability
                if certificate.sigma_L < 0.3:
                    # Low instability = compatibility issue
                    action = ControlAction.RE_ENCODE
                    reason = f"kappa_L={certificate.kappa_L:.3f} < Oobleck_L={oobleck_threshold_L:.3f}: Vision encoding mismatch"
                else:
                    # High instability = turbulence (proceed cautiously instead of re-encode)
                    action = ControlAction.PROCEED_CAUTIOUS
                    reason = f"sigma_L={certificate.sigma_L:.3f} high, kappa_L={certificate.kappa_L:.3f}: Vision grounding turbulence"

                overrides.append("HIERARCHICAL_L_UNSTABLE")
                decision = self._make_decision(
                    DegradationType.INSTABILITY, action,
                    GearState.THIRD,
                    certificate.tau, certificate.alpha_omega,
                    grid_used="none",
                    rationale=reason,
                    overrides=overrides,
                )
                telemetry.grid_used = decision.grid_used
                telemetry.degradation = decision.degradation.name
                telemetry.control_action = decision.action.name
                telemetry.overrides_applied = decision.overrides_applied
                telemetry.hierarchical_bottleneck = "vision"  # Diagnostic
                telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
                return self._decision_to_result(decision, telemetry, authorized=True)

        # Step 8: N poisoning override → SUPPRESS
        if certificate.N >= self.NOISE_POISONING_THRESHOLD:
            overrides.append("NOISE_POISONING")
            decision = self._make_decision(
                DegradationType.POISONING, ControlAction.SUPPRESS,
                GearState.FOURTH,
                certificate.tau, certificate.alpha_omega,
                grid_used="none",
                rationale=f"N={certificate.N:.3f} >= {self.NOISE_POISONING_THRESHOLD} (adversarial/corruption)",
                overrides=overrides,
            )
            telemetry.grid_used = decision.grid_used
            telemetry.degradation = decision.degradation.name
            telemetry.control_action = decision.action.name
            telemetry.overrides_applied = decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
            return self._decision_to_result(decision, telemetry, authorized=True)

        # Step 9: Collapse risk override → REJECT
        collapse_risk = certificate.extras.get('collapse_risk') if certificate.extras else None
        if collapse_risk is not None and collapse_risk >= self.COLLAPSE_RISK_THRESHOLD:
            overrides.append("COLLAPSE_RISK")
            decision = self._make_decision(
                DegradationType.COLLAPSE, ControlAction.REJECT,
                GearState.FOURTH,
                certificate.tau, certificate.alpha_omega,
                grid_used="none",
                rationale=f"collapse_risk={collapse_risk:.3f} >= {self.COLLAPSE_RISK_THRESHOLD}",
                overrides=overrides,
            )
            telemetry.grid_used = decision.grid_used
            telemetry.degradation = decision.degradation.name
            telemetry.control_action = decision.action.name
            telemetry.overrides_applied = decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
            return self._decision_to_result(decision, telemetry, authorized=False)

        # Step 10: Defense layer overrides
        defense_decision = self._check_defense_overrides(certificate, overrides)
        if defense_decision is not None:
            telemetry.grid_used = defense_decision.grid_used
            telemetry.degradation = defense_decision.degradation.name
            telemetry.control_action = defense_decision.action.name
            telemetry.overrides_applied = defense_decision.overrides_applied
            telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
            # SUPPRESS is authorized (controlled block), REJECT is not
            authorized = defense_decision.action != ControlAction.REJECT
            return self._decision_to_result(defense_decision, telemetry, authorized=authorized)

        # Step 11: Grid selection → α×κ or α×ω
        alpha_st = certificate.alpha_state

        if certificate.kappa is not None:
            # GRID A: α × κ (RSCT solver metadata available)
            kappa_st = certificate.kappa_state
            grid_key = (alpha_st, kappa_st)
            degradation, action = _GRID_ALPHA_KAPPA[grid_key]
            grid_used = "alpha_kappa"
            rationale = f"alpha={alpha_st} x kappa={kappa_st} -> {degradation.name}"
        else:
            # GRID B: α × ω (no solver metadata, use reliability)
            omega_st = certificate.omega_state
            grid_key = (alpha_st, omega_st)
            degradation, action = _GRID_ALPHA_OMEGA[grid_key]
            grid_used = "alpha_omega"
            rationale = f"alpha={alpha_st} x omega={omega_st} -> {degradation.name} (kappa unavailable)"

        # Step 12: Gear from τ (P14 — always τ-driven)
        gear = tau_to_gear(certificate.tau)

        # σ warning: if σ is elevated but not critical, bump gear up by 1
        if "SIGMA_WARNING" in overrides and gear.value >= 1 and gear.value < 4:
            gear = GearState(gear.value + 1)

        decision = self._make_decision(
            degradation, action, gear,
            certificate.tau, certificate.alpha_omega,
            grid_used=grid_used,
            rationale=rationale,
            overrides=overrides,
        )

        # =====================================================================
        # VERIFICATION PHASE (Step 13) - ADVISORY ONLY ❌ NEVER BLOCKS
        # =====================================================================
        # This phase verifies Lyapunov trajectory stability (V̇ ≤ 0).
        # Type: Backward-looking verification (analyzes past trajectory)
        # Decision: Advisory telemetry only, NEVER blocks execution
        #
        # Lyapunov is Concept 3 (orthogonal to Admissibility and Quality Envelope).
        # Admissibility (Steps 7-12) is the ONLY gate that blocks execution.
        #
        # Reference: Three_Stability_Concepts_Clarification.md (Concept 3)
        # =====================================================================

        # Step 13: Lyapunov monitoring (ADVISORY ONLY, Layer 4)
        # Lyapunov PROVES stability - it does NOT drive gear selection.
        # Quality signals (alpha, tau) drive the gearbox (Layer 2).
        # Lyapunov verifies V̇ ≤ 0 under quality-driven control (Layer 4).
        if certificate.V is not None:
            telemetry.lyapunov_V = certificate.V
            telemetry.lyapunov_V_dot = certificate.V_dot
            telemetry.lyapunov_stable = certificate.is_lyapunov_stable  # V̇ ≤ 0
            telemetry.lyapunov_margin = certificate.lyapunov_margin

        # =====================================================================
        # FINALIZE
        # =====================================================================

        telemetry.grid_used = decision.grid_used
        telemetry.degradation = decision.degradation.name
        telemetry.control_action = decision.action.name
        telemetry.overrides_applied = decision.overrides_applied
        telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000

        # Determine authorization based on action
        # SUPPRESS is authorized (controlled blocking), REJECT is not (hard rejection)
        authorized = decision.action != ControlAction.REJECT

        return self._decision_to_result(decision, telemetry, authorized=authorized)

    # =========================================================================
    # HELPER METHODS
    # =========================================================================

    def _validate_simplex(self, R: float, S: float, N: float) -> bool:
        """Validate R+S+N=1 constraint."""
        total = R + S + N
        return abs(total - 1.0) <= self.SIMPLEX_TOLERANCE

    def _validate_topology(self, t4_coords: np.ndarray) -> int:
        """
        Validate T⁴ topology using H₁ Betti number.

        Returns:
            Number of significant H₁ loops

        Note:
            Returns 4 (valid) if topology cache is not available.
        """
        if self._topology_cache is None:
            try:
                from yrsn.core.enforcement.topology_cache import TopologyCache
                self._topology_cache = TopologyCache()
            except ImportError:
                # ripser not installed - assume valid
                return 4

        return self._topology_cache.get_h1_count(t4_coords)

    def _handle_failure(
        self,
        code: FailureCode,
        telemetry: UnifiedEnforcementTelemetry,
        start_time: float,
    ) -> EnforcementResult:
        """Handle a failure by executing gearbox action."""
        response = get_failure_response(code)

        # Track failure count
        code_str = f"E{code.value}"
        self._failure_counts[code_str] = self._failure_counts.get(code_str, 0) + 1

        # Execute gearbox action
        if response.gearbox_action == GearboxAction.REVERSE:
            self.gearbox.shift(Gear.REVERSE)
        elif response.gearbox_action == GearboxAction.DOWNSHIFT:
            target = self._get_downshift_target(response.target_gear)
            if target:
                self.gearbox.shift(target)
        elif response.gearbox_action == GearboxAction.NEUTRAL:
            # Blocked - don't shift, return unauthorized
            pass

        telemetry.cycle_time_ms = (time.perf_counter() - start_time) * 1000
        state = self.gearbox.get_state()

        # Determine authorization
        authorized = response.gearbox_action != GearboxAction.NEUTRAL

        return EnforcementResult(
            authorized=authorized,
            current_gear=state.current_gear if authorized else None,
            failure_code=code_str,
            active_backend=state.engine_name if authorized else None,
            active_view=state.view if authorized else None,
            telemetry={
                "drift_distance": telemetry.drift_distance,
                "drift_phase": telemetry.drift_phase,
                "h1_count": telemetry.h1_count,
                "coherence": telemetry.coherence,
                "cycle_time_ms": telemetry.cycle_time_ms,
                "failure_message": response.message,
                "recommendation": response.recommendation,
            },
        )

    def _get_downshift_target(self, target_str: Optional[str]) -> Optional[Gear]:
        """Convert target gear string to Gear enum."""
        if target_str is None:
            return None

        mapping = {
            "1st": Gear.FIRST,
            "2nd": Gear.SECOND,
            "3rd": Gear.THIRD,
            "4th": Gear.FOURTH,
            "R": Gear.REVERSE,
        }
        return mapping.get(target_str)

    def _make_decision(
        self,
        degradation: DegradationType,
        action: ControlAction,
        gear: GearState,
        tau: float,
        alpha_omega: float,
        grid_used: str,
        rationale: str,
        overrides: Optional[List[str]] = None,
    ) -> ControlDecision:
        """Create and record a control decision."""
        decision = ControlDecision(
            degradation=degradation,
            action=action,
            gear=gear,
            tau=tau,
            alpha_omega=alpha_omega,
            grid_used=grid_used,
            rationale=rationale,
            overrides_applied=overrides or [],
        )
        self._current_gear = gear
        self._decision_history.append(decision)
        logger.info(
            f"Decision: {degradation.name} -> {action.name} "
            f"[{gear.name}] tau={tau:.2f} alpha_omega={alpha_omega:.3f} | {rationale}"
        )
        return decision

    def _check_defense_overrides(
        self,
        cert: YRSNCertificate,
        overrides: List[str],
    ) -> Optional[ControlDecision]:
        """
        Check defense layer signals for override conditions (Step 10).

        Override priority (highest first):
            1. Sybil attack detected -> SUPPRESS
            2. Goal drift detected -> SUPPRESS
            3. Rate limited -> DEFER_HUMAN
            4. High defense pressure -> PROCEED_CAUTIOUS

        Returns None if no defense override triggered.
        """
        # Check if defense fields are populated
        if not hasattr(cert, 'defense_goal_valid') or cert.defense_goal_valid is None:
            return None

        logger.debug(
            f"Checking defense overrides: goal_valid={cert.defense_goal_valid}, "
            f"is_sybil={cert.defense_is_sybil}, rate_limited={cert.defense_rate_limited}, "
            f"pressure={cert.defense_pressure}"
        )

        # Priority 1: Sybil attack
        if cert.defense_is_sybil:
            overrides.append("SYBIL_ATTACK")
            return self._make_decision(
                DegradationType.SYBIL_ATTACK,
                ControlAction.SUPPRESS,
                GearState.FOURTH,
                cert.tau, cert.alpha_omega,
                grid_used="none",
                rationale="Sybil attack detected by defense layer",
                overrides=overrides,
            )

        # Priority 2: Goal drift
        if not cert.defense_goal_valid:
            overrides.append("GOAL_DRIFT")
            return self._make_decision(
                DegradationType.GOAL_DRIFT,
                ControlAction.SUPPRESS,
                GearState.FOURTH,
                cert.tau, cert.alpha_omega,
                grid_used="none",
                rationale="Goal integrity violation detected by defense layer",
                overrides=overrides,
            )

        # Priority 3: Rate limited
        if cert.defense_rate_limited:
            overrides.append("RATE_LIMITED")
            return self._make_decision(
                DegradationType.RATE_LIMITED,
                ControlAction.DEFER_HUMAN,
                GearState.THIRD,
                cert.tau, cert.alpha_omega,
                grid_used="none",
                rationale="Rate limit triggered by defense layer",
                overrides=overrides,
            )

        # Priority 4: High defense pressure
        if cert.defense_pressure is not None:
            if cert.defense_pressure >= self.DEFENSE_PRESSURE_CRITICAL:
                overrides.append("DEFENSE_PRESSURE_CRITICAL")
                return self._make_decision(
                    DegradationType.POISONING,
                    ControlAction.PROCEED_CAUTIOUS,
                    GearState.THIRD,
                    cert.tau, cert.alpha_omega,
                    grid_used="none",
                    rationale=f"Defense pressure={cert.defense_pressure:.3f} >= {self.DEFENSE_PRESSURE_CRITICAL}",
                    overrides=overrides,
                )
            elif cert.defense_pressure >= self.DEFENSE_PRESSURE_WARNING:
                # Add to overrides but don't return early - proceed to grid
                overrides.append("DEFENSE_PRESSURE_WARNING")

        # No override triggered
        return None

    def _decision_to_result(
        self,
        decision: ControlDecision,
        telemetry: UnifiedEnforcementTelemetry,
        authorized: bool,
    ) -> EnforcementResult:
        """Convert ControlDecision to EnforcementResult."""
        state = self.gearbox.get_state()

        # Map GearState to Gear for EnforcementResult
        gear_mapping = {
            GearState.FIRST: Gear.FIRST,
            GearState.SECOND: Gear.SECOND,
            GearState.THIRD: Gear.THIRD,
            GearState.FOURTH: Gear.FOURTH,
            GearState.REVERSE: Gear.REVERSE,
        }
        current_gear = gear_mapping.get(decision.gear)

        return EnforcementResult(
            authorized=authorized,
            current_gear=current_gear if authorized else None,
            failure_code=None if authorized else decision.degradation.name,
            active_backend=state.engine_name if authorized else None,
            active_view=state.view if authorized else None,
            telemetry={
                "drift_distance": telemetry.drift_distance,
                "drift_phase": telemetry.drift_phase,
                "h1_count": telemetry.h1_count,
                "coherence": telemetry.coherence,
                "grid_used": telemetry.grid_used,
                "degradation": telemetry.degradation,
                "control_action": telemetry.control_action,
                "overrides_applied": telemetry.overrides_applied,
                "lyapunov_V": telemetry.lyapunov_V,
                "lyapunov_V_dot": telemetry.lyapunov_V_dot,
                "lyapunov_stable": telemetry.lyapunov_stable,
                "lyapunov_margin": telemetry.lyapunov_margin,
                "cycle_time_ms": telemetry.cycle_time_ms,
                "tau": decision.tau,
                "alpha_omega": decision.alpha_omega,
                "rationale": decision.rationale,
            },
        )

    def decide(self, certificate: YRSNCertificate, **kwargs) -> ControlDecision:
        """
        Convenience method: enforce certificate and return ControlDecision directly.

        This is a simpler API for callers who only need the decision without
        the full EnforcementResult. Equivalent to:
            engine.enforce_certificate(cert)
            decision = engine.history[-1]

        Args:
            certificate: YRSNCertificate to evaluate
            **kwargs: Additional arguments passed to enforce_certificate

        Returns:
            ControlDecision with degradation, action, gear, rationale

        Example:
            decision = engine.decide(cert)
            if decision.action == ControlAction.REJECT:
                print(f"Rejected: {decision.rationale}")
        """
        self.enforce_certificate(certificate, **kwargs)
        return self._decision_history[-1]

    # =========================================================================
    # DIAGNOSTIC METHODS
    # =========================================================================

    @property
    def current_gear(self) -> GearState:
        return self._current_gear

    @property
    def history(self) -> List[ControlDecision]:
        return list(self._decision_history)

    def get_stats(self) -> Dict[str, Any]:
        """Get enforcement statistics."""
        return {
            "enforcement_count": self._enforcement_count,
            "failure_counts": dict(self._failure_counts),
            "current_gear": self._current_gear.name,
            "shift_count": self.gearbox.get_shift_count(),
            "driving_mode": self.gearbox.driving_mode.value,
        }

    def reset(self) -> None:
        """Reset engine state."""
        self.gearbox.reset()
        self.drift_monitor.reset_history()
        self._enforcement_count = 0
        self._failure_counts.clear()
        self._current_gear = GearState.FIRST
        self._decision_history.clear()
        if self._topology_cache:
            self._topology_cache.clear()


__all__ = [
    "UnifiedEnforcementEngine",
    "UnifiedEnforcementTelemetry",
    "ControlDecision",
    "DegradationType",
    "ControlAction",
    "GearState",
    "tau_to_gear",
]
