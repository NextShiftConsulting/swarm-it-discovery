"""
supervisory_controller.py
==========================

Supervisory Controller with Multi-Dimensional Classification Grid (Patent §V.C.6.1)

The supervisory controller employs a multi-dimensional classification grid for
pattern-based certificate enforcement. This is the original patent architecture
restored: classification based on VECTOR PATTERNS, not scalar reductions.

Architecture Components:
  1. Pattern Identification: RSN/κ/σ vectors → discrete patterns
  2. Multi-Dimensional Grid: Pattern → Policy mappings (56/175 configured)
  3. SupervisoryController: Runtime classification engine

Patent Language:
  "A supervisory level employs a multi-dimensional classification grid mapping
   certificate components to predefined execution policies based on configurable
   threshold parameters." - Patent [0371]

Design Philosophy:
  - NO single gate kills the process
  - Pattern matching on (R,S,N) × (κ_modal) × (σ_vector)
  - Actions depend on WHICH component is weak, not just magnitude
  - Graduated response: reject only when MULTIPLE components fail

Grid as Controller Component:
  The grid is NOT a separate system - it's the declarative configuration
  employed by the controller. Think: database (grid) + query engine (controller).

Example:
  Pattern: (R-dominant, vision-weak, stable)
    → Diagnosis: Vision encoding incompatible, text works fine
    → Action: RE_ENCODE_VISION (targeted fix, not generic RE_ENCODE)
    → Micro-adjustments: {'vision_weight': 0.3, 'text_weight': 0.9}

  Pattern: (N-dominant, all-strong, stable)
    → Diagnosis: Encodings work fine, but input has noise
    → Action: FILTER_CONTEXT (filter noise, don't re-encode)

  Pattern: (N-collapsed, all-weak, unstable)
    → Diagnosis: Multiple safety violations
    → Action: REJECT (only COMBINATIONS trigger reject)

Author: Rudolph A. Martin, Next Shift Consulting LLC
License: Proprietary
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum, auto
from typing import Dict, Optional, Tuple, List

logger = logging.getLogger(__name__)


# =============================================================================
# PATTERN TYPES (Vector Shape Classification)
# =============================================================================

class RSNPattern(Enum):
    """Pattern classification for RSN vector (R, S, N)."""
    R_DOMINANT = auto()        # R > 0.6, balanced S/N
    S_DOMINANT = auto()        # S > 0.4, moderate R
    N_DOMINANT = auto()        # N > R (noise exceeds relevance)
    NOISE_COLLAPSED = auto()   # N > R×0.8 (asymmetric safety trigger)
    BALANCED = auto()          # No clear dominant component


class KappaPattern(Enum):
    """Pattern classification for κ-modal vector (text, vision, interface)."""
    ALL_STRONG = auto()        # min(κ) ≥ 0.6
    TEXT_WEAK = auto()         # κ_text < 0.3, others OK
    VISION_WEAK = auto()       # κ_vision < 0.3, others OK
    INTERFACE_WEAK = auto()    # κ_interface < 0.3, others OK
    MULTIPLE_WEAK = auto()     # 2+ modalities < 0.3
    ALL_WEAK = auto()          # all modalities < 0.3
    UNAVAILABLE = auto()       # No κ data (single-modal)


class SigmaPattern(Enum):
    """Pattern classification for σ-vector (variance, growth, entropy)."""
    STABLE = auto()            # σ < 0.4
    VARIANCE_DRIVEN = auto()   # σ_var dominates
    GROWTH_DRIVEN = auto()     # σ_growth dominates
    ENTROPY_DRIVEN = auto()    # σ_entropy dominates
    HIGHLY_UNSTABLE = auto()   # σ > 0.7


class DegradationType(Enum):
    """Typed degradation states from pattern combinations."""
    HEALTHY = auto()
    DISTRACTION = auto()           # S-dominant
    NOISE_DOMINANT = auto()        # N > R but not collapsed
    NOISE_COLLAPSED = auto()       # N > R×0.8 (asymmetric safety)
    GEOMETRY_MISMATCH = auto()     # R OK, κ weak
    CONTENT_DEGRADATION = auto()   # κ OK, R weak
    VISION_ENCODING_ISSUE = auto() # Vision modality weak
    TEXT_ENCODING_ISSUE = auto()   # Text modality weak
    FUSION_ISSUE = auto()          # Interface weak
    UNSTABLE = auto()              # σ too high
    TOTAL_FAILURE = auto()         # Multiple components failed


class ControlAction(Enum):
    """System-level responses to degradation patterns."""
    PROCEED = auto()
    PROCEED_CAUTIOUS = auto()
    FILTER_CONTEXT = auto()      # Prune S or N
    RE_ENCODE = auto()            # Fix encoding (specific modality)
    RE_ENCODE_TEXT = auto()       # Fix text encoding specifically
    RE_ENCODE_VISION = auto()     # Fix vision encoding specifically
    RE_ENCODE_FUSION = auto()     # Fix cross-modal fusion
    GATE_ADAPTATION = auto()      # Slow learning, increase monitoring
    DEFER_HUMAN = auto()
    REJECT = auto()


# =============================================================================
# PATTERN IDENTIFICATION (Vector Shape → Discrete Pattern)
# =============================================================================

def identify_rsn_pattern(
    rsn: Dict[str, float],
    asymmetric_threshold: float = 0.8
) -> RSNPattern:
    """
    Classify RSN vector pattern.

    Asymmetric Safety (Patent requirement):
      N > (R × 0.8) → NOISE_COLLAPSED (conservative trigger)
      N > R → NOISE_DOMINANT (symmetric check)

    This ensures we're cautious about noise (Type I error prevention).
    """
    r, s, n = rsn['r'], rsn['s'], rsn['n']

    # Asymmetric safety: conservative noise detection
    if n > (r * asymmetric_threshold):
        return RSNPattern.NOISE_COLLAPSED

    # Symmetric noise dominance
    if n > r:
        return RSNPattern.NOISE_DOMINATED

    # Component dominance
    if r > 0.6:
        return RSNPattern.R_DOMINANT

    if s > 0.4:
        return RSNPattern.S_DOMINANT

    return RSNPattern.BALANCED


def identify_kappa_pattern(
    kappa_modal: Optional[Dict[str, float]],
    weak_threshold: float = 0.3,
    strong_threshold: float = 0.6
) -> KappaPattern:
    """
    Classify κ-modal vector pattern.

    Key insight: We need to know WHICH modality is weak to fix it.
    min() loses this information!
    """
    if kappa_modal is None:
        return KappaPattern.UNAVAILABLE

    κ_text = kappa_modal.get('text')
    κ_vision = kappa_modal.get('vision')
    κ_interface = kappa_modal.get('interface')

    # Handle partial data (single-modal case)
    if κ_text is None and κ_vision is None and κ_interface is None:
        return KappaPattern.UNAVAILABLE

    # Identify weak components
    weak_components = []
    if κ_text is not None and κ_text < weak_threshold:
        weak_components.append('text')
    if κ_vision is not None and κ_vision < weak_threshold:
        weak_components.append('vision')
    if κ_interface is not None and κ_interface < weak_threshold:
        weak_components.append('interface')

    # Pattern classification
    if len(weak_components) == 0:
        # All strong
        return KappaPattern.ALL_STRONG

    if len(weak_components) == 1:
        # Single weak component
        if weak_components[0] == 'text':
            return KappaPattern.TEXT_WEAK
        if weak_components[0] == 'vision':
            return KappaPattern.VISION_WEAK
        if weak_components[0] == 'interface':
            return KappaPattern.INTERFACE_WEAK

    if len(weak_components) == 2:
        return KappaPattern.MULTIPLE_WEAK

    # All weak
    return KappaPattern.ALL_WEAK


def identify_sigma_pattern(
    sigma_vector: Optional[Tuple[float, float, float]],
    sigma_scalar: Optional[float],
    high_threshold: float = 0.7,
    moderate_threshold: float = 0.4
) -> SigmaPattern:
    """
    Classify σ-vector pattern.

    Identifies WHICH type of instability dominates:
    - Variance: Activation spread inconsistency
    - Growth: Trajectory divergence
    - Entropy: Distributional uncertainty
    """
    # Use scalar if vector unavailable
    if sigma_vector is None:
        if sigma_scalar is None:
            return SigmaPattern.STABLE
        if sigma_scalar > high_threshold:
            return SigmaPattern.HIGHLY_UNSTABLE
        if sigma_scalar < moderate_threshold:
            return SigmaPattern.STABLE
        # Moderate but can't identify type
        return SigmaPattern.STABLE

    σ_var, σ_growth, σ_entropy = sigma_vector
    σ_total = σ_var + σ_growth + σ_entropy

    # High overall instability
    if σ_total > high_threshold:
        return SigmaPattern.HIGHLY_UNSTABLE

    # Low overall instability
    if σ_total < moderate_threshold:
        return SigmaPattern.STABLE

    # Identify dominant component
    if σ_var > σ_growth and σ_var > σ_entropy:
        return SigmaPattern.VARIANCE_DRIVEN
    if σ_growth > σ_var and σ_growth > σ_entropy:
        return SigmaPattern.GROWTH_DRIVEN
    if σ_entropy > σ_var and σ_entropy > σ_growth:
        return SigmaPattern.ENTROPY_DRIVEN

    return SigmaPattern.STABLE


# =============================================================================
# POLICY SPECIFICATION (What to do for each pattern)
# =============================================================================

@dataclass(frozen=True)
class PolicySpec:
    """
    Policy specification for a pattern combination.

    Defines both WHAT to do (action) and HOW (micro-level parameters).
    """
    degradation: DegradationType
    action: ControlAction
    rationale: str

    # Micro-level parameter adjustments (Patent [0374])
    # "smooth interpolation of control parameters as a function of component magnitudes"
    micro_adjustments: Optional[Dict[str, float]] = None


# =============================================================================
# MULTI-DIMENSIONAL GRID (Pattern → Policy Mapping)
# =============================================================================

@dataclass(frozen=True)
class CollapsePattern:
    """Multi-dimensional pattern key for grid lookup."""
    rsn: RSNPattern
    kappa: KappaPattern
    sigma: SigmaPattern

    def __hash__(self):
        return hash((self.rsn, self.kappa, self.sigma))


# Grid: (RSN pattern, κ pattern, σ pattern) → Policy
# This is the "multi-dimensional classification grid" from patent [0371]
MULTI_DIMENSIONAL_GRID: Dict[CollapsePattern, PolicySpec] = {}

# =============================================================================
# GRID POPULATION: R-DOMINANT PATTERNS
# =============================================================================

# R-dominant + All κ strong + Stable → HEALTHY
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.HEALTHY,
    action=ControlAction.PROCEED,
    rationale="High quality content, compatible encoding, stable execution"
)

# R-dominant + Vision weak + Stable → Fix vision encoding
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.VISION_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.VISION_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_VISION,
    rationale="Good content but vision encoding incompatible with solver",
    micro_adjustments={'vision_weight': 0.3, 'text_weight': 0.9}
)

# R-dominant + Text weak + Stable → Fix text encoding
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.TEXT_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_TEXT,
    rationale="Good content but text encoding incompatible with solver",
    micro_adjustments={'text_weight': 0.3, 'vision_weight': 0.9}
)

# R-dominant + Interface weak + Stable → Fix fusion
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.INTERFACE_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.FUSION_ISSUE,
    action=ControlAction.RE_ENCODE_FUSION,
    rationale="Good modalities but cross-modal fusion incompatible",
    micro_adjustments={'fusion_strength': 0.3}
)

# R-dominant + All weak → Content good but all encodings bad
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.GEOMETRY_MISMATCH,
    action=ControlAction.RE_ENCODE,
    rationale="Content quality high but all encodings incompatible with solver"
)

# =============================================================================
# GRID POPULATION: S-DOMINANT PATTERNS (Distraction/Superfluous)
# =============================================================================

# S-dominant + Any κ + Stable → Filter context
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Too much superfluous information, filter irrelevant content",
    micro_adjustments={'filtering_strength': 0.6}
)

# S-dominant + κ weak → Filter AND re-encode
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.VISION_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,  # Filter first priority
    rationale="Superfluous content + vision encoding issue, filter then reassess",
    micro_adjustments={'filtering_strength': 0.6, 'vision_weight': 0.4}
)

# =============================================================================
# GRID POPULATION: N-DOMINANT PATTERNS (Noise)
# =============================================================================

# N-dominant + κ strong + Stable → Noise problem, not encoding
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Encodings work fine, but input has noise - filter it",
    micro_adjustments={'noise_threshold': 0.3}
)

# N-dominant + κ weak → Both noise AND bad encoding
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.VISION_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,  # Filter noise first
    rationale="Noise + vision encoding issue, filter noise then reassess encoding",
    micro_adjustments={'noise_threshold': 0.3, 'vision_weight': 0.3}
)

# =============================================================================
# GRID POPULATION: NOISE_COLLAPSED PATTERNS (Asymmetric Safety)
# =============================================================================

# NOISE_COLLAPSED + Any κ + Stable → UNSAFE (asymmetric trigger)
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: N > R×0.8, approaching collapse threshold",
    micro_adjustments={'safety_margin': 0.2}
)

# NOISE_COLLAPSED + κ weak + Stable → Multiple failures
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + all encodings incompatible - unsafe to proceed"
)

# NOISE_COLLAPSED + Unstable → Definite reject
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + highly unstable - multiple safety violations"
)

# =============================================================================
# GRID POPULATION: UNSTABLE PATTERNS (σ > 0.7)
# =============================================================================

# R-dominant + All strong + Highly unstable → Slow down
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.GATE_ADAPTATION,
    rationale="Content and encoding fine but execution unstable - slow down",
    micro_adjustments={'learning_rate': 0.1, 'monitoring_frequency': 2.0}
)

# R-dominant + Vision weak + Highly unstable → Multiple issues
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.VISION_WEAK,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.DEFER_HUMAN,
    rationale="Vision encoding weak AND highly unstable - requires human review",
    micro_adjustments={'vision_weight': 0.2, 'learning_rate': 0.05}
)

# N-dominant + All strong + Highly unstable → Unsafe combination
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.DEFER_HUMAN,
    rationale="Noise dominant AND highly unstable - unsafe to auto-execute",
    micro_adjustments={'noise_threshold': 0.2}
)

# S-dominant + All strong + Highly unstable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.GATE_ADAPTATION,
    rationale="Superfluous content + unstable execution - filter and slow down",
    micro_adjustments={'filtering_strength': 0.7, 'learning_rate': 0.1}
)

# =============================================================================
# GRID POPULATION: BALANCED PATTERNS (No clear dominant component)
# =============================================================================

# Balanced + All strong + Stable → Healthy
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.HEALTHY,
    action=ControlAction.PROCEED,
    rationale="Balanced RSN distribution, strong encoding, stable execution"
)

# Balanced + Vision weak + Stable → Fix vision
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.VISION_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.VISION_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_VISION,
    rationale="Balanced content but vision encoding incompatible",
    micro_adjustments={'vision_weight': 0.3}
)

# Balanced + Text weak + Stable → Fix text
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.TEXT_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_TEXT,
    rationale="Balanced content but text encoding incompatible",
    micro_adjustments={'text_weight': 0.3}
)

# Balanced + All weak + Stable → Re-encode all
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.GEOMETRY_MISMATCH,
    action=ControlAction.RE_ENCODE,
    rationale="Balanced content but all encodings incompatible"
)

# Balanced + All strong + Highly unstable → Instability issue
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.GATE_ADAPTATION,
    rationale="Balanced and compatible but highly unstable - slow down",
    micro_adjustments={'learning_rate': 0.1}
)

# =============================================================================
# GRID POPULATION: ADDITIONAL R-DOMINANT PATTERNS
# =============================================================================

# R-dominant + All strong + Variance-driven instability
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.VARIANCE_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.PROCEED_CAUTIOUS,
    rationale="Good quality but variance-driven instability - monitor closely",
    micro_adjustments={'monitoring_frequency': 1.5}
)

# R-dominant + Text weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.TEXT_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_TEXT,
    rationale="Good content but text encoding incompatible with solver",
    micro_adjustments={'text_weight': 0.3, 'vision_weight': 0.9}
)

# R-dominant + Multiple weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.MULTIPLE_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.GEOMETRY_MISMATCH,
    action=ControlAction.RE_ENCODE,
    rationale="Good content but multiple encoding modalities incompatible"
)

# R-dominant + Interface weak + Stable (already exists, duplicate for completeness)

# R-dominant + Unavailable κ + Stable → Use fallback
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.HEALTHY,
    action=ControlAction.PROCEED,
    rationale="Good content, no κ metadata available, stable execution"
)

# =============================================================================
# GRID POPULATION: ADDITIONAL S-DOMINANT PATTERNS
# =============================================================================

# S-dominant + Text weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous content + text encoding issue, filter then reassess",
    micro_adjustments={'filtering_strength': 0.6, 'text_weight': 0.4}
)

# S-dominant + All weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous content + all encodings weak, filter first priority",
    micro_adjustments={'filtering_strength': 0.7}
)

# S-dominant + All strong + Variance-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.VARIANCE_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous content + variance instability, filter and monitor",
    micro_adjustments={'filtering_strength': 0.6, 'monitoring_frequency': 1.5}
)

# =============================================================================
# GRID POPULATION: ADDITIONAL N-DOMINANT PATTERNS
# =============================================================================

# N-dominant + Text weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Noise + text encoding issue, filter noise then reassess",
    micro_adjustments={'noise_threshold': 0.3, 'text_weight': 0.3}
)

# N-dominant + All weak + Stable → Multiple failures
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.DEFER_HUMAN,
    rationale="Noise dominant + all encodings weak - requires human review",
)

# N-dominant + All strong + Variance-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.VARIANCE_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Noise + variance instability, filter with elevated monitoring",
    micro_adjustments={'noise_threshold': 0.25, 'monitoring_frequency': 1.5}
)

# =============================================================================
# GRID POPULATION: ADDITIONAL NOISE_COLLAPSED PATTERNS
# =============================================================================

# NOISE_COLLAPSED + Text weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed + text encoding weak",
)

# NOISE_COLLAPSED + Vision weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.VISION_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed + vision encoding weak",
)

# NOISE_COLLAPSED + Multiple weak + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.MULTIPLE_WEAK,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + multiple encodings weak - unsafe",
)

# NOISE_COLLAPSED + All strong + Variance-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.VARIANCE_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed + variance instability",
    micro_adjustments={'safety_margin': 0.3}
)

# NOISE_COLLAPSED + All weak + Variance-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.VARIANCE_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + all encodings weak + unstable - total failure",
)

# NOISE_COLLAPSED + All weak + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + all encodings weak + trajectory divergence",
)

# NOISE_COLLAPSED + All weak + Entropy-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.ENTROPY_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise collapsed + all encodings weak + distributional uncertainty",
)

# =============================================================================
# GRID POPULATION: SINGLE-MODAL PATTERNS (κ UNAVAILABLE)
# =============================================================================

# R-dominant + Unavailable + Highly unstable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.GATE_ADAPTATION,
    rationale="Good content but highly unstable, no κ metadata - slow down",
    micro_adjustments={'learning_rate': 0.1}
)

# N-dominant + Unavailable + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Noise dominant, no κ metadata - filter noise",
    micro_adjustments={'noise_threshold': 0.3}
)

# S-dominant + Unavailable + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous content, no κ metadata - filter",
    micro_adjustments={'filtering_strength': 0.6}
)

# NOISE_COLLAPSED + Unavailable + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed, no κ metadata",
)

# Balanced + Unavailable + Stable
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.UNAVAILABLE,
    SigmaPattern.STABLE
)] = PolicySpec(
    degradation=DegradationType.HEALTHY,
    action=ControlAction.PROCEED_CAUTIOUS,
    rationale="Balanced RSN, no κ metadata, stable - proceed with monitoring"
)

# =============================================================================
# GRID POPULATION: GROWTH-DRIVEN INSTABILITY PATTERNS
# =============================================================================

# R-dominant + All strong + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.PROCEED_CAUTIOUS,
    rationale="Good quality but trajectory divergence - monitor closely",
    micro_adjustments={'monitoring_frequency': 2.0}
)

# N-dominant + All strong + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Noise + trajectory divergence - filter and monitor",
    micro_adjustments={'noise_threshold': 0.25, 'monitoring_frequency': 2.0}
)

# S-dominant + All strong + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous + trajectory divergence - filter and monitor",
    micro_adjustments={'filtering_strength': 0.6, 'monitoring_frequency': 2.0}
)

# =============================================================================
# GRID POPULATION: ENTROPY-DRIVEN INSTABILITY PATTERNS
# =============================================================================

# R-dominant + All strong + Entropy-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.ENTROPY_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.UNSTABLE,
    action=ControlAction.PROCEED_CAUTIOUS,
    rationale="Good quality but distributional uncertainty - monitor",
    micro_adjustments={'monitoring_frequency': 1.5}
)

# N-dominant + All strong + Entropy-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.ENTROPY_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.NOISE_DOMINANT,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Noise + distributional uncertainty - filter with monitoring",
    micro_adjustments={'noise_threshold': 0.3, 'monitoring_frequency': 1.5}
)

# S-dominant + All strong + Entropy-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_STRONG,
    SigmaPattern.ENTROPY_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.DISTRACTION,
    action=ControlAction.FILTER_CONTEXT,
    rationale="Superfluous + distributional uncertainty - filter",
    micro_adjustments={'filtering_strength': 0.6, 'monitoring_frequency': 1.5}
)

# NOISE_COLLAPSED + All strong + Entropy-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.ENTROPY_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed + distributional uncertainty",
)

# NOISE_COLLAPSED + All strong + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.NOISE_COLLAPSED,
    KappaPattern.ALL_STRONG,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.NOISE_COLLAPSED,
    action=ControlAction.DEFER_HUMAN,
    rationale="Asymmetric safety: noise collapsed + trajectory divergence",
)

# =============================================================================
# GRID POPULATION: CRITICAL EDGE CASES
# =============================================================================

# R-dominant + All weak + Highly unstable → REJECT (multiple failures)
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="All encodings weak + highly unstable - unsafe despite good content"
)

# N-dominant + All weak + Highly unstable → REJECT
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.N_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="Noise dominant + all encodings weak + highly unstable - total failure"
)

# S-dominant + All weak + Highly unstable → DEFER
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.S_DOMINANT,
    KappaPattern.ALL_WEAK,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.DEFER_HUMAN,
    rationale="Superfluous + all encodings weak + highly unstable"
)

# Balanced + All weak + Highly unstable → REJECT
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.BALANCED,
    KappaPattern.ALL_WEAK,
    SigmaPattern.HIGHLY_UNSTABLE
)] = PolicySpec(
    degradation=DegradationType.TOTAL_FAILURE,
    action=ControlAction.REJECT,
    rationale="All encodings weak + highly unstable - total failure"
)

# R-dominant + Vision weak + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.VISION_WEAK,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.VISION_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_VISION,
    rationale="Vision encoding weak + trajectory divergence - re-encode and monitor",
    micro_adjustments={'vision_weight': 0.3, 'monitoring_frequency': 2.0}
)

# R-dominant + Text weak + Growth-driven
MULTI_DIMENSIONAL_GRID[CollapsePattern(
    RSNPattern.R_DOMINANT,
    KappaPattern.TEXT_WEAK,
    SigmaPattern.GROWTH_DRIVEN
)] = PolicySpec(
    degradation=DegradationType.TEXT_ENCODING_ISSUE,
    action=ControlAction.RE_ENCODE_TEXT,
    rationale="Text encoding weak + trajectory divergence - re-encode and monitor",
    micro_adjustments={'text_weight': 0.3, 'monitoring_frequency': 2.0}
)

# =============================================================================
# SMART FALLBACK POLICY (Safety-First for Unconfigured Patterns)
# =============================================================================

def compute_fallback_policy(
    rsn_pattern: RSNPattern,
    kappa_pattern: KappaPattern,
    sigma_pattern: SigmaPattern
) -> PolicySpec:
    """
    Compute safe fallback policy for unconfigured patterns.

    Safety-first logic:
    1. NOISE_COLLAPSED + anything → DEFER_HUMAN (asymmetric safety)
    2. ALL_WEAK κ + HIGHLY_UNSTABLE → REJECT (multiple failures)
    3. N_DOMINANT + weak κ → FILTER_CONTEXT (noise problem)
    4. HIGHLY_UNSTABLE + weak κ → GATE_ADAPTATION (slow down)
    5. Otherwise → PROCEED_CAUTIOUS (monitor)

    This ensures 68% unconfigured patterns don't blindly proceed.
    """
    # Rule 1: NOISE_COLLAPSED is always dangerous (asymmetric safety)
    if rsn_pattern == RSNPattern.NOISE_COLLAPSED:
        if kappa_pattern == KappaPattern.ALL_WEAK or sigma_pattern == SigmaPattern.HIGHLY_UNSTABLE:
            return PolicySpec(
                degradation=DegradationType.TOTAL_FAILURE,
                action=ControlAction.REJECT,
                rationale=f"FALLBACK: Noise collapsed + {kappa_pattern.name} + {sigma_pattern.name} - total failure"
            )
        else:
            return PolicySpec(
                degradation=DegradationType.NOISE_COLLAPSED,
                action=ControlAction.DEFER_HUMAN,
                rationale=f"FALLBACK: Asymmetric safety - noise collapsed ({kappa_pattern.name}, {sigma_pattern.name})"
            )

    # Rule 2: Multiple failures → REJECT
    if kappa_pattern == KappaPattern.ALL_WEAK and sigma_pattern == SigmaPattern.HIGHLY_UNSTABLE:
        return PolicySpec(
            degradation=DegradationType.TOTAL_FAILURE,
            action=ControlAction.REJECT,
            rationale=f"FALLBACK: All encodings weak + highly unstable ({rsn_pattern.name})"
        )

    # Rule 3: N-dominant → Filter noise (regardless of κ/σ)
    if rsn_pattern == RSNPattern.N_DOMINANT:
        if kappa_pattern in [KappaPattern.ALL_WEAK, KappaPattern.MULTIPLE_WEAK]:
            return PolicySpec(
                degradation=DegradationType.NOISE_DOMINANT,
                action=ControlAction.DEFER_HUMAN,
                rationale=f"FALLBACK: Noise dominant + weak encodings ({kappa_pattern.name}, {sigma_pattern.name})"
            )
        else:
            return PolicySpec(
                degradation=DegradationType.NOISE_DOMINANT,
                action=ControlAction.FILTER_CONTEXT,
                rationale=f"FALLBACK: Noise dominant - filter ({kappa_pattern.name}, {sigma_pattern.name})",
                micro_adjustments={'noise_threshold': 0.3}
            )

    # Rule 4: HIGHLY_UNSTABLE + weak κ → Slow down
    if sigma_pattern == SigmaPattern.HIGHLY_UNSTABLE:
        if kappa_pattern in [KappaPattern.ALL_WEAK, KappaPattern.MULTIPLE_WEAK]:
            return PolicySpec(
                degradation=DegradationType.UNSTABLE,
                action=ControlAction.DEFER_HUMAN,
                rationale=f"FALLBACK: Highly unstable + weak encodings ({rsn_pattern.name}, {kappa_pattern.name})"
            )
        else:
            return PolicySpec(
                degradation=DegradationType.UNSTABLE,
                action=ControlAction.GATE_ADAPTATION,
                rationale=f"FALLBACK: Highly unstable - slow down ({rsn_pattern.name}, {kappa_pattern.name})",
                micro_adjustments={'learning_rate': 0.1}
            )

    # Rule 5: S-dominant → Filter (regardless of κ/σ)
    if rsn_pattern == RSNPattern.S_DOMINANT:
        return PolicySpec(
            degradation=DegradationType.DISTRACTION,
            action=ControlAction.FILTER_CONTEXT,
            rationale=f"FALLBACK: Superfluous content - filter ({kappa_pattern.name}, {sigma_pattern.name})",
            micro_adjustments={'filtering_strength': 0.6}
        )

    # Rule 6: ALL_WEAK κ → Re-encode (regardless of RSN/σ)
    if kappa_pattern == KappaPattern.ALL_WEAK:
        return PolicySpec(
            degradation=DegradationType.GEOMETRY_MISMATCH,
            action=ControlAction.RE_ENCODE,
            rationale=f"FALLBACK: All encodings weak - re-encode ({rsn_pattern.name}, {sigma_pattern.name})"
        )

    # Rule 7: MULTIPLE_WEAK or single weak → Targeted re-encode
    if kappa_pattern == KappaPattern.MULTIPLE_WEAK:
        return PolicySpec(
            degradation=DegradationType.GEOMETRY_MISMATCH,
            action=ControlAction.RE_ENCODE,
            rationale=f"FALLBACK: Multiple encodings weak ({rsn_pattern.name}, {sigma_pattern.name})"
        )

    if kappa_pattern == KappaPattern.TEXT_WEAK:
        return PolicySpec(
            degradation=DegradationType.TEXT_ENCODING_ISSUE,
            action=ControlAction.RE_ENCODE_TEXT,
            rationale=f"FALLBACK: Text encoding weak ({rsn_pattern.name}, {sigma_pattern.name})",
            micro_adjustments={'text_weight': 0.3}
        )

    if kappa_pattern == KappaPattern.VISION_WEAK:
        return PolicySpec(
            degradation=DegradationType.VISION_ENCODING_ISSUE,
            action=ControlAction.RE_ENCODE_VISION,
            rationale=f"FALLBACK: Vision encoding weak ({rsn_pattern.name}, {sigma_pattern.name})",
            micro_adjustments={'vision_weight': 0.3}
        )

    if kappa_pattern == KappaPattern.INTERFACE_WEAK:
        return PolicySpec(
            degradation=DegradationType.FUSION_ISSUE,
            action=ControlAction.RE_ENCODE_FUSION,
            rationale=f"FALLBACK: Interface weak ({rsn_pattern.name}, {sigma_pattern.name})",
            micro_adjustments={'fusion_strength': 0.3}
        )

    # Rule 8: Default safe fallback (only reached for benign combinations)
    # Examples: R_DOMINANT + ALL_STRONG + variance-driven (not critical)
    return PolicySpec(
        degradation=DegradationType.HEALTHY,
        action=ControlAction.PROCEED_CAUTIOUS,
        rationale=f"FALLBACK: Pattern not critical ({rsn_pattern.name}, {kappa_pattern.name}, {sigma_pattern.name})"
    )


# =============================================================================
# SUPERVISORY CONTROLLER (Patent [0371])
# =============================================================================

@dataclass(frozen=True)
class PolicyDecision:
    """
    Immutable supervisory decision record.

    Includes both the discrete policy (what to do) and continuous
    micro-adjustments (how much to adjust parameters).
    """
    degradation: DegradationType
    action: ControlAction
    rationale: str

    # Pattern classification (for diagnostics)
    rsn_pattern: RSNPattern
    kappa_pattern: KappaPattern
    sigma_pattern: SigmaPattern

    # Micro-level adjustments (Patent [0374])
    micro_adjustments: Optional[Dict[str, float]] = None

    def to_dict(self) -> Dict:
        return {
            'degradation': self.degradation.name,
            'action': self.action.name,
            'rationale': self.rationale,
            'patterns': {
                'rsn': self.rsn_pattern.name,
                'kappa': self.kappa_pattern.name,
                'sigma': self.sigma_pattern.name,
            },
            'micro_adjustments': self.micro_adjustments or {}
        }


class SupervisoryController:
    """
    Multi-dimensional classification grid (Patent [0371]).

    Classifies certificate patterns and selects execution policy.
    NO single gate kills - only specific COMBINATIONS trigger REJECT.

    Architecture:
      Certificate (with vectors) → Pattern Identification → Grid Lookup → Policy

    Example Flow:
      RSN=(R=0.8, S=0.1, N=0.1) → R_DOMINANT
      κ_modal=(text=0.9, vision=0.2, interface=0.95) → VISION_WEAK
      σ_vector=(0.3, 0.2, 0.1) → STABLE

      Pattern=(R_DOMINANT, VISION_WEAK, STABLE)
      → Policy: RE_ENCODE_VISION (fix vision, content is good)
    """

    def __init__(
        self,
        asymmetric_threshold: float = 0.8,
        kappa_weak_threshold: float = 0.3,
        sigma_high_threshold: float = 0.7
    ):
        self.asymmetric_threshold = asymmetric_threshold
        self.kappa_weak_threshold = kappa_weak_threshold
        self.sigma_high_threshold = sigma_high_threshold

    def classify(self, certificate) -> PolicyDecision:
        """
        Classify certificate pattern and return policy decision.

        Args:
            certificate: YRSNCertificate with vector components

        Returns:
            PolicyDecision with action and micro-adjustments
        """
        # Extract patterns from certificate vectors
        rsn_pattern = identify_rsn_pattern(
            certificate.integrity_rsn,
            self.asymmetric_threshold
        )

        kappa_pattern = identify_kappa_pattern(
            certificate.kappa_modal,
            self.kappa_weak_threshold
        )

        sigma_pattern = identify_sigma_pattern(
            certificate.sigma_vector,
            certificate.sigma,
            self.sigma_high_threshold
        )

        # Create pattern key
        pattern = CollapsePattern(rsn_pattern, kappa_pattern, sigma_pattern)

        # Grid lookup with smart fallback
        if pattern in MULTI_DIMENSIONAL_GRID:
            policy = MULTI_DIMENSIONAL_GRID[pattern]
            logger.info(
                f"Pattern classified (GRID): RSN={rsn_pattern.name}, "
                f"κ={kappa_pattern.name}, σ={sigma_pattern.name} "
                f"→ {policy.action.name}"
            )
        else:
            # Unconfigured pattern - use smart fallback
            policy = compute_fallback_policy(rsn_pattern, kappa_pattern, sigma_pattern)
            logger.warning(
                f"Pattern classified (FALLBACK): RSN={rsn_pattern.name}, "
                f"κ={kappa_pattern.name}, σ={sigma_pattern.name} "
                f"→ {policy.action.name} | {policy.rationale}"
            )

        # Return decision
        return PolicyDecision(
            degradation=policy.degradation,
            action=policy.action,
            rationale=policy.rationale,
            rsn_pattern=rsn_pattern,
            kappa_pattern=kappa_pattern,
            sigma_pattern=sigma_pattern,
            micro_adjustments=policy.micro_adjustments
        )


# =============================================================================
# GRID COMPLETENESS CHECK
# =============================================================================

def check_grid_completeness() -> Dict[str, any]:
    """
    Verify that common pattern combinations are configured.
    Returns diagnostics about grid coverage.
    """
    total_combinations = (
        len(RSNPattern) * len(KappaPattern) * len(SigmaPattern)
    )
    configured_combinations = len(MULTI_DIMENSIONAL_GRID)

    coverage_pct = (configured_combinations / total_combinations) * 100

    return {
        'total_possible': total_combinations,
        'configured': configured_combinations,
        'coverage_pct': coverage_pct,
        'uses_fallback': total_combinations - configured_combinations,
        'status': 'COMPLETE' if coverage_pct > 50 else 'PARTIAL'
    }


def analyze_fallback_safety() -> Dict[str, any]:
    """
    Analyze fallback policy decisions for all unconfigured patterns.

    Returns safety metrics:
    - How many patterns would REJECT
    - How many would DEFER_HUMAN
    - How many would PROCEED_CAUTIOUS
    - Most dangerous unconfigured patterns
    """
    fallback_actions = {
        'REJECT': [],
        'DEFER_HUMAN': [],
        'GATE_ADAPTATION': [],
        'FILTER_CONTEXT': [],
        'RE_ENCODE': [],
        'RE_ENCODE_TEXT': [],
        'RE_ENCODE_VISION': [],
        'RE_ENCODE_FUSION': [],
        'PROCEED_CAUTIOUS': [],
    }

    for rsn in RSNPattern:
        for kappa in KappaPattern:
            for sigma in SigmaPattern:
                pattern = CollapsePattern(rsn, kappa, sigma)

                # Check if unconfigured
                if pattern not in MULTI_DIMENSIONAL_GRID:
                    policy = compute_fallback_policy(rsn, kappa, sigma)
                    action_name = policy.action.name
                    fallback_actions[action_name].append({
                        'rsn': rsn.name,
                        'kappa': kappa.name,
                        'sigma': sigma.name,
                        'rationale': policy.rationale
                    })

    # Compute safety metrics
    total_unconfigured = sum(len(v) for v in fallback_actions.values())
    reject_count = len(fallback_actions['REJECT'])
    defer_count = len(fallback_actions['DEFER_HUMAN'])
    safe_count = reject_count + defer_count  # Conservative actions

    return {
        'total_unconfigured': total_unconfigured,
        'reject_count': reject_count,
        'defer_count': defer_count,
        'safe_actions': safe_count,
        'safety_pct': (safe_count / total_unconfigured * 100) if total_unconfigured > 0 else 0,
        'action_breakdown': {k: len(v) for k, v in fallback_actions.items()},
        'most_dangerous': fallback_actions['REJECT'][:5],  # First 5 REJECT patterns
    }


if __name__ == "__main__":
    # Diagnostic output
    stats = check_grid_completeness()
    print("Multi-Dimensional Grid Statistics:")
    print(f"  Total combinations: {stats['total_possible']}")
    print(f"  Configured: {stats['configured']}")
    print(f"  Coverage: {stats['coverage_pct']:.1f}%")
    print(f"  Uses fallback: {stats['uses_fallback']}")
    print(f"  Status: {stats['status']}")
