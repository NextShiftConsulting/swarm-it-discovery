"""
YRSN Topology Cache - Cached H₁ Betti Number Validation

Provides performant topology validation by caching H₁ loop counts
and using adaptive sampling to reduce ripser computation frequency.

Performance targets:
- Cached validation: <20ms
- Full validation: <100ms
- Cache hit rate: >90% in stable operation

The cache uses a simple strategy:
1. If coordinates are "close" to cached coordinates, return cached result
2. Otherwise, compute new H₁ count and cache it
3. Invalidation on large drift or explicit request

Usage:
    from yrsn.core.enforcement.topology_cache import TopologyCache

    cache = TopologyCache()

    # Get H₁ count (may use cache)
    h1_count = cache.get_h1_count(t4_coords)

    # Check if valid T⁴ topology
    is_valid = cache.validate_topology(t4_coords)  # h1 >= 4

Reference:
    series_005/expS5_001d_final_validation.py (validation methodology)
"""

import time
from typing import Optional, Tuple
from dataclasses import dataclass, field
import numpy as np

# Try to import ripser - optional dependency
try:
    from ripser import ripser
    RIPSER_AVAILABLE = True
except ImportError:
    RIPSER_AVAILABLE = False


@dataclass
class CacheEntry:
    """Single cache entry for topology validation."""
    t4_centroid: np.ndarray          # Centroid of cached point cloud
    h1_count: int                    # Cached H₁ loop count
    timestamp: float                 # When cached
    computation_time_ms: float       # How long validation took


class TopologyCache:
    """
    Cached H₁ Betti number validation for T⁴ topology.

    Uses adaptive caching to avoid recomputing ripser on every inference:
    - Caches result if new coordinates are "close" to cached centroid
    - Invalidates on large drift or explicit request
    - Falls back to assumed-valid if ripser not installed

    Attributes:
        _cache: Current cache entry (or None)
        _distance_threshold: Max distance to use cached result
        _persistence_threshold: Minimum persistence for H₁ features
        _max_edge_length: Maximum edge length for Rips complex
    """

    def __init__(
        self,
        distance_threshold: float = 0.3,
        persistence_threshold: float = 0.1,
        max_edge_length: float = 0.5,
    ):
        """
        Initialize the topology cache.

        Args:
            distance_threshold: Max centroid distance to use cache
            persistence_threshold: Min persistence for H₁ features
            max_edge_length: Max edge length for Rips complex
        """
        self._cache: Optional[CacheEntry] = None
        self._distance_threshold = distance_threshold
        self._persistence_threshold = persistence_threshold
        self._max_edge_length = max_edge_length

        # Stats
        self._cache_hits = 0
        self._cache_misses = 0
        self._total_time_ms = 0.0

    def get_h1_count(self, t4_coords: np.ndarray) -> int:
        """
        Get H₁ loop count for coordinates.

        Args:
            t4_coords: T⁴ coordinates [N, 4] or [4] for single point

        Returns:
            Number of significant H₁ loops (4 = valid T⁴)

        Note:
            Returns 4 if ripser not installed (assume valid).
        """
        if not RIPSER_AVAILABLE:
            return 4  # Assume valid

        # Ensure 2D array
        if t4_coords.ndim == 1:
            t4_coords = t4_coords.reshape(1, -1)

        # Check cache
        if self._can_use_cache(t4_coords):
            self._cache_hits += 1
            return self._cache.h1_count

        # Compute new
        self._cache_misses += 1
        h1_count, compute_time = self._compute_h1(t4_coords)

        # Update cache
        centroid = np.mean(t4_coords, axis=0)
        self._cache = CacheEntry(
            t4_centroid=centroid,
            h1_count=h1_count,
            timestamp=time.time(),
            computation_time_ms=compute_time,
        )
        self._total_time_ms += compute_time

        return h1_count

    def validate_topology(self, t4_coords: np.ndarray) -> bool:
        """
        Validate that coordinates form valid T⁴ topology.

        Args:
            t4_coords: T⁴ coordinates [N, 4]

        Returns:
            True if H₁ >= 4 (valid T⁴)
        """
        h1_count = self.get_h1_count(t4_coords)
        return h1_count >= 4

    def _can_use_cache(self, t4_coords: np.ndarray) -> bool:
        """Check if cache can be used for these coordinates."""
        if self._cache is None:
            return False

        # Compute centroid of new coords
        centroid = np.mean(t4_coords, axis=0)

        # Check distance to cached centroid
        distance = np.linalg.norm(centroid - self._cache.t4_centroid)
        return distance < self._distance_threshold

    def _compute_h1(self, t4_coords: np.ndarray) -> Tuple[int, float]:
        """
        Compute H₁ loop count using ripser.

        Args:
            t4_coords: T⁴ coordinates [N, 4]

        Returns:
            (h1_count, computation_time_ms)
        """
        start = time.perf_counter()

        # Normalize coordinates to [0, 1]^4
        t4_normalized = self._normalize_coords(t4_coords)

        # Compute persistence diagram
        result = ripser(
            t4_normalized,
            maxdim=1,
            thresh=self._max_edge_length,
        )

        # Count significant H₁ features
        dgm = result['dgms'][1]  # H₁ diagram
        h1_count = self._count_significant_h1(dgm)

        compute_time = (time.perf_counter() - start) * 1000
        return h1_count, compute_time

    def _normalize_coords(self, t4_coords: np.ndarray) -> np.ndarray:
        """Normalize coordinates to [0, 1]^4."""
        # T⁴ coordinate ranges (CORRECTED v2.6 - DO NOT REVERT):
        # simplex_theta: [0, 360) degrees
        # phi_simplex:   [0, 360) degrees
        # alpha:         [0, 180] degrees (arccos range for quality)
        # omega:         [0, 90]  degrees (arccos range for OOD confidence)
        #
        # CRITICAL: omega is 90, NOT 180!
        # Mathematical proof: omega = arccos(x) * 180/π where x ∈ [0,1]
        # Since arccos([0,1]) = [0, π/2] radians, result is [0°, 90°]
        ranges = np.array([360.0, 360.0, 180.0, 90.0])  # CORRECTED: omega = 90
        return t4_coords / ranges

    def _count_significant_h1(self, dgm: np.ndarray) -> int:
        """
        Count H₁ features with persistence > threshold.

        Args:
            dgm: Persistence diagram [N, 2] with (birth, death)

        Returns:
            Number of significant H₁ loops
        """
        if len(dgm) == 0:
            return 0

        # Compute persistence
        persistence = dgm[:, 1] - dgm[:, 0]

        # Filter finite values
        finite_mask = np.isfinite(persistence)
        finite_persistence = persistence[finite_mask]

        # Count significant features
        return int(np.sum(finite_persistence > self._persistence_threshold))

    def clear(self) -> None:
        """Clear the cache."""
        self._cache = None

    def get_stats(self) -> dict:
        """Get cache statistics."""
        total = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total if total > 0 else 0.0

        return {
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "hit_rate": hit_rate,
            "total_compute_time_ms": self._total_time_ms,
            "avg_compute_time_ms": self._total_time_ms / self._cache_misses if self._cache_misses > 0 else 0.0,
            "ripser_available": RIPSER_AVAILABLE,
        }


__all__ = ["TopologyCache", "RIPSER_AVAILABLE"]
