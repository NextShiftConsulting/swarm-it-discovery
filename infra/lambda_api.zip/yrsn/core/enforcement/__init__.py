"""
YRSN Enforcement Layer - Unified Enforcement Engine

This module provides the unified enforcement layer for the Context Integrity ISA:
- UnifiedEnforcementEngine: Consolidated monitoring + decision + stability
- Failure codes (E1xx/E2xx/E3xx) for topology, drift, and invariant violations
- TopologyCache for performant H₁ validation
- SupervisoryController: Multi-dimensional classification grid (Patent §V.C.6.1)

Usage:
    from yrsn.core.enforcement import UnifiedEnforcementEngine
    from yrsn.core.certificate import YRSNCertificate

    # Create unified engine
    engine = UnifiedEnforcementEngine(driving_mode=DrivingMode.SPORT)
    engine.set_baseline(baseline_score)

    # Enforce with certificate
    cert = YRSNCertificate(R=0.8, S=0.15, N=0.05, alpha=0.8, omega=0.9, tau=1.2)
    result = engine.enforce_certificate(cert)
    if result.authorized:
        print(f"Gear: {result.current_gear.value}")

Archived (2026-02-17):
    - EnforcementEngine → archive_results/enforcement_deprecated_20260217/
    - UnifiedQualityController → archive_results/enforcement_deprecated_20260217/

    See docs/enforcement/MIGRATION_GUIDE.md for migration path.
"""

from yrsn.core.enforcement.failure_codes import (
    FailureCategory,
    FailureCode,
    FailureSeverity,
    GearboxAction,
    FailureResponse,
    FAILURE_RESPONSES,
    get_failure_response,
    classify_drift_failure,
    classify_betti_failure,
)
from yrsn.core.enforcement.unified_enforcement_engine import (
    UnifiedEnforcementEngine,
    UnifiedEnforcementTelemetry,
    ControlDecision,
    DegradationType,
    ControlAction,
    GearState,
    tau_to_gear,
)
from yrsn.core.enforcement.supervisory_controller import (
    SupervisoryController,
    PolicyDecision,
    RSNPattern,
    KappaPattern,
    SigmaPattern,
)
from yrsn.core.enforcement.topology_cache import (
    TopologyCache,
    RIPSER_AVAILABLE,
)

__all__ = [
    # Enums
    "FailureCategory",
    "FailureCode",
    "FailureSeverity",
    "GearboxAction",
    "DegradationType",
    "ControlAction",
    "GearState",
    "RSNPattern",
    "KappaPattern",
    "SigmaPattern",
    # Dataclasses
    "FailureResponse",
    "UnifiedEnforcementTelemetry",
    "ControlDecision",
    "PolicyDecision",
    # Registry
    "FAILURE_RESPONSES",
    # Controllers
    "UnifiedEnforcementEngine",
    "SupervisoryController",
    "TopologyCache",
    "RIPSER_AVAILABLE",
    # Functions
    "get_failure_response",
    "classify_drift_failure",
    "classify_betti_failure",
    "tau_to_gear",
]
