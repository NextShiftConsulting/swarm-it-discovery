"""
Invariant Specification for Context Quality ISA (CQ-ISA™) - OP02: INV_LOAD.

This module FORMALIZES existing validation behavior into a named, typed,
portable operation for the Context Integrity ISA.

Gap Analysis:
    You already do this: Assume constraints (R+S+N=1, bounds, etc.)
    What's missing: No invariant object or loader

This module EXTRACTS scattered constraints into a single InvariantSpec object.

Hex Architecture: CORE DOMAIN
- Defines WHAT invariants are (not HOW they're stored)
- No infrastructure dependency
- Immutable (frozen dataclass)

Spec: docs/api/specifications/CONTEXT_QUALITY_ISA_v0.1.md OP02
"""

from dataclasses import dataclass, field
from typing import Final, Tuple, Optional
from yrsn.core.monitoring.drift_monitor import DriftThresholds


@dataclass(frozen=True)  # Immutable
class InvariantSpec:
    """
    Invariant specification for Context Quality ISA (CQ-ISA™) - OP02: INV_LOAD.

    FORMALIZES existing validation constraints into ISA-compliant operation.

    This object consolidates scattered thresholds that are ALREADY USED
    throughout the codebase:
    - Drift thresholds (0.2, 0.5, 1.5) from DriftThresholds
    - Simplex tolerance (1e-6) from signal_validator.py
    - Genus target (4) from T⁴ topology definition
    - Coherence floor (0.3) from phasor coherence validation

    DO NOT make these configurable without re-running S4 calibration suite.
    See: docs/experiments/S4_CALIBRATION.md

    Attributes:
        drift_thresholds: T⁴ chordal distance thresholds (wrapped from DriftThresholds)
        simplex_eps: E301 tolerance for |R+S+N-1| constraint
        genus_target: H₁ Betti number for T⁴ topology (4-loop torus)
        coherence_floor: E302 threshold (minimum phasor coherence ω)
    """

    # =========================================================================
    # DRIFT THRESHOLDS (Wrapped from DriftThresholds)
    # =========================================================================
    # From: src/yrsn/core/monitoring/drift_monitor.py
    drift_thresholds: DriftThresholds = field(default_factory=DriftThresholds)

    # =========================================================================
    # SIMPLEX CONSTRAINT (Mathematical)
    # =========================================================================
    # From: src/yrsn/core/enforcement/failure_codes.py:65
    simplex_eps: float = 1e-6          # E301: |R+S+N-1| tolerance

    # =========================================================================
    # TOPOLOGY CONSTRAINT (T⁴ definition)
    # =========================================================================
    # From: T⁴ manifold definition (4-torus = 4 independent loops)
    genus_target: int = 4              # H₁ Betti number

    # =========================================================================
    # COHERENCE THRESHOLD (S4-calibrated)
    # =========================================================================
    # From: phasor coherence validation (empirical)
    coherence_floor: float = 0.3       # E302: Minimum phasor coherence (ω)

    # =========================================================================
    # CONVENIENCE PROPERTIES
    # =========================================================================

    @property
    def drift_phase_slip(self) -> float:
        """E201 threshold (phase slip detection)."""
        return self.drift_thresholds.nominal_max

    @property
    def drift_boundary(self) -> float:
        """E203 threshold (boundary proximity)."""
        return self.drift_thresholds.jitter_max

    @property
    def drift_collapse(self) -> float:
        """E204 threshold (Lyapunov collapse)."""
        return self.drift_thresholds.drift_max

    @property
    def drift_values(self) -> Tuple[float, float, float]:
        """Return (phase_slip, boundary, collapse) thresholds."""
        return (
            self.drift_phase_slip,
            self.drift_boundary,
            self.drift_collapse
        )

    @property
    def failure_code_map(self) -> dict:
        """Map thresholds to E-codes."""
        return {
            'E201': self.drift_phase_slip,
            'E203': self.drift_boundary,
            'E204': self.drift_collapse,
            'E301': self.simplex_eps,
            'E302': self.coherence_floor,
        }

    # =========================================================================
    # FACTORY METHODS
    # =========================================================================

    @classmethod
    def from_defaults(cls) -> "InvariantSpec":
        """
        Production defaults (S4-calibrated).

        Use this for production deployments.
        """
        return cls()

    @classmethod
    def for_domain(cls, domain: str) -> "InvariantSpec":
        """
        Domain-specific invariants.

        Different domains have different safety envelopes:
        - robotics: Stricter (safety-critical)
        - academic: Looser (exploratory research)
        - adversarial: Conservative (fast downgrade)

        Args:
            domain: Domain name ("robotics", "academic", "adversarial", "production")

        Returns:
            InvariantSpec tuned for domain

        Example:
            >>> robotics_inv = InvariantSpec.for_domain("robotics")
            >>> print(robotics_inv.drift_collapse)
            1.2
        """
        if domain == "robotics":
            # Stricter thresholds (safety-critical)
            return cls(
                drift_thresholds=DriftThresholds(
                    nominal_max=0.15,    # Earlier warning
                    jitter_max=0.4,      # Earlier alert
                    drift_max=1.2,       # Earlier collapse detection
                ),
                coherence_floor=0.4,     # Higher coherence requirement
            )
        elif domain == "academic":
            # Looser thresholds (exploratory)
            return cls(
                drift_thresholds=DriftThresholds(
                    nominal_max=0.25,    # More tolerance
                    jitter_max=0.6,      # More tolerance
                    drift_max=2.0,       # More tolerance
                ),
                coherence_floor=0.2,     # Lower coherence requirement
            )
        elif domain == "adversarial":
            # Conservative thresholds (fast response)
            return cls(
                drift_thresholds=DriftThresholds(
                    nominal_max=0.15,    # Earlier phase slip detection
                    jitter_max=0.4,      # Earlier boundary proximity
                    drift_max=1.3,       # Earlier collapse
                ),
                coherence_floor=0.35,    # Higher coherence requirement
            )
        else:
            # Default: production settings
            return cls()

    # =========================================================================
    # VALIDATION HELPERS
    # =========================================================================

    def validate_certificate(self, R: float, S: float, N: float, omega: float) -> list:
        """
        Validate certificate against invariants.

        Returns list of E-codes (empty if all pass).

        Example:
            >>> inv = InvariantSpec.from_defaults()
            >>> failures = inv.validate_certificate(R=0.6, S=0.3, N=0.1, omega=0.8)
            >>> failures
            []
        """
        failures = []

        # E301: Simplex constraint
        if abs(R + S + N - 1.0) > self.simplex_eps:
            failures.append('E301')

        # E302: Coherence floor
        if omega < self.coherence_floor:
            failures.append('E302')

        return failures

    def classify_drift_phase(self, distance: float):
        """
        Classify drift distance into operational phase.

        Delegates to DriftThresholds.classify().

        Returns:
            DriftPhase (NOMINAL, JITTER, DRIFT, COLLAPSE)

        Example:
            >>> inv = InvariantSpec.from_defaults()
            >>> phase = inv.classify_drift_phase(0.3)
            >>> phase.value
            'jitter'
        """
        return self.drift_thresholds.classify(distance)


# =============================================================================
# DOMAIN PRESETS (Factory shortcuts)
# =============================================================================

ROBOTICS_INVARIANTS = InvariantSpec.for_domain("robotics")
ACADEMIC_INVARIANTS = InvariantSpec.for_domain("academic")
ADVERSARIAL_INVARIANTS = InvariantSpec.for_domain("adversarial")
PRODUCTION_INVARIANTS = InvariantSpec.from_defaults()


__all__ = [
    'InvariantSpec',
    'ROBOTICS_INVARIANTS',
    'ACADEMIC_INVARIANTS',
    'ADVERSARIAL_INVARIANTS',
    'PRODUCTION_INVARIANTS',
]
