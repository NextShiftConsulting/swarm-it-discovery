"""
Cognitive Engine - Unifies Sequence (reasoning) with State (temperature).

This module connects three previously disconnected systems:
1. Bloom's Taxonomy → Phase Controller (sets base temperature)
2. Constraint Tension → Energy E (conflict magnitude)
3. Reasoning Traces → Signal Quality α (trace coherence)

The Unified Cognitive Loop:
    ┌─────────────────────────────────────────────────────────────────────┐
    │                         Cognitive Engine                            │
    ├─────────────────────────────────────────────────────────────────────┤
    │                                                                     │
    │  Task ──→ [BloomClassifier] ──→ Base Phase (τ₀)                    │
    │                                      ↓                              │
    │  Constraints ──→ [EnergyCalculator] ──→ Energy E (tension)         │
    │                                              ↓                      │
    │  Trace ──→ [TraceAnalyzer] ──→ Quality α (coherence)               │
    │                                      ↓                              │
    │                            ┌─────────────────────┐                  │
    │                            │ AdaptiveConfig      │                  │
    │                            │ τ = f(α, E, τ₀)     │                  │
    │                            └─────────┬───────────┘                  │
    │                                      ↓                              │
    │                              Final Temperature τ                    │
    │                                                                     │
    │  Boltzmann: P(x) ∝ exp(-E(x)/τ)                                    │
    │  Low τ → Exploitation (greedy)                                     │
    │  High τ → Exploration (sampling)                                   │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

Physics Mapping:
    - Bloom Level → Phase (Deterministic vs Creative)
    - Constraint Friction → System Energy E
    - Trace Coherence → Signal Quality α
    - Temperature τ = f(α) modulated by E and Bloom phase

Author: YRSN Framework (Rudy Martin)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Tuple, Union
from enum import Enum
import numpy as np

from .adaptive_config import (
    AdaptiveTemperatureConfig,
    QualityPhase,
    CollapseType,
    Stream,
    TemperatureResult,
    production_config,
)

from .protocols import QualitySignals, YRSNDecomposition


# =============================================================================
# BLOOM PHASE CONTROLLER
# =============================================================================

class BloomLevel(Enum):
    """Bloom's Taxonomy levels mapped to temperature phases."""
    REMEMBER = 1      # Retrieve facts, encode state → Low τ
    ANALYZE = 2       # Find patterns, decompose → Medium τ
    EVALUATE = 3      # Judge, compare, critique → Medium-High τ
    CREATE = 4        # Synthesize, design, invent → High τ


@dataclass
class BloomPhaseController:
    """
    Maps Bloom's Taxonomy to temperature phases.

    Low Bloom (Remember/Analyze) → Phase I (Low τ)
        - Tasks: fact retrieval, constraint encoding, pattern matching
        - Action: Force τ < 1.43 (exploitation/greedy)

    High Bloom (Evaluate/Create) → Phase III (High τ)
        - Tasks: judgment, synthesis, novel solutions
        - Action: Force τ > 2.50 (exploration/sampling)
    """

    # Phase boundaries (from research)
    TAU_DETERMINISTIC = 1.43    # Below: deterministic/greedy
    TAU_STOCHASTIC = 2.50       # Above: stochastic/sampling

    # Bloom level → base temperature mapping
    BLOOM_TAU_MAP = {
        BloomLevel.REMEMBER: 0.5,    # Very tight - just retrieve
        BloomLevel.ANALYZE: 1.0,     # Moderate - find patterns
        BloomLevel.EVALUATE: 2.0,    # Loose - compare options
        BloomLevel.CREATE: 3.5,      # Very loose - explore solutions
    }

    def classify_task(self, task_description: str) -> BloomLevel:
        """
        Classify a task into Bloom level.

        Simple keyword-based classification. In production, use a trained model.
        """
        task_lower = task_description.lower()

        # CREATE indicators
        if any(kw in task_lower for kw in [
            "create", "design", "synthesize", "invent", "generate",
            "compose", "construct", "develop", "formulate", "propose"
        ]):
            return BloomLevel.CREATE

        # EVALUATE indicators
        if any(kw in task_lower for kw in [
            "evaluate", "judge", "assess", "critique", "compare",
            "decide", "justify", "recommend", "prioritize", "rank"
        ]):
            return BloomLevel.EVALUATE

        # ANALYZE indicators
        if any(kw in task_lower for kw in [
            "analyze", "examine", "investigate", "categorize", "differentiate",
            "distinguish", "organize", "relate", "break down", "decompose"
        ]):
            return BloomLevel.ANALYZE

        # Default to REMEMBER
        return BloomLevel.REMEMBER

    def get_base_tau(self, level: BloomLevel) -> float:
        """Get base tau for Bloom level."""
        return self.BLOOM_TAU_MAP.get(level, 1.0)

    # Backward compatibility alias
    get_base_temperature = get_base_tau

    def get_phase(self, level: BloomLevel) -> QualityPhase:
        """Map Bloom level to quality phase."""
        tau = self.get_base_tau(level)
        if tau < self.TAU_DETERMINISTIC:
            return QualityPhase.HIGH  # Deterministic
        elif tau < self.TAU_STOCHASTIC:
            return QualityPhase.MEDIUM  # Mixed
        return QualityPhase.LOW  # Stochastic (needs exploration)

    def compute_bloom_signals(
        self,
        task: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Compute Bloom-based signals for the pipeline.

        Returns dict with:
        - bloom_level: The classified level
        - base_tau: Recommended base temperature
        - phase: Quality phase mapping
        - mode: "exploit" or "explore"
        """
        level = self.classify_task(task)
        base_tau = self.get_base_tau(level)
        phase = self.get_phase(level)

        return {
            "bloom_level": level,
            "bloom_level_value": level.value,
            "base_tau": base_tau,
            "phase": phase,
            "mode": "exploit" if base_tau < self.TAU_DETERMINISTIC else "explore",
            "is_creative": level in [BloomLevel.EVALUATE, BloomLevel.CREATE],
        }


# =============================================================================
# CONSTRAINT ENERGY CALCULATOR
# =============================================================================

@dataclass
class ConstraintTension:
    """Measures tension/friction in a constraint system."""
    total_constraints: int = 0
    violated_constraints: int = 0
    conflicting_pairs: int = 0       # Constraints that fight each other
    unresolved_entities: int = 0     # Entities with multiple candidates
    impossible_entities: int = 0     # Entities with no valid state
    propagation_depth: int = 0       # How deep constraint propagation went
    backtrack_count: int = 0         # Number of backtracks needed

    @property
    def energy(self) -> float:
        """
        Compute system energy E.

        High energy = hard problem = need exploration
        Low energy = easy problem = exploitation works

        E = violations + conflicts + unresolved + impossible*10 + backtracks*2
        """
        e = (
            self.violated_constraints * 1.0 +
            self.conflicting_pairs * 1.5 +
            self.unresolved_entities * 0.5 +
            self.impossible_entities * 10.0 +  # Critical - no solution
            self.backtrack_count * 2.0
        )
        return e

    @property
    def normalized_energy(self) -> float:
        """Normalize energy to [0, 1] range."""
        if self.total_constraints == 0:
            return 0.0
        # Normalize by total constraints (rough heuristic)
        return min(1.0, self.energy / (self.total_constraints * 2))


class ConstraintEnergyCalculator:
    """
    Calculates system energy from constraint tension.

    Physics: E(x) in Boltzmann distribution P(x) ∝ exp(-E(x)/τ)

    High tension (many conflicts) → High Energy → Need High τ to escape
    Low tension (few conflicts) → Low Energy → Low τ works (greedy)
    """

    def calculate_from_state(
        self,
        constraints: List[Any],
        entity_states: Dict[str, Any],
        propagation_trace: Optional[List[Any]] = None
    ) -> ConstraintTension:
        """
        Calculate tension from constraint system state.

        Parameters
        ----------
        constraints : list
            List of constraint objects (from constraint_algebra)
        entity_states : dict
            Entity ID → EntityState mapping
        propagation_trace : list, optional
            Trace of constraint propagation steps

        Returns
        -------
        ConstraintTension
            Measured tension with energy score
        """
        tension = ConstraintTension(total_constraints=len(constraints))

        # Count entity states
        for entity_id, state in entity_states.items():
            if hasattr(state, 'is_resolved'):
                if state.is_impossible:
                    tension.impossible_entities += 1
                elif not state.is_resolved:
                    tension.unresolved_entities += 1
            elif hasattr(state, 'candidates'):
                if len(state.candidates) == 0:
                    tension.impossible_entities += 1
                elif len(state.candidates) > 1:
                    tension.unresolved_entities += 1

        # Count violated constraints
        for constraint in constraints:
            if hasattr(constraint, 'is_violated'):
                if constraint.is_violated(entity_states):
                    tension.violated_constraints += 1
            elif hasattr(constraint, 'check'):
                if not constraint.check(entity_states):
                    tension.violated_constraints += 1

        # Analyze propagation trace for backtracks
        if propagation_trace:
            for event in propagation_trace:
                if hasattr(event, 'event_type'):
                    if str(event.event_type) == 'BACKTRACK':
                        tension.backtrack_count += 1
                elif isinstance(event, dict):
                    if event.get('type') == 'backtrack':
                        tension.backtrack_count += 1

        return tension

    def calculate_from_signals(
        self,
        quality_signals: QualitySignals
    ) -> ConstraintTension:
        """
        Estimate tension from QualitySignals (when full constraint system unavailable).

        Uses proxy signals:
        - ood_score → conflicting/unusual
        - is_label_issue → violated constraint
        - annotator_agreement → conflicting interpretations
        """
        tension = ConstraintTension(total_constraints=10)  # Estimated

        # OOD as conflict indicator
        if quality_signals.ood_score > 0.5:
            tension.conflicting_pairs = int(quality_signals.ood_score * 5)

        # Label issues as violations
        if quality_signals.is_label_issue:
            tension.violated_constraints = 2

        # Low agreement as tension
        if quality_signals.annotator_agreement < 0.7:
            disagreement = 1 - quality_signals.annotator_agreement
            tension.conflicting_pairs += int(disagreement * 5)

        # Critical failure as impossible state
        if quality_signals.critical_failure:
            tension.impossible_entities = 1

        return tension

    def energy_to_tau_adjustment(
        self,
        energy: float,
        base_tau: float = 1.0
    ) -> float:
        """
        Convert energy to tau adjustment.

        High energy → increase τ (explore more)
        Low energy → keep τ low (exploit)

        Returns multiplier for base tau.
        """
        # Energy multiplier: exp(E/scale) bounded
        scale = 5.0  # Tunable
        multiplier = 1.0 + min(2.0, energy / scale)
        return base_tau * multiplier

    # Backward compatibility alias
    energy_to_temperature_adjustment = energy_to_tau_adjustment


# =============================================================================
# TRACE QUALITY ANALYZER
# =============================================================================

@dataclass
class TraceCoherence:
    """Measures coherence of a reasoning trace."""
    total_steps: int = 0
    forward_steps: int = 0          # Steps that make progress
    backtrack_steps: int = 0        # Steps that undo progress
    skill_switches: int = 0         # Times technique changed
    confidence_mean: float = 1.0    # Mean confidence across steps
    confidence_variance: float = 0.0
    stuck_events: int = 0           # Times solver got stuck
    conflict_events: int = 0        # Times conflict detected

    @property
    def coherence_score(self) -> float:
        """
        Compute trace coherence as quality signal α.

        High coherence = clean, linear trace = high α
        Low coherence = messy, backtracking trace = low α

        α = (forward - backtrack) / total * confidence * (1 - stuck_penalty)
        """
        if self.total_steps == 0:
            return 1.0  # No trace = assume good

        # Progress ratio
        progress = (self.forward_steps - self.backtrack_steps) / max(1, self.total_steps)
        progress = max(0, progress)  # Clamp to [0, 1]

        # Skill switch penalty (too many switches = confusion)
        switch_penalty = min(0.3, self.skill_switches * 0.05)

        # Stuck/conflict penalty
        stuck_penalty = min(0.4, (self.stuck_events + self.conflict_events) * 0.1)

        # Combine
        alpha = progress * self.confidence_mean * (1 - switch_penalty) * (1 - stuck_penalty)
        return max(0.0, min(1.0, alpha))


class TraceQualityAnalyzer:
    """
    Analyzes reasoning traces to extract quality signal α.

    A clean, linear trace indicates high-quality reasoning (high α).
    A messy trace with backtracking indicates noise (low α).

    This feeds into the YRSN pipeline:
        Trace Coherence → α → τ = f(α) → Routing decision
    """

    def analyze_trace(
        self,
        trace_events: List[Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> TraceCoherence:
        """
        Analyze a reasoning trace for coherence.

        Parameters
        ----------
        trace_events : list
            List of SolveEvent or similar trace objects
        metadata : dict, optional
            Additional trace metadata

        Returns
        -------
        TraceCoherence
            Coherence metrics with quality score
        """
        coherence = TraceCoherence(total_steps=len(trace_events))

        if not trace_events:
            return coherence

        confidences = []
        prev_technique = None

        for event in trace_events:
            # Get event type
            event_type = None
            if hasattr(event, 'event_type'):
                event_type = str(event.event_type)
            elif isinstance(event, dict):
                event_type = event.get('type', event.get('event_type', ''))

            # Classify event
            if event_type in ['BACKTRACK', 'backtrack', 'undo']:
                coherence.backtrack_steps += 1
            elif event_type in ['STUCK', 'stuck', 'no_progress']:
                coherence.stuck_events += 1
            elif event_type in ['CONFLICT', 'conflict', 'invalid']:
                coherence.conflict_events += 1
            elif event_type not in ['INIT', 'init', 'start']:
                coherence.forward_steps += 1

            # Track technique/skill switches
            technique = None
            if hasattr(event, 'technique_name'):
                technique = event.technique_name
            elif isinstance(event, dict):
                technique = event.get('technique', event.get('skill', ''))

            if technique and technique != prev_technique and prev_technique is not None:
                coherence.skill_switches += 1
            prev_technique = technique

            # Collect confidence
            confidence = 1.0
            if hasattr(event, 'confidence'):
                confidence = event.confidence
            elif isinstance(event, dict):
                confidence = event.get('confidence', 1.0)
            confidences.append(confidence)

        # Compute confidence stats
        if confidences:
            coherence.confidence_mean = float(np.mean(confidences))
            coherence.confidence_variance = float(np.var(confidences))

        return coherence

    def coherence_to_quality_signals(
        self,
        coherence: TraceCoherence
    ) -> QualitySignals:
        """
        Convert trace coherence to QualitySignals for pipeline.

        Maps:
        - coherence_score → label_quality (proxy for overall quality)
        - backtrack_steps → ood_score (unusual = backtracking)
        - confidence_mean → confidence
        - stuck_events → is_label_issue (indicates problem)
        """
        alpha = coherence.coherence_score

        # OOD based on backtracking ratio
        backtrack_ratio = coherence.backtrack_steps / max(1, coherence.total_steps)

        return QualitySignals(
            label_quality=alpha,
            confidence=coherence.confidence_mean,
            ood_score=min(1.0, backtrack_ratio * 2),
            is_label_issue=coherence.stuck_events > 0,
            extra={
                "trace_coherence": alpha,
                "forward_steps": coherence.forward_steps,
                "backtrack_steps": coherence.backtrack_steps,
                "skill_switches": coherence.skill_switches,
            }
        )


# =============================================================================
# UNIFIED COGNITIVE ENGINE
# =============================================================================

@dataclass
class CognitiveState:
    """Complete cognitive state for a reasoning task."""
    # Bloom analysis
    bloom_level: BloomLevel
    base_tau: float

    # Constraint energy
    energy: float
    tension: ConstraintTension

    # Trace quality
    alpha: float
    coherence: TraceCoherence

    # Final temperature
    final_tau: float
    phase: QualityPhase

    # Routing
    stream: Stream
    confidence: float

    # Collapse detection
    collapse_type: CollapseType
    collapse_risk: float

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)


class CognitiveEngine:
    """
    The Unified Cognitive Engine - connects reasoning with temperature.

    This is the "thermostat" that balances:
    - Bloom level (task complexity) → base τ
    - Constraint energy E (conflict magnitude) → τ adjustment
    - Trace quality α (reasoning coherence) → τ modulation

    The Boltzmann Connection:
        P(x) ∝ exp(-E(x)/τ)

        High τ (creative/uncertain) → flat distribution → exploration
        Low τ (recall/certain) → peaked distribution → exploitation

    Usage:
        engine = CognitiveEngine()

        # Analyze task
        state = engine.process(
            task="Create a novel solution for...",
            constraints=constraint_system,
            trace=reasoning_trace
        )

        # Use final temperature
        probs = softmax(logits / state.final_tau)
    """

    def __init__(
        self,
        config: Optional[AdaptiveTemperatureConfig] = None,
        bloom_controller: Optional[BloomPhaseController] = None,
        energy_calculator: Optional[ConstraintEnergyCalculator] = None,
        trace_analyzer: Optional[TraceQualityAnalyzer] = None,
    ):
        self.config = config or production_config()
        self.bloom = bloom_controller or BloomPhaseController()
        self.energy_calc = energy_calculator or ConstraintEnergyCalculator()
        self.trace_analyzer = trace_analyzer or TraceQualityAnalyzer()

    def process(
        self,
        task: str = "",
        constraints: Optional[List[Any]] = None,
        entity_states: Optional[Dict[str, Any]] = None,
        trace_events: Optional[List[Any]] = None,
        quality_signals: Optional[QualitySignals] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CognitiveState:
        """
        Process inputs through the cognitive engine.

        Parameters
        ----------
        task : str
            Task description for Bloom classification
        constraints : list, optional
            Constraint objects for energy calculation
        entity_states : dict, optional
            Entity states for constraint checking
        trace_events : list, optional
            Reasoning trace events
        quality_signals : QualitySignals, optional
            Pre-computed quality signals (fallback)
        metadata : dict, optional
            Additional context

        Returns
        -------
        CognitiveState
            Complete cognitive state with final temperature
        """
        metadata = metadata or {}

        # === STAGE 1: BLOOM PHASE ===
        bloom_signals = self.bloom.compute_bloom_signals(task, metadata)
        bloom_level = bloom_signals["bloom_level"]
        base_tau = bloom_signals["base_tau"]

        # === STAGE 2: CONSTRAINT ENERGY ===
        if constraints and entity_states:
            tension = self.energy_calc.calculate_from_state(
                constraints, entity_states, trace_events
            )
        elif quality_signals:
            tension = self.energy_calc.calculate_from_signals(quality_signals)
        else:
            tension = ConstraintTension()

        energy = tension.normalized_energy

        # === STAGE 3: TRACE QUALITY ===
        if trace_events:
            coherence = self.trace_analyzer.analyze_trace(trace_events, metadata)
        else:
            coherence = TraceCoherence()

        alpha = coherence.coherence_score

        # Override alpha from quality_signals if provided
        if quality_signals:
            # Blend trace alpha with signal alpha
            signal_alpha = quality_signals.label_quality * quality_signals.confidence
            alpha = 0.5 * alpha + 0.5 * signal_alpha

        # === STAGE 4: COMPUTE FINAL TEMPERATURE ===
        # Start with base τ from Bloom level
        tau = base_tau

        # Modulate by energy (high energy → increase τ)
        energy_multiplier = 1.0 + energy  # [1.0, 2.0]
        tau *= energy_multiplier

        # Modulate by quality α (low α → increase τ via config)
        alpha_tau = self.config.compute_tau(alpha=alpha)
        tau = 0.5 * tau + 0.5 * alpha_tau  # Blend

        # Clamp to bounds
        tau = max(self.config.tau_min, min(self.config.tau_max, tau))

        # === STAGE 5: DERIVE PHASE AND STREAM ===
        phase = self.config.get_phase(alpha)

        # Compute YRSN from alpha and energy
        R = alpha
        S = (1 - alpha) * 0.5  # Some of non-quality is superfluous
        N = energy * 0.5 + (1 - alpha) * 0.5  # Energy + noise

        # Normalize
        total = R + S + N
        if total > 0:
            R, S, N = R/total, S/total, N/total

        # Detect collapse
        collapse_type, collapse_risk = self.config.detect_collapse(R, S, N)

        # Compute confidence
        confidence = self.config.compute_confidence(R, S, N)

        # Get stream
        stream = self.config.get_stream(confidence, R=R, N=N, tau=tau)

        return CognitiveState(
            bloom_level=bloom_level,
            base_tau=base_tau,
            energy=energy,
            tension=tension,
            alpha=alpha,
            coherence=coherence,
            final_tau=tau,
            phase=phase,
            stream=stream,
            confidence=confidence,
            collapse_type=collapse_type,
            collapse_risk=collapse_risk,
            metadata={
                "bloom_signals": bloom_signals,
                "R": R, "S": S, "N": N,
                **metadata
            }
        )

    def get_tau(
        self,
        task: str = "",
        constraints: Optional[List[Any]] = None,
        trace_events: Optional[List[Any]] = None,
    ) -> float:
        """Convenience method to get final tau."""
        state = self.process(task=task, constraints=constraints, trace_events=trace_events)
        return state.final_tau

    # Backward compatibility alias
    get_temperature = get_tau

    def should_explore(self, state: CognitiveState) -> bool:
        """Check if system should explore (sample) vs exploit (greedy)."""
        return state.final_tau > self.bloom.TAU_DETERMINISTIC

    def get_sampling_params(self, state: CognitiveState) -> Dict[str, Any]:
        """Get sampling parameters based on cognitive state."""
        tau = state.final_tau

        if tau < 0.5:
            # Very tight - greedy/deterministic
            return {"temperature": tau, "top_k": 1, "do_sample": False}
        elif tau < 1.5:
            # Moderate - nucleus sampling
            return {"temperature": tau, "top_p": 0.9, "do_sample": True}
        else:
            # Loose - broad exploration
            return {"temperature": tau, "top_p": 0.95, "top_k": 50, "do_sample": True}


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Bloom
    "BloomLevel",
    "BloomPhaseController",
    # Energy
    "ConstraintTension",
    "ConstraintEnergyCalculator",
    # Trace
    "TraceCoherence",
    "TraceQualityAnalyzer",
    # Engine
    "CognitiveState",
    "CognitiveEngine",
]
