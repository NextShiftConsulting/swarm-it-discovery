"""
YRSN Parameter Transparency & Audit Trail
==========================================

Provides visibility into ALL parameters being used across the YRSN system.

Key principle: No magic numbers. Every parameter should be:
1. Visible - users can see what's being used
2. Traceable - know where it came from (default, adaptive, user-set)
3. Auditable - logged for debugging and reproducibility

Usage:
    from yrsn.core.parameter_transparency import (
        ParameterRegistry,
        log_active_parameters,
        get_parameter_report,
    )

    # Register parameters from any component
    registry = ParameterRegistry.get_instance()
    registry.register('memristor.sparse_threshold', 0.001, source='adaptive')

    # Get full report
    report = registry.get_report()

Author: YRSN Framework
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, Any, List, Optional, Union
import json
import logging

# Configure logging
logger = logging.getLogger('yrsn.params')


class ParameterSource(Enum):
    """Where did this parameter value come from?"""
    DEFAULT = "default"           # Hardcoded default
    ADAPTIVE = "adaptive"         # Learned from data
    USER_SET = "user_set"         # Explicitly set by user
    CONFIG_FILE = "config_file"   # Loaded from config file
    RUNTIME_ADJUSTED = "runtime"  # Adjusted during runtime
    INHERITED = "inherited"       # Inherited from parent config


class ParameterCategory(Enum):
    """What system does this parameter belong to?"""
    MEMRISTOR = "memristor"           # Hardware memristor params
    TEMPERATURE = "temperature"        # τ/α temperature params
    ROUTING = "routing"               # Stream routing thresholds
    CALIBRATION = "calibration"       # Self-calibration params
    TRAINING = "training"             # Training hyperparams
    ARCHITECTURE = "architecture"     # Model architecture params


@dataclass
class ParameterEntry:
    """
    Single parameter entry with full metadata.
    """
    name: str                          # e.g., 'memristor.sparse_threshold'
    value: Any                         # Current value
    source: ParameterSource            # Where it came from
    category: ParameterCategory        # What system it belongs to
    timestamp: datetime = field(default_factory=datetime.now)
    description: str = ""              # Human-readable description
    bounds: Optional[tuple] = None     # (min, max) if applicable
    is_adaptive: bool = False          # Can this be learned?
    discovery_method: str = ""         # How was it discovered (if adaptive)
    previous_values: List[Any] = field(default_factory=list)  # History

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'value': self.value,
            'source': self.source.value,
            'category': self.category.value,
            'timestamp': self.timestamp.isoformat(),
            'description': self.description,
            'bounds': self.bounds,
            'is_adaptive': self.is_adaptive,
            'discovery_method': self.discovery_method,
            'history_length': len(self.previous_values),
        }


class ParameterRegistry:
    """
    Central registry for ALL YRSN parameters.

    Singleton pattern ensures one registry across the system.

    Example:
        registry = ParameterRegistry.get_instance()

        # Register from adaptive calibration
        registry.register(
            'memristor.sparse_threshold',
            value=0.00123,
            source=ParameterSource.ADAPTIVE,
            category=ParameterCategory.MEMRISTOR,
            description='Sparse update threshold',
            discovery_method='gradient_percentile_50',
        )

        # Get current value
        thresh = registry.get('memristor.sparse_threshold')

        # Get full report
        report = registry.get_report()
    """

    _instance: Optional['ParameterRegistry'] = None

    def __init__(self):
        self._parameters: Dict[str, ParameterEntry] = {}
        self._creation_time = datetime.now()

    @classmethod
    def get_instance(cls) -> 'ParameterRegistry':
        """Get singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset registry (for testing)."""
        cls._instance = None

    def register(
        self,
        name: str,
        value: Any,
        source: ParameterSource = ParameterSource.DEFAULT,
        category: ParameterCategory = ParameterCategory.MEMRISTOR,
        description: str = "",
        bounds: Optional[tuple] = None,
        is_adaptive: bool = False,
        discovery_method: str = "",
        log_change: bool = True,
    ) -> None:
        """
        Register or update a parameter.

        Args:
            name: Dot-separated parameter name (e.g., 'memristor.sparse_threshold')
            value: Current value
            source: Where the value came from
            category: System category
            description: Human-readable description
            bounds: (min, max) bounds if applicable
            is_adaptive: Whether this parameter can be learned
            discovery_method: How it was discovered (if adaptive)
            log_change: Whether to log this registration
        """
        # Track history if updating existing param
        previous_values = []
        if name in self._parameters:
            old_entry = self._parameters[name]
            previous_values = old_entry.previous_values + [old_entry.value]

        entry = ParameterEntry(
            name=name,
            value=value,
            source=source,
            category=category,
            description=description,
            bounds=bounds,
            is_adaptive=is_adaptive,
            discovery_method=discovery_method,
            previous_values=previous_values[-10:],  # Keep last 10
        )

        self._parameters[name] = entry

        if log_change:
            self._log_parameter(entry)

    def get(self, name: str, default: Any = None) -> Any:
        """Get parameter value by name."""
        entry = self._parameters.get(name)
        return entry.value if entry else default

    def get_entry(self, name: str) -> Optional[ParameterEntry]:
        """Get full parameter entry."""
        return self._parameters.get(name)

    def get_by_category(self, category: ParameterCategory) -> Dict[str, ParameterEntry]:
        """Get all parameters in a category."""
        return {
            name: entry
            for name, entry in self._parameters.items()
            if entry.category == category
        }

    def get_adaptive_params(self) -> Dict[str, ParameterEntry]:
        """Get all adaptive (learned) parameters."""
        return {
            name: entry
            for name, entry in self._parameters.items()
            if entry.is_adaptive or entry.source == ParameterSource.ADAPTIVE
        }

    def get_report(self, include_history: bool = False) -> Dict[str, Any]:
        """
        Generate full transparency report.

        Returns structured report of all parameters.
        """
        report = {
            'generated_at': datetime.now().isoformat(),
            'registry_created': self._creation_time.isoformat(),
            'total_parameters': len(self._parameters),
            'by_category': {},
            'by_source': {},
            'adaptive_parameters': [],
            'parameters': {},
        }

        # Group by category
        for cat in ParameterCategory:
            params = self.get_by_category(cat)
            if params:
                report['by_category'][cat.value] = {
                    name: entry.value for name, entry in params.items()
                }

        # Group by source
        for source in ParameterSource:
            params = {
                name: entry for name, entry in self._parameters.items()
                if entry.source == source
            }
            if params:
                report['by_source'][source.value] = list(params.keys())

        # List adaptive parameters
        adaptive = self.get_adaptive_params()
        report['adaptive_parameters'] = [
            {
                'name': name,
                'value': entry.value,
                'discovery_method': entry.discovery_method,
            }
            for name, entry in adaptive.items()
        ]

        # Full parameter list
        for name, entry in sorted(self._parameters.items()):
            entry_dict = entry.to_dict()
            if include_history:
                entry_dict['previous_values'] = entry.previous_values
            report['parameters'][name] = entry_dict

        return report

    def print_report(self, verbose: bool = False) -> None:
        """Print human-readable parameter report."""
        report = self.get_report(include_history=verbose)

        print("\n" + "=" * 70)
        print(" YRSN PARAMETER TRANSPARENCY REPORT")
        print("=" * 70)
        print(f" Generated: {report['generated_at']}")
        print(f" Total parameters: {report['total_parameters']}")

        # By category
        print("\n BY CATEGORY:")
        for cat, params in report['by_category'].items():
            print(f"\n   [{cat.upper()}]")
            for name, value in params.items():
                short_name = name.split('.')[-1]
                if isinstance(value, float):
                    print(f"     {short_name}: {value:.6f}")
                else:
                    print(f"     {short_name}: {value}")

        # Adaptive parameters
        if report['adaptive_parameters']:
            print("\n ADAPTIVE (LEARNED) PARAMETERS:")
            for p in report['adaptive_parameters']:
                print(f"   {p['name']}: {p['value']}")
                if p['discovery_method']:
                    print(f"      -> discovered via: {p['discovery_method']}")

        # By source
        print("\n BY SOURCE:")
        for source, names in report['by_source'].items():
            print(f"   [{source}]: {len(names)} params")

        print("\n" + "=" * 70)

    def _log_parameter(self, entry: ParameterEntry) -> None:
        """Log parameter change."""
        source_emoji = {
            ParameterSource.DEFAULT: "[D]",
            ParameterSource.ADAPTIVE: "[A]",
            ParameterSource.USER_SET: "[U]",
            ParameterSource.CONFIG_FILE: "[C]",
            ParameterSource.RUNTIME_ADJUSTED: "[R]",
            ParameterSource.INHERITED: "[I]",
        }

        emoji = source_emoji.get(entry.source, "[?]")
        logger.info(f"{emoji} {entry.name} = {entry.value} ({entry.source.value})")

    def to_json(self, filepath: str) -> None:
        """Save registry to JSON file."""
        report = self.get_report(include_history=True)
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2, default=str)

    @classmethod
    def from_json(cls, filepath: str) -> 'ParameterRegistry':
        """Load registry from JSON file."""
        registry = cls.get_instance()
        with open(filepath, 'r') as f:
            data = json.load(f)

        for name, entry_data in data.get('parameters', {}).items():
            registry.register(
                name=name,
                value=entry_data['value'],
                source=ParameterSource(entry_data['source']),
                category=ParameterCategory(entry_data['category']),
                description=entry_data.get('description', ''),
                is_adaptive=entry_data.get('is_adaptive', False),
                discovery_method=entry_data.get('discovery_method', ''),
                log_change=False,
            )

        return registry


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def register_memristor_params(
    sparse_threshold: float,
    learning_rate: float,
    drift_rate: float,
    ga_batch_size: int,
    energy_barrier: float,
    source: ParameterSource = ParameterSource.DEFAULT,
    discovery_method: str = "",
) -> None:
    """
    Register all memristor parameters at once.

    Call this after calibration or config setup.
    """
    registry = ParameterRegistry.get_instance()

    params = [
        ('memristor.sparse_threshold', sparse_threshold, 'Sparse update threshold', (0.0, 1.0), True, 'gradient_percentile'),
        ('memristor.learning_rate', learning_rate, 'Memristor learning rate', (0.001, 1.0), True, 'gradient_scaling'),
        ('memristor.drift_rate', drift_rate, 'Resistance drift rate', (0.001, 0.5), True, 'signal_analysis'),
        ('memristor.ga_batch_size', ga_batch_size, 'Gradient accumulation batch', (1, 64), True, 'variance_analysis'),
        ('memristor.energy_barrier', energy_barrier, 'Thermal noise barrier', (0.001, 1.0), True, 'noise_floor'),
    ]

    for name, value, desc, bounds, is_adaptive, method in params:
        registry.register(
            name=name,
            value=value,
            source=source,
            category=ParameterCategory.MEMRISTOR,
            description=desc,
            bounds=bounds,
            is_adaptive=is_adaptive,
            discovery_method=discovery_method or method,
        )


def register_temperature_params(
    tau_min: float = 0.1,
    tau_max: float = 5.0,
    power_k: float = 2.0,
    alpha_high: float = 0.70,
    alpha_low: float = 0.40,
    source: ParameterSource = ParameterSource.DEFAULT,
) -> None:
    """Register temperature configuration parameters."""
    registry = ParameterRegistry.get_instance()

    params = [
        ('temperature.tau_min', tau_min, 'Minimum temperature'),
        ('temperature.tau_max', tau_max, 'Maximum temperature'),
        ('temperature.power_k', power_k, 'Activation power exponent'),
        ('temperature.alpha_high', alpha_high, 'High quality threshold'),
        ('temperature.alpha_low', alpha_low, 'Low quality threshold'),
    ]

    for name, value, desc in params:
        registry.register(
            name=name,
            value=value,
            source=source,
            category=ParameterCategory.TEMPERATURE,
            description=desc,
            is_adaptive=name in ['temperature.power_k', 'temperature.alpha_high', 'temperature.alpha_low'],
        )


def register_routing_params(
    green_threshold: float = 0.95,
    yellow_threshold: float = 0.70,
    min_R: float = 0.50,
    max_N: float = 0.30,
    source: ParameterSource = ParameterSource.DEFAULT,
) -> None:
    """Register routing threshold parameters."""
    registry = ParameterRegistry.get_instance()

    params = [
        ('routing.green_threshold', green_threshold, 'Auto-approve confidence threshold'),
        ('routing.yellow_threshold', yellow_threshold, 'AI-assisted review threshold'),
        ('routing.min_R', min_R, 'Minimum relevance for green stream'),
        ('routing.max_N', max_N, 'Maximum noise for any stream'),
    ]

    for name, value, desc in params:
        registry.register(
            name=name,
            value=value,
            source=source,
            category=ParameterCategory.ROUTING,
            description=desc,
            is_adaptive=True,
        )


def log_active_parameters() -> None:
    """Log all active parameters (convenience function)."""
    ParameterRegistry.get_instance().print_report()


def get_parameter_report() -> Dict[str, Any]:
    """Get parameter report as dict (convenience function)."""
    return ParameterRegistry.get_instance().get_report()


# =============================================================================
# PARAMETER AUDIT DECORATOR
# =============================================================================

def audit_parameters(func):
    """
    Decorator to log parameters used by a function.

    Example:
        @audit_parameters
        def train(config):
            ...
    """
    def wrapper(*args, **kwargs):
        logger.info(f"[AUDIT] Entering {func.__name__}")

        # Log any config objects in args
        for arg in args:
            if hasattr(arg, 'to_dict'):
                logger.info(f"[AUDIT] Config: {arg.to_dict()}")
            elif hasattr(arg, '__dataclass_fields__'):
                logger.info(f"[AUDIT] Config: {arg}")

        result = func(*args, **kwargs)

        logger.info(f"[AUDIT] Exiting {func.__name__}")
        return result

    return wrapper


# =============================================================================
# TEST
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print(" PARAMETER TRANSPARENCY - Demo")
    print("=" * 70)

    # Get registry
    registry = ParameterRegistry.get_instance()

    # Register some parameters
    register_memristor_params(
        sparse_threshold=0.00123,
        learning_rate=0.15,
        drift_rate=0.12,
        ga_batch_size=8,
        energy_barrier=0.002,
        source=ParameterSource.ADAPTIVE,
        discovery_method='gradient_percentile_50',
    )

    register_temperature_params(
        tau_min=0.1,
        tau_max=5.0,
        power_k=2.0,
    )

    register_routing_params()

    # Print report
    registry.print_report(verbose=True)

    # Save to JSON
    registry.to_json('/tmp/yrsn_params.json')
    print("\nSaved to /tmp/yrsn_params.json")
