"""
DEPRECATED: Control module moved to yrsn.adapters.control

⚠️  This module is DEPRECATED and will be removed in a future version.
⚠️  Import from yrsn.adapters.control instead.

WHY IT MOVED:
------------
Control logic (enforcement, routing, monitoring) belongs in ADAPTERS, not CORE.
YRSN Core should only emit SIGNALS (measurements), not enforce CONTROL.

HEXAGONAL ARCHITECTURE:
----------------------
Core:     Measurement only (R, S, N, α, ω signals)
Adapters: Optional control (enforcement, routing, monitoring)

MIGRATION:
---------
OLD: from yrsn.core.control import BarrierController
NEW: from yrsn.adapters.control import BarrierController

See: docs/HEX_ARCHITECTURE_DEEP_AUDIT.md
"""

import warnings

warnings.warn(
    "yrsn.core.control is deprecated. "
    "Control logic moved to yrsn.adapters.control. "
    "Per hexagonal architecture, control belongs in adapters (optional), not core (measurement). "
    "Update your imports: 'from yrsn.adapters.control import ...'",
    DeprecationWarning,
    stacklevel=2
)

# Re-export from new location for backward compatibility
try:
    from yrsn.adapters.control import *
except ImportError as e:
    warnings.warn(
        f"Could not import from yrsn.adapters.control: {e}. "
        "The control module may not be fully migrated yet.",
        ImportWarning
    )
