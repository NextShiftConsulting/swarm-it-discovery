"""
YRSN Adaptive Temperature Parameter Discovery
===============================================

Learns optimal temperature parameters from α (quality) distribution:
- power_k: Activation sharpness for τ = 1/α^k
- alpha_high: High quality threshold
- alpha_low: Low quality threshold

Key insight: These thresholds should reflect the ACTUAL data distribution,
not arbitrary hardcoded values.

Usage:
    from yrsn.core.adaptive_temperature_discovery import (
        AdaptiveTemperatureDiscovery,
        discover_temperature_params,
    )

    discovery = AdaptiveTemperatureDiscovery()
    params = discovery.calibrate(alpha_scores, outcomes)

Author: YRSN Framework
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
import numpy as np

# Parameter transparency
try:
    from .parameter_transparency import (
        ParameterRegistry,
        ParameterSource,
        ParameterCategory,
    )
    HAS_TRANSPARENCY = True
except ImportError:
    HAS_TRANSPARENCY = False


# =============================================================================
# CALIBRATION RESULT
# =============================================================================

@dataclass
class TemperatureDiscoveryResult:
    """
    Result of temperature parameter discovery.
    """
    # Discovered parameters
    power_k: float              # τ = 1/α^k
    alpha_high: float           # High quality threshold
    alpha_low: float            # Low quality threshold
    tau_min: float              # Minimum temperature
    tau_max: float              # Maximum temperature

    # Distribution statistics
    alpha_stats: Dict[str, float] = field(default_factory=dict)

    # Phase distribution at these thresholds
    high_phase_pct: float = 0.0    # % in HIGH phase
    medium_phase_pct: float = 0.0  # % in MEDIUM phase
    low_phase_pct: float = 0.0     # % in LOW phase

    # Performance correlation
    high_accuracy: float = 0.0     # Accuracy in HIGH phase
    medium_accuracy: float = 0.0   # Accuracy in MEDIUM phase
    low_accuracy: float = 0.0      # Accuracy in LOW phase

    n_samples: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'power_k': self.power_k,
            'alpha_high': self.alpha_high,
            'alpha_low': self.alpha_low,
            'tau_min': self.tau_min,
            'tau_max': self.tau_max,
            'alpha_stats': self.alpha_stats,
            'high_phase_pct': self.high_phase_pct,
            'medium_phase_pct': self.medium_phase_pct,
            'low_phase_pct': self.low_phase_pct,
            'high_accuracy': self.high_accuracy,
            'medium_accuracy': self.medium_accuracy,
            'low_accuracy': self.low_accuracy,
            'n_samples': self.n_samples,
        }

    def register_for_transparency(self) -> None:
        """Register discovered parameters for audit trail."""
        if not HAS_TRANSPARENCY:
            return

        registry = ParameterRegistry.get_instance()

        params = [
            ('temperature.power_k', self.power_k, 'Activation power exponent'),
            ('temperature.alpha_high', self.alpha_high, 'High quality threshold'),
            ('temperature.alpha_low', self.alpha_low, 'Low quality threshold'),
            ('temperature.tau_min', self.tau_min, 'Minimum temperature'),
            ('temperature.tau_max', self.tau_max, 'Maximum temperature'),
        ]

        for name, value, desc in params:
            registry.register(
                name=name,
                value=value,
                source=ParameterSource.ADAPTIVE,
                category=ParameterCategory.TEMPERATURE,
                description=desc,
                is_adaptive=True,
                discovery_method='alpha_distribution_analysis',
            )


# =============================================================================
# ADAPTIVE TEMPERATURE DISCOVERY
# =============================================================================

class AdaptiveTemperatureDiscovery:
    """
    Discover optimal temperature parameters from α distribution.

    The key insight is that:
    - alpha_high/low should reflect NATURAL phase boundaries in data
    - power_k should be tuned for optimal τ response curve
    - tau_min/max should prevent extreme values

    Example:
        discovery = AdaptiveTemperatureDiscovery()
        result = discovery.calibrate(alpha_scores, outcomes)

        # Use discovered params
        config = AdaptiveTemperatureConfig(
            power_k=result.power_k,
            alpha_high=result.alpha_high,
            alpha_low=result.alpha_low,
        )
    """

    def __init__(
        self,
        target_high_pct: float = 0.3,   # Target ~30% in HIGH phase
        target_low_pct: float = 0.3,    # Target ~30% in LOW phase
        min_phase_samples: int = 50,     # Min samples per phase for stats
    ):
        """
        Initialize discovery.

        Args:
            target_high_pct: Target percentage for HIGH phase
            target_low_pct: Target percentage for LOW phase
            min_phase_samples: Minimum samples needed per phase
        """
        self.target_high_pct = target_high_pct
        self.target_low_pct = target_low_pct
        self.min_phase_samples = min_phase_samples

    def calibrate(
        self,
        alpha_scores: np.ndarray,
        outcomes: Optional[np.ndarray] = None,
        verbose: bool = True,
    ) -> TemperatureDiscoveryResult:
        """
        Discover temperature parameters from α distribution.

        Args:
            alpha_scores: Array of α (quality) scores [0, 1]
            outcomes: Optional array of outcomes (for accuracy analysis)
            verbose: Print progress

        Returns:
            TemperatureDiscoveryResult with discovered parameters
        """
        n = len(alpha_scores)

        if verbose:
            print("=" * 60)
            print(" ADAPTIVE TEMPERATURE DISCOVERY")
            print(" Learning τ parameters from α distribution...")
            print("=" * 60)

        # Phase 1: Analyze α distribution
        if verbose:
            print("\n Phase 1: Analyzing α distribution...")
        alpha_stats = self._analyze_alpha(alpha_scores, verbose)

        # Phase 2: Discover phase thresholds
        if verbose:
            print("\n Phase 2: Discovering phase thresholds...")
        alpha_high, alpha_low = self._discover_thresholds(alpha_scores, verbose)

        # Phase 3: Discover power_k
        if verbose:
            print("\n Phase 3: Discovering activation sharpness (power_k)...")
        power_k = self._discover_power_k(alpha_scores, alpha_high, alpha_low, verbose)

        # Phase 4: Compute τ bounds
        if verbose:
            print("\n Phase 4: Computing τ bounds...")
        tau_min, tau_max = self._compute_tau_bounds(alpha_scores, power_k, verbose)

        # Phase 5: Analyze phase distribution
        if verbose:
            print("\n Phase 5: Analyzing phase distribution...")

        high_mask = alpha_scores > alpha_high
        low_mask = alpha_scores < alpha_low
        medium_mask = ~high_mask & ~low_mask

        high_pct = np.mean(high_mask)
        medium_pct = np.mean(medium_mask)
        low_pct = np.mean(low_mask)

        # Accuracy by phase (if outcomes provided)
        high_acc = medium_acc = low_acc = 0.0
        if outcomes is not None:
            if np.any(high_mask):
                high_acc = np.mean(outcomes[high_mask])
            if np.any(medium_mask):
                medium_acc = np.mean(outcomes[medium_mask])
            if np.any(low_mask):
                low_acc = np.mean(outcomes[low_mask])

        if verbose:
            print(f"   HIGH   (α > {alpha_high:.2f}): {high_pct*100:5.1f}%")
            print(f"   MEDIUM ({alpha_low:.2f} ≤ α ≤ {alpha_high:.2f}): {medium_pct*100:5.1f}%")
            print(f"   LOW    (α < {alpha_low:.2f}): {low_pct*100:5.1f}%")
            if outcomes is not None:
                print(f"\n   Accuracy by phase:")
                print(f"     HIGH:   {high_acc*100:.1f}%")
                print(f"     MEDIUM: {medium_acc*100:.1f}%")
                print(f"     LOW:    {low_acc*100:.1f}%")

        result = TemperatureDiscoveryResult(
            power_k=power_k,
            alpha_high=alpha_high,
            alpha_low=alpha_low,
            tau_min=tau_min,
            tau_max=tau_max,
            alpha_stats=alpha_stats,
            high_phase_pct=high_pct,
            medium_phase_pct=medium_pct,
            low_phase_pct=low_pct,
            high_accuracy=high_acc,
            medium_accuracy=medium_acc,
            low_accuracy=low_acc,
            n_samples=n,
        )

        if verbose:
            print("\n" + "=" * 60)
            print(" TEMPERATURE DISCOVERY COMPLETE")
            print("=" * 60)
            print(f"\n Discovered parameters:")
            print(f"   power_k:    {power_k:.2f}")
            print(f"   alpha_high: {alpha_high:.2f}")
            print(f"   alpha_low:  {alpha_low:.2f}")
            print(f"   tau_min:    {tau_min:.2f}")
            print(f"   tau_max:    {tau_max:.2f}")
            print("=" * 60)

        # Register for transparency
        result.register_for_transparency()

        return result

    def _analyze_alpha(
        self,
        alpha_scores: np.ndarray,
        verbose: bool,
    ) -> Dict[str, float]:
        """Analyze α distribution."""
        stats = {
            'min': float(np.min(alpha_scores)),
            'max': float(np.max(alpha_scores)),
            'mean': float(np.mean(alpha_scores)),
            'std': float(np.std(alpha_scores)),
            'median': float(np.median(alpha_scores)),
            'p10': float(np.percentile(alpha_scores, 10)),
            'p25': float(np.percentile(alpha_scores, 25)),
            'p50': float(np.percentile(alpha_scores, 50)),
            'p75': float(np.percentile(alpha_scores, 75)),
            'p90': float(np.percentile(alpha_scores, 90)),
            'skewness': float(self._compute_skewness(alpha_scores)),
            'bimodality': float(self._compute_bimodality(alpha_scores)),
        }

        if verbose:
            print(f"   Samples: {len(alpha_scores)}")
            print(f"   Range: [{stats['min']:.3f}, {stats['max']:.3f}]")
            print(f"   Mean: {stats['mean']:.3f}, Std: {stats['std']:.3f}")
            print(f"   Skewness: {stats['skewness']:.2f}")
            print(f"   Bimodality: {stats['bimodality']:.2f}")

        return stats

    def _compute_skewness(self, data: np.ndarray) -> float:
        """Compute skewness (asymmetry of distribution)."""
        mean = np.mean(data)
        std = np.std(data)
        if std < 1e-8:
            return 0.0
        return float(np.mean(((data - mean) / std) ** 3))

    def _compute_bimodality(self, data: np.ndarray) -> float:
        """
        Estimate bimodality coefficient.

        Higher values suggest bimodal distribution.
        """
        n = len(data)
        if n < 10:
            return 0.0

        mean = np.mean(data)
        std = np.std(data)
        if std < 1e-8:
            return 0.0

        # Compute skewness and kurtosis
        skew = np.mean(((data - mean) / std) ** 3)
        kurt = np.mean(((data - mean) / std) ** 4) - 3  # Excess kurtosis

        # Bimodality coefficient (Sarle's)
        bc = (skew ** 2 + 1) / (kurt + 3 * ((n - 1) ** 2) / ((n - 2) * (n - 3)))
        return float(np.clip(bc, 0, 1))

    def _discover_thresholds(
        self,
        alpha_scores: np.ndarray,
        verbose: bool,
    ) -> Tuple[float, float]:
        """
        Discover natural phase boundaries.

        Uses percentiles based on target phase distribution.
        """
        # Use percentiles to achieve target distribution
        # HIGH phase: top target_high_pct
        alpha_high = np.percentile(alpha_scores, (1 - self.target_high_pct) * 100)

        # LOW phase: bottom target_low_pct
        alpha_low = np.percentile(alpha_scores, self.target_low_pct * 100)

        # Ensure valid ordering
        if alpha_low >= alpha_high:
            # Fall back to equal thirds
            alpha_high = np.percentile(alpha_scores, 66.7)
            alpha_low = np.percentile(alpha_scores, 33.3)

        # Clamp to reasonable range
        alpha_high = np.clip(alpha_high, 0.5, 0.9)
        alpha_low = np.clip(alpha_low, 0.2, 0.6)

        if verbose:
            print(f"   Target distribution: {self.target_high_pct*100:.0f}% HIGH, {self.target_low_pct*100:.0f}% LOW")
            print(f"   -> alpha_high = {alpha_high:.2f}")
            print(f"   -> alpha_low = {alpha_low:.2f}")

        return float(alpha_high), float(alpha_low)

    def _discover_power_k(
        self,
        alpha_scores: np.ndarray,
        alpha_high: float,
        alpha_low: float,
        verbose: bool,
    ) -> float:
        """
        Discover optimal power_k for τ = 1/α^k.

        The goal is to have τ respond appropriately:
        - α = alpha_high → τ ≈ 1 (moderate plasticity)
        - α = alpha_low → τ ≈ 2-3 (higher plasticity)

        We want: τ(alpha_low) / τ(alpha_high) ≈ target_ratio
        """
        # Target ratio: how much more plastic should LOW be vs HIGH?
        target_ratio = 3.0  # LOW should be 3x more plastic than HIGH

        # τ = 1/α^k
        # τ_low / τ_high = α_high^k / α_low^k = (α_high/α_low)^k
        # target_ratio = (α_high/α_low)^k
        # k = log(target_ratio) / log(α_high/α_low)

        ratio = alpha_high / max(alpha_low, 0.01)
        if ratio > 1:
            power_k = np.log(target_ratio) / np.log(ratio)
        else:
            power_k = 2.0  # Default

        # Clamp to reasonable range
        power_k = np.clip(power_k, 1.0, 4.0)

        if verbose:
            # Show τ values at key points
            tau_high = 1.0 / (alpha_high ** power_k)
            tau_low = 1.0 / (alpha_low ** power_k)
            print(f"   Target τ ratio (LOW/HIGH): {target_ratio:.1f}x")
            print(f"   -> power_k = {power_k:.2f}")
            print(f"   τ at α_high ({alpha_high:.2f}): {tau_high:.2f}")
            print(f"   τ at α_low ({alpha_low:.2f}): {tau_low:.2f}")
            print(f"   Actual ratio: {tau_low/tau_high:.2f}x")

        return float(power_k)

    def _compute_tau_bounds(
        self,
        alpha_scores: np.ndarray,
        power_k: float,
        verbose: bool,
    ) -> Tuple[float, float]:
        """
        Compute τ bounds based on α distribution.
        """
        # τ at extreme α values
        alpha_max = np.percentile(alpha_scores, 95)
        alpha_min = np.percentile(alpha_scores, 5)

        tau_at_max_alpha = 1.0 / (alpha_max ** power_k)
        tau_at_min_alpha = 1.0 / (max(alpha_min, 0.01) ** power_k)

        # Set bounds with some headroom
        tau_min = max(0.1, tau_at_max_alpha * 0.5)
        tau_max = min(10.0, tau_at_min_alpha * 1.5)

        # Ensure min < max
        if tau_min >= tau_max:
            tau_min = 0.1
            tau_max = 5.0

        if verbose:
            print(f"   τ range in data: [{tau_at_max_alpha:.2f}, {tau_at_min_alpha:.2f}]")
            print(f"   -> tau_min = {tau_min:.2f}")
            print(f"   -> tau_max = {tau_max:.2f}")

        return float(tau_min), float(tau_max)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def discover_temperature_params(
    alpha_scores: np.ndarray,
    outcomes: Optional[np.ndarray] = None,
    verbose: bool = True,
) -> Dict[str, float]:
    """
    One-liner to discover temperature parameters.

    Returns dict with power_k, alpha_high, alpha_low, tau_min, tau_max.
    """
    discovery = AdaptiveTemperatureDiscovery()
    result = discovery.calibrate(alpha_scores, outcomes, verbose)
    return {
        'power_k': result.power_k,
        'alpha_high': result.alpha_high,
        'alpha_low': result.alpha_low,
        'tau_min': result.tau_min,
        'tau_max': result.tau_max,
    }


# =============================================================================
# TEST
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print(" ADAPTIVE TEMPERATURE DISCOVERY - Demo")
    print("=" * 70)

    # Generate synthetic α scores (bimodal)
    np.random.seed(42)
    n = 1000

    # Mix of high-quality and low-quality samples
    alpha_high_samples = np.random.beta(8, 2, n // 2)  # High α
    alpha_low_samples = np.random.beta(2, 5, n // 2)   # Low α
    alpha_scores = np.concatenate([alpha_high_samples, alpha_low_samples])

    # Outcomes correlate with α
    outcomes = np.random.rand(n) < (alpha_scores * 0.7 + 0.2)

    # Discover
    discovery = AdaptiveTemperatureDiscovery(
        target_high_pct=0.35,
        target_low_pct=0.35,
    )

    result = discovery.calibrate(alpha_scores, outcomes, verbose=True)

    print("\n" + "=" * 70)
    print(" KEY INSIGHT: Temperature params learned FROM data distribution!")
    print("=" * 70)
