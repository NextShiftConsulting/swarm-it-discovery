"""
YRSN Models - Adaptive depth classifiers with quality-based routing.

WARNING - DO NOT USE NUMPY FOR GRADIENT COMPUTATION:
    Always use PyTorch autograd. Manual numpy gradients are buggy.
"""

from .hybrid_classifier import (
    HybridYRSNClassifier,
    HybridYRSNConfig,
    QualityFlags,
    RouteInfo,
    create_hybrid_classifier,
)

__all__ = [
    "HybridYRSNClassifier",
    "HybridYRSNConfig",
    "QualityFlags",
    "RouteInfo",
    "create_hybrid_classifier",
]
