"""Test Hybrid YRSN Classifier on Forest Cover Type dataset."""

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.datasets import fetch_covtype
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from hybrid_classifier import HybridYRSNClassifier, HybridYRSNConfig, create_hybrid_classifier


def load_forest_cover():
    """Load and preprocess Forest Cover Type dataset."""
    print("Loading Forest Cover Type dataset...")
    data = fetch_covtype()
    X, y = data.data, data.target - 1  # 0-indexed

    # Use subset for faster testing
    n_samples = 15000
    indices = np.random.RandomState(42).choice(len(X), n_samples, replace=False)
    X, y = X[indices], y[indices]

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Standardize
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    print(f"Train: {len(X_train)}, Test: {len(X_test)}")
    print(f"Classes: {np.unique(y_train)}")

    return X_train, X_test, y_train, y_test


def train_hybrid(model, train_loader, val_loader, epochs=100, lr=1e-3, device='cpu'):
    """Train hybrid classifier."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, epochs)

    best_val_acc = 0
    best_state = None

    for epoch in range(epochs):
        # Train
        model.train()
        train_loss = 0
        train_correct = 0
        train_total = 0

        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)

            optimizer.zero_grad()
            outputs = model.forward_train(X_batch)
            losses = model.compute_loss(outputs, y_batch)

            losses['total'].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            train_loss += losses['total'].item()

            # Use deep logits for training accuracy
            preds = outputs['deep_logits'].argmax(dim=-1)
            train_correct += (preds == y_batch).sum().item()
            train_total += len(y_batch)

        scheduler.step()

        # Validate
        model.eval()
        val_correct = 0
        val_total = 0
        route_stats = {"shallow_trust": 0, "deep_trust": 0, "ensemble_rerank": 0, "abstain": 0}

        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                logits, routes = model.forward(X_batch, return_routes=True)

                preds = logits.argmax(dim=-1)
                val_correct += (preds == y_batch).sum().item()
                val_total += len(y_batch)

                for r in routes:
                    route_stats[r.route] += 1

        train_acc = 100 * train_correct / train_total
        val_acc = 100 * val_correct / val_total

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

        if (epoch + 1) % 10 == 0:
            total_routes = sum(route_stats.values())
            print(f"Epoch {epoch+1:3d}: loss={train_loss/len(train_loader):.4f}, "
                  f"train={train_acc:.1f}%, val={val_acc:.1f}%, best={best_val_acc:.1f}%")
            print(f"  Routes: shallow={100*route_stats['shallow_trust']/total_routes:.0f}%, "
                  f"deep={100*route_stats['deep_trust']/total_routes:.0f}%, "
                  f"ensemble={100*route_stats['ensemble_rerank']/total_routes:.0f}%, "
                  f"abstain={100*route_stats['abstain']/total_routes:.0f}%")

    # Load best
    if best_state:
        model.load_state_dict(best_state)

    return model, best_val_acc


def evaluate_hybrid(model, test_loader, device='cpu'):
    """Evaluate with detailed routing analysis."""
    model.eval()
    model = model.to(device)

    all_routes = []
    correct = 0
    total = 0

    # Per-route accuracy
    route_correct = {"shallow_trust": 0, "deep_trust": 0, "ensemble_rerank": 0, "abstain": 0}
    route_total = {"shallow_trust": 0, "deep_trust": 0, "ensemble_rerank": 0, "abstain": 0}

    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            logits, routes = model.forward(X_batch, return_routes=True)

            preds = logits.argmax(dim=-1)
            correct += (preds == y_batch).sum().item()
            total += len(y_batch)

            for i, r in enumerate(routes):
                all_routes.append(r)
                is_correct = (preds[i] == y_batch[i]).item()
                route_correct[r.route] += is_correct
                route_total[r.route] += 1

    overall_acc = 100 * correct / total

    print("\n" + "=" * 60)
    print("FINAL RESULTS")
    print("=" * 60)
    print(f"Overall Accuracy: {overall_acc:.1f}%")
    print()

    print("Per-Route Accuracy:")
    for route in ["shallow_trust", "deep_trust", "ensemble_rerank", "abstain"]:
        if route_total[route] > 0:
            acc = 100 * route_correct[route] / route_total[route]
            pct = 100 * route_total[route] / total
            print(f"  {route:15s}: {acc:5.1f}% ({pct:4.1f}% of samples)")

    # Quality stats
    alphas = [r.quality.alpha for r in all_routes]
    print()
    print("Quality Stats:")
    print(f"  Mean alpha: {np.mean(alphas):.3f}")
    print(f"  Min alpha:  {np.min(alphas):.3f}")
    print(f"  Max alpha:  {np.max(alphas):.3f}")

    # Flag counts
    from hybrid_classifier import QualityFlags
    flag_counts = {f.name: 0 for f in QualityFlags if f != QualityFlags.NONE}
    for r in all_routes:
        for f in QualityFlags:
            if f != QualityFlags.NONE and r.quality.has_flag(f):
                flag_counts[f.name] += 1

    print()
    print("Quality Flags:")
    for name, count in flag_counts.items():
        if count > 0:
            print(f"  {name}: {count} ({100*count/total:.1f}%)")

    return overall_acc, all_routes


def main():
    print("Hybrid YRSN Classifier Test")
    print("=" * 60)

    # Load data
    X_train, X_test, y_train, y_test = load_forest_cover()

    # Create data loaders
    train_dataset = TensorDataset(
        torch.FloatTensor(X_train),
        torch.LongTensor(y_train)
    )
    test_dataset = TensorDataset(
        torch.FloatTensor(X_test),
        torch.LongTensor(y_test)
    )

    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=256)

    # Device
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device: {device}")

    # Create model
    config = HybridYRSNConfig(
        input_dim=54,
        num_classes=7,
        hidden_dim=256,
        backbone_layers=2,
        deep_adapter_layers=3,
        deep_adapter_dim=512,
        r_dim=128,
        s_dim=64,
        n_dim=32,
        alpha_high=0.65,
        alpha_med=0.45,
        alpha_low=0.25,
    )

    model = HybridYRSNClassifier(config)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")

    # Train
    print()
    print("Training...")
    print("-" * 60)
    model, best_val = train_hybrid(model, train_loader, test_loader, epochs=100, lr=1e-3, device=device)

    # Evaluate
    acc, routes = evaluate_hybrid(model, test_loader, device=device)

    print()
    print("=" * 60)
    print("COMPARISON")
    print("-" * 40)
    print(f"Hybrid YRSN:        {acc:.1f}%  <-- NEW")
    print(f"YRSN Hopfield:      78.5%")
    print(f"Random Forest:      81%")
    print(f"SOTA:               ~95%")


if __name__ == "__main__":
    main()
