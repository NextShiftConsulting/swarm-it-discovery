"""
Hybrid YRSN Classifier - Adaptive depth with quality-based routing.

Architecture:
    Input → Backbone → f0
                  ↓
             Shallow Head → (y0, p0)
                  ↓
             YRSN Quality → q1 {α, τ, R, S, N, flags}
                  ↓
             [α ≥ HIGH?] ──yes──→ Return y0 (shallow_trust)
                  ↓ no
             Deep Adapter → f1
                  ↓
             Deep Head → (y1, p1)
                  ↓
             YRSN Quality → q2
                  ↓
             [α ≥ MED?] ──yes──→ Return y1 (deep_trust)
                  ↓ no
             Ensemble(y0, y1, weights=[α1, α2])
                  ↓
             [conf ≥ MIN?] ──no──→ ABSTAIN
                  ↓ yes
             Return yE (ensemble_rerank)

Key insight: Use YRSN quality (alpha) as router, not just softmax confidence.

WARNING - DO NOT USE NUMPY FOR GRADIENT COMPUTATION:
    Always use PyTorch autograd. Manual numpy gradients are buggy (48% vs 78%).
"""

from dataclasses import dataclass, field
from enum import Flag, auto
from typing import Dict, List, Optional, Tuple, Any, Literal

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class QualityFlags(Flag):
    """Flags for anomalous quality conditions."""
    NONE = 0
    POISON = auto()      # High N, adversarial pattern
    HALLUC = auto()      # High S, low R, model making things up
    OOD = auto()         # Out-of-distribution (high epsilon/low omega)
    LOW_CONF = auto()    # Low softmax confidence
    DISAGREE = auto()    # Shallow/deep heads disagree


@dataclass
class QualitySignals:
    """YRSN quality signals for routing decisions."""
    alpha: float                    # Quality score R/(R+S+N)
    tau: float                      # Temperature 1/alpha
    R: float                        # Relevant signal strength
    S: float                        # Superfluous signal
    N: float                        # Noise signal
    omega: float = 1.0              # OOD reliability (1.0 = in-distribution)
    confidence: float = 0.0         # Max softmax probability
    entropy: float = 0.0            # Prediction entropy
    flags: QualityFlags = QualityFlags.NONE

    def has_flag(self, flag: QualityFlags) -> bool:
        return flag in self.flags


@dataclass
class RouteInfo:
    """Information about which route was taken."""
    route: Literal["shallow_trust", "deep_trust", "ensemble_rerank", "abstain"]
    quality: QualitySignals
    shallow_quality: Optional[QualitySignals] = None
    deep_quality: Optional[QualitySignals] = None


@dataclass
class HybridYRSNConfig:
    """Configuration for hybrid classifier."""
    # Architecture
    input_dim: int = 54
    hidden_dim: int = 256
    num_classes: int = 7

    # Backbone
    backbone_layers: int = 2
    backbone_dropout: float = 0.1

    # Shallow head
    shallow_layers: int = 1

    # Deep adapter
    deep_adapter_layers: int = 2
    deep_adapter_dim: int = 512

    # R/S/N projection
    r_dim: int = 128
    s_dim: int = 64
    n_dim: int = 32
    r_weight: float = 2.0      # Boost relevant
    s_weight: float = 1.0      # Normal
    n_weight: float = 0.1      # Suppress noise

    # Quality thresholds for routing (ADAPTIVE - these are initial values)
    # Will be updated based on alpha distribution via calibrate_thresholds()
    alpha_high: float = 0.7    # Trust shallow if α ≥ this (top 25%)
    alpha_med: float = 0.5     # Trust deep if α ≥ this (middle 50%)
    alpha_low: float = 0.3     # Abstain if α < this (bottom 25%)
    conf_min: float = 0.3      # Abstain if max_prob < this

    # Adaptive threshold percentiles (used by calibrate_thresholds)
    adaptive_high_pct: float = 75.0   # Top 25% → shallow
    adaptive_med_pct: float = 50.0    # Top 50% → deep
    adaptive_low_pct: float = 25.0    # Bottom 25% → abstain

    # Poison/hallucination detection
    noise_threshold: float = 0.4    # Flag poison if N > this
    superfluous_threshold: float = 0.6  # Flag halluc if S > this and R < 0.2

    # Training
    beta: float = 4.0          # Attention temperature
    label_smoothing: float = 0.1


class RSNProjection(nn.Module):
    """Project features into R/S/N subspaces."""

    def __init__(self, input_dim: int, r_dim: int, s_dim: int, n_dim: int):
        super().__init__()
        self.r_proj = nn.Linear(input_dim, r_dim)
        self.s_proj = nn.Linear(input_dim, s_dim)
        self.n_proj = nn.Linear(input_dim, n_dim)

        # Learnable separation
        self.r_gate = nn.Sequential(
            nn.Linear(input_dim, r_dim),
            nn.Sigmoid()
        )
        self.s_gate = nn.Sequential(
            nn.Linear(input_dim, s_dim),
            nn.Sigmoid()
        )
        self.n_gate = nn.Sequential(
            nn.Linear(input_dim, n_dim),
            nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        R = self.r_proj(x) * self.r_gate(x)
        S = self.s_proj(x) * self.s_gate(x)
        N = self.n_proj(x) * self.n_gate(x)
        return R, S, N


class QualityRouter(nn.Module):
    """Compute YRSN quality signals from features and predictions."""

    def __init__(self, config: HybridYRSNConfig):
        super().__init__()
        self.c = config

        # Learnable quality estimator
        rsn_dim = config.r_dim + config.s_dim + config.n_dim
        self.quality_head = nn.Sequential(
            nn.Linear(rsn_dim + config.num_classes, 128),
            nn.ReLU(),
            nn.Linear(128, 4),  # alpha, omega, epsilon, conf_adj
        )

    def forward(
        self,
        R: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor,
        logits: torch.Tensor,
    ) -> List[QualitySignals]:
        """Compute quality signals for batch."""
        batch_size = R.shape[0]

        # Compute R/S/N magnitudes
        r_mag = R.norm(dim=-1)  # [B]
        s_mag = S.norm(dim=-1)
        n_mag = N.norm(dim=-1)

        total = r_mag + s_mag + n_mag + 1e-8
        r_frac = r_mag / total
        s_frac = s_mag / total
        n_frac = n_mag / total

        # Softmax probabilities
        probs = F.softmax(logits, dim=-1)
        confidence = probs.max(dim=-1).values
        entropy = -(probs * torch.log(probs + 1e-8)).sum(dim=-1)

        # Alpha is directly R/(R+S+N) - simple and interpretable
        # No learned adjustment - keeps calibration consistent
        alpha = r_frac

        # Omega (OOD detection) from learned head
        rsn_flat = torch.cat([R, S, N], dim=-1)
        quality_input = torch.cat([rsn_flat, probs], dim=-1)
        quality_out = self.quality_head(quality_input)
        omega = torch.sigmoid(quality_out[:, 1])

        # Build quality signals
        signals = []
        for i in range(batch_size):
            flags = QualityFlags.NONE

            # Check for anomalies
            if n_frac[i].item() > self.c.noise_threshold:
                flags |= QualityFlags.POISON
            if s_frac[i].item() > self.c.superfluous_threshold and r_frac[i].item() < 0.2:
                flags |= QualityFlags.HALLUC
            if omega[i].item() < 0.5:
                flags |= QualityFlags.OOD
            if confidence[i].item() < self.c.conf_min:
                flags |= QualityFlags.LOW_CONF

            a = alpha[i].item()
            o = omega[i].item()
            # τ from α_ω (reliability-adjusted), NOT raw α
            quality_prior = 0.5
            alpha_omega = o * a + (1 - o) * quality_prior
            signals.append(QualitySignals(
                alpha=a,
                tau=1.0 / max(alpha_omega, 0.01),
                R=r_frac[i].item(),
                S=s_frac[i].item(),
                N=n_frac[i].item(),
                omega=omega[i].item(),
                confidence=confidence[i].item(),
                entropy=entropy[i].item(),
                flags=flags,
            ))

        return signals


class HybridYRSNClassifier(nn.Module):
    """
    Hybrid classifier with adaptive depth and YRSN quality routing.

    Routes samples based on quality:
    - High quality → shallow head (fast)
    - Medium quality → deep head (more capacity)
    - Low quality → ensemble or abstain
    """

    def __init__(self, config: Optional[HybridYRSNConfig] = None):
        super().__init__()
        self.c = config or HybridYRSNConfig()

        # Shared backbone
        self.backbone = self._make_backbone()

        # R/S/N projection (shared)
        self.rsn = RSNProjection(
            self.c.hidden_dim,
            self.c.r_dim,
            self.c.s_dim,
            self.c.n_dim,
        )

        # Shallow head (fast path)
        rsn_dim = self.c.r_dim + self.c.s_dim + self.c.n_dim
        self.shallow_head = nn.Sequential(
            nn.Linear(rsn_dim, self.c.hidden_dim),
            nn.ReLU(),
            nn.Dropout(self.c.backbone_dropout),
            nn.Linear(self.c.hidden_dim, self.c.num_classes),
        )

        # Deep adapter (only used when needed)
        self.deep_adapter = self._make_deep_adapter()

        # Deep head
        self.deep_rsn = RSNProjection(
            self.c.deep_adapter_dim,
            self.c.r_dim,
            self.c.s_dim,
            self.c.n_dim,
        )
        self.deep_head = nn.Sequential(
            nn.Linear(rsn_dim, self.c.deep_adapter_dim),
            nn.ReLU(),
            nn.Dropout(self.c.backbone_dropout),
            nn.Linear(self.c.deep_adapter_dim, self.c.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.c.hidden_dim, self.c.num_classes),
        )

        # Quality router
        self.quality_router = QualityRouter(self.c)

        # Ensemble combiner
        self.ensemble_weight = nn.Parameter(torch.tensor([0.5, 0.5]))

    def _make_backbone(self) -> nn.Module:
        """Create shared backbone."""
        layers = []
        in_dim = self.c.input_dim

        for i in range(self.c.backbone_layers):
            layers.extend([
                nn.Linear(in_dim, self.c.hidden_dim),
                nn.LayerNorm(self.c.hidden_dim),
                nn.GELU(),
                nn.Dropout(self.c.backbone_dropout),
            ])
            in_dim = self.c.hidden_dim

        return nn.Sequential(*layers)

    def _make_deep_adapter(self) -> nn.Module:
        """Create deep adapter layers."""
        layers = []
        in_dim = self.c.hidden_dim

        for i in range(self.c.deep_adapter_layers):
            out_dim = self.c.deep_adapter_dim if i == self.c.deep_adapter_layers - 1 else self.c.hidden_dim
            layers.extend([
                nn.Linear(in_dim, out_dim),
                nn.LayerNorm(out_dim),
                nn.GELU(),
                nn.Dropout(self.c.backbone_dropout),
            ])
            in_dim = out_dim

        return nn.Sequential(*layers)

    def _weighted_rsn(self, R: torch.Tensor, S: torch.Tensor, N: torch.Tensor) -> torch.Tensor:
        """Weight and concatenate R/S/N components."""
        return torch.cat([
            R * self.c.r_weight,
            S * self.c.s_weight,
            N * self.c.n_weight,
        ], dim=-1)

    def forward_shallow(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Forward through backbone + shallow head."""
        f0 = self.backbone(x)
        R, S, N = self.rsn(f0)
        rsn_weighted = self._weighted_rsn(R, S, N)
        logits = self.shallow_head(rsn_weighted)
        return logits, R, S, N

    def forward_deep(self, f0: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Forward through deep adapter + deep head."""
        f1 = self.deep_adapter(f0)
        R, S, N = self.deep_rsn(f1)
        rsn_weighted = self._weighted_rsn(R, S, N)
        logits = self.deep_head(rsn_weighted)
        return logits, R, S, N

    def forward(
        self,
        x: torch.Tensor,
        return_routes: bool = False,
    ) -> Tuple[torch.Tensor, Optional[List[RouteInfo]]]:
        """
        Forward pass with adaptive routing.

        During training: always compute both paths for gradient flow.
        During inference: route based on quality.

        Args:
            x: Input tensor [B, input_dim]
            return_routes: Whether to return routing information

        Returns:
            logits: Classification logits [B, num_classes]
            routes: Optional list of RouteInfo for each sample
        """
        batch_size = x.shape[0]

        # Always compute backbone
        f0 = self.backbone(x)

        # Shallow path
        R0, S0, N0 = self.rsn(f0)
        rsn0 = self._weighted_rsn(R0, S0, N0)
        logits0 = self.shallow_head(rsn0)

        # Deep path
        f1 = self.deep_adapter(f0)
        R1, S1, N1 = self.deep_rsn(f1)
        rsn1 = self._weighted_rsn(R1, S1, N1)
        logits1 = self.deep_head(rsn1)

        # Compute quality signals
        q_shallow = self.quality_router(R0, S0, N0, logits0)
        q_deep = self.quality_router(R1, S1, N1, logits1)

        # Route decisions
        routes = []
        final_logits = []

        for i in range(batch_size):
            qs = q_shallow[i]
            qd = q_deep[i]

            # Check for poison/hallucination flags
            has_bad_flag = qs.has_flag(QualityFlags.POISON) or qs.has_flag(QualityFlags.HALLUC)
            deep_has_bad_flag = qd.has_flag(QualityFlags.POISON) or qd.has_flag(QualityFlags.HALLUC)

            # Routing logic
            if qs.alpha >= self.c.alpha_high and not has_bad_flag:
                # Trust shallow
                route = "shallow_trust"
                selected_logits = logits0[i]
                quality = qs
            elif qd.alpha >= self.c.alpha_med and not deep_has_bad_flag:
                # Trust deep
                route = "deep_trust"
                selected_logits = logits1[i]
                quality = qd
            else:
                # Ensemble with alpha weighting
                alpha_sum = qs.alpha + qd.alpha + 1e-8
                w0 = qs.alpha / alpha_sum
                w1 = qd.alpha / alpha_sum

                probs0 = F.softmax(logits0[i], dim=-1)
                probs1 = F.softmax(logits1[i], dim=-1)
                ensemble_probs = w0 * probs0 + w1 * probs1

                max_prob = ensemble_probs.max().item()
                min_alpha = min(qs.alpha, qd.alpha)

                if max_prob < self.c.conf_min or min_alpha < self.c.alpha_low:
                    route = "abstain"
                    # Return uniform logits for abstain
                    selected_logits = torch.zeros_like(logits0[i])
                    # τ from α_ω (reliability-adjusted), NOT raw α
                    min_omega = min(qs.omega, qd.omega)
                    quality_prior = 0.5
                    alpha_omega = min_omega * min_alpha + (1 - min_omega) * quality_prior
                    quality = QualitySignals(
                        alpha=min_alpha,
                        tau=1.0 / max(alpha_omega, 0.01),
                        R=0.5 * (qs.R + qd.R),
                        S=0.5 * (qs.S + qd.S),
                        N=0.5 * (qs.N + qd.N),
                        omega=min_omega,
                        confidence=max_prob,
                        flags=qs.flags | qd.flags,
                    )
                else:
                    route = "ensemble_rerank"
                    # Convert back to logits
                    selected_logits = torch.log(ensemble_probs + 1e-8)
                    # τ already computed from α_ω in QualityRouter, so averaging is ok
                    quality = QualitySignals(
                        alpha=0.5 * (qs.alpha + qd.alpha),
                        tau=0.5 * (qs.tau + qd.tau),
                        R=0.5 * (qs.R + qd.R),
                        S=0.5 * (qs.S + qd.S),
                        N=0.5 * (qs.N + qd.N),
                        omega=0.5 * (qs.omega + qd.omega),
                        confidence=max_prob,
                        flags=qs.flags | qd.flags,
                    )

            final_logits.append(selected_logits)

            if return_routes:
                routes.append(RouteInfo(
                    route=route,
                    quality=quality,
                    shallow_quality=qs,
                    deep_quality=qd,
                ))

        final_logits = torch.stack(final_logits)

        if return_routes:
            return final_logits, routes
        return final_logits, None

    def forward_train(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Training forward - returns both paths for multi-task loss.

        Returns dict with:
            - shallow_logits: [B, C]
            - deep_logits: [B, C]
            - R0, S0, N0: Shallow RSN
            - R1, S1, N1: Deep RSN
        """
        f0 = self.backbone(x)

        # Shallow
        R0, S0, N0 = self.rsn(f0)
        rsn0 = self._weighted_rsn(R0, S0, N0)
        shallow_logits = self.shallow_head(rsn0)

        # Deep
        f1 = self.deep_adapter(f0)
        R1, S1, N1 = self.deep_rsn(f1)
        rsn1 = self._weighted_rsn(R1, S1, N1)
        deep_logits = self.deep_head(rsn1)

        return {
            'shallow_logits': shallow_logits,
            'deep_logits': deep_logits,
            'R0': R0, 'S0': S0, 'N0': N0,
            'R1': R1, 'S1': S1, 'N1': N1,
        }

    def compute_loss(
        self,
        outputs: Dict[str, torch.Tensor],
        targets: torch.Tensor,
        shallow_weight: float = 0.3,
        deep_weight: float = 0.7,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute multi-task loss.

        Both heads are trained, with more weight on deep head.
        """
        ce_loss = nn.CrossEntropyLoss(label_smoothing=self.c.label_smoothing)

        shallow_loss = ce_loss(outputs['shallow_logits'], targets)
        deep_loss = ce_loss(outputs['deep_logits'], targets)

        # R/S/N orthogonality regularization (via correlation of magnitudes)
        def ortho_reg(R, S, N):
            # Use magnitude correlation instead of direct product
            # This works even when dimensions differ
            r_mag = R.norm(dim=-1, keepdim=True)
            s_mag = S.norm(dim=-1, keepdim=True)
            n_mag = N.norm(dim=-1, keepdim=True)

            # Penalize when one dominates - encourage balanced contribution
            mags = torch.cat([r_mag, s_mag, n_mag], dim=-1)  # [B, 3]
            mags_norm = mags / (mags.sum(dim=-1, keepdim=True) + 1e-8)

            # Entropy-based: encourage spread across R/S/N
            entropy = -(mags_norm * torch.log(mags_norm + 1e-8)).sum(dim=-1).mean()
            # Max entropy is log(3) ≈ 1.1, we want high entropy
            return -entropy + 1.1  # Returns ~0 when balanced

        ortho_shallow = ortho_reg(outputs['R0'], outputs['S0'], outputs['N0'])
        ortho_deep = ortho_reg(outputs['R1'], outputs['S1'], outputs['N1'])

        # Contrastive quality loss: push alpha high for correct, low for incorrect
        def contrastive_quality_loss(R, S, N, logits, targets):
            # Compute alpha (R fraction)
            r_mag = R.norm(dim=-1)
            s_mag = S.norm(dim=-1)
            n_mag = N.norm(dim=-1)
            total_mag = r_mag + s_mag + n_mag + 1e-8
            alpha = r_mag / total_mag  # [B]

            # Check correctness with confidence margin
            probs = F.softmax(logits, dim=-1)
            correct_prob = probs.gather(1, targets.unsqueeze(1)).squeeze()
            preds = logits.argmax(dim=-1)
            is_correct = (preds == targets).float()

            # Margin-based targets: scale by confidence
            # High confidence correct → 0.9
            # Low confidence correct → 0.7
            # Low confidence wrong → 0.4
            # High confidence wrong → 0.2
            alpha_target = torch.where(
                is_correct.bool(),
                0.6 + 0.3 * correct_prob,   # correct: 0.6-0.9
                0.5 - 0.3 * (1 - correct_prob)  # wrong: 0.2-0.5
            )

            # Huber loss for robustness
            loss = F.smooth_l1_loss(alpha, alpha_target.detach())

            # Stronger variance encouragement
            alpha_var = alpha.var()
            target_var = 0.04  # We want at least 0.2 std = 0.04 var
            variance_loss = F.relu(target_var - alpha_var) * 10.0

            return loss + variance_loss

        contrastive_shallow = contrastive_quality_loss(
            outputs['R0'], outputs['S0'], outputs['N0'],
            outputs['shallow_logits'], targets
        )
        contrastive_deep = contrastive_quality_loss(
            outputs['R1'], outputs['S1'], outputs['N1'],
            outputs['deep_logits'], targets
        )

        total_loss = (
            shallow_weight * shallow_loss +
            deep_weight * deep_loss +
            0.01 * (ortho_shallow + ortho_deep) +
            0.5 * (contrastive_shallow + contrastive_deep)  # Strong contrastive signal
        )

        return {
            'total': total_loss,
            'shallow': shallow_loss,
            'deep': deep_loss,
            'ortho': ortho_shallow + ortho_deep,
            'contrastive': contrastive_shallow + contrastive_deep,
        }

    def predict(self, x: torch.Tensor) -> Tuple[torch.Tensor, List[RouteInfo]]:
        """Predict with routing information."""
        self.eval()
        with torch.no_grad():
            logits, routes = self.forward(x, return_routes=True)
            preds = logits.argmax(dim=-1)
        return preds, routes

    def get_route_stats(self, routes: List[RouteInfo]) -> Dict[str, float]:
        """Get routing statistics."""
        if not routes:
            return {}

        route_counts = {"shallow_trust": 0, "deep_trust": 0, "ensemble_rerank": 0, "abstain": 0}
        alphas = []

        for r in routes:
            route_counts[r.route] += 1
            alphas.append(r.quality.alpha)

        total = len(routes)
        return {
            "shallow_pct": 100.0 * route_counts["shallow_trust"] / total,
            "deep_pct": 100.0 * route_counts["deep_trust"] / total,
            "ensemble_pct": 100.0 * route_counts["ensemble_rerank"] / total,
            "abstain_pct": 100.0 * route_counts["abstain"] / total,
            "mean_alpha": np.mean(alphas),
            "std_alpha": np.std(alphas),
            "min_alpha": np.min(alphas),
            "max_alpha": np.max(alphas),
        }

    def calibrate_thresholds(self, data_loader, device: str = 'cpu') -> Dict[str, float]:
        """
        Adaptively calibrate routing thresholds from data distribution.

        YRSN principle: Thresholds should emerge from data, not be hardcoded.

        Uses percentiles from the alpha distribution:
        - alpha_high = percentile(adaptive_high_pct) → top samples go shallow
        - alpha_med = percentile(adaptive_med_pct) → middle samples go deep
        - alpha_low = percentile(adaptive_low_pct) → bottom samples abstain

        Call this after initial training warmup to calibrate routing.
        """
        self.eval()
        self.to(device)
        alphas = []

        with torch.no_grad():
            for X_batch, _ in data_loader:
                X_batch = X_batch.to(device)
                outputs = self.forward_train(X_batch)

                # Compute alpha from deep path (more reliable)
                r_mag = outputs['R1'].norm(dim=-1)
                s_mag = outputs['S1'].norm(dim=-1)
                n_mag = outputs['N1'].norm(dim=-1)
                total = r_mag + s_mag + n_mag + 1e-8
                batch_alphas = (r_mag / total).cpu().numpy()
                alphas.extend(batch_alphas)

        alphas = np.array(alphas)

        # Compute adaptive thresholds from percentiles
        self.c.alpha_high = float(np.percentile(alphas, self.c.adaptive_high_pct))
        self.c.alpha_med = float(np.percentile(alphas, self.c.adaptive_med_pct))
        self.c.alpha_low = float(np.percentile(alphas, self.c.adaptive_low_pct))

        return {
            "alpha_high": self.c.alpha_high,
            "alpha_med": self.c.alpha_med,
            "alpha_low": self.c.alpha_low,
            "alpha_mean": float(np.mean(alphas)),
            "alpha_std": float(np.std(alphas)),
        }

    def update_thresholds_online(self, alphas: List[float], momentum: float = 0.9) -> None:
        """
        Update thresholds with exponential moving average (online adaptation).

        YRSN principle: Thresholds should adapt as data distribution shifts.

        Args:
            alphas: Recent alpha values from a batch
            momentum: EMA momentum (higher = slower adaptation)
        """
        if len(alphas) < 10:
            return

        arr = np.array(alphas)
        new_high = float(np.percentile(arr, self.c.adaptive_high_pct))
        new_med = float(np.percentile(arr, self.c.adaptive_med_pct))
        new_low = float(np.percentile(arr, self.c.adaptive_low_pct))

        # EMA update
        self.c.alpha_high = momentum * self.c.alpha_high + (1 - momentum) * new_high
        self.c.alpha_med = momentum * self.c.alpha_med + (1 - momentum) * new_med
        self.c.alpha_low = momentum * self.c.alpha_low + (1 - momentum) * new_low


def create_hybrid_classifier(
    input_dim: int,
    num_classes: int,
    hidden_dim: int = 256,
    **kwargs,
) -> HybridYRSNClassifier:
    """Factory function for hybrid classifier."""
    config = HybridYRSNConfig(
        input_dim=input_dim,
        num_classes=num_classes,
        hidden_dim=hidden_dim,
        **kwargs,
    )
    return HybridYRSNClassifier(config)
