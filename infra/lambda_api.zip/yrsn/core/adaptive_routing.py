"""
DEPRECATED: Routing module moved to yrsn.adapters.routing

⚠️  This module is DEPRECATED and will be removed in a future version.
⚠️  Import from yrsn.adapters.routing instead.

WHY IT MOVED:
------------
Routing logic (deciding which tier/model to use) is CONTROL, not MEASUREMENT.
YRSN Core should only emit SIGNALS (confidence scores, recommended tiers).
Routing DECISIONS belong in ADAPTERS (optional control layer).

HEXAGONAL ARCHITECTURE:
----------------------
Core:     Emits {'confidence': 0.7, 'recommended_tier': 'SMALL'} (SIGNAL)
Adapters: Decides "Route to SMALL model" (CONTROL)

EXAMPLE:
-------
```python
# Core: Signal only
from yrsn.core import assess_quality
signal = assess_quality(data)  # {'quality': 0.7, 'recommended_tier': 'SMALL'}

# Adapter: Control
from yrsn.adapters.routing import AdaptiveRoutingCalibrator
calibrator = AdaptiveRoutingCalibrator()
decision = calibrator.route(signal)  # DECIDES routing
```

MIGRATION:
---------
OLD: from yrsn.core.adaptive_routing import AdaptiveRoutingCalibrator
NEW: from yrsn.adapters.routing import AdaptiveRoutingCalibrator

See: docs/HEX_ARCHITECTURE_DEEP_AUDIT.md
"""

import warnings

warnings.warn(
    "yrsn.core.adaptive_routing is deprecated. "
    "Routing logic moved to yrsn.adapters.routing. "
    "Per hexagonal architecture, routing decisions (control) belong in adapters, "
    "not core (measurement/signals). "
    "Update your imports: 'from yrsn.adapters.routing import ...'",
    DeprecationWarning,
    stacklevel=2
)

# Re-export from new location for backward compatibility
try:
    from yrsn.adapters.routing.adaptive_routing import *
except ImportError as e:
    warnings.warn(
        f"Could not import from yrsn.adapters.routing: {e}. "
        "The routing module may not be fully migrated yet.",
        ImportWarning
    )
