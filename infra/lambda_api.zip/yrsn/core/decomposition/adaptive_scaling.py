"""
Adaptive Scaling Module (Pillar 2 Integration)
==============================================

TERMINOLOGY NOTE:
    "temperature" in this module refers to τ_α (tau_alpha), YRSN's EMERGENT
    quality-derived signal - NOT the LLM API temperature hyperparameter.

    τ_α = f(α_ω) where α_ω is reliability-adjusted quality from R/S/N decomposition.

Integrates all Pillar 2 components:
- Temperature-Quality Duality (from temperature.py)
- BBP Phase Transitions (from phase_transitions.py)
- Spectral Analysis (from spectral_analysis.py)

This module provides unified APIs for:
1. Adaptive rank selection based on quality
2. Temperature-driven softmax scaling
3. Online quality tracking and adaptation
4. Spectral-guided rank recommendations

Key Principle: REUSE existing implementations, don't reinvent.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple
from enum import Enum
import time
from collections import deque
import numpy as np

# Reuse existing temperature module
from yrsn.core.temperature import (
    map_quality_to_temperature,
    get_quality_phase,
    get_phase_characteristics,
    QualityPhase,
    ActivationMode,
    TemperatureParams,
    softmax_with_temperature,
    ALPHA_HIGH_THRESHOLD,
    ALPHA_LOW_THRESHOLD,
    TAU_CRITICAL_1,
    TAU_CRITICAL_2,
)

# Reuse BBP phase transitions
from yrsn.core.decomposition.phase_transitions import (
    compute_bbp_threshold,
    compute_bbp_threshold_inverse,
    quality_supports_rank,
    get_rank_headroom,
    BBPThresholdTable,
    PhaseTransitionDetector,
    TransitionType,
    RankRecommendation,
)

# Reuse spectral analysis
from yrsn.core.decomposition.spectral_analysis import (
    compute_mp_bounds,
    EigenvalueTracker,
    SignalNoiseAnalyzer,
    quick_spectral_analysis,
    estimate_quality_from_matrix,
)


# =============================================================================
# Adaptive Scaling Configuration
# =============================================================================


@dataclass
class AdaptiveScalingConfig:
    """Configuration for adaptive scaling system."""

    # Temperature mapping
    temperature_mode: str = "power"  # linear, power, log, sigmoid
    tau_min: float = 0.1
    tau_max: float = 5.0

    # Rank bounds
    rank_min: int = 1
    rank_max: int = 100

    # Adaptation behavior
    adaptation_rate: float = 0.1  # Exponential moving average rate
    hysteresis: float = 0.05  # Prevents oscillation
    min_samples_for_adaptation: int = 10

    # Spectral analysis
    use_spectral_guidance: bool = True
    spectral_weight: float = 0.5  # Balance spectral vs BBP

    # Safety
    conservative_mode: bool = False  # Prefer lower ranks when uncertain


@dataclass
class AdaptiveState:
    """Current state of adaptive scaling."""

    # Quality tracking
    current_quality: float = 0.5
    smoothed_quality: float = 0.5
    quality_std: float = 0.1

    # Rank tracking
    current_rank: int = 1
    recommended_rank: int = 1
    bbp_max_rank: int = 1
    spectral_rank: Optional[int] = None

    # Tau (τ = 1/α_ω where α_ω = ω·α + (1-ω)·prior)
    current_tau: float = 2.0
    phase: QualityPhase = QualityPhase.MEDIUM

    # Statistics
    samples_seen: int = 0
    last_adaptation_time: float = 0.0


# =============================================================================
# Main Adaptive Scaling Manager
# =============================================================================


class AdaptiveScalingManager:
    """
    Unified adaptive scaling manager.

    Integrates temperature-quality mapping, BBP rank selection,
    and spectral analysis into a single coherent system.

    Example
    -------
    >>> manager = AdaptiveScalingManager()
    >>> result = manager.update(quality=0.7)
    >>> print(f"Rank: {result.recommended_rank}, τ: {result.tau}")
    """

    def __init__(self, config: Optional[AdaptiveScalingConfig] = None):
        """
        Initialize adaptive scaling manager.

        Parameters
        ----------
        config : AdaptiveScalingConfig, optional
            Configuration. Uses defaults if not provided.
        """
        self.config = config or AdaptiveScalingConfig()
        self.state = AdaptiveState()

        # Initialize sub-components
        self._bbp_table = BBPThresholdTable.build(max_rank=self.config.rank_max)
        self._phase_detector = PhaseTransitionDetector(
            window_size=self.config.min_samples_for_adaptation,
            hysteresis=self.config.hysteresis,
        )
        self._eigenvalue_tracker = EigenvalueTracker() if self.config.use_spectral_guidance else None
        self._snr_analyzer = SignalNoiseAnalyzer() if self.config.use_spectral_guidance else None

        # Quality history for smoothing
        self._quality_history: deque = deque(maxlen=100)

        # Temperature params
        self._temp_params = TemperatureParams(
            mode=ActivationMode(self.config.temperature_mode),
            tau_min=self.config.tau_min,
            tau_max=self.config.tau_max,
        )

    def update(self, quality: float) -> "AdaptiveResult":
        """
        Update adaptive state with new quality observation.

        Parameters
        ----------
        quality : float
            Quality score α in [0, 1]

        Returns
        -------
        AdaptiveResult
            Updated recommendations
        """
        now = time.time()
        self.state.samples_seen += 1
        self._quality_history.append(quality)

        # Update smoothed quality (EMA)
        self.state.current_quality = quality
        self.state.smoothed_quality = (
            self.config.adaptation_rate * quality
            + (1 - self.config.adaptation_rate) * self.state.smoothed_quality
        )

        # Compute quality statistics
        if len(self._quality_history) >= 2:
            self.state.quality_std = float(np.std(list(self._quality_history)))

        # Update phase detector
        self._phase_detector.update(self.state.smoothed_quality)

        # Compute BBP-based max rank
        self.state.bbp_max_rank = self._bbp_table.get_max_rank_for_quality(
            self.state.smoothed_quality
        )

        # Determine phase
        self.state.phase = get_quality_phase(self.state.smoothed_quality)

        # Compute tau (τ = 1/α_ω)
        self.state.current_tau = map_quality_to_temperature(
            self.state.smoothed_quality,
            mode=self.config.temperature_mode,
            params=self._temp_params,
        )

        # Compute recommended rank
        self.state.recommended_rank = self._compute_recommended_rank()
        self.state.current_rank = self.state.recommended_rank

        self.state.last_adaptation_time = now

        return self._build_result()

    def update_from_matrix(self, matrix: np.ndarray) -> "AdaptiveResult":
        """
        Update adaptive state directly from a numpy matrix.

        Parameters
        ----------
        matrix : np.ndarray
            Matrix [B, L, D] or [L, D]

        Returns
        -------
        AdaptiveResult
            Updated recommendations
        """
        if not self.config.use_spectral_guidance or self._eigenvalue_tracker is None:
            raise ValueError("Spectral guidance not enabled in config")

        # Get spectral analysis
        snapshot = self._eigenvalue_tracker.update(matrix)
        quality = snapshot.quality_alpha

        # Get spectral rank recommendation
        if self._snr_analyzer is not None:
            gamma = self._compute_gamma(matrix)
            snr_result = self._snr_analyzer.analyze(
                snapshot.eigenvalues, gamma=gamma
            )
            self.state.spectral_rank = snr_result.recommended_rank

        # Update with extracted quality
        return self.update(quality)

    def _compute_gamma(self, matrix: np.ndarray) -> float:
        """Compute aspect ratio for spectral analysis."""
        if len(matrix.shape) == 3:
            n_samples = matrix.shape[0] * matrix.shape[1]
            n_features = matrix.shape[2]
        elif len(matrix.shape) == 2:
            n_samples = matrix.shape[0]
            n_features = matrix.shape[1]
        else:
            return 1.0
        return n_samples / max(n_features, 1)

    def _compute_recommended_rank(self) -> int:
        """Compute recommended rank balancing BBP and spectral."""
        bbp_rank = self.state.bbp_max_rank

        if self.config.use_spectral_guidance and self.state.spectral_rank is not None:
            # Weighted combination
            w = self.config.spectral_weight
            combined = w * self.state.spectral_rank + (1 - w) * bbp_rank
            rank = int(round(combined))
        else:
            rank = bbp_rank

        # Apply bounds
        rank = max(self.config.rank_min, min(self.config.rank_max, rank))

        # Conservative mode: prefer lower ranks
        if self.config.conservative_mode:
            rank = min(rank, bbp_rank)

        return rank

    def _build_result(self) -> "AdaptiveResult":
        """Build result object from current state."""
        # Get phase detector recommendation
        rec = self._phase_detector.get_recommended_rank(self.state.smoothed_quality)

        return AdaptiveResult(
            quality=self.state.current_quality,
            smoothed_quality=self.state.smoothed_quality,
            tau=self.state.current_tau,
            phase=self.state.phase,
            recommended_rank=self.state.recommended_rank,
            bbp_max_rank=self.state.bbp_max_rank,
            spectral_rank=self.state.spectral_rank,
            rank_action=rec.action,
            rank_headroom=get_rank_headroom(
                self.state.smoothed_quality,
                self.state.current_rank,
            ),
            quality_std=self.state.quality_std,
        )

    def apply_softmax(self, scores: np.ndarray) -> np.ndarray:
        """
        Apply temperature-scaled softmax to scores.

        Parameters
        ----------
        scores : np.ndarray
            Raw scores

        Returns
        -------
        np.ndarray
            Probability distribution
        """
        return softmax_with_temperature(scores, self.state.current_tau)

    def reset(self) -> None:
        """Reset adaptive state."""
        self.state = AdaptiveState()
        self._phase_detector.reset()
        self._quality_history.clear()
        if self._eigenvalue_tracker is not None:
            self._eigenvalue_tracker.reset()

    def get_state(self) -> Dict[str, Any]:
        """Get current state as dictionary."""
        return {
            "quality": self.state.current_quality,
            "smoothed_quality": self.state.smoothed_quality,
            "quality_std": self.state.quality_std,
            "tau": self.state.current_tau,
            "phase": self.state.phase.value,
            "current_rank": self.state.current_rank,
            "recommended_rank": self.state.recommended_rank,
            "bbp_max_rank": self.state.bbp_max_rank,
            "spectral_rank": self.state.spectral_rank,
            "samples_seen": self.state.samples_seen,
        }


# =============================================================================
# Result Objects
# =============================================================================


@dataclass
class AdaptiveResult:
    """Result from adaptive scaling update."""

    # Quality metrics
    quality: float
    smoothed_quality: float
    quality_std: float

    # Tau (τ = 1/α_ω)
    tau: float
    phase: QualityPhase

    # Rank recommendations
    recommended_rank: int
    bbp_max_rank: int
    spectral_rank: Optional[int]
    rank_action: str  # "increase", "decrease", "maintain"
    rank_headroom: int

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "quality": self.quality,
            "smoothed_quality": self.smoothed_quality,
            "quality_std": self.quality_std,
            "tau": self.tau,
            "phase": self.phase.value,
            "recommended_rank": self.recommended_rank,
            "bbp_max_rank": self.bbp_max_rank,
            "spectral_rank": self.spectral_rank,
            "rank_action": self.rank_action,
            "rank_headroom": self.rank_headroom,
        }


# =============================================================================
# Convenience Functions
# =============================================================================


def get_adaptive_tau(quality: float, mode: str = "power") -> float:
    """
    Get tau (τ = 1/α_ω) for a quality value.

    Convenience wrapper around map_quality_to_temperature.

    Parameters
    ----------
    quality : float
        Quality score α in [0, 1]
    mode : str
        Activation mode

    Returns
    -------
    float
        Tau τ (emergent from quality measurement)
    """
    return map_quality_to_temperature(quality, mode=mode)


# Backward compatibility alias
get_adaptive_temperature = get_adaptive_tau


def get_adaptive_rank(
    quality: float,
    use_conservative: bool = False,
) -> int:
    """
    Get recommended rank for a quality value.

    Uses BBP thresholds for rank selection.

    Parameters
    ----------
    quality : float
        Quality score α in [0, 1]
    use_conservative : bool
        If True, prefer lower ranks

    Returns
    -------
    int
        Recommended rank
    """
    table = BBPThresholdTable.build()
    rank = table.get_max_rank_for_quality(quality)

    if use_conservative:
        rank = max(1, rank - 1)

    return rank


def create_adaptive_manager(
    temperature_mode: str = "power",
    use_spectral: bool = True,
    conservative: bool = False,
) -> AdaptiveScalingManager:
    """
    Create configured adaptive scaling manager.

    Parameters
    ----------
    temperature_mode : str
        Temperature activation mode
    use_spectral : bool
        Enable spectral guidance
    conservative : bool
        Prefer lower ranks

    Returns
    -------
    AdaptiveScalingManager
        Configured manager
    """
    config = AdaptiveScalingConfig(
        temperature_mode=temperature_mode,
        use_spectral_guidance=use_spectral,
        conservative_mode=conservative,
    )
    return AdaptiveScalingManager(config)


# =============================================================================
# Quick Analysis Functions
# =============================================================================


def quick_adaptive_analysis(quality: float) -> Dict[str, Any]:
    """
    Quick analysis of quality value without persistent state.

    Parameters
    ----------
    quality : float
        Quality score α in [0, 1]

    Returns
    -------
    dict
        Analysis including tau, rank, phase
    """
    table = BBPThresholdTable.build()

    return {
        "quality": quality,
        "phase": get_quality_phase(quality).value,
        "tau": {
            "linear": map_quality_to_temperature(quality, "linear"),
            "power": map_quality_to_temperature(quality, "power"),
            "log": map_quality_to_temperature(quality, "log"),
            "sigmoid": map_quality_to_temperature(quality, "sigmoid"),
        },
        "bbp_max_rank": table.get_max_rank_for_quality(quality),
        "bbp_threshold_at_rank": {
            1: compute_bbp_threshold(1),
            2: compute_bbp_threshold(2),
            3: compute_bbp_threshold(3),
            5: compute_bbp_threshold(5),
            10: compute_bbp_threshold(10),
        },
        "recommendations": get_phase_characteristics(get_quality_phase(quality)),
    }


def analyze_matrix_adaptive(matrix: np.ndarray) -> Dict[str, Any]:
    """
    Analyze numpy matrix and provide adaptive recommendations.

    Parameters
    ----------
    matrix : np.ndarray
        Matrix [B, L, D] or [L, D]

    Returns
    -------
    dict
        Complete adaptive analysis
    """
    # Get quality from spectral analysis
    quality = estimate_quality_from_matrix(matrix)

    # Get spectral details
    spectral = quick_spectral_analysis(matrix)

    # Get adaptive analysis
    adaptive = quick_adaptive_analysis(quality)

    # Combine
    return {
        "spectral": {
            "quality_alpha": spectral.quality_alpha,
            "snr": spectral.snr,
            "effective_rank": spectral.effective_rank,
            "recommended_rank": spectral.recommended_rank,
        },
        "adaptive": adaptive,
        "combined_recommendation": {
            "quality": quality,
            "tau": map_quality_to_temperature(quality, "power"),
            "rank": spectral.recommended_rank,
            "phase": get_quality_phase(quality).value,
        },
    }


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config and state
    "AdaptiveScalingConfig",
    "AdaptiveState",
    "AdaptiveResult",

    # Main manager
    "AdaptiveScalingManager",
    "create_adaptive_manager",

    # Convenience functions
    "get_adaptive_tau",
    "get_adaptive_temperature",  # Backward compat alias
    "get_adaptive_rank",
    "quick_adaptive_analysis",
    "analyze_matrix_adaptive",
]
