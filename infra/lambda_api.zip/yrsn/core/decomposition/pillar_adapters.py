"""
Pillar Adapters - Bridge Functions Between Pillars
===================================================

Provides adapter functions to connect:
- Pillar 1 (Decomposition) → Pillar 2 (Adaptive Scaling)
- Pillar 2 (Adaptive Scaling) → Pillar 3 (Collapse Detection)
- Full integration pipeline

These adapters ensure data flows correctly between pillars with
appropriate type transformations and threshold adjustments.

Usage:
    from yrsn.core.decomposition.pillar_adapters import (
        adapt_rsn_to_quality,
        adapt_quality_to_collapse_thresholds,
        create_integrated_pipeline,
    )

    # Get quality from R/S/N
    quality = adapt_rsn_to_quality(R=0.5, S=0.3, N=0.2)

    # Get phase-aware thresholds for collapse detection
    thresholds = adapt_quality_to_collapse_thresholds(
        quality=0.7,
        phase=QualityPhase.HIGH,
    )
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum

# Pillar 2 imports
from yrsn.core.temperature import (
    QualityPhase,
    get_quality_phase,
    map_quality_to_temperature,
)
from yrsn.core.decomposition.phase_transitions import (
    compute_bbp_threshold,
    quality_supports_rank,
    get_rank_headroom,
)

# Pillar 3 imports
from yrsn.core.decomposition.collapse import (
    CollapseType,
    Severity,
    CollapseAnalysis,
    CollapseSignature,
    CollapseDetector,
)


# =============================================================================
# Pillar 1 → Pillar 2 Adapters
# =============================================================================


def adapt_rsn_to_quality(
    R: float,
    S: float,
    N: float,
    mode: str = "relevance",
) -> float:
    """
    Convert R/S/N decomposition to quality metric for Pillar 2.

    Parameters
    ----------
    R, S, N : float
        YRSN component ratios [0, 1]
    mode : str
        Quality computation mode:
        - "relevance": α = R (default, simple)
        - "y_score": α = R + 0.5*S (penalizes superfluous less)
        - "inverse_risk": α = 1 - (S + 1.5*N) (risk-based)
        - "weighted": α = R - 0.5*S - N (penalizes both S and N)

    Returns
    -------
    float
        Quality metric α ∈ [0, 1]
    """
    if mode == "relevance":
        return R
    elif mode == "y_score":
        return min(1.0, R + 0.5 * S)
    elif mode == "inverse_risk":
        risk = S + 1.5 * N
        return max(0.0, 1.0 - risk)
    elif mode == "weighted":
        return max(0.0, min(1.0, R - 0.5 * S - N))
    else:
        raise ValueError(f"Unknown quality mode: {mode}")


def adapt_rsn_to_pillar2_input(
    R: float,
    S: float,
    N: float,
    quality_mode: str = "relevance",
) -> Dict[str, Any]:
    """
    Adapt Pillar 1 output to Pillar 2 input format.

    Returns
    -------
    dict
        Complete input for AdaptiveScalingManager.update()
    """
    quality = adapt_rsn_to_quality(R, S, N, mode=quality_mode)

    return {
        "quality": quality,
        "R": R,
        "S": S,
        "N": N,
        "risk_score": S + 1.5 * N,
    }


# =============================================================================
# Pillar 2 → Pillar 3 Adapters
# =============================================================================


@dataclass
class PhaseAwareThresholds:
    """Collapse detection thresholds adjusted by quality phase."""

    poisoning_n_threshold: float
    distraction_s_threshold: float
    conflict_n_threshold: float
    conflict_s_threshold: float
    clash_variance_threshold: float

    # Metadata
    base_phase: QualityPhase
    quality: float
    adjustment_factor: float

    def to_collapse_signature(self) -> CollapseSignature:
        """Convert to CollapseSignature for detector."""
        return CollapseSignature(
            POISONING_N_THRESHOLD=self.poisoning_n_threshold,
            DISTRACTION_S_THRESHOLD=self.distraction_s_threshold,
            CONFLICT_N_THRESHOLD=self.conflict_n_threshold,
            CONFLICT_S_THRESHOLD=self.conflict_s_threshold,
            CLASH_S_VARIANCE_THRESHOLD=self.clash_variance_threshold,
        )


# Default thresholds (from collapse_detection.py)
DEFAULT_THRESHOLDS = {
    "poisoning_n": 0.30,
    "distraction_s": 0.40,
    "confusion_n": 0.20,
    "confusion_s": 0.25,
    "clash_variance": 0.04,
}

# Phase multipliers: lower = stricter thresholds
PHASE_MULTIPLIERS = {
    QualityPhase.HIGH: 0.8,      # Stricter at high quality
    QualityPhase.MEDIUM: 1.0,    # Default thresholds
    QualityPhase.LOW: 1.2,       # More lenient at low quality
}


def adapt_quality_to_collapse_thresholds(
    quality: float,
    phase: Optional[QualityPhase] = None,
    base_thresholds: Optional[Dict[str, float]] = None,
    custom_multipliers: Optional[Dict[QualityPhase, float]] = None,
) -> PhaseAwareThresholds:
    """
    Adjust collapse detection thresholds based on quality phase.

    At HIGH quality, we expect better context and use stricter thresholds.
    At LOW quality, we use more lenient thresholds to avoid false positives.

    Parameters
    ----------
    quality : float
        Quality metric α ∈ [0, 1]
    phase : QualityPhase, optional
        Quality phase (computed from quality if not provided)
    base_thresholds : dict, optional
        Base threshold values (uses defaults if not provided)
    custom_multipliers : dict, optional
        Custom phase multipliers

    Returns
    -------
    PhaseAwareThresholds
        Adjusted thresholds for collapse detection
    """
    if phase is None:
        phase = get_quality_phase(quality)

    thresholds = base_thresholds or DEFAULT_THRESHOLDS
    multipliers = custom_multipliers or PHASE_MULTIPLIERS

    factor = multipliers.get(phase, 1.0)

    return PhaseAwareThresholds(
        poisoning_n_threshold=thresholds["poisoning_n"] * factor,
        distraction_s_threshold=thresholds["distraction_s"] * factor,
        conflict_n_threshold=thresholds["confusion_n"] * factor,
        conflict_s_threshold=thresholds["confusion_s"] * factor,
        clash_variance_threshold=thresholds["clash_variance"] * factor,
        base_phase=phase,
        quality=quality,
        adjustment_factor=factor,
    )


def adapt_tau_for_constraints(
    base_tau: float,
    has_fatal_violation: bool,
    has_warnings: bool,
    warning_count: int = 0,
) -> float:
    """
    Adjust tau based on constraint violations.

    When constraints are violated, we may want to adjust tau
    to encourage more exploration (higher τ) or tighter focus (lower τ).

    Parameters
    ----------
    base_tau : float
        Tau (τ = 1/α_ω) from Pillar 2
    has_fatal_violation : bool
        Whether ACTUAL tier constraint is violated
    has_warnings : bool
        Whether LEARNED tier constraints are violated
    warning_count : int
        Number of warning-level violations

    Returns
    -------
    float
        Adjusted tau
    """
    adjusted = base_tau

    if has_fatal_violation:
        # Fatal violation: increase tau for more exploration
        # to find alternative contexts
        adjusted *= 1.5
    elif has_warnings:
        # Warnings: slight increase based on count
        adjusted *= 1.0 + (0.1 * min(warning_count, 3))

    # Clamp to reasonable bounds
    return max(0.1, min(5.0, adjusted))


# Backward compatibility alias
adapt_temperature_for_constraints = adapt_tau_for_constraints


def adapt_rank_for_collapse_type(
    recommended_rank: int,
    collapse_type: CollapseType,
    collapse_severity: Severity,
) -> int:
    """
    Adjust recommended rank based on detected collapse type.

    Different collapse types may benefit from different decomposition ranks.

    Parameters
    ----------
    recommended_rank : int
        Rank recommendation from Pillar 2
    collapse_type : CollapseType
        Detected collapse type
    collapse_severity : Severity
        Collapse severity

    Returns
    -------
    int
        Adjusted rank recommendation
    """
    if collapse_type == CollapseType.NONE:
        return recommended_rank

    adjustment = 0

    # Collapse-specific adjustments
    if collapse_type == CollapseType.CONFLICT:
        # Confusion benefits from higher rank for better separation
        adjustment = 2
    elif collapse_type == CollapseType.POISONING:
        # Poisoning may need lower rank to focus on signal
        adjustment = -1
    elif collapse_type == CollapseType.DISTRACTION:
        # Distraction benefits from moderate increase
        adjustment = 1
    elif collapse_type == CollapseType.CLASH:
        # Clash needs higher rank to separate sources
        adjustment = 2

    # Severity scaling
    if collapse_severity in (Severity.HIGH, Severity.CRITICAL):
        adjustment = int(adjustment * 1.5)

    # Apply adjustment with bounds
    return max(1, recommended_rank + adjustment)


# =============================================================================
# Integrated Pipeline Result
# =============================================================================


@dataclass
class IntegratedAnalysis:
    """Complete analysis result from integrated Pillar 1→2→3 pipeline."""

    # Pillar 1: Decomposition
    R: float
    S: float
    N: float

    # Pillar 2: Adaptive Scaling
    quality: float
    phase: QualityPhase
    tau: float  # τ = 1/α_ω
    recommended_rank: int
    bbp_threshold: float

    # Pillar 3: Collapse Detection
    collapse_analysis: CollapseAnalysis
    phase_aware_thresholds: PhaseAwareThresholds

    # Adjustments
    adjusted_tau: float
    adjusted_rank: int

    # Metadata
    quality_mode: str = "relevance"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "pillar1": {
                "R": self.R,
                "S": self.S,
                "N": self.N,
            },
            "pillar2": {
                "quality": self.quality,
                "phase": self.phase.value,
                "tau": self.tau,
                "recommended_rank": self.recommended_rank,
                "bbp_threshold": self.bbp_threshold,
            },
            "pillar3": {
                "collapse_type": self.collapse_analysis.collapse_type.name,
                "severity": self.collapse_analysis.severity.value,
                "risk_score": self.collapse_analysis.risk_score,
                "is_collapsed": self.collapse_analysis.is_collapsed,
            },
            "adjusted": {
                "tau": self.adjusted_tau,
                "rank": self.adjusted_rank,
            },
            "meta": {
                "quality_mode": self.quality_mode,
                "threshold_adjustment": self.phase_aware_thresholds.adjustment_factor,
            },
        }

    @property
    def is_healthy(self) -> bool:
        """Check if context is healthy (no collapse)."""
        return not self.collapse_analysis.is_collapsed

    @property
    def needs_action(self) -> bool:
        """Check if immediate action is needed."""
        return self.collapse_analysis.needs_immediate_action

    @property
    def summary(self) -> str:
        """Get human-readable summary."""
        if self.is_healthy:
            return f"Healthy ({self.phase.value} quality, τ={self.adjusted_tau:.2f})"
        else:
            return (
                f"{self.collapse_analysis.collapse_type.name} "
                f"({self.collapse_analysis.severity.value}): "
                f"{self.collapse_analysis.recommendation}"
            )


# =============================================================================
# Integration Pipeline
# =============================================================================


class IntegratedPipeline:
    """
    Integrated pipeline for Pillar 1 → Pillar 2 → Pillar 3 processing.

    Orchestrates the full data flow with proper type transformations
    and threshold adjustments between pillars.

    Usage:
        pipeline = IntegratedPipeline()
        result = pipeline.process(R=0.5, S=0.3, N=0.2)
        print(result.summary)
    """

    def __init__(
        self,
        quality_mode: str = "relevance",
        temperature_mode: str = "power",
        use_phase_aware_thresholds: bool = True,
        use_constraint_temperature_adjustment: bool = True,
        use_collapse_rank_adjustment: bool = True,
    ):
        """
        Initialize pipeline.

        Parameters
        ----------
        quality_mode : str
            How to compute quality from R/S/N
        temperature_mode : str
            Temperature mapping mode for Pillar 2
        use_phase_aware_thresholds : bool
            Adjust collapse thresholds by quality phase
        use_constraint_temperature_adjustment : bool
            Adjust temperature based on constraint violations
        use_collapse_rank_adjustment : bool
            Adjust rank based on collapse type
        """
        self.quality_mode = quality_mode
        self.temperature_mode = temperature_mode
        self.use_phase_aware_thresholds = use_phase_aware_thresholds
        self.use_constraint_temperature_adjustment = use_constraint_temperature_adjustment
        self.use_collapse_rank_adjustment = use_collapse_rank_adjustment

        # Detector cache (lazily created with phase-aware thresholds)
        self._detectors: Dict[QualityPhase, CollapseDetector] = {}

    def _get_detector(self, phase: QualityPhase, quality: float) -> CollapseDetector:
        """Get or create detector for phase."""
        if not self.use_phase_aware_thresholds:
            # Use default detector
            if None not in self._detectors:
                self._detectors[None] = CollapseDetector()
            return self._detectors[None]

        if phase not in self._detectors:
            thresholds = adapt_quality_to_collapse_thresholds(quality, phase)
            signature = thresholds.to_collapse_signature()
            self._detectors[phase] = CollapseDetector(signature=signature)

        return self._detectors[phase]

    def process(
        self,
        R: float,
        S: float,
        N: float,
        source_S_values: Optional[List[float]] = None,
        current_rank: int = 1,
    ) -> IntegratedAnalysis:
        """
        Process R/S/N through full Pillar 1→2→3 pipeline.

        Parameters
        ----------
        R, S, N : float
            YRSN component ratios from Pillar 1
        source_S_values : list, optional
            Per-source S values for clash detection
        current_rank : int
            Current decomposition rank

        Returns
        -------
        IntegratedAnalysis
            Complete analysis with all pillar outputs
        """
        # === Pillar 1 → Pillar 2 ===
        quality = adapt_rsn_to_quality(R, S, N, mode=self.quality_mode)
        phase = get_quality_phase(quality)
        tau = map_quality_to_temperature(quality, mode=self.temperature_mode)
        recommended_rank = current_rank + get_rank_headroom(quality, current_rank)
        bbp_threshold = compute_bbp_threshold(current_rank)

        # === Pillar 2 → Pillar 3 ===
        phase_thresholds = adapt_quality_to_collapse_thresholds(quality, phase)
        detector = self._get_detector(phase, quality)
        collapse_analysis = detector.detect(R, S, N, source_S_values)

        # === Adjustments ===
        # Adjust tau based on collapse
        adjusted_tau = tau
        if self.use_constraint_temperature_adjustment:
            has_fatal = collapse_analysis.severity == Severity.CRITICAL
            has_warnings = collapse_analysis.severity in (Severity.MEDIUM, Severity.HIGH)
            adjusted_tau = adapt_tau_for_constraints(
                tau, has_fatal, has_warnings
            )

        # Adjust rank based on collapse type
        adjusted_rank = recommended_rank
        if self.use_collapse_rank_adjustment:
            adjusted_rank = adapt_rank_for_collapse_type(
                recommended_rank,
                collapse_analysis.collapse_type,
                collapse_analysis.severity,
            )

        return IntegratedAnalysis(
            # Pillar 1
            R=R,
            S=S,
            N=N,
            # Pillar 2
            quality=quality,
            phase=phase,
            tau=tau,
            recommended_rank=recommended_rank,
            bbp_threshold=bbp_threshold,
            # Pillar 3
            collapse_analysis=collapse_analysis,
            phase_aware_thresholds=phase_thresholds,
            # Adjustments
            adjusted_tau=adjusted_tau,
            adjusted_rank=adjusted_rank,
            # Meta
            quality_mode=self.quality_mode,
        )

    def process_batch(
        self,
        rsn_batch: List[Tuple[float, float, float]],
    ) -> List[IntegratedAnalysis]:
        """Process batch of R/S/N tuples."""
        return [self.process(R, S, N) for R, S, N in rsn_batch]


# =============================================================================
# Convenience Functions
# =============================================================================


def create_integrated_pipeline(
    quality_mode: str = "relevance",
    phase_aware: bool = True,
) -> IntegratedPipeline:
    """Create configured integration pipeline."""
    return IntegratedPipeline(
        quality_mode=quality_mode,
        use_phase_aware_thresholds=phase_aware,
    )


def quick_integrated_analysis(
    R: float,
    S: float,
    N: float,
) -> IntegratedAnalysis:
    """Quick integrated analysis with default settings."""
    pipeline = IntegratedPipeline()
    return pipeline.process(R, S, N)


def get_phase_threshold_multipliers() -> Dict[str, float]:
    """Get the phase-to-threshold multiplier mapping."""
    return {phase.value: mult for phase, mult in PHASE_MULTIPLIERS.items()}


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Pillar 1 → 2 adapters
    "adapt_rsn_to_quality",
    "adapt_rsn_to_pillar2_input",

    # Pillar 2 → 3 adapters
    "PhaseAwareThresholds",
    "adapt_quality_to_collapse_thresholds",
    "adapt_tau_for_constraints",
    "adapt_temperature_for_constraints",  # Backward compat alias
    "adapt_rank_for_collapse_type",

    # Integrated pipeline
    "IntegratedAnalysis",
    "IntegratedPipeline",
    "create_integrated_pipeline",
    "quick_integrated_analysis",

    # Utilities
    "get_phase_threshold_multipliers",
    "DEFAULT_THRESHOLDS",
    "PHASE_MULTIPLIERS",
]
