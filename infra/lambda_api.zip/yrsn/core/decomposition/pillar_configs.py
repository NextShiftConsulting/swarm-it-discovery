"""
Pillar Configuration Module
===========================

TERMINOLOGY NOTE:
    - τ_α (tau_alpha): YRSN's EMERGENT quality-derived signal (NOT a hyperparameter)
    - contrastive_tau: InfoNCE scaling factor (separate from YRSN's τ_α)
    - LLM temperature: API hyperparameter (external, NOT τ_α)

Unified configuration dataclasses for Pillar 1 (Semantic Decomposition)
and Pillar 2 (Phase Transitions & Temperature-Quality Duality).

These configs consolidate all parameters needed for each pillar,
making it easy to configure the entire system from a single place.

Usage:
    from yrsn.core.decomposition.pillar_configs import (
        Pillar1Config,
        Pillar2Config,
        create_default_configs,
    )

    # Create with defaults
    p1_config = Pillar1Config()
    p2_config = Pillar2Config()

    # Or load from dict/JSON
    p1_config = Pillar1Config.from_dict(config_dict)
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List
from enum import Enum

# Import canonical thresholds to avoid duplication
from yrsn.core.decomposition.collapse import CollapseSignature

# Create instance once for default values
_DEFAULT_SIG = CollapseSignature()


# =============================================================================
# Pillar 1: Semantic Decomposition Configuration
# =============================================================================


@dataclass
class Pillar1Config:
    """
    Configuration for Pillar 1: Semantic Decomposition (Y = R + S + N).

    Covers all supervised training infrastructure:
    - Projection head architecture
    - Loss function weights
    - Training parameters
    - Weak supervision settings
    - Calibration settings
    - Validation parameters
    """

    # =========================================================================
    # Projection Head Architecture
    # =========================================================================
    hidden_dim: int = 768
    projection_dim: int = 128
    projection_mode: str = "hybrid"  # linear, mlp, hybrid
    num_projection_layers: int = 2
    dropout: float = 0.1
    use_batch_norm: bool = False
    use_layer_norm: bool = True
    activation: str = "gelu"  # relu, gelu, silu
    init_scale: float = 0.02

    # =========================================================================
    # Loss Function Configuration
    # =========================================================================
    # Triplet loss
    triplet_weight: float = 1.0
    triplet_margin: float = 0.5
    mining_strategy: str = "semi_hard"  # hard, semi_hard, all
    distance_fn: str = "cosine"  # euclidean, cosine

    # Contrastive loss (SimCLR style)
    contrastive_weight: float = 0.5
    contrastive_tau: float = 0.07  # InfoNCE scaling factor (NOT YRSN's τ_α!)
    use_contrastive: bool = False  # Use contrastive instead of triplet

    # Orthogonality loss (ensures R/S/N subspaces are distinct)
    orthogonality_weight: float = 0.1

    # Classification loss (for quality classifier)
    classification_weight: float = 0.3

    # =========================================================================
    # Training Parameters
    # =========================================================================
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    warmup_steps: int = 1000
    max_steps: int = 50000
    batch_size: int = 64
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0

    # Evaluation and checkpointing
    eval_every: int = 500
    save_every: int = 2000
    log_every: int = 100

    # Early stopping
    patience: int = 10
    min_delta: float = 1e-4

    # Checkpoint
    checkpoint_dir: str = "./checkpoints/pillar1"
    save_best_only: bool = True

    # =========================================================================
    # Weak Supervision (Outcome-Based)
    # =========================================================================
    use_outcome_supervision: bool = True
    outcome_weight: float = 0.2
    pseudo_label_threshold: float = 0.8
    min_confidence: float = 0.5
    attribution_method: str = "attention"  # gradient, attention, integrated_gradients

    # =========================================================================
    # Calibration (Drift-Reset)
    # =========================================================================
    calibration_buffer_size: int = 256
    min_samples_for_calibration: int = 64
    muddy_threshold: float = 0.15
    confusion_streak_trigger: int = 5
    variance_threshold: float = 0.02
    calibration_cooldown: float = 10.0
    auto_recalibrate: bool = True

    # Robust PCA for slow path
    rpca_rank: int = 64
    rpca_sparse_threshold: float = 0.01

    # Topic shift detection
    topic_shift_noise_threshold: float = 0.40
    topic_shift_improvement_threshold: float = 0.10
    enable_topic_shift_detection: bool = True

    # =========================================================================
    # Validation
    # =========================================================================
    validation_batch_size: int = 128
    classification_threshold: float = 0.5
    separation_margin: float = 0.1

    # =========================================================================
    # Serialization
    # =========================================================================

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Pillar1Config":
        """Create config from dictionary."""
        # Filter to only known fields
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)

    def validate(self) -> List[str]:
        """Validate configuration, return list of errors."""
        errors = []

        if self.hidden_dim <= 0:
            errors.append("hidden_dim must be positive")
        if self.projection_dim <= 0:
            errors.append("projection_dim must be positive")
        if self.projection_mode not in ("linear", "mlp", "hybrid"):
            errors.append(f"Invalid projection_mode: {self.projection_mode}")
        if self.mining_strategy not in ("hard", "semi_hard", "all"):
            errors.append(f"Invalid mining_strategy: {self.mining_strategy}")
        if self.distance_fn not in ("euclidean", "cosine"):
            errors.append(f"Invalid distance_fn: {self.distance_fn}")
        if self.triplet_margin < 0:
            errors.append("triplet_margin must be non-negative")
        if self.learning_rate <= 0:
            errors.append("learning_rate must be positive")
        if self.batch_size <= 0:
            errors.append("batch_size must be positive")

        return errors


# =============================================================================
# Pillar 2: Phase Transitions & Temperature-Quality Configuration
# =============================================================================


@dataclass
class Pillar2Config:
    """
    Configuration for Pillar 2: Phase Transitions & Temperature-Quality Duality.

    Covers:
    - BBP threshold calculation and rank selection
    - Temperature-quality mapping (τ = f(α))
    - Spectral analysis (Marchenko-Pastur)
    - Adaptive scaling integration
    """

    # =========================================================================
    # BBP Phase Transition Settings
    # =========================================================================
    # BBP threshold formula: α_ℓ = (ℓ-1)/(2ℓ)
    bbp_max_rank: int = 100  # Maximum rank to precompute
    bbp_hysteresis: float = 0.05  # Prevents oscillation at boundaries
    bbp_min_samples_for_transition: int = 10  # Samples before rank change
    bbp_transition_cooldown: float = 5.0  # Seconds between transitions

    # =========================================================================
    # Temperature-Quality Duality
    # =========================================================================
    # Core mapping: τ = f(α) where τ is temperature, α is quality
    temperature_mode: str = "power"  # linear, power, log, sigmoid
    tau_min: float = 0.1  # Minimum temperature (tightest reasoning)
    tau_max: float = 5.0  # Maximum temperature (loosest reasoning)
    power_k: float = 2.0  # Exponent for power mode
    log_c: float = 10.0  # Scaling for log mode
    sigmoid_k: float = 12.0  # Steepness for sigmoid
    sigmoid_alpha_c: float = 0.5  # Center point for sigmoid

    # Quality phase thresholds
    alpha_high_threshold: float = 0.70  # α > 0.70 = HIGH quality
    alpha_low_threshold: float = 0.40  # α < 0.40 = LOW quality

    # Critical temperatures (derived from thresholds)
    # tau_c1 = 1/0.70 ≈ 1.43 (HIGH → MEDIUM)
    # tau_c2 = 1/0.40 = 2.50 (MEDIUM → LOW)

    # =========================================================================
    # Spectral Analysis (Marchenko-Pastur)
    # =========================================================================
    # MP law: eigenvalue bounds for random matrices
    spectral_sigma_estimate: float = 1.0  # Noise standard deviation estimate
    spectral_outlier_margin: float = 1.1  # Margin above MP bound for outliers
    spectral_history_size: int = 50  # History for eigenvalue tracking

    # Signal-to-Noise analysis
    snr_high_threshold: float = 10.0  # SNR above this = strong signal
    snr_low_threshold: float = 1.0  # SNR below this = mostly noise

    # Effective rank (participation ratio)
    effective_rank_warning_threshold: float = 0.5  # Warn if eff_rank < 50% of nominal

    # =========================================================================
    # Adaptive Scaling Integration
    # =========================================================================
    adaptation_rate: float = 0.1  # EMA rate for quality smoothing
    use_spectral_guidance: bool = True  # Enable spectral-based rank guidance
    spectral_weight: float = 0.5  # Weight for spectral vs BBP recommendation
    conservative_mode: bool = False  # Prefer lower ranks when uncertain

    # Rank bounds
    rank_min: int = 1
    rank_max: int = 100

    # =========================================================================
    # Quality Tracking
    # =========================================================================
    quality_history_size: int = 100  # History for quality smoothing
    quality_variance_window: int = 20  # Window for variance calculation

    # =========================================================================
    # Phase Transition Detection
    # =========================================================================
    transition_detection_enabled: bool = True
    transition_window_size: int = 20  # Samples for detecting transitions
    transition_threshold: float = 0.1  # Quality change to trigger event

    # =========================================================================
    # Serialization
    # =========================================================================

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Pillar2Config":
        """Create config from dictionary."""
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)

    def validate(self) -> List[str]:
        """Validate configuration, return list of errors."""
        errors = []

        if self.temperature_mode not in ("linear", "power", "log", "sigmoid"):
            errors.append(f"Invalid temperature_mode: {self.temperature_mode}")
        if self.tau_min <= 0:
            errors.append("tau_min must be positive")
        if self.tau_max <= self.tau_min:
            errors.append("tau_max must be greater than tau_min")
        if not (0 < self.alpha_low_threshold < self.alpha_high_threshold < 1):
            errors.append("Quality thresholds must satisfy: 0 < low < high < 1")
        if self.bbp_max_rank < 1:
            errors.append("bbp_max_rank must be >= 1")
        if self.rank_min < 1:
            errors.append("rank_min must be >= 1")
        if self.rank_max < self.rank_min:
            errors.append("rank_max must be >= rank_min")
        if not (0 < self.adaptation_rate <= 1):
            errors.append("adaptation_rate must be in (0, 1]")
        if not (0 <= self.spectral_weight <= 1):
            errors.append("spectral_weight must be in [0, 1]")

        return errors

    def get_critical_temperatures(self) -> Dict[str, float]:
        """Get critical temperature values for phase transitions."""
        return {
            "tau_c1_high_to_medium": 1.0 / self.alpha_high_threshold,
            "tau_c2_medium_to_low": 1.0 / self.alpha_low_threshold,
        }

    def get_bbp_reference(self) -> Dict[int, float]:
        """Get BBP threshold reference table."""
        return {
            ell: (ell - 1) / (2 * ell)
            for ell in range(1, min(11, self.bbp_max_rank + 1))
        }


# =============================================================================
# Pillar 3: Context Collapse Detection & Monitoring Configuration
# =============================================================================


@dataclass
class Pillar3Config:
    """
    Configuration for Pillar 3: Context Collapse Detection & Monitoring.

    Covers:
    - Collapse detection thresholds (Poisoning, Distraction, Confusion, Clash)
    - Three-tier constraint taxonomy (Actual/Learned/Emergent)
    - Collapse monitoring and audit trail
    - Early warning system
    """

    # =========================================================================
    # Collapse Detection Thresholds
    # =========================================================================
    # Defaults from CollapseConfig (single source of truth)
    poisoning_n_threshold: float = _DEFAULT_SIG.poisoning_n
    distraction_s_threshold: float = _DEFAULT_SIG.distraction_s
    conflict_n_threshold: float = _DEFAULT_SIG.confusion_n
    conflict_s_threshold: float = _DEFAULT_SIG.confusion_s
    clash_variance_threshold: float = _DEFAULT_SIG.clash_s_var

    # Severity thresholds (based on risk_score = S + 1.5*N)
    severity_low_threshold: float = 0.30
    severity_medium_threshold: float = 0.50
    severity_high_threshold: float = 0.70
    severity_critical_threshold: float = 0.85

    # =========================================================================
    # Three-Tier Constraint Taxonomy
    # =========================================================================
    # ACTUAL constraints (fatal violations - must stop)
    actual_min_relevance: float = 0.10  # R must be >= 0.10
    actual_max_noise: float = 0.50  # N must be <= 0.50
    actual_min_quality: float = 0.05  # Quality must be >= 0.05

    # LEARNED constraints (warnings - proceed with caution)
    learned_min_relevance: float = 0.30  # Preferred R >= 0.30
    learned_max_noise: float = 0.25  # Preferred N <= 0.25
    learned_max_superfluous: float = 0.35  # Preferred S <= 0.35
    learned_min_quality: float = 0.20  # Preferred quality >= 0.20

    # EMERGENT constraints (advisories - informational)
    emergent_target_relevance: float = 0.50  # Target R >= 0.50
    emergent_target_noise: float = 0.15  # Target N <= 0.15
    emergent_target_quality: float = 0.40  # Target quality >= 0.40

    # Enforcement behavior
    halt_on_actual_violation: bool = True
    log_learned_violations: bool = True
    track_emergent_metrics: bool = True

    # =========================================================================
    # Collapse Monitoring
    # =========================================================================
    monitor_history_size: int = 1000  # Events to keep in audit trail
    monitor_warning_window: int = 10  # Events for trend analysis
    monitor_trend_threshold: float = 0.02  # Minimum slope for trend detection

    # Audit trail settings
    audit_log_path: Optional[str] = None  # If set, persist audit trail
    audit_flush_interval: int = 100  # Events between flushes

    # =========================================================================
    # Early Warning System
    # =========================================================================
    early_warning_enabled: bool = True
    warning_confidence_threshold: float = 0.2  # Min confidence for warning

    # Warning level thresholds
    watch_confidence: float = 0.2  # Confidence for WATCH level
    elevated_confidence: float = 0.5  # Confidence for ELEVATED level
    imminent_confidence: float = 0.8  # Confidence for IMMINENT level

    # Time-to-collapse estimation
    collapse_risk_threshold: float = 0.6  # Risk score threshold
    estimate_time_to_collapse: bool = True

    # =========================================================================
    # Integration with Pillar 2
    # =========================================================================
    use_quality_from_pillar2: bool = True  # Use Pillar 2 quality metrics
    quality_sync_interval: int = 10  # Sync quality every N updates

    # Phase-aware thresholds (stricter at high quality, looser at low)
    phase_aware_thresholds: bool = True
    high_quality_noise_multiplier: float = 0.8  # Stricter N threshold
    low_quality_noise_multiplier: float = 1.2  # Looser N threshold

    # =========================================================================
    # Serialization
    # =========================================================================

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Pillar3Config":
        """Create config from dictionary."""
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)

    def validate(self) -> List[str]:
        """Validate configuration, return list of errors."""
        errors = []

        # Threshold validation
        if not (0 < self.poisoning_n_threshold < 1):
            errors.append("poisoning_n_threshold must be in (0, 1)")
        if not (0 < self.distraction_s_threshold < 1):
            errors.append("distraction_s_threshold must be in (0, 1)")
        if self.conflict_n_threshold >= self.poisoning_n_threshold:
            errors.append("conflict_n_threshold should be < poisoning_n_threshold")
        if self.conflict_s_threshold >= self.distraction_s_threshold:
            errors.append("conflict_s_threshold should be < distraction_s_threshold")

        # Tier constraint validation
        if self.actual_min_relevance >= self.learned_min_relevance:
            errors.append("actual constraints should be less strict than learned")
        if self.learned_min_relevance >= self.emergent_target_relevance:
            errors.append("learned constraints should be less strict than emergent targets")

        # Severity thresholds should be increasing
        thresholds = [
            self.severity_low_threshold,
            self.severity_medium_threshold,
            self.severity_high_threshold,
            self.severity_critical_threshold,
        ]
        if thresholds != sorted(thresholds):
            errors.append("severity thresholds must be in increasing order")

        # Warning confidence thresholds
        confidences = [
            self.watch_confidence,
            self.elevated_confidence,
            self.imminent_confidence,
        ]
        if confidences != sorted(confidences):
            errors.append("warning confidence thresholds must be in increasing order")

        # Monitor settings
        if self.monitor_history_size < 10:
            errors.append("monitor_history_size should be >= 10")
        if self.monitor_warning_window < 3:
            errors.append("monitor_warning_window should be >= 3")

        return errors

    def get_collapse_signature_dict(self) -> Dict[str, float]:
        """Get thresholds in CollapseSignature format."""
        return {
            "POISONING_N_THRESHOLD": self.poisoning_n_threshold,
            "DISTRACTION_S_THRESHOLD": self.distraction_s_threshold,
            "CONFLICT_N_THRESHOLD": self.conflict_n_threshold,
            "CONFLICT_S_THRESHOLD": self.conflict_s_threshold,
            "CLASH_VARIANCE_THRESHOLD": self.clash_variance_threshold,
        }

    def get_tier_constraints(self) -> Dict[str, Dict[str, float]]:
        """Get constraint thresholds by tier."""
        return {
            "actual": {
                "min_R": self.actual_min_relevance,
                "max_N": self.actual_max_noise,
                "min_quality": self.actual_min_quality,
            },
            "learned": {
                "min_R": self.learned_min_relevance,
                "max_N": self.learned_max_noise,
                "max_S": self.learned_max_superfluous,
                "min_quality": self.learned_min_quality,
            },
            "emergent": {
                "target_R": self.emergent_target_relevance,
                "target_N": self.emergent_target_noise,
                "target_quality": self.emergent_target_quality,
            },
        }


# =============================================================================
# Combined Configuration
# =============================================================================


@dataclass
class YRSNPillarConfig:
    """
    Combined configuration for all YRSN pillars.

    Usage:
        config = YRSNPillarConfig()
        config.pillar1.learning_rate = 1e-3
        config.pillar2.temperature_mode = "sigmoid"
        config.pillar3.poisoning_n_threshold = 0.25
    """

    pillar1: Pillar1Config = field(default_factory=Pillar1Config)
    pillar2: Pillar2Config = field(default_factory=Pillar2Config)
    pillar3: Pillar3Config = field(default_factory=Pillar3Config)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "pillar1": self.pillar1.to_dict(),
            "pillar2": self.pillar2.to_dict(),
            "pillar3": self.pillar3.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "YRSNPillarConfig":
        """Create from dictionary."""
        return cls(
            pillar1=Pillar1Config.from_dict(data.get("pillar1", {})),
            pillar2=Pillar2Config.from_dict(data.get("pillar2", {})),
            pillar3=Pillar3Config.from_dict(data.get("pillar3", {})),
        )

    def validate(self) -> Dict[str, List[str]]:
        """Validate all configs, return errors by pillar."""
        return {
            "pillar1": self.pillar1.validate(),
            "pillar2": self.pillar2.validate(),
            "pillar3": self.pillar3.validate(),
        }


# =============================================================================
# Factory Functions
# =============================================================================


def create_default_configs() -> YRSNPillarConfig:
    """Create default configuration for all pillars."""
    return YRSNPillarConfig()


def create_conservative_configs() -> YRSNPillarConfig:
    """Create conservative configuration (lower risks, slower adaptation)."""
    return YRSNPillarConfig(
        pillar1=Pillar1Config(
            learning_rate=5e-5,
            warmup_steps=2000,
            patience=20,
            triplet_margin=0.3,
        ),
        pillar2=Pillar2Config(
            conservative_mode=True,
            adaptation_rate=0.05,
            bbp_hysteresis=0.1,
            tau_max=3.0,
        ),
        pillar3=Pillar3Config(
            # Stricter thresholds for earlier warnings
            poisoning_n_threshold=0.25,
            distraction_s_threshold=0.35,
            severity_high_threshold=0.60,
            # More sensitive early warning
            watch_confidence=0.15,
            elevated_confidence=0.4,
        ),
    )


def create_fast_configs() -> YRSNPillarConfig:
    """Create fast configuration (quick adaptation, higher risk)."""
    return YRSNPillarConfig(
        pillar1=Pillar1Config(
            learning_rate=3e-4,
            warmup_steps=500,
            patience=5,
            eval_every=250,
        ),
        pillar2=Pillar2Config(
            adaptation_rate=0.3,
            bbp_min_samples_for_transition=5,
            bbp_hysteresis=0.02,
        ),
        pillar3=Pillar3Config(
            # Looser thresholds for faster progression
            poisoning_n_threshold=0.35,
            distraction_s_threshold=0.45,
            # Smaller monitoring window
            monitor_warning_window=5,
            # Less sensitive early warning
            elevated_confidence=0.6,
        ),
    )


def create_research_configs() -> YRSNPillarConfig:
    """Create configuration optimized for research/experimentation."""
    return YRSNPillarConfig(
        pillar1=Pillar1Config(
            log_every=10,
            eval_every=100,
            save_every=500,
            save_best_only=False,  # Save all checkpoints for analysis
        ),
        pillar2=Pillar2Config(
            spectral_history_size=200,  # More history for analysis
            quality_history_size=500,
            transition_detection_enabled=True,
        ),
        pillar3=Pillar3Config(
            # Maximum audit history for research
            monitor_history_size=5000,
            # Track all metrics
            track_emergent_metrics=True,
            log_learned_violations=True,
            # Enable all features
            early_warning_enabled=True,
            estimate_time_to_collapse=True,
            phase_aware_thresholds=True,
        ),
    )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "Pillar1Config",
    "Pillar2Config",
    "Pillar3Config",
    "YRSNPillarConfig",
    "create_default_configs",
    "create_conservative_configs",
    "create_fast_configs",
    "create_research_configs",
]
