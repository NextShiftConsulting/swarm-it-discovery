"""
RSCT Integration Module - Wire YRSN components for κ-guided curriculum.

This module integrates existing YRSN components to implement RSCT theory:
- κ = D*/D computation
- Curriculum ordering via GearboxCurriculum
- Hysteresis via AdaptiveGearbox/GearShifter
- Learning via memristor weights
- Replay via PrioritizedReplayBuffer

Hex Arch Pattern:
- Uses existing ports (IGearbox, IRetriever)
- Uses existing adapters (AdaptiveGearbox, ChromaAdapter)
- Domain logic stays in core/

Reference: docs/papers/gap_analysis/RSCT_YRSN_IMPLEMENTATION_APPENDIX.md
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple, Protocol
from enum import Enum
import numpy as np
import logging

# Core imports (domain logic)
from yrsn.core.decomposition.composition import (
    compute_compositional_kappa,
    compute_compositional_kappa_detailed,
    CompositionResult,
)
from yrsn.core.decomposition.kappa_simplex import (
    KappaSimplex,
    compute_kappa_simplex,
)

# Certificate integration - the standard YRSN data movement pattern
try:
    from yrsn.core.certificate import YRSNCertificate
    HAS_CERTIFICATE = True
except ImportError:
    HAS_CERTIFICATE = False
    YRSNCertificate = None

logger = logging.getLogger(__name__)


# =============================================================================
# D* Estimation (inline to avoid new modules)
# =============================================================================

@dataclass
class DStarEstimate:
    """D* estimate with metadata."""
    d_star: float
    confidence: float
    source: str  # 'ctc', 'similar', 'heuristic'
    details: Dict[str, Any] = field(default_factory=dict)


# Default constraint costs calibrated from CTC traces
CONSTRAINT_COSTS = {
    'killer': 5, 'arrow': 4, 'whisper': 4, 'thermometer': 3,
    'knight': 3, 'renban': 3, 'palindrome': 3, 'kropki': 2,
    'king': 2, 'diagonal': 2,
}


def estimate_d_star(
    puzzle: Dict,
    ctc_traces: Optional[Dict[str, Any]] = None,
) -> DStarEstimate:
    """
    Estimate D* using available sources.

    Priority: CTC ground truth > Similar transfer > Heuristic
    """
    puzzle_id = puzzle.get('puzzle_id', '')

    # Source 1: CTC ground truth
    if ctc_traces and puzzle_id in ctc_traces:
        trace = ctc_traces[puzzle_id]
        steps = trace.get('steps', [])
        return DStarEstimate(
            d_star=len(steps) if isinstance(steps, list) else float(steps),
            confidence=1.0,
            source='ctc',
        )

    # Source 2: Heuristic
    rules_lower = puzzle.get('rules', '').lower()
    grid_size = puzzle.get('rows', 9)

    d_star = {4: 5, 6: 15, 9: 30}.get(grid_size, 30)
    for constraint, cost in CONSTRAINT_COSTS.items():
        if constraint in rules_lower:
            d_star += cost

    return DStarEstimate(d_star=d_star, confidence=0.5, source='heuristic')


# =============================================================================
# κ Computation
# =============================================================================

@dataclass
class KappaResult:
    """Result of κ computation for a puzzle evaluation."""
    kappa: float
    d_star: float
    d_actual: float
    d_star_estimate: DStarEstimate
    composition: Optional[CompositionResult] = None
    # Ghost #2 fix: κ-Simplex diagnostics
    kappa_simplex: Optional['KappaSimplex'] = None  # (κ_A, κ_E, κ_T) decomposition
    kappa_vector: Optional[Tuple[float, float, float]] = None  # For certificate
    kappa_A: Optional[float] = None  # Alignment
    kappa_E: Optional[float] = None  # Efficiency
    kappa_T: Optional[float] = None  # Tractability


def compute_kappa(
    d_star: float,
    d_actual: float,
) -> float:
    """
    Compute κ = D*/D (encoding-solver compatibility).

    Args:
        d_star: Reference difficulty (optimal expert steps)
        d_actual: Actual steps taken by solver

    Returns:
        κ ∈ (0, 1] where 1 = optimal compatibility
    """
    if d_actual <= 0:
        return 1.0
    return min(1.0, d_star / d_actual)


def compute_kappa_from_result(
    puzzle: Dict,
    eval_result: Dict,
    ctc_traces: Optional[Dict] = None,
    primitive_kappas: Optional[Dict[str, float]] = None,
) -> KappaResult:
    """
    Compute κ from puzzle evaluation result.

    Args:
        puzzle: Puzzle dict with rules, etc.
        eval_result: Dict with 'step_count' or 'reasoning_trace'
        ctc_traces: Optional CTC traces for ground truth D*
        primitive_kappas: Optional per-primitive κ values for composition

    Returns:
        KappaResult with full details
    """
    # Estimate D*
    d_star_est = estimate_d_star(puzzle, ctc_traces)

    # Get D_actual from result
    d_actual = eval_result.get('step_count')
    if d_actual is None:
        trace = eval_result.get('reasoning_trace', '')
        d_actual = len(trace.split('\n')) if trace else 50

    # Compute base κ
    kappa = compute_kappa(d_star_est.d_star, d_actual)

    # Compute compositional κ if primitive kappas provided
    composition = None
    if primitive_kappas:
        composition = compute_compositional_kappa_detailed(primitive_kappas)
        # Use compositional κ if lower (bottleneck effect)
        kappa = min(kappa, composition.kappa_composite)

    # Ghost #2 fix: Compute κ-Simplex (Phase 1: uniform distribution)
    kappa_simplex = compute_kappa_simplex(
        d_star=d_star_est.d_star,
        d_actual=d_actual,
        phase=1,  # Phase 1: uniform distribution
    )

    return KappaResult(
        kappa=kappa,
        d_star=d_star_est.d_star,
        d_actual=d_actual,
        d_star_estimate=d_star_est,
        composition=composition,
        # κ-Simplex fields (Ghost #2 fix)
        kappa_simplex=kappa_simplex,
        kappa_vector=kappa_simplex.vector,
        kappa_A=kappa_simplex.kappa_A,
        kappa_E=kappa_simplex.kappa_E,
        kappa_T=kappa_simplex.kappa_T,
    )


# =============================================================================
# κ-Based Replay Priority (extends existing buffer)
# =============================================================================

def compute_kappa_priority(
    old_kappa: float,
    new_kappa: float,
    alpha: float = 0.6,
    epsilon: float = 0.01,
) -> float:
    """
    Compute replay priority based on κ degradation.

    Higher priority for experiences where κ degraded significantly.

    Args:
        old_kappa: κ when experience was stored
        new_kappa: κ on re-evaluation (or expected κ)
        alpha: Priority exponent (0=uniform, 1=full priority)
        epsilon: Minimum priority

    Returns:
        Priority score for replay sampling
    """
    degradation = max(0, old_kappa - new_kappa)
    return (degradation + epsilon) ** alpha


# =============================================================================
# Quality Signals for Gearbox Integration
# =============================================================================

@dataclass
class RSCTQualitySignals:
    """
    Quality signals for gear shift decisions.

    Maps RSCT κ to gearbox QualitySignals format.
    Integrates with YRSNCertificate for standard data movement.
    """
    kappa: float
    alpha: float  # α = κ (for gearbox compatibility)
    tau: float    # τ = 1/κ (temperature)
    collapse_risk: float = 0.0
    d_star: Optional[float] = None
    d_actual: Optional[float] = None

    @classmethod
    def from_kappa(cls, kappa: float, collapse_risk: float = 0.0) -> "RSCTQualitySignals":
        """Create signals from κ value."""
        return cls(
            kappa=kappa,
            alpha=kappa,
            tau=1.0 / max(kappa, 0.01),
            collapse_risk=collapse_risk,
        )

    @classmethod
    def from_certificate(cls, cert: "YRSNCertificate", d_star: float = None, d_actual: float = None) -> "RSCTQualitySignals":
        """
        Create signals from YRSNCertificate.

        Uses certificate's alpha as base, adjusts for κ if D* provided.
        """
        alpha = cert.alpha_omega if cert.alpha_omega else cert.alpha
        kappa = alpha  # Default: κ = α

        # If D* and D_actual provided, compute true κ
        if d_star is not None and d_actual is not None and d_actual > 0:
            kappa = min(1.0, d_star / d_actual)

        collapse_risk = 1.0 - (cert.health_score or (1.0 - cert.N))

        return cls(
            kappa=kappa,
            alpha=alpha,
            tau=cert.tau,
            collapse_risk=collapse_risk,
            d_star=d_star,
            d_actual=d_actual,
        )

    def to_gearbox_signals(self):
        """Convert to gearbox QualitySignals format."""
        # Lazy import to avoid circular dependency
        from yrsn.core.gearbox.shifter import QualitySignals
        return QualitySignals(
            alpha=self.alpha,
            tau=self.tau,
            collapse_risk=self.collapse_risk,
        )

    def to_certificate_update(self) -> Dict[str, Any]:
        """
        Return dict of fields to update on a YRSNCertificate.

        Usage:
            cert = YRSNCertificate(...)
            signals = RSCTQualitySignals.from_kappa(0.8)
            # Store κ in certificate metadata
        """
        return {
            'kappa': self.kappa,
            'd_star': self.d_star,
            'd_actual': self.d_actual,
        }


# =============================================================================
# RSCT Controller (Main Integration Class)
# =============================================================================

class RSCTController:
    """
    Main controller integrating RSCT components.

    Wires together:
    - GearboxCurriculum (from exp/sudoku/pillars)
    - AdaptiveGearbox (from adapters/gearbox)
    - PrioritizedReplayBuffer (from core/memory)
    - Compositional κ (from core/decomposition)

    Example:
        >>> from yrsn.core.decomposition.rsct_integration import RSCTController
        >>> controller = RSCTController()
        >>>
        >>> for puzzle in puzzles:
        ...     result = evaluate(solver, puzzle)
        ...     kappa_result = controller.record_evaluation(puzzle, result)
        ...     new_gear = controller.update_gear(kappa_result.kappa)
    """

    def __init__(
        self,
        gearbox=None,
        curriculum=None,
        replay_buffer=None,
        ctc_traces: Optional[Dict] = None,
    ):
        """
        Initialize RSCT controller.

        Args:
            gearbox: Optional AdaptiveGearbox instance
            curriculum: Optional GearboxCurriculum instance
            replay_buffer: Optional PrioritizedReplayBuffer instance
            ctc_traces: Optional CTC traces for D* estimation
        """
        self.gearbox = gearbox
        self.curriculum = curriculum
        self.replay_buffer = replay_buffer
        self.ctc_traces = ctc_traces or {}

        # History for analysis
        self.kappa_history: List[KappaResult] = []
        self.gear_history: List[int] = []

    def record_evaluation(
        self,
        puzzle: Dict,
        eval_result: Dict,
        primitive_kappas: Optional[Dict[str, float]] = None,
    ) -> KappaResult:
        """
        Record a puzzle evaluation and compute κ.

        Args:
            puzzle: Puzzle that was evaluated
            eval_result: Evaluation result with step_count
            primitive_kappas: Optional per-primitive κ values

        Returns:
            KappaResult with computed κ
        """
        kappa_result = compute_kappa_from_result(
            puzzle, eval_result, self.ctc_traces, primitive_kappas
        )
        self.kappa_history.append(kappa_result)

        logger.debug(
            f"κ={kappa_result.kappa:.3f} "
            f"(D*={kappa_result.d_star:.1f}, D={kappa_result.d_actual:.1f})"
        )

        return kappa_result

    def update_gear(self, kappa: float) -> Optional[int]:
        """
        Update gear based on κ value.

        Args:
            kappa: Current κ value

        Returns:
            New gear number if shifted, None otherwise
        """
        if self.gearbox is None:
            return None

        signals = RSCTQualitySignals.from_kappa(kappa)
        new_gear = self.gearbox.auto_shift(signals.to_gearbox_signals())

        if new_gear:
            self.gear_history.append(new_gear.ordinal)
            if self.curriculum:
                self.curriculum.current_gear = new_gear.ordinal
            return new_gear.ordinal

        return None

    def get_current_difficulty(self) -> Dict[str, Any]:
        """Get current curriculum difficulty settings."""
        if self.curriculum:
            return self.curriculum.get_difficulty()
        return {"gear": 1, "name": "unknown"}

    def get_statistics(self) -> Dict[str, Any]:
        """Get κ and gear statistics."""
        if not self.kappa_history:
            return {}

        kappas = [k.kappa for k in self.kappa_history]
        return {
            "n_evaluations": len(kappas),
            "mean_kappa": float(np.mean(kappas)),
            "std_kappa": float(np.std(kappas)),
            "min_kappa": float(np.min(kappas)),
            "max_kappa": float(np.max(kappas)),
            "current_gear": self.gear_history[-1] if self.gear_history else 1,
            "gear_changes": len(set(self.gear_history)) - 1 if self.gear_history else 0,
        }


# =============================================================================
# Factory Functions
# =============================================================================

def create_rsct_controller(
    mode: str = "eco",
    ctc_traces: Optional[Dict] = None,
) -> RSCTController:
    """
    Factory function to create fully-wired RSCT controller.

    Args:
        mode: Driving mode ('eco', 'sport', 'manual')
        ctc_traces: Optional CTC traces for D* estimation

    Returns:
        Configured RSCTController
    """
    # Import adapters (hex arch pattern)
    try:
        from yrsn.adapters.gearbox.adaptive import AdaptiveGearbox
        from yrsn.core.gearbox.driving_mode import DrivingMode

        mode_enum = {
            'eco': DrivingMode.ECO,
            'sport': DrivingMode.SPORT,
            'manual': DrivingMode.MANUAL,
        }.get(mode.lower(), DrivingMode.ECO)

        gearbox = AdaptiveGearbox(mode=mode_enum)
    except ImportError:
        logger.warning("AdaptiveGearbox not available")
        gearbox = None

    # Import curriculum (from exp/sudoku)
    try:
        import sys
        from pathlib import Path
        # Add exp to path if needed
        exp_path = Path(__file__).parents[4] / "exp" / "sudoku" / "pillars"
        if str(exp_path.parent.parent) not in sys.path:
            sys.path.insert(0, str(exp_path.parent.parent))

        from pillars.p4_memristor_curriculum import GearboxCurriculum
        curriculum = GearboxCurriculum()
    except ImportError:
        logger.warning("GearboxCurriculum not available")
        curriculum = None

    # Import replay buffer
    try:
        from yrsn.core.memory.replay import PrioritizedReplayBuffer
        replay_buffer = PrioritizedReplayBuffer()
    except ImportError:
        logger.warning("PrioritizedReplayBuffer not available")
        replay_buffer = None

    return RSCTController(
        gearbox=gearbox,
        curriculum=curriculum,
        replay_buffer=replay_buffer,
        ctc_traces=ctc_traces,
    )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # D* estimation
    "DStarEstimate",
    "estimate_d_star",
    "CONSTRAINT_COSTS",
    # κ computation
    "KappaResult",
    "compute_kappa",
    "compute_kappa_from_result",
    # Replay priority
    "compute_kappa_priority",
    # Quality signals
    "RSCTQualitySignals",
    # Main controller
    "RSCTController",
    "create_rsct_controller",
]
