"""
Collapse Detection Packs
========================

Modular collapse detection with domain-specific packs.

IMPLEMENTATION STATUS:
    ✅ GENERAL     - Implemented, tested, optimization validated
    🔮 SPATIAL     - Future (infrastructure ready)
    🔮 ROBOTICS    - Future (infrastructure ready)
    🔮 MULTIAGENT  - Future (infrastructure ready)
    🔮 INDUSTRIAL  - Future (infrastructure ready)

DEFAULT: GENERAL pack only (types 1-16)
    - All current optimization and testing is based on GENERAL pack
    - Future packs can be enabled when their collapse types are defined

Design:
    - Packs are additive (enable more as needed)
    - GENERAL is always available
    - Future packs require corresponding CollapseType definitions in collapse.py
"""
from enum import Enum
from typing import List, Set


class PackStatus(str, Enum):
    """Implementation status of a pack."""
    IMPLEMENTED = "implemented"  # Tested, optimized, ready
    FUTURE = "future"            # Infrastructure ready, types not defined


class CollapsePack(str, Enum):
    """
    Collapse detection packs.

    Only GENERAL is currently implemented.
    Other packs are infrastructure for future domain-specific collapse types.
    """
    GENERAL = "general"          # ✅ Types 1-16 (IMPLEMENTED)
    SPATIAL = "spatial"          # 🔮 Future: geometric + spatial collapse
    ROBOTICS = "robotics"        # 🔮 Future: robotics-specific collapse
    MULTIAGENT = "multiagent"    # 🔮 Future: multiagent-specific collapse
    INDUSTRIAL = "industrial"    # 🔮 Future: industrial-specific collapse
    ALL = "all"                  # All implemented types


# Default pack - what optimization and testing is based on
DEFAULT_PACK = CollapsePack.GENERAL


# Pack definitions with implementation status
COLLAPSE_PACKS = {
    CollapsePack.GENERAL: {
        "types": list(range(1, 17)),  # Types 1-16
        "description": "Core collapse types (Quality, Reliability, Representation, Uncertainty, Distributional)",
        "status": PackStatus.IMPLEMENTED,
        "tested": True,
        "optimized": True,
    },
    CollapsePack.SPATIAL: {
        "types": [],  # Future: will be types 17-20, 25-28 when defined
        "description": "Spatial AI collapse types (geometric + spatial) - FUTURE",
        "status": PackStatus.FUTURE,
        "tested": False,
        "optimized": False,
    },
    CollapsePack.ROBOTICS: {
        "types": [],  # Future: will be types 21-24, 29-31 when defined
        "description": "Robotics collapse types - FUTURE",
        "status": PackStatus.FUTURE,
        "tested": False,
        "optimized": False,
    },
    CollapsePack.MULTIAGENT: {
        "types": [],  # Future: will be types 32-35 when defined
        "description": "Multiagent collapse types - FUTURE",
        "status": PackStatus.FUTURE,
        "tested": False,
        "optimized": False,
    },
    CollapsePack.INDUSTRIAL: {
        "types": [],  # Future: will be types 36-42 when defined
        "description": "Industrial collapse types - FUTURE",
        "status": PackStatus.FUTURE,
        "tested": False,
        "optimized": False,
    },
    CollapsePack.ALL: {
        "types": list(range(1, 17)),  # Currently = GENERAL only
        "description": "All implemented collapse types",
        "status": PackStatus.IMPLEMENTED,
        "tested": True,
        "optimized": True,
    },
}


def get_types_for_pack(pack: CollapsePack) -> List[int]:
    """
    Get collapse types for a given pack.

    Returns empty list for FUTURE packs (not yet implemented).
    """
    return COLLAPSE_PACKS[pack]["types"]


def get_types_for_packs(packs: List[CollapsePack]) -> Set[int]:
    """Get collapse types for multiple packs (union)."""
    types = set()
    for pack in packs:
        types.update(get_types_for_pack(pack))
    return types


def is_pack_implemented(pack: CollapsePack) -> bool:
    """Check if a pack is implemented (vs future)."""
    return COLLAPSE_PACKS[pack]["status"] == PackStatus.IMPLEMENTED


def get_implemented_packs() -> List[CollapsePack]:
    """Get list of implemented packs."""
    return [p for p in CollapsePack if is_pack_implemented(p)]


def get_default_types() -> List[int]:
    """Get collapse types for the default (GENERAL) pack."""
    return get_types_for_pack(DEFAULT_PACK)
