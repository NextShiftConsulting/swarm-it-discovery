"""
RSCT Dual Taxonomy Classifier

Maps signal-based collapse detection (current implementation) to gate-based
RSCT enforcement modes (paper taxonomy). Enables both analysis and compliance.

Architecture:
- Signal-based: WHAT fired (CollapseType, theta, R/S/N)
- Gate-based: WHERE caught (RSCT mode, Gate 1-4, remediation)

Reference:
- Paper taxonomy: docs/primary/keep_these/rsct_MASTER_final_1045.tex (Appendix A.5)
- Implementation: src/yrsn/core/decomposition/collapse.py
- Alignment: docs/analysis/COLLAPSE_TAXONOMY_ALIGNMENT.md
"""

from dataclasses import dataclass
from typing import Optional, Tuple, List
from enum import Enum

import torch
import numpy as np

from .collapse import CollapseType


# =============================================================================
# RSCT PAPER TAXONOMY
# =============================================================================

@dataclass(frozen=True)
class RSCTClassification:
    """
    RSCT paper taxonomy - enforcement point classification.

    This is the "where caught, what to do" taxonomy from the paper,
    organized by which gate catches the failure and what remediation is needed.

    Attributes:
        mode: RSCT mode ID (e.g., "1.1", "3.1", "4.2")
        group: Collapse group 1-4 (ENCODING, DYNAMICS, SEMANTIC, EXECUTION)
        gate: Which gate catches this (e.g., "Gate1", "Gate3", None)
        remediation: Required action (REJECT, BLOCK, RE_ENCODE, REPAIR, etc.)
        trigger: Trigger condition from paper (e.g., "N > ηR", "σ > σ_thr")
        confidence: How confident we are in this classification [0-1]
    """
    mode: str              # "1.1", "2.3", "3.1", etc. or "0.0" for unknown
    group: int             # 1=ENCODING, 2=DYNAMICS, 3=SEMANTIC, 4=EXECUTION, 0=unknown
    gate: Optional[str]    # "Gate1", "Gate2", "Gate3", "Gate4", None
    remediation: str       # REJECT, BLOCK, RE_ENCODE, REPAIR, PROCEED, etc.
    trigger: str           # Trigger condition description
    confidence: float = 1.0  # [0-1] confidence in classification


class RSCTGroup(Enum):
    """Four collapse groups from RSCT paper Appendix A.5"""
    UNKNOWN = 0
    ENCODING = 1         # α < α_min or N > ηR
    SOLVER_DYNAMICS = 2  # σ > σ_thr or ΔV_t4 > 0
    SEMANTIC = 3         # high κ_gate, low c or κ_A
    EXECUTION = 4        # κ_gate = min(κ_i) < κ_req


class RSCTRemediation(Enum):
    """Remediation actions from RSCT Algorithm 1"""
    PROCEED = "PROCEED"                 # All gates passed
    PROCEED_CAUTIOUS = "PROCEED_CAUTIOUS"  # Gray zone (Landauer buffer)
    REJECT = "REJECT"                   # Gate 1: Hard block, N ≥ 0.5
    BLOCK = "BLOCK"                     # Gate 2: Soft block, c < 0.4
    RE_ENCODE = "RE_ENCODE"             # Gate 3: Return to encoding
    REPAIR = "REPAIR"                   # Gate 4: Fix specific modality
    HALT = "HALT"                       # Emergency stop (hardware)
    TIMEOUT = "TIMEOUT"                 # Loop detected
    ESCALATE = "ESCALATE"               # Human review (meta-failure)


# =============================================================================
# SIGNAL → RSCT MAPPING TABLE (10 modes currently mapped)
# =============================================================================

# Mapping: CollapseType → (mode, group, gate, remediation, trigger)
SIGNAL_TO_RSCT: dict[CollapseType, Tuple[str, int, str, str, str]] = {
    # Group 1 - Encoding Collapse
    CollapseType.POISONING: (
        "1.1", 1, "Gate1", "REJECT",
        "N > ηR (noise saturation)"
    ),
    CollapseType.DISTRACTION: (
        "1.2", 1, "Gate1", "RE_ENCODE",
        "S_sup ≫ R (superfluous drowning)"
    ),

    # Group 2 - Solver Dynamics Collapse
    # 2.1 Trajectory Divergence - partial (σ threshold exists)
    # 2.3 Oobleck Jamming - exists but not enforced
    # 2.4 Substrate Degradation - covered by HardwareAlertType (not CollapseType)

    # Group 3 - Semantic Collapse
    CollapseType.HALLUCINATION: (
        "3.1", 3, "Gate4", "REPAIR",
        "High κ_gate, Low R (fluent hallucination)"
    ),
    CollapseType.CLASH: (
        "3.2", 3, "Gate2", "BLOCK",
        "c < c_min (phasor conflict)"
    ),
    # 3.4 OOD Fabrication - implicit via ω (not explicit mode)

    # Group 4 - Execution Collapse
    # 4.1 Weakest-Link - detected via min(κ_i) in κ_gate
    # 4.2 Cross-Modal Desync - detected via κ_interface
}


# =============================================================================
# DETECTOR CLASSES
# =============================================================================

class RewardHackingDetector:
    """
    Detect when system games the metric (Mode 3.3).

    Monitors proxy metric (what's being optimized) vs true objective (what we
    actually care about) to detect Goodhart's Law violations.

    Example:
        >>> detector = RewardHackingDetector(divergence_threshold=0.3)
        >>> for step in training:
        ...     metric = compute_proxy_metric()  # e.g., test accuracy
        ...     objective = compute_true_objective()  # e.g., real-world performance
        ...     detector.update(metric, objective)
        ...
        >>> is_hacking, reason = detector.is_hacking()
        >>> if is_hacking:
        ...     print(f"Reward hacking detected: {reason}")
    """

    def __init__(self, divergence_threshold: float = 0.3):
        """
        Initialize reward hacking detector.

        Args:
            divergence_threshold: Minimum divergence to flag as hacking
        """
        self.divergence_threshold = divergence_threshold
        self.metric_history: List[float] = []
        self.objective_history: List[float] = []

    def update(self, metric_value: float, objective_value: float):
        """
        Add new measurements.

        Args:
            metric_value: Proxy metric being optimized
            objective_value: True objective we care about
        """
        self.metric_history.append(metric_value)
        self.objective_history.append(objective_value)

    def is_hacking(self) -> Tuple[bool, str]:
        """
        Check if reward hacking is occurring.

        Returns:
            (is_hacking, reason) tuple

        Detection criteria:
        1. Metric improving while objective degrading (divergence)
        2. Metric improving while objective stagnant
        """
        if len(self.metric_history) < 2:
            return False, "Insufficient history"

        # Compute trends
        metric_trend = self.metric_history[-1] - self.metric_history[0]
        objective_trend = self.objective_history[-1] - self.objective_history[0]

        # Normalize for comparison
        metric_norm = abs(metric_trend) if abs(metric_trend) > 1e-10 else 1.0
        objective_norm = abs(objective_trend) if abs(objective_trend) > 1e-10 else 1.0

        # Check 1: Metric ↑ while objective ↓ (divergence)
        if metric_trend > 0 and objective_trend < 0:
            divergence = abs(metric_trend / metric_norm - objective_trend / objective_norm)
            if divergence > self.divergence_threshold:
                return True, f"Metric improving but objective degrading (div={divergence:.2f})"

        # Check 2: Metric ↑ but objective flat (gaming)
        if metric_trend > 0.1 and abs(objective_trend) < 0.01:
            return True, "Metric improving but objective stagnant"

        return False, "Metric and objective aligned"

    def reset(self):
        """Clear all history."""
        self.metric_history.clear()
        self.objective_history.clear()


class GradientStarvationDetector:
    """
    Detect when solver stops improving (Mode 2.2).

    Tracks loss/metric values over a sliding window and detects:
    - Loss stagnation (variance too low)
    - No improvement (loss not decreasing)
    - Gradient vanishing (if gradient norms provided)

    Example:
        >>> detector = GradientStarvationDetector(window_size=10, threshold=1e-4)
        >>> for step in training_steps:
        ...     loss = compute_loss()
        ...     grad_norm = compute_grad_norm()
        ...     detector.update(loss, grad_norm)
        ...
        >>> is_starved, reason = detector.is_starved()
        >>> if is_starved:
        ...     print(f"Starvation detected: {reason}")
    """

    def __init__(self, window_size: int = 10, threshold: float = 1e-4):
        """
        Initialize gradient starvation detector.

        Args:
            window_size: Number of recent steps to track
            threshold: Minimum variance/improvement required
        """
        self.window_size = window_size
        self.threshold = threshold
        self.loss_history: List[float] = []
        self.grad_norm_history: List[float] = []

    def update(self, loss: float, grad_norm: Optional[float] = None):
        """
        Add new measurement.

        Args:
            loss: Current loss/metric value
            grad_norm: Current gradient norm (optional)
        """
        self.loss_history.append(loss)
        if grad_norm is not None:
            self.grad_norm_history.append(grad_norm)

        # Keep only recent window
        if len(self.loss_history) > self.window_size:
            self.loss_history.pop(0)
        if len(self.grad_norm_history) > self.window_size:
            self.grad_norm_history.pop(0)

    def is_starved(self) -> Tuple[bool, str]:
        """
        Check if learning is stalled.

        Returns:
            (is_starved, reason) tuple

        Detection criteria:
        1. Loss stagnant: std(loss) < threshold
        2. No improvement: loss[-1] >= loss[0]
        3. Gradients vanishing: all grad_norms < threshold
        """
        if len(self.loss_history) < self.window_size:
            return False, "Insufficient history"

        # Check 1: Loss not changing
        losses = np.array(self.loss_history)
        loss_std = losses.std()
        if loss_std < self.threshold:
            return True, f"Loss stagnant (σ={loss_std:.2e} < {self.threshold})"

        # Check 2: Loss not decreasing
        loss_delta = losses[-1] - losses[0]
        if loss_delta >= 0:  # Not improving
            return True, f"No improvement over {self.window_size} steps (ΔL={loss_delta:+.2e})"

        # Check 3: Gradient vanishing
        if self.grad_norm_history and len(self.grad_norm_history) >= self.window_size:
            grads = np.array(self.grad_norm_history)
            if (grads < self.threshold).all():
                return True, f"Gradients vanished (||∇|| < {self.threshold})"

        return False, "Learning progressing normally"

    def reset(self):
        """Clear all history."""
        self.loss_history.clear()
        self.grad_norm_history.clear()


class GatekeeperBypassDetector:
    """
    Detect adversarial attempts to fool RSCT gates (Mode 4.4).

    Meta-safety detector that identifies certificate manipulation, including:
    - Suspiciously perfect values (e.g., κ=0.700 exactly)
    - Simplex constraint violations (R+S+N ≠ 1)
    - Physical impossibilities (κ-σ relationship)
    - Temporal anomalies (sudden jumps in values)

    Example:
        >>> detector = GatekeeperBypassDetector(
        ...     perfect_threshold=1e-10,
        ...     simplex_tolerance=1e-3,
        ...     jump_threshold=0.4
        ... )
        >>> detector.update(R=0.5, S=0.3, N=0.2, kappa=0.7, sigma=0.3)
        >>> is_bypass, reason = detector.is_bypass_attempt()
        >>> if is_bypass:
        ...     print(f"Bypass detected: {reason}")
    """

    def __init__(
        self,
        perfect_threshold: float = 1e-10,
        simplex_tolerance: float = 1e-3,
        jump_threshold: float = 0.4,
        window_size: int = 5
    ):
        """
        Initialize gatekeeper bypass detector.

        Args:
            perfect_threshold: Tolerance for "too perfect" values
            simplex_tolerance: Allowed deviation from R+S+N=1
            jump_threshold: Maximum allowed jump in certificate values
            window_size: Number of recent certificates to track
        """
        self.perfect_threshold = perfect_threshold
        self.simplex_tolerance = simplex_tolerance
        self.jump_threshold = jump_threshold
        self.window_size = window_size
        self.certificate_history: List[dict] = []

    def update(
        self,
        R: float,
        S: float,
        N: float,
        kappa: float,
        sigma: float
    ):
        """
        Add new certificate values.

        Args:
            R: Relevance component
            S: Superfluous component
            N: Noise component
            kappa: Compatibility metric
            sigma: Turbulence metric
        """
        cert = {
            'R': R,
            'S': S,
            'N': N,
            'kappa': kappa,
            'sigma': sigma
        }
        self.certificate_history.append(cert)

        # Keep only recent window
        if len(self.certificate_history) > self.window_size:
            self.certificate_history.pop(0)

    def is_bypass_attempt(self) -> Tuple[bool, str]:
        """
        Check if certificate shows signs of manipulation.

        Returns:
            (is_bypass, reason) tuple

        Detection criteria:
        1. Suspiciously perfect values (exactly 0.5, 0.7, etc.)
        2. Simplex violation (R+S+N ≠ 1)
        3. Physical impossibilities (κ-σ relationship)
        4. Temporal anomalies (sudden jumps)
        """
        if len(self.certificate_history) == 0:
            return False, "No certificate history"

        current = self.certificate_history[-1]

        # Check 1: Suspiciously perfect values
        # Values exactly at round numbers (0.5, 0.7, etc.) are unlikely in real systems
        perfect_values = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
        for key, value in current.items():
            for perfect in perfect_values:
                if abs(value - perfect) < self.perfect_threshold:
                    return True, f"Suspiciously perfect {key}={value:.10f} ≈ {perfect} (possible manipulation)"

        # Check 2: Simplex constraint violation
        # R + S + N should equal 1.0 (within tolerance)
        simplex_sum = current['R'] + current['S'] + current['N']
        simplex_error = abs(simplex_sum - 1.0)
        if simplex_error > self.simplex_tolerance:
            return True, f"Simplex violation: R+S+N={simplex_sum:.6f} (error={simplex_error:.6f} > {self.simplex_tolerance})"

        # Check 3: Physical impossibilities
        # High κ (good compatibility) with high σ (high turbulence) is suspicious
        # Normally κ should decrease as σ increases due to Oobleck gate: κ_req = 0.5 + 0.4·σ
        if current['kappa'] > 0.8 and current['sigma'] > 0.7:
            return True, f"Physical impossibility: κ={current['kappa']:.3f} too high for σ={current['sigma']:.3f}"

        # Also check for impossibly low noise with high turbulence
        if current['N'] < 0.1 and current['sigma'] > 0.8:
            return True, f"Physical impossibility: N={current['N']:.3f} too low for σ={current['sigma']:.3f}"

        # Check 4: Temporal anomalies (sudden jumps)
        if len(self.certificate_history) >= 2:
            previous = self.certificate_history[-2]

            for key in ['R', 'S', 'N', 'kappa', 'sigma']:
                delta = abs(current[key] - previous[key])
                if delta > self.jump_threshold:
                    return True, f"Temporal anomaly: {key} jumped {delta:.3f} (from {previous[key]:.3f} to {current[key]:.3f})"

        return False, "Certificate appears legitimate"

    def reset(self):
        """Clear all history."""
        self.certificate_history.clear()


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def check_format_mismatch(
    output: any,
    expected_schema: any,
    strict: bool = True
) -> Tuple[bool, str]:
    """
    Check if output matches expected type/schema.

    Args:
        output: The output to validate
        expected_schema: Expected type or dict schema
        strict: If True, require exact type match

    Returns:
        (is_mismatch, reason) tuple

    Example:
        >>> check_format_mismatch({"answer": 42}, {"answer": str})
        (True, "Field 'answer' has wrong type: expected <class 'str'>, got <class 'int'>")
    """
    # For dict schemas, check structure
    if isinstance(expected_schema, dict):
        if not isinstance(output, dict):
            return True, f"Expected dict, got {type(output).__name__}"

        for key, expected_val_type in expected_schema.items():
            if key not in output:
                return True, f"Missing required field: {key}"
            if not isinstance(output[key], expected_val_type):
                return True, f"Field '{key}' has wrong type: expected {expected_val_type.__name__}, got {type(output[key]).__name__}"

        return False, "Format matches"

    # For simple type checks
    if strict:
        if not isinstance(output, expected_schema):
            return True, f"Expected {expected_schema.__name__}, got {type(output).__name__}"

    return False, "Format matches"


# =============================================================================
# CLASSIFICATION LOGIC
# =============================================================================

def classify_rsct(
    collapse_type: Optional[CollapseType],
    N: float,
    S_sup: float,
    R: float,
    kappa_gate: float,
    sigma: float,
    consensus: float = 1.0,
    kappa_H: Optional[float] = None,
    kappa_L: Optional[float] = None,
    kappa_interface: Optional[float] = None,
    sigma_max: Optional[float] = None,  # For Mode 2.3 spike detection
    loop_detected: Optional[bool] = None,  # For Mode 4.3 loop detection
    loop_step: Optional[int] = None,  # Which step the loop was detected at
    embeddings: Optional[torch.Tensor] = None,  # For Mode 1.3 dimensional fracture check
    output: Optional[any] = None,  # For Mode 1.4 format mismatch check
    expected_schema: Optional[any] = None,  # Expected format for output
    starvation_detector: Optional[GradientStarvationDetector] = None,  # For Mode 2.2 gradient starvation
    hacking_detector: Optional[RewardHackingDetector] = None,  # For Mode 3.3 reward hacking
    bypass_detector: Optional[GatekeeperBypassDetector] = None,  # For Mode 4.4 gatekeeper bypass
) -> RSCTClassification:
    """
    Classify into RSCT mode based on signals + thresholds.

    This implements the dual taxonomy: uses signal-based detection
    (current implementation) to map to gate-based enforcement (paper).

    Priority:
    1. Direct mapping from collapse_type (if in table)
    2. Threshold-based classification (using gate logic)
    3. Default to PROCEED if no failure detected

    Args:
        collapse_type: Detected collapse type (signal-based), if any
        N: Noise component [0-1]
        S_sup: Superfluous component [0-1]
        R: Relevance component [0-1]
        kappa_gate: Overall compatibility [0-1]
        sigma: Turbulence (mean) [0-1]
        consensus: Multi-agent consensus [0-1]
        kappa_H: High-level modality κ (optional)
        kappa_L: Low-level modality κ (optional)
        kappa_interface: Cross-modal κ (optional)
        sigma_max: Maximum turbulence (for spike detection, optional)
        loop_detected: Whether reasoning loop was detected (optional)
        loop_step: Step index where loop was detected (optional)
        embeddings: Embedding tensor for dimensional fracture check (optional)
        output: Output to validate format (optional)
        expected_schema: Expected type or dict schema for output (optional)
        starvation_detector: Gradient starvation detector instance (optional)
        hacking_detector: Reward hacking detector instance (optional)
        bypass_detector: Gatekeeper bypass detector instance (optional)

    Returns:
        RSCTClassification with mode, group, gate, remediation, trigger

    Example:
        >>> rsct = classify_rsct(
        ...     collapse_type=CollapseType.HALLUCINATION,
        ...     N=0.2, S_sup=0.3, R=0.5,
        ...     kappa_gate=0.8, sigma=0.3
        ... )
        >>> rsct.mode
        "3.1"
        >>> rsct.remediation
        "REPAIR"
    """

    # ═════════════════════════════════════════════════════════════════════
    # PRIORITY 0: Meta-safety check (Mode 4.4 - Gatekeeper Bypass)
    # ═════════════════════════════════════════════════════════════════════
    # Check FIRST before all other logic - detect adversarial manipulation
    if bypass_detector is not None:
        is_bypass, reason = bypass_detector.is_bypass_attempt()
        if is_bypass:
            return RSCTClassification(
                mode="4.4",
                group=4,  # Execution Collapse (meta-level)
                gate=None,  # Bypasses gate system itself
                remediation="ESCALATE",  # Requires human review
                trigger=f"Gatekeeper bypass: {reason}",
                confidence=0.70  # Medium-high confidence - adversarial context
            )

    # ═════════════════════════════════════════════════════════════════════
    # PRIORITY 1: Direct mapping from collapse_type
    # ═════════════════════════════════════════════════════════════════════
    if collapse_type and collapse_type in SIGNAL_TO_RSCT:
        mode, group, gate, remediation, trigger = SIGNAL_TO_RSCT[collapse_type]
        return RSCTClassification(
            mode=mode,
            group=group,
            gate=gate,
            remediation=remediation,
            trigger=trigger,
            confidence=1.0  # High confidence - direct mapping
        )

    # ═════════════════════════════════════════════════════════════════════
    # PRIORITY 2: Threshold-based (RSCT Algorithm 1 gate logic)
    # ═════════════════════════════════════════════════════════════════════

    # Mode 1.3: Dimensional Fracture (check early - encoding collapse)
    # Check if embedding dimension has enough "room to rotate"
    # Over-parameterization ratio κ = dim / stable_rank(Cov) should be ≥ 50
    if embeddings is not None:
        from ..geometric.primitives.rotor import check_rotor_capacity

        if not check_rotor_capacity(embeddings, min_ratio=50.0):
            dim = embeddings.shape[-1] if embeddings.dim() > 0 else 0
            return RSCTClassification(
                mode="1.3",
                group=1,  # Encoding Collapse
                gate="Gate1",
                remediation="REJECT",
                trigger=f"Insufficient rotation capacity (dim={dim}, κ < 50)",
                confidence=0.85
            )

    # Mode 1.4: Format Mismatch (check early - encoding collapse)
    # Validate output format matches expected schema
    if output is not None and expected_schema is not None:
        is_mismatch, reason = check_format_mismatch(output, expected_schema)
        if is_mismatch:
            return RSCTClassification(
                mode="1.4",
                group=1,  # Encoding Collapse
                gate="Gate1",
                remediation="REJECT",
                trigger=f"Format mismatch: {reason}",
                confidence=0.95  # High confidence - deterministic check
            )

    # Gate 1: Integrity Guard (N ≥ 0.5)
    if N >= 0.5:
        return RSCTClassification(
            mode="1.1",
            group=1,
            gate="Gate1",
            remediation="REJECT",
            trigger=f"N={N:.3f} ≥ 0.5 (noise saturation)",
            confidence=0.9  # High confidence - clear threshold
        )

    # Gate 2: Consensus Gate (c < 0.4)
    if consensus < 0.4:
        return RSCTClassification(
            mode="3.2",
            group=3,
            gate="Gate2",
            remediation="BLOCK",
            trigger=f"consensus={consensus:.3f} < 0.4 (phasor conflict)",
            confidence=0.9
        )

    # Additional threshold checks (before gate logic to catch edge cases)

    # Mode 4.3: Stalled Navigation (reasoning loop)
    # Check for loops via bivector similarity between non-consecutive steps
    # If step[i] ≈ step[j] where j >> i, solver is stuck in a loop
    if loop_detected:
        loop_info = f" at step {loop_step}" if loop_step is not None else ""
        return RSCTClassification(
            mode="4.3",
            group=4,  # Execution Collapse
            gate=None,  # Not caught by specific gate
            remediation="TIMEOUT",  # Stop the loop
            trigger=f"Reasoning loop detected{loop_info} (stalled navigation)",
            confidence=0.85
        )

    # Mode 2.3: Oobleck Jamming (turbulence spike)
    # Check for σ spike: σ_max > 2×σ_mean AND σ_max > 0.8
    # This indicates sudden instability (Oobleck shear-thickening behavior)
    if sigma_max is not None:
        is_spike = (sigma_max > 2 * sigma) and (sigma_max > 0.8)
        if is_spike:
            return RSCTClassification(
                mode="2.3",
                group=2,
                gate=None,  # Not caught by specific gate - dynamics failure
                remediation="BLOCK",
                trigger=f"σ spike: max={sigma_max:.3f} > 2×mean={sigma:.3f}, max > 0.8 (Oobleck jamming)",
                confidence=0.85
            )

    # Mode 2.2: Gradient Starvation (learning stalled)
    # Check if solver is no longer improving via loss/metric tracking
    if starvation_detector is not None:
        is_starved, reason = starvation_detector.is_starved()
        if is_starved:
            return RSCTClassification(
                mode="2.2",
                group=2,  # Solver Dynamics Collapse
                gate=None,  # Not caught by specific gate - dynamics failure
                remediation="BLOCK",
                trigger=f"Gradient starvation: {reason}",
                confidence=0.80
            )

    # Mode 3.3: Reward Hacking (gaming the metric)
    # Check if system optimizes proxy metric instead of true objective
    if hacking_detector is not None:
        is_hacking, reason = hacking_detector.is_hacking()
        if is_hacking:
            return RSCTClassification(
                mode="3.3",
                group=3,  # Semantic Collapse
                gate=None,  # Not caught by specific gate - semantic failure
                remediation="BLOCK",
                trigger=f"Reward hacking: {reason}",
                confidence=0.75
            )

    # High turbulence (σ > 0.7) suggests trajectory divergence
    # Check this BEFORE Gate 3 to avoid missing high-σ cases
    if sigma > 0.7:
        return RSCTClassification(
            mode="2.1",
            group=2,
            gate=None,  # Not caught by specific gate
            remediation="BLOCK",
            trigger=f"σ={sigma:.3f} > 0.7 (trajectory divergence)",
            confidence=0.7
        )

    # Superfluous drowning (S_sup ≫ R)
    # Check this BEFORE all-gates-pass to catch heuristic cases
    if S_sup > R * 2 and R < 0.4:
        return RSCTClassification(
            mode="1.2",
            group=1,
            gate="Gate1",
            remediation="RE_ENCODE",
            trigger=f"S_sup={S_sup:.3f} ≫ R={R:.3f} (superfluous drowning)",
            confidence=0.6  # Medium confidence - heuristic threshold
        )

    # Gate 3: Admissibility Gate (Oobleck)
    # κ_req(σ) = κ_base + λ·σ = 0.5 + 0.4·σ
    kappa_base = 0.5
    lambda_coef = 0.4
    landauer_buffer = 0.05
    kappa_req = kappa_base + lambda_coef * sigma

    if kappa_gate < kappa_req - landauer_buffer:
        # Clear failure - below Landauer buffer
        gap = kappa_req - kappa_gate
        return RSCTClassification(
            mode="4.1",
            group=4,
            gate="Gate3",
            remediation="RE_ENCODE",
            trigger=f"κ_gate={kappa_gate:.3f} < κ_req={kappa_req:.3f} (gap={gap:.3f})",
            confidence=0.8
        )

    elif kappa_gate < kappa_req:
        # Gray zone - use σ as tie-breaker
        if sigma > 0.5:
            return RSCTClassification(
                mode="2.1",
                group=2,
                gate="Gate3",
                remediation="RE_ENCODE",
                trigger=f"Turbulent gray zone: σ={sigma:.3f} > 0.5",
                confidence=0.6  # Lower confidence - gray zone
            )
        else:
            # Within Landauer buffer, stable - proceed cautiously
            return RSCTClassification(
                mode="0.0",
                group=0,
                gate="Gate3",
                remediation="PROCEED_CAUTIOUS",
                trigger=f"Landauer buffer: κ_gap={kappa_req - kappa_gate:.3f} ≤ {landauer_buffer}, σ={sigma:.3f} ≤ 0.5",
                confidence=0.7
            )

    # Gate 4: Grounding Repair (κ_L < 0.3)
    # Check this BEFORE all-gates-pass
    if kappa_L is not None and kappa_L < 0.3:
        return RSCTClassification(
            mode="4.2",
            group=4,
            gate="Gate4",
            remediation="REPAIR",
            trigger=f"κ_L={kappa_L:.3f} < 0.3 (low-level grounding failure)",
            confidence=0.8
        )

    # ═════════════════════════════════════════════════════════════════════
    # PRIORITY 3: Default - All gates passed
    # ═════════════════════════════════════════════════════════════════════
    return RSCTClassification(
        mode="0.0",
        group=0,
        gate=None,
        remediation="PROCEED",
        trigger="All gates passed",
        confidence=1.0
    )


def classify_dual(
    collapse_type: Optional[CollapseType],
    N: float,
    S_sup: float,
    R: float,
    kappa_gate: float,
    sigma: float,
    consensus: float = 1.0,
    kappa_H: Optional[float] = None,
    kappa_L: Optional[float] = None,
    kappa_interface: Optional[float] = None,
) -> RSCTClassification:
    """
    Alias for classify_rsct() with clearer name.

    "Dual" refers to dual taxonomy: signal-based + gate-based.
    """
    return classify_rsct(
        collapse_type=collapse_type,
        N=N,
        S_sup=S_sup,
        R=R,
        kappa_gate=kappa_gate,
        sigma=sigma,
        consensus=consensus,
        kappa_H=kappa_H,
        kappa_L=kappa_L,
        kappa_interface=kappa_interface,
    )


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def get_rsct_mode_name(mode: str) -> str:
    """
    Get human-readable name for RSCT mode.

    Args:
        mode: Mode ID (e.g., "1.1", "3.1")

    Returns:
        Descriptive name

    Example:
        >>> get_rsct_mode_name("3.1")
        "Fluent Hallucination"
    """
    MODE_NAMES = {
        "1.1": "Noise Saturation",
        "1.2": "Superfluous Drowning",
        "1.3": "Dimensional Fracture",
        "1.4": "Format Mismatch",
        "2.1": "Trajectory Divergence",
        "2.2": "Gradient Starvation",
        "2.3": "Oobleck Jamming",
        "2.4": "Substrate Degradation",
        "3.1": "Fluent Hallucination",
        "3.2": "Phasor Conflict",
        "3.3": "Reward Hacking",
        "3.4": "OOD Fabrication",
        "4.1": "Weakest-Link Cascade",
        "4.2": "Cross-Modal Desync",
        "4.3": "Stalled Navigation",
        "4.4": "Gatekeeper Bypass",
        "0.0": "Unknown / Healthy",
    }
    return MODE_NAMES.get(mode, f"Unknown mode {mode}")


def get_rsct_group_name(group: int) -> str:
    """Get human-readable name for RSCT group."""
    GROUP_NAMES = {
        0: "Unknown",
        1: "Encoding Collapse",
        2: "Solver Dynamics Collapse",
        3: "Semantic Collapse",
        4: "Execution Collapse",
    }
    return GROUP_NAMES.get(group, f"Unknown group {group}")


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Main classification
    "RSCTClassification",
    "classify_rsct",
    "classify_dual",

    # Enums
    "RSCTGroup",
    "RSCTRemediation",

    # Detectors
    "GradientStarvationDetector",
    "RewardHackingDetector",
    "GatekeeperBypassDetector",

    # Utilities
    "get_rsct_mode_name",
    "get_rsct_group_name",

    # Mapping table (for debugging/inspection)
    "SIGNAL_TO_RSCT",
]
