"""
Four-Tier Constraint Taxonomy
=============================

Implements the Actual/Consolidated/Learned/Emergent constraint classification
system aligned with the four curriculum stages (Mastery/Refinement/Expansion/Foundation).

Constraint Tiers (4 tiers for consistency with 4 curriculum stages):
1. ACTUAL - Fatal violations, must stop immediately (maps to Mastery)
2. CONSOLIDATED - Critical violations, validated long-term patterns (maps to Refinement)
3. LEARNED - Warning-level, patterns being reinforced (maps to Expansion)
4. EMERGENT - Advisory-level, new discoveries (maps to Foundation)

Each tier maps to different memristor behavioral models:
- ACTUAL → Threshold Adaptive (no change below threshold, permanent)
- CONSOLIDATED → Bounded Drift (slow adaptation within strict bounds)
- LEARNED → Linear Ion Drift (proportional adaptation)
- EMERGENT → Nonlinear Ion Drift (fast adaptation, boundary crystallization)

N-Level Discussion:
    Why 4 tiers instead of N? Deep RL uses 1000+ layers for representation learning,
    but constraint hierarchies serve a different purpose. Tradeoffs:

    - 2-3 tiers: Too coarse, can't distinguish "validated but adaptable" from "new"
    - 4 tiers: Maps to Bloom's taxonomy, curriculum stages, human-interpretable
    - N tiers (N>10): Loses interpretability, harder to debug, governance nightmare
    - 1000 layers: Only for continuous representation spaces, not discrete constraints

    Use N>4 tiers when: (1) domain has natural hierarchy >4 levels deep,
    (2) automated tier assignment with human review, (3) tiers are generated
    not hand-crafted. For most applications, 4 is the sweet spot.

Usage:
    from yrsn.core.decomposition.constraint_taxonomy import (
        ConstraintTier,
        TieredConstraint,
        ConstraintTaxonomy,
    )

    taxonomy = ConstraintTaxonomy()
    taxonomy.add_constraint(TieredConstraint(
        name="no_hallucination",
        tier=ConstraintTier.ACTUAL,
        threshold=0.95,
        description="Must not hallucinate facts"
    ))

    result = taxonomy.check(hidden_state, constraints_active=True)
    if result.has_fatal_violation:
        raise RuntimeError(result.fatal_violations[0].message)
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Callable
from collections import deque
import time
import numpy as np


# =============================================================================
# Constraint Tier Definitions
# =============================================================================


class ConstraintTier(Enum):
    """
    Four-tier constraint classification aligned with curriculum stages.

    Tier → Curriculum Stage → Memory Type → Decay Rate:
    - ACTUAL → Mastery → Permanent → Never forgets
    - CONSOLIDATED → Refinement → Long-term → Very slow decay
    - LEARNED → Expansion → Medium-term → Slow decay
    - EMERGENT → Foundation → Short-term → Fast decay (unless promoted)
    """
    ACTUAL = "actual"            # Fatal - must stop (permanent knowledge)
    CONSOLIDATED = "consolidated"  # Critical - validated patterns (long-term)
    LEARNED = "learned"          # Warning - being reinforced (medium-term)
    EMERGENT = "emergent"        # Advisory - new discoveries (short-term)


class ViolationSeverity(Enum):
    """Severity of constraint violation (4 levels matching 4 tiers)."""
    NONE = "none"
    ADVISORY = "advisory"    # Emergent tier - informational
    WARNING = "warning"      # Learned tier - proceed with caution
    CRITICAL = "critical"    # Consolidated tier - serious, needs attention
    FATAL = "fatal"          # Actual tier - must stop


class MemristorModel(Enum):
    """
    Memristor behavioral models mapped to constraint tiers.

    Four models for four tiers:
    - THRESHOLD_ADAPTIVE: No change below threshold (Actual - permanent)
    - BOUNDED_DRIFT: Slow adaptation within strict bounds (Consolidated - stable)
    - LINEAR_ION_DRIFT: Proportional adaptation (Learned - adaptive)
    - NONLINEAR_ION_DRIFT: Fast adaptation with crystallization (Emergent - exploratory)
    """
    THRESHOLD_ADAPTIVE = "threshold_adaptive"    # Actual tier
    BOUNDED_DRIFT = "bounded_drift"              # Consolidated tier (new)
    LINEAR_ION_DRIFT = "linear_ion_drift"        # Learned tier
    NONLINEAR_ION_DRIFT = "nonlinear_ion_drift"  # Emergent tier


# Mapping from tier to memristor model (4 tiers → 4 models)
TIER_TO_MEMRISTOR = {
    ConstraintTier.ACTUAL: MemristorModel.THRESHOLD_ADAPTIVE,
    ConstraintTier.CONSOLIDATED: MemristorModel.BOUNDED_DRIFT,
    ConstraintTier.LEARNED: MemristorModel.LINEAR_ION_DRIFT,
    ConstraintTier.EMERGENT: MemristorModel.NONLINEAR_ION_DRIFT,
}


# =============================================================================
# Constraint Definitions
# =============================================================================


@dataclass
class TieredConstraint:
    """
    A constraint with tier classification.

    Parameters
    ----------
    name : str
        Unique constraint identifier
    tier : ConstraintTier
        Constraint tier (ACTUAL/LEARNED/EMERGENT)
    threshold : float
        Value at which constraint is violated (0-1)
    description : str
        Human-readable description
    metric_name : str, optional
        Name of metric to check (default: name)
    invert : bool
        If True, violation occurs when value > threshold
        If False, violation occurs when value < threshold
    """
    name: str
    tier: ConstraintTier
    threshold: float
    description: str = ""
    metric_name: Optional[str] = None
    invert: bool = False  # If True, higher values are violations

    def __post_init__(self):
        if self.metric_name is None:
            self.metric_name = self.name

    @property
    def memristor_model(self) -> MemristorModel:
        """Get associated memristor model."""
        return TIER_TO_MEMRISTOR[self.tier]

    def check(self, value: float) -> "ConstraintViolation":
        """
        Check if constraint is violated.

        Parameters
        ----------
        value : float
            Metric value to check

        Returns
        -------
        ConstraintViolation
            Violation details (severity=NONE if not violated)
        """
        if self.invert:
            is_violated = value > self.threshold
            margin = value - self.threshold if is_violated else 0
        else:
            is_violated = value < self.threshold
            margin = self.threshold - value if is_violated else 0

        if not is_violated:
            return ConstraintViolation(
                constraint=self,
                severity=ViolationSeverity.NONE,
                value=value,
                margin=0.0,
                message=None,
            )

        severity = {
            ConstraintTier.ACTUAL: ViolationSeverity.FATAL,
            ConstraintTier.CONSOLIDATED: ViolationSeverity.CRITICAL,
            ConstraintTier.LEARNED: ViolationSeverity.WARNING,
            ConstraintTier.EMERGENT: ViolationSeverity.ADVISORY,
        }[self.tier]

        message = (
            f"{self.name}: {self.description} "
            f"(value={value:.3f}, threshold={self.threshold:.3f}, margin={margin:.3f})"
        )

        return ConstraintViolation(
            constraint=self,
            severity=severity,
            value=value,
            margin=margin,
            message=message,
        )


@dataclass
class ConstraintViolation:
    """Result of constraint check."""
    constraint: TieredConstraint
    severity: ViolationSeverity
    value: float
    margin: float  # How much the violation exceeds threshold
    message: Optional[str]

    @property
    def is_violated(self) -> bool:
        return self.severity != ViolationSeverity.NONE

    @property
    def is_fatal(self) -> bool:
        return self.severity == ViolationSeverity.FATAL


# =============================================================================
# Constraint Check Result
# =============================================================================


@dataclass
class ConstraintCheckResult:
    """Result of checking all constraints."""

    violations: List[ConstraintViolation]
    timestamp: float = field(default_factory=time.time)

    @property
    def fatal_violations(self) -> List[ConstraintViolation]:
        return [v for v in self.violations if v.severity == ViolationSeverity.FATAL]

    @property
    def critical_violations(self) -> List[ConstraintViolation]:
        return [v for v in self.violations if v.severity == ViolationSeverity.CRITICAL]

    @property
    def warnings(self) -> List[ConstraintViolation]:
        return [v for v in self.violations if v.severity == ViolationSeverity.WARNING]

    @property
    def advisories(self) -> List[ConstraintViolation]:
        return [v for v in self.violations if v.severity == ViolationSeverity.ADVISORY]

    @property
    def has_fatal_violation(self) -> bool:
        return len(self.fatal_violations) > 0

    @property
    def has_critical_violation(self) -> bool:
        return len(self.critical_violations) > 0

    @property
    def has_warnings(self) -> bool:
        return len(self.warnings) > 0

    @property
    def has_advisories(self) -> bool:
        return len(self.advisories) > 0

    @property
    def is_healthy(self) -> bool:
        return not self.has_fatal_violation and not self.has_critical_violation and not self.has_warnings

    def get_worst_severity(self) -> ViolationSeverity:
        """Get worst violation severity (4 levels)."""
        if self.has_fatal_violation:
            return ViolationSeverity.FATAL
        if self.has_critical_violation:
            return ViolationSeverity.CRITICAL
        if self.has_warnings:
            return ViolationSeverity.WARNING
        if self.has_advisories:
            return ViolationSeverity.ADVISORY
        return ViolationSeverity.NONE

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return {
            "timestamp": self.timestamp,
            "worst_severity": self.get_worst_severity().value,
            "has_fatal": self.has_fatal_violation,
            "num_warnings": len(self.warnings),
            "num_advisories": len(self.advisories),
            "violations": [
                {
                    "constraint": v.constraint.name,
                    "tier": v.constraint.tier.value,
                    "severity": v.severity.value,
                    "value": v.value,
                    "threshold": v.constraint.threshold,
                    "message": v.message,
                }
                for v in self.violations
                if v.is_violated
            ],
        }


# =============================================================================
# Constraint Taxonomy Manager
# =============================================================================


class ConstraintTaxonomy:
    """
    Manages the three-tier constraint taxonomy.

    Maintains a registry of constraints organized by tier and provides
    methods for checking constraints against metrics.

    Example
    -------
    >>> taxonomy = ConstraintTaxonomy()
    >>> taxonomy.add_default_yrsn_constraints()
    >>> result = taxonomy.check({"R": 0.3, "S": 0.4, "N": 0.3})
    >>> if result.has_fatal_violation:
    ...     print("FATAL:", result.fatal_violations[0].message)
    """

    def __init__(self):
        self._constraints: Dict[str, TieredConstraint] = {}
        self._history: deque = deque(maxlen=1000)

    def add_constraint(self, constraint: TieredConstraint) -> None:
        """Add a constraint to the taxonomy."""
        self._constraints[constraint.name] = constraint

    def remove_constraint(self, name: str) -> None:
        """Remove a constraint by name."""
        self._constraints.pop(name, None)

    def get_constraint(self, name: str) -> Optional[TieredConstraint]:
        """Get constraint by name."""
        return self._constraints.get(name)

    def list_constraints(self, tier: Optional[ConstraintTier] = None) -> List[TieredConstraint]:
        """List all constraints, optionally filtered by tier."""
        constraints = list(self._constraints.values())
        if tier is not None:
            constraints = [c for c in constraints if c.tier == tier]
        return constraints

    def check(
        self,
        metrics: Dict[str, float],
        constraints_to_check: Optional[List[str]] = None,
        threshold_multiplier: float = 1.0,
    ) -> ConstraintCheckResult:
        """
        Check constraints against metrics.

        Parameters
        ----------
        metrics : dict
            Metric values keyed by metric name
        constraints_to_check : list, optional
            Specific constraints to check (default: all)
        threshold_multiplier : float
            Multiplier applied to thresholds (< 1.0 = stricter, > 1.0 = more lenient)
            Used for phase-aware checking from Pillar 2 integration.

        Returns
        -------
        ConstraintCheckResult
            Results of all constraint checks
        """
        violations = []

        constraints = self._constraints.values()
        if constraints_to_check is not None:
            constraints = [c for c in constraints if c.name in constraints_to_check]

        for constraint in constraints:
            metric_name = constraint.metric_name
            if metric_name in metrics:
                value = metrics[metric_name]

                # Apply threshold multiplier for phase-aware checking
                if threshold_multiplier != 1.0:
                    adjusted_constraint = TieredConstraint(
                        name=constraint.name,
                        tier=constraint.tier,
                        threshold=constraint.threshold * threshold_multiplier,
                        description=constraint.description,
                        metric_name=constraint.metric_name,
                        invert=constraint.invert,
                    )
                    violation = adjusted_constraint.check(value)
                else:
                    violation = constraint.check(value)

                if violation.is_violated:
                    violations.append(violation)

        result = ConstraintCheckResult(violations=violations)
        self._history.append(result)
        return result

    def check_phase_aware(
        self,
        metrics: Dict[str, float],
        quality: float,
        constraints_to_check: Optional[List[str]] = None,
    ) -> ConstraintCheckResult:
        """
        Phase-aware constraint check using Pillar 2 quality metric.

        Adjusts thresholds based on quality phase:
        - HIGH quality (α > 0.70): Stricter thresholds (multiplier 0.8)
        - MEDIUM quality (0.40 ≤ α ≤ 0.70): Default thresholds (multiplier 1.0)
        - LOW quality (α < 0.40): More lenient thresholds (multiplier 1.2)

        Parameters
        ----------
        metrics : dict
            Metric values keyed by metric name
        quality : float
            Quality metric α from Pillar 2 [0, 1]
        constraints_to_check : list, optional
            Specific constraints to check

        Returns
        -------
        ConstraintCheckResult
            Phase-aware constraint check results
        """
        # Determine multiplier based on quality phase
        if quality > 0.70:
            multiplier = 0.8  # Stricter at high quality
        elif quality < 0.40:
            multiplier = 1.2  # More lenient at low quality
        else:
            multiplier = 1.0  # Default at medium quality

        return self.check(metrics, constraints_to_check, threshold_multiplier=multiplier)

    def get_history(self, limit: int = 100) -> List[ConstraintCheckResult]:
        """Get recent constraint check history."""
        return list(self._history)[-limit:]

    def clear_history(self) -> None:
        """Clear constraint check history."""
        self._history.clear()

    # =========================================================================
    # Preset Constraints
    # =========================================================================

    def add_default_yrsn_constraints(self) -> None:
        """Add default YRSN constraints from Four Pillars document."""

        # ACTUAL constraints (fatal violations)
        self.add_constraint(TieredConstraint(
            name="min_relevance",
            tier=ConstraintTier.ACTUAL,
            threshold=0.1,
            description="Minimum relevance ratio required",
            metric_name="R",
            invert=False,  # violation if R < 0.1
        ))

        self.add_constraint(TieredConstraint(
            name="max_noise_fatal",
            tier=ConstraintTier.ACTUAL,
            threshold=0.5,
            description="Maximum noise before fatal failure",
            metric_name="N",
            invert=True,  # violation if N > 0.5
        ))

        # LEARNED constraints (warnings)
        self.add_constraint(TieredConstraint(
            name="poisoning_warning",
            tier=ConstraintTier.LEARNED,
            threshold=0.3,
            description="Noise level indicates potential poisoning",
            metric_name="N",
            invert=True,  # violation if N > 0.3
        ))

        self.add_constraint(TieredConstraint(
            name="distraction_warning",
            tier=ConstraintTier.LEARNED,
            threshold=0.4,
            description="Superfluous content indicates distraction",
            metric_name="S",
            invert=True,  # violation if S > 0.4
        ))

        self.add_constraint(TieredConstraint(
            name="low_quality_warning",
            tier=ConstraintTier.LEARNED,
            threshold=0.4,
            description="Overall quality is low",
            metric_name="quality",
            invert=False,  # violation if quality < 0.4
        ))

        # EMERGENT constraints (advisories)
        self.add_constraint(TieredConstraint(
            name="suboptimal_relevance",
            tier=ConstraintTier.EMERGENT,
            threshold=0.6,
            description="Relevance could be improved",
            metric_name="R",
            invert=False,  # violation if R < 0.6
        ))

        self.add_constraint(TieredConstraint(
            name="noise_present",
            tier=ConstraintTier.EMERGENT,
            threshold=0.15,
            description="Some noise detected in context",
            metric_name="N",
            invert=True,  # violation if N > 0.15
        ))

        self.add_constraint(TieredConstraint(
            name="superfluous_present",
            tier=ConstraintTier.EMERGENT,
            threshold=0.25,
            description="Some superfluous content detected",
            metric_name="S",
            invert=True,  # violation if S > 0.25
        ))

    def add_collapse_constraints(self) -> None:
        """Add constraints matching collapse detection thresholds."""

        # Match CollapseSignature thresholds
        self.add_constraint(TieredConstraint(
            name="collapse_poisoning",
            tier=ConstraintTier.LEARNED,
            threshold=0.30,
            description="Poisoning collapse threshold",
            metric_name="N",
            invert=True,
        ))

        self.add_constraint(TieredConstraint(
            name="collapse_distraction",
            tier=ConstraintTier.LEARNED,
            threshold=0.40,
            description="Distraction collapse threshold",
            metric_name="S",
            invert=True,
        ))

        # Confusion requires compound check (handled separately)

    def to_dict(self) -> Dict[str, Any]:
        """Export taxonomy as dictionary."""
        return {
            "constraints": {
                name: {
                    "tier": c.tier.value,
                    "threshold": c.threshold,
                    "metric_name": c.metric_name,
                    "invert": c.invert,
                    "description": c.description,
                    "memristor_model": c.memristor_model.value,
                }
                for name, c in self._constraints.items()
            },
            "counts": {
                "actual": len(self.list_constraints(ConstraintTier.ACTUAL)),
                "learned": len(self.list_constraints(ConstraintTier.LEARNED)),
                "emergent": len(self.list_constraints(ConstraintTier.EMERGENT)),
            },
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConstraintTaxonomy":
        """Create taxonomy from dictionary."""
        taxonomy = cls()
        for name, c_data in data.get("constraints", {}).items():
            taxonomy.add_constraint(TieredConstraint(
                name=name,
                tier=ConstraintTier(c_data["tier"]),
                threshold=c_data["threshold"],
                metric_name=c_data.get("metric_name", name),
                invert=c_data.get("invert", False),
                description=c_data.get("description", ""),
            ))
        return taxonomy


# =============================================================================
# Convenience Functions
# =============================================================================


def create_yrsn_taxonomy() -> ConstraintTaxonomy:
    """Create taxonomy with default YRSN constraints."""
    taxonomy = ConstraintTaxonomy()
    taxonomy.add_default_yrsn_constraints()
    return taxonomy


def check_yrsn_constraints(
    R: float,
    S: float,
    N: float,
    quality: Optional[float] = None,
) -> ConstraintCheckResult:
    """
    Quick constraint check for YRSN metrics.

    Parameters
    ----------
    R, S, N : float
        YRSN component ratios
    quality : float, optional
        Quality metric (default: R)

    Returns
    -------
    ConstraintCheckResult
        Constraint check results
    """
    taxonomy = create_yrsn_taxonomy()
    metrics = {
        "R": R,
        "S": S,
        "N": N,
        "quality": quality if quality is not None else R,
    }
    return taxonomy.check(metrics)


def check_yrsn_constraints_phase_aware(
    R: float,
    S: float,
    N: float,
    quality: float,
) -> ConstraintCheckResult:
    """
    Phase-aware constraint check for YRSN metrics.

    Uses Pillar 2 quality metric to adjust constraint thresholds:
    - HIGH quality (α > 0.70): Stricter thresholds
    - MEDIUM quality (0.40 ≤ α ≤ 0.70): Default thresholds
    - LOW quality (α < 0.40): More lenient thresholds

    Parameters
    ----------
    R, S, N : float
        YRSN component ratios
    quality : float
        Quality metric α from Pillar 2 [0, 1]

    Returns
    -------
    ConstraintCheckResult
        Phase-aware constraint check results
    """
    taxonomy = create_yrsn_taxonomy()
    metrics = {
        "R": R,
        "S": S,
        "N": N,
        "quality": quality,
    }
    return taxonomy.check_phase_aware(metrics, quality)


def get_tier_enforcement_rules() -> Dict[str, Dict[str, Any]]:
    """
    Get enforcement rules for each tier.

    Returns
    -------
    dict
        Enforcement rules by tier
    """
    return {
        ConstraintTier.ACTUAL.value: {
            "action": "STOP",
            "description": "Fatal violation - must stop immediately",
            "log_level": "CRITICAL",
            "can_continue": False,
            "memristor_model": MemristorModel.THRESHOLD_ADAPTIVE.value,
        },
        ConstraintTier.LEARNED.value: {
            "action": "WARN",
            "description": "Warning - continue with caution",
            "log_level": "WARNING",
            "can_continue": True,
            "memristor_model": MemristorModel.LINEAR_ION_DRIFT.value,
        },
        ConstraintTier.EMERGENT.value: {
            "action": "ADVISE",
            "description": "Advisory - informational only",
            "log_level": "INFO",
            "can_continue": True,
            "memristor_model": MemristorModel.NONLINEAR_ION_DRIFT.value,
        },
    }


# =============================================================================
# Tier Transition Detection (NeurIPS 2024 AI Scientist-v2 inspired)
# =============================================================================


class TransitionType(Enum):
    """
    Type of tier transition for constraint evolution.

    CONSTRAINT LIFECYCLE: Constraints evolve through tiers based on usage patterns.

    Progression (typical):
        EMERGENT → LEARNED → ACTUAL
        (discovered)  (validated)  (enforced)

    Regression (rare):
        LEARNED → EMERGENT (decay due to disuse)
        ACTUAL → LEARNED (explicit governance override only)
    """
    CRYSTALLIZE = "crystallize"   # Emergent → Learned: Pattern has proven consistent
    HARDEN = "harden"             # Learned → Actual: Pattern is now mandatory
    DECAY = "decay"               # Learned → Emergent: Pattern fell out of use
    SOFTEN = "soften"             # Actual → Learned: Governance explicitly relaxed


@dataclass
class TransitionEvent:
    """
    Event emitted when a constraint changes tier.

    AUDIT TRAIL: Every tier transition is logged for compliance and debugging.
    This provides a complete history of how constraints evolved, enabling:
    1. Regulatory audits ("why is this constraint enforced?")
    2. Root cause analysis ("when did this become mandatory?")
    3. Trend analysis ("which emergent patterns are crystallizing?")

    Attributes
    ----------
    constraint_name : str
        Name of the constraint that transitioned
    from_tier : ConstraintTier
        Previous tier (where it was)
    to_tier : ConstraintTier
        New tier (where it's going)
    transition_type : TransitionType
        Type of transition (CRYSTALLIZE, HARDEN, DECAY, SOFTEN)
    trigger_count : int
        Number of signals that triggered the transition
    timestamp : float
        Unix timestamp of transition (for ordering and time-based queries)
    reason : str
        Human-readable explanation (for audit logs and debugging)
    """
    constraint_name: str
    from_tier: ConstraintTier
    to_tier: ConstraintTier
    transition_type: TransitionType
    trigger_count: int
    timestamp: float
    reason: str

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary for serialization."""
        return {
            "constraint_name": self.constraint_name,
            "from_tier": self.from_tier.value,
            "to_tier": self.to_tier.value,
            "transition_type": self.transition_type.value,
            "trigger_count": self.trigger_count,
            "timestamp": self.timestamp,
            "reason": self.reason,
        }


class TierTransitionDetector:
    """
    Detects when constraints should change tier based on signal history.

    ANALOGY: Like a credit score system for constraints:
    - Consistent positive signals raise the "score" (crystallization)
    - Severe violations escalate severity (hardening)
    - Inactivity lowers the "score" (decay)

    THRESHOLDS (configurable):
    - CRYSTALLIZE (Emergent→Learned): 20+ activations with >70% consistency
      "This pattern keeps appearing reliably - promote to learned"

    - HARDEN (Learned→Actual): 50+ high-severity violations
      "Violations of this pattern cause serious problems - make it mandatory"

    - DECAY (Learned→Emergent): <5 activations in 30 days
      "Nobody's using this constraint anymore - demote back to emergent"

    WHY AI SCIENTIST-v2 INSPIRED: Progressive experimentation teaches us that
    hypotheses (emergent constraints) should be promoted to conclusions (learned)
    and eventually to axioms (actual) based on evidence accumulation.

    Example
    -------
    >>> detector = TierTransitionDetector()
    >>> constraint = TieredConstraint("budget_limit", ConstraintTier.EMERGENT, 0.5)
    >>> # Simulate 25 consistent signals
    >>> for _ in range(25):
    ...     detector.record_signal("budget_limit", 0.8)
    >>> event = detector.check_transition(constraint)
    >>> event.transition_type
    TransitionType.CRYSTALLIZE
    """

    # TRANSITION THRESHOLDS - tune these based on your domain requirements
    CRYSTALLIZE_COUNT: int = 20        # Minimum signals to consider crystallization
    CRYSTALLIZE_CONSISTENCY: float = 0.7  # 70%+ of signals must be positive (>0.5)
    HARDEN_COUNT: int = 50             # High-severity violations to trigger hardening
    DECAY_WINDOW_DAYS: int = 30        # Time window for decay detection
    DECAY_MIN_COUNT: int = 5           # Below this count = inactive constraint

    def __init__(
        self,
        crystallize_count: int = 20,
        crystallize_consistency: float = 0.7,
        harden_count: int = 50,
        decay_window_days: int = 30,
        decay_min_count: int = 5,
    ):
        """
        Initialize detector with configurable thresholds.

        Args:
            crystallize_count: Minimum signals to consider crystallization
            crystallize_consistency: Required consistency ratio (0-1)
            harden_count: High-severity violations to trigger hardening
            decay_window_days: Time window for decay detection
            decay_min_count: Below this count = inactive constraint
        """
        self.CRYSTALLIZE_COUNT = crystallize_count
        self.CRYSTALLIZE_CONSISTENCY = crystallize_consistency
        self.HARDEN_COUNT = harden_count
        self.DECAY_WINDOW_DAYS = decay_window_days
        self.DECAY_MIN_COUNT = decay_min_count

        # Signal history: constraint_name → list of (timestamp, signal_value)
        self.signal_history: Dict[str, List[tuple]] = {}

        # Transition history: complete audit trail of all tier changes
        self.transition_history: List[TransitionEvent] = []

    def record_signal(self, constraint_name: str, value: float) -> None:
        """
        Record a signal for a constraint.

        Called whenever the constraint is activated/evaluated.
        Signal value interpretation:
        - value > 0.8: High severity (violation or strong activation)
        - value > 0.5: Positive activation
        - value <= 0.5: Weak or negative signal

        Args:
            constraint_name: Name of the constraint
            value: Signal value (0-1)
        """
        if constraint_name not in self.signal_history:
            self.signal_history[constraint_name] = []
        self.signal_history[constraint_name].append((time.time(), value))

    def check_transition(
        self,
        constraint: TieredConstraint,
    ) -> Optional[TransitionEvent]:
        """
        Check if constraint should transition to a different tier.

        ALGORITHM:
        1. Get signal history for the constraint
        2. Based on current tier, check applicable transition conditions
        3. If threshold met, create TransitionEvent and log it
        4. Return event (or None if no transition)

        Args:
            constraint: Constraint to check (must have .name and .tier attributes)

        Returns:
            TransitionEvent if tier should change, None otherwise
        """
        name = constraint.name
        current_tier = constraint.tier
        signals = self.signal_history.get(name, [])

        # No signals = no transition possible
        if not signals:
            return None

        now = time.time()

        # ═══════════════════════════════════════════════════════════════════
        # CHECK CRYSTALLIZATION: Emergent → Learned
        # "Has this pattern proven itself consistent enough to promote?"
        # ═══════════════════════════════════════════════════════════════════
        if current_tier == ConstraintTier.EMERGENT:
            if len(signals) >= self.CRYSTALLIZE_COUNT:
                # Compute consistency over most recent signals
                values = [v for _, v in signals[-self.CRYSTALLIZE_COUNT:]]
                consistency = sum(1 for v in values if v > 0.5) / len(values)

                if consistency >= self.CRYSTALLIZE_CONSISTENCY:
                    event = TransitionEvent(
                        constraint_name=name,
                        from_tier=ConstraintTier.EMERGENT,
                        to_tier=ConstraintTier.LEARNED,
                        transition_type=TransitionType.CRYSTALLIZE,
                        trigger_count=len(signals),
                        timestamp=now,
                        reason=f"Activated {len(signals)} times with {consistency:.0%} consistency"
                    )
                    self.transition_history.append(event)
                    return event

        # ═══════════════════════════════════════════════════════════════════
        # CHECK HARDENING or DECAY for LEARNED constraints
        # ═══════════════════════════════════════════════════════════════════
        elif current_tier == ConstraintTier.LEARNED:
            # COUNT HIGH-SEVERITY VIOLATIONS (signal > 0.8)
            violations = sum(1 for _, v in signals if v > 0.8)

            if violations >= self.HARDEN_COUNT:
                event = TransitionEvent(
                    constraint_name=name,
                    from_tier=ConstraintTier.LEARNED,
                    to_tier=ConstraintTier.ACTUAL,
                    transition_type=TransitionType.HARDEN,
                    trigger_count=violations,
                    timestamp=now,
                    reason=f"{violations} high-severity violations detected"
                )
                self.transition_history.append(event)
                return event

            # CHECK FOR DECAY: Has the constraint gone dormant?
            window_start = now - (self.DECAY_WINDOW_DAYS * 24 * 3600)
            recent_signals = [s for s in signals if s[0] > window_start]

            if len(recent_signals) < self.DECAY_MIN_COUNT and len(signals) > 0:
                event = TransitionEvent(
                    constraint_name=name,
                    from_tier=ConstraintTier.LEARNED,
                    to_tier=ConstraintTier.EMERGENT,
                    transition_type=TransitionType.DECAY,
                    trigger_count=len(recent_signals),
                    timestamp=now,
                    reason=f"Only {len(recent_signals)} activations in last {self.DECAY_WINDOW_DAYS} days"
                )
                self.transition_history.append(event)
                return event

        return None

    def get_transition_history(self, limit: int = 100) -> List[TransitionEvent]:
        """
        Get recent transition events for audit/debugging.

        Args:
            limit: Maximum events to return

        Returns:
            Most recent transitions in chronological order
        """
        return self.transition_history[-limit:]

    def get_signal_count(self, constraint_name: str) -> int:
        """Get number of recorded signals for a constraint."""
        return len(self.signal_history.get(constraint_name, []))

    def clear_history(self, constraint_name: Optional[str] = None) -> None:
        """
        Clear signal history.

        Args:
            constraint_name: Specific constraint to clear, or None for all
        """
        if constraint_name:
            self.signal_history.pop(constraint_name, None)
        else:
            self.signal_history.clear()


def detect_tier_transition(
    constraint: TieredConstraint,
    signal_history: List[tuple],
    crystallize_count: int = 20,
    crystallize_consistency: float = 0.7,
    harden_count: int = 50,
) -> Optional[TransitionEvent]:
    """
    Convenience function for one-shot tier transition detection.

    Args:
        constraint: Constraint to check
        signal_history: List of (timestamp, value) tuples
        crystallize_count: Minimum signals for crystallization
        crystallize_consistency: Required consistency ratio
        harden_count: High-severity violations for hardening

    Returns:
        TransitionEvent if transition should occur, None otherwise
    """
    detector = TierTransitionDetector(
        crystallize_count=crystallize_count,
        crystallize_consistency=crystallize_consistency,
        harden_count=harden_count,
    )
    detector.signal_history[constraint.name] = signal_history
    return detector.check_transition(constraint)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "ConstraintTier",
    "ViolationSeverity",
    "MemristorModel",
    "TransitionType",

    # Dataclasses
    "TieredConstraint",
    "ConstraintViolation",
    "ConstraintCheckResult",
    "TransitionEvent",

    # Manager
    "ConstraintTaxonomy",
    "TierTransitionDetector",

    # Constants
    "TIER_TO_MEMRISTOR",

    # Convenience functions
    "create_yrsn_taxonomy",
    "check_yrsn_constraints",
    "check_yrsn_constraints_phase_aware",
    "get_tier_enforcement_rules",
    "detect_tier_transition",
]
