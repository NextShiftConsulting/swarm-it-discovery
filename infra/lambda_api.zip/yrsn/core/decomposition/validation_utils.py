"""
Validation Utilities for YRSN Experiments

This module provides defensive checks to catch common wiring mistakes in experiments.
Import and call these functions at the start of experiments to fail fast with clear errors.

Usage:
    from yrsn.core.decomposition.validation_utils import (
        validate_projection_mode,
        validate_theta_source,
        warn_proxy_theta,
    )

    # At experiment start
    validate_projection_mode(projection, requires_theta=True)

    # When computing theta
    theta = result.get('sample_theta')
    validate_theta_source(theta, result.get('N'), experiment_name="expS4_048")
"""

import warnings
import numpy as np
from typing import Any, Dict, Optional

# Track warnings to avoid spam
_warned_issues = set()


def validate_projection_mode(
    projection,
    requires_theta: bool = False,
    requires_scale: bool = False,
    experiment_name: str = "unknown",
) -> None:
    """
    Validate that projection mode matches experiment requirements.

    Args:
        projection: TrainedRSNProjection instance
        requires_theta: If True, fail if projection doesn't provide theta
        requires_scale: If True, fail if projection doesn't provide scale
        experiment_name: Name of calling experiment (for error messages)

    Raises:
        ValueError: If projection mode doesn't match requirements
    """
    mode = getattr(projection, 'projection_mode', 'unknown')

    if requires_theta and mode == "mlp":
        raise ValueError(
            f"\n{'='*70}\n"
            f"❌ EXPERIMENT WIRING ERROR: {experiment_name}\n"
            f"{'='*70}\n"
            f"This experiment requires geometric outputs (theta, sample_theta)\n"
            f"but is using MLP projection which doesn't provide them.\n"
            f"\n"
            f"Current: projection_mode='{mode}'\n"
            f"Required: projection_mode='rotor'\n"
            f"\n"
            f"Fix:\n"
            f"  Use rotor checkpoint: --checkpoint checkpoints/trained_rotor_<dim>.pt\n"
            f"  Or modify experiment to not require theta\n"
            f"{'='*70}\n"
        )

    if requires_scale and mode == "mlp":
        raise ValueError(
            f"\n{'='*70}\n"
            f"❌ EXPERIMENT WIRING ERROR: {experiment_name}\n"
            f"{'='*70}\n"
            f"This experiment requires geometric outputs (scale, sample_radius)\n"
            f"but is using MLP projection which doesn't provide them.\n"
            f"\n"
            f"Fix: Use rotor checkpoint\n"
            f"{'='*70}\n"
        )

    # Log the mode for debugging
    print(f"  [validation] projection_mode={mode}, requires_theta={requires_theta}")


def validate_theta_source(
    theta: Optional[float],
    N: Optional[float],
    experiment_name: str = "unknown",
    tolerance: float = 0.01,
) -> None:
    """
    Check if theta appears to be derived from N (proxy formula).

    The proxy formula `theta = -30 * (N - 0.33)` creates fake theta that is
    perfectly correlated with N. This is a common wiring mistake.

    Args:
        theta: The theta value being used
        N: The N value from the same sample
        experiment_name: Name of calling experiment
        tolerance: Tolerance for detecting proxy relationship

    Warns:
        If theta appears to be derived from N
    """
    if theta is None or N is None:
        return

    # Check if theta matches the common proxy formula
    proxy_theta = -30.0 * (N - 0.33)
    if abs(theta - proxy_theta) < tolerance:
        key = f"{experiment_name}_proxy_theta"
        if key not in _warned_issues:
            warnings.warn(
                f"\n{'='*70}\n"
                f"⚠️  PROXY THETA DETECTED: {experiment_name}\n"
                f"{'='*70}\n"
                f"theta={theta:.4f} matches proxy formula -30*(N-0.33)={proxy_theta:.4f}\n"
                f"\n"
                f"This means theta is DERIVED from N, not computed geometrically!\n"
                f"Results testing theta vs N correlation will be meaningless.\n"
                f"\n"
                f"Fix:\n"
                f"  - Use result.get('sample_theta') from rotor projection\n"
                f"  - NOT: theta = -30 * (N - 0.33)\n"
                f"{'='*70}\n",
                UserWarning,
                stacklevel=2
            )
            _warned_issues.add(key)


def warn_proxy_theta(experiment_name: str = "unknown") -> None:
    """
    Emit a warning that proxy theta is being used.

    Call this when you detect code is using the proxy formula.
    """
    key = f"{experiment_name}_proxy_theta_explicit"
    if key not in _warned_issues:
        warnings.warn(
            f"\n{'='*70}\n"
            f"⚠️  PROXY THETA FORMULA DETECTED: {experiment_name}\n"
            f"{'='*70}\n"
            f"Code is using: theta = -30 * (N - 0.33)\n"
            f"\n"
            f"This creates FAKE theta perfectly correlated with N.\n"
            f"Any theta-based hypothesis testing will be invalid.\n"
            f"\n"
            f"Fix:\n"
            f"  1. Use rotor checkpoint (e.g., trained_rotor_<dim>.pt)\n"
            f"  2. Get real theta: result.get('sample_theta')\n"
            f"  3. Never compute theta from N!\n"
            f"{'='*70}\n",
            UserWarning,
            stacklevel=2
        )
        _warned_issues.add(key)


def validate_theta_variance(
    theta_values: np.ndarray,
    experiment_name: str = "unknown",
    min_variance: float = 0.01,
) -> bool:
    """
    Check if theta values have meaningful variance.

    If all theta values are nearly identical, it suggests using global theta
    instead of per-sample theta.

    Args:
        theta_values: Array of theta values
        experiment_name: Name of calling experiment
        min_variance: Minimum expected variance in degrees

    Returns:
        True if variance is acceptable, False if suspiciously low

    Warns:
        If variance is too low
    """
    if theta_values is None or len(theta_values) == 0:
        return True

    variance = np.var(theta_values)
    theta_range = np.max(theta_values) - np.min(theta_values)

    if variance < min_variance and theta_range < 0.1:
        key = f"{experiment_name}_theta_variance"
        if key not in _warned_issues:
            warnings.warn(
                f"\n{'='*70}\n"
                f"⚠️  CONSTANT THETA DETECTED: {experiment_name}\n"
                f"{'='*70}\n"
                f"theta range: [{np.min(theta_values):.4f}, {np.max(theta_values):.4f}]\n"
                f"theta variance: {variance:.6f}\n"
                f"\n"
                f"All theta values are nearly IDENTICAL!\n"
                f"This suggests using GLOBAL theta instead of per-sample theta.\n"
                f"\n"
                f"Common causes:\n"
                f"  - Using out['theta'] (global learned parameter)\n"
                f"  - Should use out['sample_theta'] (per-sample geometric angle)\n"
                f"\n"
                f"Fix:\n"
                f"  WRONG: theta = out['theta']  # Same for all samples!\n"
                f"  RIGHT: theta = out['sample_theta']  # Varies per sample\n"
                f"{'='*70}\n",
                UserWarning,
                stacklevel=2
            )
            _warned_issues.add(key)
            return False

    return True


def validate_signal_independence(
    signal_a: np.ndarray,
    signal_b: np.ndarray,
    signal_a_name: str,
    signal_b_name: str,
    experiment_name: str = "unknown",
    max_correlation: float = 0.99,
) -> bool:
    """
    Check if two signals are suspiciously perfectly correlated.

    Perfect correlation (|r| > 0.99) suggests the signals are derived from
    each other rather than being independent measurements.

    Args:
        signal_a, signal_b: The two signals to compare
        signal_a_name, signal_b_name: Names for error messages
        experiment_name: Name of calling experiment
        max_correlation: Maximum acceptable correlation

    Returns:
        True if signals appear independent, False if suspiciously correlated

    Warns:
        If signals appear perfectly correlated
    """
    if signal_a is None or signal_b is None:
        return True

    if len(signal_a) != len(signal_b) or len(signal_a) < 3:
        return True

    corr = np.corrcoef(signal_a, signal_b)[0, 1]

    if abs(corr) > max_correlation:
        key = f"{experiment_name}_{signal_a_name}_{signal_b_name}_correlation"
        if key not in _warned_issues:
            warnings.warn(
                f"\n{'='*70}\n"
                f"⚠️  PERFECT CORRELATION DETECTED: {experiment_name}\n"
                f"{'='*70}\n"
                f"r({signal_a_name}, {signal_b_name}) = {corr:.6f}\n"
                f"\n"
                f"These signals are almost perfectly correlated!\n"
                f"This suggests they are derived from each other, not independent.\n"
                f"\n"
                f"Common causes:\n"
                f"  - theta derived from N: theta = -30 * (N - 0.33)\n"
                f"  - omega derived from N: omega = 1 - N\n"
                f"  - Using same underlying data with different names\n"
                f"\n"
                f"Testing 'complementarity' of perfectly correlated signals is meaningless.\n"
                f"{'='*70}\n",
                UserWarning,
                stacklevel=2
            )
            _warned_issues.add(key)
            return False

    return True


def diagnose_experiment_wiring(
    projection,
    sample_result: Dict[str, Any],
    experiment_name: str = "unknown",
) -> Dict[str, Any]:
    """
    Run comprehensive diagnostics on experiment wiring.

    Call this at experiment start to identify potential issues.

    Args:
        projection: TrainedRSNProjection instance
        sample_result: Result from compute_rsn() on one sample
        experiment_name: Name of calling experiment

    Returns:
        Dict with diagnostic information
    """
    diagnostics = {
        'experiment': experiment_name,
        'projection_mode': getattr(projection, 'projection_mode', 'unknown'),
        'issues': [],
        'warnings': [],
    }

    # Check projection mode
    mode = diagnostics['projection_mode']

    # Check if geometric outputs are available
    has_theta = 'theta' in sample_result and sample_result['theta'] is not None
    has_sample_theta = 'sample_theta' in sample_result and sample_result['sample_theta'] is not None
    has_scale = 'scale' in sample_result and sample_result['scale'] is not None

    diagnostics['has_theta'] = has_theta
    diagnostics['has_sample_theta'] = has_sample_theta
    diagnostics['has_scale'] = has_scale

    if mode == "mlp":
        diagnostics['warnings'].append(
            "MLP mode: theta/scale not available. Use rotor checkpoint for geometric outputs."
        )

    if mode == "rotor" and not has_sample_theta:
        diagnostics['issues'].append(
            "ROTOR mode but sample_theta not in result - check model output"
        )

    # Print summary
    print(f"\n{'='*50}")
    print(f"WIRING DIAGNOSTICS: {experiment_name}")
    print(f"{'='*50}")
    print(f"  projection_mode: {mode}")
    print(f"  has_theta (global): {has_theta}")
    print(f"  has_sample_theta (per-sample): {has_sample_theta}")
    print(f"  has_scale: {has_scale}")

    if diagnostics['warnings']:
        print(f"\n  WARNINGS:")
        for w in diagnostics['warnings']:
            print(f"    - {w}")

    if diagnostics['issues']:
        print(f"\n  ISSUES:")
        for i in diagnostics['issues']:
            print(f"    - {i}")

    print(f"{'='*50}\n")

    return diagnostics
