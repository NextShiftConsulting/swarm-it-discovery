"""
κ Policy Framework - Tiered Risk Management for Geometric Compatibility

TERMINOLOGY FIX (2026-02-11):
-----------------------------
This module was renamed from omega_policy.py to kappa_policy.py for clarity.

In YRSN:
- κ (kappa) = Representation-solver compatibility = D*/D (RSCT theory)
- ω (omega) = Reliability coefficient from latent variance (OOD detection)

These are DIFFERENT signals. The previous naming used ω for compatibility,
which conflicted with certificate.omega. This rename aligns with RSCT paper.

WHAT THIS MODULE DOES:
---------------------
κ is the geometric firewall between perception and reasoning.
When encoding doesn't match solver, everything struggles.

This module implements tiered κ policies that control WHAT YOU DO when κ is
low or ambiguous - without changing WHAT κ MEANS.

ARCHITECTURE:
------------
                    ┌─────────────────────────────────────────┐
                    │           Policy Resolution             │
                    │                                         │
                    │  (consumer_tier, env_tier) → κ_level   │
                    │                                         │
                    │  κ_level + κ_value → action            │
                    └─────────────────────────────────────────┘

CONSUMER TIERS:
--------------
- Tier A (Safety-Critical): Compliance, approvals, irreversible actions
- Tier B (Business-Critical): Analyst workflows, batch reporting
- Tier C (Exploratory): Research sandbox, prototyping, demos
- Tier D (Physical): Memristor, neuromorphic, analog hardware

ENVIRONMENT TIERS:
-----------------
- Env 1 (Stable): Controlled inputs, predictable distributions
- Env 2 (Variable): New domains, shifting data, inconsistent formatting
- Env 3 (Hostile): Untrusted inputs, adversarial patterns, frequent drift

κ POLICY LEVELS:
---------------
- κ-L0 (Minimal): κ₀ only, no hard gate, heavy logging
- κ-L1 (Adaptive): κ₀ gate + borderline refinement + alternate encoding
- κ-L2 (Strict): Full checks + safe fallback ladder + audits
- κ-L3 (Physical): Hardware-mandatory gating, no fallback after commit

THEORY ALIGNMENT:
----------------
From "Intelligence as Representation-Solver Compatibility" (RSCT paper):
    κ(E, S) = D*/D = representation-solver compatibility

For software solvers: κ measures "will this work well?"
For physical solvers: κ measures "can this exist stably on hardware?"
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Callable, Any, Tuple
import json
from pathlib import Path


# =============================================================================
# Enums: Consumer Tiers, Environment Tiers, Policy Levels
# =============================================================================

class ConsumerTier(Enum):
    """Risk classification for consumers/tenants."""
    A = "safety_critical"    # Compliance, approvals, irreversible
    B = "business_critical"  # Analyst workflows, batch reporting
    C = "exploratory"        # Research, prototyping, demos
    D = "physical"           # Memristor, neuromorphic, analog hardware


class EnvironmentTier(Enum):
    """Stability classification for execution environments."""
    STABLE = 1    # Controlled inputs, predictable distributions
    VARIABLE = 2  # New domains, shifting data, inconsistent formatting
    HOSTILE = 3   # Untrusted inputs, adversarial patterns, drift


class KappaLevel(Enum):
    """κ policy strictness levels."""
    L0_MINIMAL = 0   # κ₀ only, no hard gate, heavy logging
    L1_ADAPTIVE = 1  # κ₀ gate + borderline refinement + alternate encoding
    L2_STRICT = 2    # Full checks + safe fallback ladder + audits
    L3_PHYSICAL = 3  # Hardware-mandatory gating, no fallback after commit


# Backwards compatibility alias
OmegaLevel = KappaLevel


class FallbackAction(Enum):
    """Actions in the fallback ladder."""
    PROCEED = auto()           # κ high enough, proceed normally
    RE_ENCODE = auto()         # Canonicalize / alternative encoding view
    SWITCH_GEAR = auto()       # Lower-risk inference mode
    SWITCH_BACKEND = auto()    # Symbolic / brute force / constrained
    RETURN_PRIOR = auto()      # Return prior + explanation
    QUARANTINE = auto()        # Flag for human review
    SIMULATE_FIRST = auto()    # Digital twin before hardware (Tier D)
    REJECT = auto()            # Hard rejection, do not proceed


# =============================================================================
# Threshold Configuration
# =============================================================================

@dataclass
class KappaThresholds:
    """
    κ thresholds for a specific policy level.

    T_low: Below this, hard fallback (unless L0)
    T_high: Above this, proceed normally
    Borderline [T_low, T_high]: Triggers refinement/re-encode
    """
    t_low: float
    t_high: float

    def classify(self, kappa: float) -> str:
        """Classify κ into low/borderline/high."""
        if kappa < self.t_low:
            return "low"
        elif kappa >= self.t_high:
            return "high"
        else:
            return "borderline"


# Backwards compatibility alias
OmegaThresholds = KappaThresholds

# Default thresholds per consumer tier
DEFAULT_THRESHOLDS: Dict[ConsumerTier, KappaThresholds] = {
    ConsumerTier.A: KappaThresholds(t_low=0.35, t_high=0.70),  # Strict
    ConsumerTier.B: KappaThresholds(t_low=0.25, t_high=0.60),  # Balanced
    ConsumerTier.C: KappaThresholds(t_low=0.15, t_high=0.50),  # Permissive
    ConsumerTier.D: KappaThresholds(t_low=0.40, t_high=0.75),  # Hardware-strict
}


# =============================================================================
# Policy Configuration
# =============================================================================

@dataclass
class KappaPolicy:
    """
    Complete κ policy for a consumer×environment combination.

    This determines:
    - Which κ signals to compute (κ₀, κ₁, κ₂, κ₃, κ₄)
    - What thresholds to use
    - What actions to take at each κ level
    - What to log

    TERMINOLOGY:
    - κ (kappa) = representation-solver compatibility
    - This is DIFFERENT from ω (omega) = reliability coefficient
    """
    name: str
    consumer_tier: ConsumerTier
    environment_tier: EnvironmentTier
    kappa_level: KappaLevel
    thresholds: KappaThresholds

    # Which κ signals to compute
    compute_mahalanobis: bool = True      # κ₁ - always on
    compute_norm: bool = True              # κ₃ - always on
    compute_templates: bool = False        # κ₂ - L1+
    compute_cka: bool = False              # κ₄ - L2+ borderline only

    # Fallback behavior
    fallback_ladder: List[FallbackAction] = field(default_factory=list)
    require_human_review_below: Optional[float] = None

    # Logging
    log_full_decomposition: bool = True
    log_raw_embeddings: bool = False
    sample_rate: float = 1.0  # 1.0 = log all, 0.1 = sample 10%

    # Hardware-specific (Tier D)
    simulate_before_commit: bool = False
    hardware_gate_mandatory: bool = False

    # Backwards compatibility property
    @property
    def omega_level(self) -> KappaLevel:
        """Backwards compatibility: omega_level -> kappa_level."""
        return self.kappa_level

    def get_action(self, kappa: float, kappa_decomposition: Dict[str, float]) -> FallbackAction:
        """
        Determine action based on κ value.

        Args:
            kappa: Combined κ value [0, 1]
            kappa_decomposition: Individual κ signals for debugging

        Returns:
            FallbackAction to take
        """
        classification = self.thresholds.classify(kappa)

        if classification == "high":
            return FallbackAction.PROCEED

        elif classification == "borderline":
            # For borderline, try re-encoding first
            if FallbackAction.RE_ENCODE in self.fallback_ladder:
                return FallbackAction.RE_ENCODE
            elif FallbackAction.SWITCH_GEAR in self.fallback_ladder:
                return FallbackAction.SWITCH_GEAR
            else:
                return FallbackAction.PROCEED  # L0 behavior

        else:  # low
            if self.kappa_level == KappaLevel.L0_MINIMAL:
                # L0: Log but proceed (permissive)
                return FallbackAction.PROCEED

            elif self.kappa_level == KappaLevel.L3_PHYSICAL:
                # Physical: Hard reject, never proceed with bad κ
                return FallbackAction.REJECT

            else:
                # L1/L2: Walk the fallback ladder
                if self.require_human_review_below and kappa < self.require_human_review_below:
                    return FallbackAction.QUARANTINE

                # Return first available fallback
                for action in self.fallback_ladder:
                    if action not in [FallbackAction.PROCEED]:
                        return action

                return FallbackAction.RETURN_PRIOR

    def to_dict(self) -> Dict[str, Any]:
        """Serialize policy to dict for config files."""
        return {
            "name": self.name,
            "consumer_tier": self.consumer_tier.value,
            "environment_tier": self.environment_tier.value,
            "kappa_level": self.kappa_level.name,
            "thresholds": {
                "t_low": self.thresholds.t_low,
                "t_high": self.thresholds.t_high,
            },
            "compute": {
                "mahalanobis": self.compute_mahalanobis,
                "norm": self.compute_norm,
                "templates": self.compute_templates,
                "cka": self.compute_cka,
            },
            "fallback_ladder": [a.name for a in self.fallback_ladder],
            "logging": {
                "full_decomposition": self.log_full_decomposition,
                "raw_embeddings": self.log_raw_embeddings,
                "sample_rate": self.sample_rate,
            },
            "hardware": {
                "simulate_before_commit": self.simulate_before_commit,
                "gate_mandatory": self.hardware_gate_mandatory,
            },
        }


# Backwards compatibility alias
OmegaPolicy = KappaPolicy


# =============================================================================
# Policy Factory: The Matrix
# =============================================================================

def create_default_policy(
    consumer_tier: ConsumerTier,
    environment_tier: EnvironmentTier,
) -> KappaPolicy:
    """
    Create default policy based on consumer×environment matrix.

    Matrix:
    -------
    Tier A (Safety-Critical):
        Env 1: κ-L2
        Env 2: κ-L2 + quarantine for low-κ
        Env 3: κ-L2 + always require alternate encoding OR human review

    Tier B (Business-Critical):
        Env 1: κ-L1
        Env 2: κ-L1 + tighter drift monitor
        Env 3: κ-L2-lite (strict gating, fewer expensive checks)

    Tier C (Exploratory):
        Env 1: κ-L0
        Env 2: κ-L0 + sampling audits
        Env 3: κ-L1 (avoid wasting compute, keep permissive)

    Tier D (Physical):
        All Envs: κ-L3 (mandatory hardware gating)
    """
    thresholds = DEFAULT_THRESHOLDS[consumer_tier]

    # Standard fallback ladder
    standard_ladder = [
        FallbackAction.RE_ENCODE,
        FallbackAction.SWITCH_GEAR,
        FallbackAction.SWITCH_BACKEND,
        FallbackAction.RETURN_PRIOR,
        FallbackAction.QUARANTINE,
    ]

    # Hardware fallback ladder (Tier D)
    hardware_ladder = [
        FallbackAction.RE_ENCODE,
        FallbackAction.SIMULATE_FIRST,
        FallbackAction.SWITCH_BACKEND,  # Fall back to digital
        FallbackAction.REJECT,
    ]

    # Tier D: Physical solvers - always κ-L3
    if consumer_tier == ConsumerTier.D:
        return KappaPolicy(
            name=f"physical_{environment_tier.name.lower()}",
            consumer_tier=consumer_tier,
            environment_tier=environment_tier,
            kappa_level=KappaLevel.L3_PHYSICAL,
            thresholds=thresholds,
            compute_mahalanobis=True,
            compute_norm=True,
            compute_templates=True,  # Always check known-stable patterns
            compute_cka=True,        # Full alignment check for hardware
            fallback_ladder=hardware_ladder,
            require_human_review_below=None,  # No human review - just reject
            log_full_decomposition=True,
            log_raw_embeddings=True,  # Keep for hardware debugging
            sample_rate=1.0,
            simulate_before_commit=True,
            hardware_gate_mandatory=True,
        )

    # Tier A: Safety-Critical
    if consumer_tier == ConsumerTier.A:
        if environment_tier == EnvironmentTier.STABLE:
            return KappaPolicy(
                name="safety_critical_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L2_STRICT,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return KappaPolicy(
                name="safety_critical_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L2_STRICT,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                require_human_review_below=0.25,  # Quarantine very low κ
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        else:  # HOSTILE
            return KappaPolicy(
                name="safety_critical_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L2_STRICT,
                thresholds=KappaThresholds(t_low=0.40, t_high=0.75),  # Tighter
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                require_human_review_below=0.60,  # Human review unless high κ
                log_full_decomposition=True,
                log_raw_embeddings=True,
                sample_rate=1.0,
            )

    # Tier B: Business-Critical
    if consumer_tier == ConsumerTier.B:
        if environment_tier == EnvironmentTier.STABLE:
            return KappaPolicy(
                name="business_critical_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,  # No CKA for L1
                fallback_ladder=standard_ladder[:3],  # Shorter ladder
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return KappaPolicy(
                name="business_critical_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,
                fallback_ladder=standard_ladder[:4],
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        else:  # HOSTILE
            # L2-lite: strict gating but fewer expensive checks
            return KappaPolicy(
                name="business_critical_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L2_STRICT,
                thresholds=KappaThresholds(t_low=0.30, t_high=0.65),
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,  # Skip CKA for cost
                fallback_ladder=standard_ladder,
                log_full_decomposition=True,
                sample_rate=1.0,
            )

    # Tier C: Exploratory
    if consumer_tier == ConsumerTier.C:
        if environment_tier == EnvironmentTier.STABLE:
            return KappaPolicy(
                name="exploratory_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L0_MINIMAL,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=False,
                compute_cka=False,
                fallback_ladder=[],  # No fallback, just log
                log_full_decomposition=True,
                sample_rate=1.0,  # Log everything for learning
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return KappaPolicy(
                name="exploratory_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L0_MINIMAL,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=False,
                compute_cka=False,
                fallback_ladder=[],
                log_full_decomposition=True,
                sample_rate=0.1,  # Sample to avoid storage blowup
            )
        else:  # HOSTILE
            # Upgrade to L1 to avoid wasting compute
            return KappaPolicy(
                name="exploratory_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                kappa_level=KappaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,
                fallback_ladder=standard_ladder[:2],
                log_full_decomposition=True,
                sample_rate=0.1,
            )

    # Fallback: L1 Adaptive
    return KappaPolicy(
        name="default",
        consumer_tier=consumer_tier,
        environment_tier=environment_tier,
        kappa_level=KappaLevel.L1_ADAPTIVE,
        thresholds=thresholds,
        compute_mahalanobis=True,
        compute_norm=True,
        compute_templates=True,
        compute_cka=False,
        fallback_ladder=standard_ladder[:3],
        log_full_decomposition=True,
        sample_rate=1.0,
    )


# =============================================================================
# Policy Registry
# =============================================================================

class KappaPolicyRegistry:
    """
    Registry for named κ policies.

    Policies can be:
    - Created from consumer×environment matrix (default)
    - Loaded from config file
    - Registered programmatically
    """

    def __init__(self):
        self._policies: Dict[str, KappaPolicy] = {}
        self._tenant_mapping: Dict[str, str] = {}

    def register(self, policy: KappaPolicy):
        """Register a policy by name."""
        self._policies[policy.name] = policy

    def get(self, name: str) -> KappaPolicy:
        """Get policy by name."""
        if name not in self._policies:
            raise KeyError(f"Policy '{name}' not found")
        return self._policies[name]

    def get_for_tenant(self, tenant_id: str) -> KappaPolicy:
        """Get policy for a specific tenant."""
        if tenant_id not in self._tenant_mapping:
            return create_default_policy(ConsumerTier.B, EnvironmentTier.STABLE)
        return self.get(self._tenant_mapping[tenant_id])

    def map_tenant(self, tenant_id: str, policy_name: str):
        """Map a tenant to a policy."""
        if policy_name not in self._policies:
            raise KeyError(f"Policy '{policy_name}' not found")
        self._tenant_mapping[tenant_id] = policy_name

    def create_default_policies(self):
        """Create and register all default matrix policies."""
        for consumer in ConsumerTier:
            for env in EnvironmentTier:
                policy = create_default_policy(consumer, env)
                self.register(policy)


# Backwards compatibility alias
OmegaPolicyRegistry = KappaPolicyRegistry


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    # Enums
    'ConsumerTier',
    'EnvironmentTier',
    'KappaLevel',
    'FallbackAction',
    # Classes (new names)
    'KappaThresholds',
    'KappaPolicy',
    'KappaPolicyRegistry',
    # Functions
    'create_default_policy',
    # Constants
    'DEFAULT_THRESHOLDS',
    # Backwards compatibility aliases
    'OmegaLevel',
    'OmegaThresholds',
    'OmegaPolicy',
    'OmegaPolicyRegistry',
]


if __name__ == "__main__":
    print("=" * 80)
    print("κ POLICY FRAMEWORK")
    print("=" * 80)
    print()
    print("TERMINOLOGY:")
    print("  κ (kappa) = representation-solver compatibility = D*/D")
    print("  ω (omega) = reliability coefficient (different signal!)")
    print()

    # Demo policy
    policy = create_default_policy(ConsumerTier.A, EnvironmentTier.HOSTILE)
    print(f"Policy: {policy.name}")
    print(f"  Level: {policy.kappa_level.name}")
    print(f"  Thresholds: low={policy.thresholds.t_low}, high={policy.thresholds.t_high}")

    for kappa in [0.2, 0.5, 0.8]:
        action = policy.get_action(kappa, {})
        print(f"  κ={kappa:.1f} → {action.name}")
