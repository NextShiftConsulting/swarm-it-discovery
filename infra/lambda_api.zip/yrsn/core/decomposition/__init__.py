"""
YRSN Core Decomposition Module
==============================

Y = R + S + N mathematical decomposition framework.

This module provides algorithms for decomposing content into:
- R (Relevant): Information that directly contributes to task performance
- S (Superfluous): Neutral information that neither helps nor hurts
- N (Noise): Information that actively degrades performance

Decomposition Methods:
- Heuristic: Keyword/pattern-based decomposition (fast)
- Semantic: Embedding-based decomposition (accurate)
- Robust PCA: Matrix decomposition (L + S + N)
- Neural: Learned projection heads (trainable)

Key Types:
- DecompositionScore: R/S/N ratios with Y-score
- DecompositionResult: Full decomposition output
- DecomposerConfig: Configuration for decomposition

Key Functions:
- decompose(): Main decomposition function
- decompose_matrix(): Robust PCA for matrices
- decompose_semantic(): Embedding-based decomposition
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple, Union
from enum import Enum
import math
import warnings
import numpy as np


class DecompositionMethod(str, Enum):
    """Available decomposition methods."""

    HEURISTIC = "heuristic"  # Keyword/pattern-based (fast)
    SEMANTIC = "semantic"  # Embedding-based (requires embeddings)
    ROBUST_PCA = "robust_pca"  # Matrix decomposition
    NEURAL = "neural"  # Learned projection heads


@dataclass
class DecompositionScore:
    """
    Represents R+S+N+ε decomposition of content.

    The fundamental unit of quality measurement in YRSN.

    This is a CERTIFICATE - a structured, constrained, verifiable attestation
    of semantic quality. The certificate satisfies the simplex invariant
    R+S+N=1 and provides typed semantics for downstream consumers.

    Certificate Properties:
        1. Constrained: R + S + N = 1 (simplex invariant)
        2. Verifiable: is_valid checks invariant satisfaction
        3. Decomposed: Explains WHY quality is low (high N vs high S)
        4. Semantic: Components have defined meanings

    Decomposition Model:
        Y_observed = R + S + N + ε
        where ε is reconstruction error (minimized during decomposition)

    Attributes:
        relevant: R - Core systematic content (0.0-1.0)
        superfluous: S - Marginally systematic content (0.0-1.0)
        noise: N - True noise/errors (0.0-1.0)
        epsilon: ε - Reconstruction error, unexplained signal (≥0)
        computation_method: How the decomposition was computed
        certificate_version: Version for compatibility tracking
    """

    relevant: float  # R: Core systematic content
    superfluous: float  # S: Marginally systematic
    noise: float  # N: True noise/errors
    epsilon: float = 0.0  # ε: Reconstruction error (unexplained signal)
    omega: float = 1.0  # ω: Reliability coefficient (1.0 = in-distribution)
    quality_prior: float = 0.5  # Prior for α_ω blending when OOD
    computation_method: str = "heuristic"  # How computed: "heuristic", "learned", "hybrid", "vae"
    computation_time_ms: float = 0.0  # Computation time in milliseconds (v2.7+)
    certificate_version: str = "1.0"  # Certificate format version

    # Geometric parameters (optional, only populated for rotor projection mode)
    theta: Optional[float] = None  # Rotation angle in degrees (rotor mode only)
    scale: Optional[float] = None  # Scale parameter (rotor mode only)
    projection_mode: str = "mlp"  # "mlp" (default) or "rotor"

    # T⁴ coordinates (optional, computed from R, S, N)
    # Note: Naming distinction - rotor's theta is different from simplex_theta
    t4_simplex_theta: Optional[float] = None  # Angular position on simplex [0, 360)
    t4_phi_simplex: Optional[float] = None    # Distance from simplex center [0, 360)
    t4_alpha: Optional[float] = None          # Quality as angle [0, 180) (different from raw alpha property)
    t4_omega: Optional[float] = None          # OOD confidence from boundary [0, 90]° (different from reliability omega)
                                              # Mathematical constraint: omega = arccos(φ) only produces [0°, 90°]
                                              # See geometric_utils.compute_omega() for formula

    @property
    def R(self) -> float:
        """Alias for relevant."""
        return self.relevant

    @property
    def S(self) -> float:
        """Alias for superfluous."""
        return self.superfluous

    @property
    def N(self) -> float:
        """Alias for noise."""
        return self.noise

    @property
    def eps(self) -> float:
        """Alias for epsilon (reconstruction error)."""
        return self.epsilon

    @property
    def total(self) -> float:
        """Total of explained components (should sum to 1.0 after normalization)."""
        return self.relevant + self.superfluous + self.noise

    @property
    def total_observed(self) -> float:
        """Total observed signal: R + S + N + ε."""
        return self.relevant + self.superfluous + self.noise + self.epsilon

    @property
    def alpha(self) -> float:
        """Raw quality score alpha = R / (R + S + N). WARNING: Can be misleading for OOD."""
        total = self.total
        return self.relevant / total if total > 0 else 0.0

    @property
    def alpha_omega(self) -> float:
        """Reliability-adjusted quality α_ω = ω×α + (1-ω)×prior. USE THIS for decisions."""
        return self.omega * self.alpha + (1 - self.omega) * self.quality_prior

    @property
    def y_score(self) -> float:
        """Y score - overall relevance metric: Y = R + 0.5*S."""
        return self.relevant + (0.5 * self.superfluous)

    @property
    def risk_score(self) -> float:
        """Collapse risk: S + 1.5*N."""
        return self.superfluous + (1.5 * self.noise)

    @property
    def tau(self) -> float:
        """Temperature tau = 1 / α_ω (reliability-adjusted, NOT raw alpha)."""
        alpha_omega = self.alpha_omega
        return 1.0 / max(alpha_omega, 0.01)

    @property
    def is_valid(self) -> bool:
        """
        Verify the certificate satisfies the simplex constraint.

        A valid certificate has R + S + N ≈ 1.0 (within tolerance).
        This enables downstream consumers to verify certificate integrity.

        Returns:
            True if |R + S + N - 1| < 0.001
        """
        return abs(self.total - 1.0) < 0.001

    @property
    def constraint_violation(self) -> float:
        """
        Measure how far the certificate violates the simplex constraint.

        Returns:
            |R + S + N - 1| (0.0 = perfectly valid)
        """
        return abs(self.total - 1.0)

    def normalize(self) -> "DecompositionScore":
        """
        Normalize explained components (R, S, N) to sum to 1.0.

        Note: epsilon is preserved as-is since it represents the
        unexplained portion of the signal that couldn't be decomposed.
        After normalization: R + S + N = 1.0, epsilon unchanged.

        This ensures the certificate satisfies the simplex constraint,
        making is_valid return True.
        """
        total = self.total
        if total == 0:
            return DecompositionScore(
                0.33, 0.33, 0.34,
                epsilon=self.epsilon,
                omega=self.omega,
                quality_prior=self.quality_prior,
                computation_method=self.computation_method,
                certificate_version=self.certificate_version,
                theta=self.theta,
                scale=self.scale,
                projection_mode=self.projection_mode,
            )

        return DecompositionScore(
            relevant=self.relevant / total,
            superfluous=self.superfluous / total,
            noise=self.noise / total,
            epsilon=self.epsilon,  # Preserve reconstruction error
            omega=self.omega,
            quality_prior=self.quality_prior,
            computation_method=self.computation_method,
            certificate_version=self.certificate_version,
            theta=self.theta,
            scale=self.scale,
            projection_mode=self.projection_mode,
        )

    def to_tuple(self) -> Tuple[float, float, float]:
        """Return as (R, S, N) tuple (backward compatible)."""
        return (self.relevant, self.superfluous, self.noise)

    def to_tuple_full(self) -> Tuple[float, float, float, float]:
        """Return as (R, S, N, ε) tuple with reconstruction error."""
        return (self.relevant, self.superfluous, self.noise, self.epsilon)

    @property
    def t4_coordinates(self) -> Optional[Dict[str, float]]:
        """Get T⁴ coordinates if populated."""
        if self.t4_simplex_theta is None:
            return None
        return {
            'simplex_theta': self.t4_simplex_theta,
            'phi_simplex': self.t4_phi_simplex,
            'alpha_t4': self.t4_alpha,  # T⁴ angle in degrees, not certificate scalar
            'omega_t4': self.t4_omega,  # T⁴ angle in degrees, not certificate scalar
        }

    def t4_distance_to(self, other: 'DecompositionScore') -> Optional[float]:
        """
        Compute topological distance to another model state using T⁴ manifold geometry.

        This is the VALIDATED production distance metric (expS5_001d) that proved
        135% more discriminative than Euclidean distance (99 vs 42 H1 loops).

        Essential for:
        - Drift detection: Monitor model state changes over time
        - Model clustering: Group models by behavioral similarity
        - Anomaly detection: Flag states far from reference distribution
        - Context management: Track topological proximity in state space

        WHY THIS MATTERS:
        ----------------
        Using Euclidean distance on (R,S,N) treats values near boundaries as "far apart"
        when they're actually adjacent on the periodic manifold:

        Example (WRONG - Euclidean):
            Model A: R=0.01, S=0.49, N=0.50 → distance = large
            Model B: R=0.99, S=0.00, N=0.01 → (they're actually neighbors!)

        Example (CORRECT - Chordal on T⁴):
            Same models → distance = small (recognizes periodic wrap-around)

        Args:
            other: Another DecompositionScore to compare against

        Returns:
            Chordal distance (float >= 0) or None if T⁴ coordinates not populated

        Example:
            >>> # Track model drift during inference
            >>> baseline_score = projection.compute_rsn(baseline_embedding, return_t4=True)
            >>> current_score = projection.compute_rsn(current_embedding, return_t4=True)
            >>> drift = baseline_score.t4_distance_to(current_score)
            >>>
            >>> if drift > 0.5:
            ...     print("WARNING: Significant state change detected!")
            ...     # Trigger model recalibration, alert operator, etc.

        Validation:
            series_005/expS5_001d_final_validation.py
            Proved chordal distance is 135% more discriminative than Euclidean

        Reference:
            docs/SME_REVIEW_T4_INFERENCE.md
            CIP #1: T⁴ Parameterization
        """
        if self.t4_coordinates is None or other.t4_coordinates is None:
            return None

        from .geometric_utils import t4_chordal_distance
        return t4_chordal_distance(self.t4_coordinates, other.t4_coordinates)

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        result = {
            "R": self.relevant,
            "S": self.superfluous,
            "N": self.noise,
            "epsilon": self.epsilon,
            "alpha": self.alpha,
            "y_score": self.y_score,
            "risk_score": self.risk_score,
            "tau": self.tau,
            "projection_mode": self.projection_mode,
        }
        # Include geometric params if rotor mode
        if self.theta is not None:
            result["theta"] = self.theta
        if self.scale is not None:
            result["scale"] = self.scale
        # Include T⁴ coordinates if present
        if self.t4_coordinates is not None:
            result["t4_coordinates"] = self.t4_coordinates
        return result


@dataclass
class DecomposerConfig:
    """
    Configuration for decomposition.

    The decomposition method is CONFIGURABLE - heuristic, learned, and hybrid
    methods are all valid embodiments of the certificate computation.
    The novelty lies in the certificate structure (R/S/N on simplex with
    alpha-omega conjunction), not in the specific estimation technique.

    Attributes:
        method: Primary decomposition method to use
        normalize: Whether to normalize R+S+N to sum to 1.0
        min_content_length: Minimum content length to decompose
        semantic_threshold: Threshold for semantic similarity
        fallback_to_heuristic: If learned/hybrid fails, fall back to heuristic
        log_computation_method: Track which method produced the certificate
        validate_certificate: Check R+S+N=1 invariant on output
    """

    method: DecompositionMethod = DecompositionMethod.HEURISTIC
    normalize: bool = True
    min_content_length: int = 10
    semantic_threshold: float = 0.5
    fallback_to_heuristic: bool = True  # Fall back to heuristic if learned fails
    log_computation_method: bool = True  # Track computation method in output
    validate_certificate: bool = True  # Verify R+S+N=1 constraint


class HeuristicDecomposer:
    """
    Keyword/pattern-based decomposition.

    Fast heuristic approach that uses keyword matching and
    structural analysis to estimate R/S/N ratios.

    Supports multiple domains:
    - "academic": Text/document analysis (default)
    - "robotics": Robot manipulation instructions
    """

    # ==========================================================================
    # Academic/Text Domain (default)
    # ==========================================================================
    RELEVANT_KEYWORDS = [
        "mathematical",
        "decomposition",
        "signal",
        "separation",
        "systematic",
        "analysis",
        "model",
        "algorithm",
        "method",
        "approach",
        "result",
        "solution",
    ]

    SUPERFLUOUS_KEYWORDS = [
        "background",
        "introduction",
        "related",
        "survey",
        "overview",
        "context",
        "general",
        "previous",
        "history",
        "literature",
    ]

    NOISE_KEYWORDS = [
        "error",
        "unclear",
        "formatting",
        "broken",
        "missing",
        "incomplete",
        "typo",
        "advertisement",
    ]

    # ==========================================================================
    # Robotics Domain - for VLA instruction quality
    # ==========================================================================
    ROBOTICS_RELEVANT_KEYWORDS = [
        # Actions
        "pick", "place", "grasp", "grip", "grab", "lift", "lower", "move",
        "push", "pull", "rotate", "turn", "open", "close", "press", "release",
        "insert", "remove", "stack", "pour", "slide", "reach", "hold", "drop",
        # Objects (colors + shapes)
        "red", "blue", "green", "yellow", "white", "black", "orange", "purple",
        "block", "cube", "ball", "sphere", "cup", "bowl", "plate", "box",
        "bottle", "can", "container", "object", "item", "handle", "lid", "button",
        # Spatial terms
        "left", "right", "up", "down", "above", "below", "top", "bottom",
        "front", "back", "forward", "backward", "center", "middle", "corner",
        "near", "far", "next", "beside", "between", "inside", "outside", "onto",
        # Quantifiers
        "slowly", "carefully", "gently", "quickly", "precisely", "exactly",
        # Measurements
        "cm", "mm", "inch", "degrees", "90", "180", "45",
    ]

    ROBOTICS_SUPERFLUOUS_KEYWORDS = [
        # Unnecessary qualifiers
        "please", "kindly", "maybe", "perhaps", "possibly", "probably",
        "i think", "i guess", "sort of", "kind of", "like",
        # Verbose phrases
        "if you could", "would you mind", "i want you to", "can you",
    ]

    ROBOTICS_NOISE_KEYWORDS = [
        # Vague terms (high noise = low quality instruction)
        "something", "stuff", "thing", "things", "whatever", "anything",
        "somewhere", "somehow", "some", "any", "idk", "dunno",
        # Incomplete
        "the", "a", "it", "that", "this",  # alone = incomplete
        # Nonsense detection (single chars, random)
        "asdf", "qwer", "xyz", "abc", "test", "foo", "bar",
        # Dangerous ambiguity
        "fast", "hard", "strong",  # without context = dangerous
    ]

    def _detect_domain(self, query: str) -> str:
        """Detect domain from query string."""
        query_lower = query.lower()
        robotics_indicators = [
            "robot", "manipulation", "vla", "gripper", "arm", "action",
            "pick", "place", "grasp", "move", "instruction",
        ]
        if any(ind in query_lower for ind in robotics_indicators):
            return "robotics"
        return "academic"

    def decompose(
        self, content: str, query: str = "", config: Optional[DecomposerConfig] = None
    ) -> DecompositionScore:
        """
        Decompose content using heuristics.

        Args:
            content: Text content to decompose
            query: Optional query for relevance scoring (also used for domain detection)
            config: Decomposer configuration

        Returns:
            DecompositionScore with R, S, N values
        """
        config = config or DecomposerConfig()

        # Handle empty/very short content
        if len(content) < config.min_content_length:
            # Short content in robotics = incomplete instruction = high noise
            domain = self._detect_domain(query)
            if domain == "robotics":
                return DecompositionScore(0.1, 0.2, 0.7)  # Bad instruction
            return DecompositionScore(0.5, 0.3, 0.2)

        text = content.lower()
        words = text.split()
        word_count = len(words)

        # Detect domain and select keyword sets
        domain = self._detect_domain(query)

        if domain == "robotics":
            relevant_kw = self.ROBOTICS_RELEVANT_KEYWORDS
            superfluous_kw = self.ROBOTICS_SUPERFLUOUS_KEYWORDS
            noise_kw = self.ROBOTICS_NOISE_KEYWORDS
        else:
            relevant_kw = self.RELEVANT_KEYWORDS
            superfluous_kw = self.SUPERFLUOUS_KEYWORDS
            noise_kw = self.NOISE_KEYWORDS

        # Count keyword matches
        r_matches = sum(1 for kw in relevant_kw if kw in text)
        s_matches = sum(1 for kw in superfluous_kw if kw in text)
        n_matches = sum(1 for kw in noise_kw if kw in text)

        # Special handling for robotics instructions
        if domain == "robotics":
            # Penalize very short instructions (< 3 words)
            if word_count < 3:
                n_matches += 3  # Significantly increase noise

            # Penalize single-word instructions heavily
            if word_count == 1:
                n_matches += 5

            # Check for instruction completeness
            # Good instruction has: action + object OR action + direction
            has_action = any(kw in text for kw in [
                "pick", "place", "grasp", "grab", "lift", "move", "push", "pull",
                "rotate", "turn", "open", "close", "press", "release", "drop",
            ])
            has_object = any(kw in text for kw in [
                "block", "cube", "ball", "cup", "bowl", "box", "bottle", "object",
                "red", "blue", "green", "yellow", "button", "handle", "lid",
            ])
            has_direction = any(kw in text for kw in [
                "left", "right", "up", "down", "forward", "backward", "onto",
            ])

            # Complete instruction bonus
            if has_action and (has_object or has_direction):
                r_matches += 3  # Bonus for complete instruction

            # Action without target = incomplete
            if has_action and not has_object and not has_direction:
                n_matches += 2

        # Query relevance boost
        query_boost = 0.0
        if query:
            query_terms = query.lower().split()
            query_matches = sum(1 for term in query_terms if term in text)
            query_boost = query_matches / max(len(query_terms), 1) * 0.3

        # Base scores with domain-specific weighting
        if domain == "robotics":
            # Robotics: more weight on r_matches, higher penalty for noise
            base_r = 0.2 + (r_matches * 0.08) + query_boost
            base_s = 0.15 + (s_matches * 0.03)
            base_n = 0.05 + (n_matches * 0.12)  # Higher noise penalty
        else:
            # Academic: original weighting
            base_r = 0.3 + (r_matches * 0.05) + query_boost
            base_s = 0.2 + (s_matches * 0.04)
            base_n = 0.1 + (n_matches * 0.06)

        # Content structure analysis
        sentence_count = content.count(".") + content.count("!") + content.count("?")

        if sentence_count > 0:
            avg_sentence_length = word_count / sentence_count
            # Very long sentences may indicate noise
            if avg_sentence_length > 50:
                base_n += 0.1
            elif avg_sentence_length < 5:
                base_n += 0.05

        # Ensure reasonable bounds
        r_score = max(0.1, min(0.9, base_r))
        s_score = max(0.05, min(0.6, base_s))
        n_score = max(0.02, min(0.5, base_n))

        score = DecompositionScore(
            r_score, s_score, n_score,
            computation_method="heuristic",
            certificate_version="1.0",
        )

        if config.normalize:
            score = score.normalize()

        # Validate certificate if configured
        if config.validate_certificate and not score.is_valid:
            # This should not happen after normalization, but check anyway
            score = score.normalize()

        return score


# =============================================================================
# Type Detection and Auto-Selection (v2.7+)
# =============================================================================

def _detect_input_type(content: Union[str, np.ndarray]) -> str:
    """
    Detect input type for auto-method selection.

    Returns:
        "text", "matrix", "embedding", or "embedding_batch"
    """
    if isinstance(content, str):
        return "text"

    if isinstance(content, np.ndarray):
        if content.ndim == 1:
            return "embedding"  # Single vector
        elif content.ndim == 2:
            # Disambiguate matrix vs embedding batch
            # Heuristic: if more columns than rows, likely embeddings
            # (embeddings usually 768-1024 dims, matrices vary)
            if content.shape[1] > content.shape[0]:
                return "embedding_batch"
            else:
                return "matrix"
        else:
            return "matrix"  # 3D+ tensor → matrix (will be unfolded)

    raise TypeError(f"Unsupported input type: {type(content)}")


def _auto_select_method(input_type: str, method: str) -> str:
    """
    Auto-select method based on input type if method="auto".

    Args:
        input_type: Detected input type
        method: User-specified method or "auto"

    Returns:
        Resolved method name
    """
    if method != "auto":
        return method

    # Auto-detection
    if input_type == "text":
        return "heuristic"
    elif input_type == "matrix":
        return "robust_pca"
    elif input_type in ("embedding", "embedding_batch"):
        return "neural"

    return "heuristic"  # Fallback


# Module-level cache for loaded neural projections
_PROJECTION_CACHE: Dict[str, Any] = {}


def clear_projection_cache():
    """Clear cached neural projections to free memory."""
    global _PROJECTION_CACHE
    _PROJECTION_CACHE.clear()


# =============================================================================
# Method-Specific Decomposition Helpers (v2.7+)
# =============================================================================

def _decompose_with_rpca(
    matrix: np.ndarray,
    lambda_s: Optional[float] = None,
    max_iter: int = 1000,
) -> DecompositionScore:
    """
    Decompose matrix using Robust PCA (M = L + S + N).

    Args:
        matrix: Input matrix to decompose
        lambda_s: Sparsity penalty (auto-tuned if None)
        max_iter: Maximum iterations for optimization

    Returns:
        DecompositionScore with R/S/N from low-rank/sparse/noise components
    """
    import time
    from .pca import robust_pca

    start_time = time.perf_counter()

    # Call robust_pca
    result = robust_pca(
        matrix,
        method="ialm",  # Default to IALM (fastest)
        lambda_s=lambda_s,
        max_iter=max_iter
    )

    # Convert to YRSN ratios
    R, S, N = result.to_yrsn()

    computation_time = (time.perf_counter() - start_time) * 1000  # ms

    # Build DecompositionScore
    return DecompositionScore(
        relevant=R,
        superfluous=S,
        noise=N,
        epsilon=abs(R + S + N - 1.0),
        computation_method="robust_pca",
        computation_time_ms=computation_time,
    )


def _decompose_with_neural(
    embedding: np.ndarray,
    checkpoint_path: str,
) -> DecompositionScore:
    """
    Decompose embedding using trained neural projection.

    Uses module-level cache to avoid reloading checkpoints.

    Args:
        embedding: Input embedding vector(s)
        checkpoint_path: Path to trained projection checkpoint

    Returns:
        DecompositionScore with R/S/N from neural projection
    """
    import time
    from .trained_projection import TrainedRSNProjection
    from pathlib import Path

    start_time = time.perf_counter()

    # Check cache
    cache_key = str(Path(checkpoint_path).resolve())
    if cache_key not in _PROJECTION_CACHE:
        # Load and cache projection
        if not Path(checkpoint_path).exists():
            raise FileNotFoundError(
                f"Checkpoint not found: {checkpoint_path}\n"
                f"Ensure the path is correct and checkpoint exists."
            )
        _PROJECTION_CACHE[cache_key] = TrainedRSNProjection.from_checkpoint(
            checkpoint_path
        )

    projection = _PROJECTION_CACHE[cache_key]

    # Compute R/S/N
    result = projection.compute_rsn(embedding, return_t4=True)

    computation_time = (time.perf_counter() - start_time) * 1000  # ms

    # Extract T⁴ coordinates if available
    t4_coords = result.get('t4_coordinates', {})

    # Build DecompositionScore
    return DecompositionScore(
        relevant=result['R'],
        superfluous=result['S'],
        noise=result['N'],
        epsilon=abs(result['R'] + result['S'] + result['N'] - 1.0),
        computation_method="neural",
        computation_time_ms=computation_time,
        t4_simplex_theta=t4_coords.get('simplex_theta'),
        t4_phi_simplex=t4_coords.get('phi_simplex'),
        t4_alpha=t4_coords.get('alpha'),
        t4_omega=t4_coords.get('omega'),
    )


def _text_to_embedding(text: str, model_name: str) -> np.ndarray:
    """
    Convert text to embedding using sentence-transformers.

    Args:
        text: Input text to encode
        model_name: Model identifier (e.g., 'all-MiniLM-L6-v2')

    Returns:
        Embedding vector as numpy array

    Raises:
        ImportError: If sentence-transformers not installed
    """
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise ImportError(
            "neural method with text input requires sentence-transformers.\n"
            "Install: pip install sentence-transformers"
        )

    # Cache model in _PROJECTION_CACHE (reuse for multiple calls)
    cache_key = f"embedding_model:{model_name}"
    if cache_key not in _PROJECTION_CACHE:
        _PROJECTION_CACHE[cache_key] = SentenceTransformer(model_name)

    model = _PROJECTION_CACHE[cache_key]
    embedding = model.encode(text)

    return np.array(embedding)


def decompose(
    content: Union[str, np.ndarray],
    query: str = "",
    method: str = "auto",
    config: Optional[DecomposerConfig] = None,
    # Robust PCA params
    lambda_s: Optional[float] = None,
    max_iter: int = 1000,
    # Neural params
    checkpoint_path: Optional[str] = None,
    embedding_model: Optional[str] = None,
) -> DecompositionScore:
    """
    Decompose content into R+S+N using specified method.

    Supports text, matrix, and embedding inputs with automatic type detection.

    Args:
        content: Input to decompose
            - str: Text content (uses heuristic or embedding-based)
            - np.ndarray [N, M]: Matrix (uses robust_pca)
            - np.ndarray [D]: Single embedding vector (uses neural)
            - np.ndarray [N, D]: Batch of embeddings (uses neural)

        query: Optional query string (only used for heuristic text method)

        method: Decomposition method
            - "auto": Auto-detect from content type (recommended)
            - "heuristic": Text-based keyword matching
            - "robust_pca": Matrix decomposition (requires matrix input)
            - "neural": Neural projection (requires embeddings or embedding_model)

        config: Optional heuristic configuration

        lambda_s: Sparsity penalty for robust_pca (auto-tuned if None)
        max_iter: Maximum iterations for robust_pca (default: 1000)

        checkpoint_path: Path to trained projection for neural method
        embedding_model: Model name for text→embedding conversion

    Returns:
        DecompositionScore with R, S, N ratios and derived metrics

    Examples:
        # Text decomposition (auto-detects heuristic)
        >>> score = decompose("Mathematical analysis of signal processing")
        >>> print(f"R={score.R:.2f}, S={score.S:.2f}, N={score.N:.2f}")

        # Matrix decomposition (auto-detects robust_pca)
        >>> matrix = np.random.randn(100, 50)
        >>> score = decompose(matrix, method="auto")

        # Embedding decomposition (neural)
        >>> score = decompose(
        ...     embedding,
        ...     method="neural",
        ...     checkpoint_path="checkpoints/trained.pt"
        ... )
    """
    # Type detection
    input_type = _detect_input_type(content)
    resolved_method = _auto_select_method(input_type, method)

    # Dispatch to appropriate decomposer
    if resolved_method == "heuristic":
        if not isinstance(content, str):
            raise ValueError(
                f"Heuristic method requires text input, got {type(content)}"
            )
        decomposer = HeuristicDecomposer()
        return decomposer.decompose(content, query, config)

    elif resolved_method == "robust_pca":
        if not isinstance(content, np.ndarray):
            raise ValueError(
                f"robust_pca method requires matrix input, got {type(content)}"
            )
        return _decompose_with_rpca(
            content,
            lambda_s=lambda_s,
            max_iter=max_iter
        )

    elif resolved_method == "neural":
        if isinstance(content, str):
            # Convert text to embedding
            if embedding_model is None:
                raise ValueError(
                    "neural method with text input requires embedding_model parameter"
                )
            content = _text_to_embedding(content, embedding_model)

        if checkpoint_path is None:
            raise ValueError(
                "neural method requires checkpoint_path parameter"
            )

        return _decompose_with_neural(
            content,
            checkpoint_path=checkpoint_path
        )

    elif resolved_method == "semantic":
        # Future: semantic method (not implemented yet)
        warnings.warn(
            "Semantic method not yet implemented, falling back to heuristic",
            UserWarning
        )
        if not isinstance(content, str):
            raise ValueError("Semantic fallback requires text input")
        decomposer = HeuristicDecomposer()
        return decomposer.decompose(content, query, config)

    else:
        raise ValueError(f"Unknown method: {resolved_method}")


def compute_yrsn(
    content: str, query: str = "", backend: str = "heuristic"
) -> Tuple[float, float, float]:
    """
    Compute Y=R+S+N decomposition.

    Convenience function returning (R, S, N) tuple.

    Args:
        content: Text content to analyze
        query: Optional query for relevance scoring
        backend: Decomposition backend

    Returns:
        Tuple of (R, S, N) values
    """
    score = decompose(content, query, method=backend)
    return score.to_tuple()


# =============================================================================
# Convenience Functions (v2.7+)
# =============================================================================

def decompose_matrix(
    matrix: np.ndarray,
    method: str = "ialm",
    lambda_s: Optional[float] = None,
    max_iter: int = 1000,
) -> DecompositionScore:
    """
    Decompose matrix using Robust PCA.

    Convenience wrapper for matrix decomposition.

    Args:
        matrix: Input matrix [N, M]
        method: RPCA algorithm ('ialm', 'pcp', 'godec')
        lambda_s: Sparsity penalty (auto-tuned if None)
        max_iter: Maximum iterations

    Returns:
        DecompositionScore with R/S/N from low-rank/sparse/noise

    Example:
        >>> import numpy as np
        >>> matrix = np.random.randn(100, 50)
        >>> score = decompose_matrix(matrix, method='ialm')
        >>> print(f"R={score.R:.2f}, S={score.S:.2f}, N={score.N:.2f}")
    """
    return decompose(matrix, method="robust_pca", lambda_s=lambda_s, max_iter=max_iter)


def decompose_embedding(
    embedding: np.ndarray,
    checkpoint_path: str,
) -> DecompositionScore:
    """
    Decompose embedding using trained neural projection.

    Convenience wrapper for embedding decomposition.

    Args:
        embedding: Input embedding vector(s)
        checkpoint_path: Path to trained projection checkpoint

    Returns:
        DecompositionScore with R/S/N from neural projection

    Example:
        >>> from sentence_transformers import SentenceTransformer
        >>> model = SentenceTransformer('all-MiniLM-L6-v2')
        >>> embedding = model.encode("Signal processing analysis")
        >>> score = decompose_embedding(
        ...     embedding,
        ...     checkpoint_path="checkpoints/trained.pt"
        ... )
        >>> print(f"Quality: {score.alpha:.2f}")
    """
    return decompose(
        embedding,
        method="neural",
        checkpoint_path=checkpoint_path
    )


# =============================================================================
# Reliability-Adjusted Quality (Claim 2)
# =============================================================================


def compute_alpha_omega(
    r: float,
    s: float,
    n: float,
    omega: float = 1.0,   # 1.0 = trust fully; lower = blend with prior
    prior: float = 0.5,   # 0.5 = neutral; adjust per domain if needed
) -> float:
    """
    Compute reliability-adjusted quality α_ω.

    QUICK START
    -----------
    >>> from yrsn.core import compute_alpha_omega
    >>>
    >>> # Basic usage - trust measurement fully
    >>> alpha_omega = compute_alpha_omega(r=0.7, s=0.2, n=0.1)
    >>> print(f"Quality: {alpha_omega:.2f}")  # 0.70
    >>>
    >>> # OOD adjustment - blend with prior
    >>> alpha_omega = compute_alpha_omega(r=0.7, s=0.2, n=0.1, omega=0.5)
    >>> print(f"Quality: {alpha_omega:.2f}")  # 0.60 (blended toward 0.5 prior)
    >>>
    >>> # Fully OOD - fall back to prior
    >>> alpha_omega = compute_alpha_omega(r=0.7, s=0.2, n=0.1, omega=0.0)
    >>> print(f"Quality: {alpha_omega:.2f}")  # 0.50 (prior)

    WHEN TO USE
    -----------
    - omega < 1.0 when:
        - Input is out-of-distribution (low ω from VGFA)
        - Source reliability is questionable
        - Want conservative estimates
    - prior != 0.5 when:
        - Domain has different baseline quality expectation
        - Adversarial domain: use lower prior (e.g., 0.3)
        - High-trust domain: use higher prior (e.g., 0.6)

    FORMULA
    -------
    α = R / (R + S + N)            -- raw quality
    α_ω = ω × α + (1 - ω) × prior  -- reliability-adjusted

    The reliability coefficient ω regresses α toward the prior:
    - ω = 1.0: In-distribution, trust α fully → α_ω = α
    - ω = 0.0: Out-of-distribution, distrust α → α_ω = prior
    - 0 < ω < 1: Partial trust → weighted blend

    This is TRANSFORMATION, not addition: the same input yields a
    DIFFERENT quality score based on distributional alignment.

    Args:
        r: Relevant signal (R)
        s: Superfluous signal (S)
        n: Noise (N)
        omega: Reliability coefficient from variance gating (0-1).
               Default 1.0 = trust measurement fully.
        prior: Prior quality estimate. Default 0.5 = neutral/uninformative.

    Returns:
        Reliability-adjusted quality α_ω in [0, 1]

    See Also:
        TauMode.GATED: Automatic ω-based fallback for temperature
        compute_tau_from_alpha_omega: Derive temperature from α_ω
    """
    total = r + s + n
    if total <= 0:
        alpha = prior  # No signal → fall back to prior
    else:
        alpha = r / total

    # Reliability adjustment (Claim 2 formula)
    alpha_omega = omega * alpha + (1 - omega) * prior

    return alpha_omega


def compute_quality_from_score(
    score: "DecompositionScore", omega: float = 1.0, prior: float = 0.5
) -> float:
    """
    Compute α_ω from a DecompositionScore.

    Convenience wrapper for compute_alpha_omega using score object.

    Args:
        score: DecompositionScore with R, S, N values
        omega: Reliability coefficient (default 1.0 = in-distribution)
        prior: Prior quality estimate (default 0.5)

    Returns:
        Reliability-adjusted quality α_ω
    """
    return compute_alpha_omega(
        score.relevant, score.superfluous, score.noise, omega, prior
    )


# Research Framework (paper analysis)
from .research_framework import (
    PaperAnalysis,
    ResearchFramework,
    analyze_context_collapse_types,
    extract_table_of_contents,
    extract_bibliography,
    get_demo_papers,
)

# Label Reading and False Label Generation
from .label_reader import (
    LabelReader,
    LabelData,
    LabelFormat,
    ValidationResult,
)

from .false_label_generator import (
    FalseLabelGenerator,
    NoiseConfig,
    NoiseType,
    CorruptionResult,
)

# Collapse Detection (measurement only - policy is in yrsn.policy)
from .collapse import (
    CollapseType,
    Severity,
    CollapseSignature,
    CollapseAnalysis,
    CollapseDetector,
    detect_collapse,
    detect_collapse_full,  # Full 16-type detection with geometric domain
    get_collapse_summary,
    detect_collapse_phase_aware,
    detect_collapse_with_frequency,
    # HiveMind Detection
    HiveMindAnalysis,
    HiveMindDetector,
    # Note: generate_with_r_boost moved to yrsn.policy (it's control, not measurement)
)

# Robust PCA
from .pca import (
    RPCAMethod,
    RPCAResult,
    RobustPCA,
    robust_pca,
    decompose_to_yrsn,
)

# Phase Transitions (BBP thresholds)
from .phase_transitions import (
    compute_bbp_threshold,
    compute_bbp_threshold_inverse,
    quality_supports_rank,
    get_rank_headroom,
    get_bbp_reference_table,
    BBPThresholdTable,
    PhaseTransitionDetector,
    TransitionType,
    TransitionEvent,
    RankRecommendation,
)

# Spectral Analysis (Marchenko-Pastur)
from .spectral_analysis import (
    EigenvalueSnapshot,
    MPValidationResult,
    SNRAnalysisResult,
    compute_mp_bounds,
    mp_density,
    EigenvalueTracker,
    MarchenkoPasturValidator,
    SignalNoiseAnalyzer,
    quick_spectral_analysis,
    estimate_quality_from_matrix,
)

# Adaptive Scaling (Pillar 2 Integration)
from .adaptive_scaling import (
    AdaptiveScalingConfig,
    AdaptiveState,
    AdaptiveResult,
    AdaptiveScalingManager,
    create_adaptive_manager,
    get_adaptive_temperature,
    get_adaptive_rank,
    quick_adaptive_analysis,
    analyze_matrix_adaptive,
)

# Calibration Manager (requires torch)
# These are conditionally exported based on torch availability
_calibration_exports = []
try:
    from .calibration_manager import (
        CalibrationState,
        CalibrationConfig,
        CalibrationMetrics,
        CalibrationManager,
        SupervisedCalibrationManager,
        create_calibrated_projections,
        create_supervised_calibration,
    )
    _calibration_exports = [
        "CalibrationState",
        "CalibrationConfig",
        "CalibrationMetrics",
        "CalibrationManager",
        "SupervisedCalibrationManager",
        "create_calibrated_projections",
        "create_supervised_calibration",
    ]
except ImportError:
    # torch not available - skip calibration manager
    pass

# Frequency-based RSN (self-supervised)
from .frequency_rsn import FrequencyBasedRSN

# Frequency-based Omega (TRUE pre-task 6D tuple)
from .frequency_omega import FrequencyBasedOmega, FrequencySignals, compute_frequency_6d

# Trained RSN Projection
from .trained_projection import TrainedRSNProjection, load_trained_projection, FitStrategy

# Hybrid Rotor Projection (geometric alternative)
from .hybrid_rotor import (
    HybridSimplexRotor,
    HybridSimplexRotorCompact,
    SimplexRotor,
    RotorVariant,
    RotorConfig,
    create_rotor,
    is_rotor_checkpoint,
    load_rotor_from_checkpoint,
)

# Entropy Metrics (expS5_215 - entropy-enhanced α)
from .entropy_metrics import (
    EntropyMetrics,
    compute_entropy_metrics_from_scalars,
    compute_entropy_metrics_from_vectors,
    compute_alpha_entropy,
    compute_alpha_confident,
    compute_entropy_metrics_batch,
    compute_alpha_entropy_batch,
)

# T⁴ Coordinate System (geometric utilities)
from .geometric_utils import (
    compute_simplex_theta,
    compute_phi_simplex,
    compute_alpha,
    compute_omega,
    compute_t4_coordinates,
    wrapped_angle_distance,
    geodesic_distance_t4,
    normalize_angle,
    # T⁴ Chordal Distance (Validated in expS5_001d)
    normalize_angles_to_2pi,
    t4_chordal_distance,
    # Pipeline coordinate functions (Series 005)
    compute_pipeline1_coords,
    compute_pipeline2_coords,
    compute_pipeline3_coords,
    compute_pipeline4_coords,
)

# RSN Labeler (training target generation)
from .rsn_labeler import (
    RSNLabeler,
    RSNTrainingTarget,
    RSNLabel,  # Deprecated alias
    LabelMode,
)

# Geometric Domain Classification (from EXP-S4-001) - now in collapse.py
from .collapse import (
    GeometricDomain,
    Severity as GeometricSeverity,  # Alias to avoid conflict with collapse.Severity
    ModelAlert,
    GeometricClassification,
    classify_geometric_domain,
    classify_severity as classify_geometric_severity,
    get_model_alerts,
    create_composite_label,
    classify_full as classify_geometric_full,
    get_expected_domain,
    EXPECTED_DOMAIN_BY_TYPE,
)

# RSN-First Monitoring (from expS4_000 discovery)
from .rsn_first_monitor import (
    RSNFirstMonitor,
    RSNAlert,
    RSNBaseline,
    compute_rsn_divergence,
    detect_rsn_drift,
)

# YRSN Fragility Monitor (from expS4_102c - hardware health)
from .fragility_monitor import (
    YRSNFragilityMonitor,
    FragilityDiagnosis,
)

# Comprehensive Collapse Detection (incorporates all S4 findings)
from .collapse import (
    # Enums
    CollapseDetector,
    CollapseAnalysis,
    CollapseType,
    GeometricDomain,
    Severity,
    SignalRole,
    HardwareAlertType,
    ModelAlert,
    # Classes - Core Detection
    RealTimeCollapseMonitor,
    MonitorStatus,
    # Classes - Configuration
    CollapseConfig,
    # Classes - Hardware Health
    HardwareHealthStatus,
    # Classes - HiveMind
    HiveMindAnalysis,
    HiveMindDetector,
    # Functions - Core
    detect_collapse,
    detect_collapse_phase_aware,
    get_signal_roles,
    get_domain_calibration,
    # Functions - Hardware Health
    classify_hardware_alert,
    get_hardware_alerts,
    get_model_alerts,
    get_expected_domain,
    # Functions - Visualization
    generate_constraint_mermaid,
    generate_constraint_graphviz,
    # Constants
    DOMAIN_CALIBRATION,
    SEVERITY_THRESHOLDS,
    TYPE_THETA_SIGNATURES,
    HARDWARE_SIGNATURES,
    HARDWARE_SEVERITY_SIGNALS,
    EXPECTED_DOMAIN_BY_TYPE,
)

__all__ = [
    # Enums
    "DecompositionMethod",
    # Classes
    "DecompositionScore",
    "DecomposerConfig",
    "HeuristicDecomposer",
    # Functions
    "decompose",
    "compute_yrsn",
    "decompose_matrix",      # v2.7+ convenience
    "decompose_embedding",   # v2.7+ convenience
    "clear_projection_cache",  # v2.7+ cache management
    # Reliability-Adjusted Quality (Claim 2)
    "compute_alpha_omega",
    "compute_quality_from_score",
    # Research Framework
    "PaperAnalysis",
    "ResearchFramework",
    "analyze_context_collapse_types",
    "extract_table_of_contents",
    "extract_bibliography",
    "get_demo_papers",
    # Collapse Detection (measurement only)
    "CollapseType",
    "Severity",
    "CollapseSignature",
    "CollapseAnalysis",
    "CollapseDetector",
    "detect_collapse",
    "detect_collapse_full",  # Full 16-type with geometric domain
    "get_collapse_summary",
    "detect_collapse_phase_aware",
    "detect_collapse_with_frequency",
    # HiveMind Detection (measurement only)
    "HiveMindAnalysis",
    "HiveMindDetector",
    # Note: generate_with_r_boost is in yrsn.policy (control, not measurement)
    # Robust PCA
    "RPCAMethod",
    "RPCAResult",
    "RobustPCA",
    "robust_pca",
    "decompose_to_yrsn",
    # Phase Transitions
    "compute_bbp_threshold",
    "compute_bbp_threshold_inverse",
    "quality_supports_rank",
    "get_rank_headroom",
    "get_bbp_reference_table",
    "BBPThresholdTable",
    "PhaseTransitionDetector",
    "TransitionType",
    "TransitionEvent",
    "RankRecommendation",
    # Spectral Analysis
    "EigenvalueSnapshot",
    "MPValidationResult",
    "SNRAnalysisResult",
    "compute_mp_bounds",
    "mp_density",
    "EigenvalueTracker",
    "MarchenkoPasturValidator",
    "SignalNoiseAnalyzer",
    "quick_spectral_analysis",
    "estimate_quality_from_matrix",
    # Adaptive Scaling
    "AdaptiveScalingConfig",
    "AdaptiveState",
    "AdaptiveResult",
    "AdaptiveScalingManager",
    "create_adaptive_manager",
    "get_adaptive_temperature",
    "get_adaptive_rank",
    "quick_adaptive_analysis",
    "analyze_matrix_adaptive",
    # Label Reading
    "LabelReader",
    "LabelData",
    "LabelFormat",
    "ValidationResult",
    # False Label Generation
    "FalseLabelGenerator",
    "NoiseConfig",
    "NoiseType",
    "CorruptionResult",
    # Frequency-based RSN
    "FrequencyBasedRSN",
    # Frequency-based Omega (TRUE pre-task 6D)
    "FrequencyBasedOmega",
    "FrequencySignals",
    "compute_frequency_6d",
    # Trained RSN Projection
    "TrainedRSNProjection",
    "load_trained_projection",
    "FitStrategy",
    # Hybrid Rotor Projection (geometric alternative)
    "HybridSimplexRotor",
    "HybridSimplexRotorCompact",
    "SimplexRotor",
    "RotorVariant",
    "RotorConfig",
    "create_rotor",
    "is_rotor_checkpoint",
    "load_rotor_from_checkpoint",
    # Entropy Metrics (expS5_215)
    "EntropyMetrics",
    "compute_entropy_metrics_from_scalars",
    "compute_entropy_metrics_from_vectors",
    "compute_alpha_entropy",
    "compute_alpha_confident",
    "compute_entropy_metrics_batch",
    "compute_alpha_entropy_batch",
    # T⁴ Coordinate System (geometric utilities)
    "compute_simplex_theta",
    "compute_phi_simplex",
    "compute_alpha",
    "compute_omega",
    "compute_t4_coordinates",
    "wrapped_angle_distance",
    "geodesic_distance_t4",
    "normalize_angle",
    # Pipeline coordinate functions (Series 005)
    "compute_pipeline1_coords",
    "compute_pipeline2_coords",
    "compute_pipeline3_coords",
    "compute_pipeline4_coords",
    # RSN Labeler (training target generation)
    "RSNLabeler",
    "RSNTrainingTarget",
    "RSNLabel",  # Deprecated alias for RSNTrainingTarget
    "LabelMode",
    # Geometric Domain Classification (from EXP-S4-001)
    "GeometricDomain",
    "GeometricSeverity",
    "ModelAlert",
    "GeometricClassification",
    "classify_geometric_domain",
    "classify_geometric_severity",
    "get_model_alerts",
    "create_composite_label",
    "classify_geometric_full",
    "get_expected_domain",
    "EXPECTED_DOMAIN_BY_TYPE",
    # RSN-First Monitoring (from expS4_000 discovery)
    "RSNFirstMonitor",
    "RSNAlert",
    "RSNBaseline",
    "compute_rsn_divergence",
    "detect_rsn_drift",
    # YRSN Fragility Monitor (from expS4_102c - hardware health)
    "YRSNFragilityMonitor",
    "FragilityDiagnosis",
    # Comprehensive Collapse Detection
    # Enums
    "CollapseDetector",
    "CollapseAnalysis",
    "CollapseType",
    "GeometricDomain",
    "Severity",
    "SignalRole",
    "HardwareAlertType",
    "ModelAlert",
    # Classes - Core Detection
    "RealTimeCollapseMonitor",
    "MonitorStatus",
    # Classes - Configuration
    "CollapseConfig",
    # Classes - Hardware Health
    "HardwareHealthStatus",
    # Classes - HiveMind
    "HiveMindAnalysis",
    "HiveMindDetector",
    # Functions - Core
    "detect_collapse",
    "detect_collapse_phase_aware",
    "get_signal_roles",
    "get_domain_calibration",
    # Functions - Hardware Health
    "classify_hardware_alert",
    "get_hardware_alerts",
    "get_model_alerts",
    "get_expected_domain",
    # Functions - Visualization
    "generate_constraint_mermaid",
    "generate_constraint_graphviz",
    # Constants
    "DOMAIN_CALIBRATION",
    "SEVERITY_THRESHOLDS",
    "TYPE_THETA_SIGNATURES",
    "HARDWARE_SIGNATURES",
    "HARDWARE_SEVERITY_SIGNALS",
    "EXPECTED_DOMAIN_BY_TYPE",
    # RSCT Integration (κ-guided curriculum)
    "compute_compositional_kappa",
    "compute_compositional_kappa_detailed",
    "CompositionResult",
    "DStarEstimate",
    "estimate_d_star",
    "KappaResult",
    "compute_kappa",
    "compute_kappa_from_result",
    "compute_kappa_priority",
    "RSCTQualitySignals",
    "RSCTController",
    "create_rsct_controller",
    # Kappa Simplex (Layer 2 diagnostics - Ghost #2 fix)
    "KappaSimplex",
    "compute_kappa_simplex",
    "compute_kappa_simplex_from_scalar",
    "diagnose_kappa_bottleneck",
] + _calibration_exports


# RSCT Integration (κ-guided curriculum) - Gap Analysis implementation
from .composition import (
    compute_compositional_kappa,
    compute_compositional_kappa_detailed,
    CompositionResult,
)
from .rsct_integration import (
    DStarEstimate,
    estimate_d_star,
    KappaResult,
    compute_kappa,
    compute_kappa_from_result,
    compute_kappa_priority,
    RSCTQualitySignals,
    RSCTController,
    create_rsct_controller,
)

# Kappa Simplex (Layer 2 diagnostics - Ghost #2 fix)
from .kappa_simplex import (
    KappaSimplex,
    compute_kappa_simplex,
    compute_kappa_simplex_from_scalar,
    diagnose_kappa_bottleneck,
)
