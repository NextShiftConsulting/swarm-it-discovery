"""
Semantic Labeling for R/S/N Components

This module provides human-interpretable semantic labels for R/S/N
decomposition results, enabling better understanding and debugging
of the decomposition quality.

Key features:
1. Semantic vocabulary for R/S/N categories
2. Clustering-based pattern discovery
3. Human-readable explanations
4. Integration with decomposition scores

Based on research synthesis:
- Interpretable ML techniques
- Clustering for pattern discovery
- Natural language explanations
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Set
from enum import Enum
import numpy as np
from collections import defaultdict

from .yrsn_decomposition import DecompositionScore


# =============================================================================
# Semantic Label Vocabulary
# =============================================================================

@dataclass
class SemanticLabel:
    """A semantic label with description and confidence."""
    category: str  # R, S, or N
    label: str  # Human-readable label
    description: str  # Detailed description
    confidence: float  # Confidence in this label
    evidence: List[str] = field(default_factory=list)  # Supporting evidence


class RSNSemanticVocabulary:
    """
    Vocabulary of semantic labels for R/S/N categories.

    Each category has a predefined set of labels that describe
    common patterns in context decomposition.
    """

    # Relevant (R) labels - content that directly contributes to the task
    R_LABELS = {
        'directly_answers_query': {
            'description': 'Content that directly answers or addresses the main query',
            'keywords': ['answer', 'solution', 'result', 'conclusion', 'finding'],
        },
        'provides_key_evidence': {
            'description': 'Content providing crucial evidence or data for reasoning',
            'keywords': ['evidence', 'data', 'proof', 'demonstration', 'example'],
        },
        'contains_core_concept': {
            'description': 'Content containing the core concept being discussed',
            'keywords': ['concept', 'definition', 'principle', 'theory', 'fundamental'],
        },
        'essential_context': {
            'description': 'Context that is essential for understanding the task',
            'keywords': ['context', 'background', 'prerequisite', 'foundation'],
        },
        'primary_reasoning_support': {
            'description': 'Content that supports the primary chain of reasoning',
            'keywords': ['reasoning', 'logic', 'inference', 'deduction', 'argument'],
        },
        'task_specific_instruction': {
            'description': 'Instructions or guidance specific to the task',
            'keywords': ['instruction', 'step', 'procedure', 'method', 'how-to'],
        },
        'critical_constraint': {
            'description': 'Content specifying critical constraints or requirements',
            'keywords': ['constraint', 'requirement', 'must', 'should', 'cannot'],
        },
    }

    # Superfluous (S) labels - content that is structured but not essential
    S_LABELS = {
        'background_information': {
            'description': 'General background that provides context but is not essential',
            'keywords': ['background', 'history', 'overview', 'introduction'],
        },
        'tangentially_related': {
            'description': 'Content related to the topic but not directly relevant',
            'keywords': ['related', 'similar', 'associated', 'connected'],
        },
        'redundant_detail': {
            'description': 'Details that repeat or elaborate on already stated information',
            'keywords': ['also', 'additionally', 'furthermore', 'moreover'],
        },
        'supporting_but_not_essential': {
            'description': 'Supporting information that could be removed without loss',
            'keywords': ['support', 'supplement', 'additional', 'extra'],
        },
        'context_padding': {
            'description': 'Content that fills space but adds little value',
            'keywords': ['note', 'remark', 'aside', 'incidentally'],
        },
        'verbose_explanation': {
            'description': 'Overly detailed explanations of simple concepts',
            'keywords': ['explanation', 'clarification', 'elaboration'],
        },
        'example_overkill': {
            'description': 'More examples than necessary to illustrate a point',
            'keywords': ['example', 'instance', 'case', 'illustration'],
        },
    }

    # Noise (N) labels - content that degrades performance
    N_LABELS = {
        'formatting_artifact': {
            'description': 'Formatting or encoding artifacts that add no meaning',
            'keywords': ['\\n', '\\t', '  ', '---', '==='],
        },
        'encoding_error': {
            'description': 'Text encoding errors or corrupted content',
            'keywords': ['\\x', '\\u', 'ï»¿', '�'],
        },
        'irrelevant_content': {
            'description': 'Content completely unrelated to the task',
            'keywords': ['advertisement', 'promotion', 'unrelated'],
        },
        'contradictory_information': {
            'description': 'Information that contradicts other context',
            'keywords': ['however', 'but', 'contrary', 'opposite', 'despite'],
        },
        'outdated_information': {
            'description': 'Information that is outdated or superseded',
            'keywords': ['deprecated', 'obsolete', 'old', 'former', 'previous'],
        },
        'misleading_content': {
            'description': 'Content that could mislead the reasoning process',
            'keywords': ['incorrect', 'wrong', 'error', 'mistake', 'false'],
        },
        'garbled_text': {
            'description': 'Text that is garbled or unreadable',
            'keywords': [],  # Detected by character patterns
        },
        'metadata_leak': {
            'description': 'Metadata that leaked into content (timestamps, IDs)',
            'keywords': ['id:', 'timestamp:', 'created:', 'modified:'],
        },
    }

    def __init__(self):
        self.all_labels = {
            'R': self.R_LABELS,
            'S': self.S_LABELS,
            'N': self.N_LABELS,
        }

    def get_labels_for_category(self, category: str) -> Dict[str, Dict]:
        """Get all labels for a category (R, S, or N)."""
        return self.all_labels.get(category.upper(), {})

    def get_all_r_labels(self) -> List[str]:
        """Get all R label names."""
        return list(self.R_LABELS.keys())

    def get_all_s_labels(self) -> List[str]:
        """Get all S label names."""
        return list(self.S_LABELS.keys())

    def get_all_n_labels(self) -> List[str]:
        """Get all N label names."""
        return list(self.N_LABELS.keys())


# =============================================================================
# Semantic Labeler
# =============================================================================

class SemanticLabeler:
    """
    Generate semantic labels for R/S/N components.

    Provides human-interpretable descriptions of why content
    was classified as Relevant, Superfluous, or Noise.
    """

    def __init__(
        self,
        vocabulary: Optional[RSNSemanticVocabulary] = None,
        use_clustering: bool = True,
        min_confidence: float = 0.3,
    ):
        self.vocabulary = vocabulary or RSNSemanticVocabulary()
        self.use_clustering = use_clustering
        self.min_confidence = min_confidence

        # Cluster centroids (learned from data)
        self.r_centroids: Optional[torch.Tensor] = None
        self.s_centroids: Optional[torch.Tensor] = None
        self.n_centroids: Optional[torch.Tensor] = None

        # Label assignments for centroids
        self.centroid_labels: Dict[str, List[str]] = {
            'R': [],
            'S': [],
            'N': [],
        }

    def label_decomposition(
        self,
        embedding: torch.Tensor,
        rsn_scores: DecompositionScore,
        text_content: Optional[str] = None,
        query_embedding: Optional[torch.Tensor] = None,
    ) -> Dict[str, Any]:
        """
        Generate semantic labels for a decomposition result.

        Args:
            embedding: [D] or [L, D] context embedding
            rsn_scores: DecompositionScore with R, S, N values
            text_content: Optional text for keyword matching
            query_embedding: Optional query for relevance scoring

        Returns:
            Dict with:
                - 'R_label': SemanticLabel for relevant component
                - 'S_label': SemanticLabel for superfluous component
                - 'N_label': SemanticLabel for noise component
                - 'explanation': Human-readable explanation
                - 'confidence': Overall labeling confidence
        """
        result = {
            'R_label': None,
            'S_label': None,
            'N_label': None,
            'explanation': '',
            'confidence': 0.0,
        }

        # Determine dominant category
        scores = {
            'R': rsn_scores.relevant,
            'S': rsn_scores.superfluous,
            'N': rsn_scores.noise,
        }
        dominant = max(scores, key=scores.get)

        # Get label for dominant category
        dominant_label = self._get_best_label(
            category=dominant,
            embedding=embedding,
            text_content=text_content,
            score=scores[dominant],
        )
        result[f'{dominant}_label'] = dominant_label

        # Get labels for other categories if significant
        for cat in ['R', 'S', 'N']:
            if cat != dominant and scores[cat] > self.min_confidence:
                label = self._get_best_label(
                    category=cat,
                    embedding=embedding,
                    text_content=text_content,
                    score=scores[cat],
                )
                result[f'{cat}_label'] = label

        # Generate explanation
        result['explanation'] = self._generate_explanation(result, rsn_scores)
        result['confidence'] = self._compute_labeling_confidence(result, rsn_scores)

        return result

    def _get_best_label(
        self,
        category: str,
        embedding: torch.Tensor,
        text_content: Optional[str],
        score: float,
    ) -> SemanticLabel:
        """Get the best matching semantic label for a category."""
        labels = self.vocabulary.get_labels_for_category(category)
        best_label = None
        best_confidence = 0.0
        evidence = []

        for label_name, label_info in labels.items():
            confidence = 0.0

            # Keyword matching if text available
            if text_content:
                text_lower = text_content.lower()
                keywords = label_info.get('keywords', [])
                matches = sum(1 for kw in keywords if kw.lower() in text_lower)
                if keywords:
                    keyword_score = matches / len(keywords)
                    confidence += keyword_score * 0.5

                    if matches > 0:
                        matched_kws = [kw for kw in keywords if kw.lower() in text_lower]
                        evidence.extend([f"Found keyword: '{kw}'" for kw in matched_kws[:3]])

            # Cluster matching if available
            if self.use_clustering and embedding is not None:
                cluster_score = self._get_cluster_score(category, embedding, label_name)
                confidence += cluster_score * 0.5

            # Base confidence from RSN score
            confidence = confidence * 0.7 + score * 0.3

            if confidence > best_confidence:
                best_confidence = confidence
                best_label = SemanticLabel(
                    category=category,
                    label=label_name,
                    description=label_info['description'],
                    confidence=confidence,
                    evidence=evidence.copy(),
                )

        # Fallback if no good match
        if best_label is None or best_confidence < self.min_confidence:
            default_labels = {
                'R': 'general_relevance',
                'S': 'general_superfluity',
                'N': 'general_noise',
            }
            default_descriptions = {
                'R': 'Content appears relevant but no specific pattern identified',
                'S': 'Content appears superfluous but no specific pattern identified',
                'N': 'Content appears noisy but no specific pattern identified',
            }
            best_label = SemanticLabel(
                category=category,
                label=default_labels[category],
                description=default_descriptions[category],
                confidence=score,
                evidence=['Based on RSN score only'],
            )

        return best_label

    def _get_cluster_score(
        self,
        category: str,
        embedding: torch.Tensor,
        label_name: str,
    ) -> float:
        """Get cluster-based confidence score."""
        centroids = {
            'R': self.r_centroids,
            'S': self.s_centroids,
            'N': self.n_centroids,
        }.get(category)

        if centroids is None or len(self.centroid_labels[category]) == 0:
            return 0.0

        # Find if this label has a centroid
        try:
            label_idx = self.centroid_labels[category].index(label_name)
        except ValueError:
            return 0.0

        # Compute similarity to centroid
        if embedding.dim() > 1:
            embedding = embedding.mean(dim=0)

        embedding = F.normalize(embedding.unsqueeze(0), dim=-1)
        centroid = F.normalize(centroids[label_idx].unsqueeze(0), dim=-1)

        similarity = torch.mm(embedding, centroid.t()).item()

        return max(0.0, similarity)

    def _generate_explanation(
        self,
        labels: Dict[str, Any],
        rsn_scores: DecompositionScore,
    ) -> str:
        """Generate human-readable explanation."""
        parts = []

        # Dominant category explanation
        scores = {'R': rsn_scores.relevant, 'S': rsn_scores.superfluous, 'N': rsn_scores.noise}
        dominant = max(scores, key=scores.get)
        dominant_label = labels.get(f'{dominant}_label')

        if dominant_label:
            parts.append(
                f"This content is primarily {dominant_label.category} ({dominant_label.label}): "
                f"{dominant_label.description}"
            )

            if dominant_label.evidence:
                parts.append(f"Evidence: {', '.join(dominant_label.evidence[:3])}")

        # Score breakdown
        parts.append(
            f"Score breakdown - R: {rsn_scores.relevant:.2f}, "
            f"S: {rsn_scores.superfluous:.2f}, N: {rsn_scores.noise:.2f}"
        )

        # Y-score interpretation
        y_score = rsn_scores.y_score
        if y_score > 0.7:
            parts.append("Overall quality: HIGH - content is highly relevant")
        elif y_score > 0.4:
            parts.append("Overall quality: MODERATE - content has mixed relevance")
        else:
            parts.append("Overall quality: LOW - content may need filtering")

        return "\n".join(parts)

    def _compute_labeling_confidence(
        self,
        labels: Dict[str, Any],
        rsn_scores: DecompositionScore,
    ) -> float:
        """Compute overall confidence in the labeling."""
        confidences = []

        for cat in ['R', 'S', 'N']:
            label = labels.get(f'{cat}_label')
            if label and isinstance(label, SemanticLabel):
                confidences.append(label.confidence)

        if not confidences:
            return 0.0

        # Weighted by RSN scores
        scores = [rsn_scores.relevant, rsn_scores.superfluous, rsn_scores.noise]
        weighted = sum(c * s for c, s in zip(confidences, scores[:len(confidences)]))
        total_score = sum(scores[:len(confidences)])

        return weighted / (total_score + 1e-8)

    def fit_clusters(
        self,
        embeddings: torch.Tensor,
        rsn_labels: torch.Tensor,
        n_clusters_per_category: int = 5,
    ) -> None:
        """
        Fit cluster centroids from labeled data.

        Args:
            embeddings: [N, D] embeddings
            rsn_labels: [N] labels (0=R, 1=S, 2=N)
            n_clusters_per_category: Number of clusters per category
        """
        try:
            from sklearn.cluster import KMeans
        except ImportError:
            print("Warning: sklearn not available, clustering disabled")
            self.use_clustering = False
            return

        for cat_idx, cat in enumerate(['R', 'S', 'N']):
            mask = rsn_labels == cat_idx
            cat_embeddings = embeddings[mask].numpy()

            if len(cat_embeddings) < n_clusters_per_category:
                continue

            # Fit k-means
            kmeans = KMeans(n_clusters=n_clusters_per_category, random_state=42)
            kmeans.fit(cat_embeddings)

            centroids = torch.tensor(kmeans.cluster_centers_, dtype=torch.float32)

            if cat == 'R':
                self.r_centroids = centroids
            elif cat == 'S':
                self.s_centroids = centroids
            else:
                self.n_centroids = centroids

            # Assign labels to centroids (placeholder - would need more sophisticated mapping)
            labels_list = list(self.vocabulary.get_labels_for_category(cat).keys())
            self.centroid_labels[cat] = labels_list[:n_clusters_per_category]

    def cluster_decompositions(
        self,
        decomposition_history: List[DecompositionScore],
        n_clusters: int = 10,
    ) -> Dict[int, str]:
        """
        Cluster decomposition patterns and assign semantic labels.

        Useful for discovering common R/S/N patterns in a dataset.

        Args:
            decomposition_history: List of DecompositionScore objects
            n_clusters: Number of clusters to find

        Returns:
            Dict mapping cluster ID to semantic description
        """
        try:
            from sklearn.cluster import KMeans
        except ImportError:
            return {}

        # Convert to numpy array
        data = np.array([
            [d.relevant, d.superfluous, d.noise]
            for d in decomposition_history
        ])

        if len(data) < n_clusters:
            n_clusters = len(data)

        # Cluster
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        cluster_labels = kmeans.fit_predict(data)
        centroids = kmeans.cluster_centers_

        # Assign semantic descriptions to clusters
        cluster_descriptions = {}
        for i, centroid in enumerate(centroids):
            r, s, n = centroid
            dominant = np.argmax(centroid)

            if dominant == 0:  # R-dominant
                if r > 0.7:
                    desc = "Highly relevant context"
                elif r > 0.5:
                    desc = "Moderately relevant context"
                else:
                    desc = "Slightly relevant context"
            elif dominant == 1:  # S-dominant
                if s > 0.7:
                    desc = "Highly superfluous context"
                elif s > 0.5:
                    desc = "Moderately superfluous context"
                else:
                    desc = "Slightly superfluous context"
            else:  # N-dominant
                if n > 0.7:
                    desc = "Very noisy context"
                elif n > 0.5:
                    desc = "Moderately noisy context"
                else:
                    desc = "Slightly noisy context"

            cluster_descriptions[i] = f"{desc} (R={r:.2f}, S={s:.2f}, N={n:.2f})"

        return cluster_descriptions


# =============================================================================
# Batch Labeling
# =============================================================================

class BatchSemanticLabeler:
    """
    Efficient batch labeling for large datasets.
    """

    def __init__(
        self,
        labeler: Optional[SemanticLabeler] = None,
        batch_size: int = 64,
    ):
        self.labeler = labeler or SemanticLabeler()
        self.batch_size = batch_size

    def label_batch(
        self,
        embeddings: torch.Tensor,
        rsn_scores: List[DecompositionScore],
        text_contents: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Label a batch of decomposition results.

        Args:
            embeddings: [B, D] embeddings
            rsn_scores: List of DecompositionScore objects
            text_contents: Optional list of text content

        Returns:
            List of label dictionaries
        """
        results = []

        for i, (emb, scores) in enumerate(zip(embeddings, rsn_scores)):
            text = text_contents[i] if text_contents else None
            result = self.labeler.label_decomposition(
                embedding=emb,
                rsn_scores=scores,
                text_content=text,
            )
            results.append(result)

        return results


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'SemanticLabel',
    'RSNSemanticVocabulary',
    'SemanticLabeler',
    'BatchSemanticLabeler',
]
