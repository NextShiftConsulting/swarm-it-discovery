"""
Industrial utilities for collapse detection - minimal implementation.
Phase 6: Industrial Pack support.
"""
import numpy as np
from typing import Optional, List, Dict
from datetime import datetime, timedelta


def compute_temporal_freshness(
    data_timestamp: datetime,
    current_time: Optional[datetime] = None,
    max_age_hours: float = 24.0
) -> float:
    """
    Compute data temporal freshness (how recent the data is).

    Parameters
    ----------
    data_timestamp : datetime
        Timestamp of the data
    current_time : datetime, optional
        Current time (default: now)
    max_age_hours : float
        Maximum acceptable age in hours

    Returns
    -------
    float
        Freshness score [0, 1] (1.0 = fresh, 0.0 = stale)
    """
    if current_time is None:
        current_time = datetime.now()

    age = current_time - data_timestamp
    age_hours = age.total_seconds() / 3600.0

    # Freshness decreases with age
    freshness = max(0.0, 1.0 - (age_hours / max_age_hours))
    return float(min(1.0, freshness))


def compute_source_credibility(
    source_reputation: float,
    verification_status: bool,
    historical_accuracy: float
) -> float:
    """
    Compute source credibility score.

    Parameters
    ----------
    source_reputation : float
        Reputation score [0, 1]
    verification_status : bool
        Whether source is verified
    historical_accuracy : float
        Historical accuracy [0, 1]

    Returns
    -------
    float
        Credibility score [0, 1] (1.0 = highly credible)
    """
    # Verification adds 0.2 to credibility
    verification_bonus = 0.2 if verification_status else 0.0

    # Combined credibility
    credibility = (source_reputation + historical_accuracy + verification_bonus) / 2.2
    return float(min(1.0, max(0.0, credibility)))


def compute_compliance_score(
    rules_checked: int,
    rules_passed: int,
    critical_violations: int = 0
) -> float:
    """
    Compute regulatory compliance score.

    Parameters
    ----------
    rules_checked : int
        Number of rules checked
    rules_passed : int
        Number of rules passed
    critical_violations : int
        Number of critical violations

    Returns
    -------
    float
        Compliance score [0, 1] (1.0 = fully compliant)
    """
    if rules_checked == 0:
        return 1.0  # No rules = no violations

    base_score = rules_passed / rules_checked

    # Critical violations reduce score significantly
    critical_penalty = critical_violations * 0.2
    compliance = base_score - critical_penalty

    return float(min(1.0, max(0.0, compliance)))


def compute_security_score(
    vulnerabilities_found: int,
    vulnerabilities_patched: int,
    encryption_enabled: bool,
    access_controls: float
) -> float:
    """
    Compute security score.

    Parameters
    ----------
    vulnerabilities_found : int
        Number of vulnerabilities found
    vulnerabilities_patched : int
        Number of vulnerabilities patched
    encryption_enabled : bool
        Whether encryption is enabled
    access_controls : float
        Access control score [0, 1]

    Returns
    -------
    float
        Security score [0, 1] (1.0 = secure)
    """
    # Patch ratio
    if vulnerabilities_found > 0:
        patch_ratio = vulnerabilities_patched / vulnerabilities_found
    else:
        patch_ratio = 1.0

    # Encryption bonus
    encryption_bonus = 0.2 if encryption_enabled else 0.0

    # Combined security
    security = (patch_ratio + access_controls + encryption_bonus) / 2.2
    return float(min(1.0, max(0.0, security)))


def compute_privacy_score(
    pii_detected: int,
    pii_protected: int,
    consent_obtained: bool,
    data_minimization: float
) -> float:
    """
    Compute privacy/data protection score.

    Parameters
    ----------
    pii_detected : int
        Number of PII elements detected
    pii_protected : int
        Number of PII elements protected
    consent_obtained : bool
        Whether consent was obtained
    data_minimization : float
        Data minimization score [0, 1]

    Returns
    -------
    float
        Privacy score [0, 1] (1.0 = privacy protected)
    """
    # Protection ratio
    if pii_detected > 0:
        protection_ratio = pii_protected / pii_detected
    else:
        protection_ratio = 1.0

    # Consent bonus
    consent_bonus = 0.2 if consent_obtained else 0.0

    # Combined privacy
    privacy = (protection_ratio + data_minimization + consent_bonus) / 2.2
    return float(min(1.0, max(0.0, privacy)))


def compute_bias_score(
    demographic_disparities: List[float],
    fairness_metrics: Dict[str, float]
) -> float:
    """
    Compute bias/fairness score.

    Parameters
    ----------
    demographic_disparities : list of float
        Disparity scores for each demographic [0, 1]
    fairness_metrics : dict
        Fairness metrics (e.g., equalized odds, demographic parity)

    Returns
    -------
    float
        Bias score [0, 1] (0.0 = no bias, 1.0 = high bias)
    """
    if len(demographic_disparities) == 0:
        return 0.0

    # Average disparity
    avg_disparity = np.mean(demographic_disparities)

    # Fairness metrics (if available)
    if fairness_metrics:
        fairness_values = list(fairness_metrics.values())
        avg_fairness = np.mean(fairness_values)
        # Combine disparity and unfairness
        bias = (avg_disparity + (1.0 - avg_fairness)) / 2.0
    else:
        bias = avg_disparity

    return float(min(1.0, max(0.0, bias)))


def compute_audit_completeness(
    events_logged: int,
    events_expected: int,
    log_integrity: float
) -> float:
    """
    Compute audit trail completeness.

    Parameters
    ----------
    events_logged : int
        Number of events logged
    events_expected : int
        Number of events expected
    log_integrity : float
        Log integrity score [0, 1]

    Returns
    -------
    float
        Audit completeness [0, 1] (1.0 = complete audit trail)
    """
    if events_expected == 0:
        return 1.0  # No events expected = complete

    # Coverage ratio
    coverage = events_logged / events_expected

    # Combined completeness
    completeness = (coverage + log_integrity) / 2.0
    return float(min(1.0, max(0.0, completeness)))
