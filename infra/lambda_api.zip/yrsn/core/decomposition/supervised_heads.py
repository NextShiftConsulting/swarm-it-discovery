"""
Learnable YRSN Projection Heads for Supervised Training

This module extends the YRSNProjectionHeads with learnable parameters
for supervised and semi-supervised training of R/S/N decomposition.

Three modes of operation:
1. WEIGHT_DERIVED: Initialize from model weights (existing fast path)
2. SUPERVISED: Learn from labeled R/S/N examples
3. HYBRID: Initialize from weights, fine-tune with supervision

Based on research synthesis:
- SimCLR projection head design (2-layer MLP)
- Port training API from yrsn-1210
- Integration with CalibrationManager for online learning
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Union
from enum import Enum
import numpy as np

from . import DecompositionScore


# =============================================================================
# Configuration
# =============================================================================

class ProjectionMode(Enum):
    """Operating mode for projection heads."""
    WEIGHT_DERIVED = "weight_derived"  # From model weights via SVD
    SUPERVISED = "supervised"  # Fully learned from labels
    HYBRID = "hybrid"  # Initialize from weights, fine-tune


@dataclass
class ProjectionHeadConfig:
    """Configuration for learnable projection heads."""
    hidden_dim: int = 768
    projection_dim: int = 128
    mode: str = "hybrid"
    num_layers: int = 2
    dropout: float = 0.1
    use_batch_norm: bool = False
    use_layer_norm: bool = True
    activation: str = "gelu"
    init_scale: float = 0.02
    classifier_hidden_dim: Optional[int] = None  # If None, use projection_dim


# =============================================================================
# Projection Head Builder
# =============================================================================

def _build_mlp(
    in_dim: int,
    out_dim: int,
    hidden_dim: Optional[int] = None,
    num_layers: int = 2,
    dropout: float = 0.1,
    use_batch_norm: bool = False,
    use_layer_norm: bool = True,
    activation: str = "gelu",
) -> nn.Module:
    """
    Build MLP projection head (SimCLR style).

    Architecture for num_layers=2:
        Linear -> Norm -> Activation -> Dropout -> Linear -> Norm
    """
    hidden_dim = hidden_dim or in_dim

    if activation == "gelu":
        act_fn = nn.GELU()
    elif activation == "relu":
        act_fn = nn.ReLU()
    elif activation == "silu":
        act_fn = nn.SiLU()
    else:
        act_fn = nn.GELU()

    layers = []

    if num_layers == 1:
        layers.append(nn.Linear(in_dim, out_dim))
        if use_layer_norm:
            layers.append(nn.LayerNorm(out_dim))
    else:
        # First layer
        layers.append(nn.Linear(in_dim, hidden_dim))
        if use_batch_norm:
            layers.append(nn.BatchNorm1d(hidden_dim))
        elif use_layer_norm:
            layers.append(nn.LayerNorm(hidden_dim))
        layers.append(act_fn)
        if dropout > 0:
            layers.append(nn.Dropout(dropout))

        # Middle layers
        for _ in range(num_layers - 2):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            if use_batch_norm:
                layers.append(nn.BatchNorm1d(hidden_dim))
            elif use_layer_norm:
                layers.append(nn.LayerNorm(hidden_dim))
            layers.append(act_fn)
            if dropout > 0:
                layers.append(nn.Dropout(dropout))

        # Final layer
        layers.append(nn.Linear(hidden_dim, out_dim))
        if use_layer_norm:
            layers.append(nn.LayerNorm(out_dim))

    return nn.Sequential(*layers)


# =============================================================================
# Learnable Projection Heads
# =============================================================================

class LearnedYRSNProjectionHeads(nn.Module):
    """
    Learnable YRSN Projection Heads with training support.

    Projects hidden states to three quality subspaces:
    - R (Relevant): Task-aligned, semantically meaningful
    - S (Superfluous): Structured but non-essential
    - N (Noise): Unstructured stochastic component

    Supports three modes:
    1. WEIGHT_DERIVED: Initialize from model weights (existing)
    2. SUPERVISED: Learn from labeled R/S/N examples
    3. HYBRID: Initialize from weights, fine-tune with supervision

    Args:
        config: ProjectionHeadConfig with all hyperparameters
    """

    def __init__(self, config: ProjectionHeadConfig):
        super().__init__()
        self.config = config
        self.hidden_dim = config.hidden_dim
        self.projection_dim = config.projection_dim
        self.mode = ProjectionMode(config.mode)

        # Build projection heads (MLP style for better representation)
        self.R_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        self.S_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        self.N_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        # Quality classifier (for direct R/S/N classification)
        # ⚠️ NOTE: This outputs RAW LOGITS (before softmax), NOT probabilities
        # Use this when you need logits for classification (e.g., RSNValidator, loss functions)
        # You should apply softmax yourself if you need probabilities
        classifier_hidden = config.classifier_hidden_dim or config.classifier_hidden_dim or config.projection_dim
        self.quality_classifier = nn.Sequential(
            nn.Linear(config.projection_dim * 3, classifier_hidden),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(classifier_hidden, 3),  # 3 classes: R, S, N
            # NO SOFTMAX - OUTPUTS RAW LOGITS
        )

        # Score predictor (for continuous R/S/N scores)
        self.score_predictor = nn.Sequential(
            nn.Linear(config.projection_dim * 3, classifier_hidden),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(classifier_hidden, 3),  # 3 scores: R, S, N
            nn.Softmax(dim=-1),  # Scores sum to 1
        )

        # Backup weights for weight-derived mode (used in topic shift detection)
        self.register_buffer('R_weight_backup', None)
        self.register_buffer('S_weight_backup', None)
        self.register_buffer('N_weight_backup', None)

        # Initialize weights
        self._init_weights()

        # Track if initialized from model weights
        self._weight_derived_init = False

    def _init_weights(self):
        """Initialize weights with small values."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.trunc_normal_(module.weight, std=self.config.init_scale)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.LayerNorm):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

    def initialize_from_weights(
        self,
        model: nn.Module,
        device: torch.device,
        use_svd: bool = True,
    ) -> None:
        """
        Initialize projection heads from model weights (warm start).

        Uses SVD decomposition of model weights to create initial
        R/S/N projections that are then fine-tuned.

        Args:
            model: Source model with input_proj and lm_head
            device: Target device
            use_svd: Whether to use SVD (True) or random init (False)
        """
        if not use_svd:
            self._weight_derived_init = False
            return

        # Get weights from model
        input_weight = None
        output_weight = None

        if hasattr(model, 'input_proj'):
            input_weight = model.input_proj.weight.detach().to(device=device, dtype=torch.float32)
        else:
            for module in model.modules():
                if isinstance(module, nn.Linear) and module.in_features == self.hidden_dim:
                    input_weight = module.weight.detach().to(device=device, dtype=torch.float32)
                    break

        if hasattr(model, 'lm_head'):
            output_weight = model.lm_head.weight.detach().to(device=device, dtype=torch.float32)
        else:
            for module in reversed(list(model.modules())):
                if isinstance(module, nn.Linear) and module.out_features < 100:
                    output_weight = module.weight.detach().to(device=device, dtype=torch.float32)
                    break

        if input_weight is None or output_weight is None:
            print("Warning: Could not find suitable weights for initialization")
            self._weight_derived_init = False
            return

        # Compute base matrix
        try:
            if output_weight.shape[1] == self.hidden_dim:
                gram = torch.matmul(output_weight.T, output_weight)
                reg = 1e-5 * torch.eye(gram.shape[0], device=gram.device, dtype=gram.dtype)

                if input_weight.shape[0] == self.hidden_dim and input_weight.shape[1] == self.hidden_dim:
                    base_matrix = torch.linalg.solve(gram + reg, input_weight)
                else:
                    base_matrix = torch.eye(self.hidden_dim, device=device, dtype=torch.float32)
            else:
                base_matrix = torch.eye(self.hidden_dim, device=device, dtype=torch.float32)

            # SVD decomposition
            U, S, Vh = torch.linalg.svd(base_matrix, full_matrices=False)
            rank = min(128, U.shape[1])

            # R: Low-rank component (top singular values)
            R_proj = U[:, :rank] @ torch.diag(S[:rank]) @ Vh[:rank, :]

            # S: Sparse residual (thresholded)
            S_residual = base_matrix - R_proj
            S_proj = torch.sign(S_residual) * torch.clamp(torch.abs(S_residual) - 0.01, min=0)

            # N: Noise (orthogonal complement)
            N_proj = base_matrix - R_proj - S_proj

            # Initialize first linear layer of each head
            self._set_first_layer_weight(self.R_head, R_proj)
            self._set_first_layer_weight(self.S_head, S_proj)
            self._set_first_layer_weight(self.N_head, N_proj)

            # Store backups for topic shift detection
            self.R_weight_backup = R_proj.clone()
            self.S_weight_backup = S_proj.clone()
            self.N_weight_backup = N_proj.clone()

            self._weight_derived_init = True

        except Exception as e:
            print(f"Warning: SVD initialization failed: {e}")
            self._weight_derived_init = False

    def _set_first_layer_weight(self, head: nn.Module, weight: torch.Tensor):
        """Set the first linear layer's weight in a head."""
        for module in head.modules():
            if isinstance(module, nn.Linear):
                # Truncate or pad weight to match dimensions
                out_dim, in_dim = module.weight.shape
                w = weight[:out_dim, :in_dim] if weight.shape[0] >= out_dim else weight
                if w.shape[0] < out_dim:
                    padding = torch.zeros(out_dim - w.shape[0], in_dim, device=weight.device)
                    w = torch.cat([w, padding], dim=0)
                module.weight.data = w.to(module.weight.dtype)
                break

    def forward(
        self,
        hidden_states: torch.Tensor,
        return_scores: bool = False,
        return_classification: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Project hidden states to R/S/N subspaces.

        Args:
            hidden_states: [B, D] or [B, L, D] hidden states
            return_scores: If True, include continuous R/S/N scores (PROBABILITIES, after softmax)
            return_classification: If True, include classification logits (RAW LOGITS, before softmax)

        Returns:
            Dict with keys:
                - 'R': R projection
                - 'S': S projection
                - 'N': N projection
                - 'scores': (optional) Continuous R/S/N scores [B, 3] - PROBABILITIES (sum to 1, after softmax)
                - 'logits': (optional) Classification logits [B, 3] - RAW LOGITS (before softmax)

        ⚠️ IMPORTANT: Choosing between return_scores and return_classification
        =========================================================================
        
        **Use return_scores=True when:**
        - You need normalized probabilities (already sum to 1.0)
        - You want continuous R/S/N scores for quality metrics
        - You will NOT apply softmax again (scores are already probabilities)
        
        **Use return_classification=True when:**
        - You need raw logits for classification tasks
        - You will apply softmax yourself (e.g., in RSNValidator, loss functions)
        - You need to compute log-probabilities or cross-entropy loss
        
        **DO NOT use both simultaneously if you will apply softmax** - this causes
        double softmax (softmax(softmax(x)) ≠ softmax(x)) and distorts probabilities.
        
        Example (CORRECT):
            # For RSNValidator (applies softmax internally):
            output = projection_heads(embeddings, return_classification=True)
            logits = output['logits']  # Raw logits → RSNValidator → softmax → probabilities
            
        Example (WRONG):
            # Double softmax bug:
            output = projection_heads(embeddings, return_scores=True)
            scores = output['scores']  # Already probabilities (after softmax)
            probs = F.softmax(scores, dim=-1)  # WRONG: softmax(probabilities) distorts distribution!
        """
        # Handle sequence dimension
        is_sequence = hidden_states.dim() == 3
        if is_sequence:
            B, L, D = hidden_states.shape
            hidden_states = hidden_states.view(B * L, D)

        # Project to subspaces
        R_proj = self.R_head(hidden_states)
        S_proj = self.S_head(hidden_states)
        N_proj = self.N_head(hidden_states)

        # Concatenate for classifier/scorer
        combined = torch.cat([R_proj, S_proj, N_proj], dim=-1)

        result = {'R': R_proj, 'S': S_proj, 'N': N_proj}

        if return_scores:
            # score_predictor outputs PROBABILITIES (after softmax) - normalized to sum to 1.0
            # Do NOT apply softmax again if using these scores
            scores = self.score_predictor(combined)
            result['scores'] = scores  # [B, 3] probabilities

        if return_classification:
            # quality_classifier outputs RAW LOGITS (before softmax)
            # Apply softmax yourself if you need probabilities (e.g., in loss functions, validators)
            logits = self.quality_classifier(combined)
            result['logits'] = logits  # [B, 3] raw logits

        # Reshape if sequence
        if is_sequence:
            result['R'] = result['R'].view(B, L, -1)
            result['S'] = result['S'].view(B, L, -1)
            result['N'] = result['N'].view(B, L, -1)
            if 'scores' in result:
                result['scores'] = result['scores'].view(B, L, -1)
            if 'logits' in result:
                result['logits'] = result['logits'].view(B, L, -1)

        return result

    def compute_rsn_scores(
        self,
        hidden_states: torch.Tensor,
    ) -> DecompositionScore:
        """
        Compute normalized R/S/N scores from hidden states.

        Args:
            hidden_states: [B, D] or [D] hidden states

        Returns:
            DecompositionScore with R, S, N values (summing to 1)
        """
        # Handle single vector
        if hidden_states.dim() == 1:
            hidden_states = hidden_states.unsqueeze(0)

        output = self.forward(hidden_states, return_scores=True)
        scores = output['scores'].mean(dim=0)  # Average over batch

        return DecompositionScore(
            relevant=scores[0].item(),
            superfluous=scores[1].item(),
            noise=scores[2].item(),
        )

    def get_projection_weights(self) -> Dict[str, torch.Tensor]:
        """Get the first linear layer weights from each head."""
        weights = {}
        for name, head in [('R', self.R_head), ('S', self.S_head), ('N', self.N_head)]:
            for module in head.modules():
                if isinstance(module, nn.Linear):
                    weights[name] = module.weight
                    break
        return weights

    def train_projections(
        self,
        training_data: List[Tuple[torch.Tensor, torch.Tensor, int]],
        labels: torch.Tensor,
        optimizer: Optional[torch.optim.Optimizer] = None,
        num_epochs: int = 1,
    ) -> Dict[str, float]:
        """
        Train projection matrices from labeled data.

        Port of API from yrsn-1210/ysrn_engine.py.

        Args:
            training_data: List of (context_embedding, query_embedding, rsn_label) tuples
            labels: Tensor of R/S/N labels (0=R, 1=S, 2=N)
            optimizer: Optional optimizer (creates Adam if None)
            num_epochs: Number of training epochs

        Returns:
            Dict with training metrics
        """
        from .triplet_loss import YRSNCombinedLoss

        device = next(self.parameters()).device

        if optimizer is None:
            optimizer = torch.optim.AdamW(self.parameters(), lr=1e-4, weight_decay=0.01)

        loss_fn = YRSNCombinedLoss(
            triplet_weight=1.0,
            orthogonality_weight=0.1,
            classification_weight=0.5,
        )

        self.train()
        total_loss = 0.0
        num_batches = 0

        for epoch in range(num_epochs):
            for context_emb, query_emb, rsn_label in training_data:
                context_emb = context_emb.to(device)
                rsn_label = torch.tensor([rsn_label], device=device)

                optimizer.zero_grad()

                # Forward pass
                output = self.forward(context_emb.unsqueeze(0), return_classification=True)

                # Compute loss using mean of projections
                embeddings = (output['R'] + output['S'] + output['N']) / 3

                loss_output = loss_fn(
                    embeddings=embeddings,
                    rsn_labels=rsn_label,
                    projection_heads=self,
                    classification_logits=output['logits'],
                )

                loss_output.total_loss.backward()
                optimizer.step()

                total_loss += loss_output.total_loss.item()
                num_batches += 1

        return {
            'avg_loss': total_loss / max(num_batches, 1),
            'num_batches': num_batches,
            'num_epochs': num_epochs,
        }


# =============================================================================
# RSN Quality Classifier
# =============================================================================

class RSNQualityClassifier(nn.Module):
    """
    Direct classifier for R/S/N quality labels.

    Used for:
    1. Direct supervision when labels available
    2. Pseudo-labeling for semi-supervised learning
    3. Quality validation during inference

    Args:
        hidden_dim: Input hidden dimension
        num_classes: Number of classes (default 3 for R/S/N)
        hidden_layers: Number of hidden layers
        hidden_size: Size of hidden layers
        dropout: Dropout rate
        uncertainty_estimation: If True, output uncertainty via MC dropout
    """

    def __init__(
        self,
        hidden_dim: int,
        num_classes: int = 3,
        hidden_layers: int = 2,
        hidden_size: int = 256,
        dropout: float = 0.1,
        uncertainty_estimation: bool = True,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_classes = num_classes
        self.uncertainty_estimation = uncertainty_estimation
        self.dropout = dropout

        # Build classifier
        layers = []
        in_dim = hidden_dim

        for i in range(hidden_layers):
            layers.append(nn.Linear(in_dim, hidden_size))
            layers.append(nn.LayerNorm(hidden_size))
            layers.append(nn.GELU())
            layers.append(nn.Dropout(dropout))
            in_dim = hidden_size

        layers.append(nn.Linear(hidden_size, num_classes))

        self.classifier = nn.Sequential(*layers)

        # Temperature for uncertainty calibration
        self.temperature = nn.Parameter(torch.ones(1))

    def forward(
        self,
        hidden_states: torch.Tensor,
        return_uncertainty: bool = False,
        num_mc_samples: int = 10,
    ) -> Dict[str, torch.Tensor]:
        """
        Classify hidden states as R/S/N.

        Args:
            hidden_states: [B, D] hidden states
            return_uncertainty: If True, compute uncertainty via MC dropout
            num_mc_samples: Number of MC samples for uncertainty

        Returns:
            Dict with:
                - 'logits': [B, 3] classification logits
                - 'probs': [B, 3] softmax probabilities
                - 'uncertainty': [B] epistemic uncertainty (if requested)
        """
        logits = self.classifier(hidden_states)
        logits_calibrated = logits / self.temperature
        probs = F.softmax(logits_calibrated, dim=-1)

        result = {
            'logits': logits,
            'probs': probs,
        }

        if return_uncertainty and self.uncertainty_estimation:
            # MC Dropout for uncertainty estimation
            self.train()  # Enable dropout

            mc_probs = []
            for _ in range(num_mc_samples):
                mc_logits = self.classifier(hidden_states) / self.temperature
                mc_probs.append(F.softmax(mc_logits, dim=-1))

            mc_probs = torch.stack(mc_probs, dim=0)  # [num_samples, B, 3]

            # Epistemic uncertainty = variance of predictions
            uncertainty = mc_probs.var(dim=0).sum(dim=-1)  # [B]

            # Also compute predictive entropy
            mean_probs = mc_probs.mean(dim=0)
            entropy = -(mean_probs * torch.log(mean_probs + 1e-8)).sum(dim=-1)

            result['uncertainty'] = uncertainty
            result['entropy'] = entropy
            result['mc_probs'] = mc_probs

            self.eval()  # Disable dropout

        return result

    def predict(
        self,
        hidden_states: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Get predicted class and confidence.

        Args:
            hidden_states: [B, D] hidden states

        Returns:
            predicted_class: [B] predicted R/S/N labels
            confidence: [B] prediction confidence
        """
        output = self.forward(hidden_states)
        probs = output['probs']
        confidence, predicted = probs.max(dim=-1)
        return predicted, confidence


# =============================================================================
# Factory Functions
# =============================================================================

def create_projection_heads(
    hidden_dim: int = 768,
    projection_dim: int = 128,
    mode: str = "hybrid",
    **kwargs
) -> LearnedYRSNProjectionHeads:
    """
    Factory function to create projection heads.

    Args:
        hidden_dim: Input hidden dimension
        projection_dim: Output projection dimension
        mode: Operating mode (weight_derived, supervised, hybrid)
        **kwargs: Additional config options

    Returns:
        Configured LearnedYRSNProjectionHeads instance
    """
    config = ProjectionHeadConfig(
        hidden_dim=hidden_dim,
        projection_dim=projection_dim,
        mode=mode,
        **kwargs
    )
    return LearnedYRSNProjectionHeads(config)


def create_quality_classifier(
    hidden_dim: int = 768,
    **kwargs
) -> RSNQualityClassifier:
    """
    Factory function to create quality classifier.

    Args:
        hidden_dim: Input hidden dimension
        **kwargs: Additional config options

    Returns:
        Configured RSNQualityClassifier instance
    """
    return RSNQualityClassifier(hidden_dim=hidden_dim, **kwargs)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'ProjectionMode',
    'ProjectionHeadConfig',
    'LearnedYRSNProjectionHeads',
    'GatedYRSNProjectionHeads',
    'RSNQualityClassifier',
    'create_projection_heads',
    'create_gated_projection_heads',
    'create_quality_classifier',
]


# =============================================================================
# Gated Projection Heads (NeurIPS 2024 Gated Attention inspired)
# =============================================================================

class GatedYRSNProjectionHeads(nn.Module):
    """
    Projection heads with sigmoid gating to break low-rank bottlenecks.

    From Gated Attention paper (NeurIPS 2024): inserting sigmoid(query · W_gate)
    after attention output breaks the W_V · W_O low-rank bottleneck.

    For YRSN: applies gating to R/S/N projections to prevent retrieval sinks.

    KEY INSIGHT: Standard attention wastes ~47% on first tokens ("attention sinks").
    By adding learnable gates, we allow the model to dynamically suppress or
    amplify each projection dimension, preventing any single passage from
    dominating regardless of actual relevance.

    Args:
        config: ProjectionHeadConfig with all hyperparameters
        gate_init_bias: Initial bias for gates (0.0 = neutral, sigmoid(0)=0.5)
    """

    def __init__(
        self,
        config: ProjectionHeadConfig,
        gate_init_bias: float = 0.0,
    ):
        super().__init__()
        self.config = config
        self.hidden_dim = config.hidden_dim
        self.projection_dim = config.projection_dim

        # Build base projection heads (MLP style)
        self.R_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        self.S_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        self.N_head = _build_mlp(
            in_dim=config.hidden_dim,
            out_dim=config.projection_dim,
            num_layers=config.num_layers,
            dropout=config.dropout,
            use_batch_norm=config.use_batch_norm,
            use_layer_norm=config.use_layer_norm,
            activation=config.activation,
        )

        # GATING MECHANISM: Each gate learns to modulate its corresponding projection
        # Gate output in [0,1] via sigmoid: 0 = fully suppress, 1 = fully pass through
        self.gate_R = nn.Linear(config.hidden_dim, config.projection_dim)
        self.gate_S = nn.Linear(config.hidden_dim, config.projection_dim)
        self.gate_N = nn.Linear(config.hidden_dim, config.projection_dim)

        # INITIALIZATION: Zero weights + configurable bias for stable training start
        # With zero weights and zero bias: sigmoid(0) = 0.5, so gates start at 50%
        nn.init.zeros_(self.gate_R.weight)
        nn.init.constant_(self.gate_R.bias, gate_init_bias)
        nn.init.zeros_(self.gate_S.weight)
        nn.init.constant_(self.gate_S.bias, gate_init_bias)
        nn.init.zeros_(self.gate_N.weight)
        nn.init.constant_(self.gate_N.bias, gate_init_bias)

        # Score predictor for continuous R/S/N scores
        # ⚠️ NOTE: This outputs PROBABILITIES (after softmax), NOT logits
        # Use this when you need normalized scores that sum to 1.0
        # Do NOT apply softmax again if using return_scores=True
        classifier_hidden = config.classifier_hidden_dim or config.projection_dim
        self.score_predictor = nn.Sequential(
            nn.Linear(config.projection_dim * 3, classifier_hidden),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(classifier_hidden, 3),
            nn.Softmax(dim=-1),  # OUTPUTS PROBABILITIES (after softmax)
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        return_scores: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass with gating.

        The gating operation: output = base_projection * sigmoid(gate(input))

        This element-wise multiplication allows fine-grained control:
        - Dimensions with high gate activation pass through
        - Dimensions with low gate activation are suppressed
        - The model learns which dimensions are "retrieval sinks" and gates them out

        Args:
            hidden_states: [B, D] or [B, L, D] hidden states from transformer layers
            return_scores: If True, include continuous R/S/N scores (PROBABILITIES, after softmax)

        Returns:
            Dict with keys:
                - 'R': R projection
                - 'S': S projection
                - 'N': N projection
                - 'scores': (optional) Continuous R/S/N scores [B, 3] - PROBABILITIES (sum to 1, after softmax)
        
        ⚠️ IMPORTANT: return_scores outputs PROBABILITIES (after softmax)
        ==================================================================
        
        **Use return_scores=True when:**
        - You need normalized probabilities (already sum to 1.0)
        - You want continuous R/S/N scores for quality metrics
        - You will NOT apply softmax again (scores are already probabilities)
        
        **Do NOT apply softmax again** - this causes double softmax distortion.
        """
        # Handle sequence dimension
        is_sequence = hidden_states.dim() == 3
        if is_sequence:
            B, L, D = hidden_states.shape
            hidden_states = hidden_states.view(B * L, D)

        # Step 1: Get base R/S/N projections
        R_base = self.R_head(hidden_states)
        S_base = self.S_head(hidden_states)
        N_base = self.N_head(hidden_states)

        # Step 2: Apply sigmoid gating - element-wise multiplication
        R_proj = R_base * torch.sigmoid(self.gate_R(hidden_states))
        S_proj = S_base * torch.sigmoid(self.gate_S(hidden_states))
        N_proj = N_base * torch.sigmoid(self.gate_N(hidden_states))

        result = {'R': R_proj, 'S': S_proj, 'N': N_proj}

        if return_scores:
            combined = torch.cat([R_proj, S_proj, N_proj], dim=-1)
            scores = self.score_predictor(combined)
            result['scores'] = scores

        # Reshape if sequence
        if is_sequence:
            result['R'] = result['R'].view(B, L, -1)
            result['S'] = result['S'].view(B, L, -1)
            result['N'] = result['N'].view(B, L, -1)
            if 'scores' in result:
                result['scores'] = result['scores'].view(B, L, -1)

        return result

    def get_gate_statistics(self, hidden_states: torch.Tensor) -> Dict[str, float]:
        """
        Compute gating statistics for monitoring retrieval sink behavior.

        Use this to track:
        - Mean gate activation < 0.3: Heavy suppression (possible sink detected)
        - Mean gate activation > 0.7: Most dimensions passing through
        - Variance across dimensions: High variance = selective gating learned

        Returns:
            Dict with gate_R_mean, gate_S_mean, gate_N_mean values
        """
        with torch.no_grad():
            gate_R = torch.sigmoid(self.gate_R(hidden_states)).mean().item()
            gate_S = torch.sigmoid(self.gate_S(hidden_states)).mean().item()
            gate_N = torch.sigmoid(self.gate_N(hidden_states)).mean().item()

        return {
            "gate_R_mean": gate_R,
            "gate_S_mean": gate_S,
            "gate_N_mean": gate_N,
        }


def create_gated_projection_heads(
    hidden_dim: int = 768,
    projection_dim: int = 128,
    gate_init_bias: float = 0.0,
    **kwargs
) -> GatedYRSNProjectionHeads:
    """
    Factory function to create gated projection heads.

    Args:
        hidden_dim: Input hidden dimension
        projection_dim: Output projection dimension
        gate_init_bias: Initial bias for gates (0.0 = neutral)
        **kwargs: Additional config options

    Returns:
        Configured GatedYRSNProjectionHeads instance
    """
    config = ProjectionHeadConfig(
        hidden_dim=hidden_dim,
        projection_dim=projection_dim,
        **kwargs
    )
    return GatedYRSNProjectionHeads(config, gate_init_bias=gate_init_bias)
