"""
Entropy Metrics for RSN Decomposition Quality Assessment

This module provides Shannon entropy calculations for R/S/N components,
enabling entropy-enhanced quality metrics (α_H) per expS5_215.

Key insight (from 2601.19832):
  "Shannon entropy measures information flow quality between scene elements"

The entropy-enhanced α provides:
  - Detection of uncertain quality assessments (high H(R))
  - Better correlation with downstream performance
  - Information-theoretic foundation for quality gating

Reference:
  - exp/series_005/expS5_215_entropy_alpha_doe.md
  - docs/architecture/ALPHA_OMEGA_FORMULA.md
"""

import math
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Union

import numpy as np
import torch


@dataclass
class EntropyMetrics:
    """Container for entropy measurements of RSN components."""
    H_r: float      # Normalized entropy of R component [0,1]
    H_s: float      # Normalized entropy of S component [0,1]
    H_n: float      # Normalized entropy of N component [0,1]
    H_total: float  # Normalized entropy of total R+S+N [0,1]

    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary for JSON serialization."""
        return {
            'H_r': self.H_r,
            'H_s': self.H_s,
            'H_n': self.H_n,
            'H_total': self.H_total,
        }


def compute_shannon_entropy(p: np.ndarray, eps: float = 1e-10) -> float:
    """
    Compute Shannon entropy H(p) = -sum(p * log(p)).

    Args:
        p: Probability distribution (must sum to 1)
        eps: Small constant for numerical stability

    Returns:
        Shannon entropy in nats
    """
    p = np.clip(p, eps, 1.0)
    return -np.sum(p * np.log(p))


def to_probability_distribution(v: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Convert vector to probability distribution.

    Args:
        v: Input vector (any non-negative values)
        eps: Small constant for numerical stability

    Returns:
        Probability distribution (sums to 1)
    """
    v_pos = np.abs(v) + eps
    return v_pos / v_pos.sum()


def compute_entropy_metrics_from_vectors(
    r_vector: np.ndarray,
    s_vector: np.ndarray,
    n_vector: np.ndarray,
) -> EntropyMetrics:
    """
    Compute entropy metrics from R/S/N component vectors.

    This function measures the "spread" or "uncertainty" in each component.
    Low entropy = concentrated signal (more certain)
    High entropy = spread signal (less certain)

    Args:
        r_vector: R component values across dimensions
        s_vector: S component values across dimensions
        n_vector: N component values across dimensions

    Returns:
        EntropyMetrics with normalized entropy values [0,1]
    """
    dim = len(r_vector)
    max_entropy = math.log(dim)  # Maximum possible entropy

    # Convert to probability distributions
    p_r = to_probability_distribution(r_vector)
    p_s = to_probability_distribution(s_vector)
    p_n = to_probability_distribution(n_vector)

    # Combined distribution
    combined = np.concatenate([r_vector, s_vector, n_vector])
    p_total = to_probability_distribution(combined)
    max_entropy_total = math.log(3 * dim)

    # Compute normalized entropies [0,1]
    H_r = compute_shannon_entropy(p_r) / max_entropy if max_entropy > 0 else 0
    H_s = compute_shannon_entropy(p_s) / max_entropy if max_entropy > 0 else 0
    H_n = compute_shannon_entropy(p_n) / max_entropy if max_entropy > 0 else 0
    H_total = compute_shannon_entropy(p_total) / max_entropy_total if max_entropy_total > 0 else 0

    return EntropyMetrics(
        H_r=float(np.clip(H_r, 0, 1)),
        H_s=float(np.clip(H_s, 0, 1)),
        H_n=float(np.clip(H_n, 0, 1)),
        H_total=float(np.clip(H_total, 0, 1)),
    )


def compute_entropy_metrics_from_scalars(
    R: float,
    S: float,
    N: float,
) -> EntropyMetrics:
    """
    Compute entropy metrics from scalar R/S/N values.

    For scalar inputs, we compute entropy of the RSN distribution itself:
    H([R, S, N]) measures how "spread" the quality is across components.

    Low entropy (e.g., [0.9, 0.05, 0.05]) = clear signal
    High entropy (e.g., [0.33, 0.33, 0.34]) = ambiguous signal

    Args:
        R: Relevance score [0,1]
        S: Superfluous score [0,1]
        N: Noise score [0,1]

    Returns:
        EntropyMetrics with normalized entropy values [0,1]
    """
    rsn = np.array([R, S, N])
    max_entropy = math.log(3)  # Maximum for 3-class distribution

    # Normalize RSN to probability distribution
    p_rsn = to_probability_distribution(rsn)

    # Compute entropy of the RSN distribution
    H_rsn = compute_shannon_entropy(p_rsn) / max_entropy

    # For scalar inputs, component entropies are defined as
    # how much each component deviates from uniform
    H_r = 1.0 - abs(R - 1/3) * 3  # High if R near 1/3 (uniform)
    H_s = 1.0 - abs(S - 1/3) * 3
    H_n = 1.0 - abs(N - 1/3) * 3

    return EntropyMetrics(
        H_r=float(np.clip(H_r, 0, 1)),
        H_s=float(np.clip(H_s, 0, 1)),
        H_n=float(np.clip(H_n, 0, 1)),
        H_total=float(np.clip(H_rsn, 0, 1)),
    )


def compute_alpha_entropy(
    R: float,
    S: float,
    N: float,
    entropy_metrics: Optional[EntropyMetrics] = None,
    lambda_weight: float = 0.3,
) -> float:
    """
    Compute entropy-enhanced quality metric α_H.

    Formula:
        α_H = (R + λ·(1 - H_r)) / (R + S + N + λ·H_total)

    Interpretation:
        - Low H_r (concentrated R) → bonus to numerator
        - High H_total (spread signal) → penalty to denominator
        - λ controls entropy influence (default 0.3)

    Args:
        R: Relevance score
        S: Superfluous score
        N: Noise score
        entropy_metrics: Precomputed entropy (optional)
        lambda_weight: Weight for entropy terms [0,1]

    Returns:
        α_H: Entropy-enhanced quality metric [0,1]
    """
    if entropy_metrics is None:
        entropy_metrics = compute_entropy_metrics_from_scalars(R, S, N)

    H_r = entropy_metrics.H_r
    H_total = entropy_metrics.H_total

    # Entropy-enhanced α
    # Low entropy in R is good (add bonus)
    # High total entropy is bad (add penalty)
    numerator = R + lambda_weight * (1 - H_r)
    denominator = R + S + N + lambda_weight * H_total

    alpha_H = numerator / (denominator + 1e-8)

    return float(np.clip(alpha_H, 0, 1))


def compute_alpha_confident(
    R: float,
    S: float,
    N: float,
    entropy_metrics: Optional[EntropyMetrics] = None,
    prior: float = 0.5,
) -> float:
    """
    Compute confidence-weighted α using entropy as uncertainty measure.

    Formula:
        confidence = 1 - H_total
        α_confident = α × confidence + prior × (1 - confidence)

    This blends α toward the prior when entropy is high (uncertain).

    Args:
        R: Relevance score
        S: Superfluous score
        N: Noise score
        entropy_metrics: Precomputed entropy (optional)
        prior: Baseline value for uncertain cases

    Returns:
        α_confident: Confidence-weighted quality metric [0,1]
    """
    if entropy_metrics is None:
        entropy_metrics = compute_entropy_metrics_from_scalars(R, S, N)

    # Standard α
    alpha = R / (R + S + N + 1e-8)

    # Confidence = inverse of entropy
    confidence = 1 - entropy_metrics.H_total

    # Blend toward prior when uncertain
    alpha_confident = alpha * confidence + prior * (1 - confidence)

    return float(np.clip(alpha_confident, 0, 1))


# Batch versions for torch tensors

def compute_entropy_metrics_batch(
    R: torch.Tensor,
    S: torch.Tensor,
    N: torch.Tensor,
) -> Dict[str, torch.Tensor]:
    """
    Compute entropy metrics for a batch of R/S/N values.

    Args:
        R: Relevance scores [batch_size]
        S: Superfluous scores [batch_size]
        N: Noise scores [batch_size]

    Returns:
        Dict with H_r, H_s, H_n, H_total tensors [batch_size]
    """
    # Stack into [batch_size, 3]
    rsn = torch.stack([R, S, N], dim=-1)

    # Normalize to probabilities
    rsn_prob = rsn / (rsn.sum(dim=-1, keepdim=True) + 1e-10)

    # Shannon entropy: -sum(p * log(p))
    log_rsn = torch.log(rsn_prob + 1e-10)
    H_rsn = -torch.sum(rsn_prob * log_rsn, dim=-1)

    # Normalize by max entropy (log(3))
    max_entropy = math.log(3)
    H_total = H_rsn / max_entropy

    # Component-specific entropy (deviation from uniform)
    H_r = 1.0 - torch.abs(R - 1/3) * 3
    H_s = 1.0 - torch.abs(S - 1/3) * 3
    H_n = 1.0 - torch.abs(N - 1/3) * 3

    return {
        'H_r': torch.clamp(H_r, 0, 1),
        'H_s': torch.clamp(H_s, 0, 1),
        'H_n': torch.clamp(H_n, 0, 1),
        'H_total': torch.clamp(H_total, 0, 1),
    }


def compute_alpha_entropy_batch(
    R: torch.Tensor,
    S: torch.Tensor,
    N: torch.Tensor,
    lambda_weight: float = 0.3,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Compute entropy-enhanced α for a batch.

    Args:
        R: Relevance scores [batch_size]
        S: Superfluous scores [batch_size]
        N: Noise scores [batch_size]
        lambda_weight: Weight for entropy terms

    Returns:
        alpha_H: Entropy-enhanced quality [batch_size]
        entropy_metrics: Dict of entropy tensors
    """
    entropy = compute_entropy_metrics_batch(R, S, N)

    numerator = R + lambda_weight * (1 - entropy['H_r'])
    denominator = R + S + N + lambda_weight * entropy['H_total']

    alpha_H = numerator / (denominator + 1e-8)
    alpha_H = torch.clamp(alpha_H, 0, 1)

    return alpha_H, entropy
