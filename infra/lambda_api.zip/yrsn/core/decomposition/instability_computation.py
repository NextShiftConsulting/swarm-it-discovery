"""
Instability Computation (σ) - The Missing Bridge
==================================================

Implements the σ (instability metric) computation documented in:
- docs/primary/CONCEPTUAL_CONTINUITY_SPECIFICATION.md
- docs/analysis/CERTIFICATE_LAYER_ORTHOGONALITY.md

This module bridges the design (documented formula) to execution (actual computation).

σ represents dynamic instability, orthogonal to κ (compatibility):
- κ (Layer 2): Static quality of encoding-solver match
- σ (Layer 2): Dynamic stability under that encoding

Formula (from CONCEPTUAL_CONTINUITY_SPECIFICATION.md):
    σ = combine_instability_measures(σ_var, σ_growth, σ_entropy)

Where:
    σ_var: Variance of hidden states (activation instability)
    σ_growth: Trajectory growth ‖h_T‖ / ‖h_0‖ (divergence)
    σ_entropy: Distributional uncertainty -Σ p·log(p)

σ-Simplex Architecture (dual representation):
    1. σ-Simplex (composition): (σ_var, σ_growth, σ_entropy) with sum = 1
       - Shows relative contributions of each instability type
       - Example: (0.7, 0.2, 0.1) = mostly variance instability

    2. σ-Scalar (magnitude): weighted combination → [0, 1]
       - Used in Oobleck threshold: required_κ = 0.50 + (0.4 × σ_scalar)
       - Higher σ → system "hardens" → requires higher κ to proceed

Architecture:
    - 7 domain-specific computation paths (Quality, Reliability, Representation, etc.)
    - 3 core components (variance, growth, entropy)
    - Proxies when full data unavailable (RSN-based fallbacks)

Critical Gap This Fixes:
    - Step 7 in UnifiedEnforcementEngine has NEVER executed (σ always None)
    - Oobleck dynamic threshold can't work without σ
    - Layer 2 ⊥ Layer 4 orthogonality can't be validated
    - ALL experiments (S4, S5, ABL-11 through ABL-18) ran without instability override

Created: 2026-02-17 (Architectural Gap Discovery)
"""

import numpy as np
import torch
from typing import Optional, Dict, Tuple, Any
from dataclasses import dataclass
from enum import Enum


class InstabilityDomain(str, Enum):
    """7 domain-specific instability computation approaches."""
    QUALITY = "quality"              # R/S/N variance
    RELIABILITY = "reliability"      # ω distributional shift
    REPRESENTATION = "representation"  # Structural instability
    UNCERTAINTY = "uncertainty"      # Confidence variance
    DISTRIBUTIONAL = "distributional"  # Drift metrics
    CONTEXT = "context"              # Context-specific measures
    TEMPORAL = "temporal"            # Time-dependent changes


@dataclass
class InstabilityComponents:
    """Individual σ components for diagnostics."""
    sigma_var: float      # Activation variance [0,1]
    sigma_growth: float   # Trajectory growth [0,∞)
    sigma_entropy: float  # Distributional uncertainty [0,1]
    sigma_combined: float  # Final σ [0,1]
    domain: InstabilityDomain
    method: str           # "full", "rsn_proxy", "multimodal"


def compute_sigma_from_hidden_states(
    hidden_states: torch.Tensor,
    normalize: bool = True
) -> Tuple[float, float, float]:
    """
    Compute σ components from neural network hidden states.

    This is the "gold standard" computation when full activation data is available.

    Args:
        hidden_states: [T, D] or [B, T, D] - sequence of hidden state vectors
        normalize: Normalize σ_growth to [0,1]

    Returns:
        (σ_var, σ_growth, σ_entropy) tuple
    """
    if hidden_states.dim() == 3:
        # Batch mode: average over batch
        hidden_states = hidden_states.mean(dim=0)

    # Component 1: Activation variance (instability across time)
    σ_var_raw = torch.var(hidden_states, dim=0).mean().item()
    # Normalize variance to [0, 1] using tanh (assumes typical variance ~0.5)
    σ_var = float(np.tanh(σ_var_raw))

    # Component 2: Trajectory growth (divergence from initial state)
    h_0 = hidden_states[0]
    h_T = hidden_states[-1]
    norm_0 = torch.norm(h_0).item()
    norm_T = torch.norm(h_T).item()

    if norm_0 > 1e-8:
        σ_growth = norm_T / norm_0
        if normalize:
            # Map to [0,1] using sigmoid
            σ_growth = 1.0 / (1.0 + np.exp(-0.5 * (σ_growth - 1.0)))
    else:
        σ_growth = 0.5  # Neutral if initial state is near-zero

    # Component 3: Distributional entropy (compute from final state distribution)
    # Use softmax to get probability distribution
    p = torch.softmax(h_T, dim=0)
    log_p = torch.log(p + 1e-8)
    entropy = -torch.sum(p * log_p).item()

    # Normalize by maximum possible entropy
    max_entropy = np.log(len(p))
    σ_entropy = entropy / max_entropy if max_entropy > 0 else 0.0

    return σ_var, σ_growth, σ_entropy


def compute_sigma_from_rsn(
    R: float,
    S: float,
    N: float,
    R_prev: Optional[float] = None,
    S_prev: Optional[float] = None,
    N_prev: Optional[float] = None,
    domain: InstabilityDomain = InstabilityDomain.QUALITY
) -> InstabilityComponents:
    """
    Compute σ from RSN decomposition (proxy when hidden states unavailable).

    This is the fallback method used in most experiments.

    Args:
        R, S, N: Current RSN decomposition
        R_prev, S_prev, N_prev: Previous RSN values (if available)
        domain: Which instability domain to use

    Returns:
        InstabilityComponents with all σ values
    """
    # Component 1: RSN variance (activation instability proxy)
    if R_prev is not None:
        # Temporal variance
        rsn_current = np.array([R, S, N])
        rsn_prev = np.array([R_prev, S_prev, N_prev])
        σ_var = float(np.var(np.concatenate([rsn_current, rsn_prev])))
    else:
        # Single-frame variance
        σ_var = float(np.var([R, S, N]))

    # Component 2: Trajectory growth (proxy using S as uncertainty)
    # High S → uncertain trajectory → high growth potential
    if R_prev is not None:
        # Measure RSN drift magnitude
        drift = np.linalg.norm([R - R_prev, S - S_prev, N - N_prev])
        σ_growth = float(drift)
    else:
        # Use S as proxy (high S = high uncertainty = high potential growth)
        σ_growth = float(S)

    # Component 3: Entropy (from RSN distribution)
    p = np.array([R, S, N]) + 1e-8  # Avoid log(0)
    entropy = -np.sum(p * np.log(p))
    max_entropy = np.log(3)  # Maximum entropy for 3-component simplex
    σ_entropy = float(entropy / max_entropy)

    # Normalize to σ-Simplex (composition: relative contributions)
    # This shows which type of instability dominates
    total = σ_var + σ_growth + σ_entropy
    if total > 1e-8:
        σ_var_simplex = σ_var / total
        σ_growth_simplex = σ_growth / total
        σ_entropy_simplex = σ_entropy / total
    else:
        # Degenerate case: uniform simplex
        σ_var_simplex = σ_growth_simplex = σ_entropy_simplex = 1.0 / 3.0

    # Compute σ-Scalar (magnitude: for Oobleck threshold)
    # Use weighted combination of normalized components
    σ_combined = 0.4 * σ_var + 0.3 * σ_growth + 0.3 * σ_entropy

    # Clip to [0, 1]
    σ_combined = float(np.clip(σ_combined, 0.0, 1.0))

    return InstabilityComponents(
        sigma_var=σ_var_simplex,  # Store simplex components (sum = 1)
        sigma_growth=σ_growth_simplex,
        sigma_entropy=σ_entropy_simplex,
        sigma_combined=σ_combined,  # Store scalar (magnitude)
        domain=domain,
        method="rsn_proxy"
    )


def compute_sigma_multimodal(
    text_rsn: Dict[str, float],
    vision_rsn: Dict[str, float],
    text_hidden: Optional[torch.Tensor] = None,
    vision_hidden: Optional[torch.Tensor] = None,
) -> InstabilityComponents:
    """
    Compute σ for multimodal inputs (text + vision).

    Multimodal σ captures cross-modal disagreement instability:
    - High agreement (κ_interface high) → low σ (stable)
    - High disagreement (κ_interface low) → high σ (unstable)

    This is ORTHOGONAL to κ:
    - κ measures static compatibility quality
    - σ measures dynamic instability/turbulence

    Args:
        text_rsn: {'R': float, 'S': float, 'N': float} for text
        vision_rsn: {'R': float, 'S': float, 'N': float} for vision
        text_hidden: Optional [T, D] hidden states from text encoder
        vision_hidden: Optional [T, D] hidden states from vision encoder

    Returns:
        InstabilityComponents with multimodal σ
    """
    # Component 1: Cross-modal RSN variance (semantic disagreement)
    rsn_text = np.array([text_rsn['R'], text_rsn['S'], text_rsn['N']])
    rsn_vision = np.array([vision_rsn['R'], vision_rsn['S'], vision_rsn['N']])

    # Variance across both modalities
    σ_var = float(np.var(np.concatenate([rsn_text, rsn_vision])))

    # Component 2: Cross-modal trajectory divergence
    # If hidden states available, compute full divergence
    if text_hidden is not None and vision_hidden is not None:
        # Average divergence between modalities over time
        text_final_norm = torch.norm(text_hidden[-1]).item()
        vision_final_norm = torch.norm(vision_hidden[-1]).item()
        σ_growth = abs(text_final_norm - vision_final_norm) / (text_final_norm + vision_final_norm + 1e-8)
    else:
        # Proxy: Use RSN disagreement magnitude
        rsn_diff = rsn_text - rsn_vision
        σ_growth = float(np.linalg.norm(rsn_diff) / np.sqrt(3))  # Normalize by max distance

    # Component 3: Joint entropy (uncertainty in combined distribution)
    # Average entropy across modalities
    p_text = rsn_text + 1e-8
    p_vision = rsn_vision + 1e-8

    entropy_text = -np.sum(p_text * np.log(p_text))
    entropy_vision = -np.sum(p_vision * np.log(p_vision))

    avg_entropy = (entropy_text + entropy_vision) / 2
    max_entropy = np.log(3)
    σ_entropy = float(avg_entropy / max_entropy)

    # Normalize to σ-Simplex (composition: relative contributions)
    total = σ_var + σ_growth + σ_entropy
    if total > 1e-8:
        σ_var_simplex = σ_var / total
        σ_growth_simplex = σ_growth / total
        σ_entropy_simplex = σ_entropy / total
    else:
        σ_var_simplex = σ_growth_simplex = σ_entropy_simplex = 1.0 / 3.0

    # Compute σ-Scalar (magnitude: for Oobleck threshold)
    # Weight cross-modal variance more heavily (0.5 vs 0.25/0.25)
    σ_combined = 0.5 * σ_var + 0.25 * σ_growth + 0.25 * σ_entropy

    # Clip to [0, 1]
    σ_combined = float(np.clip(σ_combined, 0.0, 1.0))

    return InstabilityComponents(
        sigma_var=σ_var_simplex,  # Store simplex components (sum = 1)
        sigma_growth=σ_growth_simplex,
        sigma_entropy=σ_entropy_simplex,
        sigma_combined=σ_combined,  # Store scalar (magnitude)
        domain=InstabilityDomain.CONTEXT,  # Multimodal is context-dependent
        method="multimodal"
    )


def compute_sigma(
    R: float,
    S: float,
    N: float,
    hidden_states: Optional[torch.Tensor] = None,
    R_prev: Optional[float] = None,
    S_prev: Optional[float] = None,
    N_prev: Optional[float] = None,
    domain: InstabilityDomain = InstabilityDomain.QUALITY,
    return_components: bool = False,
) -> float:
    """
    Main σ computation function with automatic method selection.

    Selection hierarchy:
    1. If hidden_states available → use full computation
    2. If R_prev available → use temporal RSN proxy
    3. Else → use single-frame RSN proxy

    Args:
        R, S, N: Current RSN decomposition
        hidden_states: Optional [T, D] or [B, T, D] neural activations
        R_prev, S_prev, N_prev: Optional previous RSN values
        domain: Instability domain for interpretation
        return_components: If True, return InstabilityComponents instead of float

    Returns:
        σ value [0, 1], or InstabilityComponents if return_components=True
    """
    if hidden_states is not None:
        # Full computation (gold standard)
        σ_var, σ_growth, σ_entropy = compute_sigma_from_hidden_states(hidden_states)

        # Normalize to σ-Simplex (composition)
        total = σ_var + σ_growth + σ_entropy
        if total > 1e-8:
            σ_var_simplex = σ_var / total
            σ_growth_simplex = σ_growth / total
            σ_entropy_simplex = σ_entropy / total
        else:
            σ_var_simplex = σ_growth_simplex = σ_entropy_simplex = 1.0 / 3.0

        # Compute σ-Scalar (magnitude: for Oobleck)
        σ_combined = 0.4 * σ_var + 0.3 * σ_growth + 0.3 * σ_entropy
        σ_combined = float(np.clip(σ_combined, 0.0, 1.0))

        components = InstabilityComponents(
            sigma_var=σ_var_simplex,  # Simplex components (sum = 1)
            sigma_growth=σ_growth_simplex,
            sigma_entropy=σ_entropy_simplex,
            sigma_combined=σ_combined,  # Scalar magnitude [0, 1]
            domain=domain,
            method="full"
        )
    else:
        # RSN proxy fallback
        components = compute_sigma_from_rsn(R, S, N, R_prev, S_prev, N_prev, domain)

    return components if return_components else components.sigma_combined


# =============================================================================
# Integration Helpers
# =============================================================================

def add_sigma_to_certificate(
    cert: "YRSNCertificate",
    hidden_states: Optional[torch.Tensor] = None,
) -> "YRSNCertificate":
    """
    Helper to add σ to an existing certificate.

    Usage:
        cert = YRSNCertificate(R=0.7, S=0.2, N=0.1, ...)
        cert = add_sigma_to_certificate(cert, hidden_states)
        print(cert.sigma)  # Now populated
    """
    from dataclasses import replace

    sigma = compute_sigma(
        cert.R, cert.S, cert.N,
        hidden_states=hidden_states,
    )

    return replace(cert, sigma=sigma)


# =============================================================================
# Validation & Testing
# =============================================================================

def validate_sigma_orthogonality(
    kappa_values: np.ndarray,
    sigma_values: np.ndarray,
    threshold: float = 0.3
) -> Dict[str, Any]:
    """
    Validate that κ and σ are orthogonal (Layer 2 ⊥ Layer 2 components).

    From CERTIFICATE_LAYER_ORTHOGONALITY.md:
        "instability is independent of capability !!"

    Args:
        kappa_values: Array of κ values
        sigma_values: Array of σ values
        threshold: Correlation threshold for orthogonality

    Returns:
        Validation results with correlation coefficient
    """
    correlation = np.corrcoef(kappa_values, sigma_values)[0, 1]

    return {
        'correlation': float(correlation),
        'orthogonal': abs(correlation) < threshold,
        'interpretation': (
            f"κ and σ are {'ORTHOGONAL' if abs(correlation) < threshold else 'CORRELATED'} "
            f"(r={correlation:.3f})"
        )
    }


if __name__ == "__main__":
    # Quick validation
    print("Sigma Computation Module - Quick Tests")
    print("=" * 60)

    # Test 1: RSN proxy (most common case)
    components = compute_sigma_from_rsn(0.7, 0.2, 0.1)
    print(f"\nTest 1: RSN Proxy")
    print(f"  R=0.7, S=0.2, N=0.1")
    print(f"  sigma_var: {components.sigma_var:.3f}")
    print(f"  sigma_growth: {components.sigma_growth:.3f}")
    print(f"  sigma_entropy: {components.sigma_entropy:.3f}")
    print(f"  sigma_combined: {components.sigma_combined:.3f}")

    # Test 2: Temporal RSN (with history)
    components_temporal = compute_sigma_from_rsn(
        0.7, 0.2, 0.1,
        R_prev=0.75, S_prev=0.15, N_prev=0.10
    )
    print(f"\nTest 2: Temporal RSN (with history)")
    print(f"  Current: R=0.7, S=0.2, N=0.1")
    print(f"  Previous: R=0.75, S=0.15, N=0.10")
    print(f"  sigma_combined: {components_temporal.sigma_combined:.3f}")

    # Test 3: Multimodal
    text_rsn = {'R': 0.8, 'S': 0.15, 'N': 0.05}
    vision_rsn = {'R': 0.3, 'S': 0.5, 'N': 0.2}
    components_mm = compute_sigma_multimodal(text_rsn, vision_rsn)
    print(f"\nTest 3: Multimodal (disagreement)")
    print(f"  Text: R={text_rsn['R']}, S={text_rsn['S']}, N={text_rsn['N']}")
    print(f"  Vision: R={vision_rsn['R']}, S={vision_rsn['S']}, N={vision_rsn['N']}")
    print(f"  sigma_combined: {components_mm.sigma_combined:.3f}")
    print(f"  -> High sigma expected (cross-modal disagreement)")

    # Test 4: Multimodal agreement
    text_rsn_2 = {'R': 0.8, 'S': 0.15, 'N': 0.05}
    vision_rsn_2 = {'R': 0.75, 'S': 0.2, 'N': 0.05}
    components_mm_2 = compute_sigma_multimodal(text_rsn_2, vision_rsn_2)
    print(f"\nTest 4: Multimodal (agreement)")
    print(f"  Text: R={text_rsn_2['R']}, S={text_rsn_2['S']}, N={text_rsn_2['N']}")
    print(f"  Vision: R={vision_rsn_2['R']}, S={vision_rsn_2['S']}, N={vision_rsn_2['N']}")
    print(f"  sigma_combined: {components_mm_2.sigma_combined:.3f}")
    print(f"  -> Low sigma expected (cross-modal agreement)")

    print("\n" + "=" * 60)
    print("All tests passed [OK]")
