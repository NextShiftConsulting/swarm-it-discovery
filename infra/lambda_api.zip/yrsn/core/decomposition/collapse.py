"""
YRSN Collapse Detection S4: Comprehensive Detection with Geometric Insights

This module integrates all findings from Series 4 experiments into a unified
collapse detection system. It supersedes the legacy collapse.py with:

KEY S4 FINDINGS INCORPORATED:
============================

1. SIGNAL ROLES (S4-000, S4-048):
   - θ (sample_theta): TYPE classification - discriminates collapse types
   - RSN: DRIFT detection - 29 steps faster than geometric radius
   - α (alpha): ERROR detection - Cohen's d = 3.42, AUROC = 0.93
   - ω (omega): OOD detection - AUROC = 0.806
   - Signals are correlated (r>0.94) in rotor architecture - redundant by design

2. DOMAIN = CALIBRATION (S4-002b, S4-033):
   - COMPRESSION: Overconfident, 22-37% error rate, needs scrutiny
   - EXPANSION: Well-calibrated, 1-3% error rate, reliable
   - NEUTRAL: Intermediate calibration

3. GEOMETRIC INVARIANTS (S4-036, S4-083):
   - R+S+N=1 holds to machine precision (2e-16)
   - 100% RSN tampering detection
   - Scale indicates RSN_COLLAPSE (100% agreement)

4. PERFORMANCE (S4-044, S4-085):
   - 25x faster than MC-Dropout
   - 10x faster than Deep Ensembles
   - 2441 samples/sec throughput
   - Single forward pass uncertainty quantification

5. DRIFT DETECTION (S4-090):
   - Omega drops 15.4% under drift
   - Theta shifts 40° under distribution shift
   - Domain distribution changes dramatically (42% swing)

6. FRAGILITY FINGERPRINTING (S4-102c, S4-103):
   - 7D YRSN fingerprint for hardware/OOD health
   - 100% detection rate (vs 13% legacy = 7.7× improvement)
   - Type-specific signatures: OOD = "attenuation", in-dist = "noise_snr"

7. EXPLORE-EXPLOIT (S4-104, S4-105):
   - COMPRESSION samples: higher learning rate, explore more
   - EXPANSION samples: stable, exploit more

Usage:
    from yrsn.core.decomposition.collapse import (
        CollapseDetector,
        detect_collapse,
        RealTimeCollapseMonitor,
    )

    # Single sample detection
    result = detect_collapse(
        R=0.5, S=0.3, N=0.2,
        theta=-12.0, scale=1.05,
        omega=0.85, alpha=0.72,
    )

    # Real-time monitoring
    monitor = RealTimeCollapseMonitor(projection)
    for features in stream:
        status = monitor.update(features)
        if status.requires_action:
            handle_collapse(status)
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple, Any, Callable
import numpy as np


# =============================================================================
# SIGNAL ROLE CONSTANTS (from S4-000, S4-048)
# =============================================================================

class SignalRole(str, Enum):
    """
    Signal roles discovered in S4 experiments.

    Each signal has a primary purpose based on empirical validation.
    """
    THETA = "TYPE_CLASSIFICATION"      # θ discriminates collapse types (H4: AUC=1.0)
    RSN = "DRIFT_DETECTION"            # RSN is 29 steps faster than radius
    ALPHA = "ERROR_DETECTION"          # Cohen's d=3.42, AUROC=0.93
    OMEGA = "OOD_DETECTION"            # AUROC=0.806 for ID vs OOD
    SCALE = "RSN_COLLAPSE_INDICATOR"   # 100% agreement with traditional method


# =============================================================================
# GEOMETRIC DOMAIN (from S4-002b) - CALIBRATION INTERPRETATION
# =============================================================================

class GeometricDomain(str, Enum):
    """
    Geometric domain classification with calibration interpretation.

    S4-002b FINDING: Domains measure CALIBRATION, not clustering.
    - COMPRESSION = Overconfident (high certainty, prone to errors)
    - EXPANSION = Well-calibrated (hedges bets, fewer errors)
    - NEUTRAL = Intermediate calibration quality
    """
    COMPRESSION = "COMPRESSION"   # theta < -5°, error_rate ~22-37%
    NEUTRAL = "NEUTRAL"           # -5° ≤ theta ≤ +5°, intermediate
    EXPANSION = "EXPANSION"       # theta > +5°, error_rate ~1-3%
    UNKNOWN = "UNKNOWN"


# Calibration statistics from S4-002b, S4-033
DOMAIN_CALIBRATION = {
    GeometricDomain.COMPRESSION: {
        'error_rate': 0.226,       # 22.6% from S4-002b
        'overconfidence': 0.131,   # 13.1% overconfident
        'ece': 0.128,              # Expected Calibration Error
        'action': 'SCRUTINIZE',    # Requires validation
    },
    GeometricDomain.NEUTRAL: {
        'error_rate': 0.10,        # ~10%
        'overconfidence': 0.10,
        'ece': 0.144,
        'action': 'MONITOR',
    },
    GeometricDomain.EXPANSION: {
        'error_rate': 0.030,       # 3.0% from S4-002b
        'overconfidence': 0.020,   # 2.0% overconfident
        'ece': 0.017,              # Well-calibrated
        'action': 'TRUST',         # Reliable predictions
    },
}


# =============================================================================
# SEVERITY WITH CALIBRATED THRESHOLDS (from S4-003)
# =============================================================================

class Severity(str, Enum):
    """Severity levels with calibrated thresholds from S4-003."""
    MILD = "MILD"         # Normal operation
    MODERATE = "MODERATE" # Elevated risk
    SEVERE = "SEVERE"     # Intervention needed
    UNKNOWN = "UNKNOWN"


# Calibrated thresholds from S4-003 "tight" configuration
SEVERITY_THRESHOLDS = {
    'scale_severe_low': 0.80,    # (was 0.70)
    'scale_severe_high': 1.30,   # (was 1.50)
    'scale_moderate_low': 0.90,
    'scale_moderate_high': 1.15,
    'corr_severe': 0.30,         # (was 0.20)
    'corr_moderate': 0.50,
}


# =============================================================================
# COLLAPSE TYPE (extended from legacy with S4 insights)
# =============================================================================

class CollapseType(str, Enum):
    """
    Collapse types with geometric domain associations.

    S4-000 FINDING: θ perfectly discriminates some type pairs (HALL vs O_POIS: AUC=1.0)
    """
    NONE = "NONE"

    # Quality Domain (from R/S/N) - typically COMPRESSION
    POISONING = "POISONING"
    DISTRACTION = "DISTRACTION"
    CONFLICT = "CONFLICT"
    CLASH = "CLASH"

    # Reliability Domain (from omega) - mixed domains
    HALLUCINATION = "HALLUCINATION"    # θ = +64° (EXPANSION)
    O_POISONING = "O_POISONING"        # θ = -71° (COMPRESSION)
    DRIFT = "DRIFT"

    # Representation Domain
    RSN_COLLAPSE = "RSN_COLLAPSE"      # θ = 48°, scale → 0
    POSTERIOR_COLLAPSE = "POSTERIOR_COLLAPSE"
    MODE_COLLAPSE = "MODE_COLLAPSE"

    # Uncertainty Domain
    OVERCONFIDENCE = "OVERCONFIDENCE"
    EPISTEMIC_SPIKE = "EPISTEMIC_SPIKE"
    ALEATORIC_DOMINANCE = "ALEATORIC_DOMINANCE"

    # Distributional Domain
    DISTRIBUTIONAL_SHIFT = "DISTRIBUTIONAL_SHIFT"
    GRADUAL_DRIFT = "GRADUAL_DRIFT"
    CONFIRMED_DRIFT = "CONFIRMED_DRIFT"


# Theta signatures by type (from S4-000)
TYPE_THETA_SIGNATURES = {
    CollapseType.O_POISONING: {'mean': -71.0, 'std': 33.5},
    CollapseType.RSN_COLLAPSE: {'mean': 48.0, 'std': 0.2},
    CollapseType.CONFLICT: {'mean': 55.9, 'std': 3.2},
    CollapseType.DISTRACTION: {'mean': 56.4, 'std': 2.3},
    CollapseType.POISONING: {'mean': 58.8, 'std': 2.1},
    CollapseType.NONE: {'mean': 58.9, 'std': 2.0},
    CollapseType.HALLUCINATION: {'mean': 63.9, 'std': 2.0},
}


# =============================================================================
# COLLAPSE ANALYSIS RESULT
# =============================================================================

@dataclass
class CollapseAnalysis:
    """
    Comprehensive collapse analysis incorporating all S4 findings.

    Provides:
    - Primary collapse type with confidence
    - Geometric domain (calibration interpretation)
    - Multi-signal evidence (α, ω, θ, scale)
    - Fragility assessment (hardware/OOD health)
    - Actionable severity with explore/exploit guidance
    """
    # Primary detection
    collapse_type: CollapseType
    confidence: float
    severity: Severity

    # Geometric domain (S4-002b: calibration interpretation)
    geometric_domain: GeometricDomain
    calibration_risk: float  # 0-1, based on domain

    # Core YRSN signals
    R: float
    S: float
    N: float
    theta: Optional[float] = None
    scale: Optional[float] = None
    alpha: Optional[float] = None
    omega: Optional[float] = None

    # Signal-specific scores (S4-000: each signal has a role)
    error_score: float = 0.0       # From alpha (S4-033)
    ood_score: float = 0.0         # From omega (S4-046)
    drift_score: float = 0.0       # From RSN dynamics (S4-090)
    type_score: float = 0.0        # From theta (S4-000)

    # Fragility assessment (S4-102c)
    fragility_fingerprint: Optional[List[float]] = None
    fragility_type: Optional[str] = None
    fragility_severity: float = 0.0

    # Composite label (DOMAIN/TYPE/SEVERITY)
    composite_label: Optional[str] = None

    # Explore/exploit guidance (S4-104, S4-105)
    learning_rate_multiplier: float = 1.0
    strategy: str = "NEUTRAL"  # EXPLORE, EXPLOIT, or NEUTRAL

    # Multi-label detection (all triggered types)
    triggered_types: List[CollapseType] = field(default_factory=list)
    type_scores: Dict[str, float] = field(default_factory=dict)

    # Invariant verification (S4-036, S4-083)
    simplex_violation: float = 0.0
    invariant_valid: bool = True

    # Model alerts
    alerts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return {
            'collapse_type': self.collapse_type.value,
            'confidence': self.confidence,
            'severity': self.severity.value,
            'geometric_domain': self.geometric_domain.value,
            'calibration_risk': self.calibration_risk,
            'R': self.R, 'S': self.S, 'N': self.N,
            'theta': self.theta,
            'scale': self.scale,
            'alpha': self.alpha,
            'omega': self.omega,
            'error_score': self.error_score,
            'ood_score': self.ood_score,
            'drift_score': self.drift_score,
            'type_score': self.type_score,
            'fragility_type': self.fragility_type,
            'fragility_severity': self.fragility_severity,
            'composite_label': self.composite_label,
            'strategy': self.strategy,
            'learning_rate_multiplier': self.learning_rate_multiplier,
            'triggered_types': [t.value for t in self.triggered_types],
            'simplex_violation': self.simplex_violation,
            'invariant_valid': self.invariant_valid,
            'alerts': self.alerts,
        }

    @property
    def is_collapsed(self) -> bool:
        """True if any collapse detected."""
        return self.collapse_type != CollapseType.NONE

    @property
    def requires_action(self) -> bool:
        """True if severity warrants intervention."""
        return self.severity in (Severity.MODERATE, Severity.SEVERE)

    @property
    def is_trustworthy(self) -> bool:
        """
        True if prediction can be trusted.

        Based on S4-002b: EXPANSION domain has 3% error rate.
        """
        return (
            self.geometric_domain == GeometricDomain.EXPANSION and
            self.calibration_risk < 0.1 and
            self.invariant_valid
        )


# =============================================================================
# COLLAPSE DETECTOR S4
# =============================================================================

class CollapseDetector:
    """
    Comprehensive collapse detector incorporating all S4 findings.

    SIGNAL USAGE (from S4-000, S4-048):
    - θ (theta): Used for TYPE classification
    - RSN: Used for DRIFT detection (29 steps faster than radius)
    - α (alpha): Used for ERROR detection (Cohen's d = 3.42)
    - ω (omega): Used for OOD detection (AUROC = 0.806)
    - scale: Used for RSN_COLLAPSE detection (100% agreement)

    DOMAIN INTERPRETATION (from S4-002b):
    - COMPRESSION: Overconfident, 22-37% error rate
    - EXPANSION: Well-calibrated, 1-3% error rate

    PERFORMANCE (from S4-044, S4-085):
    - Single forward pass (no ensembles needed)
    - 25x faster than MC-Dropout
    - 2441 samples/sec throughput
    """

    # Detection thresholds (calibrated from S4 experiments)
    THRESHOLDS = {
        # Quality domain (S4-033)
        'poisoning_n': 0.30,
        'distraction_s': 0.40,
        'confusion_n': 0.20,
        'confusion_s': 0.25,
        'conflict_n': 0.20,   # Alias for confusion_n (used in detect())
        'conflict_s': 0.25,   # Alias for confusion_s (used in detect())
        'clash_s_var': 0.10,

        # Reliability domain (S4-046, S4-090)
        'hallucination_alpha': 0.70,
        'hallucination_omega': 0.50,
        'o_poisoning_r': 0.50,
        'o_poisoning_omega': 0.50,
        'drift_omega': 0.35,
        'drift_omega_drop': 0.05,  # 5% drop from S4-090

        # RSN collapse (S4-000)
        'rsn_collapse_delta': 0.15,
        'rsn_collapse_scale': 0.1,  # scale < 0.1 = RSN collapse

        # Geometric domain (S4-002b)
        'compression_theta': -5.0,
        'expansion_theta': 5.0,

        # Alpha error detection (S4-033)
        'error_alpha_high': 0.70,  # High alpha = likely correct
        'error_alpha_low': 0.30,   # Low alpha = likely error

        # Healthy state (S4-033)
        'healthy_r': 0.45,
        'healthy_s_max': 0.38,
        'healthy_n_max': 0.28,
        'healthy_omega': 0.40,
    }

    def __init__(self, thresholds: Optional[Dict[str, float]] = None):
        """
        Initialize detector with optional threshold overrides.

        Args:
            thresholds: Custom threshold values to override defaults
        """
        self.thresholds = {**self.THRESHOLDS}
        if thresholds:
            self.thresholds.update(thresholds)

        # Baseline for drift detection (S4-090)
        self.baseline_omega: Optional[float] = None
        self.baseline_rsn: Optional[Tuple[float, float, float]] = None

    def detect(
        self,
        R: float,
        S: float,
        N: float,
        theta: Optional[float] = None,
        scale: Optional[float] = None,
        alpha: Optional[float] = None,
        omega: Optional[float] = None,
        correlation: Optional[float] = None,
        source_S_values: Optional[List[float]] = None,
        # Advanced inputs
        fragility_fingerprint: Optional[List[float]] = None,
        previous_rsn: Optional[Tuple[float, float, float]] = None,
    ) -> CollapseAnalysis:
        """
        Detect collapse with full S4 signal integration.

        This method implements the comprehensive detection logic from S4:
        1. Verify simplex invariant (S4-036)
        2. Classify geometric domain → calibration risk (S4-002b)
        3. Compute signal-specific scores (S4-000)
        4. Detect collapse types with priority ordering
        5. Assess severity with calibrated thresholds (S4-003)
        6. Generate explore/exploit guidance (S4-105)

        Args:
            R, S, N: RSN components (must sum to 1)
            theta: Rotation angle from rotor (degrees)
            scale: Scale parameter from rotor
            alpha: Quality signal (R / (R+S+N))
            omega: OOD/reliability signal
            correlation: N-error correlation
            source_S_values: Per-source S values for CLASH detection
            fragility_fingerprint: 7D fingerprint from YRSNFragilityMonitor
            previous_rsn: Previous (R, S, N) for drift detection

        Returns:
            CollapseAnalysis with comprehensive analysis
        """
        t = self.thresholds

        # =====================================================================
        # 1. VERIFY SIMPLEX INVARIANT (S4-036, S4-083)
        # =====================================================================
        simplex_violation = abs(R + S + N - 1.0)
        invariant_valid = simplex_violation < 1e-6

        # =====================================================================
        # 2. CLASSIFY GEOMETRIC DOMAIN (S4-002b)
        # =====================================================================
        if theta is not None:
            if theta < t['compression_theta']:
                geo_domain = GeometricDomain.COMPRESSION
            elif theta > t['expansion_theta']:
                geo_domain = GeometricDomain.EXPANSION
            else:
                geo_domain = GeometricDomain.NEUTRAL
        else:
            geo_domain = GeometricDomain.UNKNOWN

        # Calibration risk from domain (S4-002b, S4-033)
        calibration_risk = DOMAIN_CALIBRATION.get(
            geo_domain, {'error_rate': 0.1}
        )['error_rate']

        # =====================================================================
        # 3. COMPUTE SIGNAL-SPECIFIC SCORES (S4-000)
        # =====================================================================

        # Alpha-based error score (S4-033: Cohen's d = 3.42)
        if alpha is not None:
            # Low alpha = high error probability
            error_score = max(0, 1.0 - alpha)
        else:
            error_score = N + 0.5 * S  # Fallback to RSN-based

        # Omega-based OOD score (S4-046: AUROC = 0.806)
        if omega is not None:
            # Low omega = high OOD probability
            ood_score = max(0, 1.0 - omega)
        else:
            ood_score = 0.0

        # RSN-based drift score (S4-090: 29 steps faster than radius)
        if previous_rsn is not None:
            prev_R, prev_S, prev_N = previous_rsn
            rsn_change = abs(R - prev_R) + abs(S - prev_S) + abs(N - prev_N)
            drift_score = min(1.0, rsn_change * 5)  # Scale to 0-1
        elif omega is not None and self.baseline_omega is not None:
            # Omega drop detection (S4-090: 15.4% drop = drift)
            omega_drop = self.baseline_omega - omega
            drift_score = max(0, omega_drop / 0.20)  # Normalize to 20% = 1.0
        else:
            drift_score = 0.0

        # Theta-based type score (S4-000: perfect discrimination)
        if theta is not None:
            # Distance from healthy (theta ~ 59°)
            type_score = min(1.0, abs(theta - 59.0) / 100.0)
        else:
            type_score = 0.0

        # =====================================================================
        # 4. DETECT COLLAPSE TYPES (priority ordering)
        # =====================================================================
        type_scores = {}
        triggered_types = []

        # Priority 0: RSN_COLLAPSE (S4-000: scale < 0.1 = 100% detection)
        if scale is not None and scale < t['rsn_collapse_scale']:
            type_scores['RSN_COLLAPSE'] = 1.0
            triggered_types.append(CollapseType.RSN_COLLAPSE)
        else:
            rsn_score = self._score_rsn_collapse(R, S, N)
            if rsn_score > 0.5:
                type_scores['RSN_COLLAPSE'] = rsn_score
                triggered_types.append(CollapseType.RSN_COLLAPSE)

        # Priority 1: Reliability domain (omega-based)
        if omega is not None:
            # DRIFT (S4-090: omega < 0.35)
            if omega < t['drift_omega']:
                drift_type_score = (t['drift_omega'] - omega) / t['drift_omega']
                type_scores['DRIFT'] = drift_type_score
                triggered_types.append(CollapseType.DRIFT)

            # HALLUCINATION (S4-000: θ = 64° = highest)
            if alpha is not None and alpha > t['hallucination_alpha'] and omega < t['hallucination_omega']:
                type_scores['HALLUCINATION'] = 0.8
                triggered_types.append(CollapseType.HALLUCINATION)

            # O_POISONING (S4-000: θ = -71° = lowest)
            if R > t['o_poisoning_r'] and omega < t['o_poisoning_omega']:
                type_scores['O_POISONING'] = 0.7
                triggered_types.append(CollapseType.O_POISONING)

        # Priority 2: Quality domain
        # POISONING
        if N >= t['poisoning_n']:
            type_scores['POISONING'] = (N - t['poisoning_n']) / (1 - t['poisoning_n'])
            triggered_types.append(CollapseType.POISONING)

        # DISTRACTION
        if S >= t['distraction_s']:
            type_scores['DISTRACTION'] = (S - t['distraction_s']) / (1 - t['distraction_s'])
            triggered_types.append(CollapseType.DISTRACTION)

        # CONFLICT (compound)
        if N > t['conflict_n'] and S > t['conflict_s']:
            type_scores['CONFLICT'] = 0.8
            triggered_types.append(CollapseType.CONFLICT)

        # CLASH (source variance)
        if source_S_values and len(source_S_values) >= 2:
            s_var = np.var(source_S_values)
            if s_var > t['clash_s_var']:
                type_scores['CLASH'] = min(1.0, s_var / t['clash_s_var'])
                triggered_types.append(CollapseType.CLASH)

        # Select dominant type
        if type_scores:
            dominant = max(type_scores.items(), key=lambda x: x[1])
            collapse_type = CollapseType(dominant[0])
            confidence = dominant[1]
        else:
            collapse_type = CollapseType.NONE
            confidence = 1.0

        # =====================================================================
        # 5. ASSESS SEVERITY (S4-003 calibrated thresholds)
        # =====================================================================
        severity = self._classify_severity(scale, correlation)

        # =====================================================================
        # 6. FRAGILITY ASSESSMENT (S4-102c)
        # =====================================================================
        fragility_type = None
        fragility_severity = 0.0

        if fragility_fingerprint is not None and len(fragility_fingerprint) == 7:
            fragility_type, fragility_severity = self._classify_fragility(
                fragility_fingerprint
            )

        # =====================================================================
        # 7. EXPLORE/EXPLOIT GUIDANCE (S4-104, S4-105)
        # =====================================================================
        if geo_domain == GeometricDomain.COMPRESSION:
            # COMPRESSION: higher LR, explore (S4-105: 100% explore)
            strategy = "EXPLORE"
            lr_multiplier = 1.5
        elif geo_domain == GeometricDomain.EXPANSION:
            # EXPANSION: stable, exploit (S4-105: 37% explore)
            strategy = "EXPLOIT"
            lr_multiplier = 0.8
        else:
            strategy = "NEUTRAL"
            lr_multiplier = 1.0

        # =====================================================================
        # 8. BUILD COMPOSITE LABEL
        # =====================================================================
        composite = f"{geo_domain.value}/{collapse_type.value}/{severity.value}"

        # =====================================================================
        # 9. GENERATE ALERTS
        # =====================================================================
        alerts = []
        if theta is not None and abs(theta) > 20:
            alerts.append("THETA_EXTREME")
        if scale is not None:
            if scale < 0.80:
                alerts.append("SCALE_COLLAPSE")
            elif scale > 1.30:
                alerts.append("SCALE_EXPLOSION")
        if not invariant_valid:
            alerts.append("SIMPLEX_VIOLATION")
        if calibration_risk > 0.20:
            alerts.append("HIGH_CALIBRATION_RISK")

        return CollapseAnalysis(
            collapse_type=collapse_type,
            confidence=confidence,
            severity=severity,
            geometric_domain=geo_domain,
            calibration_risk=calibration_risk,
            R=R, S=S, N=N,
            theta=theta,
            scale=scale,
            alpha=alpha,
            omega=omega,
            error_score=error_score,
            ood_score=ood_score,
            drift_score=drift_score,
            type_score=type_score,
            fragility_fingerprint=fragility_fingerprint,
            fragility_type=fragility_type,
            fragility_severity=fragility_severity,
            composite_label=composite,
            learning_rate_multiplier=lr_multiplier,
            strategy=strategy,
            triggered_types=triggered_types,
            type_scores=type_scores,
            simplex_violation=simplex_violation,
            invariant_valid=invariant_valid,
            alerts=alerts,
        )

    def _score_rsn_collapse(self, R: float, S: float, N: float) -> float:
        """Score RSN_COLLAPSE: R ≈ S ≈ N."""
        delta_rs = abs(R - S)
        delta_sn = abs(S - N)
        threshold = self.thresholds['rsn_collapse_delta']

        if delta_rs < threshold and delta_sn < threshold:
            avg_delta = (delta_rs + delta_sn) / 2
            return 1.0 - (avg_delta / threshold)
        return 0.0

    def _classify_severity(
        self,
        scale: Optional[float],
        correlation: Optional[float],
    ) -> Severity:
        """Classify severity with S4-003 calibrated thresholds."""
        t = SEVERITY_THRESHOLDS

        if scale is None and correlation is None:
            return Severity.UNKNOWN

        # SEVERE conditions
        if scale is not None:
            if scale < t['scale_severe_low'] or scale > t['scale_severe_high']:
                return Severity.SEVERE
        if correlation is not None and correlation < t['corr_severe']:
            return Severity.SEVERE

        # MODERATE conditions
        if scale is not None:
            if scale < t['scale_moderate_low'] or scale > t['scale_moderate_high']:
                return Severity.MODERATE
        if correlation is not None and correlation < t['corr_moderate']:
            return Severity.MODERATE

        return Severity.MILD

    def _classify_fragility(
        self,
        fingerprint: List[float],
    ) -> Tuple[str, float]:
        """
        Classify fragility type from 7D fingerprint (S4-102c).

        Fingerprint: [theta, radius, rsn, omega, angular_coh, boundary_prox, alpha_var]
        """
        from yrsn.core.decomposition.rsn_first_monitor import YRSNFragilityMonitor

        # Signatures from S4-102c
        signatures = {
            'attenuation': np.array([0.18, 0.01, 0.09, -0.95, 0.00, 0.54, -0.08]),
            'stuck': np.array([-0.06, 0.05, -0.14, -0.98, 0.00, 0.36, -0.37]),
            'quantization': np.array([-0.01, -0.01, 0.00, -0.91, 0.00, 0.01, 0.06]),
            'noise_snr': np.array([-0.33, 0.11, -0.33, -0.99, 0.00, 0.09, -0.62]),
        }

        fp = np.array(fingerprint)
        best_type = 'unknown'
        best_dist = float('inf')

        for ftype, sig in signatures.items():
            dist = np.linalg.norm(fp - sig)
            if dist < best_dist:
                best_dist = dist
                best_type = ftype

        # Severity from fingerprint norm
        severity = min(1.0, np.linalg.norm(fp) / 2.0)

        return best_type, severity

    def set_baseline(self, omega: float, rsn: Tuple[float, float, float]):
        """Set baseline for drift detection (S4-090)."""
        self.baseline_omega = omega
        self.baseline_rsn = rsn


# =============================================================================
# REAL-TIME COLLAPSE MONITOR (moved to yrsn/core/decomposition/monitor.py)
# Re-exported here for backward compatibility
# =============================================================================

from .monitor import MonitorStatus, RealTimeCollapseMonitor


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def detect_collapse(
    R: float,
    S: float,
    N: float,
    theta: Optional[float] = None,
    scale: Optional[float] = None,
    alpha: Optional[float] = None,
    omega: Optional[float] = None,
    correlation: Optional[float] = None,
    **kwargs,
) -> CollapseAnalysis:
    """
    Detect collapse with full S4 signal integration.

    Convenience wrapper around CollapseDetector.

    Args:
        R, S, N: RSN components (must sum to 1)
        theta: Rotation angle from rotor (degrees)
        scale: Scale parameter from rotor
        alpha: Quality signal
        omega: OOD/reliability signal
        correlation: N-error correlation
        **kwargs: Additional parameters for advanced detection

    Returns:
        CollapseAnalysis with comprehensive analysis

    Example:
        >>> result = detect_collapse(R=0.5, S=0.3, N=0.2, theta=-12.0)
        >>> print(result.geometric_domain)
        GeometricDomain.COMPRESSION
        >>> print(result.calibration_risk)
        0.226
    """
    detector = CollapseDetector()
    return detector.detect(
        R=R, S=S, N=N,
        theta=theta,
        scale=scale,
        alpha=alpha,
        omega=omega,
        correlation=correlation,
        **kwargs,
    )


def get_signal_roles() -> Dict[str, str]:
    """
    Get the role of each YRSN signal (from S4-000).

    Returns:
        Dictionary mapping signal name to its primary role.
    """
    return {
        'theta': 'TYPE_CLASSIFICATION - discriminates collapse types (AUC=1.0 for HALL vs O_POIS)',
        'RSN': 'DRIFT_DETECTION - 29 steps faster than geometric radius',
        'alpha': 'ERROR_DETECTION - Cohen\'s d=3.42, AUROC=0.93',
        'omega': 'OOD_DETECTION - AUROC=0.806 for ID vs OOD',
        'scale': 'RSN_COLLAPSE_INDICATOR - 100% agreement with traditional method',
    }


def get_domain_calibration(domain: GeometricDomain) -> Dict[str, Any]:
    """
    Get calibration statistics for a domain (from S4-002b).

    Args:
        domain: Geometric domain

    Returns:
        Dictionary with error_rate, overconfidence, ece, action
    """
    return DOMAIN_CALIBRATION.get(domain, {
        'error_rate': 0.10,
        'overconfidence': 0.10,
        'ece': 0.10,
        'action': 'MONITOR',
    })


# =============================================================================
# HARDWARE HEALTH ALERTS (from S4-102c, S4-103)
# =============================================================================

class HardwareAlertType(str, Enum):
    """
    Hardware health alert types from S4-102c fragility fingerprinting.

    Each type has a unique 7D YRSN signature that enables:
    - 100% detection rate (vs 13% legacy = 7.7× improvement)
    - 100% type classification accuracy
    """
    NONE = "NONE"
    ATTENUATION = "ATTENUATION"      # Signal strength degradation
    STUCK_AT = "STUCK_AT"            # Stuck-at faults (weights zeroed)
    QUANTIZATION = "QUANTIZATION"    # Quantization artifacts
    NOISE_SNR = "NOISE_SNR"          # SNR degradation (in-distribution noise)
    UNKNOWN = "UNKNOWN"


# 7D YRSN fingerprint signatures (from S4-102c)
# [theta, radius, rsn, omega, angular_coh, boundary_prox, alpha_var]
HARDWARE_SIGNATURES = {
    HardwareAlertType.ATTENUATION: np.array([0.18, 0.01, 0.09, -0.95, 0.00, 0.54, -0.08]),
    HardwareAlertType.STUCK_AT: np.array([-0.06, 0.05, -0.14, -0.98, 0.00, 0.36, -0.37]),
    HardwareAlertType.QUANTIZATION: np.array([-0.01, -0.01, 0.00, -0.91, 0.00, 0.01, 0.06]),
    HardwareAlertType.NOISE_SNR: np.array([-0.33, 0.11, -0.33, -0.99, 0.00, 0.09, -0.62]),
}

# Severity signals per hardware type (from S4-102c)
HARDWARE_SEVERITY_SIGNALS = {
    HardwareAlertType.ATTENUATION: 'theta',           # Theta increases with attenuation
    HardwareAlertType.STUCK_AT: 'boundary_proximity', # Stuck changes boundary position
    HardwareAlertType.QUANTIZATION: 'boundary_proximity',
    HardwareAlertType.NOISE_SNR: 'theta',             # Theta crashes with SNR degradation
}


@dataclass
class HardwareHealthStatus:
    """
    Hardware health status from YRSN fragility fingerprinting.

    From S4-102c: 7D fingerprint achieves 100% detection, 100% classification.
    """
    is_healthy: bool
    alert_type: HardwareAlertType
    severity: float  # 0-1
    confidence: float  # Classification confidence
    fingerprint: List[float]  # 7D YRSN fingerprint

    # Discriminating signals (from S4-102c)
    theta_response: float = 0.0
    boundary_response: float = 0.0
    alpha_var_response: float = 0.0

    # Alerts triggered
    alerts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'is_healthy': self.is_healthy,
            'alert_type': self.alert_type.value,
            'severity': self.severity,
            'confidence': self.confidence,
            'fingerprint': self.fingerprint,
            'theta_response': self.theta_response,
            'boundary_response': self.boundary_response,
            'alpha_var_response': self.alpha_var_response,
            'alerts': self.alerts,
        }


def classify_hardware_alert(fingerprint: List[float]) -> Tuple[HardwareAlertType, float]:
    """
    Classify hardware degradation type from 7D YRSN fingerprint.

    Uses rule-based classification (S4-102c) with cosine similarity fallback.

    Args:
        fingerprint: 7D array [theta, radius, rsn, omega, angular_coh, boundary_prox, alpha_var]

    Returns:
        (alert_type, confidence)
    """
    if len(fingerprint) != 7:
        return HardwareAlertType.UNKNOWN, 0.0

    fp = np.array(fingerprint)
    theta_response = fp[0]
    rsn_response = fp[2]
    boundary_response = fp[5]
    alpha_var_response = fp[6]

    # Rule 1: Strong positive theta + high boundary -> attenuation
    if theta_response > 0.10 and boundary_response > 0.30:
        return HardwareAlertType.ATTENUATION, 0.95

    # Rule 2: Large negative theta + large negative alpha_var -> noise_snr
    if theta_response < -0.20 and alpha_var_response < -0.40:
        return HardwareAlertType.NOISE_SNR, 0.92

    # Rule 3: Small changes overall + small boundary -> quantization
    if abs(theta_response) < 0.05 and abs(rsn_response) < 0.05 and boundary_response < 0.10:
        return HardwareAlertType.QUANTIZATION, 0.80

    # Rule 4: Moderate boundary response + moderate alpha_var drop -> stuck
    if boundary_response > 0.20 and boundary_response < 0.50 and alpha_var_response < -0.20:
        return HardwareAlertType.STUCK_AT, 0.88

    # Rule 5: Negative theta but not extreme -> stuck
    if theta_response < 0 and theta_response > -0.15 and boundary_response > 0.15:
        return HardwareAlertType.STUCK_AT, 0.85

    # Fallback: cosine similarity (excluding omega which doesn't discriminate)
    reduced_fp = np.array([fp[0], fp[1], fp[2], fp[5], fp[6]])  # theta, radius, rsn, boundary, alpha_var

    reduced_signatures = {
        HardwareAlertType.ATTENUATION: np.array([0.18, 0.01, 0.09, 0.54, -0.08]),
        HardwareAlertType.STUCK_AT: np.array([-0.06, 0.05, -0.14, 0.36, -0.37]),
        HardwareAlertType.QUANTIZATION: np.array([-0.01, -0.01, 0.00, 0.01, 0.06]),
        HardwareAlertType.NOISE_SNR: np.array([-0.33, 0.11, -0.33, 0.09, -0.62]),
    }

    best_type = HardwareAlertType.UNKNOWN
    best_similarity = -np.inf

    for hw_type, sig in reduced_signatures.items():
        similarity = np.dot(reduced_fp, sig) / (
            np.linalg.norm(reduced_fp) * np.linalg.norm(sig) + 1e-8
        )
        if similarity > best_similarity:
            best_similarity = similarity
            best_type = hw_type

    return best_type, float(max(0, best_similarity))


def get_hardware_alerts(fingerprint: List[float], threshold: float = 0.12) -> HardwareHealthStatus:
    """
    Get hardware health status from 7D YRSN fingerprint.

    Args:
        fingerprint: 7D YRSN fingerprint
        threshold: Detection threshold (fingerprint magnitude)

    Returns:
        HardwareHealthStatus with detection result
    """
    if len(fingerprint) != 7:
        return HardwareHealthStatus(
            is_healthy=True,
            alert_type=HardwareAlertType.NONE,
            severity=0.0,
            confidence=0.0,
            fingerprint=fingerprint,
        )

    fp = np.array(fingerprint)
    magnitude = np.linalg.norm(fp)

    # Detection
    is_degraded = magnitude > threshold

    # Classification
    alert_type, confidence = classify_hardware_alert(fingerprint)

    # Severity from fingerprint norm
    severity = min(1.0, magnitude / 2.0) if is_degraded else 0.0

    # Build alerts list
    alerts = []
    if fp[0] > 0.15:  # theta
        alerts.append("THETA_DRIFT_POSITIVE")
    if fp[0] < -0.20:
        alerts.append("THETA_DRIFT_NEGATIVE")
    if fp[5] > 0.30:  # boundary_proximity
        alerts.append("BOUNDARY_SHIFT")
    if fp[6] < -0.30:  # alpha_variance
        alerts.append("ALPHA_UNSTABLE")
    if fp[3] < -0.90:  # omega (all types have this)
        alerts.append("OMEGA_DEGRADED")

    return HardwareHealthStatus(
        is_healthy=not is_degraded,
        alert_type=alert_type if is_degraded else HardwareAlertType.NONE,
        severity=severity,
        confidence=confidence if is_degraded else 1.0,
        fingerprint=fingerprint,
        theta_response=fp[0],
        boundary_response=fp[5],
        alpha_var_response=fp[6],
        alerts=alerts,
    )


# =============================================================================
# CONFIGURABLE THRESHOLDS (from legacy CollapseSignature)
# =============================================================================

@dataclass
class CollapseConfig:
    """
    Configurable thresholds for S4 collapse detection.

    Defaults are calibrated from S4 experiments. Override for custom sensitivity.
    """
    # Quality Domain (S4-033)
    poisoning_n: float = 0.30
    distraction_s: float = 0.40
    confusion_n: float = 0.20
    confusion_s: float = 0.25
    clash_s_var: float = 0.10

    # Reliability Domain (S4-046, S4-090)
    hallucination_alpha: float = 0.70
    hallucination_omega: float = 0.50
    o_poisoning_r: float = 0.50
    o_poisoning_omega: float = 0.50
    drift_omega: float = 0.35
    drift_omega_drop: float = 0.05

    # RSN Collapse (S4-000)
    rsn_collapse_delta: float = 0.15
    rsn_collapse_scale: float = 0.10

    # Conflict Detection (§7.10.4.4) - from phasor_coherence.py
    # CONFLICTED = coherence < 0.4, MODERATE = 0.4-0.7, COHERENT = >= 0.7
    conflict_coherence_threshold: float = 0.40

    # Fragility Boundary Margins (§7.10.3.3)
    # Used in _is_boundary_risk for Lyapunov margin check
    lyapunov_boundary_margin: float = 0.30

    # Geometric Domain (S4-002b)
    compression_theta: float = -5.0
    expansion_theta: float = 5.0

    # Alpha Error Detection (S4-033)
    error_alpha_high: float = 0.70
    error_alpha_low: float = 0.30

    # Healthy State
    healthy_r: float = 0.45
    healthy_s_max: float = 0.38
    healthy_n_max: float = 0.28
    healthy_omega: float = 0.40

    # Severity (S4-003 "tight")
    scale_severe_low: float = 0.80
    scale_severe_high: float = 1.30
    scale_moderate_low: float = 0.90
    scale_moderate_high: float = 1.15
    corr_severe: float = 0.30
    corr_moderate: float = 0.50

    def to_dict(self) -> Dict[str, float]:
        """Export as threshold dictionary for CollapseDetector."""
        return {
            'poisoning_n': self.poisoning_n,
            'distraction_s': self.distraction_s,
            'confusion_n': self.confusion_n,
            'confusion_s': self.confusion_s,
            'clash_s_var': self.clash_s_var,
            'hallucination_alpha': self.hallucination_alpha,
            'hallucination_omega': self.hallucination_omega,
            'o_poisoning_r': self.o_poisoning_r,
            'o_poisoning_omega': self.o_poisoning_omega,
            'drift_omega': self.drift_omega,
            'drift_omega_drop': self.drift_omega_drop,
            'rsn_collapse_delta': self.rsn_collapse_delta,
            'rsn_collapse_scale': self.rsn_collapse_scale,
            'compression_theta': self.compression_theta,
            'expansion_theta': self.expansion_theta,
            'error_alpha_high': self.error_alpha_high,
            'error_alpha_low': self.error_alpha_low,
            'healthy_r': self.healthy_r,
            'healthy_s_max': self.healthy_s_max,
            'healthy_n_max': self.healthy_n_max,
            'healthy_omega': self.healthy_omega,
        }

    def with_phase_multiplier(self, multiplier: float) -> 'CollapseConfig':
        """
        Create config with phase-adjusted thresholds.

        From legacy detect_collapse_phase_aware:
        - multiplier < 1.0: Stricter thresholds
        - multiplier > 1.0: More lenient thresholds
        """
        return CollapseConfig(
            poisoning_n=self.poisoning_n * multiplier,
            distraction_s=self.distraction_s * multiplier,
            confusion_n=self.confusion_n * multiplier,
            confusion_s=self.confusion_s * multiplier,
            clash_s_var=self.clash_s_var * multiplier,
            # Keep other thresholds unchanged
            hallucination_alpha=self.hallucination_alpha,
            hallucination_omega=self.hallucination_omega,
            o_poisoning_r=self.o_poisoning_r,
            o_poisoning_omega=self.o_poisoning_omega,
            drift_omega=self.drift_omega,
            drift_omega_drop=self.drift_omega_drop,
            rsn_collapse_delta=self.rsn_collapse_delta,
            rsn_collapse_scale=self.rsn_collapse_scale,
            compression_theta=self.compression_theta,
            expansion_theta=self.expansion_theta,
            error_alpha_high=self.error_alpha_high,
            error_alpha_low=self.error_alpha_low,
            healthy_r=self.healthy_r,
            healthy_s_max=self.healthy_s_max,
            healthy_n_max=self.healthy_n_max,
            healthy_omega=self.healthy_omega,
            scale_severe_low=self.scale_severe_low,
            scale_severe_high=self.scale_severe_high,
            scale_moderate_low=self.scale_moderate_low,
            scale_moderate_high=self.scale_moderate_high,
            corr_severe=self.corr_severe,
            corr_moderate=self.corr_moderate,
        )


# Legacy alias for backward compatibility
CollapseSignature = CollapseConfig


def detect_collapse_phase_aware(
    R: float,
    S: float,
    N: float,
    quality: float,
    **kwargs,
) -> CollapseAnalysis:
    """
    Phase-aware collapse detection using quality metric.

    Adjusts detection thresholds based on quality phase:
    - HIGH quality (α > 0.70): Stricter thresholds (multiplier 0.8)
    - MEDIUM quality: Default (multiplier 1.0)
    - LOW quality (α < 0.40): More lenient (multiplier 1.2)

    Args:
        R, S, N: RSN components
        quality: Quality metric alpha [0, 1]
        **kwargs: Additional arguments for detect()

    Returns:
        CollapseAnalysis with phase-aware detection
    """
    if quality > 0.70:
        multiplier = 0.8  # Stricter at high quality
    elif quality < 0.40:
        multiplier = 1.2  # More lenient at low quality
    else:
        multiplier = 1.0

    config = CollapseConfig().with_phase_multiplier(multiplier)
    detector = CollapseDetector(thresholds=config.to_dict())
    return detector.detect(R=R, S=S, N=N, alpha=quality, **kwargs)


# =============================================================================
# HIVEMIND DETECTOR (moved to yrsn/core/decomposition/hivemind.py)
# Re-exported here for backward compatibility
# =============================================================================

from .hivemind import HiveMindAnalysis, HiveMindDetector


# =============================================================================
# VISUALIZATION (moved to scripts/visualize_collapse.py)
# Re-exported here for backward compatibility
# =============================================================================

# Import visualization functions lazily to avoid circular imports
def generate_constraint_mermaid(config=None):
    """Generate Mermaid diagram. See scripts/visualize_collapse.py for standalone use."""
    from scripts.visualize_collapse import generate_constraint_mermaid as _gen, VisualizationConfig
    if config is None:
        return _gen()
    # Convert CollapseConfig to VisualizationConfig
    vc = VisualizationConfig(
        poisoning_n=config.poisoning_n,
        distraction_s=config.distraction_s,
        confusion_n=config.confusion_n,
        confusion_s=config.confusion_s,
        clash_s_var=config.clash_s_var,
        hallucination_alpha=config.hallucination_alpha,
        hallucination_omega=config.hallucination_omega,
        o_poisoning_r=config.o_poisoning_r,
        o_poisoning_omega=config.o_poisoning_omega,
        drift_omega=config.drift_omega,
        compression_theta=config.compression_theta,
        expansion_theta=config.expansion_theta,
        healthy_r=config.healthy_r,
        healthy_s_max=config.healthy_s_max,
        healthy_n_max=config.healthy_n_max,
    )
    return _gen(vc)


def generate_constraint_graphviz(config=None):
    """Generate GraphViz diagram. See scripts/visualize_collapse.py for standalone use."""
    from scripts.visualize_collapse import generate_constraint_graphviz as _gen, VisualizationConfig
    if config is None:
        return _gen()
    # Convert CollapseConfig to VisualizationConfig
    vc = VisualizationConfig(
        poisoning_n=config.poisoning_n,
        distraction_s=config.distraction_s,
        confusion_n=config.confusion_n,
        confusion_s=config.confusion_s,
        clash_s_var=config.clash_s_var,
        hallucination_alpha=config.hallucination_alpha,
        hallucination_omega=config.hallucination_omega,
        o_poisoning_r=config.o_poisoning_r,
        o_poisoning_omega=config.o_poisoning_omega,
        drift_omega=config.drift_omega,
        compression_theta=config.compression_theta,
        expansion_theta=config.expansion_theta,
        healthy_r=config.healthy_r,
        healthy_s_max=config.healthy_s_max,
        healthy_n_max=config.healthy_n_max,
    )
    return _gen(vc)


# =============================================================================
# MODEL ALERTS (from geometric_domain.py - training/deployment health)
# =============================================================================

class ModelAlert(str, Enum):
    """
    Model-level health alerts based on geometric parameters.

    These indicate model training or deployment issues, not sample-level collapse.
    Different from HardwareAlertType which focuses on sensor/hardware degradation.
    """
    THETA_EXTREME = "THETA_EXTREME"      # |theta| > 20°, unusual rotation
    SCALE_COLLAPSE = "SCALE_COLLAPSE"    # scale < 0.8, feature compression
    SCALE_EXPLOSION = "SCALE_EXPLOSION"  # scale > 1.3, feature expansion
    THETA_UNSTABLE = "THETA_UNSTABLE"    # std(theta) > 10°, training issue


def get_model_alerts(
    theta: Optional[float] = None,
    scale: Optional[float] = None,
    theta_std: Optional[float] = None,
    theta_extreme_threshold: float = 20.0,
    scale_collapse_threshold: float = 0.80,
    scale_explosion_threshold: float = 1.30,
    theta_unstable_threshold: float = 10.0,
) -> List[str]:
    """
    Generate model-level health alerts.

    These alerts indicate issues with model training or deployment,
    not sample-level collapse. Use for monitoring model health.

    Args:
        theta: Current theta value (degrees)
        scale: Current scale value
        theta_std: Standard deviation of theta across runs/batches

    Returns:
        List of alert strings (empty if healthy)
    """
    alerts = []

    if theta is not None and abs(theta) > theta_extreme_threshold:
        alerts.append(ModelAlert.THETA_EXTREME.value)

    if scale is not None:
        if scale < scale_collapse_threshold:
            alerts.append(ModelAlert.SCALE_COLLAPSE.value)
        elif scale > scale_explosion_threshold:
            alerts.append(ModelAlert.SCALE_EXPLOSION.value)

    if theta_std is not None and theta_std > theta_unstable_threshold:
        alerts.append(ModelAlert.THETA_UNSTABLE.value)

    return alerts


# =============================================================================
# EXPECTED DOMAIN BY TYPE (from geometric_domain.py - validation mapping)
# =============================================================================

# Based on EXP-S4-001 results: semantic type -> expected geometric domain
EXPECTED_DOMAIN_BY_TYPE = {
    # Compression domain (theta ~ -12°)
    'POSTERIOR_COLLAPSE': GeometricDomain.COMPRESSION,
    'RSN_COLLAPSE': GeometricDomain.COMPRESSION,
    'POISONING': GeometricDomain.COMPRESSION,
    'CONFLICT': GeometricDomain.COMPRESSION,
    'ALEATORIC_DOMINANCE': GeometricDomain.COMPRESSION,

    # Neutral domain (theta ~ 0°)
    'CLASH': GeometricDomain.NEUTRAL,
    'MODE_COLLAPSE': GeometricDomain.NEUTRAL,
    'HALLUCINATION': GeometricDomain.NEUTRAL,
    'DISTRACTION': GeometricDomain.NEUTRAL,

    # Expansion domain (theta ~ +7°)
    'O_POISONING': GeometricDomain.EXPANSION,
    'OVERCONFIDENCE': GeometricDomain.EXPANSION,
    'EPISTEMIC_SPIKE': GeometricDomain.EXPANSION,
    'DRIFT': GeometricDomain.EXPANSION,
    'DISTRIBUTIONAL_SHIFT': GeometricDomain.EXPANSION,
    'GRADUAL_DRIFT': GeometricDomain.EXPANSION,
    'CONFIRMED_DRIFT': GeometricDomain.EXPANSION,

    # Baseline
    'NONE': GeometricDomain.COMPRESSION,  # Based on EXP-S4-001: theta=-11.5°
}


def get_expected_domain(semantic_type: str) -> GeometricDomain:
    """
    Get expected geometric domain for a semantic type.

    Useful for validation: if observed domain differs from expected,
    may indicate unusual collapse pattern.

    Args:
        semantic_type: One of the 17 semantic collapse types

    Returns:
        Expected GeometricDomain based on EXP-S4-001 results
    """
    return EXPECTED_DOMAIN_BY_TYPE.get(semantic_type, GeometricDomain.UNKNOWN)


# =============================================================================
# GEOMETRIC CLASSIFICATION (from geometric_domain.py)
# =============================================================================

@dataclass
class GeometricClassification:
    """
    Complete geometric classification for a sample or batch.

    Combines geometric domain, severity, and composite labeling
    for comprehensive collapse characterization.
    """
    # Primary geometric classification
    domain: GeometricDomain
    theta: Optional[float] = None
    scale: Optional[float] = None

    # Severity assessment
    severity: Severity = Severity.UNKNOWN
    correlation: Optional[float] = None

    # Composite label (e.g., "COMPRESSION/POISONING/MODERATE")
    semantic_type: Optional[str] = None
    composite_label: Optional[str] = None

    # Model-level alerts (populated for model health checks)
    alerts: List[str] = field(default_factory=list)


def classify_geometric_domain(
    theta: Optional[float],
    compression_threshold: float = -5.0,
    expansion_threshold: float = 5.0,
) -> GeometricDomain:
    """
    Classify theta into geometric domain.

    Args:
        theta: Rotation angle in degrees (from SimplexRotor)
        compression_threshold: Below this -> COMPRESSION (default -5)
        expansion_threshold: Above this -> EXPANSION (default +5)

    Returns:
        GeometricDomain enum value
    """
    if theta is None:
        return GeometricDomain.UNKNOWN

    if theta < compression_threshold:
        return GeometricDomain.COMPRESSION
    elif theta > expansion_threshold:
        return GeometricDomain.EXPANSION
    else:
        return GeometricDomain.NEUTRAL


def classify_severity(
    scale: Optional[float] = None,
    correlation: Optional[float] = None,
    scale_severe_low: float = 0.80,
    scale_severe_high: float = 1.30,
    scale_moderate_low: float = 0.90,
    scale_moderate_high: float = 1.15,
    corr_severe: float = 0.30,
    corr_moderate: float = 0.50,
) -> Severity:
    """
    Classify severity based on scale and correlation.

    Args:
        scale: Scale parameter from SimplexRotor
        correlation: N-error correlation (higher = better detection)

    Returns:
        Severity enum value
    """
    if scale is None and correlation is None:
        return Severity.UNKNOWN

    # Check for SEVERE conditions
    if scale is not None:
        if scale < scale_severe_low or scale > scale_severe_high:
            return Severity.SEVERE

    if correlation is not None:
        if correlation < corr_severe:
            return Severity.SEVERE

    # Check for MODERATE conditions
    if scale is not None:
        if scale < scale_moderate_low or scale > scale_moderate_high:
            return Severity.MODERATE

    if correlation is not None:
        if correlation < corr_moderate:
            return Severity.MODERATE

    return Severity.MILD


def create_composite_label(
    domain: GeometricDomain,
    semantic_type: str,
    severity: Severity,
) -> str:
    """
    Create hierarchical composite label.

    Format: {GEOMETRIC_DOMAIN}/{SEMANTIC_TYPE}/{SEVERITY}
    """
    return f"{domain.value}/{semantic_type}/{severity.value}"


def classify_full(
    theta: Optional[float] = None,
    scale: Optional[float] = None,
    correlation: Optional[float] = None,
    semantic_type: str = "UNKNOWN",
    theta_std: Optional[float] = None,
) -> GeometricClassification:
    """
    Perform full geometric classification.

    Convenience function that combines all classification steps.
    """
    domain = classify_geometric_domain(theta)
    severity = classify_severity(scale, correlation)
    composite = create_composite_label(domain, semantic_type, severity)
    alerts = get_model_alerts(theta, scale, theta_std)

    return GeometricClassification(
        domain=domain,
        theta=theta,
        scale=scale,
        severity=severity,
        correlation=correlation,
        semantic_type=semantic_type,
        composite_label=composite,
        alerts=alerts,
    )


# =============================================================================
# LEGACY COMPATIBILITY FUNCTIONS
# =============================================================================

def detect_collapse_full(
    R: float,
    S: float,
    N: float,
    theta: Optional[float] = None,
    scale: Optional[float] = None,
    omega: Optional[float] = None,
    alpha: Optional[float] = None,
    correlation: Optional[float] = None,
    **kwargs,
) -> CollapseAnalysis:
    """
    Full collapse detection with all signals.

    Alias for detect_collapse() with correlation parameter.
    """
    return detect_collapse(
        R=R, S=S, N=N,
        theta=theta,
        scale=scale,
        omega=omega,
        alpha=alpha if alpha is not None else R,
        correlation=correlation,
        **kwargs,
    )


def get_collapse_summary(analysis: CollapseAnalysis) -> str:
    """Get human-readable summary of collapse analysis."""
    domain = analysis.geometric_domain.value if analysis.geometric_domain else "UNKNOWN"
    return (
        f"{analysis.collapse_type.value} ({analysis.severity.value}) "
        f"in {domain} domain: "
        f"R={analysis.R:.2f}, S={analysis.S:.2f}, N={analysis.N:.2f}"
    )


def detect_collapse_with_frequency(
    R: float, S: float, N: float, omega: float,
    raw_image: Optional[np.ndarray] = None, **kwargs
) -> CollapseAnalysis:
    """Legacy function - use detect_collapse() with omega parameter."""
    return detect_collapse(R=R, S=S, N=N, omega=omega, **kwargs)


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [
    # Enums
    'SignalRole',
    'GeometricDomain',
    'Severity',
    'CollapseType',
    'HardwareAlertType',
    'ModelAlert',
    # Classes - Core Detection
    'CollapseAnalysis',
    'CollapseDetector',
    'RealTimeCollapseMonitor',
    'MonitorStatus',
    # Classes - Configuration
    'CollapseConfig',
    'CollapseSignature',  # Legacy alias
    # Classes - Hardware Health (S4-102c)
    'HardwareHealthStatus',
    # Classes - HiveMind
    'HiveMindAnalysis',
    'HiveMindDetector',
    # Functions - Core
    'detect_collapse',
    'detect_collapse_full',  # Legacy alias
    'detect_collapse_phase_aware',
    'detect_collapse_with_frequency',  # Legacy alias
    'get_collapse_summary',
    'get_signal_roles',
    'get_domain_calibration',
    # Functions - Hardware Health
    'classify_hardware_alert',
    'get_hardware_alerts',
    # Functions - Model Health
    'get_model_alerts',
    'get_expected_domain',
    # Classes - Geometric Classification
    'GeometricClassification',
    # Functions - Geometric Classification
    'classify_geometric_domain',
    'classify_severity',
    'create_composite_label',
    'classify_full',
    # Functions - Visualization
    'generate_constraint_mermaid',
    'generate_constraint_graphviz',
    # Constants
    'DOMAIN_CALIBRATION',
    'SEVERITY_THRESHOLDS',
    'TYPE_THETA_SIGNATURES',
    'HARDWARE_SIGNATURES',
    'HARDWARE_SEVERITY_SIGNALS',
    'EXPECTED_DOMAIN_BY_TYPE',
]
