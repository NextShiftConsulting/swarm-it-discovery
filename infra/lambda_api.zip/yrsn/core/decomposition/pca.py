"""
Robust PCA: Low-Rank + Sparse Decomposition
===========================================

Decomposes matrices/tensors into:
M = L + S + N

Where:
- L = Low-rank component (corresponds to YRSN R)
- S = Sparse component (corresponds to YRSN S)
- N = Noise/residual (corresponds to YRSN N)

Algorithms:
- IALM: Inexact Augmented Lagrangian Method (default, fast)
- GoDec: Go Decomposition (randomized, large matrices)
- PCP: Principal Component Pursuit (classic)

Usage:
    from yrsn.core.decomposition.pca import robust_pca, RobustPCA

    # Quick decomposition
    result = robust_pca(data_matrix)
    print(f"Rank: {result.rank}, Sparsity: {result.sparsity:.2%}")

    # Convert to YRSN ratios
    R, S, N = result.to_yrsn()

References:
- Candès et al. (2011). Robust Principal Component Analysis
- Zhou & Tao (2011). GoDec: Randomized Low-rank & Sparse Matrix Decomposition
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum


class RPCAMethod(str, Enum):
    """Available RPCA algorithms."""

    IALM = "ialm"  # Inexact ALM (default, fast)
    PCP = "pcp"  # Principal Component Pursuit
    GODEC = "godec"  # Go Decomposition (randomized)


@dataclass
class RPCAResult:
    """
    Result of Robust PCA decomposition.

    Attributes
    ----------
    L : np.ndarray
        Low-rank component (corresponds to YRSN R)
    S : np.ndarray
        Sparse component (corresponds to YRSN S)
    N : np.ndarray
        Noise/residual (corresponds to YRSN N)
    rank : int
        Estimated rank of L
    sparsity : float
        Sparsity ratio of S (fraction of non-zero elements)
    iterations : int
        Iterations to converge
    converged : bool
        Whether algorithm converged within tolerance
    metrics : dict
        Additional metrics (reconstruction_error, norms, etc.)
    """

    L: np.ndarray
    S: np.ndarray
    N: np.ndarray
    rank: int
    sparsity: float
    iterations: int
    converged: bool
    metrics: Dict[str, float]

    @property
    def reconstruction_error(self) -> float:
        """||M - (L + S)||_F / ||M||_F"""
        return self.metrics.get("relative_error", 0.0)

    @property
    def noise_ratio(self) -> float:
        """||N||_F / ||M||_F"""
        return self.metrics.get("noise_ratio", 0.0)

    def to_yrsn(self) -> Tuple[float, float, float]:
        """
        Convert to YRSN ratios based on energy (Frobenius norm).

        Returns
        -------
        tuple of (R, S, N)
            Where R + S + N = 1.0
        """
        l_norm = np.linalg.norm(self.L, "fro")
        s_norm = np.linalg.norm(self.S, "fro")
        n_norm = np.linalg.norm(self.N, "fro")

        total = l_norm + s_norm + n_norm
        if total == 0:
            return (0.33, 0.33, 0.34)

        R = l_norm / total
        S = s_norm / total
        N = n_norm / total

        return (R, S, N)

    def to_dict(self) -> Dict[str, Any]:
        """Export result as dictionary (without large arrays)."""
        R, S, N = self.to_yrsn()
        return {
            "rank": self.rank,
            "sparsity": self.sparsity,
            "iterations": self.iterations,
            "converged": self.converged,
            "yrsn": {"R": R, "S": S, "N": N},
            "metrics": self.metrics,
        }


class RobustPCA:
    """
    Robust PCA decomposition: M = L + S + N

    Decomposes a matrix into low-rank (L), sparse (S), and noise (N) components.
    Directly maps to YRSN framework where L→R, S→S, N→N.

    Parameters
    ----------
    method : RPCAMethod
        Algorithm to use (IALM, GoDec, PCP)
    lambda_s : float, optional
        Sparsity penalty weight. If None, auto-tuned as 1/sqrt(max(m,n))
    max_iter : int
        Maximum iterations (default 1000)
    tol : float
        Convergence tolerance (default 1e-7)
    rank : int, optional
        Target rank for GoDec method (default 10)

    Examples
    --------
    >>> rpca = RobustPCA(method=RPCAMethod.IALM)
    >>> result = rpca.decompose(data_matrix)
    >>> R, S, N = result.to_yrsn()
    >>> print(f"Quality: R={R:.2f}, S={S:.2f}, N={N:.2f}")
    """

    def __init__(
        self,
        method: RPCAMethod = RPCAMethod.IALM,
        lambda_s: Optional[float] = None,
        max_iter: int = 1000,
        tol: float = 1e-7,
        rank: int = 10,
    ):
        self.method = method
        self.lambda_s = lambda_s
        self.max_iter = max_iter
        self.tol = tol
        self.rank = rank

    def decompose(self, M: np.ndarray) -> RPCAResult:
        """
        Decompose matrix M into L + S + N.

        Parameters
        ----------
        M : np.ndarray
            Input matrix (2D) or tensor (unfolded to 2D internally)

        Returns
        -------
        RPCAResult
            Decomposition result with L, S, N components and metrics
        """
        # Ensure float type
        M = np.asarray(M, dtype=np.float64)

        # Handle tensors by unfolding to matrix
        original_shape = M.shape
        if M.ndim > 2:
            M = M.reshape(M.shape[0], -1)
        elif M.ndim == 1:
            M = M.reshape(-1, 1)

        m, n = M.shape
        M_norm = np.linalg.norm(M, "fro")

        # Auto-tune lambda if not provided
        lambda_s = self.lambda_s
        if lambda_s is None:
            lambda_s = 1.0 / np.sqrt(max(m, n))

        # Dispatch to algorithm
        if self.method == RPCAMethod.IALM:
            L, S, info = self._ialm(M, lambda_s)
        elif self.method == RPCAMethod.PCP:
            L, S, info = self._pcp(M, lambda_s)
        elif self.method == RPCAMethod.GODEC:
            L, S, info = self._godec(M, lambda_s)
        else:
            raise ValueError(f"Unknown method: {self.method}")

        # Compute residual noise
        N = M - L - S

        # Reshape back if needed
        if len(original_shape) > 2:
            L = L.reshape(original_shape)
            S = S.reshape(original_shape)
            N = N.reshape(original_shape)
        elif len(original_shape) == 1:
            L = L.flatten()
            S = S.flatten()
            N = N.flatten()

        # Compute metrics
        l_norm = np.linalg.norm(L, "fro") if L.ndim >= 2 else np.linalg.norm(L)
        s_norm = np.linalg.norm(S, "fro") if S.ndim >= 2 else np.linalg.norm(S)
        n_norm = np.linalg.norm(N, "fro") if N.ndim >= 2 else np.linalg.norm(N)

        # Compute rank
        L_2d = (
            L.reshape(L.shape[0], -1)
            if L.ndim > 2
            else (L.reshape(-1, 1) if L.ndim == 1 else L)
        )
        estimated_rank = np.linalg.matrix_rank(L_2d)

        metrics = {
            "reconstruction_error": n_norm,
            "relative_error": n_norm / M_norm if M_norm > 0 else 0.0,
            "noise_ratio": n_norm / (l_norm + s_norm + n_norm)
            if (l_norm + s_norm + n_norm) > 0
            else 0.0,
            "L_nuclear_norm": np.sum(np.linalg.svd(L_2d, compute_uv=False)),
            "S_l1_norm": np.sum(np.abs(S)),
            "lambda_s": lambda_s,
        }

        return RPCAResult(
            L=L,
            S=S,
            N=N,
            rank=estimated_rank,
            sparsity=np.sum(np.abs(S) > 1e-10) / S.size,
            iterations=info["iterations"],
            converged=info["converged"],
            metrics=metrics,
        )

    def _ialm(
        self, M: np.ndarray, lambda_s: float
    ) -> Tuple[np.ndarray, np.ndarray, Dict]:
        """
        Inexact Augmented Lagrangian Method.

        Fast and memory-efficient RPCA algorithm.
        """
        m, n = M.shape
        M_norm = np.linalg.norm(M, 2)

        # Initialize
        Y = M / max(M_norm, np.max(np.abs(M)) / lambda_s)
        L = np.zeros_like(M)
        S = np.zeros_like(M)

        # ALM parameters
        mu = 1.25 / M_norm
        mu_bar = mu * 1e7
        rho = 1.5

        for k in range(self.max_iter):
            # Update L via SVD thresholding
            temp = M - S + Y / mu
            U, sigma, Vt = np.linalg.svd(temp, full_matrices=False)
            sigma_thresh = np.maximum(sigma - 1 / mu, 0)
            L = U @ np.diag(sigma_thresh) @ Vt

            # Update S via soft thresholding
            temp = M - L + Y / mu
            S = self._soft_threshold(temp, lambda_s / mu)

            # Update dual variable
            residual = M - L - S
            Y = Y + mu * residual

            # Update penalty parameter
            mu = min(rho * mu, mu_bar)

            # Check convergence
            err = np.linalg.norm(residual, "fro") / np.linalg.norm(M, "fro")
            if err < self.tol:
                return L, S, {"iterations": k + 1, "converged": True}

        return L, S, {"iterations": self.max_iter, "converged": False}

    def _pcp(
        self, M: np.ndarray, lambda_s: float
    ) -> Tuple[np.ndarray, np.ndarray, Dict]:
        """Principal Component Pursuit via ADMM (uses IALM internally)."""
        return self._ialm(M, lambda_s)

    def _godec(
        self, M: np.ndarray, lambda_s: float
    ) -> Tuple[np.ndarray, np.ndarray, Dict]:
        """
        Go Decomposition - fast randomized RPCA.

        Uses randomized SVD for speed. Good for very large matrices.
        """
        m, n = M.shape
        rank = min(self.rank, min(m, n) - 1)

        L = np.zeros_like(M)
        S = np.zeros_like(M)

        power_iter = 2

        for k in range(self.max_iter):
            # Low-rank update via randomized SVD
            Y = M - S

            # Randomized range finder
            Omega = np.random.randn(n, rank + 10)
            Q = Y @ Omega
            for _ in range(power_iter):
                Q = Y @ (Y.T @ Q)
            Q, _ = np.linalg.qr(Q)

            # Project and decompose
            B = Q.T @ Y
            U_B, sigma, Vt = np.linalg.svd(B, full_matrices=False)
            U = Q @ U_B[:, :rank]
            L = U @ np.diag(sigma[:rank]) @ Vt[:rank, :]

            # Sparse update via hard thresholding
            residual = M - L
            threshold = lambda_s * np.std(residual)
            S = self._hard_threshold(residual, threshold)

            # Check convergence
            err = np.linalg.norm(M - L - S, "fro") / np.linalg.norm(M, "fro")
            if err < self.tol:
                return L, S, {"iterations": k + 1, "converged": True}

        return L, S, {"iterations": self.max_iter, "converged": False}

    @staticmethod
    def _soft_threshold(X: np.ndarray, thresh: float) -> np.ndarray:
        """Soft thresholding (shrinkage) operator."""
        return np.sign(X) * np.maximum(np.abs(X) - thresh, 0)

    @staticmethod
    def _hard_threshold(X: np.ndarray, thresh: float) -> np.ndarray:
        """Hard thresholding operator."""
        result = X.copy()
        result[np.abs(result) < thresh] = 0
        return result


# =============================================================================
# Convenience Functions
# =============================================================================


def robust_pca(
    M: np.ndarray,
    method: str = "ialm",
    lambda_s: Optional[float] = None,
    max_iter: int = 1000,
    tol: float = 1e-7,
) -> RPCAResult:
    """
    Decompose matrix M into L + S + N (Robust PCA).

    Convenience wrapper around RobustPCA class.

    Parameters
    ----------
    M : np.ndarray
        Input matrix
    method : str
        Algorithm: 'ialm' (default), 'pcp', or 'godec'
    lambda_s : float, optional
        Sparsity penalty (auto-tuned if None)
    max_iter : int
        Maximum iterations
    tol : float
        Convergence tolerance

    Returns
    -------
    RPCAResult
        L (low-rank), S (sparse), N (noise) components

    Examples
    --------
    >>> result = robust_pca(data_matrix)
    >>> print(f"Rank: {result.rank}, Converged: {result.converged}")

    >>> # Convert to YRSN
    >>> R, S, N = result.to_yrsn()
    """
    rpca = RobustPCA(
        method=RPCAMethod(method), lambda_s=lambda_s, max_iter=max_iter, tol=tol
    )
    return rpca.decompose(M)


def decompose_to_yrsn(
    M: np.ndarray, method: str = "ialm", lambda_s: Optional[float] = None
) -> Tuple[float, float, float]:
    """
    Decompose matrix and return YRSN ratios directly.

    Convenience function for quick YRSN analysis.

    Parameters
    ----------
    M : np.ndarray
        Input matrix
    method : str
        RPCA algorithm ('ialm', 'pcp', 'godec')
    lambda_s : float, optional
        Sparsity penalty

    Returns
    -------
    tuple of (R, S, N)
        YRSN ratios where R + S + N = 1.0

    Examples
    --------
    >>> R, S, N = decompose_to_yrsn(data_matrix)
    >>> print(f"Relevant: {R:.1%}, Superfluous: {S:.1%}, Noise: {N:.1%}")
    """
    result = robust_pca(M, method=method, lambda_s=lambda_s)
    return result.to_yrsn()


__all__ = [
    # Enums
    "RPCAMethod",
    # Classes
    "RPCAResult",
    "RobustPCA",
    # Functions
    "robust_pca",
    "decompose_to_yrsn",
]
