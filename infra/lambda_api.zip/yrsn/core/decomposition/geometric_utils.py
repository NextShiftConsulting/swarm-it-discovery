"""
Geometric Utilities - T⁴ Topology and Geodesic Distance

Pure mathematical domain logic for geometric operations on the 4-dimensional
torus (T⁴ = S¹ × S¹ × S¹ × S¹) that underlies YRSN's quality metric space.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.6: Toroidal Geometric Mapping
  - §7.6.2: Functional Requirements (periodic output, toroidal topology)
  - §7.6.3: Mathematical Foundation (toroidal coordinates, simplex relationship)
  - §7.6.4: Mapping Architectures (direct angular encoding, derived metrics)
  - §7.6.5: Distance Computation (wrapped angle, geodesic, chordal)
- §7.4.5: Geometric Interpretation (probability simplex, coordinates)

Relevant patent files:
- docs/specs/patent_spec_section_7_6_toroidal_mapping.md
- docs/specs/patent_spec_section_7_4_decomposition.md (lines 215-251)

Production validation: Experiment expS5_001d showed T⁴ chordal distance
is 135% more discriminative than Euclidean distance.

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

┌────────────────────────────────────────────────────────────────────┐
│                       WHAT THIS DOES                                │
├────────────────────────────────────────────────────────────────────┤
│ Computes distances on T⁴ using proper toroidal topology:           │
│   • Wrapped distance on circles (handles 0°=360° wrap)             │
│   • Geodesic distance on 4-torus                                   │
│   • Coordinate transformations                                     │
│                                                                     │
│ CRITICAL: Euclidean distance is WRONG on tori - use geodesic!      │
└────────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
YRSN coordinates (theta, alpha, omega, phi_simplex) live on a 4-dimensional
torus, not Euclidean space. Using Euclidean distance breaks:
- 10° and 350° are 20° apart geodesically, NOT 340°
- Gradient descent without wraparound diverges
- Clustering algorithms fail near boundaries

This module provides pure toroidal geometry (zero dependencies).

DOMAIN LOGIC (Pure Math):
-------------------------
This module contains ONLY pure mathematical functions with zero external
dependencies. No matplotlib, no PyTorch, no infrastructure.

For visualization, see: infrastructure/rendering/matplotlib/t4_renderer.py
For adapters, see: adapters/visualization/matplotlib_adapter.py

FIRST PRINCIPLES COMPLIANCE:
----------------------------
✓ P1: T⁴ topology (fundamental to YRSN)
✓ Hex architecture: Domain layer
✓ Testable: All functions are pure (input → output, no side effects)

USAGE EXAMPLES:
--------------

Example 1: Wrapped Distance on Circle
>>> from yrsn.core.decomposition.geometric_utils import wrapped_angle_distance
>>>
>>> # Points near boundary: 10° and 350°
>>> dist = wrapped_angle_distance(10.0, 350.0)
>>> print(f"{dist}°")  # 20° (CORRECT - wraps around)
>>>
>>> # Euclidean would give 340° (WRONG!)
>>> euclidean = abs(350.0 - 10.0)
>>> print(f"{euclidean}°")  # 340° (WRONG!)

Example 2: Geodesic Distance on T⁴
>>> from yrsn.core.decomposition.geometric_utils import geodesic_distance_t4
>>> import numpy as np
>>>
>>> # Two points on T⁴
>>> point1 = np.array([10.0, 0.8, 0.9, 0.1])   # (theta, alpha, omega, phi)
>>> point2 = np.array([350.0, 0.75, 0.85, 0.15])
>>>
>>> dist = geodesic_distance_t4(point1, point2)
>>> print(f"Geodesic distance: {dist:.3f}")

Example 3: Normalize Angle to [0, 360)
>>> from yrsn.core.decomposition.geometric_utils import normalize_angle
>>>
>>> normalize_angle(370.0)  # 10.0
>>> normalize_angle(-10.0)  # 350.0

REFERENCE:
---------
CIP #1: T⁴ Parameterization
docs/CIP_01_T4_PARAMETERIZATION.md
docs/schemas/T4_COORDINATES.md
docs/FOUR_TORUS_GEOMETRIC_FRAMEWORK.md
"""

import numpy as np
from typing import Union, Dict


# =============================================================================
# T⁴ Topology - Toroidal Geometry (NEW)
# =============================================================================

def normalize_angle(angle: float) -> float:
    """
    Normalize angle to [0, 360) range.

    Args:
        angle: Angle in degrees (any value)

    Returns:
        Normalized angle in [0, 360)

    Example:
        >>> normalize_angle(370.0)
        10.0
        >>> normalize_angle(-10.0)
        350.0
        >>> normalize_angle(720.0)
        0.0
    """
    normalized = angle % 360.0
    if normalized < 0:
        normalized += 360.0
    return normalized


def wrapped_angle_distance(theta1: float, theta2: float) -> float:
    """
    Compute geodesic distance between two angles on a circle.

    CRITICAL DIFFERENCE FROM EUCLIDEAN:
    ----------------------------------
    On a circle, 10° and 350° are 20° apart (wrapping around 0°/360°),
    NOT 340° apart (Euclidean difference).

    This is the fundamental operation that makes T⁴ topology work.

    Args:
        theta1: First angle in degrees
        theta2: Second angle in degrees

    Returns:
        Shortest angular distance in degrees [0, 180]

    Example:
        >>> wrapped_angle_distance(10.0, 350.0)
        20.0  # CORRECT (geodesic)
        >>> abs(350.0 - 10.0)
        340.0  # WRONG (Euclidean)
        >>>
        >>> wrapped_angle_distance(0.0, 180.0)
        180.0
        >>> wrapped_angle_distance(0.0, 270.0)
        90.0  # Wraps shorter direction (360 - 270 = 90)
    """
    # Compute absolute difference
    diff = abs(theta2 - theta1)

    # Take shorter arc
    if diff > 180.0:
        diff = 360.0 - diff

    return diff


def normalize_angles_to_2pi(angles: np.ndarray) -> np.ndarray:
    """
    Normalize angles to [0, 2π) radians.

    Ensures all phase angles are in the standard periodic range for chordal distance.

    Args:
        angles: Array of angles in radians (any values)

    Returns:
        Normalized angles in [0, 2π)

    Example:
        >>> normalize_angles_to_2pi(np.array([0, np.pi, 3*np.pi]))
        array([0.        , 3.14159265, 3.14159265])
    """
    return np.mod(angles, 2 * np.pi)


def t4_chordal_distance(coords1: dict, coords2: dict) -> float:
    """
    Compute chordal distance on T⁴ manifold using validated periodic boundaries.

    This is the VALIDATED production distance metric from expS5_001d, which proved
    135% more discriminative than Euclidean distance (99 vs 42 H1 loops).

    CRITICAL FORMULA:
    ----------------
    d² = Σᵢ (2 - 2·cos(Δθᵢ))  for all 4 dimensions

    This is chordal distance on unit circles - the straight-line distance through
    3D space between points on a circle, which naturally handles periodicity.

    WHY THIS WORKS:
    --------------
    - 10° and 350° are correctly 20° apart (not 340°)
    - No boundary artifacts (manifold is "seamless")
    - Noise strengthens topology (anti-fragile property from expS5_001c)
    - Structure-preserving under smoothing

    Args:
        coords1: Dict with keys ['simplex_theta', 'phi_simplex', 'alpha', 'omega']
                 Values in DEGREES with ranges:
                 - simplex_theta: [0, 360)
                 - phi_simplex:   [0, 360)
                 - alpha:         [0, 180)
                 - omega:         [0, 90]  (arccos range, NOT [0, 180))
        coords2: Dict with same structure

    Returns:
        Chordal distance (float >= 0)
        Returns np.inf if coordinates are malformed

    Example:
        >>> c1 = {'simplex_theta': 10.0, 'phi_simplex': 20.0, 'alpha': 90.0, 'omega': 45.0}
        >>> c2 = {'simplex_theta': 350.0, 'phi_simplex': 340.0, 'alpha': 90.0, 'omega': 45.0}
        >>>
        >>> # Euclidean (WRONG):
        >>> euclidean = np.sqrt((350-10)**2 + (340-20)**2) / 360  # ~0.94
        >>>
        >>> # Chordal (CORRECT):
        >>> chordal = t4_chordal_distance(c1, c2)  # ~0.11 (recognizes wrap-around!)

    Validation:
        series_005/expS5_001d_final_validation.py (lines 47-51)
        Proved 135% improvement: 42 loops (Euclidean) → 99 loops (Chordal)

    Reference:
        docs/SME_REVIEW_T4_INFERENCE.md
        CIP #1: T⁴ Parameterization
    """
    try:
        # Handle None or missing coordinates
        if coords1 is None or coords2 is None:
            return np.inf

        # Extract 4 dimensions (in DEGREES)
        keys = ['simplex_theta', 'phi_simplex', 'alpha', 'omega']

        # Get values with defaults (graceful handling of missing keys)
        theta1_deg = np.array([coords1.get(k, 0.0) for k in keys])
        theta2_deg = np.array([coords2.get(k, 0.0) for k in keys])

        # Convert to radians normalized to [0, 2π) for ALL dimensions:
        # - simplex_theta: [0, 360) → [0, 2π)  (multiply by 2π/360)
        # - phi_simplex:   [0, 360) → [0, 2π)  (multiply by 2π/360)
        # - alpha:         [0, 180) → [0, 2π)  (multiply by 2π/180 to stretch to full circle)
        # - omega:         [0, 90]  → [0, 2π)  (multiply by 2π/90 to stretch to full circle)
        #
        # BUG FIX (v2.6): omega range corrected from 180 → 90
        # Key insight: For chordal distance on unit circle, we need everything in [0, 2π)
        scale_factors = np.array([360.0, 360.0, 180.0, 90.0])
        theta1_rad = theta1_deg * (2 * np.pi / scale_factors)
        theta2_rad = theta2_deg * (2 * np.pi / scale_factors)

        # Normalize to [0, 2π) for consistent periodic arithmetic
        theta1_norm = normalize_angles_to_2pi(theta1_rad)
        theta2_norm = normalize_angles_to_2pi(theta2_rad)

        # Chordal distance formula (validated in expS5_001d)
        # For each dimension: d²ᵢ = 2 - 2·cos(Δθᵢ)
        # Total: d² = Σᵢ d²ᵢ
        delta = theta1_norm - theta2_norm
        d_squared_per_dim = 2.0 - 2.0 * np.cos(delta)
        d_squared_total = np.sum(d_squared_per_dim)

        # Return Euclidean norm in chordal space
        return float(np.sqrt(max(d_squared_total, 0.0)))

    except (TypeError, KeyError, ValueError) as e:
        # Handle malformed coordinates gracefully
        # Return infinity to signal "infinitely far" (useful for filtering)
        return np.inf


def geodesic_distance_t4(
    point1: np.ndarray,
    point2: np.ndarray,
    weights: Union[np.ndarray, None] = None
) -> float:
    """
    Compute geodesic distance on T⁴ (4-dimensional torus).

    T⁴ = S¹ × S¹ × S¹ × S¹ (Cartesian product of 4 circles)

    ALGORITHM:
    ---------
    1. For each dimension, compute wrapped distance (handles periodicity)
    2. Combine using weighted Euclidean norm in wrapped space

    Args:
        point1: [4] array of (theta, alpha, omega, phi_simplex)
                - theta: [0, 360) degrees
                - alpha: [0, 1]
                - omega: [0, 1]
                - phi_simplex: [0, 1]
        point2: [4] array with same structure
        weights: Optional [4] array of dimension weights (default: uniform)

    Returns:
        Geodesic distance on T⁴

    Example:
        >>> import numpy as np
        >>> p1 = np.array([10.0, 0.8, 0.9, 0.1])
        >>> p2 = np.array([350.0, 0.75, 0.85, 0.15])
        >>> dist = geodesic_distance_t4(p1, p2)
        >>> print(f"{dist:.3f}")  # Uses wrapped distance for theta
    """
    if point1.shape != (4,) or point2.shape != (4,):
        raise ValueError(f"Points must be shape (4,), got {point1.shape}, {point2.shape}")

    if weights is None:
        weights = np.ones(4)

    # Dimension 0: theta (angular, wrapped)
    theta_dist = wrapped_angle_distance(point1[0], point2[0])
    # Normalize to [0, 1] for combination with other dimensions
    theta_dist_normalized = theta_dist / 180.0  # Max wrapped distance is 180°

    # Dimensions 1-3: alpha, omega, phi (linear [0,1], but periodic)
    # For now, treat as linear (can add periodicity later if needed)
    alpha_dist = abs(point2[1] - point1[1])
    omega_dist = abs(point2[2] - point1[2])
    phi_dist = abs(point2[3] - point1[3])

    # Weighted Euclidean norm
    squared_dists = np.array([
        theta_dist_normalized**2,
        alpha_dist**2,
        omega_dist**2,
        phi_dist**2
    ])

    weighted_squared_dists = squared_dists * (weights**2)
    geodesic_dist = np.sqrt(np.sum(weighted_squared_dists))

    return float(geodesic_dist)


def compute_winding_number(points: np.ndarray, dimension: int = 0) -> int:
    """
    Compute winding number around a torus dimension.

    The winding number counts how many times a path winds around a circle.
    On a torus, this is a topological invariant.

    Args:
        points: [N, 4] array of points on T⁴ in DEGREES
                - Column 0: simplex_theta [0, 360)
                - Column 1: phi_simplex [0, 360)
                - Column 2: alpha [0, 180)
                - Column 3: omega [0, 90]  (CORRECTED from 180)
        dimension: Which dimension to compute winding for (0-3)

    Returns:
        Winding number (integer)

    Example:
        >>> # Path that winds once around theta dimension
        >>> points = np.array([
        ...     [0, 180, 90, 45],
        ...     [90, 180, 90, 45],
        ...     [180, 180, 90, 45],
        ...     [270, 180, 90, 45],
        ...     [0, 180, 90, 45],  # Back to start
        ... ])
        >>> winding = compute_winding_number(points, dimension=0)
        >>> print(winding)  # 1 (wound once around)

    Bug Fix (v2.6):
        Omega range corrected to [0, 90] (was incorrectly [0, 180])
        Scaling factors updated accordingly.
    """
    if dimension not in [0, 1, 2, 3]:
        raise ValueError(f"Dimension must be 0-3, got {dimension}")

    if len(points) < 2:
        return 0

    # Extract values for this dimension
    values = points[:, dimension]

    # Scale to [0, 360) for consistent periodic arithmetic
    # - simplex_theta, phi_simplex: already in [0, 360)
    # - alpha: [0, 180) → scale by 2x
    # - omega: [0, 90] → scale by 4x (CORRECTED from 2x)
    scale_factors = [1.0, 1.0, 2.0, 4.0]  # BUG FIX: omega scale 4x (was 2x)
    angles = values * scale_factors[dimension]

    # Accumulate total angle change with wraparound
    total_angle = 0.0
    for i in range(len(angles) - 1):
        delta = angles[i + 1] - angles[i]

        # Handle wraparound
        if delta > 180.0:
            delta -= 360.0
        elif delta < -180.0:
            delta += 360.0

        total_angle += delta

    # Winding number = total_angle / 360
    winding = round(total_angle / 360.0)

    return int(winding)


# =============================================================================
# Legacy Functions (Kept for Backward Compatibility)
# =============================================================================

def compute_curvature_simple(embedding, k=5):
    """
    Minimal curvature computation (LEGACY - placeholder).

    DEPRECATED: This is a placeholder. For real curvature computation,
    use proper differential geometry methods.

    Start simple, refine later.
    """
    # Simplified: use variance as proxy for curvature
    return np.var(embedding)


def compute_geodesic_deviation_simple(embedding1, embedding2):
    """
    Minimal geodesic deviation computation (LEGACY - placeholder).

    DEPRECATED: Use geodesic_distance_t4() for proper T⁴ geodesic distance.

    This legacy function uses Euclidean distance, which is INCORRECT for
    toroidal topology. Kept only for backward compatibility.
    """
    # Simplified: use Euclidean distance as proxy (WRONG for tori!)
    return np.linalg.norm(embedding1 - embedding2)


# =============================================================================
# T⁴ Coordinate System (RSN Simplex → 4D Torus)
# =============================================================================

def compute_simplex_theta(
    R: Union[float, np.ndarray],
    S: Union[float, np.ndarray],
    N: Union[float, np.ndarray]
) -> np.ndarray:
    """
    Compute angular position on RSN simplex.

    Converts RSN simplex coordinates to angular position in simplex plane
    using barycentric-to-angular transformation.

    DUAL-MODE API: Supports both scalar and batch inputs.

    Args:
        R: Relevance value(s) in [0, 1]
           - Scalar float → Returns 0-d array
           - 1-D array [N] → Returns 1-d array [N]
        S: Spurious value(s) in [0, 1] (same type/shape as R)
        N: Noise value(s) in [0, 1] (same type/shape as R)

    Returns:
        theta: Angular position in degrees [0, 360)
               Shape matches input: () for scalars, (N,) for arrays

    Mathematical Derivation:
        1. Convert RSN to 2D Cartesian (barycentric transformation)
           Simplex vertices: R=(0,0), S=(1,0), N=(0.5, √3/2)
        2. Compute angle from simplex center using atan2
        3. Normalize to [0, 360)

    Examples:
        # Scalar mode
        >>> theta = compute_simplex_theta(1.0, 0.0, 0.0)  # Pure R
        >>> print(f"{theta:.1f}°")  # ~240° (R vertex direction)
        >>> print(theta.shape)       # () - scalar (0-d array)

        # Batch mode
        >>> R = np.array([1.0, 0.0, 0.0])
        >>> S = np.array([0.0, 1.0, 0.0])
        >>> N = np.array([0.0, 0.0, 1.0])
        >>> theta = compute_simplex_theta(R, S, N)
        >>> print(theta)       # [240.0, 0.0, 120.0] (vertex angles)
        >>> print(theta.shape) # (3,) - batch

    Reference: series_005/expS5_001_SOLUTION.md
    """
    # Convert to numpy if needed
    R = np.asarray(R)
    S = np.asarray(S)
    N = np.asarray(N)

    # Barycentric to Cartesian (simplex vertices: R=(0,0), S=(1,0), N=(0.5, sqrt(3)/2))
    x = S + 0.5 * N
    y = (np.sqrt(3.0) / 2.0) * N

    # Simplex center (where R=S=N=1/3)
    center_x = 0.5
    center_y = np.sqrt(3.0) / 6.0

    # Vector from center to point
    dx = x - center_x
    dy = y - center_y

    # Angle in degrees
    theta = np.arctan2(dy, dx) * 180.0 / np.pi

    # Normalize to [0, 360)
    theta = np.where(theta < 0, theta + 360.0, theta)

    return theta


def compute_phi_simplex(
    R: Union[float, np.ndarray],
    S: Union[float, np.ndarray],
    N: Union[float, np.ndarray]
) -> np.ndarray:
    """
    Compute distance from simplex center (normalized to periodic range).

    Measures how far a point is from the simplex center (R=S=N=1/3).
    Normalized to [0, 360) for periodic topology consistency.

    DUAL-MODE API: Supports both scalar and batch inputs.

    Args:
        R: Relevance value(s) in [0, 1]
           - Scalar float → Returns 0-d array
           - 1-D array [N] → Returns 1-d array [N]
        S: Spurious value(s) in [0, 1] (same type/shape as R)
        N: Noise value(s) in [0, 1] (same type/shape as R)

    Returns:
        phi: Distance from center in degrees [0, 360)
             Shape matches input: () for scalars, (N,) for arrays

    Interpretation:
        - phi ≈ 0°: Near simplex center (balanced R/S/N)
        - phi ≈ 180°: Near simplex boundary (pure R, S, or N)

    Examples:
        # Scalar mode (at center)
        >>> phi = compute_phi_simplex(1/3, 1/3, 1/3)
        >>> print(f"{phi:.1f}°")  # ~0° (at center)
        >>> print(phi.shape)      # () - scalar

        # Scalar mode (at boundary)
        >>> phi = compute_phi_simplex(1.0, 0.0, 0.0)
        >>> print(f"{phi:.1f}°")  # ~360° (at R vertex)

        # Batch mode
        >>> R = np.array([1/3, 1.0, 0.0])
        >>> S = np.array([1/3, 0.0, 1.0])
        >>> N = np.array([1/3, 0.0, 0.0])
        >>> phi = compute_phi_simplex(R, S, N)
        >>> print(phi.shape)  # (3,) - batch

    Reference: series_005/expS5_001_SOLUTION.md
    """
    # Convert to numpy if needed
    R = np.asarray(R)
    S = np.asarray(S)
    N = np.asarray(N)

    # Barycentric to Cartesian
    x = S + 0.5 * N
    y = (np.sqrt(3.0) / 2.0) * N

    # Simplex center
    center_x = 0.5
    center_y = np.sqrt(3.0) / 6.0

    # Euclidean distance from center
    distance = np.sqrt((x - center_x)**2 + (y - center_y)**2)

    # Maximum distance (center to vertex)
    max_distance = np.sqrt((0 - center_x)**2 + (0 - center_y)**2)

    # Normalize to [0, 1]
    normalized_distance = distance / max_distance

    # Map to [0, 360) for periodic topology
    phi = normalized_distance * 360.0

    return phi


def compute_alpha(
    R: Union[float, np.ndarray],
    S: Union[float, np.ndarray],
    N: Union[float, np.ndarray]
) -> np.ndarray:
    """
    Compute quality level from Relevance.

    Maps Relevance (R) to angular coordinate representing quality.
    High R → Low alpha (high quality), Low R → High alpha (low quality).

    DUAL-MODE API: Supports both scalar and batch inputs.

    Args:
        R: Relevance value(s) in [0, 1]
           - Scalar float → Returns 0-d array
           - 1-D array [N] → Returns 1-d array [N]
        S: Spurious value(s) (not used, included for interface consistency)
        N: Noise value(s) (not used, included for interface consistency)

    Returns:
        alpha: Quality level in degrees [0, 180)
               Shape matches input: () for scalars, (N,) for arrays

    Mathematical Mapping:
        alpha = arccos(R) * 180 / π

        R = 1.0 → alpha = 0° (perfect quality)
        R = 0.5 → alpha = 90° (medium quality)
        R = 0.0 → alpha = 180° (zero quality)

    Examples:
        # Scalar mode
        >>> alpha = compute_alpha(1.0, 0.0, 0.0)  # Perfect relevance
        >>> print(f"{alpha:.1f}°")  # 0° (high quality)
        >>> print(alpha.shape)      # () - scalar

        # Batch mode
        >>> R = np.array([1.0, 0.5, 0.0])
        >>> S = np.array([0.0, 0.3, 0.5])
        >>> N = np.array([0.0, 0.2, 0.5])
        >>> alpha = compute_alpha(R, S, N)
        >>> print(alpha)       # [0.0, 60.0, 180.0]
        >>> print(alpha.shape) # (3,) - batch

    Reference: series_005/expS5_001_SOLUTION.md
    """
    # Convert to numpy if needed
    R = np.asarray(R)

    # Clamp R to [0, 1] to avoid arccos domain errors
    R_clamped = np.clip(R, 0.0, 1.0)

    # Map to [0, 180] via arccos
    alpha = np.arccos(R_clamped) * 180.0 / np.pi

    return alpha


def compute_omega(
    R: Union[float, np.ndarray],
    S: Union[float, np.ndarray],
    N: Union[float, np.ndarray]
) -> np.ndarray:
    """
    Compute OOD (out-of-distribution) confidence from simplex geometry.

    Measures how confident we are in the prediction based on proximity
    to simplex boundary. Near boundary → High confidence (in-distribution),
    Near center → Low confidence (potentially OOD).

    DUAL-MODE API: Supports both scalar and batch inputs.

    Args:
        R: Relevance value(s) in [0, 1]
           - Scalar float → Returns 0-d array
           - 1-D array [N] → Returns 1-d array [N]
        S: Spurious value(s) in [0, 1] (same type/shape as R)
        N: Noise value(s) in [0, 1] (same type/shape as R)

    Returns:
        omega: OOD confidence in degrees [0, 90]
               Shape matches input: () for scalars, (N,) for arrays

        **IMPORTANT**: Range is [0, 90], NOT [0, 180)!
        This was corrected in v2.6 (Bug #3 in series_005/expS5_003)
        Mathematical constraint: arccos([0, 1]) → [0°, 90°]

    Interpretation:
        - omega ≈ 0°: High confidence, in-distribution (near boundary)
        - omega ≈ 45°: Medium confidence
        - omega ≈ 90°: Low confidence, potentially OOD (near center)

    Method:
        Uses phi_simplex (distance from center) as proxy:
        omega = arccos(phi_normalized) where phi_normalized ∈ [0, 1]

    Examples:
        # Scalar mode (at boundary)
        >>> omega = compute_omega(1.0, 0.0, 0.0)  # Pure R (boundary)
        >>> print(f"{omega:.1f}°")  # ~0° (high confidence)
        >>> print(omega.shape)      # () - scalar

        # Scalar mode (at center)
        >>> omega = compute_omega(1/3, 1/3, 1/3)  # Center
        >>> print(f"{omega:.1f}°")  # ~90° (low confidence, OOD)

        # Batch mode
        >>> R = np.array([1.0, 0.5, 1/3])
        >>> S = np.array([0.0, 0.3, 1/3])
        >>> N = np.array([0.0, 0.2, 1/3])
        >>> omega = compute_omega(R, S, N)
        >>> print(omega.shape)  # (3,) - batch

    Reference:
        - series_005/expS5_001_SOLUTION.md
        - series_005/expS5_003 Bug #3 (omega range correction)

    Note: This is a geometric proxy. True OOD detection may benefit from
    additional features (softmax entropy, Mahalanobis distance, etc.).
    """
    # Compute phi_simplex
    phi = compute_phi_simplex(R, S, N)

    # Normalize to [0, 1]
    phi_normalized = phi / 360.0

    # Clamp to [0, 1] for arccos domain
    phi_clamped = np.clip(phi_normalized, 0.0, 1.0)

    # Map to [0, 90] via arccos (NOT [0, 180] - that was docstring error)
    omega = np.arccos(phi_clamped) * 180.0 / np.pi

    return omega


def compute_t4_coordinates(
    R: Union[float, np.ndarray],
    S: Union[float, np.ndarray],
    N: Union[float, np.ndarray]
) -> dict:
    """
    Compute all T⁴ coordinates from RSN simplex values.

    Converts 3D RSN simplex coordinates (with R+S+N=1 constraint) to
    4D torus coordinates (simplex_theta, phi_simplex, alpha, omega).

    DUAL-MODE API (Scalar and Batch Processing):
    ---------------------------------------------
    This function supports BOTH single-certificate and batch modes:

    - **Scalar Mode**: Pass float values → Returns 0-dimensional numpy arrays (scalars)
    - **Batch Mode**: Pass 1-D arrays → Returns 1-dimensional numpy arrays

    The polymorphic behavior is achieved via np.asarray() and is intentional.
    This design enables flexible usage while maintaining type consistency.

    Args:
        R: Relevance value(s) in [0, 1]
           - Scalar: Single float (e.g., 0.65)
           - Array: Shape [N] for batch processing (e.g., np.array([0.65, 0.70]))
        S: Spurious value(s) in [0, 1] (same type/shape as R)
        N: Noise value(s) in [0, 1] (same type/shape as R)

    Returns:
        Dict with keys ['simplex_theta', 'phi_simplex', 'alpha', 'omega']

        **Return Shape Behavior**:
        - Scalar inputs → Dict values are 0-d numpy arrays (use float() to extract)
        - Array inputs → Dict values are 1-d numpy arrays (same length as input)

        **Coordinate Ranges**:
        - 'simplex_theta': [0, 360) degrees (angular position on simplex)
        - 'phi_simplex': [0, 360) degrees (distance from center, normalized)
        - 'alpha_t4': [0, 180) degrees (T⁴ quality angle, arccos(R))
        - 'omega_t4': [0, 90] degrees (T⁴ OOD angle, NOT [0, 180)!)
                      Mathematical constraint: arccos([0,1]) → [0°, 90°]
        - 'alpha': [0, 180) degrees (DEPRECATED - use 'alpha_t4')
        - 'omega': [0, 90] degrees (DEPRECATED - use 'omega_t4')

        **IMPORTANT**: The 'alpha_t4' and 'omega_t4' keys return ANGLES in degrees.
        These are DIFFERENT from certificate.alpha and certificate.omega which are
        scalar quality metrics in [0, 1]. See ALPHA_OMEGA_NAMESPACE_COLLISION_ANALYSIS.md

    T⁴ Topology:
        The output coordinates parameterize a 4-dimensional torus:
        T⁴ = S¹ × S¹ × S¹ × S¹

    Examples:
        # ========== SCALAR MODE (Single Certificate) ==========
        >>> # Common use case: Single certificate generation
        >>> coords = compute_t4_coordinates(0.65, 0.25, 0.10)
        >>>
        >>> # Returns 0-dimensional arrays (scalars wrapped in numpy)
        >>> print(coords['simplex_theta'].shape)  # ()
        >>> print(coords['alpha'].shape)          # ()
        >>>
        >>> # Extract Python float values (use _t4 suffix for angles)
        >>> theta = float(coords['simplex_theta'])  # 233.41
        >>> alpha_angle = float(coords['alpha_t4'])  # 50.21 (angle in degrees)
        >>>
        >>> # Direct indexing fails (0-d array has no indices)
        >>> # coords['simplex_theta'][0]  # ERROR: IndexError!

        # ========== BATCH MODE (Multiple Certificates) ==========
        >>> # Batch processing as specified in Patent §7.6.8.4
        >>> R = np.array([1.0, 0.5, 0.0])
        >>> S = np.array([0.0, 0.3, 0.5])
        >>> N = np.array([0.0, 0.2, 0.5])
        >>> coords = compute_t4_coordinates(R, S, N)
        >>>
        >>> # Returns 1-dimensional arrays
        >>> print(coords['simplex_theta'].shape)  # (3,)
        >>> print(coords['simplex_theta'])        # [240.0, 218.9, 180.0]
        >>> print(coords['alpha_t4'])             # [0.0, 60.0, 180.0] (angles in degrees)
        >>>
        >>> # Indexing works for batch mode
        >>> first_theta = coords['simplex_theta'][0]  # 240.0

    Usage in Persistent Homology:
        >>> # Normalize coordinates for Ripser/GUDHI
        >>> R_batch = np.array([0.7, 0.6, 0.5])
        >>> S_batch = np.array([0.2, 0.3, 0.3])
        >>> N_batch = np.array([0.1, 0.1, 0.2])
        >>> coords = compute_t4_coordinates(R_batch, S_batch, N_batch)
        >>>
        >>> t4_normalized = np.stack([
        ...     coords['simplex_theta'] / 360.0,  # [0, 1)
        ...     coords['phi_simplex'] / 360.0,    # [0, 1)
        ...     coords['alpha_t4'] / 180.0,       # [0, 1) - Use alpha_t4, not alpha
        ...     coords['omega_t4'] / 90.0,        # [0, 1] (NOT /180!) - Use omega_t4
        ... ], axis=-1)

    Patent Compliance:
        - §7.6.4.1: Direct Angular Encoding (barycentric-to-angular conversion)
        - §7.6.8.4: Batched Processing (batch mode support)
        - Extension: Scalar mode added for single-certificate ergonomics

    Reference:
        - series_005/expS5_001_SOLUTION.md
        - series_005/expS5_001_t4_persistent_homology_doe.md
        - docs/specs/patent_spec_section_7_6_toroidal_mapping.md
        - docs/specs/t4_dual_mode_api.md (API specification)
    """
    # Compute coordinate values
    alpha_angle = compute_alpha(R, S, N)
    omega_angle = compute_omega(R, S, N)

    return {
        'simplex_theta': compute_simplex_theta(R, S, N),
        'phi_simplex': compute_phi_simplex(R, S, N),
        # NEW: Preferred keys with _t4 suffix (angles in degrees)
        'alpha_t4': alpha_angle,
        'omega_t4': omega_angle,
        # DEPRECATED: Old keys for backward compatibility (will be removed in v3.0)
        'alpha': alpha_angle,
        'omega': omega_angle,
    }


# =============================================================================
# Pipeline Coordinate Functions (Series 005 Topology Experiments)
# =============================================================================

def compute_pipeline1_coords(R: np.ndarray, S: np.ndarray, N: np.ndarray) -> np.ndarray:
    """
    Pipeline 1: T⁴ Full - All 4 coordinates with hard domain boundaries.

    Returns [N, 4] array normalized to [0, 1]⁴ for persistent homology.
    Coordinates: (simplex_theta, phi_simplex, alpha, omega)

    This is the "current claim" - full T⁴ topology with hard boundaries at ±5°.
    """
    t4 = compute_t4_coordinates(R, S, N)
    return np.stack([
        t4['simplex_theta'] / 360.0,
        t4['phi_simplex'] / 360.0,
        t4['alpha_t4'] / 180.0,
        t4['omega_t4'] / 90.0,  # CRITICAL FIX: omega ∈ [0, 90], not [0, 180]
    ], axis=-1)


def compute_pipeline2_coords(R: np.ndarray, S: np.ndarray, N: np.ndarray) -> np.ndarray:
    """
    Pipeline 2: T² Intrinsic - Only intrinsic simplex coordinates.

    Returns [N, 2] array normalized to [0, 1]².
    Coordinates: (simplex_theta, phi_simplex)

    Tests if the true topology is just a 2-torus without the derived dimensions.
    """
    theta = compute_simplex_theta(R, S, N)
    phi = compute_phi_simplex(R, S, N)
    return np.stack([
        theta / 360.0,
        phi / 360.0,
    ], axis=-1)


def compute_pipeline3_coords(
    R: np.ndarray,
    S: np.ndarray,
    N: np.ndarray,
    compression_threshold: float = -5.0,
    expansion_threshold: float = 5.0,
) -> np.ndarray:
    """
    Pipeline 3: T³ + Domain Boundaries - Intrinsic coords + discrete domain label.

    Returns [N, 3] array normalized to [0, 1]³.
    Coordinates: (simplex_theta, phi_simplex, domain_discrete)

    Tests whether hard domain boundaries create topological artifacts.
    Domain labels: COMPRESSION=0, NEUTRAL=0.5, EXPANSION=1.0
    """
    from .collapse import classify_geometric_domain, GeometricDomain

    theta = compute_simplex_theta(R, S, N)
    phi = compute_phi_simplex(R, S, N)

    # Classify domains (hard boundaries)
    domain_labels = np.zeros(len(R))
    for i, t in enumerate(theta):
        domain = classify_geometric_domain(t, compression_threshold, expansion_threshold)
        if domain == GeometricDomain.COMPRESSION:
            domain_labels[i] = 0.0
        elif domain == GeometricDomain.NEUTRAL:
            domain_labels[i] = 0.5
        elif domain == GeometricDomain.EXPANSION:
            domain_labels[i] = 1.0
        else:
            domain_labels[i] = 0.5  # UNKNOWN -> treat as NEUTRAL

    return np.stack([
        theta / 360.0,
        phi / 360.0,
        domain_labels,
    ], axis=-1)


def compute_pipeline4_coords(
    R: np.ndarray,
    S: np.ndarray,
    N: np.ndarray,
    boundary_softness: float = 2.0,
) -> np.ndarray:
    """
    Pipeline 4: T⁴ Smoothed - All 4 coordinates with soft domain boundaries.

    Returns [N, 4] array normalized to [0, 1]⁴.
    Coordinates: (simplex_theta, phi_simplex, alpha_soft, omega_soft)

    Tests whether smoothing the boundaries reduces topological artifacts.
    Uses sigmoid to soften the hard ±5° thresholds.

    Args:
        boundary_softness: Controls sigmoid steepness (higher = softer, default 2.0)
    """
    theta = compute_simplex_theta(R, S, N)
    phi = compute_phi_simplex(R, S, N)

    # Compute alpha and omega with soft boundaries
    # Instead of hard thresholds, use sigmoid transitions

    # Soft alpha: sigmoid around compression/expansion boundaries
    # Map theta to [0, 1] with smooth transitions at ±5°
    alpha_soft = 1.0 / (1.0 + np.exp(-theta / boundary_softness))

    # Soft omega: smooth version based on distance from boundaries
    # Center at 0° (neutral), soft transitions at ±5°
    boundary_distance = np.minimum(np.abs(theta + 5), np.abs(theta - 5))
    omega_soft = 1.0 / (1.0 + np.exp(-boundary_distance / boundary_softness))

    return np.stack([
        theta / 360.0,
        phi / 360.0,
        alpha_soft,
        omega_soft,
    ], axis=-1)


# =============================================================================
# Binary Fingerprint Serialization (OP07)
# =============================================================================

def t4_to_bytes(coords: Dict[str, float]) -> bytes:
    """
    Serialize T⁴ coordinates to 32-byte fingerprint (OP07: FP_EMBED).

    Wire Format (Context Integrity ISA v0.1):
        - 4×float64 (IEEE 754, little-endian)
        - Order: simplex_theta, phi_simplex, alpha, omega
        - Total: 32 bytes (deterministic, hash-compatible)

    Args:
        coords: T⁴ coordinates dict with keys:
                - simplex_theta: [0, 360) degrees
                - phi_simplex: [0, 360) degrees
                - alpha: [0, 360) degrees (wrapped quality coordinate)
                - omega: [0, 360) degrees (wrapped reliability coordinate)

    Returns:
        32-byte binary fingerprint (deterministic for same coords)

    Raises:
        KeyError: If required coordinate missing
        ValueError: If coordinate values are invalid

    Example:
        >>> coords = {'simplex_theta': 90.0, 'phi_simplex': 180.0,
        ...           'alpha': 45.0, 'omega': 270.0}
        >>> fp = t4_to_bytes(coords)
        >>> len(fp)
        32
        >>> import hashlib
        >>> hashlib.sha256(fp).hexdigest()[:16]
        '5f7c3d2e1a9b...'

    Spec:
        docs/api/specifications/CONTEXT_INTEGRITY_ISA_v0.1.md OP07
    """
    import struct

    # Key order (wire format specification)
    keys = ['simplex_theta', 'phi_simplex', 'alpha', 'omega']

    # Extract values (raises KeyError if missing)
    values = [coords[k] for k in keys]

    # Validate ranges (all should be [0, 360))
    for i, (key, val) in enumerate(zip(keys, values)):
        if not (0.0 <= val < 360.0):
            raise ValueError(
                f"Coordinate '{key}' out of range [0, 360): {val}"
            )

    # Serialize: '<' = little-endian, '4d' = 4 doubles (float64)
    return struct.pack('<4d', *values)


def t4_from_bytes(data: bytes) -> Dict[str, float]:
    """
    Deserialize 32-byte fingerprint to T⁴ coordinates (OP07: FP_EMBED).

    Inverse of t4_to_bytes(). Used for roundtrip verification and
    baseline retrieval from registry.

    Args:
        data: 32-byte fingerprint (from t4_to_bytes)

    Returns:
        T⁴ coordinates dict with keys:
        - simplex_theta, phi_simplex, alpha, omega

    Raises:
        ValueError: If data is not exactly 32 bytes
        struct.error: If data is corrupted

    Example:
        >>> fp = t4_to_bytes({'simplex_theta': 90.0, 'phi_simplex': 180.0,
        ...                   'alpha': 45.0, 'omega': 270.0})
        >>> coords = t4_from_bytes(fp)
        >>> coords['simplex_theta']
        90.0

    Spec:
        docs/api/specifications/CONTEXT_INTEGRITY_ISA_v0.1.md OP07
    """
    import struct

    if len(data) != 32:
        raise ValueError(f"Expected 32 bytes, got {len(data)}")

    # Deserialize: '<' = little-endian, '4d' = 4 doubles
    values = struct.unpack('<4d', data)

    # Reconstruct dict (same key order as t4_to_bytes)
    keys = ['simplex_theta', 'phi_simplex', 'alpha', 'omega']
    return dict(zip(keys, values))


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # T⁴ Topology (NEW)
    'normalize_angle',
    'wrapped_angle_distance',
    'geodesic_distance_t4',
    'compute_winding_number',

    # T⁴ Coordinate System (NEW - Series 005)
    'compute_simplex_theta',
    'compute_phi_simplex',
    'compute_alpha',
    'compute_omega',
    'compute_t4_coordinates',

    # Pipeline Coordinate Functions (Series 005)
    'compute_pipeline1_coords',  # T⁴ full with hard boundaries
    'compute_pipeline2_coords',  # T² intrinsic only
    'compute_pipeline3_coords',  # T³ with discrete domain labels
    'compute_pipeline4_coords',  # T⁴ with soft boundaries

    # Binary Fingerprint Serialization (ISA OP07)
    't4_to_bytes',
    't4_from_bytes',

    # Legacy (Backward Compatibility)
    'compute_curvature_simple',
    'compute_geodesic_deviation_simple',
]
