"""
R/S/N Validation and Quality Assessment

This module provides tools for validating R/S/N decomposition quality
against ground truth data and computing quality metrics.

Key features:
1. Classification metrics (accuracy, precision, recall, F1)
2. Separation score (inter-class vs intra-class distance)
3. Orthogonality score (subspace independence)
4. Visualization utilities
5. Ground truth dataset utilities

Based on research synthesis:
- Standard ML evaluation metrics
- Representation quality assessment
- Visualization for interpretability
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import numpy as np
from collections import defaultdict

from . import DecompositionScore


# =============================================================================
# Validation Results
# =============================================================================

@dataclass
class ClassMetrics:
    """Per-class metrics."""
    precision: float
    recall: float
    f1: float
    support: int  # Number of samples


@dataclass
class ValidationResult:
    """Results from R/S/N quality validation."""
    # Overall metrics
    accuracy: float
    macro_f1: float
    weighted_f1: float

    # Per-class metrics
    class_metrics: Dict[str, ClassMetrics]

    # Confusion matrix [true, pred]
    confusion_matrix: np.ndarray

    # Representation quality
    separation_score: float  # Inter/intra class distance ratio
    orthogonality_score: float  # Subspace independence (1 = orthogonal)
    calibration_error: float  # Expected calibration error

    # Additional info
    num_samples: int
    timestamp: float = field(default_factory=lambda: __import__('time').time())

    def to_dict(self) -> Dict[str, Any]:
        return {
            'accuracy': self.accuracy,
            'macro_f1': self.macro_f1,
            'weighted_f1': self.weighted_f1,
            'class_metrics': {
                k: {
                    'precision': v.precision,
                    'recall': v.recall,
                    'f1': v.f1,
                    'support': v.support,
                }
                for k, v in self.class_metrics.items()
            },
            'confusion_matrix': self.confusion_matrix.tolist(),
            'separation_score': self.separation_score,
            'orthogonality_score': self.orthogonality_score,
            'calibration_error': self.calibration_error,
            'num_samples': self.num_samples,
            'timestamp': self.timestamp,
        }

    def __str__(self) -> str:
        lines = [
            "=" * 50,
            "R/S/N Validation Results",
            "=" * 50,
            f"Accuracy: {self.accuracy:.4f}",
            f"Macro F1: {self.macro_f1:.4f}",
            f"Weighted F1: {self.weighted_f1:.4f}",
            "",
            "Per-class metrics:",
        ]

        for cls_name, metrics in self.class_metrics.items():
            lines.append(
                f"  {cls_name}: P={metrics.precision:.3f} R={metrics.recall:.3f} "
                f"F1={metrics.f1:.3f} (n={metrics.support})"
            )

        lines.extend([
            "",
            "Representation quality:",
            f"  Separation score: {self.separation_score:.4f}",
            f"  Orthogonality score: {self.orthogonality_score:.4f}",
            f"  Calibration error: {self.calibration_error:.4f}",
            "",
            f"Total samples: {self.num_samples}",
            "=" * 50,
        ])

        return "\n".join(lines)


# =============================================================================
# RSN Validator
# =============================================================================

class RSNValidator:
    """
    Validate R/S/N decomposition quality against ground truth.

    Computes comprehensive metrics including:
    - Classification accuracy
    - Per-class precision, recall, F1
    - Separation score (representation quality)
    - Orthogonality score (subspace independence)
    - Calibration error
    """

    def __init__(
        self,
        device: Optional[torch.device] = None,
    ):
        self.device = device or torch.device('cpu')
        self.class_names = {0: 'R', 1: 'S', 2: 'N'}

    def validate(
        self,
        model: nn.Module,
        dataloader: DataLoader,
        compute_calibration: bool = True,
    ) -> ValidationResult:
        """
        Validate model on a dataset.

        Args:
            model: Model with forward() returning {'logits': [B, 3]} or [B, 3] tensor
                ⚠️ IMPORTANT: Model must output RAW LOGITS (before softmax), NOT probabilities
                This validator applies softmax internally. If your model outputs probabilities,
                you will get incorrect results due to double softmax.
            dataloader: DataLoader yielding (embeddings, labels) or (embeddings, labels, weights)
                Labels should be R/S/N class indices: 0=R, 1=S, 2=N
            compute_calibration: Whether to compute calibration error

        Returns:
            ValidationResult with all metrics

        Example:
            # CORRECT: Use quality_classifier (outputs logits)
            output = projection_heads(embeddings, return_classification=True)
            logits = output['logits']  # Raw logits
            validator.validate(model_wrapper, dataloader)  # ✓ Correct
            
            # WRONG: Using score_predictor (outputs probabilities)
            output = projection_heads(embeddings, return_scores=True)
            scores = output['scores']  # Already probabilities (after softmax)
            # validator applies softmax again → double softmax → wrong results!
        """
        model.eval()
        model.to(self.device)

        all_preds = []
        all_labels = []
        all_probs = []
        all_embeddings = []

        with torch.no_grad():
            for batch in dataloader:
                if len(batch) == 2:
                    embeddings, labels = batch
                else:
                    embeddings, labels, _ = batch

                embeddings = embeddings.to(self.device)
                labels = labels.to(self.device)

                # Get model output
                # ⚠️ IMPORTANT: Model should output RAW LOGITS (before softmax)
                # We apply softmax here, so providing probabilities causes double softmax
                output = model(embeddings)
                if isinstance(output, dict):
                    logits = output.get('logits', output.get('probs'))
                else:
                    logits = output

                # Apply softmax to get probabilities (assumes logits input)
                # If input is already probabilities, this causes double softmax distortion
                probs = F.softmax(logits, dim=-1)
                preds = logits.argmax(dim=-1)

                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs.cpu().numpy())
                all_embeddings.append(embeddings.cpu())

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)
        all_probs = np.array(all_probs)
        all_embeddings = torch.cat(all_embeddings, dim=0)

        # Compute metrics
        accuracy = (all_preds == all_labels).mean()

        # Per-class metrics
        class_metrics = {}
        f1_scores = []
        weights = []

        for cls_idx, cls_name in self.class_names.items():
            cls_mask = all_labels == cls_idx
            pred_mask = all_preds == cls_idx

            tp = np.sum(cls_mask & pred_mask)
            fp = np.sum(~cls_mask & pred_mask)
            fn = np.sum(cls_mask & ~pred_mask)

            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            support = int(cls_mask.sum())

            class_metrics[cls_name] = ClassMetrics(
                precision=precision,
                recall=recall,
                f1=f1,
                support=support,
            )

            f1_scores.append(f1)
            weights.append(support)

        # Macro and weighted F1
        macro_f1 = np.mean(f1_scores)
        total_support = sum(weights)
        weighted_f1 = sum(f1 * w for f1, w in zip(f1_scores, weights)) / max(total_support, 1)

        # Confusion matrix
        confusion_matrix = np.zeros((3, 3), dtype=np.int32)
        for true, pred in zip(all_labels, all_preds):
            confusion_matrix[true, pred] += 1

        # Separation score
        separation_score = self._compute_separation_score(
            model, all_embeddings, torch.tensor(all_labels)
        )

        # Orthogonality score
        orthogonality_score = self._compute_orthogonality_score(model)

        # Calibration error
        calibration_error = 0.0
        if compute_calibration:
            calibration_error = self._compute_calibration_error(all_probs, all_labels)

        return ValidationResult(
            accuracy=accuracy,
            macro_f1=macro_f1,
            weighted_f1=weighted_f1,
            class_metrics=class_metrics,
            confusion_matrix=confusion_matrix,
            separation_score=separation_score,
            orthogonality_score=orthogonality_score,
            calibration_error=calibration_error,
            num_samples=len(all_labels),
        )

    def _compute_separation_score(
        self,
        model: nn.Module,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
    ) -> float:
        """
        Compute separation score: ratio of inter-class to intra-class distance.

        Higher is better (classes are well-separated).
        """
        model.eval()
        embeddings = embeddings.to(self.device)
        labels = labels.to(self.device)

        with torch.no_grad():
            # Get representations
            output = model(embeddings)
            if isinstance(output, dict):
                # Try to get projected embeddings
                if 'R' in output:
                    proj = (output['R'] + output['S'] + output['N']) / 3
                else:
                    # Use logits as representation
                    proj = output.get('logits', output.get('probs'))
            else:
                proj = output

            if proj is None:
                return 0.0

            # Compute centroids
            centroids = {}
            for cls_idx in range(3):
                mask = labels == cls_idx
                if mask.sum() > 0:
                    centroids[cls_idx] = proj[mask].mean(dim=0)
                else:
                    return 0.0  # Can't compute without all classes

            # Inter-class distance (average pairwise centroid distance)
            inter_dist = 0.0
            count = 0
            for i in range(3):
                for j in range(i + 1, 3):
                    inter_dist += torch.dist(centroids[i], centroids[j]).item()
                    count += 1
            inter_dist /= max(count, 1)

            # Intra-class distance (average distance to centroid)
            intra_dist = 0.0
            for cls_idx in range(3):
                mask = labels == cls_idx
                if mask.sum() > 0:
                    class_embs = proj[mask]
                    dists = torch.cdist(class_embs, centroids[cls_idx].unsqueeze(0))
                    intra_dist += dists.mean().item()
            intra_dist /= 3

            return inter_dist / (intra_dist + 1e-8)

    def _compute_orthogonality_score(self, model: nn.Module) -> float:
        """
        Compute orthogonality score for R/S/N subspaces.

        Returns score in [0, 1] where 1 = perfectly orthogonal.
        """
        # Try to get projection weights
        weights = {}

        if hasattr(model, 'R_head') and model.R_head is not None:
            weights['R'] = model.R_head.weight if hasattr(model.R_head, 'weight') else None
        if hasattr(model, 'S_head') and model.S_head is not None:
            weights['S'] = model.S_head.weight if hasattr(model.S_head, 'weight') else None
        if hasattr(model, 'N_head') and model.N_head is not None:
            weights['N'] = model.N_head.weight if hasattr(model.N_head, 'weight') else None

        if hasattr(model, 'get_projection_weights'):
            weights = model.get_projection_weights()

        if not all(k in weights and weights[k] is not None for k in ['R', 'S', 'N']):
            return 0.5  # Can't compute

        R_w = weights['R'].detach()
        S_w = weights['S'].detach()
        N_w = weights['N'].detach()

        # Compute pairwise overlaps
        RS_overlap = torch.norm(torch.mm(R_w.t(), S_w), p='fro').item()
        RN_overlap = torch.norm(torch.mm(R_w.t(), N_w), p='fro').item()
        SN_overlap = torch.norm(torch.mm(S_w.t(), N_w), p='fro').item()

        total_overlap = RS_overlap + RN_overlap + SN_overlap

        # Convert to score (lower overlap = higher orthogonality)
        # Normalize by expected overlap for random matrices
        dim = R_w.shape[0] * R_w.shape[1]
        expected_overlap = np.sqrt(dim) * 3  # Rough estimate

        score = 1.0 / (1.0 + total_overlap / max(expected_overlap, 1))

        return score

    def _compute_calibration_error(
        self,
        probs: np.ndarray,
        labels: np.ndarray,
        num_bins: int = 10,
    ) -> float:
        """
        Compute Expected Calibration Error (ECE).

        ECE measures how well predicted probabilities match actual accuracy.
        """
        confidences = probs.max(axis=1)
        predictions = probs.argmax(axis=1)
        accuracies = (predictions == labels).astype(float)

        # Bin by confidence
        bin_boundaries = np.linspace(0, 1, num_bins + 1)
        ece = 0.0

        for i in range(num_bins):
            in_bin = (confidences >= bin_boundaries[i]) & (confidences < bin_boundaries[i + 1])
            prop_in_bin = in_bin.mean()

            if prop_in_bin > 0:
                avg_confidence = confidences[in_bin].mean()
                avg_accuracy = accuracies[in_bin].mean()
                ece += np.abs(avg_accuracy - avg_confidence) * prop_in_bin

        return ece


# =============================================================================
# Ground Truth Dataset
# =============================================================================

class GroundTruthDataset(Dataset):
    """
    Dataset with ground truth R/S/N labels.

    Can be created from:
    1. Manual annotations (from file)
    2. Synthetic generation
    3. Model distillation
    """

    def __init__(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        metadata: Optional[List[Dict]] = None,
    ):
        self.embeddings = embeddings
        self.labels = labels
        self.metadata = metadata or [{} for _ in range(len(labels))]

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        return self.embeddings[idx], self.labels[idx].item()

    @classmethod
    def from_annotations(cls, path: str) -> 'GroundTruthDataset':
        """
        Load from annotation file (JSON).

        Expected format:
        {
            "samples": [
                {"embedding": [...], "label": 0, "text": "...", ...},
                ...
            ]
        }
        """
        import json
        with open(path, 'r') as f:
            data = json.load(f)

        samples = data.get('samples', data)

        embeddings = torch.tensor([s['embedding'] for s in samples], dtype=torch.float32)
        labels = torch.tensor([s['label'] for s in samples], dtype=torch.long)
        metadata = [{k: v for k, v in s.items() if k not in ['embedding', 'label']}
                   for s in samples]

        return cls(embeddings, labels, metadata)

    @classmethod
    def generate_synthetic(
        cls,
        num_samples: int = 10000,
        embedding_dim: int = 768,
        class_separation: float = 2.0,
        noise_level: float = 0.3,
        class_balance: Tuple[float, float, float] = (0.33, 0.33, 0.34),
    ) -> 'GroundTruthDataset':
        """
        Generate synthetic R/S/N examples.

        Creates embeddings with clear R/S/N characteristics:
        - R: High query relevance (clustered in specific direction)
        - S: Medium relevance (between R and N)
        - N: Low relevance, high variance (scattered)

        Args:
            num_samples: Number of samples to generate
            embedding_dim: Dimension of embeddings
            class_separation: How far apart class centroids are
            noise_level: Amount of noise to add
            class_balance: Proportion of each class

        Returns:
            GroundTruthDataset with synthetic data
        """
        # Generate class centroids
        np.random.seed(42)

        R_centroid = np.random.randn(embedding_dim)
        R_centroid = R_centroid / np.linalg.norm(R_centroid) * class_separation

        S_centroid = np.random.randn(embedding_dim)
        S_centroid = S_centroid / np.linalg.norm(S_centroid) * class_separation * 0.5

        N_centroid = np.zeros(embedding_dim)  # N is centered at origin (no structure)

        # Generate samples for each class
        embeddings = []
        labels = []

        n_R = int(num_samples * class_balance[0])
        n_S = int(num_samples * class_balance[1])
        n_N = num_samples - n_R - n_S

        # R samples: tight cluster around R_centroid
        R_samples = R_centroid + np.random.randn(n_R, embedding_dim) * noise_level * 0.5
        embeddings.append(R_samples)
        labels.extend([0] * n_R)

        # S samples: spread around S_centroid
        S_samples = S_centroid + np.random.randn(n_S, embedding_dim) * noise_level
        embeddings.append(S_samples)
        labels.extend([1] * n_S)

        # N samples: high variance, no clear structure
        N_samples = N_centroid + np.random.randn(n_N, embedding_dim) * noise_level * 2
        embeddings.append(N_samples)
        labels.extend([2] * n_N)

        embeddings = np.vstack(embeddings)
        labels = np.array(labels)

        # Shuffle
        indices = np.random.permutation(len(labels))
        embeddings = embeddings[indices]
        labels = labels[indices]

        return cls(
            torch.tensor(embeddings, dtype=torch.float32),
            torch.tensor(labels, dtype=torch.long),
        )

    @classmethod
    def from_model_distillation(
        cls,
        teacher_model: nn.Module,
        embeddings: torch.Tensor,
        confidence_threshold: float = 0.8,
        device: Optional[torch.device] = None,
    ) -> 'GroundTruthDataset':
        """
        Create dataset by distilling from a teacher model.

        Uses high-confidence predictions as pseudo-labels.

        Args:
            teacher_model: Trained teacher model
            embeddings: [N, D] unlabeled embeddings
            confidence_threshold: Minimum confidence for inclusion
            device: Device for inference

        Returns:
            GroundTruthDataset with high-confidence samples
        """
        device = device or torch.device('cpu')
        teacher_model.eval()
        teacher_model.to(device)

        selected_embeddings = []
        selected_labels = []
        selected_metadata = []

        batch_size = 64
        with torch.no_grad():
            for i in range(0, len(embeddings), batch_size):
                batch = embeddings[i:i + batch_size].to(device)

                output = teacher_model(batch)
                if isinstance(output, dict):
                    logits = output.get('logits', output.get('probs'))
                else:
                    logits = output

                probs = F.softmax(logits, dim=-1)
                confidences, predictions = probs.max(dim=-1)

                # Select high-confidence samples
                mask = confidences >= confidence_threshold

                selected_embeddings.append(batch[mask].cpu())
                selected_labels.extend(predictions[mask].cpu().numpy())
                selected_metadata.extend([
                    {'confidence': conf.item(), 'probs': prob.tolist()}
                    for conf, prob in zip(confidences[mask], probs[mask])
                ])

        if not selected_embeddings:
            raise ValueError("No samples passed confidence threshold")

        return cls(
            torch.cat(selected_embeddings, dim=0),
            torch.tensor(selected_labels, dtype=torch.long),
            selected_metadata,
        )

    def get_dataloader(
        self,
        batch_size: int = 32,
        shuffle: bool = True,
    ) -> DataLoader:
        """Create DataLoader from this dataset."""
        return DataLoader(self, batch_size=batch_size, shuffle=shuffle)

    def get_class_distribution(self) -> Dict[str, int]:
        """Get count of each class."""
        class_names = {0: 'R', 1: 'S', 2: 'N'}
        distribution = defaultdict(int)

        for label in self.labels:
            distribution[class_names[label.item()]] += 1

        return dict(distribution)

    def split(
        self,
        train_ratio: float = 0.8,
        seed: int = 42,
    ) -> Tuple['GroundTruthDataset', 'GroundTruthDataset']:
        """Split into train and test datasets."""
        np.random.seed(seed)
        n = len(self)
        indices = np.random.permutation(n)

        train_size = int(n * train_ratio)
        train_indices = indices[:train_size]
        test_indices = indices[train_size:]

        train_dataset = GroundTruthDataset(
            self.embeddings[train_indices],
            self.labels[train_indices],
            [self.metadata[i] for i in train_indices] if self.metadata else None,
        )

        test_dataset = GroundTruthDataset(
            self.embeddings[test_indices],
            self.labels[test_indices],
            [self.metadata[i] for i in test_indices] if self.metadata else None,
        )

        return train_dataset, test_dataset


# =============================================================================
# Quick Validation Functions
# =============================================================================

def quick_validate(
    model: nn.Module,
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    device: Optional[torch.device] = None,
) -> ValidationResult:
    """
    Quick validation on a batch of data.

    Args:
        model: Model to validate
        embeddings: [N, D] embeddings
        labels: [N] R/S/N labels

    Returns:
        ValidationResult
    """
    dataset = GroundTruthDataset(embeddings, labels)
    dataloader = dataset.get_dataloader(batch_size=64, shuffle=False)

    validator = RSNValidator(device=device)
    return validator.validate(model, dataloader)


def validate_separation(
    projections: Dict[str, torch.Tensor],
    labels: torch.Tensor,
) -> float:
    """
    Quick separation score from projections.

    Args:
        projections: Dict with 'R', 'S', 'N' tensors
        labels: R/S/N labels

    Returns:
        Separation score
    """
    # Combine projections
    combined = (projections['R'] + projections['S'] + projections['N']) / 3

    # Compute centroids
    centroids = {}
    for cls_idx in range(3):
        mask = labels == cls_idx
        if mask.sum() > 0:
            centroids[cls_idx] = combined[mask].mean(dim=0)
        else:
            return 0.0

    # Inter-class distance
    inter_dist = 0.0
    for i in range(3):
        for j in range(i + 1, 3):
            inter_dist += torch.dist(centroids[i], centroids[j]).item()
    inter_dist /= 3

    # Intra-class distance
    intra_dist = 0.0
    for cls_idx in range(3):
        mask = labels == cls_idx
        if mask.sum() > 0:
            dists = torch.cdist(combined[mask], centroids[cls_idx].unsqueeze(0))
            intra_dist += dists.mean().item()
    intra_dist /= 3

    return inter_dist / (intra_dist + 1e-8)


# =============================================================================
# Retrieval Sink Metrics (NeurIPS 2024 Gated Attention inspired)
# =============================================================================


@dataclass
class RetrievalSinkMetrics:
    """
    Metrics for measuring the "retrieval sink" phenomenon.

    WHAT IS A RETRIEVAL SINK?
    Analogous to "attention sinks" in transformers (where first tokens receive
    disproportionate attention), retrieval sinks occur when certain passages
    dominate retrieval scores regardless of actual query relevance.

    PROBLEM: In RAG systems, the first retrieved passage often gets ~47% of
    attention weight even when it's not the most relevant. This biases
    generation toward early-retrieved content.

    SOLUTION: Measure the sink, then apply gating (see supervised_heads.py
    GatedYRSNProjectionHeads) to fix it.

    Attributes
    ----------
    first_passage_attention : float
        Fraction of total attention on first passage (0.0-1.0)
        HEALTHY: < 0.15 (uniform would be 1/n)
        SINK: > 0.20 (first passage getting 20%+ when it shouldn't)

    top_3_concentration : float
        Fraction of attention on top 3 passages combined
        HEALTHY: < 0.50 for 10+ passages
        CONCENTRATED: > 0.70 (attention too focused)

    query_correlation : float
        Pearson correlation between attention and ground-truth relevance
        HIGH (> 0.7): Attention tracks relevance well
        LOW (< 0.3): Attention is not following relevance (possible sink)

    sink_ratio : float
        first_passage_attention / expected_uniform_attention
        = 1.0: Perfectly uniform
        > 2.0: First passage getting 2x expected attention (definite sink)
    """
    first_passage_attention: float
    top_3_concentration: float
    query_correlation: float
    sink_ratio: float

    @property
    def has_sink(self) -> bool:
        """
        True if retrieval sink detected.

        Threshold: >20% attention on first passage is considered a sink.
        For 10 passages, uniform would be 10%, so 20% is 2x expected.
        """
        return self.first_passage_attention > 0.20

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary for serialization."""
        return {
            'first_passage_attention': self.first_passage_attention,
            'top_3_concentration': self.top_3_concentration,
            'query_correlation': self.query_correlation,
            'sink_ratio': self.sink_ratio,
            'has_sink': self.has_sink,
        }

    def __str__(self) -> str:
        status = "🚨 SINK DETECTED" if self.has_sink else "✓ No sink"
        return (
            f"RetrievalSinkMetrics({status})\n"
            f"  first_passage_attention: {self.first_passage_attention:.3f}\n"
            f"  top_3_concentration: {self.top_3_concentration:.3f}\n"
            f"  query_correlation: {self.query_correlation:.3f}\n"
            f"  sink_ratio: {self.sink_ratio:.2f}x"
        )


def measure_retrieval_sink(
    attention_weights: np.ndarray,
    relevance_scores: Optional[np.ndarray] = None,
) -> RetrievalSinkMetrics:
    """
    Measure retrieval sink phenomenon in attention distributions.

    USE CASES:
    1. Diagnose RAG quality issues ("why is generation biased?")
    2. A/B test gating effectiveness (measure before/after applying gates)
    3. Monitor production systems for sink drift

    Parameters
    ----------
    attention_weights : np.ndarray
        Attention weights over passages, shape [num_queries, num_passages]
        Each row should sum to ~1.0 (softmax output)

    relevance_scores : np.ndarray, optional
        Ground truth relevance scores for correlation analysis
        Same shape as attention_weights
        If provided, enables query_correlation metric

    Returns
    -------
    RetrievalSinkMetrics
        Complete sink measurements for analysis

    Example
    -------
    >>> # Simulate sink: first passage gets 50% of attention
    >>> weights = np.array([[0.5, 0.2, 0.1, 0.1, 0.1]])
    >>> metrics = measure_retrieval_sink(weights)
    >>> metrics.has_sink
    True
    >>> metrics.sink_ratio
    2.5  # First passage gets 2.5x expected (0.5 / 0.2)

    >>> # Healthy distribution: relatively uniform
    >>> weights = np.array([[0.25, 0.20, 0.20, 0.18, 0.17]])
    >>> metrics = measure_retrieval_sink(weights)
    >>> metrics.has_sink
    False
    """
    # STEP 1: Ensure 2D array [num_queries, num_passages]
    if attention_weights.ndim == 1:
        attention_weights = attention_weights.reshape(1, -1)

    num_passages = attention_weights.shape[1]

    # Expected attention per passage if uniform distribution
    expected_uniform = 1.0 / num_passages

    # STEP 2: Measure first passage attention (key sink indicator)
    first_passage = float(attention_weights[:, 0].mean())

    # STEP 3: Measure concentration on top 3 passages
    sorted_weights = np.sort(attention_weights, axis=1)[:, ::-1]  # Descending
    top_3 = float(sorted_weights[:, :3].sum(axis=1).mean())

    # STEP 4: Compute attention-relevance correlation (if ground truth available)
    if relevance_scores is not None:
        if relevance_scores.ndim == 1:
            relevance_scores = relevance_scores.reshape(1, -1)

        correlations = []
        for i in range(attention_weights.shape[0]):
            corr = np.corrcoef(attention_weights[i], relevance_scores[i])[0, 1]
            if not np.isnan(corr):
                correlations.append(corr)
        query_correlation = float(np.mean(correlations)) if correlations else 0.0
    else:
        query_correlation = 0.0

    # STEP 5: Return structured metrics
    return RetrievalSinkMetrics(
        first_passage_attention=first_passage,
        top_3_concentration=top_3,
        query_correlation=query_correlation,
        sink_ratio=first_passage / expected_uniform,
    )


def diagnose_attention_quality(
    attention_weights: np.ndarray,
    relevance_scores: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """
    Comprehensive attention quality diagnosis.

    Combines sink detection with additional metrics for debugging.

    Args:
        attention_weights: [num_queries, num_passages] attention distribution
        relevance_scores: Optional ground truth for correlation

    Returns:
        Dict with sink_metrics, recommendations, and summary
    """
    metrics = measure_retrieval_sink(attention_weights, relevance_scores)

    recommendations = []
    severity = "low"

    if metrics.has_sink:
        severity = "high"
        recommendations.append("Apply gated projection heads (GatedYRSNProjectionHeads)")
        recommendations.append("Check if first passages are over-indexed in retrieval")

    if metrics.sink_ratio > 3.0:
        severity = "critical"
        recommendations.append("Consider re-ranking retrieved passages")
        recommendations.append("Audit retrieval index for bias")

    if metrics.top_3_concentration > 0.80:
        recommendations.append("Attention is highly concentrated - increase temperature")

    if relevance_scores is not None and metrics.query_correlation < 0.3:
        recommendations.append("Attention doesn't track relevance - model may need fine-tuning")

    return {
        'sink_metrics': metrics.to_dict(),
        'severity': severity,
        'recommendations': recommendations,
        'summary': str(metrics),
    }


# =============================================================================
# Exports
# =============================================================================

# =============================================================================
# Attention Sink Detection (NeurIPS 2025 Theme 1)
# =============================================================================


@dataclass
class AttentionSinkResult:
    """
    Result of attention sink detection analysis.

    Attention sinks are tokens that attract attention without contributing signal.
    In YRSN terms: high-S tokens masquerading as high-R.
    """
    token_position: int
    incoming_attention: float      # Sum of attention weights TO this token
    r_score: float                 # YRSN relevance score
    is_sink: bool                  # True if high attention + low relevance
    sink_severity: float           # Degree of sink behavior (0-1)


class AttentionSinkDetector:
    """
    Identifies attention sinks using YRSN R-score analysis.

    NeurIPS 2025 Theme 1: Attention Plumbing Integration

    The Problem:
    - Attention sinks: Tokens that attract attention without contributing signal
    - Quadratic scaling: O(n²) makes long contexts expensive
    - Wasteful computation: Attending equally to relevant and irrelevant tokens

    YRSN Lens:
    Attention sinks are tokens with:
    - High incoming attention (other tokens attend to them)
    - Low R-score (they don't contribute to relevant signal)

    These are essentially high-S tokens masquerading as important.

    R-Score Guided Attention Gating:
    | Token Type | R Score | Attention Treatment       |
    |------------|---------|---------------------------|
    | Signal     | >0.6    | Full attention (dense)    |
    | Context    | 0.3-0.6 | Sparse attention          |
    | Noise      | <0.3    | Gated out (zero attention)|

    Usage:
        detector = AttentionSinkDetector()
        results = detector.detect_sinks(attention_weights, r_scores)

        for r in results:
            if r.is_sink:
                print(f"Sink at position {r.token_position}: "
                      f"attention={r.incoming_attention:.3f}, R={r.r_score:.3f}")
    """

    def __init__(
        self,
        attention_threshold: float = 0.1,   # Min incoming attention to consider
        r_threshold: float = 0.3,           # R-score below this = potential sink
        sink_severity_scale: float = 1.0    # Scaling for severity calculation
    ):
        """
        Initialize attention sink detector.

        Parameters
        ----------
        attention_threshold : float
            Minimum incoming attention weight to consider as potential sink.
        r_threshold : float
            R-score below this threshold indicates a potential sink.
        sink_severity_scale : float
            Scaling factor for severity calculation.
        """
        self.attention_threshold = attention_threshold
        self.r_threshold = r_threshold
        self.sink_severity_scale = sink_severity_scale

    def detect_sinks(
        self,
        attention_weights: np.ndarray,  # Shape: [seq_len, seq_len]
        r_scores: np.ndarray            # Shape: [seq_len]
    ) -> List[AttentionSinkResult]:
        """
        Identify attention sinks in the sequence.

        Parameters
        ----------
        attention_weights : np.ndarray
            Attention matrix where [i,j] = attention from i to j
        r_scores : np.ndarray
            Per-token R-scores from YRSN decomposition

        Returns
        -------
        list of AttentionSinkResult
            Sink detection results for each token
        """
        seq_len = len(r_scores)
        results = []

        for pos in range(seq_len):
            # Sum attention flowing TO this position
            incoming = float(attention_weights[:, pos].sum())
            r_score = float(r_scores[pos])

            # Sink = high attention + low relevance
            is_sink = incoming > self.attention_threshold and r_score < self.r_threshold

            # Severity: how much attention is "wasted" on low-R tokens
            if is_sink:
                severity = min(1.0,
                    self.sink_severity_scale * incoming * (1 - r_score)
                )
            else:
                severity = 0.0

            results.append(AttentionSinkResult(
                token_position=pos,
                incoming_attention=incoming,
                r_score=r_score,
                is_sink=is_sink,
                sink_severity=severity
            ))

        return results

    def compute_sink_ratio(self, results: List[AttentionSinkResult]) -> float:
        """Compute fraction of tokens that are sinks."""
        if not results:
            return 0.0
        return sum(1 for r in results if r.is_sink) / len(results)

    def get_sink_positions(self, results: List[AttentionSinkResult]) -> List[int]:
        """Get positions of all sink tokens."""
        return [r.token_position for r in results if r.is_sink]

    def create_attention_mask(
        self,
        r_scores: np.ndarray,
        signal_threshold: float = 0.6,
        context_threshold: float = 0.3
    ) -> np.ndarray:
        """
        Create R-score guided attention mask.

        Returns a mask with values:
        - 1.0 for signal tokens (R > signal_threshold)
        - 0.5 for context tokens (context_threshold <= R <= signal_threshold)
        - 0.0 for noise tokens (R < context_threshold)

        Parameters
        ----------
        r_scores : np.ndarray
            Per-token R-scores
        signal_threshold : float
            R-score above this = full attention
        context_threshold : float
            R-score below this = zero attention

        Returns
        -------
        np.ndarray
            Attention mask for gating
        """
        mask = np.zeros_like(r_scores)

        # Signal: full attention
        mask[r_scores > signal_threshold] = 1.0

        # Context: sparse attention
        context_mask = (r_scores >= context_threshold) & (r_scores <= signal_threshold)
        mask[context_mask] = 0.5

        # Noise: gated out (already 0.0)

        return mask


# =============================================================================
# Diffusion Quality Tracking (NeurIPS 2025 Theme 4)
# =============================================================================


@dataclass
class DiffusionStepState:
    """
    State at a single diffusion step.

    Tracks the N→S→R trajectory during denoising.
    """
    step: int
    t_frac: float              # Normalized timestep (0=clean, 1=noise)
    r_score: float
    s_score: float
    n_score: float
    quality_alpha: float       # α = R/(R+S+N)
    is_memorized: bool
    phase_transition: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'step': self.step,
            't_frac': self.t_frac,
            'r_score': self.r_score,
            's_score': self.s_score,
            'n_score': self.n_score,
            'quality_alpha': self.quality_alpha,
            'is_memorized': self.is_memorized,
            'phase_transition': self.phase_transition,
        }


class DiffusionQualityTracker:
    """
    Tracks N→S→R trajectory during diffusion denoising.

    NeurIPS 2025 Theme 4: Diffusion for Quality Understanding

    Key insight: diffusion denoising follows the YRSN trajectory:
    - Early steps: High N (noise), low S, low R
    - Middle steps: Decreasing N, rising S (patterns), emerging R
    - Late steps: Low N, stable S, high R (signal)

    Diffusion as N→S→R Trajectory:
    | Diffusion Step | YRSN State           | Content Type          |
    |----------------|----------------------|-----------------------|
    | t=T (noise)    | N=1.0, S=0, R=0      | Pure noise            |
    | t=0.7T         | N=0.6, S=0.3, R=0.1  | Structure emerges     |
    | t=0.5T         | N=0.3, S=0.4, R=0.3  | Patterns crystallize  |
    | t=0.3T         | N=0.1, S=0.5, R=0.4  | Details refine        |
    | t=0 (clean)    | N=0.05, S=0.4, R=0.55| Final output          |

    The memorization boundary is where generation shifts from
    creative (R-dominant) to retrieval (S-dominant): t* where dS/dt > dR/dt

    Usage:
        tracker = DiffusionQualityTracker()

        trajectory = tracker.track_trajectory(
            total_steps=1000,
            decompose_fn=my_decompose,
            denoise_step_fn=diffusion_model.denoise_step,
        )

        # Find memorization boundary
        boundary = tracker.find_memorization_boundary(trajectory)

        # Classify final output
        classification = tracker.classify_generation(
            final_r=0.55, final_s=0.4, training_similarity=0.3
        )
    """

    def __init__(
        self,
        memorization_similarity_threshold: float = 0.8,
        phase_transition_alpha: float = 0.5
    ):
        """
        Initialize diffusion quality tracker.

        Parameters
        ----------
        memorization_similarity_threshold : float
            Similarity to training data above this = memorization
        phase_transition_alpha : float
            Quality threshold for detecting creativity→refinement transition
        """
        self.memorization_threshold = memorization_similarity_threshold
        self.phase_transition_alpha = phase_transition_alpha

    def track_trajectory(
        self,
        total_steps: int,
        decompose_fn,  # Callable[[Any], Tuple[float, float, float]]
        denoise_step_fn,  # Callable[[Any, int], Any]
        similarity_fn = None,  # Optional[Callable[[Any], float]]
        initial_noise = None  # Optional[Any]
    ) -> List[DiffusionStepState]:
        """
        Track full diffusion trajectory with YRSN decomposition.

        Parameters
        ----------
        total_steps : int
            Total diffusion timesteps T
        decompose_fn : callable
            Function mapping latent → (r, s, n) scores
        denoise_step_fn : callable
            Function performing one denoise step: (latent, t) → latent
        similarity_fn : callable, optional
            Function computing training set similarity
        initial_noise : any, optional
            Starting noise (must be provided externally)

        Returns
        -------
        list of DiffusionStepState
            State at each denoising step
        """
        trajectory = []
        x_t = initial_noise

        for t in reversed(range(total_steps)):
            # Denoise one step
            x_t = denoise_step_fn(x_t, t)

            # Decompose current state
            r, s, n = decompose_fn(x_t)
            total = r + s + n
            alpha = r / total if total > 0 else 0.0

            # Check for memorization
            is_memorized = False
            if similarity_fn is not None:
                similarity = similarity_fn(x_t)
                is_memorized = similarity > self.memorization_threshold

            # Detect phase transition
            phase_transition = None
            if len(trajectory) > 0:
                prev_alpha = trajectory[-1].quality_alpha
                if alpha > self.phase_transition_alpha and prev_alpha < self.phase_transition_alpha:
                    phase_transition = "creativity_to_refinement"

            trajectory.append(DiffusionStepState(
                step=t,
                t_frac=t / total_steps,
                r_score=r,
                s_score=s,
                n_score=n,
                quality_alpha=alpha,
                is_memorized=is_memorized,
                phase_transition=phase_transition
            ))

        return trajectory

    def find_memorization_boundary(
        self,
        trajectory: List[DiffusionStepState]
    ) -> Optional[int]:
        """
        Find the step where generation crosses into memorization.

        The memorization boundary is where dS/dt > dR/dt,
        i.e., learned patterns start dominating novel signal.

        Parameters
        ----------
        trajectory : list of DiffusionStepState
            Tracked trajectory from track_trajectory()

        Returns
        -------
        int or None
            Step number of memorization boundary, or None if not found
        """
        for i in range(1, len(trajectory)):
            prev = trajectory[i-1]
            curr = trajectory[i]

            ds_dt = curr.s_score - prev.s_score
            dr_dt = curr.r_score - prev.r_score

            if ds_dt > dr_dt and curr.s_score > curr.r_score:
                return curr.step

        return None

    def classify_generation(
        self,
        final_r: float,
        final_s: float,
        training_similarity: float
    ) -> str:
        """
        Classify whether output is generated vs memorized.

        Classification:
        - MEMORIZED: High S + high similarity = retrieval from training data
        - GENERATED: High R + low similarity = genuine novel generation
        - RECOMBINED: High R + moderate similarity = creative recombination
        - MIXED: Ambiguous state

        Parameters
        ----------
        final_r : float
            Final R-score
        final_s : float
            Final S-score
        training_similarity : float
            Similarity to nearest training example

        Returns
        -------
        str
            One of: "MEMORIZED", "GENERATED", "RECOMBINED", "MIXED"
        """
        # High S + high similarity = memorization
        if final_s > 0.5 and training_similarity > 0.8:
            return "MEMORIZED"

        # High R + low similarity = genuine generation
        if final_r > 0.5 and training_similarity < 0.5:
            return "GENERATED"

        # High R + moderate similarity = creative recombination
        if final_r > 0.4 and 0.3 < training_similarity < 0.7:
            return "RECOMBINED"

        return "MIXED"

    def get_trajectory_summary(
        self,
        trajectory: List[DiffusionStepState]
    ) -> Dict[str, Any]:
        """
        Get summary statistics from a trajectory.

        Returns
        -------
        dict with keys:
            - final_alpha: Quality at end
            - max_alpha: Peak quality
            - phase_transitions: List of transitions
            - memorization_detected: Whether any step was memorized
            - memorization_boundary: Step where memorization began
        """
        if not trajectory:
            return {}

        final = trajectory[-1]
        return {
            'final_alpha': final.quality_alpha,
            'final_r': final.r_score,
            'final_s': final.s_score,
            'final_n': final.n_score,
            'max_alpha': max(s.quality_alpha for s in trajectory),
            'phase_transitions': [
                s.phase_transition for s in trajectory if s.phase_transition
            ],
            'memorization_detected': any(s.is_memorized for s in trajectory),
            'memorization_boundary': self.find_memorization_boundary(trajectory),
        }


class YRSNGuidedDiffusion:
    """
    Quality-guided diffusion using YRSN decomposition.

    NeurIPS 2025 Theme 4: Diffusion for Quality Understanding

    Uses R-score to guide denoising toward higher quality outputs
    by applying gradient guidance when quality is below target.

    Quality Schedule:
    - Early stages: Accept lower quality (still noisy)
    - Middle stages: Target moderate quality
    - Late stages: Push for high quality

    Key equation:
        α(t) = R(t) / (R(t) + S(t) + N(t))

    Guidance is applied when α < α_target for the current phase.

    Usage:
        guided = YRSNGuidedDiffusion(guidance_scale=0.1)

        # Custom quality schedule
        guided = YRSNGuidedDiffusion(
            quality_schedule={
                (0.7, 1.0): 0.3,  # Early: low target
                (0.3, 0.7): 0.5,  # Middle: moderate
                (0.0, 0.3): 0.7,  # Late: high target
            }
        )

        # Guided denoising
        x_out = guided.guided_denoise_step(
            x_t, t, total_steps,
            denoise_fn, decompose_fn, gradient_fn
        )
    """

    def __init__(
        self,
        guidance_scale: float = 0.1,
        quality_schedule: Optional[Dict[Tuple[float, float], float]] = None
    ):
        """
        Initialize quality-guided diffusion.

        Parameters
        ----------
        guidance_scale : float
            Scale factor for quality gradient guidance
        quality_schedule : dict, optional
            Mapping of (t_frac_low, t_frac_high) → quality_target
            Default: lower targets early, higher late
        """
        self.guidance_scale = guidance_scale

        # Default quality schedule: lower targets early, higher late
        self.quality_schedule = quality_schedule or {
            (0.7, 1.0): 0.3,  # Early: accept lower quality (still noisy)
            (0.3, 0.7): 0.5,  # Middle: target moderate quality
            (0.0, 0.3): 0.7,  # Late: push for high quality
        }

    def get_quality_target(self, t_frac: float) -> float:
        """
        Get quality target for current diffusion phase.

        Parameters
        ----------
        t_frac : float
            Normalized timestep (0=clean, 1=noise)

        Returns
        -------
        float
            Target quality α for this phase
        """
        for (low, high), target in self.quality_schedule.items():
            if low <= t_frac < high:
                return target
        return 0.5  # Default

    def guided_denoise_step(
        self,
        x_t,  # Any - current latent state
        t: int,
        total_steps: int,
        denoise_fn,  # Callable - base denoising function
        decompose_fn,  # Callable - YRSN decomposition function
        gradient_fn = None  # Optional[Callable] - function to compute quality gradient
    ):
        """
        Perform quality-guided denoising step.

        Parameters
        ----------
        x_t : any
            Current latent state
        t : int
            Current timestep
        total_steps : int
            Total diffusion steps
        denoise_fn : callable
            Base denoising function: (latent, t) → latent
        decompose_fn : callable
            YRSN decomposition: latent → (r, s, n)
        gradient_fn : callable, optional
            Function to compute quality gradient: (loss, latent) → gradient

        Returns
        -------
        any
            Guided denoised latent
        """
        # Standard denoising
        x_pred = denoise_fn(x_t, t)

        # Decompose prediction
        r, s, n = decompose_fn(x_pred)
        total = r + s + n
        alpha = r / total if total > 0 else 0.0

        # Get quality target for this phase
        t_frac = t / total_steps
        quality_target = self.get_quality_target(t_frac)

        # Guide toward higher quality if below target
        if alpha < quality_target and gradient_fn is not None:
            quality_loss = (alpha - quality_target) ** 2
            quality_grad = gradient_fn(quality_loss, x_pred)
            x_guided = x_pred + self.guidance_scale * quality_grad
            return x_guided

        return x_pred

    def compute_guidance_strength(
        self,
        current_alpha: float,
        target_alpha: float
    ) -> float:
        """
        Compute guidance strength based on quality gap.

        Parameters
        ----------
        current_alpha : float
            Current quality
        target_alpha : float
            Target quality

        Returns
        -------
        float
            Guidance strength (0 if at or above target)
        """
        if current_alpha >= target_alpha:
            return 0.0

        gap = target_alpha - current_alpha
        return self.guidance_scale * gap


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'ClassMetrics',
    'ValidationResult',
    'RSNValidator',
    'GroundTruthDataset',
    'quick_validate',
    'validate_separation',
    # Retrieval sink metrics
    'RetrievalSinkMetrics',
    'measure_retrieval_sink',
    'diagnose_attention_quality',
    # Attention sink detection (NeurIPS 2025 Theme 1)
    'AttentionSinkResult',
    'AttentionSinkDetector',
    # Diffusion quality tracking (NeurIPS 2025 Theme 4)
    'DiffusionStepState',
    'DiffusionQualityTracker',
    'YRSNGuidedDiffusion',
]
