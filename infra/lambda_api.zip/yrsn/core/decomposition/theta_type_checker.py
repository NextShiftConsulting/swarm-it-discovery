"""
Theta Type Checking and Validation Utilities

This module provides comprehensive type checking, validation, and conversion utilities
for the four types of theta in the YRSN codebase:

1. `theta` - Model parameter (scalar, learned rotation angle)
2. `sample_theta` - Per-sample 2D projection angle (batch tensor)
3. `simplex_theta` - Per-sample RSN simplex angle (batch array)
4. `bloch_theta` - Quantum Bloch sphere polar angle (scalar or batch array)

Usage:
    from yrsn.core.decomposition.theta_type_checker import (
        ThetaTypeChecker,
        validate_theta,
        convert_theta,
        check_theta_compatibility,
    )

    # Validate a theta value
    checker = ThetaTypeChecker()
    result = checker.validate_theta(theta_value, theta_type='sample_theta', batch_size=10)
    if not result.is_valid:
        print(f"Errors: {result.errors}")

    # Convert between formats
    theta_numpy = convert_theta(theta_tensor, from_type='sample_theta', to_type='simplex_theta')

    # Check compatibility before operations
    check_theta_compatibility(theta1, theta2, operation='correlation')
"""

import math
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Tuple, Union

import numpy as np
import torch


class ThetaType(str, Enum):
    """Enumeration of the four theta types."""
    MODEL = "theta"  # Model parameter (scalar)
    SAMPLE = "sample_theta"  # Per-sample 2D projection angle
    SIMPLEX = "simplex_theta"  # Per-sample RSN simplex angle
    BLOCH = "bloch_theta"  # Quantum Bloch sphere polar angle


@dataclass
class ThetaValidationResult:
    """Result of theta validation."""
    is_valid: bool
    theta_type: ThetaType
    detected_type: Optional[ThetaType] = None
    shape: Optional[Tuple[int, ...]] = None
    dtype: Optional[str] = None
    value_range: Optional[Tuple[float, float]] = None
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class ThetaTypeChecker:
    """
    Comprehensive type checker for theta values.

    Validates datatypes, shapes, ranges, and units for all four theta types.
    Provides conversion utilities and compatibility checks.
    """

    # Expected ranges (in degrees, except bloch_theta which is in radians)
    EXPECTED_RANGES = {
        ThetaType.MODEL: (-180.0, 180.0),  # degrees
        ThetaType.SAMPLE: (-180.0, 180.0),  # degrees
        ThetaType.SIMPLEX: (-180.0, 180.0),  # degrees
        ThetaType.BLOCH: (0.0, math.pi),  # radians
    }

    # Expected shapes
    EXPECTED_SHAPES = {
        ThetaType.MODEL: (),  # Scalar (0-dim)
        ThetaType.SAMPLE: None,  # [batch_size] - dynamic
        ThetaType.SIMPLEX: None,  # [batch_size] - dynamic
        ThetaType.BLOCH: None,  # Scalar or [batch_size] - dynamic
    }

    def __init__(self, strict: bool = True, warn_on_issues: bool = True):
        """
        Initialize type checker.

        Args:
            strict: If True, raise errors on validation failures
            warn_on_issues: If True, emit warnings for non-critical issues
        """
        self.strict = strict
        self.warn_on_issues = warn_on_issues

    def validate_theta(
        self,
        theta: Any,
        theta_type: Optional[ThetaType] = None,
        batch_size: Optional[int] = None,
        expected_range: Optional[Tuple[float, float]] = None,
    ) -> ThetaValidationResult:
        """
        Validate a theta value against expected type and constraints.

        Args:
            theta: The theta value to validate
            theta_type: Expected type (if None, will auto-detect)
            batch_size: Expected batch size (for batch types)
            expected_range: Override default range for this type

        Returns:
            ThetaValidationResult with validation details
        """
        result = ThetaValidationResult(
            is_valid=True,
            theta_type=theta_type or ThetaType.MODEL,
        )

        # Auto-detect type if not specified
        if theta_type is None:
            result.detected_type = self._detect_theta_type(theta)
            result.theta_type = result.detected_type
            if self.warn_on_issues:
                warnings.warn(
                    f"Auto-detected theta type: {result.detected_type.value}. "
                    f"Consider explicitly specifying theta_type for better validation."
                )

        # Check basic type
        type_check = self._check_basic_type(theta, result.theta_type)
        if not type_check[0]:
            result.is_valid = False
            result.errors.append(type_check[1])
            if self.strict:
                raise TypeError(f"Theta type validation failed: {type_check[1]}")
            return result

        # Extract shape and dtype
        result.shape = self._get_shape(theta)
        result.dtype = self._get_dtype(theta)

        # Validate shape
        shape_check = self._check_shape(theta, result.theta_type, batch_size)
        if not shape_check[0]:
            result.is_valid = False
            result.errors.append(shape_check[1])
            if self.strict:
                raise ValueError(f"Theta shape validation failed: {shape_check[1]}")

        # Validate range
        range_to_check = expected_range or self.EXPECTED_RANGES.get(result.theta_type)
        if range_to_check:
            range_check = self._check_range(theta, range_to_check, result.theta_type)
            if not range_check[0]:
                result.is_valid = False
                result.errors.append(range_check[1])
                if self.strict:
                    raise ValueError(f"Theta range validation failed: {range_check[1]}")
            result.value_range = range_check[2]

        # Check units (warn if bloch_theta might be in wrong units)
        if result.theta_type == ThetaType.BLOCH:
            units_check = self._check_bloch_units(theta)
            if not units_check[0] and self.warn_on_issues:
                result.warnings.append(units_check[1])
                warnings.warn(units_check[1])

        return result

    def _detect_theta_type(self, theta: Any) -> ThetaType:
        """Auto-detect theta type from value characteristics."""
        # Check if it's a PyTorch Parameter (model theta)
        if isinstance(theta, torch.nn.Parameter):
            return ThetaType.MODEL

        # Check if it's a scalar
        if isinstance(theta, (int, float, np.number)):
            # Could be model theta or bloch_theta
            # Check range: bloch_theta is [0, π], model is [-180, 180]
            if isinstance(theta, (int, float)):
                val = float(theta)
            else:
                val = float(theta.item())

            if 0.0 <= val <= math.pi:
                return ThetaType.BLOCH
            else:
                return ThetaType.MODEL

        # Check if it's a tensor/array
        if isinstance(theta, torch.Tensor):
            if theta.dim() == 0:  # Scalar tensor
                val = theta.item()
                if 0.0 <= val <= math.pi:
                    return ThetaType.BLOCH
                else:
                    return ThetaType.MODEL
            elif theta.dim() == 1:  # 1D tensor
                # Check if values are in bloch range
                values = theta.detach().cpu().numpy()
                if np.all((values >= 0) & (values <= math.pi)):
                    return ThetaType.BLOCH
                else:
                    return ThetaType.SAMPLE
            else:
                return ThetaType.SAMPLE  # Default for batch tensors

        if isinstance(theta, np.ndarray):
            if theta.ndim == 0:  # Scalar array
                val = float(theta.item())
                if 0.0 <= val <= math.pi:
                    return ThetaType.BLOCH
                else:
                    return ThetaType.MODEL
            elif theta.ndim == 1:  # 1D array
                if np.all((theta >= 0) & (theta <= math.pi)):
                    return ThetaType.BLOCH
                else:
                    return ThetaType.SIMPLEX
            else:
                return ThetaType.SIMPLEX  # Default for batch arrays

        # Default fallback
        return ThetaType.MODEL

    def _check_basic_type(self, theta: Any, theta_type: ThetaType) -> Tuple[bool, str]:
        """Check if theta has the correct basic type."""
        if theta_type == ThetaType.MODEL:
            if isinstance(theta, torch.nn.Parameter):
                return True, ""
            if isinstance(theta, torch.Tensor) and theta.dim() == 0:
                return True, ""
            if isinstance(theta, (int, float, np.number)):
                return True, ""
            return False, (
                f"Model theta must be nn.Parameter, scalar tensor, or scalar number. "
                f"Got: {type(theta)}"
            )

        elif theta_type == ThetaType.SAMPLE:
            if isinstance(theta, torch.Tensor) and theta.dim() == 1:
                return True, ""
            return False, (
                f"Sample theta must be 1D torch.Tensor [batch_size]. "
                f"Got: {type(theta)} with shape {getattr(theta, 'shape', 'unknown')}"
            )

        elif theta_type == ThetaType.SIMPLEX:
            if isinstance(theta, np.ndarray) and theta.ndim == 1:
                return True, ""
            return False, (
                f"Simplex theta must be 1D numpy.ndarray [batch_size]. "
                f"Got: {type(theta)} with shape {getattr(theta, 'shape', 'unknown')}"
            )

        elif theta_type == ThetaType.BLOCH:
            # Bloch can be scalar or array
            if isinstance(theta, (int, float, np.number)):
                return True, ""
            if isinstance(theta, torch.Tensor) and theta.dim() in (0, 1):
                return True, ""
            if isinstance(theta, np.ndarray) and theta.ndim in (0, 1):
                return True, ""
            return False, (
                f"Bloch theta must be scalar or 1D array/tensor. "
                f"Got: {type(theta)} with shape {getattr(theta, 'shape', 'unknown')}"
            )

        return False, f"Unknown theta type: {theta_type}"

    def _check_shape(
        self, theta: Any, theta_type: ThetaType, batch_size: Optional[int]
    ) -> Tuple[bool, str]:
        """Check if theta has the correct shape."""
        shape = self._get_shape(theta)

        if theta_type == ThetaType.MODEL:
            if shape == () or shape == (1,):
                return True, ""
            return False, f"Model theta must be scalar. Got shape: {shape}"

        elif theta_type in (ThetaType.SAMPLE, ThetaType.SIMPLEX):
            if len(shape) != 1:
                return False, (
                    f"{theta_type.value} must be 1D [batch_size]. Got shape: {shape}"
                )
            if batch_size is not None and shape[0] != batch_size:
                return False, (
                    f"{theta_type.value} batch size mismatch: "
                    f"expected {batch_size}, got {shape[0]}"
                )
            return True, ""

        elif theta_type == ThetaType.BLOCH:
            # Bloch can be scalar or 1D
            if shape == () or (len(shape) == 1 and (batch_size is None or shape[0] == batch_size)):
                return True, ""
            return False, (
                f"Bloch theta must be scalar or 1D [batch_size]. Got shape: {shape}"
            )

        return True, ""

    def _check_range(
        self, theta: Any, expected_range: Tuple[float, float], theta_type: ThetaType
    ) -> Tuple[bool, str, Optional[Tuple[float, float]]]:
        """Check if theta values are within expected range."""
        # Extract values
        if isinstance(theta, torch.Tensor):
            values = theta.detach().cpu().numpy()
        elif isinstance(theta, np.ndarray):
            values = theta
        elif isinstance(theta, torch.nn.Parameter):
            values = np.array([theta.item()])
        else:
            values = np.array([float(theta)])

        # Flatten for range check
        values_flat = values.flatten()
        min_val, max_val = float(np.min(values_flat)), float(np.max(values_flat))
        actual_range = (min_val, max_val)

        range_min, range_max = expected_range
        if np.any(values_flat < range_min) or np.any(values_flat > range_max):
            # Check if it's a units issue (degrees vs radians)
            if theta_type == ThetaType.BLOCH:
                # Bloch should be in radians [0, π]
                # If values are in degrees, they'd be [0, 180]
                if np.all((values_flat >= 0) & (values_flat <= 180)):
                    return False, (
                        f"Bloch theta appears to be in degrees (range: {actual_range}). "
                        f"Expected radians [0, π]. Convert: theta_rad = theta_deg * π / 180"
                    ), actual_range
            else:
                # Other thetas should be in degrees
                # If values are in radians, they'd be [-π, π]
                if np.all((values_flat >= -math.pi) & (values_flat <= math.pi)):
                    return False, (
                        f"{theta_type.value} appears to be in radians (range: {actual_range}). "
                        f"Expected degrees [-180, 180]. Convert: theta_deg = theta_rad * 180 / π"
                    ), actual_range

            return False, (
                f"{theta_type.value} values out of range. "
                f"Expected: {expected_range}, got: {actual_range}"
            ), actual_range

        return True, "", actual_range

    def _check_bloch_units(self, theta: Any) -> Tuple[bool, str]:
        """Check if bloch_theta is likely in correct units (radians)."""
        if isinstance(theta, torch.Tensor):
            values = theta.detach().cpu().numpy()
        elif isinstance(theta, np.ndarray):
            values = theta
        else:
            values = np.array([float(theta)])

        values_flat = values.flatten()
        max_val = float(np.max(np.abs(values_flat)))

        # Bloch theta should be [0, π] ≈ [0, 3.14]
        # If max is > 10, likely in degrees
        if max_val > 10.0:
            return False, (
                f"Bloch theta values seem large (max: {max_val:.2f}). "
                f"Expected radians [0, π] ≈ [0, 3.14]. "
                f"If in degrees, convert: theta_rad = theta_deg * π / 180"
            )

        return True, ""

    def _get_shape(self, theta: Any) -> Tuple[int, ...]:
        """Extract shape from theta value."""
        if isinstance(theta, (torch.Tensor, np.ndarray)):
            return tuple(theta.shape)
        if isinstance(theta, torch.nn.Parameter):
            return tuple(theta.shape)
        return ()  # Scalar

    def _get_dtype(self, theta: Any) -> str:
        """Extract dtype string from theta value."""
        if isinstance(theta, torch.Tensor):
            return str(theta.dtype)
        if isinstance(theta, np.ndarray):
            return str(theta.dtype)
        if isinstance(theta, torch.nn.Parameter):
            return str(theta.dtype)
        return type(theta).__name__


def convert_theta(
    theta: Any,
    from_type: Optional[ThetaType] = None,
    to_type: ThetaType = ThetaType.SIMPLEX,
    batch_size: Optional[int] = None,
) -> Union[float, np.ndarray, torch.Tensor]:
    """
    Convert theta between different types and formats.

    Args:
        theta: The theta value to convert
        from_type: Source type (auto-detected if None)
        to_type: Target type
        batch_size: Expected batch size (for validation)

    Returns:
        Converted theta value in target format

    Raises:
        ValueError: If conversion is not possible or validation fails
        TypeError: If types are incompatible
    """
    checker = ThetaTypeChecker(strict=True)

    # Auto-detect source type if not provided
    if from_type is None:
        from_type = checker._detect_theta_type(theta)

    # Validate source
    source_result = checker.validate_theta(theta, from_type, batch_size)
    if not source_result.is_valid:
        raise ValueError(
            f"Source theta validation failed: {', '.join(source_result.errors)}"
        )

    # Handle same-type conversion (just format conversion)
    if from_type == to_type:
        return _convert_format(theta, to_type)

    # Handle cross-type conversions
    if from_type == ThetaType.MODEL and to_type == ThetaType.SAMPLE:
        raise ValueError(
            "Cannot convert model theta (scalar) to sample_theta (batch). "
            "Model theta is a single learned parameter, not per-sample values."
        )

    if from_type == ThetaType.SAMPLE and to_type == ThetaType.SIMPLEX:
        # Both are batch types, but computed at different stages
        # This conversion requires RSN values - not possible from theta alone
        raise ValueError(
            "Cannot convert sample_theta to simplex_theta without RSN values. "
            "Use compute_simplex_theta(rsn) function instead."
        )

    if from_type == ThetaType.SIMPLEX and to_type == ThetaType.SAMPLE:
        raise ValueError(
            "Cannot convert simplex_theta to sample_theta. "
            "These represent different geometric spaces (simplex vs 2D projection)."
        )

    # Convert to numpy/torch formats
    if to_type == ThetaType.SAMPLE:
        # Convert to torch.Tensor
        if isinstance(theta, torch.Tensor):
            return theta
        if isinstance(theta, np.ndarray):
            return torch.from_numpy(theta)
        # Scalar to batch (not recommended, but handle it)
        if batch_size:
            return torch.full((batch_size,), float(theta), dtype=torch.float32)
        raise ValueError("Cannot convert scalar to sample_theta without batch_size")

    if to_type == ThetaType.SIMPLEX:
        # Convert to numpy.ndarray
        if isinstance(theta, np.ndarray):
            return theta
        if isinstance(theta, torch.Tensor):
            return theta.detach().cpu().numpy()
        # Scalar to batch
        if batch_size:
            return np.full((batch_size,), float(theta), dtype=np.float32)
        raise ValueError("Cannot convert scalar to simplex_theta without batch_size")

    if to_type == ThetaType.BLOCH:
        # Convert to appropriate format (scalar or array)
        if isinstance(theta, (int, float)):
            # Convert degrees to radians if needed
            if from_type != ThetaType.BLOCH:
                # Assume degrees, convert to radians
                theta_rad = math.radians(float(theta))
            else:
                theta_rad = float(theta)
            return theta_rad

        # Array case
        if isinstance(theta, torch.Tensor):
            values = theta.detach().cpu().numpy()
        elif isinstance(theta, np.ndarray):
            values = theta
        else:
            values = np.array([float(theta)])

        # Convert degrees to radians if needed
        if from_type != ThetaType.BLOCH:
            values = np.deg2rad(values)

        # Return scalar if single value, array otherwise
        if values.size == 1:
            return float(values.item())
        return values

    if to_type == ThetaType.MODEL:
        # Extract scalar value
        if isinstance(theta, torch.Tensor):
            if theta.numel() == 1:
                return theta.item()
            raise ValueError("Cannot convert batch theta to model theta (scalar)")
        if isinstance(theta, np.ndarray):
            if theta.size == 1:
                return float(theta.item())
            raise ValueError("Cannot convert batch theta to model theta (scalar)")
        return float(theta)

    raise ValueError(f"Unsupported conversion: {from_type} -> {to_type}")


def _convert_format(theta: Any, theta_type: ThetaType) -> Any:
    """Convert theta to preferred format for its type."""
    if theta_type == ThetaType.MODEL:
        if isinstance(theta, torch.nn.Parameter):
            return theta
        if isinstance(theta, torch.Tensor):
            return theta
        return float(theta)

    if theta_type == ThetaType.SAMPLE:
        if isinstance(theta, torch.Tensor):
            return theta
        if isinstance(theta, np.ndarray):
            return torch.from_numpy(theta)
        raise TypeError(f"Cannot convert {type(theta)} to sample_theta format")

    if theta_type == ThetaType.SIMPLEX:
        if isinstance(theta, np.ndarray):
            return theta
        if isinstance(theta, torch.Tensor):
            return theta.detach().cpu().numpy()
        raise TypeError(f"Cannot convert {type(theta)} to simplex_theta format")

    if theta_type == ThetaType.BLOCH:
        # Keep as-is, but ensure correct units
        return theta

    return theta


def check_theta_compatibility(
    theta1: Any,
    theta2: Any,
    operation: str = "correlation",
    strict: bool = True,
) -> Tuple[bool, list[str]]:
    """
    Check if two theta values are compatible for an operation.

    Args:
        theta1: First theta value
        theta2: Second theta value
        operation: Operation being performed ('correlation', 'comparison', 'arithmetic')
        strict: If True, return errors; if False, return warnings

    Returns:
        Tuple of (is_compatible, list_of_issues)
    """
    checker = ThetaTypeChecker(strict=False)
    issues = []

    # Validate both thetas
    result1 = checker.validate_theta(theta1)
    result2 = checker.validate_theta(theta2)

    if not result1.is_valid:
        issues.append(f"Theta1 validation failed: {', '.join(result1.errors)}")
    if not result2.is_valid:
        issues.append(f"Theta2 validation failed: {', '.join(result2.errors)}")

    if issues:
        return False, issues

    # Check shape compatibility
    shape1 = result1.shape
    shape2 = result2.shape

    if operation in ("correlation", "comparison", "arithmetic"):
        # Shapes must match or be broadcastable
        if shape1 != shape2:
            # Check if broadcastable
            if len(shape1) == 0 or len(shape2) == 0:
                # Scalar can broadcast
                pass
            elif len(shape1) == 1 and len(shape2) == 1:
                if shape1[0] != shape2[0]:
                    issues.append(
                        f"Shape mismatch: {shape1} vs {shape2}. "
                        f"Cannot perform {operation} on incompatible shapes."
                    )
            else:
                issues.append(
                    f"Shape mismatch: {shape1} vs {shape2}. "
                    f"Cannot perform {operation} on incompatible shapes."
                )

    # Check type compatibility
    if result1.theta_type != result2.theta_type:
        if operation == "comparison":
            issues.append(
                f"Type mismatch: {result1.theta_type.value} vs {result2.theta_type.value}. "
                f"Comparing different theta types may not be meaningful."
            )
        elif operation == "correlation":
            issues.append(
                f"Type mismatch: {result1.theta_type.value} vs {result2.theta_type.value}. "
                f"Correlating different theta types may not be meaningful."
            )

    # Check units compatibility (bloch vs others)
    if (result1.theta_type == ThetaType.BLOCH) != (result2.theta_type == ThetaType.BLOCH):
        issues.append(
            f"Units mismatch: {result1.theta_type.value} (degrees/radians) vs "
            f"{result2.theta_type.value} (radians/degrees). "
            f"Convert to same units before {operation}."
        )

    is_compatible = len(issues) == 0
    if not is_compatible and strict:
        raise ValueError(f"Theta compatibility check failed:\n" + "\n".join(issues))

    return is_compatible, issues


# Convenience functions
def validate_theta(
    theta: Any,
    theta_type: Optional[ThetaType] = None,
    batch_size: Optional[int] = None,
    strict: bool = True,
) -> ThetaValidationResult:
    """Convenience function for theta validation."""
    checker = ThetaTypeChecker(strict=strict)
    return checker.validate_theta(theta, theta_type, batch_size)


def get_theta_info(theta: Any) -> dict[str, Any]:
    """
    Get comprehensive information about a theta value.

    Returns:
        Dictionary with type, shape, dtype, range, and validation status
    """
    checker = ThetaTypeChecker(strict=False)
    result = checker.validate_theta(theta)

    return {
        "type": result.theta_type.value,
        "detected_type": result.detected_type.value if result.detected_type else None,
        "shape": result.shape,
        "dtype": result.dtype,
        "value_range": result.value_range,
        "is_valid": result.is_valid,
        "errors": result.errors,
        "warnings": result.warnings,
    }


# Export all
__all__ = [
    "ThetaType",
    "ThetaTypeChecker",
    "ThetaValidationResult",
    "validate_theta",
    "convert_theta",
    "check_theta_compatibility",
    "get_theta_info",
]
