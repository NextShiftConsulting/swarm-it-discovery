"""
Label Reader - Unified interface for reading labels from various sources.

YRSN uses multiple label types and formats:
- R/S/N labels (0, 1, 2) - Core decomposition
- Semantic labels - Human-readable descriptions
- Strategy labels - CTC reasoning strategies
- True labels - Ground truth for supervised learning
- Pseudo-labels - Semi-supervised learning

This module provides a unified interface for reading, validating, and converting
between different label formats and sources.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union, Any
from enum import Enum
from pathlib import Path
import json
import csv

try:
    import torch
    import numpy as np
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None
    np = None

from yrsn.core.signal_spec import YRSNLabels


class LabelFormat(str, Enum):
    """Supported label formats."""
    GROUND_TRUTH = "ground_truth"  # R/S/N integer labels (0, 1, 2)
    SEMANTIC = "semantic"  # Semantic labels with descriptions
    STRATEGY = "strategy"  # CTC strategy labels
    TRUE_LABEL = "true_label"  # String labels for classification
    PSEUDO = "pseudo"  # Pseudo-labels from model predictions


@dataclass
class LabelData:
    """Container for label data with metadata."""
    labels: Union[torch.Tensor, np.ndarray, List[int], List[str]]
    format: LabelFormat
    metadata: Dict[str, Any] = field(default_factory=dict)
    num_classes: Optional[int] = None
    class_names: Optional[List[str]] = None
    
    def to_tensor(self, device: Optional[Any] = None) -> torch.Tensor:
        """Convert labels to PyTorch tensor."""
        if not TORCH_AVAILABLE:
            raise ImportError("PyTorch required for tensor conversion")
        
        if isinstance(self.labels, torch.Tensor):
            result = self.labels
        elif isinstance(self.labels, np.ndarray):
            result = torch.from_numpy(self.labels)
        elif isinstance(self.labels, list):
            if isinstance(self.labels[0], str):
                # String labels - need to map to integers
                if self.class_names is None:
                    self.class_names = sorted(set(self.labels))
                label_map = {name: idx for idx, name in enumerate(self.class_names)}
                int_labels = [label_map[label] for label in self.labels]
                result = torch.tensor(int_labels, dtype=torch.long)
            else:
                result = torch.tensor(self.labels, dtype=torch.long)
        else:
            raise ValueError(f"Cannot convert {type(self.labels)} to tensor")
        
        if device is not None:
            result = result.to(device)
        return result
    
    def to_numpy(self) -> np.ndarray:
        """Convert labels to NumPy array."""
        if isinstance(self.labels, np.ndarray):
            return self.labels
        elif isinstance(self.labels, torch.Tensor):
            return self.labels.cpu().numpy()
        elif isinstance(self.labels, list):
            return np.array(self.labels)
        else:
            raise ValueError(f"Cannot convert {type(self.labels)} to numpy")
    
    def validate(self) -> Tuple[bool, Optional[str]]:
        """Validate label data."""
        if len(self.labels) == 0:
            return False, "Empty labels"
        
        # Check format consistency
        if self.format == LabelFormat.GROUND_TRUTH:
            labels_array = self.to_numpy()
            if labels_array.dtype.kind not in ['i', 'u']:  # Integer types
                return False, "Ground truth labels must be integers"
            unique = np.unique(labels_array)
            if len(unique) > 3 or not all(0 <= u <= 2 for u in unique):
                return False, "Ground truth labels must be 0, 1, or 2 (R, S, N)"
        
        return True, None


@dataclass
class ValidationResult:
    """Result of label validation."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    num_labels: int = 0
    num_classes: Optional[int] = None
    class_distribution: Optional[Dict[int, int]] = None


class LabelReader:
    """
    Unified interface for reading labels from various sources.
    
    Supports:
    - JSON files (ground truth format)
    - CSV files
    - PyTorch tensors
    - NumPy arrays
    - TypedDict (YRSNLabels)
    - Direct annotations
    
    Examples:
        >>> reader = LabelReader()
        >>> # Read from JSON
        >>> labels = reader.read_from_json("labels.json")
        >>> # Read from CSV
        >>> labels = reader.read_from_csv("labels.csv", label_column="label")
        >>> # Validate
        >>> result = reader.validate_labels(labels)
    """
    
    def __init__(self, default_format: LabelFormat = LabelFormat.GROUND_TRUTH):
        """
        Initialize label reader.
        
        Args:
            default_format: Default format to assume when format is ambiguous
        """
        self.default_format = default_format
    
    def read_from_json(
        self,
        path: Union[str, Path],
        format: Optional[LabelFormat] = None,
        label_key: str = "label",
    ) -> LabelData:
        """
        Read labels from JSON file.
        
        Expected formats:
        1. Ground truth format:
           {"samples": [{"embedding": [...], "label": 0, ...}, ...]}
        2. Simple format:
           [{"label": 0, ...}, ...]
        3. Direct labels:
           {"labels": [0, 1, 2, ...]}
        
        Args:
            path: Path to JSON file
            format: Label format (auto-detected if None)
            label_key: Key for label in each sample
        
        Returns:
            LabelData with labels and metadata
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Label file not found: {path}")
        
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Extract labels
        if "samples" in data:
            # Ground truth format
            samples = data["samples"]
            labels = [s[label_key] for s in samples if label_key in s]
            metadata = {
                "source": str(path),
                "num_samples": len(samples),
                "sample_metadata": [{k: v for k, v in s.items() if k != label_key} for s in samples],
            }
            format = format or LabelFormat.GROUND_TRUTH
        elif isinstance(data, list):
            # List of samples
            labels = [s[label_key] for s in data if label_key in s]
            metadata = {"source": str(path), "num_samples": len(data)}
            format = format or self.default_format
        elif "labels" in data:
            # Direct labels array
            labels = data["labels"]
            metadata = {"source": str(path), **{k: v for k, v in data.items() if k != "labels"}}
            format = format or self.default_format
        else:
            raise ValueError(f"Unknown JSON format in {path}")
        
        # Determine num_classes and class_names
        num_classes = None
        class_names = None
        
        if isinstance(labels[0], int):
            unique_labels = sorted(set(labels))
            num_classes = len(unique_labels)
        elif isinstance(labels[0], str):
            class_names = sorted(set(labels))
            num_classes = len(class_names)
        
        return LabelData(
            labels=labels,
            format=format or self.default_format,
            metadata=metadata,
            num_classes=num_classes,
            class_names=class_names,
        )
    
    def read_from_csv(
        self,
        path: Union[str, Path],
        label_column: str = "label",
        format: Optional[LabelFormat] = None,
    ) -> LabelData:
        """
        Read labels from CSV file.
        
        Args:
            path: Path to CSV file
            label_column: Name of column containing labels
            format: Label format (auto-detected if None)
        
        Returns:
            LabelData with labels and metadata
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"CSV file not found: {path}")
        
        labels = []
        metadata_rows = []
        
        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            if label_column not in reader.fieldnames:
                raise ValueError(f"Label column '{label_column}' not found in CSV")
            
            for row in reader:
                label_val = row[label_column]
                # Try to convert to int if possible
                try:
                    label_val = int(label_val)
                except ValueError:
                    pass  # Keep as string
                labels.append(label_val)
                metadata_rows.append({k: v for k, v in row.items() if k != label_column})
        
        # Determine num_classes and class_names
        num_classes = None
        class_names = None
        
        if isinstance(labels[0], int):
            unique_labels = sorted(set(labels))
            num_classes = len(unique_labels)
        elif isinstance(labels[0], str):
            class_names = sorted(set(labels))
            num_classes = len(class_names)
        
        return LabelData(
            labels=labels,
            format=format or self.default_format,
            metadata={"source": str(path), "num_samples": len(labels), "rows": metadata_rows},
            num_classes=num_classes,
            class_names=class_names,
        )
    
    def read_from_tensors(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        format: Optional[LabelFormat] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> LabelData:
        """
        Read labels from PyTorch tensor, NumPy array, or list.
        
        Args:
            labels: Labels as tensor, array, or list
            format: Label format (defaults to GROUND_TRUTH)
            metadata: Optional metadata
        
        Returns:
            LabelData with labels
        """
        if isinstance(labels, list):
            # Determine if integers or strings
            if labels and isinstance(labels[0], int):
                num_classes = len(set(labels))
                class_names = None
            elif labels and isinstance(labels[0], str):
                class_names = sorted(set(labels))
                num_classes = len(class_names)
            else:
                num_classes = None
                class_names = None
        else:
            # Tensor or array
            if TORCH_AVAILABLE and isinstance(labels, torch.Tensor):
                unique = torch.unique(labels)
                num_classes = len(unique)
            elif isinstance(labels, np.ndarray):
                unique = np.unique(labels)
                num_classes = len(unique)
            else:
                num_classes = None
            class_names = None
        
        return LabelData(
            labels=labels,
            format=format or self.default_format,
            metadata=metadata or {},
            num_classes=num_classes,
            class_names=class_names,
        )
    
    def read_from_annotations(
        self,
        annotations: Dict[str, Any],
        format: Optional[LabelFormat] = None,
    ) -> LabelData:
        """
        Read labels from annotation dictionary (YRSNLabels format).
        
        Args:
            annotations: Dictionary with label information
            format: Label format (defaults to TRUE_LABEL)
        
        Returns:
            LabelData with labels
        """
        if "true_label" in annotations:
            labels = [annotations["true_label"]]
            class_names = annotations.get("candidate_labels", [])
        elif "labels" in annotations:
            labels = annotations["labels"]
            class_names = annotations.get("class_names")
        else:
            raise ValueError("Annotations must contain 'true_label' or 'labels'")
        
        num_classes = len(class_names) if class_names else len(set(labels))
        
        return LabelData(
            labels=labels,
            format=format or LabelFormat.TRUE_LABEL,
            metadata=annotations,
            num_classes=num_classes,
            class_names=class_names,
        )
    
    def validate_labels(self, label_data: LabelData) -> ValidationResult:
        """
        Validate label data.
        
        Checks:
        - Non-empty labels
        - Format consistency
        - Valid value ranges
        - Class distribution
        
        Args:
            label_data: LabelData to validate
        
        Returns:
            ValidationResult with validation status
        """
        errors = []
        warnings = []
        
        # Basic checks
        if len(label_data.labels) == 0:
            errors.append("Empty labels")
            return ValidationResult(
                is_valid=False,
                errors=errors,
                warnings=warnings,
                num_labels=0,
            )
        
        num_labels = len(label_data.labels)
        
        # Convert to numpy for analysis
        try:
            labels_array = label_data.to_numpy()
        except Exception as e:
            errors.append(f"Cannot convert labels to array: {e}")
            return ValidationResult(
                is_valid=False,
                errors=errors,
                warnings=warnings,
                num_labels=num_labels,
            )
        
        # Format-specific validation
        if label_data.format == LabelFormat.GROUND_TRUTH:
            if labels_array.dtype.kind not in ['i', 'u']:  # Integer types
                errors.append("Ground truth labels must be integers")
            else:
                unique = np.unique(labels_array)
                if len(unique) > 3:
                    errors.append(f"Ground truth should have ≤3 classes, found {len(unique)}")
                if not all(0 <= u <= 2 for u in unique):
                    errors.append("Ground truth labels must be 0, 1, or 2 (R, S, N)")
        
        # Class distribution
        unique, counts = np.unique(labels_array, return_counts=True)
        class_distribution = {int(u): int(c) for u, c in zip(unique, counts)}
        num_classes = len(unique)
        
        # Check for class imbalance
        if num_classes > 1:
            max_count = max(counts)
            min_count = min(counts)
            imbalance_ratio = max_count / min_count if min_count > 0 else float('inf')
            if imbalance_ratio > 10:
                warnings.append(f"Severe class imbalance: {imbalance_ratio:.1f}:1")
            elif imbalance_ratio > 5:
                warnings.append(f"Moderate class imbalance: {imbalance_ratio:.1f}:1")
        
        # Check num_classes consistency
        if label_data.num_classes is not None and label_data.num_classes != num_classes:
            warnings.append(
                f"Metadata num_classes ({label_data.num_classes}) doesn't match "
                f"actual ({num_classes})"
            )
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            num_labels=num_labels,
            num_classes=num_classes,
            class_distribution=class_distribution,
        )
    
    def convert_format(
        self,
        label_data: LabelData,
        target_format: LabelFormat,
    ) -> LabelData:
        """
        Convert labels between formats.
        
        Args:
            label_data: Source label data
            target_format: Target format
        
        Returns:
            Converted LabelData
        """
        # For now, most conversions are just metadata changes
        # Actual conversion logic would depend on specific format requirements
        return LabelData(
            labels=label_data.labels,
            format=target_format,
            metadata={**label_data.metadata, "converted_from": label_data.format.value},
            num_classes=label_data.num_classes,
            class_names=label_data.class_names,
        )


__all__ = [
    "LabelReader",
    "LabelData",
    "LabelFormat",
    "ValidationResult",
]

