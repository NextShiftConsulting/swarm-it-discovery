"""
False Label Generator - Generate incorrect labels for robustness testing.

YRSN uses false labels for:
- Testing robustness to label noise
- Adversarial testing (trying to fool the system)
- Stress testing collapse detection
- Testing calibration under label noise

This module provides various methods for generating false/incorrect labels
that can be used to test YRSN's resilience to label corruption.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union, Any
from enum import Enum
import random

try:
    import torch
    import numpy as np
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None
    np = None


class NoiseType(str, Enum):
    """Types of label noise."""
    RANDOM = "random"  # Uniform random flips
    TARGETED = "targeted"  # Flip to specific class
    CLASS_DEPENDENT = "class_dependent"  # Class-specific noise rates
    RSN_SPECIFIC = "rsn_specific"  # R/S/N-specific corruption patterns
    ADVERSARIAL = "adversarial"  # Model-based adversarial flips


@dataclass
class NoiseConfig:
    """Configuration for label noise generation."""
    noise_rate: float = 0.1  # Overall noise rate (0.0 to 1.0)
    noise_type: NoiseType = NoiseType.RANDOM
    target_class: Optional[int] = None  # For targeted noise
    noise_matrix: Optional[np.ndarray] = None  # For class-dependent noise
    preserve_distribution: bool = False  # Try to preserve class distribution
    seed: Optional[int] = None


@dataclass
class CorruptionResult:
    """Result of label corruption."""
    corrupted_labels: Union[torch.Tensor, np.ndarray, List[int]]
    corruption_mask: Union[torch.Tensor, np.ndarray, List[bool]]  # Which labels were flipped
    corruption_rate: float  # Actual corruption rate
    original_distribution: Dict[int, int]  # Original class distribution
    corrupted_distribution: Dict[int, int]  # Corrupted class distribution
    metadata: Dict[str, Any] = field(default_factory=dict)


class FalseLabelGenerator:
    """
    Generate false/incorrect labels for robustness testing.
    
    Supports multiple noise types:
    - Random flips (uniform noise)
    - Targeted flips (adversarial)
    - Class-dependent noise (realistic)
    - R/S/N-specific corruption
    - Model-based adversarial noise
    
    Examples:
        >>> generator = FalseLabelGenerator(seed=42)
        >>> # Random noise
        >>> result = generator.generate_random_flips(labels, noise_rate=0.1)
        >>> # Targeted flips
        >>> result = generator.generate_targeted_flips(labels, target_class=2)
        >>> # R/S/N specific
        >>> result = generator.generate_rsn_specific_corruption(labels, "poisoning")
    """
    
    def __init__(self, seed: Optional[int] = None):
        """
        Initialize false label generator.
        
        Args:
            seed: Random seed for reproducibility
        """
        self.seed = seed
        self._rng = None
        if seed is not None:
            random.seed(seed)
            if np is not None:
                # Use default_rng for better reproducibility
                self._rng = np.random.default_rng(seed)
            if torch is not None:
                torch.manual_seed(seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(seed)
    
    def _to_numpy(self, labels: Union[torch.Tensor, np.ndarray, List[int]]) -> np.ndarray:
        """Convert labels to NumPy array."""
        if isinstance(labels, np.ndarray):
            return labels
        elif isinstance(labels, torch.Tensor):
            return labels.cpu().numpy()
        elif isinstance(labels, list):
            return np.array(labels)
        else:
            raise ValueError(f"Cannot convert {type(labels)} to numpy")
    
    def _get_class_distribution(self, labels: np.ndarray) -> Dict[int, int]:
        """Get class distribution from labels."""
        unique, counts = np.unique(labels, return_counts=True)
        return {int(u): int(c) for u, c in zip(unique, counts)}
    
    def generate_random_flips(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        noise_rate: float = 0.1,
        num_classes: Optional[int] = None,
        preserve_distribution: bool = False,
    ) -> CorruptionResult:
        """
        Generate random label flips (uniform noise).
        
        Each label has `noise_rate` probability of being flipped to a random class.
        
        Args:
            labels: Original labels
            noise_rate: Probability of flipping each label (0.0 to 1.0)
            num_classes: Number of classes (auto-detected if None)
            preserve_distribution: Try to preserve original class distribution
        
        Returns:
            CorruptionResult with corrupted labels and metadata
        """
        labels_array = self._to_numpy(labels)
        n_samples = len(labels_array)
        
        # Determine num_classes
        if num_classes is None:
            unique = np.unique(labels_array)
            num_classes = len(unique)
        
        # Generate corruption mask
        corruption_mask = np.random.random(n_samples) < noise_rate
        
        # Generate corrupted labels
        corrupted_labels = labels_array.copy()
        
        if preserve_distribution:
            # Preserve distribution by sampling from original distribution
            original_dist = self._get_class_distribution(labels_array)
            total = sum(original_dist.values())
            probs = [original_dist.get(i, 0) / total for i in range(num_classes)]
            
            for i in range(n_samples):
                if corruption_mask[i]:
                    # Sample from original distribution
                    if self._rng is not None:
                        corrupted_labels[i] = self._rng.choice(num_classes, p=probs)
                    else:
                        corrupted_labels[i] = np.random.choice(num_classes, p=probs)
        else:
            # Uniform random flips
            for i in range(n_samples):
                if corruption_mask[i]:
                    # Flip to random class (excluding original)
                    possible_classes = [c for c in range(num_classes) if c != labels_array[i]]
            if possible_classes:
                if self._rng is not None:
                    corrupted_labels[i] = self._rng.choice(possible_classes)
                else:
                    corrupted_labels[i] = np.random.choice(possible_classes)
                    # If only one class, can't flip
        
        actual_rate = corruption_mask.sum() / n_samples
        
        return CorruptionResult(
            corrupted_labels=corrupted_labels,
            corruption_mask=corruption_mask,
            corruption_rate=actual_rate,
            original_distribution=self._get_class_distribution(labels_array),
            corrupted_distribution=self._get_class_distribution(corrupted_labels),
            metadata={
                "noise_type": NoiseType.RANDOM.value,
                "noise_rate": noise_rate,
                "preserve_distribution": preserve_distribution,
            },
        )
    
    def generate_targeted_flips(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        target_class: int,
        noise_rate: float = 0.1,
    ) -> CorruptionResult:
        """
        Generate targeted label flips (adversarial).
        
        Flips labels to a specific target class. Useful for adversarial testing.
        
        Args:
            labels: Original labels
            target_class: Class to flip labels to
            noise_rate: Probability of flipping each label
        
        Returns:
            CorruptionResult with corrupted labels
        """
        labels_array = self._to_numpy(labels)
        n_samples = len(labels_array)
        
        # Generate corruption mask
        corruption_mask = np.random.random(n_samples) < noise_rate
        
        # Generate corrupted labels
        corrupted_labels = labels_array.copy()
        for i in range(n_samples):
            if corruption_mask[i] and labels_array[i] != target_class:
                corrupted_labels[i] = target_class
        
        actual_rate = corruption_mask.sum() / n_samples
        
        return CorruptionResult(
            corrupted_labels=corrupted_labels,
            corruption_mask=corruption_mask,
            corruption_rate=actual_rate,
            original_distribution=self._get_class_distribution(labels_array),
            corrupted_distribution=self._get_class_distribution(corrupted_labels),
            metadata={
                "noise_type": NoiseType.TARGETED.value,
                "target_class": target_class,
                "noise_rate": noise_rate,
            },
        )
    
    def generate_class_dependent_noise(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        noise_matrix: np.ndarray,
    ) -> CorruptionResult:
        """
        Generate class-dependent label noise.
        
        Uses a noise matrix where noise_matrix[i, j] is the probability
        of flipping class i to class j.
        
        Args:
            labels: Original labels
            noise_matrix: [num_classes, num_classes] noise transition matrix
        
        Returns:
            CorruptionResult with corrupted labels
        """
        labels_array = self._to_numpy(labels)
        n_samples = len(labels_array)
        num_classes = noise_matrix.shape[0]
        
        if noise_matrix.shape != (num_classes, num_classes):
            raise ValueError(f"Noise matrix must be [{num_classes}, {num_classes}]")
        
        # Generate corrupted labels
        corrupted_labels = labels_array.copy()
        corruption_mask = np.zeros(n_samples, dtype=bool)
        
        for i in range(n_samples):
            original_class = int(labels_array[i])
            if original_class >= num_classes:
                continue  # Skip invalid classes
            
                # Sample from noise distribution for this class
                probs = noise_matrix[original_class, :]
                # Don't allow staying in same class (normalize)
                probs[original_class] = 0.0
                probs_sum = probs.sum()
                if probs_sum > 0:
                    probs = probs / probs_sum
                    if self._rng is not None:
                        new_class = self._rng.choice(num_classes, p=probs)
                    else:
                        new_class = np.random.choice(num_classes, p=probs)
                corrupted_labels[i] = new_class
                corruption_mask[i] = True
        
        actual_rate = corruption_mask.sum() / n_samples
        
        return CorruptionResult(
            corrupted_labels=corrupted_labels,
            corruption_mask=corruption_mask,
            corruption_rate=actual_rate,
            original_distribution=self._get_class_distribution(labels_array),
            corrupted_distribution=self._get_class_distribution(corrupted_labels),
            metadata={
                "noise_type": NoiseType.CLASS_DEPENDENT.value,
                "noise_matrix": noise_matrix.tolist(),
            },
        )
    
    def generate_rsn_specific_corruption(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        corruption_type: str = "poisoning",
        intensity: float = 0.5,
    ) -> CorruptionResult:
        """
        Generate R/S/N-specific label corruption.
        
        Corruption patterns designed for R/S/N labels (0=R, 1=S, 2=N):
        - "poisoning": Increase N labels (0,1 -> 2)
        - "distraction": Increase S labels (0,2 -> 1)
        - "confusion": Mix R and S (0 <-> 1)
        - "collapse": All labels become same class
        
        Args:
            labels: Original R/S/N labels (0, 1, 2)
            corruption_type: Type of corruption pattern
            intensity: Corruption intensity (0.0 to 1.0)
        
        Returns:
            CorruptionResult with corrupted labels
        """
        labels_array = self._to_numpy(labels)
        n_samples = len(labels_array)
        
        # Validate R/S/N labels
        unique = np.unique(labels_array)
        if not all(0 <= u <= 2 for u in unique):
            raise ValueError("R/S/N labels must be 0, 1, or 2")
        
        corrupted_labels = labels_array.copy()
        corruption_mask = np.zeros(n_samples, dtype=bool)
        
        if corruption_type == "poisoning":
            # Increase N (noise) labels: R,S -> N
            for i in range(n_samples):
                rand_val = self._rng.random() if self._rng is not None else np.random.random()
                if labels_array[i] in [0, 1] and rand_val < intensity:
                    corrupted_labels[i] = 2  # N
                    corruption_mask[i] = True
        
        elif corruption_type == "distraction":
            # Increase S (superfluous) labels: R,N -> S
            for i in range(n_samples):
                rand_val = self._rng.random() if self._rng is not None else np.random.random()
                if labels_array[i] in [0, 2] and rand_val < intensity:
                    corrupted_labels[i] = 1  # S
                    corruption_mask[i] = True
        
        elif corruption_type == "confusion":
            # Mix R and S: 0 <-> 1
            for i in range(n_samples):
                rand_val = self._rng.random() if self._rng is not None else np.random.random()
                if labels_array[i] in [0, 1] and rand_val < intensity:
                    corrupted_labels[i] = 1 - labels_array[i]  # Flip 0<->1
                    corruption_mask[i] = True
        
        elif corruption_type == "collapse":
            # All labels become same class (most common)
            most_common = int(np.bincount(labels_array.astype(int)).argmax())
            for i in range(n_samples):
                rand_val = self._rng.random() if self._rng is not None else np.random.random()
                if labels_array[i] != most_common and rand_val < intensity:
                    corrupted_labels[i] = most_common
                    corruption_mask[i] = True
        
        else:
            raise ValueError(
                f"Unknown corruption type: {corruption_type}. "
                f"Must be one of: poisoning, distraction, confusion, collapse"
            )
        
        actual_rate = corruption_mask.sum() / n_samples
        
        return CorruptionResult(
            corrupted_labels=corrupted_labels,
            corruption_mask=corruption_mask,
            corruption_rate=actual_rate,
            original_distribution=self._get_class_distribution(labels_array),
            corrupted_distribution=self._get_class_distribution(corrupted_labels),
            metadata={
                "noise_type": NoiseType.RSN_SPECIFIC.value,
                "corruption_type": corruption_type,
                "intensity": intensity,
            },
        )
    
    def generate_adversarial_labels(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        model: Optional[Any] = None,
        embeddings: Optional[Union[torch.Tensor, np.ndarray]] = None,
        noise_rate: float = 0.1,
    ) -> CorruptionResult:
        """
        Generate adversarial labels using model predictions.
        
        Flips labels to classes that the model is most confident about
        (but incorrectly). This creates adversarial examples.
        
        Args:
            labels: Original labels
            model: Model to use for adversarial generation (optional)
            embeddings: Input embeddings for model (optional)
            noise_rate: Probability of flipping each label
        
        Returns:
            CorruptionResult with corrupted labels
        
        Note:
            This is a placeholder for future adversarial label generation.
            Currently falls back to random flips if model is not provided.
        """
        if model is None or embeddings is None:
            # Fall back to random flips
            return self.generate_random_flips(labels, noise_rate=noise_rate)
        
        # TODO: Implement model-based adversarial label generation
        # This would:
        # 1. Get model predictions
        # 2. Find samples where model is confident but wrong
        # 3. Flip labels to model's predicted class
        # 4. This creates adversarial training examples
        
        # For now, use random flips
        return self.generate_random_flips(labels, noise_rate=noise_rate)
    
    def generate_from_config(
        self,
        labels: Union[torch.Tensor, np.ndarray, List[int]],
        config: NoiseConfig,
    ) -> CorruptionResult:
        """
        Generate corrupted labels from configuration.
        
        Args:
            labels: Original labels
            config: Noise configuration
        
        Returns:
            CorruptionResult with corrupted labels
        """
        if config.seed is not None:
            self.__init__(seed=config.seed)
        
        if config.noise_type == NoiseType.RANDOM:
            return self.generate_random_flips(
                labels,
                noise_rate=config.noise_rate,
                preserve_distribution=config.preserve_distribution,
            )
        elif config.noise_type == NoiseType.TARGETED:
            if config.target_class is None:
                raise ValueError("target_class required for targeted noise")
            return self.generate_targeted_flips(
                labels,
                target_class=config.target_class,
                noise_rate=config.noise_rate,
            )
        elif config.noise_type == NoiseType.CLASS_DEPENDENT:
            if config.noise_matrix is None:
                raise ValueError("noise_matrix required for class-dependent noise")
            return self.generate_class_dependent_noise(labels, config.noise_matrix)
        elif config.noise_type == NoiseType.RSN_SPECIFIC:
            return self.generate_rsn_specific_corruption(
                labels,
                corruption_type="poisoning",  # Default, could be configurable
                intensity=config.noise_rate,
            )
        else:
            raise ValueError(f"Unknown noise type: {config.noise_type}")


__all__ = [
    "FalseLabelGenerator",
    "NoiseConfig",
    "NoiseType",
    "CorruptionResult",
]

