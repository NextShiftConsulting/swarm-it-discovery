"""
Ω Gateway - Production Interface for Geometric Compatibility Checking

This module combines:
- geometry_compatibility.py: Measures ω = κ(E,S)
- omega_policy.py: Determines what to DO based on ω

Ω is the geometric firewall between perception and reasoning.
When it lies, everything lies.

USAGE:
------
>>> from yrsn.core.decomposition.omega_gateway import OmegaGateway
>>>
>>> # Initialize once
>>> gateway = OmegaGateway.from_rotor_checkpoint(
...     checkpoint_path="rotor_v1/",
...     consumer_tier=ConsumerTier.B,
...     environment_tier=EnvironmentTier.STABLE,
... )
>>>
>>> # Check every request
>>> result = gateway.check(adapter_output)
>>> if result.action == FallbackAction.PROCEED:
...     output = rotor(adapter_output)
>>> elif result.action == FallbackAction.RE_ENCODE:
...     adapter_output = re_encode(input)
...     output = rotor(adapter_output)
>>> else:
...     output = handle_fallback(result)

PIPELINE PLACEMENT:
------------------
    Input → Adapter → [Ω GATEWAY] → Rotor → Output
                          │
                          ├── PROCEED: continue to rotor
                          ├── RE_ENCODE: try alternate encoding
                          ├── SWITCH_GEAR: use safer inference mode
                          ├── SWITCH_BACKEND: fall back to symbolic
                          ├── RETURN_PRIOR: return prior + explanation
                          ├── QUARANTINE: flag for human review
                          ├── SIMULATE_FIRST: digital twin (hardware)
                          └── REJECT: do not proceed

LOGGING SCHEMA:
--------------
Every check produces a structured log entry:
{
    "omega_total": 0.72,
    "omega_decomposition": {
        "mahalanobis": 0.85,
        "norm": 0.95,
        "templates": 0.68,
        "cka": null
    },
    "action": "PROCEED",
    "policy": "business_critical_stable",
    "consumer_tier": "B",
    "environment_tier": "STABLE",
    "latency_ms": 2.3,
    "fallback_used": false,
    "timestamp": "2025-01-30T12:34:56Z"
}
"""

import numpy as np
import time
import logging
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, Tuple, Callable
from pathlib import Path
from datetime import datetime

from .geometry_compatibility import (
    GeometryCompatibilityChecker,
    TrainingDistributionStats,
    CompatibilityReport,
)
from .omega_policy import (
    OmegaPolicy,
    OmegaPolicyRegistry,
    ConsumerTier,
    EnvironmentTier,
    FallbackAction,
    create_default_policy,
)


logger = logging.getLogger(__name__)


# =============================================================================
# Gateway Result
# =============================================================================

@dataclass
class OmegaCheckResult:
    """
    Result of an Ω gateway check.

    Contains everything needed for:
    - Making a proceed/fallback decision
    - Logging for observability
    - Debugging geometry mismatches
    """
    # Decision
    omega: float                           # Combined ω [0, 1]
    action: FallbackAction                 # What to do
    proceed: bool                          # Shortcut: action == PROCEED

    # Decomposition (for debugging)
    omega_mahalanobis: float              # ω₁: Distribution match
    omega_norm: float                      # ω₃: Norm consistency
    omega_templates: Optional[float]       # ω₂: Template similarity (if computed)
    omega_cka: Optional[float]            # ω₄: CKA alignment (if computed)

    # Context
    policy_name: str
    consumer_tier: str
    environment_tier: str
    omega_classification: str              # "low", "borderline", "high"

    # Diagnostics
    latency_ms: float
    timestamp: str

    # Detailed report (optional, for debugging)
    compatibility_report: Optional[CompatibilityReport] = None

    def to_log_dict(self) -> Dict[str, Any]:
        """Convert to structured log entry."""
        return {
            "omega_total": round(self.omega, 4),
            "omega_decomposition": {
                "mahalanobis": round(self.omega_mahalanobis, 4),
                "norm": round(self.omega_norm, 4),
                "templates": round(self.omega_templates, 4) if self.omega_templates else None,
                "cka": round(self.omega_cka, 4) if self.omega_cka else None,
            },
            "action": self.action.name,
            "proceed": self.proceed,
            "classification": self.omega_classification,
            "policy": self.policy_name,
            "consumer_tier": self.consumer_tier,
            "environment_tier": self.environment_tier,
            "latency_ms": round(self.latency_ms, 2),
            "timestamp": self.timestamp,
        }


# =============================================================================
# Template Bank (for ω₂)
# =============================================================================

class TemplateBank:
    """
    Bank of known-good embeddings for template similarity (ω₂).

    These are reference embeddings that the rotor is known to handle well.
    """

    def __init__(self, templates: Optional[np.ndarray] = None):
        """
        Args:
            templates: Reference embeddings [N, embed_dim]
        """
        self.templates = templates
        self._normalized = False

        if templates is not None:
            self._normalize_templates()

    def _normalize_templates(self):
        """L2 normalize templates for cosine similarity."""
        if self.templates is not None and not self._normalized:
            norms = np.linalg.norm(self.templates, axis=1, keepdims=True)
            self.templates = self.templates / (norms + 1e-8)
            self._normalized = True

    def compute_similarity(self, features: np.ndarray) -> float:
        """
        Compute max cosine similarity to templates.

        Args:
            features: Query features [embed_dim] or [N, embed_dim]

        Returns:
            Max cosine similarity to any template [0, 1]
        """
        if self.templates is None or len(self.templates) == 0:
            return 1.0  # No templates = assume compatible

        features = np.asarray(features)
        if features.ndim == 1:
            features = features.reshape(1, -1)

        # L2 normalize query
        norms = np.linalg.norm(features, axis=1, keepdims=True)
        features_norm = features / (norms + 1e-8)

        # Mean of queries
        query = features_norm.mean(axis=0)

        # Cosine similarity to all templates
        similarities = self.templates @ query

        return float(similarities.max())

    @classmethod
    def from_features(cls, features: np.ndarray, n_templates: int = 100) -> 'TemplateBank':
        """
        Create template bank from training features.

        Uses k-means clustering to select representative templates.

        Args:
            features: Training features [N, embed_dim]
            n_templates: Number of templates to keep

        Returns:
            TemplateBank with representative embeddings
        """
        features = np.asarray(features)

        if len(features) <= n_templates:
            return cls(templates=features.copy())

        # Simple sampling (for production, use k-means)
        indices = np.random.choice(len(features), n_templates, replace=False)
        return cls(templates=features[indices].copy())

    def save(self, path: Path):
        """Save templates to file."""
        np.save(path, self.templates)

    @classmethod
    def load(cls, path: Path) -> 'TemplateBank':
        """Load templates from file."""
        templates = np.load(path)
        return cls(templates=templates)


# =============================================================================
# Ω Gateway
# =============================================================================

class OmegaGateway:
    """
    Production gateway for geometric compatibility checking.

    Combines:
    - GeometryCompatibilityChecker: Computes ω signals
    - OmegaPolicy: Determines action based on ω
    - TemplateBank: Reference embeddings for ω₂
    - Logging: Structured observability

    This is the PRIMARY interface for ω checking in production.
    """

    def __init__(
        self,
        checker: GeometryCompatibilityChecker,
        policy: OmegaPolicy,
        template_bank: Optional[TemplateBank] = None,
        cka_reference: Optional[np.ndarray] = None,
        log_callback: Optional[Callable[[Dict], None]] = None,
    ):
        """
        Initialize Ω gateway.

        Args:
            checker: Geometry compatibility checker (computes ω₁, ω₃)
            policy: Ω policy (determines action based on ω)
            template_bank: Reference embeddings for ω₂ (optional)
            cka_reference: Reference batch for CKA ω₄ (optional)
            log_callback: Custom logging function (optional)
        """
        self.checker = checker
        self.policy = policy
        self.template_bank = template_bank
        self.cka_reference = cka_reference
        self.log_callback = log_callback or self._default_log

        # Validate policy has required signals
        self._validate_policy()

    def _validate_policy(self):
        """Ensure policy can be satisfied with available data."""
        if self.policy.compute_templates and self.template_bank is None:
            logger.warning(f"Policy {self.policy.name} requests templates but none provided")

        if self.policy.compute_cka and self.cka_reference is None:
            logger.warning(f"Policy {self.policy.name} requests CKA but no reference provided")

    def _default_log(self, entry: Dict):
        """Default logging: write to logger."""
        logger.info(f"omega_check: {entry}")

    def check(
        self,
        features: np.ndarray,
        include_report: bool = False,
    ) -> OmegaCheckResult:
        """
        Check geometric compatibility and determine action.

        This is the main entry point.

        Args:
            features: Adapter output [N, embed_dim] or [embed_dim]
            include_report: Include detailed CompatibilityReport

        Returns:
            OmegaCheckResult with decision and diagnostics
        """
        start_time = time.perf_counter()
        features = np.asarray(features)

        # ================================================================
        # Compute ω signals based on policy
        # ================================================================

        # ω₁: Mahalanobis (always computed)
        omega_mah, report = self.checker.estimate_omega(features, return_report=True)

        # Extract norm score from report
        omega_norm = report.scale_match

        # ω₂: Template similarity (if policy requires)
        omega_templates = None
        if self.policy.compute_templates and self.template_bank is not None:
            omega_templates = self.template_bank.compute_similarity(features)

        # ω₄: CKA alignment (if policy requires and borderline)
        omega_cka = None
        # Note: CKA is expensive, only compute on borderline cases
        # For now, skip CKA - implement when needed

        # ================================================================
        # Combine ω signals
        # ================================================================

        # Primary combination: geometric compatibility from checker
        omega_combined = omega_mah

        # Incorporate template similarity if available
        if omega_templates is not None:
            # Geometric mean of mahalanobis-based and template-based
            omega_combined = np.sqrt(omega_mah * omega_templates)

        # ================================================================
        # Get action from policy
        # ================================================================

        omega_decomposition = {
            "mahalanobis": omega_mah,
            "norm": omega_norm,
            "templates": omega_templates,
            "cka": omega_cka,
        }

        action = self.policy.get_action(omega_combined, omega_decomposition)
        classification = self.policy.thresholds.classify(omega_combined)

        # ================================================================
        # Build result
        # ================================================================

        latency_ms = (time.perf_counter() - start_time) * 1000

        result = OmegaCheckResult(
            omega=omega_combined,
            action=action,
            proceed=(action == FallbackAction.PROCEED),
            omega_mahalanobis=omega_mah,
            omega_norm=omega_norm,
            omega_templates=omega_templates,
            omega_cka=omega_cka,
            policy_name=self.policy.name,
            consumer_tier=self.policy.consumer_tier.value,
            environment_tier=self.policy.environment_tier.name,
            omega_classification=classification,
            latency_ms=latency_ms,
            timestamp=datetime.now().astimezone().isoformat(),
            compatibility_report=report if include_report else None,
        )

        # ================================================================
        # Log (respecting sample rate)
        # ================================================================

        if np.random.random() < self.policy.sample_rate:
            log_entry = result.to_log_dict()
            if self.policy.log_raw_embeddings:
                log_entry["embedding_hash"] = hash(features.tobytes()) % (10 ** 8)
            self.log_callback(log_entry)

        return result

    def check_batch(
        self,
        features_batch: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Check batch of features.

        Args:
            features_batch: [B, embed_dim]

        Returns:
            (omega_values, proceed_mask) - arrays of shape [B]
        """
        omegas = []
        proceeds = []

        for features in features_batch:
            result = self.check(features)
            omegas.append(result.omega)
            proceeds.append(result.proceed)

        return np.array(omegas), np.array(proceeds)

    @classmethod
    def from_rotor_checkpoint(
        cls,
        checkpoint_path: Path,
        consumer_tier: ConsumerTier = ConsumerTier.B,
        environment_tier: EnvironmentTier = EnvironmentTier.STABLE,
        policy: Optional[OmegaPolicy] = None,
    ) -> 'OmegaGateway':
        """
        Create gateway from rotor checkpoint directory.

        Expected files in checkpoint_path:
        - geometry_stats.npz: Training distribution stats
        - templates.npy: Reference templates (optional)

        Args:
            checkpoint_path: Path to rotor checkpoint directory
            consumer_tier: Consumer risk tier
            environment_tier: Environment stability tier
            policy: Custom policy (or created from tiers)

        Returns:
            Configured OmegaGateway
        """
        checkpoint_path = Path(checkpoint_path)

        # Load training stats
        stats_path = checkpoint_path / "geometry_stats.npz"
        if stats_path.exists():
            training_stats = TrainingDistributionStats.load(stats_path)
        else:
            logger.warning(f"No geometry_stats.npz found at {checkpoint_path}")
            training_stats = None

        # Create checker
        checker = GeometryCompatibilityChecker(training_stats=training_stats)

        # Load templates if available
        templates_path = checkpoint_path / "templates.npy"
        if templates_path.exists():
            template_bank = TemplateBank.load(templates_path)
        else:
            template_bank = None

        # Create or use provided policy
        if policy is None:
            policy = create_default_policy(consumer_tier, environment_tier)

        return cls(
            checker=checker,
            policy=policy,
            template_bank=template_bank,
        )

    @classmethod
    def create_minimal(
        cls,
        expected_dim: int,
        consumer_tier: ConsumerTier = ConsumerTier.C,
    ) -> 'OmegaGateway':
        """
        Create minimal gateway for development/testing.

        No calibration data - just dimension checking and permissive policy.

        Args:
            expected_dim: Expected embedding dimension
            consumer_tier: Consumer tier (default: exploratory)

        Returns:
            Minimal OmegaGateway
        """
        checker = GeometryCompatibilityChecker(
            training_stats=None,
            expected_dim=expected_dim,
        )

        policy = create_default_policy(consumer_tier, EnvironmentTier.STABLE)

        return cls(checker=checker, policy=policy)


# =============================================================================
# Convenience Functions
# =============================================================================

def quick_check(
    features: np.ndarray,
    training_stats: Optional[TrainingDistributionStats] = None,
    expected_dim: Optional[int] = None,
) -> Tuple[float, FallbackAction]:
    """
    Quick ω check without full gateway setup.

    For simple use cases where you just need ω and basic action.

    Args:
        features: Adapter output
        training_stats: Training distribution stats (optional)
        expected_dim: Expected dimension (optional)

    Returns:
        (omega, action)
    """
    checker = GeometryCompatibilityChecker(
        training_stats=training_stats,
        expected_dim=expected_dim,
    )

    omega = checker.estimate_omega(features)

    # Simple action logic
    if omega >= 0.6:
        action = FallbackAction.PROCEED
    elif omega >= 0.25:
        action = FallbackAction.RE_ENCODE
    else:
        action = FallbackAction.RETURN_PRIOR

    return omega, action


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'OmegaGateway',
    'OmegaCheckResult',
    'TemplateBank',
    'quick_check',
]


if __name__ == "__main__":
    # Demo: create gateway and check some features
    print("=" * 80)
    print("Ω GATEWAY DEMO")
    print("=" * 80)

    # Create minimal gateway
    gateway = OmegaGateway.create_minimal(
        expected_dim=768,
        consumer_tier=ConsumerTier.B,
    )

    # Simulate some features
    print("\nSimulating feature checks...")

    # Good features (normalized, expected dim)
    good_features = np.random.randn(768)
    good_features = good_features / np.linalg.norm(good_features)

    result = gateway.check(good_features, include_report=True)
    print(f"\nGood features:")
    print(f"  ω = {result.omega:.3f}")
    print(f"  Action = {result.action.name}")
    print(f"  Proceed = {result.proceed}")
    print(f"  Latency = {result.latency_ms:.2f}ms")

    # Bad features (wrong dimension)
    bad_features = np.random.randn(512)  # Wrong dim
    bad_features = bad_features / np.linalg.norm(bad_features)

    # Create checker that expects 768
    gateway_strict = OmegaGateway.create_minimal(
        expected_dim=768,
        consumer_tier=ConsumerTier.A,
    )

    result = gateway_strict.check(bad_features)
    print(f"\nBad features (wrong dim):")
    print(f"  ω = {result.omega:.3f}")
    print(f"  Action = {result.action.name}")
    print(f"  Proceed = {result.proceed}")

    print("\n" + "=" * 80)
    print("PHYSICAL SOLVER (MEMRISTOR) DEMO")
    print("=" * 80)

    # Create gateway for physical solver
    gateway_hw = OmegaGateway.create_minimal(
        expected_dim=768,
        consumer_tier=ConsumerTier.D,  # Physical solver
    )

    print(f"\nPolicy: {gateway_hw.policy.name}")
    print(f"Level: {gateway_hw.policy.omega_level.name}")
    print(f"Hardware gate mandatory: {gateway_hw.policy.hardware_gate_mandatory}")

    # Check marginal features
    marginal_features = np.random.randn(768)
    marginal_features = marginal_features / np.linalg.norm(marginal_features) * 0.8  # Slightly off norm

    result = gateway_hw.check(marginal_features)
    print(f"\nMarginal features on hardware solver:")
    print(f"  ω = {result.omega:.3f}")
    print(f"  Action = {result.action.name}")
    print(f"  Proceed = {result.proceed}")
