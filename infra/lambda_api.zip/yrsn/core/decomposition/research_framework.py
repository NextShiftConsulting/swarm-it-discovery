"""
Research Framework - Y="+", C="-" Mathematical Model
===================================================

Y=R+S+N Mathematical Decomposition Framework for Research Paper Analysis.

Implementation of the mathematical decomposition framework for Context Engineering:
Y = "+" (Relevant Content) vs C = "-" (Context Collapse)

Where C = R + S + N:
- R: Relevant systematic items
- S: Superfluous marginally systematic content
- N: True noise and errors

This module provides scoring and analysis functions for research papers.

Created by: Rudy Martin / Next Shift Consulting LLC
License: AGPL-3.0
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
import re
import math

# Import DecompositionScore from parent module
from . import DecompositionScore


@dataclass
class PaperAnalysis:
    """Complete analysis of a research paper."""

    title: str
    authors: List[str]
    arxiv_id: Optional[str]
    abstract: str
    decomposition: DecompositionScore
    context_relevance: str  # "High", "Medium", "Low"
    key_concepts: List[str]
    methodology_score: float

    @property
    def overall_score(self) -> float:
        """Combined scoring metric."""
        return (self.decomposition.y_score * 0.7) + (self.methodology_score * 0.3)


class ResearchFramework:
    """Core framework for Y="+", C="-" research paper analysis."""

    # Mathematical decomposition keywords
    RELEVANT_KEYWORDS = [
        'mathematical decomposition', 'signal separation', 'noise reduction',
        'systematic analysis', 'orthogonal projection', 'residual analysis',
        'variance decomposition', 'systematic risk', 'signal processing',
        'mathematical model', 'systematic error', 'noise filtering'
    ]

    SUPERFLUOUS_KEYWORDS = [
        'background information', 'literature review', 'historical context',
        'future work', 'acknowledgments', 'related work', 'introduction',
        'general discussion', 'broader implications', 'survey'
    ]

    NOISE_KEYWORDS = [
        'formatting error', 'typo', 'reference error', 'unclear text',
        'incomplete sentence', 'broken equation', 'missing data',
        'unrelated content', 'advertising', 'boilerplate'
    ]

    def __init__(self):
        self.analysis_cache: Dict[str, DecompositionScore] = {}

    def _calculate_semantic_relevance(self, text: str, search_query: str) -> float:
        """
        Calculate semantic relevance between text and search query.

        Uses term frequency and semantic similarity techniques.
        Returns: float 0.0-1.0 representing relevance
        """
        if not search_query.strip():
            return 0.5  # Default relevance when no query provided

        text = text.lower()
        query = search_query.lower()

        # Direct query term matching
        query_terms = [term.strip() for term in query.split() if len(term.strip()) > 2]
        if not query_terms:
            return 0.5

        # Calculate term overlap
        direct_matches = sum(1 for term in query_terms if term in text)
        direct_relevance = direct_matches / len(query_terms)

        # Semantic expansion - find related terms
        semantic_score = self._calculate_semantic_expansion(text, query_terms)

        # Title boost - if query terms appear in title area (first 100 chars)
        title_area = text[:100]
        title_matches = sum(1 for term in query_terms if term in title_area)
        title_boost = (title_matches / len(query_terms)) * 0.3

        # Combined relevance score
        total_relevance = min(1.0, direct_relevance + semantic_score + title_boost)

        return total_relevance

    def _calculate_semantic_expansion(self, text: str, query_terms: List[str]) -> float:
        """Calculate semantic similarity using domain-specific term relationships."""
        # Domain-specific semantic mappings
        semantic_groups = {
            'neural': ['network', 'neuron', 'deep', 'learning', 'artificial', 'intelligence', 'ai'],
            'network': ['neural', 'graph', 'connection', 'node', 'edge', 'topology'],
            'machine': ['learning', 'ai', 'artificial', 'algorithm', 'model', 'training'],
            'learning': ['machine', 'training', 'optimization', 'gradient', 'model'],
            'signal': ['processing', 'filter', 'frequency', 'noise', 'decomposition'],
            'processing': ['signal', 'image', 'data', 'algorithm', 'computation'],
            'mathematical': ['math', 'equation', 'formula', 'theorem', 'proof', 'analysis'],
            'decomposition': ['factorization', 'separation', 'analysis', 'breakdown'],
            'quantum': ['physics', 'mechanics', 'entanglement', 'superposition', 'qubit'],
            'physics': ['quantum', 'particle', 'energy', 'matter', 'field']
        }

        semantic_score = 0.0
        total_possible = 0

        for query_term in query_terms:
            if query_term in semantic_groups:
                related_terms = semantic_groups[query_term]
                matches = sum(1 for term in related_terms if term in text)
                if related_terms:
                    semantic_score += matches / len(related_terms)
                    total_possible += 1

        if total_possible > 0:
            # Weight semantic expansion lower than direct matches
            return (semantic_score / total_possible) * 0.4

        return 0.0

    def analyze_paper_content(
        self,
        title: str,
        abstract: str,
        content: str = "",
        search_query: str = ""
    ) -> DecompositionScore:
        """
        Analyze paper content and return R+S+N decomposition.

        Args:
            title: Paper title
            abstract: Paper abstract
            content: Full paper content (optional)
            search_query: Search query to calculate relevance against

        Returns:
            DecompositionScore with R, S, N components
        """
        # Combine available text
        full_text = f"{title} {abstract} {content}".lower()

        # Calculate semantic relevance to search query
        query_relevance = self._calculate_semantic_relevance(full_text, search_query)

        # Count keyword matches
        relevant_matches = sum(1 for kw in self.RELEVANT_KEYWORDS if kw in full_text)
        superfluous_matches = sum(1 for kw in self.SUPERFLUOUS_KEYWORDS if kw in full_text)
        noise_matches = sum(1 for kw in self.NOISE_KEYWORDS if kw in full_text)

        # Base scoring - query relevance is primary factor
        base_r = 0.2 + (relevant_matches * 0.04) + (query_relevance * 0.4)
        base_s = 0.2 + (superfluous_matches * 0.05)
        base_n = 0.1 + (noise_matches * 0.03)

        # Apply content-specific bonuses/penalties
        math_terms = ['mathematical', 'equation', 'formula', 'theorem', 'proof', 'decomposition']
        math_count = sum(1 for term in math_terms if term in full_text)

        if math_count >= 3:
            base_r += 0.15  # High math content boosts relevance
            base_s -= 0.05  # Reduces superfluous content
        elif math_count >= 1:
            base_r += 0.08

        # Context Engineering terms boost
        context_terms = ['context', 'engineering', 'systematic', 'signal', 'noise']
        context_count = sum(1 for term in context_terms if term in full_text)

        if context_count >= 2:
            base_r += 0.12
            base_n -= 0.03

        # Quality indicators
        quality_terms = ['robust', 'validated', 'comprehensive', 'rigorous']
        quality_count = sum(1 for term in quality_terms if term in full_text)

        if quality_count >= 1:
            base_r += 0.05
            base_n -= 0.02

        # Complexity penalty (too much jargon can add noise)
        complex_terms = ['heterogeneous', 'multidimensional', 'nonlinear', 'stochastic']
        complexity = sum(1 for term in complex_terms if term in full_text)

        if complexity >= 2:
            base_s += 0.08
            base_n += 0.05

        # Ensure realistic bounds
        r_score = max(0.25, min(0.85, base_r))
        s_score = max(0.10, min(0.45, base_s))
        n_score = max(0.05, min(0.35, base_n))

        # Create and normalize the score
        score = DecompositionScore(r_score, s_score, n_score).normalize()
        return score

    def calculate_y_score(self, decomposition: DecompositionScore) -> float:
        """
        Calculate Y score using the Y="+" framework.

        Y represents relevant content that contributes positively to understanding.
        """
        return decomposition.y_score

    def calculate_context_collapse_risk(
        self,
        decomposition: DecompositionScore
    ) -> Tuple[float, str]:
        """
        Calculate Context Collapse risk using C="-" framework.

        Returns:
            (risk_score, risk_level) where risk_level is "Low", "Medium", "High"
        """
        # Context collapse increases with superfluous content and noise
        c_score = decomposition.superfluous + (1.5 * decomposition.noise)

        if c_score < 0.3:
            return c_score, "Low"
        elif c_score < 0.6:
            return c_score, "Medium"
        else:
            return c_score, "High"

    def analyze_mathematical_content(self, text: str) -> Dict[str, float]:
        """
        Analyze mathematical content quality in research papers.

        Returns scores for different mathematical aspects.
        """
        text_lower = text.lower()
        word_count = max(len(text.split()), 1)

        scores = {
            'equation_density': len(re.findall(r'equation|formula|\$.*?\$', text)) / word_count,
            'proof_rigor': len(re.findall(r'proof|theorem|lemma|corollary', text_lower)) / word_count,
            'model_complexity': len(re.findall(r'model|framework|system|approach', text_lower)) / word_count,
            'validation_strength': len(re.findall(r'validation|verification|test|experiment', text_lower)) / word_count
        }

        return {k: min(1.0, v * 100) for k, v in scores.items()}

    def generate_paper_recommendations(self, analysis: PaperAnalysis) -> List[str]:
        """Generate actionable recommendations based on paper analysis."""
        recommendations = []

        decomp = analysis.decomposition

        if decomp.relevant > 0.8:
            recommendations.append("High relevance - Excellent for Context Engineering research")
        elif decomp.relevant > 0.6:
            recommendations.append("Good relevance - Useful supporting material")
        else:
            recommendations.append("Low relevance - Consider secondary source")

        if decomp.noise > 0.3:
            recommendations.append("High noise content - May need preprocessing")

        if decomp.superfluous > 0.4:
            recommendations.append("High superfluous content - Focus on core sections")

        y_score = decomp.y_score
        if y_score > 0.9:
            recommendations.append("Core paper - Essential for framework validation")
        elif y_score > 0.7:
            recommendations.append("Supporting paper - Good for literature review")

        context_risk, risk_level = self.calculate_context_collapse_risk(decomp)
        if risk_level == "High":
            recommendations.append("High context collapse risk - Use with caution")
        elif risk_level == "Medium":
            recommendations.append("Medium context collapse risk - Validate key claims")

        return recommendations

    def create_paper_analysis(
        self,
        title: str,
        authors: List[str],
        abstract: str,
        arxiv_id: Optional[str] = None,
        content: str = "",
        search_query: str = ""
    ) -> PaperAnalysis:
        """
        Create a complete PaperAnalysis from input data.

        Args:
            title: Paper title
            authors: List of author names
            abstract: Paper abstract
            arxiv_id: Optional arXiv identifier
            content: Full paper content (optional)
            search_query: Search query for relevance scoring

        Returns:
            PaperAnalysis instance
        """
        decomp = self.analyze_paper_content(title, abstract, content, search_query)
        math_scores = self.analyze_mathematical_content(f"{title} {abstract} {content}")

        # Determine context relevance category
        if decomp.y_score > 0.8:
            context_relevance = "High"
        elif decomp.y_score > 0.6:
            context_relevance = "Medium"
        else:
            context_relevance = "Low"

        # Compute methodology score from mathematical content
        methodology_score = (
            math_scores['equation_density'] * 0.2 +
            math_scores['proof_rigor'] * 0.3 +
            math_scores['model_complexity'] * 0.2 +
            math_scores['validation_strength'] * 0.3
        )

        return PaperAnalysis(
            title=title,
            authors=authors,
            arxiv_id=arxiv_id,
            abstract=abstract,
            decomposition=decomp,
            context_relevance=context_relevance,
            key_concepts=["mathematical decomposition", "signal separation", "noise reduction"],
            methodology_score=methodology_score
        )


def analyze_context_collapse_types(text: str) -> Dict[str, float]:
    """
    Analyze the four types of context collapse (from dbreuning.com):

    1. Context Poisoning - misinformation absorption
    2. Context Distraction - information overload
    3. Context Confusion - non-relevant data
    4. Context Clash - conflicting sources

    Args:
        text: Text content to analyze

    Returns:
        Dictionary with scores for each collapse type (0.0-1.0)
    """
    text_lower = text.lower()

    # Context Poisoning indicators
    poisoning_terms = ['misinformation', 'bias', 'incorrect', 'false', 'misleading', 'error']
    poisoning_score = sum(1 for term in poisoning_terms if term in text_lower) / len(poisoning_terms)

    # Context Distraction indicators
    distraction_terms = ['overwhelming', 'too much', 'information overload', 'complexity', 'extensive']
    distraction_score = sum(1 for term in distraction_terms if term in text_lower) / len(distraction_terms)

    # Context Confusion indicators
    confusion_terms = ['unclear', 'ambiguous', 'confusing', 'non-relevant', 'unrelated', 'mixed']
    confusion_score = sum(1 for term in confusion_terms if term in text_lower) / len(confusion_terms)

    # Context Clash indicators
    clash_terms = ['conflicting', 'contradictory', 'inconsistent', 'opposing', 'disagreement', 'conflict']
    clash_score = sum(1 for term in clash_terms if term in text_lower) / len(clash_terms)

    return {
        'poisoning': min(1.0, poisoning_score),
        'distraction': min(1.0, distraction_score),
        'confusion': min(1.0, confusion_score),
        'clash': min(1.0, clash_score)
    }


def extract_table_of_contents(text: str) -> List[Dict[str, str]]:
    """
    Extract table of contents from academic paper text.

    Args:
        text: Full paper text

    Returns:
        List of dictionaries with section headers and page numbers
    """
    toc_entries = []
    text_lines = text.split('\n')

    # Common academic paper section patterns
    section_patterns = [
        r'^(\d+\.?\s+)([A-Z][^.]*?)\.?\s*\.+\s*(\d+)$',  # 1. Introduction ........ 5
        r'^([A-Z][A-Z\s]+)\s*\.+\s*(\d+)$',              # INTRODUCTION ........ 5
        r'^(\d+\.?\d*\.?\s+)([A-Z][^.]*?)\.?\s*(\d+)$',  # 1.1 Background .... 7
        r'^([A-Z][a-z\s]+)\s+(\d+)$',                    # Introduction 5
        r'^(\d+\.?\s+)([A-Z][a-z\s]+)$',                 # 1. Introduction
    ]

    for line in text_lines:
        line = line.strip()
        if not line:
            continue

        for pattern in section_patterns:
            match = re.match(pattern, line)
            if match:
                groups = match.groups()
                if len(groups) == 3:
                    section_num, title, page = groups
                    toc_entries.append({
                        'section_number': section_num.strip(),
                        'title': title.strip(),
                        'page': page.strip()
                    })
                elif len(groups) == 2:
                    if groups[1].isdigit():  # Title and page
                        title, page = groups
                        toc_entries.append({
                            'section_number': '',
                            'title': title.strip(),
                            'page': page.strip()
                        })
                    else:  # Section number and title
                        section_num, title = groups
                        toc_entries.append({
                            'section_number': section_num.strip(),
                            'title': title.strip(),
                            'page': ''
                        })
                break

    # If no formal TOC found, extract section headers from content
    if not toc_entries:
        section_headers = [
            r'^#+\s+(.+)$',                    # Markdown headers
            r'^\d+\.?\s+([A-Z][^.]*?)\.?$',    # 1. Introduction
            r'^([A-Z][A-Z\s]{3,})$',           # ABSTRACT, INTRODUCTION
            r'^([A-Z][a-z\s]{3,}):?\s*$',      # Introduction:
        ]

        for line_num, line in enumerate(text_lines):
            line = line.strip()
            for pattern in section_headers:
                match = re.match(pattern, line)
                if match:
                    title = match.group(1).strip()
                    # Estimate page number based on line position
                    estimated_page = max(1, line_num // 50)  # ~50 lines per page

                    toc_entries.append({
                        'section_number': '',
                        'title': title,
                        'page': str(estimated_page)
                    })
                    break

    return toc_entries


def extract_bibliography(text: str) -> List[Dict[str, str]]:
    """
    Extract bibliography/references from academic paper text.

    Args:
        text: Full paper text

    Returns:
        List of dictionaries with citation information
    """
    references = []
    text_lines = text.split('\n')

    # Find references section
    ref_section_start = -1
    ref_patterns = [
        r'^references?\s*$',
        r'^bibliography\s*$',
        r'^works\s+cited\s*$',
        r'^literature\s+cited\s*$'
    ]

    for i, line in enumerate(text_lines):
        line_lower = line.strip().lower()
        for pattern in ref_patterns:
            if re.match(pattern, line_lower):
                ref_section_start = i
                break
        if ref_section_start != -1:
            break

    if ref_section_start == -1:
        return []  # No references section found

    # Extract references from references section
    citation_patterns = [
        r'^\[(\d+)\]\s+(.+)$',                           # [1] Author, Title, Journal
        r'^(\d+\.)\s+(.+)$',                             # 1. Author, Title, Journal
        r'^([A-Z][a-z]+,?\s+[A-Z]\.?\s*(?:[A-Z]\.?\s*)*)\s*\((\d{4})\)\.?\s*(.+)$',
        r'^(.+?)\s*\((\d{4})\)\.?\s*(.+)$',              # General author (year) pattern
    ]

    ref_number = 1
    for line in text_lines[ref_section_start+1:]:
        line = line.strip()
        if not line:
            continue

        # Stop if we hit another major section
        if re.match(r'^[A-Z][A-Z\s]+$', line) and len(line) > 3:
            break

        citation_found = False
        for pattern in citation_patterns:
            match = re.match(pattern, line)
            if match:
                groups = match.groups()

                if len(groups) == 2:  # Number and full citation
                    ref_num, full_citation = groups
                    references.append({
                        'number': ref_num.rstrip('.'),
                        'full_citation': full_citation.strip(),
                        'author': '',
                        'year': '',
                        'title': '',
                        'journal': ''
                    })
                elif len(groups) == 3:  # Author, year, title/journal
                    author, year, title_journal = groups
                    references.append({
                        'number': str(ref_number),
                        'full_citation': line,
                        'author': author.strip(),
                        'year': year.strip(),
                        'title': title_journal.strip()[:100],
                        'journal': ''
                    })

                citation_found = True
                ref_number += 1
                break

        # If no pattern matched but line looks like a reference
        if not citation_found and len(line) > 20 and ('.' in line or ',' in line):
            references.append({
                'number': str(ref_number),
                'full_citation': line,
                'author': '',
                'year': '',
                'title': line[:100],
                'journal': ''
            })
            ref_number += 1

    return references


def get_demo_papers() -> List[PaperAnalysis]:
    """Return demo papers with realistic varied decomposition scores."""
    framework = ResearchFramework()

    papers = [
        {
            "title": "Mathematical Decomposition of Signal and Noise in Context Engineering Systems",
            "authors": ["Dr. Sarah Chen", "Prof. Michael Torres", "Dr. Elena Kozlov"],
            "arxiv_id": "2024.12001",
            "abstract": "This paper presents a comprehensive mathematical framework for decomposing signal and noise in context engineering systems. We develop systematic methods for identifying relevant systematic content, superfluous marginally systematic information, and true noise components. Our robust mathematical approach validates the Y=R+S+N decomposition theory with rigorous proof and comprehensive validation across multiple domains."
        },
        {
            "title": "Survey of Background Literature in Information Theory Applications",
            "authors": ["John Smith", "Mary Johnson"],
            "arxiv_id": "2024.11045",
            "abstract": "This comprehensive survey provides extensive background information and literature review of information theory applications. The paper includes general discussion of historical context, related work across multiple disciplines, and broader implications for future research directions. While containing some relevant mathematical concepts, much content serves as introduction and acknowledgments."
        },
        {
            "title": "Multidimensional Stochastic Analysis with Heterogeneous Nonlinear Components",
            "authors": ["Complex Research Collective"],
            "arxiv_id": "2024.10234",
            "abstract": "Complex multidimensional analysis of heterogeneous stochastic systems with nonlinear dynamics. The methodology involves unclear mathematical formulations and ambiguous theoretical frameworks. Some equations contain formatting errors and incomplete derivations, making validation difficult."
        },
        {
            "title": "Context Collapse Prevention Through Systematic Decomposition",
            "authors": ["Dr. Alex Rivera", "Prof. Lisa Wang"],
            "arxiv_id": "2024.09876",
            "abstract": "Systematic approach to preventing context collapse in AI systems through mathematical decomposition. The paper presents validated methods for context engineering with robust signal separation techniques. Mathematical proofs demonstrate comprehensive noise reduction capabilities in systematic frameworks."
        }
    ]

    analyses = []
    for paper in papers:
        analysis = framework.create_paper_analysis(
            title=paper["title"],
            authors=paper["authors"],
            abstract=paper["abstract"],
            arxiv_id=paper["arxiv_id"]
        )
        analyses.append(analysis)

    return analyses


__all__ = [
    # Classes
    "PaperAnalysis",
    "ResearchFramework",
    # Functions
    "analyze_context_collapse_types",
    "extract_table_of_contents",
    "extract_bibliography",
    "get_demo_papers",
]
