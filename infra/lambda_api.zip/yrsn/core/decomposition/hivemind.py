"""
HiveMind Detection via S-Dominance Analysis

HiveMind refers to the convergence of model outputs toward:
- Common patterns and phrasings
- Loss of individual style/creativity
- Mode collapse in generation
- Derivative rather than novel outputs

This is essentially **over-learned S dominating generative R**.

YRSN Integration:
- HiveMind occurs when R (novel signal) decreases and S (learned patterns) increases
- Novel patterns get absorbed into S before reaching R

The S-Trap:
- Normal training: N -> S -> R (noise becomes learned, then signal)
- HiveMind: N -> S <- R (novel patterns absorbed into S before reaching R)

Usage:
    from yrsn.core.decomposition.hivemind import HiveMindDetector

    detector = HiveMindDetector()

    for output in generated_texts:
        r, s, n = decompose(output)
        patterns = extract_patterns(output)
        analysis = detector.analyze_generation(output, r, s, n, patterns)

        if analysis.is_hivemind:
            print("WARNING: HiveMind detected!")

    # Apply S-decay to prevent ossification
    demoted = detector.apply_s_decay(decay_rate=0.1)
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple, Any
import time


@dataclass
class HiveMindAnalysis:
    """
    Result of HiveMind detection analysis.

    HiveMind is the convergence of model outputs toward common patterns,
    loss of creativity, and mode collapse - essentially S-dominance with R-absorption.
    """
    hivemind_score: float          # Overall score (0-1, higher = more HiveMind)
    crystallization_rate: float    # Rate of Emergent->Learned transitions
    r_score: float                 # Current R-score of output
    s_score: float                 # Current S-score (learned patterns)
    novel_pattern_count: int       # Number of novel patterns detected
    absorbed_pattern_count: int    # Patterns absorbed into S

    def to_dict(self) -> Dict[str, Any]:
        return {
            'hivemind_score': self.hivemind_score,
            'crystallization_rate': self.crystallization_rate,
            'r_score': self.r_score,
            's_score': self.s_score,
            'novel_pattern_count': self.novel_pattern_count,
            'absorbed_pattern_count': self.absorbed_pattern_count,
        }

    @property
    def is_hivemind(self) -> bool:
        """True if HiveMind state detected."""
        return self.hivemind_score > 0.5

    @property
    def is_concerning(self) -> bool:
        """True if scores indicate concerning state."""
        return self.hivemind_score > 0.3


class HiveMindDetector:
    """
    Detects HiveMind convergence via S-dominance analysis.

    HiveMind refers to the convergence of model outputs toward:
    - Common patterns and phrasings
    - Loss of individual style/creativity
    - Mode collapse in generation
    - Derivative rather than novel outputs

    This is essentially **over-learned S dominating generative R**.

    Detection uses the Emergent tier to track pattern crystallization.
    """

    def __init__(
        self,
        crystallization_threshold: int = 5,
        hivemind_r_threshold: float = 0.3,
        hivemind_s_threshold: float = 0.5,
    ):
        """
        Initialize HiveMind detector.

        Args:
            crystallization_threshold: Times seen before pattern is "crystallized"
            hivemind_r_threshold: R-score below this is concerning
            hivemind_s_threshold: S-score above this indicates dominance
        """
        self.emergent_signals: Dict[str, Dict[str, Any]] = {}
        self.crystallization_threshold = crystallization_threshold
        self.hivemind_r_threshold = hivemind_r_threshold
        self.hivemind_s_threshold = hivemind_s_threshold
        self.crystallization_count = 0
        self.total_patterns_seen = 0

    def analyze_generation(
        self,
        output: str,
        r_score: float,
        s_score: float,
        n_score: float,
        detected_patterns: List[str],
    ) -> HiveMindAnalysis:
        """
        Analyze a generation for HiveMind indicators.

        Args:
            output: Generated text (for context)
            r_score: R-score from YRSN decomposition
            s_score: S-score from YRSN decomposition
            n_score: N-score from YRSN decomposition
            detected_patterns: Pattern identifiers found in output

        Returns:
            HiveMindAnalysis with detection result
        """
        novel_count = 0
        absorbed_count = 0

        for pattern in detected_patterns:
            self.total_patterns_seen += 1

            if pattern in self.emergent_signals:
                self.emergent_signals[pattern]['count'] += 1

                if self.emergent_signals[pattern]['count'] == self.crystallization_threshold:
                    self.crystallization_count += 1
                    absorbed_count += 1
            else:
                self.emergent_signals[pattern] = {
                    'count': 1,
                    'first_seen': time.time(),
                }
                novel_count += 1

        if self.total_patterns_seen > 0:
            crystallization_rate = self.crystallization_count / self.total_patterns_seen
        else:
            crystallization_rate = 0.0

        # HiveMind score: high crystallization + low R
        hivemind_score = crystallization_rate * (1 - r_score)

        return HiveMindAnalysis(
            hivemind_score=hivemind_score,
            crystallization_rate=crystallization_rate,
            r_score=r_score,
            s_score=s_score,
            novel_pattern_count=novel_count,
            absorbed_pattern_count=absorbed_count,
        )

    def apply_s_decay(self, decay_rate: float = 0.1) -> int:
        """
        Apply decay to tracked patterns to prevent ossification.

        Args:
            decay_rate: Fraction of count to decay (0.1 = 10%)

        Returns:
            Number of patterns demoted back to "unseen"
        """
        demoted = 0
        patterns_to_remove = []

        for pattern, info in self.emergent_signals.items():
            info['count'] = int(info['count'] * (1 - decay_rate))
            if info['count'] <= 0:
                patterns_to_remove.append(pattern)
                demoted += 1

        for pattern in patterns_to_remove:
            del self.emergent_signals[pattern]

        return demoted

    def get_top_crystallized_patterns(self, n: int = 10) -> List[Tuple[str, int]]:
        """Get the most frequently seen patterns."""
        sorted_patterns = sorted(
            self.emergent_signals.items(),
            key=lambda x: x[1]['count'],
            reverse=True,
        )
        return [(p, info['count']) for p, info in sorted_patterns[:n]]

    def reset(self):
        """Reset detector state."""
        self.emergent_signals.clear()
        self.crystallization_count = 0
        self.total_patterns_seen = 0

    def get_statistics(self) -> Dict[str, Any]:
        """Get detector statistics."""
        return {
            'total_patterns_tracked': len(self.emergent_signals),
            'total_patterns_seen': self.total_patterns_seen,
            'crystallization_count': self.crystallization_count,
            'crystallization_rate': (
                self.crystallization_count / self.total_patterns_seen
                if self.total_patterns_seen > 0 else 0.0
            ),
        }


__all__ = [
    'HiveMindAnalysis',
    'HiveMindDetector',
]
