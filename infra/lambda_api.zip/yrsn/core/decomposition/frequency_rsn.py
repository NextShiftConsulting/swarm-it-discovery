"""
Frequency-Based RSN Computation (Self-Supervised)

This module computes R/S/N signals directly from image frequency analysis.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.4: Decomposition and Invariant Enforcement
  - §7.4.2: Functional Requirements (input acceptance, component generation)
  - §7.4.3.3: Distributional Decomposition (frequency-based analysis)
  - §7.4.4: Normalization and Invariant Enforcement (simplex constraint)
  - §7.4.7: Training and Calibration (self-supervised, no labels)
- §7.3: Input Reception Module (image processing, informal implementation)

Key patent compliance features:
- No reliance on labeled ground truth (§7.4.7.1: self-supervised)
- R+S+N=1 simplex constraint enforced (§7.4.4.1)
- Semantic stability: R always means relevance (§7.4.2)

Relevant patent files:
- docs/specs/patent_spec_section_7_4_decomposition.md
- docs/specs/patent_spec_section_7_3_input_reception.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

┌────────────────────────────────────────────────────────────────────┐
│                       WHAT THIS DOES                                │
├────────────────────────────────────────────────────────────────────┤
│ Computes R/S/N from images using frequency decomposition:          │
│   • R (Relevant): Low-frequency content (object structure)         │
│   • S (Superfluous): Mid-frequency content (texture/details)       │
│   • N (Noise): High-frequency content (noise/artifacts)            │
│                                                                     │
│ NO TRAINING REQUIRED - Pure signal processing                      │
└────────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
- Compute R/S/N WITHOUT needing a trained projection
- Interpretable: frequency bands have clear meaning
- Fast: No neural network forward pass
- Self-supervised: No labels needed

HOW IT WORKS (Frequency Analysis):
---------------------------------
1. Convert image to grayscale
2. Apply Gaussian filters at different scales:
   - σ=3.0: Low-pass filter (smooth, keeps structure)
   - σ=1.0: Mid-pass filter (keeps details)
   - Original - σ=1.0: High-pass filter (keeps noise)

3. Compute energy in each frequency band:
   - Low-frequency energy → R (object structure is RELEVANT)
   - Mid-frequency energy → S (texture is SUPERFLUOUS)
   - High-frequency energy → N (noise is NOISE)

4. Normalize energies to sum to 1 → R/S/N values

WHEN TO USE:
-----------
✓ Quick prototyping without training
✓ Image quality assessment
✓ Interpretable RSN computation
✓ Baseline for comparison

WHEN NOT TO USE:
---------------
✗ Non-image data (text, audio, etc.)
✗ Need task-specific R/S/N (use trained projection)
✗ Domain where frequency ≠ relevance

USAGE EXAMPLES:
--------------

Example 1: Compute R/S/N from Single Image
>>> from yrsn.core.decomposition import FrequencyBasedRSN
>>> import numpy as np
>>> from PIL import Image
>>> 
>>> # Load image
>>> image = np.array(Image.open('photo.jpg'))
>>> 
>>> # Compute R/S/N
>>> rsn_computer = FrequencyBasedRSN()
>>> rsn = rsn_computer.compute_rsn(image)
>>> 
>>> print(f"R: {rsn['R']:.3f} (relevant structure)")
>>> print(f"S: {rsn['S']:.3f} (superfluous details)")
>>> print(f"N: {rsn['N']:.3f} (noise)")
>>> print(f"Alpha: {rsn['alpha']:.3f} (quality score)")

Example 2: Batch Processing
>>> images = [np.array(Image.open(p)) for p in image_paths]
>>> rsn_batch = rsn_computer.compute_rsn_batch(images)
>>> print(rsn_batch['R'].shape)  # [num_images]

Example 3: Quality-Aware Gating (No Training!)
>>> for image in images:
...     rsn = rsn_computer.compute_rsn(image)
...     if rsn['alpha'] >= 0.5:  # High quality
...         process_image(image)
...     else:
...         skip_image(image)  # Low quality, save compute

Example 4: Compare with Trained Projection
>>> # Frequency-based (no training)
>>> freq_rsn = FrequencyBasedRSN()
>>> freq_result = freq_rsn.compute_rsn(image)
>>> 
>>> # Trained projection (task-specific)
>>> from yrsn.core.decomposition import load_trained_projection
>>> proj = load_trained_projection('checkpoints/trained_rsn_cifar64.pt')
>>> features = model(image, return_features=True)
>>> proj_result = proj.compute_rsn(features.numpy())
>>> 
>>> # Compare
>>> print("Frequency-based alpha:", freq_result['alpha'])
>>> print("Projection-based alpha:", proj_result['alpha'])

IMPORTANT:
---------
This is COMPLEMENTARY to trained projections, not a replacement:
- Frequency-based: Universal, interpretable, no training
- Trained projection: Task-specific, more accurate for your domain
"""

import numpy as np
from scipy.ndimage import gaussian_filter
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class FrequencyBands:
    """
    Frequency band energies.
    
    Attributes:
        low: Low-frequency energy (object structure)
        mid: Mid-frequency energy (texture/details)
        high: High-frequency energy (noise/artifacts)
    """
    low: float
    mid: float
    high: float


class FrequencyBasedRSN:
    """
    Frequency-based RSN computation (self-supervised).
    
    CAPABILITIES:
    ------------
    ✓ Compute R/S/N from image frequency analysis
    ✓ No training required
    ✓ Batch processing support
    ✓ Interpretable frequency bands
    ✓ Quality score (alpha) computation
    
    CONFIGURATION:
    -------------
    low_sigma: float (default=3.0)
        Sigma for low-pass filter (larger = smoother)
        Controls what counts as "structure" (R)
        
    mid_sigma: float (default=1.0)
        Sigma for mid-pass filter
        Controls what counts as "details" (S)
        
    normalize_input: bool (default=True)
        Whether to normalize input images to [0, 1]
        
    FREQUENCY BAND MEANING:
    ----------------------
    - Low (R): Object boundaries, shapes, global structure
      Example: Edge of a car, outline of a person
      
    - Mid (S): Textures, patterns, local details
      Example: Fabric texture, grass patterns
      
    - High (N): Sensor noise, compression artifacts
      Example: JPEG artifacts, sensor grain
    
    METHODS:
    -------
    compute_rsn(image) -> Dict[str, float]
        Compute R/S/N from single image
        
    compute_rsn_batch(images) -> Dict[str, np.ndarray]
        Batch process multiple images
        
    extract_frequency_bands(image) -> FrequencyBands
        Get raw frequency band energies
        
    visualize_decomposition(image) -> Figure
        Show frequency decomposition visually
    """
    
    def __init__(
        self,
        low_sigma: float = 3.0,
        mid_sigma: float = 1.0,
        normalize_input: bool = True
    ):
        """
        Initialize frequency-based RSN computer.
        
        Args:
            low_sigma: Sigma for low-pass filter (structure)
            mid_sigma: Sigma for mid-pass filter (details)
            normalize_input: Normalize images to [0, 1]
        """
        self.low_sigma = low_sigma
        self.mid_sigma = mid_sigma
        self.normalize_input = normalize_input
        
    def _to_grayscale(self, image: np.ndarray) -> np.ndarray:
        """
        Convert image to grayscale.
        
        Handles multiple input formats:
        - (H, W): Already grayscale
        - (C, H, W): Channel-first RGB
        - (H, W, C): Channel-last RGB
        
        Args:
            image: Input image
            
        Returns:
            Grayscale image (H, W)
        """
        if image.ndim == 2:
            # Already grayscale
            return image
        elif image.ndim == 3:
            if image.shape[0] <= 4:
                # Assume (C, H, W)
                gray = np.mean(image, axis=0)
            else:
                # Assume (H, W, C)
                gray = np.mean(image, axis=2)
            return gray
        else:
            raise ValueError(f"Unsupported image shape: {image.shape}")
            
    def _normalize(self, image: np.ndarray) -> np.ndarray:
        """
        Normalize image to [0, 1].
        
        Args:
            image: Input image
            
        Returns:
            Normalized image
        """
        if self.normalize_input:
            min_val = image.min()
            max_val = image.max()
            if max_val > min_val:
                return (image - min_val) / (max_val - min_val)
            else:
                return image
        else:
            return image
            
    def extract_frequency_bands(self, image: np.ndarray) -> FrequencyBands:
        """
        Extract frequency band energies from image.
        
        FREQUENCY DECOMPOSITION:
        -----------------------
        1. Low-frequency: Gaussian filter with large sigma
           - Keeps smooth variations (object shapes)
           - Removes details and noise
           
        2. Mid-frequency: Difference of Gaussians
           - Bandpass filter for textures
           - Keeps local patterns
           
        3. High-frequency: Original - smoothed
           - Highpass filter for noise
           - Keeps rapid variations
        
        Args:
            image: Input image (any format)
            
        Returns:
            FrequencyBands with low/mid/high energies
            
        Example:
            >>> bands = rsn_computer.extract_frequency_bands(image)
            >>> print(f"Low: {bands.low:.2f}, Mid: {bands.mid:.2f}, High: {bands.high:.2f}")
        """
        # Convert to grayscale and normalize
        gray = self._to_grayscale(image)
        gray = self._normalize(gray)
        
        # Low-frequency: Gaussian smoothing (object structure)
        low_freq = gaussian_filter(gray, sigma=self.low_sigma)
        low_energy = np.sum(low_freq ** 2)
        
        # Mid-frequency: Difference of Gaussians (texture)
        mid_freq = gaussian_filter(gray, sigma=self.mid_sigma) - low_freq
        mid_energy = np.sum(mid_freq ** 2)
        
        # High-frequency: Original - smoothed (noise)
        high_freq = gray - gaussian_filter(gray, sigma=self.mid_sigma)
        high_energy = np.sum(high_freq ** 2)
        
        return FrequencyBands(
            low=float(low_energy),
            mid=float(mid_energy),
            high=float(high_energy)
        )
        
    def compute_rsn(self, image: np.ndarray) -> Dict[str, float]:
        """
        Compute R/S/N from image frequency analysis.
        
        MAPPING:
        -------
        Low-frequency energy → R (Relevant structure)
        Mid-frequency energy → S (Superfluous details)
        High-frequency energy → N (Noise)
        
        Alpha (quality) = R / (R + N)
        - High alpha: Clear structure, low noise
        - Low alpha: Noisy or unclear
        
        Args:
            image: Input image (H,W) or (C,H,W) or (H,W,C)
            
        Returns:
            Dict with:
            - 'R': Relevant component (0-1)
            - 'S': Superfluous component (0-1)
            - 'N': Noise component (0-1)
            - 'alpha': Quality score (0-1)
            - 'bands': Raw frequency band energies
            
        Example:
            >>> rsn = rsn_computer.compute_rsn(image)
            >>> if rsn['alpha'] >= 0.5:
            ...     print("High quality image")
            >>> else:
            ...     print("Low quality image")
        """
        # Extract frequency bands
        bands = self.extract_frequency_bands(image)
        
        # Normalize to R/S/N (sum to 1)
        total = bands.low + bands.mid + bands.high + 1e-8
        r = bands.low / total
        s = bands.mid / total
        n = bands.high / total
        
        # Compute alpha (quality score)
        alpha = r / (r + n + 1e-8)
        
        return {
            'R': float(r),
            'S': float(s),
            'N': float(n),
            'alpha': float(alpha),
            'bands': {
                'low': bands.low,
                'mid': bands.mid,
                'high': bands.high
            }
        }
        
    def compute_rsn_batch(self, images: List[np.ndarray]) -> Dict[str, np.ndarray]:
        """
        Batch compute R/S/N for multiple images.
        
        EFFICIENT PROCESSING:
        --------------------
        - Vectorized operations where possible
        - Reuses frequency filters
        - Returns numpy arrays for analysis
        
        Args:
            images: List of images (any format)
            
        Returns:
            Dict with:
            - 'R': Array of R values [num_images]
            - 'S': Array of S values [num_images]
            - 'N': Array of N values [num_images]
            - 'alpha': Array of alpha values [num_images]
            
        Example:
            >>> images = [load_image(p) for p in paths]
            >>> batch_rsn = rsn_computer.compute_rsn_batch(images)
            >>> print(f"Mean alpha: {batch_rsn['alpha'].mean():.3f}")
            >>> print(f"Low quality: {(batch_rsn['alpha'] < 0.5).sum()} images")
        """
        r_values = []
        s_values = []
        n_values = []
        alpha_values = []
        
        for image in images:
            rsn = self.compute_rsn(image)
            r_values.append(rsn['R'])
            s_values.append(rsn['S'])
            n_values.append(rsn['N'])
            alpha_values.append(rsn['alpha'])
            
        return {
            'R': np.array(r_values),
            'S': np.array(s_values),
            'N': np.array(n_values),
            'alpha': np.array(alpha_values)
        }
        
    def visualize_decomposition(
        self,
        image: np.ndarray,
        save_path: Optional[str] = None
    ):
        """
        Visualize frequency decomposition.
        
        WHAT THIS SHOWS:
        ---------------
        4-panel figure:
        1. Original image
        2. Low-frequency (R - structure)
        3. Mid-frequency (S - details)
        4. High-frequency (N - noise)
        
        Args:
            image: Input image
            save_path: Where to save figure (if None, just show)
            
        Example:
            >>> rsn_computer.visualize_decomposition(
            ...     image,
            ...     save_path='frequency_decomposition.png'
            ... )
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib required for visualization")
            
        # Convert to grayscale
        gray = self._to_grayscale(image)
        gray = self._normalize(gray)
        
        # Compute frequency bands
        low_freq = gaussian_filter(gray, sigma=self.low_sigma)
        mid_freq = gaussian_filter(gray, sigma=self.mid_sigma) - low_freq
        high_freq = gray - gaussian_filter(gray, sigma=self.mid_sigma)
        
        # Compute R/S/N
        rsn = self.compute_rsn(image)
        
        # Create figure
        fig, axes = plt.subplots(2, 2, figsize=(10, 10))
        
        # Original
        axes[0, 0].imshow(gray, cmap='gray')
        axes[0, 0].set_title('Original', fontsize=12, fontweight='bold')
        axes[0, 0].axis('off')
        
        # Low-frequency (R)
        axes[0, 1].imshow(low_freq, cmap='gray')
        axes[0, 1].set_title(f'Low-Freq (R={rsn["R"]:.2f})\nObject Structure',
                            fontsize=12, fontweight='bold')
        axes[0, 1].axis('off')
        
        # Mid-frequency (S)
        axes[1, 0].imshow(mid_freq, cmap='gray')
        axes[1, 0].set_title(f'Mid-Freq (S={rsn["S"]:.2f})\nTexture/Details',
                            fontsize=12, fontweight='bold')
        axes[1, 0].axis('off')
        
        # High-frequency (N)
        axes[1, 1].imshow(high_freq, cmap='gray')
        axes[1, 1].set_title(f'High-Freq (N={rsn["N"]:.2f})\nNoise/Artifacts',
                            fontsize=12, fontweight='bold')
        axes[1, 1].axis('off')
        
        plt.suptitle(f'Frequency Decomposition (Alpha={rsn["alpha"]:.3f})',
                    fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
        else:
            plt.show()


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'FrequencyBasedRSN',
    'FrequencyBands',
]
