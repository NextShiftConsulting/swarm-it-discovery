"""
Robotics utilities for collapse detection - minimal implementation.
Phase 4: Robotics Pack support.
"""
import numpy as np
from typing import Optional, List, Tuple


def compute_sensor_fusion_confidence(
    sensor_readings: List[np.ndarray],
    fusion_weights: Optional[List[float]] = None
) -> float:
    """
    Compute sensor fusion confidence (agreement across sensors).
    
    Minimal implementation: uses variance across sensors as proxy.
    
    Parameters
    ----------
    sensor_readings : list of np.ndarray
        Readings from multiple sensors
    fusion_weights : list of float, optional
        Weights for each sensor
    
    Returns
    -------
    float
        Fusion confidence [0, 1] (1.0 = perfect agreement)
    """
    if len(sensor_readings) < 2:
        return 1.0
    
    # Compute variance across sensors
    stacked = np.stack(sensor_readings)
    variance = np.var(stacked, axis=0).mean()
    
    # Convert variance to confidence (inverse relationship)
    confidence = 1.0 / (1.0 + variance)
    return float(min(1.0, max(0.0, confidence)))


def compute_slam_confidence(
    pose_estimates: List[np.ndarray],
    loop_closure_detected: bool = False
) -> float:
    """
    Compute SLAM system confidence.
    
    Minimal implementation: uses pose consistency as proxy.
    
    Parameters
    ----------
    pose_estimates : list of np.ndarray
        Pose estimates over time
    loop_closure_detected : bool
        Whether loop closure was detected
    
    Returns
    -------
    float
        SLAM confidence [0, 1]
    """
    if len(pose_estimates) < 2:
        return 0.5  # Default confidence
    
    # Compute pose consistency (variance)
    stacked = np.stack(pose_estimates)
    variance = np.var(stacked, axis=0).mean()
    
    # Lower variance = higher confidence
    confidence = 1.0 / (1.0 + variance)
    
    # Boost if loop closure detected
    if loop_closure_detected:
        confidence = min(1.0, confidence * 1.2)
    
    return float(min(1.0, max(0.0, confidence)))


def compute_dynamic_obstacle_detection_confidence(
    obstacle_tracks: List[np.ndarray],
    tracking_consistency: float = 1.0
) -> float:
    """
    Compute dynamic obstacle detection confidence.
    
    Minimal implementation: uses tracking consistency as proxy.
    
    Parameters
    ----------
    obstacle_tracks : list of np.ndarray
        Obstacle track positions over time
    tracking_consistency : float
        Tracking consistency score [0, 1]
    
    Returns
    -------
    float
        Detection confidence [0, 1]
    """
    if len(obstacle_tracks) < 2:
        return 0.5  # Default confidence
    
    # Use tracking consistency directly
    return float(min(1.0, max(0.0, tracking_consistency)))


def compute_realtime_performance(
    latency_ms: float,
    frame_rate: float,
    target_latency_ms: float = 100.0,
    target_frame_rate: float = 30.0
) -> float:
    """
    Compute real-time performance score.
    
    Parameters
    ----------
    latency_ms : float
        Processing latency in milliseconds
    frame_rate : float
        Frame rate in FPS
    target_latency_ms : float
        Target latency (default 100ms)
    target_frame_rate : float
        Target frame rate (default 30 FPS)
    
    Returns
    -------
    float
        Performance score [0, 1] (1.0 = meets targets)
    """
    # Normalize latency (lower is better)
    latency_score = 1.0 / (1.0 + (latency_ms / target_latency_ms))
    
    # Normalize frame rate (higher is better)
    frame_rate_score = min(1.0, frame_rate / target_frame_rate)
    
    # Combined score
    performance = (latency_score + frame_rate_score) / 2.0
    return float(min(1.0, max(0.0, performance)))


def compute_manipulation_success_probability(
    grasp_confidence: float,
    object_stability: float,
    collision_risk: float
) -> float:
    """
    Compute manipulation success probability.
    
    Parameters
    ----------
    grasp_confidence : float
        Grasp confidence [0, 1]
    object_stability : float
        Object stability [0, 1]
    collision_risk : float
        Collision risk [0, 1] (inverse of safety)
    
    Returns
    -------
    float
        Success probability [0, 1]
    """
    # Success = high grasp confidence + high stability + low collision risk
    success = (grasp_confidence + object_stability + (1.0 - collision_risk)) / 3.0
    return float(min(1.0, max(0.0, success)))


def compute_path_planning_feasibility(
    path_length: float,
    obstacle_density: float,
    path_complexity: float
) -> float:
    """
    Compute path planning feasibility.
    
    Parameters
    ----------
    path_length : float
        Path length (normalized)
    obstacle_density : float
        Obstacle density [0, 1]
    path_complexity : float
        Path complexity [0, 1]
    
    Returns
    -------
    float
        Feasibility score [0, 1] (1.0 = highly feasible)
    """
    # Feasibility = low length + low density + low complexity
    feasibility = (1.0 - path_length) + (1.0 - obstacle_density) + (1.0 - path_complexity)
    feasibility = feasibility / 3.0
    return float(min(1.0, max(0.0, feasibility)))


def compute_control_system_stability(
    tracking_error: float,
    actuator_saturation: float,
    system_delay: float
) -> float:
    """
    Compute control system stability.
    
    Parameters
    ----------
    tracking_error : float
        Tracking error [0, 1]
    actuator_saturation : float
        Actuator saturation [0, 1]
    system_delay : float
        System delay [0, 1] (normalized)
    
    Returns
    -------
    float
        Stability score [0, 1] (1.0 = highly stable)
    """
    # Stability = low error + low saturation + low delay
    stability = (1.0 - tracking_error) + (1.0 - actuator_saturation) + (1.0 - system_delay)
    stability = stability / 3.0
    return float(min(1.0, max(0.0, stability)))

