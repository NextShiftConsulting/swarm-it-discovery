"""
Frequency-Based Omega Computation (Self-Supervised)

This module computes omega (reliability) signals directly from image frequency analysis,
enabling a TRUE pre-task 6D tuple WITHOUT any model inference.

┌────────────────────────────────────────────────────────────────────┐
│                    FREQUENCY-BASED 6D TUPLE                         │
├────────────────────────────────────────────────────────────────────┤
│ All 6 signals computed from RAW IMAGES - NO MODEL NEEDED:          │
│   • R (Relevant): Low-frequency content (object structure)         │
│   • S (Superfluous): Mid-frequency content (texture/details)       │
│   • N (Noise): High-frequency content (noise/artifacts)            │
│   • alpha: R/(R+N) - quality score                                 │
│   • omega: 7 frequency-based reliability signals                   │
│   • tau: Frequency-based calibrated temperature                    │
│                                                                     │
│ ENABLES TRUE PRE-TASK GATING - gate BEFORE any neural network      │
└────────────────────────────────────────────────────────────────────┘

SIGNAL MAPPING (Model-Based → Frequency-Based):
----------------------------------------------
| # | Model-Based Signal      | Frequency-Based Equivalent           |
|---|-------------------------|--------------------------------------|
| 1 | SDM confidence          | Frequency pattern match confidence   |
| 2 | Hopfield confidence     | Frequency template recall            |
| 3 | Replay similarity       | Historical frequency similarity      |
| 4 | Consistency             | Frequency-alpha variance             |
| 5 | Trend                   | Quality trend (improving/degrading)  |
| 6 | Decision stability      | Gate decision stability              |
| 7 | Hidden coherence        | Frequency band coherence             |

USAGE:
------
>>> from yrsn.core.decomposition import FrequencyBasedRSN, FrequencyBasedOmega
>>>
>>> # Initialize
>>> freq_rsn = FrequencyBasedRSN()
>>> freq_omega = FrequencyBasedOmega()
>>>
>>> # Process images (TRUE pre-task - no model)
>>> for image in images:
...     rsn = freq_rsn.compute_rsn(image)
...     omega, tau = freq_omega.compute_omega(image, rsn)
...
...     # Full 6D tuple - no model inference!
...     certificate = {
...         'R': rsn['R'], 'S': rsn['S'], 'N': rsn['N'],
...         'alpha': rsn['alpha'],
...         'omega': omega,
...         'tau': tau
...     }
...
...     # Gate decision BEFORE any model
...     if certificate['alpha'] >= 0.5 and certificate['omega'] >= 0.4:
...         prediction = model(image)  # Only run model if passed
...     else:
...         skip_image(image)  # Save compute
"""

import numpy as np
from scipy.ndimage import gaussian_filter
from collections import deque
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field

from .frequency_rsn import FrequencyBasedRSN


@dataclass
class FrequencySignals:
    """
    7 frequency-based reliability signals.

    These mirror the model-based signals but use frequency analysis only.
    """
    pattern_confidence: float      # Signal 1: Frequency pattern match
    template_recall: float         # Signal 2: Template similarity
    historical_similarity: float   # Signal 3: Similarity to history
    consistency: float             # Signal 4: Alpha variance (low = good)
    trend: float                   # Signal 5: Quality trend
    gate_stability: float          # Signal 6: Gate decision stability
    band_coherence: float          # Signal 7: Frequency band coherence

    def to_dict(self) -> Dict[str, float]:
        return {
            'pattern_confidence': self.pattern_confidence,
            'template_recall': self.template_recall,
            'historical_similarity': self.historical_similarity,
            'consistency': self.consistency,
            'trend': self.trend,
            'gate_stability': self.gate_stability,
            'band_coherence': self.band_coherence,
        }

    def mean(self) -> float:
        """Compute mean omega from all 7 signals."""
        values = [
            self.pattern_confidence,
            self.template_recall,
            self.historical_similarity,
            self.consistency,
            self.trend,
            self.gate_stability,
            self.band_coherence,
        ]
        return float(np.mean(values))


class FrequencyBasedOmega:
    """
    Frequency-based omega computation for TRUE pre-task 6D tuple.

    CAPABILITIES:
    ------------
    ✓ Compute 7 reliability signals from frequency analysis
    ✓ No model forward pass required
    ✓ Track quality history for temporal signals
    ✓ Compute calibrated temperature (tau)
    ✓ Enable TRUE pre-task gating with full 6D tuple

    CONFIGURATION:
    -------------
    window_size: int (default=50)
        History window for temporal signals

    n_templates: int (default=10)
        Number of frequency templates to store

    gate_threshold: float (default=0.5)
        Threshold for gate decision stability
    """

    def __init__(
        self,
        window_size: int = 50,
        n_templates: int = 10,
        gate_threshold: float = 0.5,
    ):
        self.window_size = window_size
        self.n_templates = n_templates
        self.gate_threshold = gate_threshold

        # History buffers
        self._alpha_history: deque = deque(maxlen=window_size)
        self._rsn_history: deque = deque(maxlen=window_size)
        self._gate_history: deque = deque(maxlen=window_size)
        self._band_history: deque = deque(maxlen=window_size)

        # Frequency templates (learned from "good" images)
        self._templates: List[Dict[str, float]] = []

        # RSN computer
        self._rsn_computer = FrequencyBasedRSN()

    def compute_omega(
        self,
        image: np.ndarray,
        rsn: Optional[Dict[str, float]] = None,
    ) -> Tuple[float, float]:
        """
        Compute frequency-based omega and tau.

        Args:
            image: Raw image (H,W) or (C,H,W) or (H,W,C)
            rsn: Pre-computed RSN dict (optional, computed if not provided)

        Returns:
            Tuple of (omega, tau):
            - omega: Mean of 7 frequency-based reliability signals [0,1]
            - tau: Calibrated temperature based on quality history
        """
        # Compute RSN if not provided
        if rsn is None:
            rsn = self._rsn_computer.compute_rsn(image)

        # Compute all 7 signals
        signals = self.compute_signals(image, rsn)

        # Compute omega as mean of signals
        omega = signals.mean()

        # Compute tau from history
        tau = self._compute_tau()

        # Update history
        self._update_history(rsn, signals)

        return omega, tau

    def compute_signals(
        self,
        image: np.ndarray,
        rsn: Dict[str, float],
    ) -> FrequencySignals:
        """
        Compute all 7 frequency-based reliability signals.

        Args:
            image: Raw image
            rsn: RSN dict with R, S, N, alpha, bands

        Returns:
            FrequencySignals with all 7 values
        """
        alpha = rsn['alpha']
        bands = rsn.get('bands', {'low': 0.33, 'mid': 0.33, 'high': 0.34})

        # Signal 1: Pattern confidence
        # How well does this image's frequency pattern match known good patterns?
        pattern_confidence = self._compute_pattern_confidence(rsn)

        # Signal 2: Template recall
        # Similarity to stored frequency templates
        template_recall = self._compute_template_recall(rsn)

        # Signal 3: Historical similarity
        # How similar is this RSN to recent history?
        historical_similarity = self._compute_historical_similarity(rsn)

        # Signal 4: Consistency
        # Low variance in alpha history = high consistency
        consistency = self._compute_consistency()

        # Signal 5: Trend
        # Is quality improving or degrading?
        trend = self._compute_trend()

        # Signal 6: Gate stability
        # Would the gate decision be stable across recent images?
        gate_stability = self._compute_gate_stability(alpha)

        # Signal 7: Band coherence
        # Are frequency bands internally coherent?
        band_coherence = self._compute_band_coherence(bands)

        return FrequencySignals(
            pattern_confidence=pattern_confidence,
            template_recall=template_recall,
            historical_similarity=historical_similarity,
            consistency=consistency,
            trend=trend,
            gate_stability=gate_stability,
            band_coherence=band_coherence,
        )

    def compute_6d_tuple(
        self,
        image: np.ndarray,
    ) -> Dict[str, float]:
        """
        Compute complete 6D tuple from raw image.

        NO MODEL INFERENCE REQUIRED.

        Args:
            image: Raw image

        Returns:
            Dict with R, S, N, alpha, omega, tau
        """
        # Compute RSN
        rsn = self._rsn_computer.compute_rsn(image)

        # Compute omega and tau
        omega, tau = self.compute_omega(image, rsn)

        return {
            'R': rsn['R'],
            'S': rsn['S'],
            'N': rsn['N'],
            'alpha': rsn['alpha'],
            'omega': omega,
            'tau': tau,
        }

    def add_template(self, rsn: Dict[str, float]):
        """
        Add a frequency template (from a "good" image).

        Call this during setup with known high-quality images
        to establish baseline frequency patterns.
        """
        if len(self._templates) < self.n_templates:
            self._templates.append({
                'R': rsn['R'],
                'S': rsn['S'],
                'N': rsn['N'],
                'alpha': rsn['alpha'],
            })
        else:
            # Replace worst template
            worst_idx = min(range(len(self._templates)),
                          key=lambda i: self._templates[i]['alpha'])
            if rsn['alpha'] > self._templates[worst_idx]['alpha']:
                self._templates[worst_idx] = {
                    'R': rsn['R'],
                    'S': rsn['S'],
                    'N': rsn['N'],
                    'alpha': rsn['alpha'],
                }

    # =========================================================================
    # Signal Computation Methods
    # =========================================================================

    def _compute_pattern_confidence(self, rsn: Dict[str, float]) -> float:
        """
        Signal 1: Pattern confidence.

        High R, low N indicates a "good" frequency pattern.
        """
        R, N = rsn['R'], rsn['N']
        # Confidence is high when R dominates and N is low
        confidence = R * (1 - N)
        return float(np.clip(confidence, 0, 1))

    def _compute_template_recall(self, rsn: Dict[str, float]) -> float:
        """
        Signal 2: Template recall.

        Similarity to stored "good" frequency templates.
        """
        if not self._templates:
            return 0.5  # No templates yet

        # Compute similarity to each template
        similarities = []
        for template in self._templates:
            dist = np.sqrt(
                (rsn['R'] - template['R'])**2 +
                (rsn['S'] - template['S'])**2 +
                (rsn['N'] - template['N'])**2
            )
            # Convert distance to similarity (max dist on simplex is sqrt(2))
            sim = 1 - dist / np.sqrt(2)
            similarities.append(sim)

        # Return max similarity
        return float(np.max(similarities))

    def _compute_historical_similarity(self, rsn: Dict[str, float]) -> float:
        """
        Signal 3: Historical similarity.

        How similar is this RSN to recent history?
        """
        if not self._rsn_history:
            return 0.5  # No history yet

        # Compute similarity to recent RSN values
        recent = list(self._rsn_history)[-5:]  # Last 5
        similarities = []
        for hist in recent:
            dist = np.sqrt(
                (rsn['R'] - hist['R'])**2 +
                (rsn['S'] - hist['S'])**2 +
                (rsn['N'] - hist['N'])**2
            )
            sim = 1 - dist / np.sqrt(2)
            similarities.append(sim)

        return float(np.mean(similarities))

    def _compute_consistency(self) -> float:
        """
        Signal 4: Consistency.

        Low variance in alpha history = high consistency.
        """
        if len(self._alpha_history) < 2:
            return 0.5  # Not enough history

        alpha_list = list(self._alpha_history)
        variance = np.var(alpha_list)
        # Convert variance to consistency (low variance = high consistency)
        # Variance is typically 0-0.25 for values in [0,1]
        consistency = 1 - np.clip(variance * 4, 0, 1)
        return float(consistency)

    def _compute_trend(self) -> float:
        """
        Signal 5: Trend.

        Positive/stable trend = high value.
        Negative trend = low value.
        """
        if len(self._alpha_history) < 3:
            return 0.5  # Not enough history

        alpha_list = list(self._alpha_history)[-10:]  # Last 10
        if len(alpha_list) < 3:
            return 0.5

        # Compute slope using linear regression
        x = np.arange(len(alpha_list))
        slope = np.polyfit(x, alpha_list, 1)[0]

        # Convert slope to trend value
        # Positive slope = improving = high value
        # Negative slope = degrading = low value
        trend = 0.5 + slope * 5  # Scale slope
        return float(np.clip(trend, 0, 1))

    def _compute_gate_stability(self, alpha: float) -> float:
        """
        Signal 6: Gate decision stability.

        Would the gate decision be consistent across recent images?
        """
        # Current gate decision
        current_gate = alpha >= self.gate_threshold

        if not self._gate_history:
            self._gate_history.append(current_gate)
            return 0.5

        # Check how often gate decision matches recent history
        recent = list(self._gate_history)[-10:]
        matches = sum(1 for g in recent if g == current_gate)
        stability = matches / len(recent)

        self._gate_history.append(current_gate)
        return float(stability)

    def _compute_band_coherence(self, bands: Dict[str, float]) -> float:
        """
        Signal 7: Frequency band coherence.

        Measures if frequency bands are internally consistent.
        """
        low = bands.get('low', 0.33)
        mid = bands.get('mid', 0.33)
        high = bands.get('high', 0.34)

        if not self._band_history:
            self._band_history.append((low, mid, high))
            return 0.5

        # Compute coherence with recent band distributions
        recent = list(self._band_history)[-5:]
        coherences = []
        for prev_low, prev_mid, prev_high in recent:
            # Cosine similarity of band distributions
            vec1 = np.array([low, mid, high])
            vec2 = np.array([prev_low, prev_mid, prev_high])
            cos_sim = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2) + 1e-8)
            coherences.append(cos_sim)

        self._band_history.append((low, mid, high))
        return float(np.mean(coherences))

    def _compute_tau(self) -> float:
        """
        Compute calibrated temperature from quality history.

        High quality history → low tau (confident)
        Low/variable quality → high tau (uncertain)
        """
        if len(self._alpha_history) < 5:
            return 1.0  # Default temperature

        alpha_list = list(self._alpha_history)
        mean_alpha = np.mean(alpha_list)
        std_alpha = np.std(alpha_list)

        # Tau is inverse of mean quality, scaled by variance
        # High quality + low variance → low tau
        # Low quality + high variance → high tau
        tau = (1 - mean_alpha) + std_alpha
        tau = 0.5 + tau  # Shift to [0.5, 1.5+]

        return float(np.clip(tau, 0.1, 3.0))

    def _update_history(self, rsn: Dict[str, float], signals: FrequencySignals):
        """Update history buffers."""
        self._alpha_history.append(rsn['alpha'])
        self._rsn_history.append({
            'R': rsn['R'],
            'S': rsn['S'],
            'N': rsn['N'],
        })

    def reset(self):
        """Reset all history buffers."""
        self._alpha_history.clear()
        self._rsn_history.clear()
        self._gate_history.clear()
        self._band_history.clear()
        self._templates.clear()


# =============================================================================
# Convenience Function
# =============================================================================

def compute_frequency_6d(
    image: np.ndarray,
    omega_computer: Optional[FrequencyBasedOmega] = None,
) -> Dict[str, float]:
    """
    Compute full 6D tuple from raw image without any model.

    This is the main entry point for TRUE pre-task 6D computation.

    Args:
        image: Raw image (any format)
        omega_computer: Optional FrequencyBasedOmega instance (created if None)

    Returns:
        Dict with R, S, N, alpha, omega, tau

    Example:
        >>> cert = compute_frequency_6d(image)
        >>> if cert['alpha'] >= 0.5 and cert['omega'] >= 0.4:
        ...     model(image)  # Only run model if quality passes
    """
    if omega_computer is None:
        omega_computer = FrequencyBasedOmega()

    return omega_computer.compute_6d_tuple(image)


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'FrequencyBasedOmega',
    'FrequencySignals',
    'compute_frequency_6d',
]
