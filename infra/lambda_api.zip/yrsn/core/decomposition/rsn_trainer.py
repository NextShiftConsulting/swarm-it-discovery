"""
R/S/N Projection Head Trainer

This module provides the training loop for learning discriminative
R/S/N projection heads using:
1. Supervised training with explicit R/S/N labels
2. Weak supervision from downstream outcomes
3. Self-supervised contrastive learning
4. Hybrid approaches combining all three

Based on research synthesis:
- Curriculum learning principles
- Multi-task learning
- Online learning integration
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Union, Callable
from enum import Enum
import time
import json
from pathlib import Path
import numpy as np

from .triplet_loss import YRSNTripletLoss, YRSNContrastiveLoss, YRSNOrthogonalityLoss, YRSNCombinedLoss
from .supervised_heads import LearnedYRSNProjectionHeads, ProjectionHeadConfig
from .outcome_supervision import OutcomeBasedSupervision, RewardSignalCollector


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class RSNTrainingConfig:
    """Configuration for R/S/N projection head training."""

    # Loss weights
    triplet_weight: float = 1.0
    contrastive_weight: float = 0.5
    orthogonality_weight: float = 0.1
    classification_weight: float = 0.3

    # Triplet loss params
    triplet_margin: float = 0.5
    mining_strategy: str = "semi_hard"
    distance_fn: str = "cosine"

    # Contrastive loss params
    temperature: float = 0.07
    use_contrastive: bool = False  # Use contrastive instead of triplet

    # Training params
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    warmup_steps: int = 1000
    max_steps: int = 50000
    batch_size: int = 64
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0

    # Weak supervision
    use_outcome_supervision: bool = True
    outcome_weight: float = 0.2
    pseudo_label_threshold: float = 0.8
    min_confidence: float = 0.5

    # Evaluation
    eval_every: int = 500
    save_every: int = 2000
    log_every: int = 100

    # Early stopping
    patience: int = 10
    min_delta: float = 1e-4

    # Checkpoint
    checkpoint_dir: str = "./checkpoints"
    save_best_only: bool = True


class TrainingState(Enum):
    """Training state machine states."""
    INITIALIZED = "initialized"
    TRAINING = "training"
    EVALUATING = "evaluating"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


# =============================================================================
# Training Metrics
# =============================================================================

@dataclass
class TrainingMetrics:
    """Container for training metrics."""
    step: int = 0
    epoch: int = 0
    total_loss: float = 0.0
    triplet_loss: float = 0.0
    contrastive_loss: float = 0.0
    orthogonality_loss: float = 0.0
    classification_loss: float = 0.0
    weak_supervision_loss: float = 0.0
    learning_rate: float = 0.0
    grad_norm: float = 0.0
    num_triplets: int = 0
    num_valid_triplets: int = 0
    separation_ratio: float = 0.0
    classification_accuracy: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'step': self.step,
            'epoch': self.epoch,
            'total_loss': self.total_loss,
            'triplet_loss': self.triplet_loss,
            'contrastive_loss': self.contrastive_loss,
            'orthogonality_loss': self.orthogonality_loss,
            'classification_loss': self.classification_loss,
            'weak_supervision_loss': self.weak_supervision_loss,
            'learning_rate': self.learning_rate,
            'grad_norm': self.grad_norm,
            'num_triplets': self.num_triplets,
            'num_valid_triplets': self.num_valid_triplets,
            'separation_ratio': self.separation_ratio,
            'classification_accuracy': self.classification_accuracy,
            'timestamp': self.timestamp,
        }


@dataclass
class EvaluationMetrics:
    """Container for evaluation metrics."""
    step: int = 0
    loss: float = 0.0
    accuracy: float = 0.0
    precision: Dict[str, float] = field(default_factory=dict)
    recall: Dict[str, float] = field(default_factory=dict)
    f1: Dict[str, float] = field(default_factory=dict)
    separation_score: float = 0.0
    orthogonality_score: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'step': self.step,
            'loss': self.loss,
            'accuracy': self.accuracy,
            'precision': self.precision,
            'recall': self.recall,
            'f1': self.f1,
            'separation_score': self.separation_score,
            'orthogonality_score': self.orthogonality_score,
            'timestamp': self.timestamp,
        }


# =============================================================================
# Learning Rate Scheduler
# =============================================================================

def create_scheduler(
    optimizer: torch.optim.Optimizer,
    warmup_steps: int,
    max_steps: int,
    schedule_type: str = "cosine",
) -> torch.optim.lr_scheduler._LRScheduler:
    """Create learning rate scheduler with warmup."""

    def lr_lambda(current_step: int) -> float:
        if current_step < warmup_steps:
            # Linear warmup
            return float(current_step) / float(max(1, warmup_steps))

        # After warmup
        progress = float(current_step - warmup_steps) / float(max(1, max_steps - warmup_steps))

        if schedule_type == "cosine":
            return max(0.0, 0.5 * (1.0 + np.cos(np.pi * progress)))
        elif schedule_type == "linear":
            return max(0.0, 1.0 - progress)
        else:
            return 1.0

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# =============================================================================
# RSN Dataset
# =============================================================================

class RSNDataset(Dataset):
    """Dataset for R/S/N training."""

    def __init__(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        weights: Optional[torch.Tensor] = None,
    ):
        self.embeddings = embeddings
        self.labels = labels
        self.weights = weights if weights is not None else torch.ones(len(labels))

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return self.embeddings[idx], self.labels[idx], self.weights[idx]


# =============================================================================
# RSN Trainer
# =============================================================================

class RSNProjectionTrainer:
    """
    Training loop for R/S/N projection heads.

    Supports:
    1. Supervised training with explicit R/S/N labels
    2. Weak supervision from downstream outcomes
    3. Self-supervised contrastive learning
    4. Hybrid approaches combining all three
    """

    def __init__(
        self,
        projection_heads: LearnedYRSNProjectionHeads,
        config: RSNTrainingConfig,
        device: Optional[torch.device] = None,
    ):
        self.heads = projection_heads
        self.config = config
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.heads.to(self.device)

        # Initialize losses
        if config.use_contrastive:
            self.separation_loss = YRSNContrastiveLoss(
                temperature=config.temperature,
            )
        else:
            self.separation_loss = YRSNTripletLoss(
                margin=config.triplet_margin,
                distance_fn=config.distance_fn,
                mining_strategy=config.mining_strategy,
            )

        self.orthogonality_loss = YRSNOrthogonalityLoss()
        self.classification_loss = nn.CrossEntropyLoss()

        # Combined loss
        self.combined_loss = YRSNCombinedLoss(
            triplet_weight=config.triplet_weight,
            orthogonality_weight=config.orthogonality_weight,
            classification_weight=config.classification_weight,
            use_contrastive=config.use_contrastive,
            triplet_margin=config.triplet_margin,
            temperature=config.temperature,
        )

        # Weak supervision components
        self.outcome_supervisor = OutcomeBasedSupervision()
        self.reward_collector = RewardSignalCollector()

        # Optimizer and scheduler
        self.optimizer = torch.optim.AdamW(
            projection_heads.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )
        self.scheduler = create_scheduler(
            self.optimizer,
            config.warmup_steps,
            config.max_steps,
        )

        # Training state
        self.state = TrainingState.INITIALIZED
        self.global_step = 0
        self.epoch = 0
        self.best_loss = float('inf')
        self.patience_counter = 0

        # Metrics history
        self.training_history: List[TrainingMetrics] = []
        self.evaluation_history: List[EvaluationMetrics] = []

        # Checkpoint directory
        self.checkpoint_dir = Path(config.checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def train_step(
        self,
        embeddings: torch.Tensor,
        rsn_labels: Optional[torch.Tensor] = None,
        sample_weights: Optional[torch.Tensor] = None,
        task_outcomes: Optional[Dict] = None,
    ) -> TrainingMetrics:
        """
        Single training step.

        Args:
            embeddings: [B, D] hidden states
            rsn_labels: [B] explicit labels (if available)
            sample_weights: [B] sample weights for weighted loss
            task_outcomes: Downstream task results for weak supervision

        Returns:
            TrainingMetrics with loss components and metrics
        """
        self.heads.train()
        self.optimizer.zero_grad()

        embeddings = embeddings.to(self.device)
        if rsn_labels is not None:
            rsn_labels = rsn_labels.to(self.device)
        if sample_weights is not None:
            sample_weights = sample_weights.to(self.device)

        metrics = TrainingMetrics(step=self.global_step, epoch=self.epoch)
        total_loss = torch.tensor(0.0, device=self.device)

        # Forward pass
        output = self.heads(embeddings, return_classification=True)

        # Get mean projection for loss computation
        proj_embeddings = (output['R'] + output['S'] + output['N']) / 3

        # 1. Separation loss (triplet or contrastive) if labels available
        if rsn_labels is not None:
            sep_output = self.separation_loss(proj_embeddings, rsn_labels)
            sep_loss = sep_output.total_loss * self.config.triplet_weight

            if sample_weights is not None:
                # Weighted loss not directly supported, apply to total
                pass

            total_loss = total_loss + sep_loss

            if self.config.use_contrastive:
                metrics.contrastive_loss = sep_loss.item()
            else:
                metrics.triplet_loss = sep_loss.item()
                metrics.num_triplets = sep_output.metrics.get('num_triplets', 0)
                metrics.num_valid_triplets = sep_output.metrics.get('num_valid_triplets', 0)
                metrics.separation_ratio = sep_output.metrics.get('separation_ratio', 0.0)

        # 2. Orthogonality loss
        weights = self.heads.get_projection_weights()
        if all(w is not None for w in weights.values()):
            ortho_output = self.orthogonality_loss(
                weights['R'], weights['S'], weights['N']
            )
            ortho_loss = ortho_output.total_loss * self.config.orthogonality_weight
            total_loss = total_loss + ortho_loss
            metrics.orthogonality_loss = ortho_loss.item()

        # 3. Classification loss if labels available
        if rsn_labels is not None and 'logits' in output:
            cls_loss = self.classification_loss(output['logits'], rsn_labels)
            cls_loss = cls_loss * self.config.classification_weight
            total_loss = total_loss + cls_loss
            metrics.classification_loss = cls_loss.item()

            # Accuracy
            with torch.no_grad():
                preds = output['logits'].argmax(dim=-1)
                accuracy = (preds == rsn_labels).float().mean().item()
                metrics.classification_accuracy = accuracy

        # 4. Weak supervision from outcomes
        if task_outcomes is not None and self.config.use_outcome_supervision:
            weak_labels = self.outcome_supervisor.compute_weak_labels(
                embeddings.unsqueeze(1),  # Add sequence dim
                task_outcomes['prediction'],
                task_outcomes['target'],
            )
            weak_labels = weak_labels.squeeze(1)  # Remove sequence dim

            weak_loss = self.classification_loss(output['logits'], weak_labels)
            weak_loss = weak_loss * self.config.outcome_weight
            total_loss = total_loss + weak_loss
            metrics.weak_supervision_loss = weak_loss.item()

        # Backward pass
        total_loss.backward()

        # Gradient clipping
        grad_norm = torch.nn.utils.clip_grad_norm_(
            self.heads.parameters(),
            self.config.max_grad_norm
        )
        metrics.grad_norm = grad_norm.item()

        # Optimizer step
        self.optimizer.step()
        self.scheduler.step()

        # Update metrics
        metrics.total_loss = total_loss.item()
        metrics.learning_rate = self.scheduler.get_last_lr()[0]
        metrics.timestamp = time.time()

        self.global_step += 1

        return metrics

    def train_epoch(
        self,
        dataloader: DataLoader,
        use_weak_supervision: bool = True,
    ) -> Dict[str, float]:
        """
        Train for one epoch.

        Args:
            dataloader: DataLoader with (embeddings, labels, weights) batches
            use_weak_supervision: Whether to use weak supervision

        Returns:
            Dict with epoch metrics
        """
        self.state = TrainingState.TRAINING
        self.heads.train()

        epoch_metrics = {
            'total_loss': 0.0,
            'triplet_loss': 0.0,
            'orthogonality_loss': 0.0,
            'classification_loss': 0.0,
            'classification_accuracy': 0.0,
            'num_batches': 0,
        }

        for batch in dataloader:
            embeddings, labels, weights = batch

            step_metrics = self.train_step(
                embeddings=embeddings,
                rsn_labels=labels,
                sample_weights=weights,
            )

            # Accumulate metrics
            epoch_metrics['total_loss'] += step_metrics.total_loss
            epoch_metrics['triplet_loss'] += step_metrics.triplet_loss
            epoch_metrics['orthogonality_loss'] += step_metrics.orthogonality_loss
            epoch_metrics['classification_loss'] += step_metrics.classification_loss
            epoch_metrics['classification_accuracy'] += step_metrics.classification_accuracy
            epoch_metrics['num_batches'] += 1

            # Logging
            if self.global_step % self.config.log_every == 0:
                self.training_history.append(step_metrics)

            # Evaluation
            if self.global_step % self.config.eval_every == 0:
                self.state = TrainingState.EVALUATING
                # Evaluation would happen here with eval dataloader
                self.state = TrainingState.TRAINING

            # Checkpoint
            if self.global_step % self.config.save_every == 0:
                self.save_checkpoint()

            # Check max steps
            if self.global_step >= self.config.max_steps:
                break

        # Average metrics
        num_batches = max(epoch_metrics['num_batches'], 1)
        for key in ['total_loss', 'triplet_loss', 'orthogonality_loss',
                    'classification_loss', 'classification_accuracy']:
            epoch_metrics[key] /= num_batches

        self.epoch += 1

        return epoch_metrics

    def evaluate(
        self,
        eval_dataloader: DataLoader,
    ) -> EvaluationMetrics:
        """
        Evaluate projection heads.

        Args:
            eval_dataloader: DataLoader for evaluation data

        Returns:
            EvaluationMetrics with evaluation results
        """
        self.heads.eval()
        prev_state = self.state
        self.state = TrainingState.EVALUATING

        metrics = EvaluationMetrics(step=self.global_step)

        all_preds = []
        all_labels = []
        total_loss = 0.0
        num_batches = 0

        with torch.no_grad():
            for batch in eval_dataloader:
                embeddings, labels, weights = batch
                embeddings = embeddings.to(self.device)
                labels = labels.to(self.device)

                output = self.heads(embeddings, return_classification=True)
                proj_embeddings = (output['R'] + output['S'] + output['N']) / 3

                # Compute loss
                loss_output = self.combined_loss(
                    proj_embeddings,
                    labels,
                    self.heads,
                    output.get('logits'),
                )
                total_loss += loss_output.total_loss.item()
                num_batches += 1

                # Collect predictions
                preds = output['logits'].argmax(dim=-1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

        # Compute metrics
        metrics.loss = total_loss / max(num_batches, 1)

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)

        # Accuracy
        metrics.accuracy = (all_preds == all_labels).mean()

        # Per-class metrics
        for cls_idx, cls_name in enumerate(['R', 'S', 'N']):
            cls_mask = all_labels == cls_idx
            pred_mask = all_preds == cls_idx

            tp = np.sum(cls_mask & pred_mask)
            fp = np.sum(~cls_mask & pred_mask)
            fn = np.sum(cls_mask & ~pred_mask)

            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

            metrics.precision[cls_name] = precision
            metrics.recall[cls_name] = recall
            metrics.f1[cls_name] = f1

        # Separation score (inter-class / intra-class distance)
        metrics.separation_score = self._compute_separation_score(eval_dataloader)

        # Orthogonality score
        weights = self.heads.get_projection_weights()
        if all(w is not None for w in weights.values()):
            ortho_output = self.orthogonality_loss(
                weights['R'], weights['S'], weights['N']
            )
            metrics.orthogonality_score = 1.0 / (1.0 + ortho_output.metrics['total_overlap'])

        metrics.timestamp = time.time()
        self.evaluation_history.append(metrics)

        # Early stopping check
        if metrics.loss < self.best_loss - self.config.min_delta:
            self.best_loss = metrics.loss
            self.patience_counter = 0
            if self.config.save_best_only:
                self.save_checkpoint('best')
        else:
            self.patience_counter += 1

        if self.patience_counter >= self.config.patience:
            self.state = TrainingState.COMPLETED
        else:
            self.state = prev_state

        return metrics

    def _compute_separation_score(
        self,
        dataloader: DataLoader,
    ) -> float:
        """Compute inter-class vs intra-class distance ratio."""
        self.heads.eval()

        class_embeddings = {0: [], 1: [], 2: []}

        with torch.no_grad():
            for batch in dataloader:
                embeddings, labels, _ = batch
                embeddings = embeddings.to(self.device)
                labels = labels.to(self.device)

                output = self.heads(embeddings, return_classification=False)
                proj = (output['R'] + output['S'] + output['N']) / 3

                for i in range(3):
                    mask = labels == i
                    if mask.sum() > 0:
                        class_embeddings[i].append(proj[mask])

        # Compute centroids
        centroids = {}
        for cls_idx in range(3):
            if class_embeddings[cls_idx]:
                all_emb = torch.cat(class_embeddings[cls_idx], dim=0)
                centroids[cls_idx] = all_emb.mean(dim=0)
            else:
                return 0.0

        # Inter-class distance
        inter_dist = 0.0
        count = 0
        for i in range(3):
            for j in range(i + 1, 3):
                inter_dist += torch.dist(centroids[i], centroids[j]).item()
                count += 1
        inter_dist /= max(count, 1)

        # Intra-class distance
        intra_dist = 0.0
        for cls_idx in range(3):
            if class_embeddings[cls_idx]:
                all_emb = torch.cat(class_embeddings[cls_idx], dim=0)
                dists = torch.cdist(all_emb, centroids[cls_idx].unsqueeze(0))
                intra_dist += dists.mean().item()
        intra_dist /= 3

        return inter_dist / (intra_dist + 1e-8)

    def save_checkpoint(self, name: Optional[str] = None) -> str:
        """Save training checkpoint."""
        if name is None:
            name = f"step_{self.global_step}"

        checkpoint_path = self.checkpoint_dir / f"rsn_trainer_{name}.pt"

        checkpoint = {
            'model_state_dict': self.heads.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'global_step': self.global_step,
            'epoch': self.epoch,
            'best_loss': self.best_loss,
            'patience_counter': self.patience_counter,
            'config': self.config.__dict__,
            'training_history': [m.to_dict() for m in self.training_history[-100:]],
            'evaluation_history': [m.to_dict() for m in self.evaluation_history[-20:]],
        }

        torch.save(checkpoint, checkpoint_path)
        return str(checkpoint_path)

    def load_checkpoint(self, path: str) -> None:
        """Load training checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)

        self.heads.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.global_step = checkpoint['global_step']
        self.epoch = checkpoint['epoch']
        self.best_loss = checkpoint['best_loss']
        self.patience_counter = checkpoint['patience_counter']

    def train(
        self,
        train_dataloader: DataLoader,
        eval_dataloader: Optional[DataLoader] = None,
        num_epochs: int = 10,
    ) -> Dict[str, Any]:
        """
        Full training loop.

        Args:
            train_dataloader: Training data loader
            eval_dataloader: Evaluation data loader (optional)
            num_epochs: Number of epochs

        Returns:
            Dict with final training results
        """
        self.state = TrainingState.TRAINING

        for epoch in range(num_epochs):
            epoch_metrics = self.train_epoch(train_dataloader)

            print(f"Epoch {epoch + 1}/{num_epochs} - "
                  f"Loss: {epoch_metrics['total_loss']:.4f}, "
                  f"Accuracy: {epoch_metrics['classification_accuracy']:.4f}")

            if eval_dataloader is not None:
                eval_metrics = self.evaluate(eval_dataloader)
                print(f"  Eval - Loss: {eval_metrics.loss:.4f}, "
                      f"Accuracy: {eval_metrics.accuracy:.4f}, "
                      f"Separation: {eval_metrics.separation_score:.4f}")

            if self.state == TrainingState.COMPLETED:
                print("Early stopping triggered")
                break

            if self.global_step >= self.config.max_steps:
                print("Max steps reached")
                break

        self.state = TrainingState.COMPLETED

        return {
            'final_epoch': self.epoch,
            'final_step': self.global_step,
            'best_loss': self.best_loss,
            'training_history': self.training_history,
            'evaluation_history': self.evaluation_history,
        }


# =============================================================================
# Factory Functions
# =============================================================================

def create_trainer(
    hidden_dim: int = 768,
    projection_dim: int = 128,
    config: Optional[RSNTrainingConfig] = None,
    device: Optional[torch.device] = None,
) -> Tuple[RSNProjectionTrainer, LearnedYRSNProjectionHeads]:
    """
    Factory function to create trainer and projection heads.

    Args:
        hidden_dim: Input hidden dimension
        projection_dim: Output projection dimension
        config: Training configuration (creates default if None)
        device: Target device

    Returns:
        Tuple of (trainer, projection_heads)
    """
    head_config = ProjectionHeadConfig(
        hidden_dim=hidden_dim,
        projection_dim=projection_dim,
        mode="hybrid",
    )

    projection_heads = LearnedYRSNProjectionHeads(head_config)

    if config is None:
        config = RSNTrainingConfig()

    trainer = RSNProjectionTrainer(
        projection_heads=projection_heads,
        config=config,
        device=device,
    )

    return trainer, projection_heads


def create_dataloader(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    weights: Optional[torch.Tensor] = None,
    batch_size: int = 64,
    shuffle: bool = True,
) -> DataLoader:
    """
    Create DataLoader for RSN training.

    Args:
        embeddings: [N, D] embeddings
        labels: [N] R/S/N labels
        weights: [N] sample weights (optional)
        batch_size: Batch size
        shuffle: Whether to shuffle

    Returns:
        DataLoader
    """
    dataset = RSNDataset(embeddings, labels, weights)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'RSNTrainingConfig',
    'TrainingState',
    'TrainingMetrics',
    'EvaluationMetrics',
    'RSNDataset',
    'RSNProjectionTrainer',
    'create_trainer',
    'create_dataloader',
]
