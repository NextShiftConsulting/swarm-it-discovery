"""
YRSN Fragility Monitor
======================

Hardware health monitoring using YRSN fragility fingerprinting.

This module provides production-ready health monitoring that measures
sensitivity to perturbation using the full YRSN signal suite:

1. GEOMETRIC FRAGILITY (from HybridSimplexRotor):
   - theta: sensitivity of sample_theta (2D projection angle)
   - radius: sensitivity of sample_radius (2D projection magnitude)
   - angular_coherence: 1/(1 + var(theta across probes))
   - radial_stability: 1/(1 + var(radius across probes))

2. OMEGA FRAGILITY (OOD detection):
   - omega_fragility: how OOD confidence changes with probes
   - omega_stability: variance of omega across probes

3. SIMPLEX DYNAMICS:
   - rsn: L1 distance on R+S+N=1 simplex
   - boundary_proximity: min(R, S, N) - closeness to simplex edge
   - alpha_variance: variance of alpha across probes

Usage:
    from yrsn.core.decomposition import YRSNFragilityMonitor

    monitor = YRSNFragilityMonitor(projection, probe_scale=0.01, n_probes=10)
    monitor.calibrate(healthy_features)

    result = monitor.diagnose(test_features)
    if result['detected']:
        print(f"Degradation detected: {result['type']} (severity={result['severity']:.2f})")

Reference: series_004/expS4_102c_sensitivity_health.py
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import numpy as np


@dataclass
class FragilityDiagnosis:
    """Result of fragility-based health diagnosis."""
    detected: bool
    degradation_type: Optional[str]
    severity: float
    confidence: float
    fingerprint: List[float]
    yrsn_signals: Dict[str, float]

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return {
            'detected': self.detected,
            'type': self.degradation_type,
            'severity': self.severity,
            'confidence': self.confidence,
            'fingerprint': self.fingerprint,
            'yrsn_signals': self.yrsn_signals,
        }


class YRSNFragilityMonitor:
    """
    Hardware health monitor using FULL YRSN signal suite for fragility fingerprinting.

    This is the production-ready implementation of the approach validated in
    expS4_102c, achieving 100% detection and 100% classification accuracy.

    YRSN-SPECIFIC SIGNALS USED:
    ==========================

    1. GEOMETRIC FRAGILITY (from HybridSimplexRotor):
       - delta_theta: sensitivity of sample_theta (2D projection angle)
       - delta_radius: sensitivity of sample_radius (2D projection magnitude)
       - angular_coherence: 1/(1 + var(theta across probes)) - stability metric
       - radial_stability: 1/(1 + var(radius across probes))

    2. OMEGA FRAGILITY (OOD detection):
       - delta_omega: how OOD confidence changes with probes
       - omega_stability: variance of omega across probes
       - Healthy hardware: stable omega; Degraded: fluctuating omega

    3. SIMPLEX DYNAMICS:
       - delta_RSN: L1 distance on R+S+N=1 simplex
       - simplex_velocity: rate of movement on simplex per probe
       - boundary_proximity: min(R, S, N) - closeness to simplex edge
       - alpha_stability: variance of alpha (=R) across probes

    Example:
        >>> from yrsn.core.decomposition import YRSNFragilityMonitor, TrainedRSNProjection
        >>>
        >>> projection = TrainedRSNProjection.from_checkpoint('checkpoint.pt')
        >>> monitor = YRSNFragilityMonitor(projection)
        >>> monitor.calibrate(healthy_features)
        >>>
        >>> result = monitor.diagnose(test_features)
        >>> if result.detected:
        ...     print(f"Degradation: {result.degradation_type}")
        ...     print(f"Severity: {result.severity:.2f}")
    """

    # Extended fingerprint signatures with full YRSN signals
    # [theta, radius, rsn, omega, angular_coh, boundary_prox, alpha_var]
    # 7-dimensional fingerprint exploiting YRSN geometry
    #
    # NOTE: Omega signal (-0.9x) is uniform across types - not discriminating
    # Key discriminating signals: theta, boundary_proximity, alpha_variance
    SIGNATURES = {
        'attenuation': np.array([0.18, 0.01, 0.09, -0.95, 0.00, 0.54, -0.08]),
        'stuck':       np.array([-0.06, 0.05, -0.14, -0.98, 0.00, 0.36, -0.37]),
        'quantization':np.array([-0.01, -0.01, 0.00, -0.91, 0.00, 0.01, 0.06]),
        'noise_snr':   np.array([-0.33, 0.11, -0.33, -0.99, 0.00, 0.09, -0.62]),
    }

    # Type-specific severity signals (use discriminating signals)
    SEVERITY_SIGNAL = {
        'attenuation': 'theta',  # Theta increases strongly with attenuation
        'stuck': 'boundary_proximity',  # Stuck changes boundary position
        'quantization': 'boundary_proximity',
        'noise_snr': 'theta',  # Theta crashes with SNR degradation
    }

    def __init__(
        self,
        projection,
        probe_scale: float = 0.01,
        n_probes: int = 10,
    ):
        """
        Initialize fragility monitor.

        Args:
            projection: TrainedRSNProjection or similar with compute_rsn() method
            probe_scale: Magnitude of perturbation probes (default 0.01)
            n_probes: Number of random probes to average over (default 10)
        """
        self.projection = projection
        self.probe_scale = probe_scale
        self.n_probes = n_probes
        self.baseline = None
        self.means = None
        self.thresholds = None
        self._calibrated = False

    def _compute_full_signals(self, features: np.ndarray) -> List[Dict[str, float]]:
        """
        Compute ALL available YRSN signals for features.

        Returns list of dicts with geometric, simplex, and OOD signals.
        """
        results = []
        for i in range(len(features)):
            rsn = self.projection.compute_rsn(features[i:i+1])

            # Compute omega via distance if reference embeddings available
            if hasattr(self.projection, '_compute_omega_distance'):
                omega = self.projection._compute_omega_distance(features[i:i+1])
            else:
                omega = float(rsn.get('omega', 1.0 - rsn['N']))

            results.append({
                # Geometric signals (from rotor)
                'theta': float(rsn.get('sample_theta', 0)),
                'radius': float(rsn.get('sample_radius', 1.0)),
                'scale': float(rsn.get('scale', 1.0)),
                # Simplex signals
                'R': float(rsn['R']),
                'S': float(rsn['S']),
                'N': float(rsn['N']),
                'alpha': float(rsn.get('alpha', rsn['R'])),
                # OOD signal
                'omega': omega,
                # Derived: boundary proximity (how close to simplex edge)
                'boundary_proximity': min(float(rsn['R']), float(rsn['S']), float(rsn['N'])),
            })
        return results

    def _compute_yrsn_fragility(self, features: np.ndarray) -> Dict[str, Any]:
        """
        Compute fragility using FULL YRSN signal suite.

        Measures sensitivity across all geometric, simplex, and OOD signals.
        """
        n_samples = len(features)
        baseline = self._compute_full_signals(features)

        # Initialize accumulators for all signals
        delta_theta = np.zeros(n_samples)
        delta_radius = np.zeros(n_samples)
        delta_rsn = np.zeros(n_samples)
        delta_omega = np.zeros(n_samples)
        delta_alpha = np.zeros(n_samples)
        delta_boundary = np.zeros(n_samples)

        # Store per-probe values for variance/coherence metrics
        probe_thetas = []
        probe_radii = []
        probe_omegas = []
        probe_alphas = []
        probe_boundaries = []

        for probe_idx in range(self.n_probes):
            # Generate random unit probe
            probe = np.random.randn(*features.shape)
            probe = probe / (np.linalg.norm(probe, axis=1, keepdims=True) + 1e-8)

            # Apply probe and compute all signals
            probed = self._compute_full_signals(features + self.probe_scale * probe)

            # Store for variance calculation
            probe_thetas.append([p['theta'] for p in probed])
            probe_radii.append([p['radius'] for p in probed])
            probe_omegas.append([p['omega'] for p in probed])
            probe_alphas.append([p['alpha'] for p in probed])
            probe_boundaries.append([p['boundary_proximity'] for p in probed])

            # Accumulate deltas
            for i in range(n_samples):
                delta_theta[i] += abs(probed[i]['theta'] - baseline[i]['theta'])
                delta_radius[i] += abs(probed[i]['radius'] - baseline[i]['radius'])
                delta_rsn[i] += (
                    abs(probed[i]['R'] - baseline[i]['R']) +
                    abs(probed[i]['S'] - baseline[i]['S']) +
                    abs(probed[i]['N'] - baseline[i]['N'])
                )
                delta_omega[i] += abs(probed[i]['omega'] - baseline[i]['omega'])
                delta_alpha[i] += abs(probed[i]['alpha'] - baseline[i]['alpha'])
                delta_boundary[i] += abs(probed[i]['boundary_proximity'] - baseline[i]['boundary_proximity'])

        # Convert to arrays
        probe_thetas = np.array(probe_thetas)  # [n_probes, n_samples]
        probe_radii = np.array(probe_radii)
        probe_omegas = np.array(probe_omegas)
        probe_alphas = np.array(probe_alphas)
        probe_boundaries = np.array(probe_boundaries)

        # Compute coherence metrics (inverse of variance)
        # Low coherence = high sensitivity = potential degradation
        angular_coherence = 1.0 / (1.0 + np.mean(np.var(probe_thetas, axis=0)))
        radial_stability = 1.0 / (1.0 + np.mean(np.var(probe_radii, axis=0)))
        omega_stability = 1.0 / (1.0 + np.mean(np.var(probe_omegas, axis=0)))
        alpha_variance = np.mean(np.var(probe_alphas, axis=0))

        # Simplex velocity: average movement on simplex per probe
        simplex_velocity = delta_rsn / (self.n_probes * self.probe_scale)

        return {
            # Primary fragility metrics (normalized)
            'theta': delta_theta / (self.n_probes * self.probe_scale),
            'radius': delta_radius / (self.n_probes * self.probe_scale),
            'rsn': delta_rsn / (self.n_probes * self.probe_scale),
            'omega': delta_omega / (self.n_probes * self.probe_scale),
            'alpha': delta_alpha / (self.n_probes * self.probe_scale),
            'boundary_proximity': delta_boundary / (self.n_probes * self.probe_scale),

            # Coherence/stability metrics (YRSN-specific)
            'angular_coherence': angular_coherence,
            'radial_stability': radial_stability,
            'omega_stability': omega_stability,
            'alpha_variance': alpha_variance,

            # Simplex dynamics
            'simplex_velocity': simplex_velocity,

            # Raw baseline values (for normalization)
            'baseline_theta': np.array([b['theta'] for b in baseline]),
            'baseline_omega': np.array([b['omega'] for b in baseline]),
            'baseline_boundary': np.array([b['boundary_proximity'] for b in baseline]),
        }

    def calibrate(self, healthy_features: np.ndarray) -> 'YRSNFragilityMonitor':
        """
        Calibrate on healthy hardware samples using full YRSN signals.

        Args:
            healthy_features: Feature array from healthy/reference hardware

        Returns:
            self (for chaining)
        """
        self.baseline = self._compute_yrsn_fragility(healthy_features)

        # Compute means for each signal
        self.means = {
            'theta': np.mean(self.baseline['theta']),
            'radius': np.mean(self.baseline['radius']),
            'rsn': np.mean(self.baseline['rsn']),
            'omega': np.mean(self.baseline['omega']),
            'alpha': np.mean(self.baseline['alpha']),
            'boundary_proximity': np.mean(self.baseline['boundary_proximity']),
            'angular_coherence': self.baseline['angular_coherence'],
            'radial_stability': self.baseline['radial_stability'],
            'omega_stability': self.baseline['omega_stability'],
            'alpha_variance': self.baseline['alpha_variance'],
        }

        # Compute thresholds (mean + 2*std) for each signal
        self.thresholds = {
            'theta': self.means['theta'] + 2 * np.std(self.baseline['theta']),
            'radius': self.means['radius'] + 2 * np.std(self.baseline['radius']),
            'rsn': self.means['rsn'] + 2 * np.std(self.baseline['rsn']),
            'omega': self.means['omega'] + 2 * np.std(self.baseline['omega']),
            'boundary_proximity': self.means['boundary_proximity'] + 2 * np.std(self.baseline['boundary_proximity']),
        }

        self._calibrated = True
        return self

    def _compute_fingerprint(self, fragility: Dict[str, Any]) -> np.ndarray:
        """
        Compute 7D YRSN fingerprint from fragility measurements.

        Fingerprint = [theta, radius, rsn, omega, angular_coh, boundary_prox, alpha_var]
        Each component normalized relative to healthy baseline.
        """
        fingerprint = np.array([
            # Geometric fragility
            (np.mean(fragility['theta']) - self.means['theta']) / (self.means['theta'] + 1e-8),
            (np.mean(fragility['radius']) - self.means['radius']) / (self.means['radius'] + 1e-8),
            # Simplex fragility
            (np.mean(fragility['rsn']) - self.means['rsn']) / (self.means['rsn'] + 1e-8),
            # OOD fragility (omega)
            (np.mean(fragility['omega']) - self.means['omega']) / (self.means['omega'] + 1e-8),
            # Coherence change (negative = degradation)
            (fragility['angular_coherence'] - self.means['angular_coherence']) / (self.means['angular_coherence'] + 1e-8),
            # Boundary proximity change
            (np.mean(fragility['boundary_proximity']) - self.means['boundary_proximity']) / (self.means['boundary_proximity'] + 1e-8),
            # Alpha variance change
            (fragility['alpha_variance'] - self.means['alpha_variance']) / (self.means['alpha_variance'] + 1e-8),
        ])
        return fingerprint

    def _classify_type(self, fingerprint: np.ndarray) -> tuple:
        """
        Classify degradation type from 7D YRSN fingerprint.

        Uses:
        1. YRSN-specific rules based on discriminating signals
        2. Cosine similarity fallback to known signatures
        """
        theta_response = fingerprint[0]
        rsn_response = fingerprint[2]
        boundary_response = fingerprint[5]
        alpha_var_response = fingerprint[6]
        fingerprint_magnitude = np.linalg.norm(fingerprint)

        # Rule 1: Strong positive theta + high boundary -> attenuation
        if theta_response > 0.10 and boundary_response > 0.30:
            return 'attenuation', 0.95

        # Rule 2: Large negative theta + large negative alpha_var -> noise_snr
        if theta_response < -0.20 and alpha_var_response < -0.40:
            return 'noise_snr', 0.92

        # Rule 3: Small changes overall + small boundary -> quantization
        if abs(theta_response) < 0.05 and abs(rsn_response) < 0.05 and boundary_response < 0.10:
            return 'quantization', 0.80

        # Rule 4: Moderate boundary response + moderate alpha_var drop -> stuck
        if boundary_response > 0.20 and boundary_response < 0.50 and alpha_var_response < -0.20:
            return 'stuck', 0.88

        # Rule 5: Negative theta but not extreme -> stuck
        if theta_response < 0 and theta_response > -0.15 and boundary_response > 0.15:
            return 'stuck', 0.85

        # Fallback: cosine similarity (excluding omega which doesn't discriminate)
        # Use reduced fingerprint: [theta, radius, rsn, boundary, alpha_var]
        reduced_fingerprint = np.array([
            fingerprint[0],  # theta
            fingerprint[1],  # radius
            fingerprint[2],  # rsn
            fingerprint[5],  # boundary_proximity
            fingerprint[6],  # alpha_variance
        ])

        reduced_signatures = {
            'attenuation': np.array([0.18, 0.01, 0.09, 0.54, -0.08]),
            'stuck':       np.array([-0.06, 0.05, -0.14, 0.36, -0.37]),
            'quantization':np.array([-0.01, -0.01, 0.00, 0.01, 0.06]),
            'noise_snr':   np.array([-0.33, 0.11, -0.33, 0.09, -0.62]),
        }

        best_type = None
        best_similarity = -np.inf

        for deg_type, signature in reduced_signatures.items():
            similarity = np.dot(reduced_fingerprint, signature) / (
                np.linalg.norm(reduced_fingerprint) * np.linalg.norm(signature) + 1e-8
            )
            if similarity > best_similarity:
                best_similarity = similarity
                best_type = deg_type

        return best_type, float(best_similarity)

    def _compute_severity(self, fragility: Dict[str, Any], deg_type: str) -> float:
        """Compute severity using type-specific YRSN signal."""
        signal_name = self.SEVERITY_SIGNAL.get(deg_type, 'theta')

        if signal_name in ['angular_coherence', 'omega_stability', 'radial_stability']:
            # For coherence metrics: lower = worse
            current = fragility[signal_name]
            baseline = self.means[signal_name]
            severity = (baseline - current) / (baseline + 1e-8)
        else:
            # For delta metrics: higher = worse
            current = np.mean(fragility[signal_name])
            baseline = self.means[signal_name]
            threshold = self.thresholds.get(signal_name, baseline * 2)
            severity = (current - baseline) / (threshold - baseline + 1e-8)

        return float(np.clip(severity, 0, 1))

    def diagnose(self, features: np.ndarray) -> FragilityDiagnosis:
        """
        Diagnose hardware health using full YRSN signal suite.

        Args:
            features: Feature array from hardware to diagnose

        Returns:
            FragilityDiagnosis with detection result, type, severity, and YRSN signals

        Raises:
            ValueError: If monitor not calibrated
        """
        if not self._calibrated:
            raise ValueError("Must call calibrate() first")

        fragility = self._compute_yrsn_fragility(features)
        fingerprint = self._compute_fingerprint(fragility)

        # Detection using multiple YRSN criteria
        fingerprint_magnitude = np.linalg.norm(fingerprint)

        # YRSN-specific detection criteria
        coherence_drop = self.means['angular_coherence'] - fragility['angular_coherence']
        omega_instability = fragility['omega_stability'] < self.means['omega_stability'] * 0.9

        detected = (
            fingerprint_magnitude > 0.12 or  # Overall deviation
            coherence_drop > 0.05 or  # Angular stability degraded
            omega_instability or  # OOD confidence unstable
            np.mean(fragility['theta']) > self.thresholds['theta'] or
            np.mean(fragility['omega']) > self.thresholds['omega']
        )

        # Classify and compute severity
        deg_type, confidence = self._classify_type(fingerprint)
        severity = self._compute_severity(fragility, deg_type) if detected else 0.0

        return FragilityDiagnosis(
            detected=bool(detected),
            degradation_type=deg_type if detected else None,
            severity=severity,
            confidence=confidence if detected else 0.0,
            fingerprint=fingerprint.tolist(),
            yrsn_signals={
                'angular_coherence': fragility['angular_coherence'],
                'omega_stability': fragility['omega_stability'],
                'radial_stability': fragility['radial_stability'],
                'alpha_variance': fragility['alpha_variance'],
                'theta_fragility': float(np.mean(fragility['theta'])),
                'omega_fragility': float(np.mean(fragility['omega'])),
            },
        )

    @property
    def is_calibrated(self) -> bool:
        """Whether the monitor has been calibrated."""
        return self._calibrated


__all__ = [
    'YRSNFragilityMonitor',
    'FragilityDiagnosis',
]
