"""
Phasor Coherence - Multi-Source Interference Detection

Pure mathematical domain logic for detecting conflicts across multiple information
sources using quantum-inspired phasor interference.

┌────────────────────────────────────────────────────────────────────┐
│                       WHAT THIS DOES                                │
├────────────────────────────────────────────────────────────────────┤
│ Detects conflicts between multiple sources (e.g., RAG contexts,    │
│ multi-agent outputs) by treating each source as a phasor:          │
│   • Amplitude: Relevance/importance of source                      │
│   • Phase: Stance/polarity (0-360°)                                │
│   • Coherence: How well sources agree (constructive interference)  │
│                                                                     │
│ HIGH coherence = sources agree → Trust output                      │
│ LOW coherence = sources conflict → Flag for review                 │
└────────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
Multi-source systems (RAG, multi-agent) can produce conflicting outputs.
Traditional approaches (voting, averaging) don't capture phase relationships.
Phasor coherence provides quantum-inspired conflict detection.

DOMAIN LOGIC (Pure Math):
-------------------------
This module contains ONLY pure mathematical functions with zero external
dependencies. No matplotlib, no PyTorch, no infrastructure.

For visualization, see: infrastructure/rendering/matplotlib/phasor_renderer.py
For adapters, see: adapters/visualization/matplotlib_adapter.py

FIRST PRINCIPLES COMPLIANCE:
----------------------------
✓ P1: Pure domain logic (zero infrastructure dependencies)
✓ Hex architecture: Domain layer
✓ Testable: All functions are pure (input → output, no side effects)

USAGE EXAMPLES:
--------------

Example 1: Detect Conflict in RAG Contexts
>>> from yrsn.core.decomposition.phasor_coherence import (
...     PhasorSource, compute_coherence, detect_conflict
... )
>>>
>>> # Three sources with different stances
>>> sources = [
...     PhasorSource(amplitude=0.8, phase=45.0, source_id='doc1'),   # Pro
...     PhasorSource(amplitude=0.6, phase=50.0, source_id='doc2'),   # Pro
...     PhasorSource(amplitude=0.9, phase=200.0, source_id='doc3'),  # Con (opposite)
... ]
>>>
>>> coherence = compute_coherence(sources)
>>> print(f"Coherence: {coherence:.3f}")  # Low (0.3-0.5) = conflict detected
>>>
>>> is_conflicted, conflicting_pairs = detect_conflict(sources, threshold=0.7)
>>> if is_conflicted:
...     print(f"Conflict detected between: {conflicting_pairs}")

Example 2: Multi-Agent Agreement
>>> agents = [
...     PhasorSource(0.9, 120.0, 'agent_A'),  # Different approach
...     PhasorSource(0.8, 125.0, 'agent_B'),  # Similar to A
...     PhasorSource(0.7, 130.0, 'agent_C'),  # Similar to A
... ]
>>>
>>> coherence = compute_coherence(agents)
>>> print(f"Coherence: {coherence:.3f}")  # High (0.8+) = agents agree

Example 3: Phase Center (Consensus Direction)
>>> from yrsn.core.decomposition.phasor_coherence import compute_phase_center
>>>
>>> phase_center = compute_phase_center(sources)
>>> print(f"Consensus direction: {phase_center:.1f}°")

REFERENCE:
---------
CIP #2: Phasor Coherence for Conflict Detection
docs/CIP_02_PHASOR_COHERENCE.md
docs/schemas/PHASOR_COHERENCE.md
"""

from dataclasses import dataclass
from typing import List, Tuple, Optional
from enum import Enum
import numpy as np


# =============================================================================
# Domain Types
# =============================================================================

class FragilityLevel(str, Enum):
    """Classification of coherence-based fragility."""
    COHERENT = "COHERENT"           # coherence >= 0.7 (sources agree)
    MODERATE = "MODERATE"           # 0.4 <= coherence < 0.7
    CONFLICTED = "CONFLICTED"       # coherence < 0.4 (sources conflict)


@dataclass
class PhasorSource:
    """
    Single phasor source in multi-source interference.

    Attributes:
        amplitude: Relevance/importance weight [0, 1]
        phase: Stance/polarity angle [0, 360] degrees
        source_id: Unique identifier for source

    Example:
        >>> source = PhasorSource(
        ...     amplitude=0.8,     # 80% relevance
        ...     phase=45.0,        # Positive stance
        ...     source_id='doc1'
        ... )
    """
    amplitude: float
    phase: float
    source_id: str

    def __post_init__(self):
        """Validate constraints."""
        if not (0.0 <= self.amplitude <= 1.0):
            raise ValueError(f"Amplitude must be in [0, 1], got {self.amplitude}")
        if not (0.0 <= self.phase < 360.0):
            raise ValueError(f"Phase must be in [0, 360), got {self.phase}")


@dataclass
class PhasorCoherence:
    """
    Result of phasor coherence computation.

    Attributes:
        coherence: Constructive interference ratio [0, 1]
                  1.0 = perfect agreement, 0.0 = complete cancellation
        conflict: Inverse of coherence (1 - coherence)
        phase_center: Resultant phase angle [0, 360] degrees
        fragility_level: Classification (COHERENT/MODERATE/CONFLICTED)
        num_sources: Number of input sources

    Example:
        >>> result = PhasorCoherence(
        ...     coherence=0.85,
        ...     conflict=0.15,
        ...     phase_center=47.5,
        ...     fragility_level=FragilityLevel.COHERENT,
        ...     num_sources=3
        ... )
    """
    coherence: float
    conflict: float
    phase_center: float
    fragility_level: FragilityLevel
    num_sources: int


# =============================================================================
# Pure Math Functions (Zero Dependencies)
# =============================================================================

def compute_coherence(sources: List[PhasorSource]) -> float:
    """
    Compute phasor coherence from multi-source interference.

    ALGORITHM:
    ---------
    1. Convert each phasor to complex form: A·e^(iθ)
    2. Sum complex vectors: Σ A_i·e^(iθ_i)
    3. Compute resultant magnitude: |Σ|
    4. Normalize by total amplitude: coherence = |Σ| / Σ A_i

    INTERPRETATION:
    --------------
    - coherence = 1.0: Perfect constructive interference (all sources agree)
    - coherence = 0.5: Partial cancellation (some conflict)
    - coherence = 0.0: Perfect destructive interference (sources cancel)

    Args:
        sources: List of PhasorSource objects

    Returns:
        Coherence value in [0, 1]

    Example:
        >>> sources = [
        ...     PhasorSource(0.8, 45.0, 'a'),
        ...     PhasorSource(0.6, 50.0, 'b'),
        ... ]
        >>> coherence = compute_coherence(sources)
        >>> print(f"{coherence:.3f}")  # High (~0.95) - sources agree
    """
    if not sources:
        return 0.0

    if len(sources) == 1:
        return 1.0  # Single source = perfect coherence

    # Convert to complex vectors
    real_sum = 0.0
    imag_sum = 0.0
    total_amplitude = 0.0

    for source in sources:
        phase_rad = np.deg2rad(source.phase)
        real_sum += source.amplitude * np.cos(phase_rad)
        imag_sum += source.amplitude * np.sin(phase_rad)
        total_amplitude += source.amplitude

    # Resultant magnitude
    resultant_magnitude = np.sqrt(real_sum**2 + imag_sum**2)

    # Coherence = normalized resultant
    if total_amplitude == 0.0:
        return 0.0

    coherence = resultant_magnitude / total_amplitude

    return float(np.clip(coherence, 0.0, 1.0))


def compute_phase_center(sources: List[PhasorSource]) -> float:
    """
    Compute resultant phase angle (consensus direction).

    This is the phase of the vector sum: arg(Σ A_i·e^(iθ_i))

    Args:
        sources: List of PhasorSource objects

    Returns:
        Phase angle in [0, 360) degrees

    Example:
        >>> sources = [
        ...     PhasorSource(0.8, 45.0, 'a'),
        ...     PhasorSource(0.6, 50.0, 'b'),
        ... ]
        >>> center = compute_phase_center(sources)
        >>> print(f"{center:.1f}°")  # ~47° (weighted average)
    """
    if not sources:
        return 0.0

    real_sum = 0.0
    imag_sum = 0.0

    for source in sources:
        phase_rad = np.deg2rad(source.phase)
        real_sum += source.amplitude * np.cos(phase_rad)
        imag_sum += source.amplitude * np.sin(phase_rad)

    # Compute angle of resultant
    phase_rad = np.arctan2(imag_sum, real_sum)
    phase_deg = np.rad2deg(phase_rad)

    # Normalize to [0, 360)
    if phase_deg < 0:
        phase_deg += 360.0

    return float(phase_deg)


def classify_fragility(coherence: float) -> FragilityLevel:
    """
    Classify coherence into fragility level.

    THRESHOLDS:
    ----------
    - coherence >= 0.7: COHERENT (sources agree, trust output)
    - 0.4 <= coherence < 0.7: MODERATE (some conflict, review)
    - coherence < 0.4: CONFLICTED (high conflict, flag for human)

    Args:
        coherence: Coherence value [0, 1]

    Returns:
        FragilityLevel enum

    Example:
        >>> classify_fragility(0.85)
        FragilityLevel.COHERENT
        >>> classify_fragility(0.35)
        FragilityLevel.CONFLICTED
    """
    if coherence >= 0.7:
        return FragilityLevel.COHERENT
    elif coherence >= 0.4:
        return FragilityLevel.MODERATE
    else:
        return FragilityLevel.CONFLICTED


def compute_phasor_coherence(sources: List[PhasorSource]) -> PhasorCoherence:
    """
    Compute complete phasor coherence result.

    This is the main entry point combining all sub-functions.

    Args:
        sources: List of PhasorSource objects

    Returns:
        PhasorCoherence result object

    Example:
        >>> sources = [
        ...     PhasorSource(0.8, 45.0, 'doc1'),
        ...     PhasorSource(0.9, 200.0, 'doc2'),  # Opposite phase
        ... ]
        >>> result = compute_phasor_coherence(sources)
        >>> print(result.coherence)  # Low (~0.3)
        >>> print(result.fragility_level)  # CONFLICTED
    """
    coherence = compute_coherence(sources)
    conflict = 1.0 - coherence
    phase_center = compute_phase_center(sources)
    fragility_level = classify_fragility(coherence)

    return PhasorCoherence(
        coherence=coherence,
        conflict=conflict,
        phase_center=phase_center,
        fragility_level=fragility_level,
        num_sources=len(sources)
    )


def detect_conflict(
    sources: List[PhasorSource],
    threshold: float = 0.7
) -> Tuple[bool, List[Tuple[str, str]]]:
    """
    Detect conflicting source pairs.

    Two sources conflict if their phase difference is > 90° and both
    have significant amplitude (> 0.3).

    Args:
        sources: List of PhasorSource objects
        threshold: Phase difference threshold (degrees) for conflict

    Returns:
        (is_conflicted, conflicting_pairs)
        - is_conflicted: True if any conflicts found
        - conflicting_pairs: List of (source_id1, source_id2) tuples

    Example:
        >>> sources = [
        ...     PhasorSource(0.8, 45.0, 'a'),
        ...     PhasorSource(0.9, 200.0, 'b'),  # 155° apart
        ... ]
        >>> is_conflicted, pairs = detect_conflict(sources, threshold=90.0)
        >>> print(is_conflicted)  # True
        >>> print(pairs)  # [('a', 'b')]
    """
    conflicting_pairs = []

    for i in range(len(sources)):
        for j in range(i + 1, len(sources)):
            s1, s2 = sources[i], sources[j]

            # Skip if either source has low amplitude
            if s1.amplitude < 0.3 or s2.amplitude < 0.3:
                continue

            # Compute phase difference (wrapped)
            phase_diff = abs(s1.phase - s2.phase)
            if phase_diff > 180:
                phase_diff = 360 - phase_diff

            # Check if conflict
            if phase_diff > threshold:
                conflicting_pairs.append((s1.source_id, s2.source_id))

    is_conflicted = len(conflicting_pairs) > 0
    return is_conflicted, conflicting_pairs


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Types
    'FragilityLevel',
    'PhasorSource',
    'PhasorCoherence',

    # Functions
    'compute_coherence',
    'compute_phase_center',
    'classify_fragility',
    'compute_phasor_coherence',
    'detect_conflict',
]
