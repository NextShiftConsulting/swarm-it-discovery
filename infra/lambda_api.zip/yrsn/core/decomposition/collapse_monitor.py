"""
Collapse Monitor - Audit Trail and Early Warning System
=======================================================

Provides real-time monitoring of context collapse risk with:
- Audit trail of all collapse events
- Early warning system (predict collapse before it happens)
- Integration with Pillar 2 quality thresholds
- Observable metrics for dashboards

Usage:
    from yrsn.core.decomposition.collapse_monitor import (
        CollapseMonitor,
        CollapseEvent,
    )

    monitor = CollapseMonitor()

    # Update with new YRSN metrics
    event = monitor.update(R=0.4, S=0.35, N=0.25)

    # Check early warnings
    if monitor.has_early_warning():
        print(f"Warning: {monitor.get_early_warning()}")

    # Get audit trail
    for event in monitor.get_audit_trail():
        print(event)
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Deque
from collections import deque
from enum import Enum
import time
import numpy as np

from yrsn.core.decomposition.collapse import (
    detect_collapse,
    CollapseType,
    Severity,
    CollapseAnalysis,
)


# =============================================================================
# Early Warning System
# =============================================================================


class WarningLevel(Enum):
    """Early warning levels."""
    NONE = "none"
    WATCH = "watch"        # Trend towards collapse detected
    ELEVATED = "elevated"  # High risk of imminent collapse
    IMMINENT = "imminent"  # Collapse very likely on next update


@dataclass
class EarlyWarning:
    """Early warning of potential collapse."""
    level: WarningLevel
    predicted_collapse_type: Optional[CollapseType]
    confidence: float  # 0-1
    trend: str  # "improving", "stable", "degrading"
    time_to_collapse: Optional[int]  # Estimated updates until collapse
    message: str
    metrics: Dict[str, float]
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "level": self.level.value,
            "predicted_collapse_type": self.predicted_collapse_type.name if self.predicted_collapse_type else None,
            "confidence": self.confidence,
            "trend": self.trend,
            "time_to_collapse": self.time_to_collapse,
            "message": self.message,
            "metrics": self.metrics,
            "timestamp": self.timestamp,
        }


# =============================================================================
# Collapse Event for Audit Trail
# =============================================================================


@dataclass
class CollapseEvent:
    """Auditable collapse event."""
    event_id: int
    timestamp: float
    R: float
    S: float
    N: float
    quality: float
    collapse_analysis: CollapseAnalysis
    early_warning: Optional[EarlyWarning]
    constraint_violations: List[str]  # Names of violated constraints

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "metrics": {"R": self.R, "S": self.S, "N": self.N, "quality": self.quality},
            "collapse_type": self.collapse_analysis.collapse_type.name,
            "severity": self.collapse_analysis.severity.value,
            "risk_score": self.collapse_analysis.risk_score,
            "is_collapsed": self.collapse_analysis.is_collapsed,
            "early_warning": self.early_warning.to_dict() if self.early_warning else None,
            "constraint_violations": self.constraint_violations,
        }


# =============================================================================
# Collapse Monitor
# =============================================================================


class CollapseMonitor:
    """
    Real-time collapse monitoring with audit trail and early warning.

    Tracks YRSN metrics over time, detects trends, and predicts
    potential collapses before they occur.

    Parameters
    ----------
    history_size : int
        Number of events to keep in history
    warning_window : int
        Number of recent events to analyze for trends
    trend_threshold : float
        Minimum change rate to detect trend
    """

    def __init__(
        self,
        history_size: int = 1000,
        warning_window: int = 10,
        trend_threshold: float = 0.02,
    ):
        self.history_size = history_size
        self.warning_window = warning_window
        self.trend_threshold = trend_threshold

        # Audit trail
        self._events: Deque[CollapseEvent] = deque(maxlen=history_size)
        self._event_counter = 0

        # Metric history for trend analysis
        self._R_history: Deque[float] = deque(maxlen=warning_window * 2)
        self._S_history: Deque[float] = deque(maxlen=warning_window * 2)
        self._N_history: Deque[float] = deque(maxlen=warning_window * 2)
        self._risk_history: Deque[float] = deque(maxlen=warning_window * 2)

        # Current state
        self._current_warning: Optional[EarlyWarning] = None
        self._collapse_count = 0
        self._last_collapse_time: Optional[float] = None

    def update(
        self,
        R: float,
        S: float,
        N: float,
        quality: Optional[float] = None,
        source_S_values: Optional[List[float]] = None,
    ) -> CollapseEvent:
        """
        Update monitor with new YRSN metrics.

        Parameters
        ----------
        R, S, N : float
            YRSN component ratios [0, 1]
        quality : float, optional
            Quality metric (default: R)
        source_S_values : list, optional
            Per-source S values for clash detection

        Returns
        -------
        CollapseEvent
            Event record for audit trail
        """
        now = time.time()
        quality = quality if quality is not None else R

        # Update histories
        self._R_history.append(R)
        self._S_history.append(S)
        self._N_history.append(N)

        # Detect collapse
        analysis = detect_collapse(R, S, N, source_S_values)
        self._risk_history.append(analysis.risk_score)

        # Compute early warning
        warning = self._compute_early_warning(R, S, N, quality, analysis)
        self._current_warning = warning

        # Track collapses
        if analysis.is_collapsed:
            self._collapse_count += 1
            self._last_collapse_time = now

        # Get constraint violations (simple check for now)
        violations = self._check_simple_constraints(R, S, N)

        # Create event
        self._event_counter += 1
        event = CollapseEvent(
            event_id=self._event_counter,
            timestamp=now,
            R=R,
            S=S,
            N=N,
            quality=quality,
            collapse_analysis=analysis,
            early_warning=warning if warning.level != WarningLevel.NONE else None,
            constraint_violations=violations,
        )

        self._events.append(event)
        return event

    def _compute_early_warning(
        self,
        R: float,
        S: float,
        N: float,
        quality: float,
        analysis: CollapseAnalysis,
    ) -> EarlyWarning:
        """Compute early warning based on trends."""

        if len(self._R_history) < self.warning_window:
            return EarlyWarning(
                level=WarningLevel.NONE,
                predicted_collapse_type=None,
                confidence=0.0,
                trend="insufficient_data",
                time_to_collapse=None,
                message="Insufficient data for trend analysis",
                metrics={"R": R, "S": S, "N": N},
            )

        # Compute trends
        r_trend = self._compute_trend(list(self._R_history))
        s_trend = self._compute_trend(list(self._S_history))
        n_trend = self._compute_trend(list(self._N_history))
        risk_trend = self._compute_trend(list(self._risk_history))

        # Determine overall trend
        if risk_trend > self.trend_threshold:
            trend = "degrading"
        elif risk_trend < -self.trend_threshold:
            trend = "improving"
        else:
            trend = "stable"

        # Predict collapse type
        predicted_type = None
        confidence = 0.0
        time_to_collapse = None
        level = WarningLevel.NONE
        message = "No warning"

        # Check for degrading trends
        if trend == "degrading":
            # Noise increasing → potential poisoning
            if n_trend > self.trend_threshold and N > 0.2:
                predicted_type = CollapseType.POISONING
                confidence = min(1.0, n_trend * 10 + N)

            # Superfluous increasing → potential distraction
            elif s_trend > self.trend_threshold and S > 0.3:
                predicted_type = CollapseType.DISTRACTION
                confidence = min(1.0, s_trend * 10 + S)

            # Both increasing → potential confusion
            if n_trend > 0 and s_trend > 0 and N > 0.15 and S > 0.2:
                predicted_type = CollapseType.CONFLICT
                confidence = min(1.0, (n_trend + s_trend) * 5 + (N + S) / 2)

            # Estimate time to collapse
            if predicted_type is not None and risk_trend > 0:
                current_risk = analysis.risk_score
                threshold = 0.6  # Collapse risk threshold
                if current_risk < threshold:
                    time_to_collapse = int((threshold - current_risk) / risk_trend)

            # Determine warning level
            if confidence > 0.8 or (time_to_collapse and time_to_collapse <= 2):
                level = WarningLevel.IMMINENT
                message = f"Imminent {predicted_type.name if predicted_type else 'collapse'} risk"
            elif confidence > 0.5 or (time_to_collapse and time_to_collapse <= 5):
                level = WarningLevel.ELEVATED
                message = f"Elevated {predicted_type.name if predicted_type else 'collapse'} risk"
            elif confidence > 0.2:
                level = WarningLevel.WATCH
                message = f"Watch for {predicted_type.name if predicted_type else 'degradation'}"

        # If already collapsed, mark as imminent
        if analysis.is_collapsed:
            level = WarningLevel.IMMINENT
            predicted_type = analysis.collapse_type
            confidence = analysis.confidence
            message = f"Active {analysis.collapse_type.name} collapse"

        return EarlyWarning(
            level=level,
            predicted_collapse_type=predicted_type,
            confidence=confidence,
            trend=trend,
            time_to_collapse=time_to_collapse,
            message=message,
            metrics={"R": R, "S": S, "N": N, "risk": analysis.risk_score},
        )

    def _compute_trend(self, values: List[float]) -> float:
        """Compute trend (slope) of values."""
        if len(values) < 2:
            return 0.0
        x = np.arange(len(values))
        slope, _ = np.polyfit(x, values, 1)
        return float(slope)

    def _check_simple_constraints(self, R: float, S: float, N: float) -> List[str]:
        """Check simple constraint violations."""
        violations = []

        if N > 0.3:
            violations.append("poisoning_threshold")
        if S > 0.4:
            violations.append("distraction_threshold")
        if N > 0.2 and S > 0.25:
            violations.append("confusion_threshold")
        if R < 0.1:
            violations.append("min_relevance")

        return violations

    # =========================================================================
    # Query Methods
    # =========================================================================

    def has_early_warning(self) -> bool:
        """Check if there's an active early warning."""
        return (
            self._current_warning is not None
            and self._current_warning.level != WarningLevel.NONE
        )

    def get_early_warning(self) -> Optional[EarlyWarning]:
        """Get current early warning."""
        return self._current_warning

    def get_audit_trail(
        self,
        limit: int = 100,
        collapsed_only: bool = False,
    ) -> List[CollapseEvent]:
        """
        Get audit trail of events.

        Parameters
        ----------
        limit : int
            Maximum events to return
        collapsed_only : bool
            Only return collapsed events

        Returns
        -------
        list
            Recent collapse events
        """
        events = list(self._events)
        if collapsed_only:
            events = [e for e in events if e.collapse_analysis.is_collapsed]
        return events[-limit:]

    def get_statistics(self) -> Dict[str, Any]:
        """Get monitoring statistics."""
        events = list(self._events)

        if not events:
            return {
                "total_events": 0,
                "collapse_count": 0,
                "collapse_rate": 0.0,
            }

        collapsed = [e for e in events if e.collapse_analysis.is_collapsed]
        collapse_types = {}
        for e in collapsed:
            ct = e.collapse_analysis.collapse_type.name
            collapse_types[ct] = collapse_types.get(ct, 0) + 1

        return {
            "total_events": len(events),
            "collapse_count": len(collapsed),
            "collapse_rate": len(collapsed) / len(events) if events else 0,
            "collapse_types": collapse_types,
            "current_warning_level": (
                self._current_warning.level.value
                if self._current_warning
                else "none"
            ),
            "avg_risk": (
                np.mean(list(self._risk_history))
                if self._risk_history
                else 0
            ),
            "risk_trend": (
                self._compute_trend(list(self._risk_history))
                if len(self._risk_history) >= self.warning_window
                else 0
            ),
        }

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of recent metrics."""
        if not self._R_history:
            return {}

        return {
            "R": {
                "current": self._R_history[-1] if self._R_history else 0,
                "mean": np.mean(list(self._R_history)),
                "std": np.std(list(self._R_history)),
                "trend": self._compute_trend(list(self._R_history)),
            },
            "S": {
                "current": self._S_history[-1] if self._S_history else 0,
                "mean": np.mean(list(self._S_history)),
                "std": np.std(list(self._S_history)),
                "trend": self._compute_trend(list(self._S_history)),
            },
            "N": {
                "current": self._N_history[-1] if self._N_history else 0,
                "mean": np.mean(list(self._N_history)),
                "std": np.std(list(self._N_history)),
                "trend": self._compute_trend(list(self._N_history)),
            },
            "risk": {
                "current": self._risk_history[-1] if self._risk_history else 0,
                "mean": np.mean(list(self._risk_history)),
                "std": np.std(list(self._risk_history)),
                "trend": self._compute_trend(list(self._risk_history)),
            },
        }

    def reset(self) -> None:
        """Reset monitor state."""
        self._events.clear()
        self._R_history.clear()
        self._S_history.clear()
        self._N_history.clear()
        self._risk_history.clear()
        self._current_warning = None
        self._collapse_count = 0
        self._last_collapse_time = None
        self._event_counter = 0


# =============================================================================
# Convenience Functions
# =============================================================================


def create_collapse_monitor(
    history_size: int = 1000,
    warning_window: int = 10,
) -> CollapseMonitor:
    """Create configured collapse monitor."""
    return CollapseMonitor(
        history_size=history_size,
        warning_window=warning_window,
    )


def quick_collapse_check(
    R: float,
    S: float,
    N: float,
) -> Dict[str, Any]:
    """
    Quick collapse check without persistent monitor.

    Returns
    -------
    dict
        Collapse status and recommendations
    """
    analysis = detect_collapse(R, S, N)
    return {
        "is_collapsed": analysis.is_collapsed,
        "collapse_type": analysis.collapse_type.name,
        "severity": analysis.severity.value,
        "risk_score": analysis.risk_score,
        "recommendation": analysis.recommendation,
        "paradigm_remedy": analysis.paradigm_remedy,
    }


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "WarningLevel",

    # Dataclasses
    "EarlyWarning",
    "CollapseEvent",

    # Monitor
    "CollapseMonitor",

    # Convenience
    "create_collapse_monitor",
    "quick_collapse_check",
]
