"""
Trained RSN Projection Loader

This module provides a simple interface to load and use trained R/S/N projections
in experiments. It replaces the heuristic hack with proper learned projections.

Usage (Recommended - Class Method):
    from yrsn.core.decomposition.trained_projection import TrainedRSNProjection

    # Load trained projection using class method
    projection = TrainedRSNProjection.from_checkpoint('checkpoints/trained_rsn_memristor.pt')

    # Use in experiments
    result = projection.compute_rsn(embedding)
    print(f"R={result['R']:.3f}, S={result['S']:.3f}, N={result['N']:.3f}")

Alternative (Standalone Function):
    from yrsn.core.decomposition.trained_projection import load_trained_projection
    
    projection = load_trained_projection('checkpoints/trained_rsn_memristor.pt')
"""

from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from enum import Enum
from datetime import datetime
import torch
import torch.nn as nn
import numpy as np

from .supervised_heads import (
    LearnedYRSNProjectionHeads,
    ProjectionHeadConfig,
)
from . import DecompositionScore
from .frequency_rsn import FrequencyBasedRSN

# Adaptive thresholds for frequency fallback
OMEGA_THRESHOLD_FREQUENCY = 0.3  # Below this, augment with frequency signals
OMEGA_CRITICAL = 0.1  # Below this, frequency signals dominate


# =============================================================================
# FIT STRATEGY SCHEMA (P9: Schema as Source of Truth)
# =============================================================================

class FitStrategy(Enum):
    """
    Fit methodology for projection reference establishment.

    This enum defines how experiments should fit their reference embeddings.
    Used by DataWiringValidator to enforce DOE compliance (P11).

    Values:
        FIT_ONCE_ON_CLEAN: Fit on clean reference data once, never re-fit.
            - Use for: expS5_203 (certificate accuracy)
            - DOE says: "Same RSN projection" as control variable

        FIT_PER_DOMAIN: Fit once per domain/corruption type.
            - Use for: Domain adaptation experiments
            - Each domain gets its own reference

        FIT_NEVER: Use pre-trained embeddings only, no fitting.
            - Use for: Production inference
            - Checkpoint already has reference embeddings
    """
    FIT_ONCE_ON_CLEAN = "once_on_clean"
    FIT_PER_DOMAIN = "per_domain"
    FIT_NEVER = "never"


class TrainedRSNProjection:
    """
    Wrapper for trained R/S/N projection that provides a simple interface.

    This is the PROPER way to compute R/S/N decomposition:
    - Uses learned projections trained with curriculum learning
    - NOT heuristic frequency filters
    - Omega computed via distance to reference embeddings (OOD detection)

    Args:
        projection_heads: Trained LearnedYRSNProjectionHeads
        device: Target device for computation
        
    Example:
        # Load from checkpoint (recommended)
        projection = TrainedRSNProjection.from_checkpoint('checkpoints/trained_rsn_memristor.pt')
        
        # Compute R/S/N
        result = projection.compute_rsn(embedding)
        print(f"R={result['R']:.3f}, S={result['S']:.3f}, N={result['N']:.3f}")
    """

    def __init__(
        self,
        projection_heads: Union[LearnedYRSNProjectionHeads, nn.Module],
        device: Optional[torch.device] = None,
        projection_mode: str = "auto",  # "mlp", "rotor", or "auto"
    ):
        self.device = device or torch.device('cpu')

        # Auto-detect mode from model type if needed
        if projection_mode == "auto":
            from .hybrid_rotor import HybridSimplexRotor, HybridSimplexRotorCompact, SimplexRotor
            if isinstance(projection_heads, (HybridSimplexRotor, HybridSimplexRotorCompact, SimplexRotor)):
                self.projection_mode = "rotor"
            else:
                self.projection_mode = "mlp"
        else:
            self.projection_mode = projection_mode

        self.projection_heads = projection_heads
        self.projection_heads.to(self.device)
        self.projection_heads.eval()

        # Expose config for validation
        if hasattr(projection_heads, 'config'):
            self.config = projection_heads.config
        else:
            # Rotor mode - create minimal config-like object
            self.config = type('Config', (), {
                'hidden_dim': projection_heads.embed_dim if hasattr(projection_heads, 'embed_dim') else 768
            })()

        # For distance-based omega computation (OOD detection)
        self.reference_embeddings: Optional[np.ndarray] = None
        self.omega_scale: float = 1.0  # Calibrated from training distances

        # Fit state tracking (P1: Measurement - observable state)
        self._fit_count: int = 0
        self._fit_history: List[Dict[str, Any]] = []

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Union[str, Path],
        device: Optional[torch.device] = None,
        auto_fit_embeddings: Optional[np.ndarray] = None,
    ) -> 'TrainedRSNProjection':
        """
        Load a trained R/S/N projection from checkpoint.
        
        This is the recommended way to instantiate TrainedRSNProjection.
        
        Args:
            checkpoint_path: Path to .pt checkpoint file
            device: Target device (default: auto-detect GPU/CPU)
            auto_fit_embeddings: Optional training embeddings to fit for omega
            
        Returns:
            TrainedRSNProjection ready for use
            
        Example:
            projection = TrainedRSNProjection.from_checkpoint(
                'checkpoints/trained_rsn_memristor.pt'
            )
            result = projection.compute_rsn(embedding)
        """
        # Delegate to standalone function (avoids circular dependency)
        return load_trained_projection(checkpoint_path, device, auto_fit_embeddings)

    def fit(
        self,
        embeddings: Union[np.ndarray, torch.Tensor],
        labels: Optional[np.ndarray] = None,
        max_reference_samples: int = 10000,
        strategy: Optional[FitStrategy] = None,
    ) -> None:
        """
        Fit reference embeddings for distance-based omega computation.

        Tracks fit calls for methodology validation (P1: Measurement).

        Args:
            embeddings: Training embeddings [N, D]
            labels: Optional labels (unused, for API compatibility)
            max_reference_samples: Max samples to store (memory budget)
            strategy: Optional FitStrategy for tracking (default: FIT_ONCE_ON_CLEAN)
        """
        # Track fit call (P1: observable state)
        self._fit_count += 1
        self._fit_history.append({
            'timestamp': datetime.now().isoformat(),
            'n_samples': len(embeddings),
            'strategy': (strategy or FitStrategy.FIT_ONCE_ON_CLEAN).value,
            'call_number': self._fit_count,
        })

        if isinstance(embeddings, torch.Tensor):
            embeddings = embeddings.cpu().numpy()
        
        # Subsample if too many embeddings
        if len(embeddings) > max_reference_samples:
            indices = np.random.choice(len(embeddings), max_reference_samples, replace=False)
            embeddings = embeddings[indices]
        
        self.reference_embeddings = embeddings.astype(np.float32)

        # Reset cached statistics for Mahalanobis computation
        self._ref_mean = np.mean(embeddings, axis=0)
        self._ref_std = np.std(embeddings, axis=0) + 1e-6

        # Calibrate omega_scale from training data distances
        # Use median distance to nearest neighbor (excluding self)
        try:
            from sklearn.neighbors import NearestNeighbors
            nn = NearestNeighbors(n_neighbors=min(2, len(embeddings)), algorithm='auto')
            nn.fit(embeddings)
            distances, _ = nn.kneighbors(embeddings)
            # Use distance to 2nd nearest neighbor (1st is self with distance 0)
            if distances.shape[1] > 1:
                self.omega_scale = float(np.median(distances[:, 1]))
            else:
                self.omega_scale = float(np.median(distances[:, 0]))
        except ImportError:
            # Fallback: use random sample distances
            n_samples = min(1000, len(embeddings))
            sample_indices = np.random.choice(len(embeddings), n_samples, replace=False)
            sample_dists = []
            for i in sample_indices:
                dists = np.linalg.norm(embeddings - embeddings[i], axis=1)
                dists[i] = np.inf  # Exclude self
                sample_dists.append(np.min(dists))
            self.omega_scale = float(np.median(sample_dists))
        
        # Ensure omega_scale is reasonable
        self.omega_scale = max(self.omega_scale, 0.01)
        print(f"Fitted reference embeddings: {len(self.reference_embeddings)} samples, omega_scale={self.omega_scale:.4f}")

    @property
    def fit_state(self) -> Dict[str, Any]:
        """
        Observable fit state for validation (P1: Measurement).

        Returns dict with:
            fit_count: Number of times fit() was called
            fit_history: List of fit call records (timestamp, n_samples, strategy)
            reference_size: Current number of reference embeddings (0 if not fitted)

        Used by DataWiringValidator.validate_fit_methodology() to check DOE compliance.
        """
        return {
            'fit_count': self._fit_count,
            'fit_history': self._fit_history.copy(),
            'reference_size': len(self.reference_embeddings) if self.reference_embeddings is not None else 0,
        }

    def _compute_omega_distance(self, embedding: Union[np.ndarray, torch.Tensor]) -> float:
        """
        Compute omega via distance to nearest reference embedding.
        
        Device-aware: handles both numpy and torch inputs efficiently.
        
        Returns:
            omega in [0, 1]: 1.0 = in-distribution, 0.0 = out-of-distribution
        """
        if self.reference_embeddings is None:
            return 0.5  # Uncertain fallback (NOT 1.0!)
        
        # Convert to numpy if tensor (needed for reference comparison)
        if isinstance(embedding, torch.Tensor):
            embedding = embedding.detach().cpu().numpy()
        
        # Compute distance to all reference embeddings
        if embedding.ndim == 1:
            embedding = embedding.reshape(1, -1)
        
        distances = np.linalg.norm(self.reference_embeddings - embedding, axis=1)
        min_distance = float(np.min(distances))
        
        # Convert distance to similarity (omega)
        # exp(-d/scale) gives 1.0 for d=0, decays to 0 for large d
        omega = float(np.exp(-min_distance / self.omega_scale))
        return omega

    def _compute_omega_batch(self, embeddings: Union[np.ndarray, torch.Tensor]) -> np.ndarray:
        """
        Compute omega for batch of embeddings using 1-NN distance.

        Uses minimum distance to reference samples with calibrated scale.

        Returns:
            omega array of shape [B] with values in [0, 1]
        """
        if self.reference_embeddings is None:
            n = len(embeddings) if isinstance(embeddings, np.ndarray) else embeddings.size(0)
            return np.full(n, 0.5)  # Uncertain fallback

        # Convert to numpy if tensor
        if isinstance(embeddings, torch.Tensor):
            embeddings = embeddings.detach().cpu().numpy()

        # Vectorized computation for efficiency
        # [B, D] - [N, D] -> [B, N] distances via broadcasting
        # Use chunked computation for memory efficiency
        batch_size = len(embeddings)
        omegas = np.empty(batch_size, dtype=np.float32)

        chunk_size = min(1000, len(self.reference_embeddings))
        for i in range(batch_size):
            min_dist = float('inf')
            for j in range(0, len(self.reference_embeddings), chunk_size):
                ref_chunk = self.reference_embeddings[j:j+chunk_size]
                dists = np.linalg.norm(ref_chunk - embeddings[i], axis=1)
                chunk_min = np.min(dists)
                if chunk_min < min_dist:
                    min_dist = chunk_min
            omegas[i] = float(np.exp(-min_dist / self.omega_scale))

        return omegas

    def compute_rsn(
        self,
        embedding: Union[np.ndarray, torch.Tensor],
        return_t4: bool = False,
    ) -> Dict[str, float]:
        """
        Compute R/S/N decomposition for an embedding.

        Args:
            embedding: Input embedding [D] or [B, D]

        Returns:
            Dict with R, S, N scores (summing to 1.0)
            
        Note:
            Uses return_scores=True which outputs PROBABILITIES (after softmax).
            This is correct for this use case (we want normalized scores that sum to 1.0).
            Do NOT use this method's output as logits for classification - use
            projection_heads(embedding, return_classification=True) instead.
        """
        # Convert to tensor if needed
        if isinstance(embedding, np.ndarray):
            embedding = torch.from_numpy(embedding).float()

        # Add batch dimension if needed
        if embedding.dim() == 1:
            embedding = embedding.unsqueeze(0)

        # =====================================================================
        # CRITICAL: Validate dimension matches what projection was trained for
        # =====================================================================
        expected_dim = self.config.hidden_dim  # The input dimension
        actual_dim = embedding.shape[-1]
        
        if actual_dim != expected_dim:
            raise ValueError(
                f"\n{'='*70}\n"
                f"❌ DIMENSION MISMATCH - This will produce GARBAGE!\n"
                f"{'='*70}\n"
                f"Expected: {expected_dim}-dim (from checkpoint training)\n"
                f"Received: {actual_dim}-dim (from current model)\n"
                f"\n"
                f"Common causes:\n"
                f"  1. Using wrong checkpoint (e.g., memristor vs cifar)\n"
                f"  2. Model feature_dim doesn't match projection training\n"
                f"  3. Feature extraction layer mismatch\n"
                f"\n"
                f"Fix:\n"
                f"  - Use correct checkpoint for your model\n"
                f"  - Or retrain projection with current model features\n"
                f"{'='*70}\n"
            )

        embedding = embedding.to(self.device)

        with torch.no_grad():
            if self.projection_mode == "rotor":
                # ROTOR mode: get R, S, N + geometric outputs
                output = self.projection_heads(embedding)
                r = output['R'].mean().item()
                s = output['S'].mean().item()
                n = output['N'].mean().item()
                # Geometric outputs
                theta = output.get('theta', None)  # Global learned theta (scalar)
                scale = output.get('scale', None)  # Global learned scale (scalar)
                # Per-sample geometric parameters (averaged if batch > 1)
                sample_theta_tensor = output.get('sample_theta', None)
                sample_radius_tensor = output.get('sample_radius', None)
                sample_theta = float(sample_theta_tensor.mean().item()) if sample_theta_tensor is not None else None
                sample_radius = float(sample_radius_tensor.mean().item()) if sample_radius_tensor is not None else None
            else:
                # MLP mode: use return_scores=True to get normalized probabilities
                output = self.projection_heads(embedding, return_scores=True)
                scores = output['scores'].mean(dim=0)
                r = scores[0].item()
                s = scores[1].item()
                n = scores[2].item()
                theta = None
                scale = None
                sample_theta = None
                sample_radius = None

        # Derived metrics
        alpha = r  # α = R / (R + S + N), but already normalized

        # Omega placeholder - use BaseLearner.compute_omega() for real 7-signal omega
        # This is kept for backward compatibility but experiments should use BaseLearner
        omega = 1.0 - n  # Simple approximation (use BaseLearner for adaptive 7-signal)

        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / max(alpha_omega, 0.01)

        result = {
            'R': r,
            'S': s,
            'N': n,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
            'projection_mode': self.projection_mode,
        }

        # Include geometric params for rotor mode
        if theta is not None:
            result['theta'] = theta
        if scale is not None:
            result['scale'] = scale
        if sample_theta is not None:
            result['sample_theta'] = sample_theta
        if sample_radius is not None:
            result['sample_radius'] = sample_radius

        # Include T⁴ coordinates if requested
        if return_t4:
            from .geometric_utils import compute_t4_coordinates
            # np is already imported at module level
            t4_coords = compute_t4_coordinates(
                np.array([r]),
                np.array([s]),
                np.array([n])
            )
            result['t4_coordinates'] = {
                'simplex_theta': float(t4_coords['simplex_theta'][0]),
                'phi_simplex': float(t4_coords['phi_simplex'][0]),
                'alpha_t4': float(t4_coords['alpha_t4'][0]),
                'omega_t4': float(t4_coords['omega_t4'][0]),
            }

        return result

    def compute_rsn_batch(
        self,
        embeddings: Union[np.ndarray, torch.Tensor],
        return_t4: bool = False,
        **extra_signals,
    ) -> Dict[str, np.ndarray]:
        """
        Compute R/S/N decomposition for a batch of embeddings.

        Args:
            embeddings: Input embeddings [B, D]
            **extra_signals: Additional signals to include in output (pass-through)
                Example: feature_variance=embeddings.var(axis=-1)

        Returns:
            Dict with R, S, N, alpha, omega, tau arrays of shape [B]
            Plus any extra_signals passed in
        """
        if isinstance(embeddings, np.ndarray):
            embeddings = torch.from_numpy(embeddings).float()

        # VALIDATE DIMENSIONS
        expected_dim = self.config.hidden_dim
        actual_dim = embeddings.shape[-1]
        
        if actual_dim != expected_dim:
            raise ValueError(
                f"Dimension mismatch: expected {expected_dim}-dim, got {actual_dim}-dim. "
                f"Use correct checkpoint or retrain projection."
            )

        embeddings = embeddings.to(self.device)

        with torch.no_grad():
            output = self.projection_heads(embeddings, return_scores=True)
            scores = output['scores'].cpu().numpy()

        r = scores[:, 0]
        s = scores[:, 1]
        n = scores[:, 2]

        alpha = r

        # Compute omega: use distance-based if reference embeddings are fitted
        if self.reference_embeddings is not None:
            omega = self._compute_omega_batch(embeddings.cpu().numpy())
        else:
            # Fallback: simple approximation (not recommended for OOD detection)
            omega = 1.0 - n

        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        quality_prior = 0.5
        alpha_omega = alpha * omega + (1 - omega) * quality_prior
        tau = 1.0 / np.maximum(alpha_omega, 0.01)

        result = {
            'R': r,
            'S': s,
            'N': n,
            'alpha': alpha,
            'omega': omega,
            'alpha_omega': alpha_omega,
            'tau': tau,
        }

        # Add any extra signals passed via kwargs
        result.update(extra_signals)

        # Include T⁴ coordinates if requested
        if return_t4:
            from .geometric_utils import compute_t4_coordinates
            t4_coords = compute_t4_coordinates(r, s, n)
            result['t4_simplex_theta'] = t4_coords['simplex_theta']
            result['t4_phi_simplex'] = t4_coords['phi_simplex']
            result['t4_alpha'] = t4_coords['alpha_t4']
            result['t4_omega'] = t4_coords['omega_t4']

        return result

    def compute_rsn_batch_adaptive(
        self,
        embeddings: Union[np.ndarray, torch.Tensor],
        raw_images: Optional[List[np.ndarray]] = None,
        omega_threshold: float = OMEGA_THRESHOLD_FREQUENCY,
        omega_critical: float = OMEGA_CRITICAL,
        return_t4: bool = False,
        **extra_signals,
    ) -> Dict[str, np.ndarray]:
        """
        Adaptive 6D computation that triggers frequency-based signals when omega is low.

        This is the KEY INNOVATION: When model-based omega indicates OOD (low omega),
        we augment with frequency-based signals which are:
        1. Model-independent (work on raw images)
        2. OOD-robust (measure image-level noise/structure)
        3. Complementary (pixel-level vs embedding-level)

        TRIGGER LOGIC:
        - omega >= threshold: Use model-based signals only (standard)
        - omega_critical <= omega < threshold: Blend model + frequency signals
        - omega < omega_critical: Frequency signals dominate (severe OOD)

        Args:
            embeddings: Model features [B, D]
            raw_images: Optional raw images for frequency analysis [B, C, H, W] or list
            omega_threshold: Below this, augment with frequency (default 0.3)
            omega_critical: Below this, frequency dominates (default 0.1)
            **extra_signals: Additional signals to pass through

        Returns:
            Dict with:
            - R, S, N, alpha, omega, tau: Standard 6D tuple
            - freq_triggered: Boolean array indicating frequency fallback
            - omega_model: Original model-based omega
            - omega_freq: Frequency-based alpha (when available)
            - N_freq: Frequency-based noise level (when available)

        Example:
            >>> result = projection.compute_rsn_batch_adaptive(
            ...     embeddings=features,
            ...     raw_images=images,  # Enables frequency fallback
            ... )
            >>> # Check where frequency was triggered
            >>> ood_samples = result['freq_triggered']
        """
        # First: compute standard model-based RSN
        model_result = self.compute_rsn_batch(embeddings, return_t4=return_t4, **extra_signals)

        omega_model = model_result['omega']
        n_samples = len(omega_model)

        # Initialize frequency signals as None
        omega_freq = np.full(n_samples, np.nan)
        N_freq = np.full(n_samples, np.nan)
        freq_triggered = np.zeros(n_samples, dtype=bool)

        # Check if frequency fallback is needed and possible
        needs_frequency = omega_model < omega_threshold

        if raw_images is not None and needs_frequency.any():
            # Initialize frequency computer (lazy)
            if not hasattr(self, '_freq_rsn'):
                self._freq_rsn = FrequencyBasedRSN()

            # Compute frequency signals for low-omega samples
            for i in np.where(needs_frequency)[0]:
                if i < len(raw_images):
                    freq_result = self._freq_rsn.compute_rsn(raw_images[i])
                    omega_freq[i] = freq_result['alpha']  # Frequency alpha as proxy
                    N_freq[i] = freq_result['N']  # Frequency noise level
                    freq_triggered[i] = True

            # KEY INSIGHT: Frequency signals measure IMAGE QUALITY, not DISTRIBUTION.
            # Different datasets have varying quality profiles (some cleaner, some noisier).
            # So we can't use freq_alpha as omega replacement - it conflates quality with OOD.
            #
            # CORRECT APPROACH: Use frequency signals as ADDITIONAL OOD indicators:
            # 1. Keep omega_model as primary signal (embedding distance)
            # 2. Add frequency N as noise penalty (high noise = potentially degraded)
            # 3. Use freq_alpha for quality gating, not OOD detection
            #
            # The frequency trigger itself is the signal: if omega_model is low
            # AND we triggered frequency, we're confident about OOD.

            for i in np.where(freq_triggered)[0]:
                # DO NOT blend omega - keep model-based omega as primary OOD signal
                # The value of frequency is:
                # 1. Confirming low omega (double-check)
                # 2. Providing N_freq for downstream quality analysis
                # 3. Enabling pre-inference gating decisions

                # Optionally penalize omega slightly if frequency N is high
                # (noisy image + low omega = more confident OOD)
                if N_freq[i] > 0.02:  # Above noise floor
                    # Small penalty for noisy images
                    noise_penalty = min(0.1, N_freq[i] * 0.3)
                    model_result['omega'][i] = max(0.0, omega_model[i] - noise_penalty)

                # Update N with frequency information (additive, not replacement)
                # This helps downstream collapse detection
                model_result['N'][i] = max(model_result['N'][i], N_freq[i])

                # Renormalize R+S+N=1
                total = model_result['R'][i] + model_result['S'][i] + model_result['N'][i]
                if total > 0:
                    model_result['R'][i] /= total
                    model_result['S'][i] /= total
                    model_result['N'][i] /= total

                # Update alpha
                model_result['alpha'][i] = model_result['R'][i]

        # Recompute derived signals
        model_result['alpha_omega'] = model_result['alpha'] * model_result['omega']
        model_result['tau'] = 1.0 / np.maximum(model_result['alpha_omega'], 0.01)

        # Add diagnostic signals
        model_result['freq_triggered'] = freq_triggered
        model_result['omega_model'] = omega_model  # Original model omega
        model_result['omega_freq'] = omega_freq  # Frequency alpha (where computed)
        model_result['N_freq'] = N_freq  # Frequency noise (where computed)

        return model_result

    def get_decomposition_score(
        self,
        embedding: Union[np.ndarray, torch.Tensor],
    ) -> DecompositionScore:
        """Get R/S/N as DecompositionScore object."""
        result = self.compute_rsn(embedding)
        return DecompositionScore(
            relevant=result['R'],
            superfluous=result['S'],
            noise=result['N'],
        )

    def forward(self, embedding: np.ndarray) -> Dict[str, Any]:
        """
        Forward pass compatible with YRSNMemristorProjection interface.

        This allows TrainedRSNProjection to be used as a drop-in replacement
        for YRSNMemristorProjection in experiments.
        """
        return self.compute_rsn(embedding)


def load_trained_projection(
    checkpoint_path: Union[str, Path],
    device: Optional[torch.device] = None,
    auto_fit_embeddings: Optional[np.ndarray] = None,
) -> TrainedRSNProjection:
    """
    Load a trained R/S/N projection from checkpoint.

    Args:
        checkpoint_path: Path to .pt checkpoint file
        device: Target device (default: auto-detect)
        auto_fit_embeddings: Optional training embeddings to fit for omega computation

    Returns:
        TrainedRSNProjection ready for use
        
    Note:
        For proper omega (OOD) computation, either:
        1. Use a checkpoint that includes reference_embeddings, OR
        2. Pass auto_fit_embeddings, OR  
        3. Call projection.fit(embeddings) after loading
        
        Without reference embeddings, omega defaults to 0.5 (uncertain).

    Example:
        projection = load_trained_projection('checkpoints/trained_rsn_projection.pt')
        projection.fit(train_embeddings)  # Enable distance-based omega
        result = projection.compute_rsn(embedding)
    """
    checkpoint_path = Path(checkpoint_path)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)

    # Check if this is a rotor checkpoint
    is_rotor = (
        'rotor_variant' in checkpoint or
        'model_state_dict' in checkpoint and
        ('theta' in checkpoint.get('model_state_dict', {}) or
         'encoder.0.weight' in checkpoint.get('model_state_dict', {}))
    )

    if is_rotor:
        # === ROTOR CHECKPOINT ===
        embed_dim = checkpoint.get('embed_dim', 64)
        variant = checkpoint.get('rotor_variant', 'large')

        # Import rotor creation function
        from .hybrid_rotor import create_rotor, RotorVariant

        # Map variant string to enum
        variant_map = {
            'large': RotorVariant.LARGE,
            'compact': RotorVariant.COMPACT,
            'tiny': RotorVariant.TINY,
            'pure': RotorVariant.PURE,
        }
        rotor_variant = variant_map.get(variant, RotorVariant.LARGE)

        # Create rotor model
        projection_heads = create_rotor(embed_dim=embed_dim, variant=rotor_variant)

        # Load state dict
        state_dict = checkpoint.get('model_state_dict', checkpoint)
        projection_heads.load_state_dict(state_dict)

        projection = TrainedRSNProjection(projection_heads, device, projection_mode="rotor")

        print(f"Loaded ROTOR projection from {checkpoint_path}")
        print(f"  Embed dim: {embed_dim}")
        print(f"  Variant: {variant}")
        print(f"  Parameters: {sum(p.numel() for p in projection_heads.parameters()):,}")
        print(f"  Initial theta: {checkpoint.get('theta', 0.0):.1f} degrees")

    else:
        # === MLP CHECKPOINT ===
        config_dict = checkpoint.get('config', {})
        embed_dim = checkpoint.get('embed_dim', config_dict.get('hidden_dim', 256))

        config = ProjectionHeadConfig(
            hidden_dim=embed_dim,
            projection_dim=config_dict.get('projection_dim', 128),
            mode=config_dict.get('mode', 'hybrid'),
            num_layers=config_dict.get('num_layers', 2),
            dropout=config_dict.get('dropout', 0.1),
        )

        # Create and load projection heads
        projection_heads = LearnedYRSNProjectionHeads(config)
        projection_heads.load_state_dict(checkpoint['projection_heads_state_dict'])

        projection = TrainedRSNProjection(projection_heads, device, projection_mode="mlp")

        print(f"Loaded MLP projection from {checkpoint_path}")
        print(f"  Embed dim: {embed_dim}")
        print(f"  Training results: {checkpoint.get('training_results', {}).get('final_accuracy', 'N/A')}")

    # Load reference embeddings if present in checkpoint
    if 'reference_embeddings' in checkpoint:
        projection.reference_embeddings = checkpoint['reference_embeddings']
        projection.omega_scale = checkpoint.get('omega_scale', 1.0)
        print(f"Loaded reference embeddings: {len(projection.reference_embeddings)} samples")

    # Auto-fit if embeddings provided
    if auto_fit_embeddings is not None:
        projection.fit(auto_fit_embeddings)

    print(f"  Omega ready: {projection.reference_embeddings is not None}")
    print(f"  Projection mode: {projection.projection_mode}")

    return projection


def save_projection_with_references(
    projection: TrainedRSNProjection,
    checkpoint_path: Union[str, Path],
    original_checkpoint_path: Optional[Union[str, Path]] = None,
) -> None:
    """
    Save a projection with reference embeddings for omega computation.
    
    Args:
        projection: TrainedRSNProjection with fitted reference_embeddings
        checkpoint_path: Where to save the new checkpoint
        original_checkpoint_path: Original checkpoint to copy metadata from
    """
    checkpoint_path = Path(checkpoint_path)
    
    # Start with original checkpoint data if available
    if original_checkpoint_path and Path(original_checkpoint_path).exists():
        checkpoint = torch.load(original_checkpoint_path, map_location='cpu', weights_only=False)
    else:
        checkpoint = {}
    
    # Update with current state
    checkpoint['projection_heads_state_dict'] = projection.projection_heads.state_dict()
    
    # Save reference embeddings for omega
    if projection.reference_embeddings is not None:
        checkpoint['reference_embeddings'] = projection.reference_embeddings
        checkpoint['omega_scale'] = projection.omega_scale
    
    torch.save(checkpoint, checkpoint_path)
    print(f"Saved projection with references to {checkpoint_path}")


def get_default_projection(
    embed_dim: int = 256,
    device: Optional[torch.device] = None,
    checkpoint_dir: Union[str, Path] = 'checkpoints',
) -> TrainedRSNProjection:
    """
    Get the default trained projection, training if necessary.

    This is a convenience function that:
    1. Tries to load existing checkpoint
    2. If not found, raises error with instructions

    Args:
        embed_dim: Expected embedding dimension
        device: Target device
        checkpoint_dir: Directory containing checkpoints

    Returns:
        TrainedRSNProjection ready for use
    """
    checkpoint_dir = Path(checkpoint_dir)
    checkpoint_path = checkpoint_dir / 'trained_rsn_projection.pt'

    if checkpoint_path.exists():
        return load_trained_projection(checkpoint_path, device)

    # Check other common locations
    alt_paths = [
        Path('trained_rsn_projection.pt'),
        Path('~/.yrsn/trained_rsn_projection.pt').expanduser(),
        Path(__file__).parent.parent.parent.parent.parent / 'checkpoints' / 'trained_rsn_projection.pt',
    ]

    for alt_path in alt_paths:
        if alt_path.exists():
            return load_trained_projection(alt_path, device)

    raise FileNotFoundError(
        f"No trained RSN projection found.\n\n"
        f"Run the training script first:\n"
        f"  python scripts/train_rsn_projection.py --epochs 10\n\n"
        f"Searched locations:\n"
        f"  - {checkpoint_path}\n" +
        "\n".join(f"  - {p}" for p in alt_paths)
    )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'TrainedRSNProjection',
    'load_trained_projection',
    'get_default_projection',
    'save_projection_with_references',
]
