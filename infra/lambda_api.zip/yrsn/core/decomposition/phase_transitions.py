"""
BBP Phase Transitions for Automatic Rank Selection

TERMINOLOGY NOTE:
    "temperature" (τ_α) in this module is YRSN's quality-derived adaptive signal,
    NOT the LLM API temperature. τ_α EMERGES from R/S/N decomposition.

TERMINOLOGY CLARIFICATION:
    This module uses "phase transitions" in the BBP (Baik-Ben Arous-Péché) sense:
    signal eigenvalues emerging from noise bulk at critical thresholds.
    
    This is DIFFERENT from "Quality Phases" in temperature.py:
    - BBP Phase Transitions → Rank selection (how many components)
    - Quality Phases → Temperature mapping (what temperature regime)
    
    Both are valid uses of "phase transition" but in different contexts.

This module implements the Baik-Ben Arous-Péché (BBP) phase transition
framework for automatic rank selection in R/S/N decomposition.

Core Formula:
    α_ℓ = (ℓ-1)/(2ℓ)

Where ℓ is the decomposition depth/rank. When quality α crosses these
thresholds, signal eigenvalues emerge from the noise bulk—a phase transition.

Key insight: Stop increasing rank when α < α_ℓ. The next level won't
recover signal—it will fit noise.

Integration with existing temperature.py:
    - Uses map_quality_to_temperature() for τ = f(α)
    - Uses QualityPhase for phase classification
    - Adds BBP-specific thresholds on top

Reference: Baik, Ben Arous, Péché (2005) - Phase transition of the
largest eigenvalue for nonnull complex sample covariance matrices.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import time
from collections import deque

# Reuse existing temperature infrastructure
from yrsn.core.temperature import (
    map_quality_to_temperature,
    get_quality_phase,
    QualityPhase,
    TAU_CRITICAL_1,
    TAU_CRITICAL_2,
    ALPHA_HIGH_THRESHOLD,
    ALPHA_LOW_THRESHOLD,
)


# =============================================================================
# BBP Threshold Calculation
# =============================================================================

def compute_bbp_threshold(ell: int) -> float:
    """
    Compute BBP critical threshold α_ℓ = (ℓ-1)/(2ℓ).

    This is the minimum quality required to reliably detect ℓ signal
    components above the noise bulk.

    Args:
        ell: Decomposition depth/rank (ℓ ≥ 1)

    Returns:
        Critical quality threshold α_ℓ

    Examples:
        >>> compute_bbp_threshold(1)
        0.0
        >>> compute_bbp_threshold(2)
        0.25
        >>> compute_bbp_threshold(3)
        0.3333333333333333
        >>> compute_bbp_threshold(4)
        0.375
        >>> compute_bbp_threshold(100)
        0.495

    Reference values:
        ℓ=1 → α=0.000 (any signal detectable)
        ℓ=2 → α=0.250 (moderate quality required)
        ℓ=3 → α=0.333 (higher quality threshold)
        ℓ=4 → α=0.375 (approaching asymptote)
        ℓ=∞ → α=0.500 (maximum useful depth)
    """
    if ell < 1:
        raise ValueError(f"Rank ℓ must be >= 1, got {ell}")

    return (ell - 1) / (2 * ell)


def compute_bbp_threshold_inverse(alpha: float) -> int:
    """
    Compute maximum useful rank for given quality α.

    Inverse of α_ℓ = (ℓ-1)/(2ℓ), solving for ℓ:
        α = (ℓ-1)/(2ℓ)
        2αℓ = ℓ - 1
        2αℓ - ℓ = -1
        ℓ(2α - 1) = -1
        ℓ = -1 / (2α - 1) = 1 / (1 - 2α)

    Args:
        alpha: Quality score in [0, 0.5)

    Returns:
        Maximum useful rank (floored to integer)

    Examples:
        >>> compute_bbp_threshold_inverse(0.0)
        1
        >>> compute_bbp_threshold_inverse(0.25)
        2
        >>> compute_bbp_threshold_inverse(0.333)
        3
        >>> compute_bbp_threshold_inverse(0.49)
        50
    """
    if alpha < 0:
        raise ValueError(f"Quality α must be >= 0, got {alpha}")

    if alpha >= 0.5:
        return 1000  # Effective infinity (asymptotic limit)

    if alpha == 0:
        return 1

    # ℓ = 1 / (1 - 2α)
    ell = 1 / (1 - 2 * alpha)
    return max(1, int(ell))


# =============================================================================
# BBP Threshold Table
# =============================================================================

@dataclass
class BBPThresholdTable:
    """
    Precomputed BBP thresholds for efficient lookup.

    Stores α_ℓ values for ranks 1 to max_rank, enabling O(1) lookup
    and reverse lookup (quality → max rank).
    """
    max_rank: int = 100
    thresholds: Dict[int, float] = field(default_factory=dict)
    _inverse_cache: List[Tuple[float, int]] = field(default_factory=list)

    def __post_init__(self):
        if not self.thresholds:
            self._build_table()

    def _build_table(self):
        """Build threshold lookup table."""
        self.thresholds = {
            ell: compute_bbp_threshold(ell)
            for ell in range(1, self.max_rank + 1)
        }
        # Build sorted list for inverse lookup
        self._inverse_cache = sorted(
            [(alpha, ell) for ell, alpha in self.thresholds.items()],
            key=lambda x: x[0]
        )

    @classmethod
    def build(cls, max_rank: int = 100) -> 'BBPThresholdTable':
        """Factory method to build threshold table."""
        return cls(max_rank=max_rank)

    def get_threshold(self, rank: int) -> float:
        """
        Get BBP threshold for given rank.

        Args:
            rank: Decomposition rank

        Returns:
            Critical quality threshold α_ℓ
        """
        if rank < 1:
            raise ValueError(f"Rank must be >= 1, got {rank}")
        if rank > self.max_rank:
            # Compute directly for ranks beyond table
            return compute_bbp_threshold(rank)
        return self.thresholds[rank]

    def get_max_rank_for_quality(self, alpha: float) -> int:
        """
        Get maximum useful rank for given quality.

        Iterates through sorted thresholds to find largest rank
        where α ≥ α_ℓ.

        Args:
            alpha: Quality score in [0, 1)

        Returns:
            Maximum rank where α ≥ α_ℓ
        """
        if alpha < 0:
            return 1
        if alpha >= 0.5:
            return self.max_rank

        # Find largest rank where alpha >= threshold
        max_rank = 1
        for threshold, rank in self._inverse_cache:
            if alpha >= threshold:
                max_rank = rank

        return max_rank

    def get_margin(self, alpha: float, current_rank: int) -> float:
        """
        Get margin between current quality and threshold.

        Positive margin = quality exceeds threshold (safe)
        Negative margin = quality below threshold (at risk)

        Args:
            alpha: Current quality
            current_rank: Current decomposition rank

        Returns:
            Margin (α - α_ℓ)
        """
        threshold = self.get_threshold(current_rank)
        return alpha - threshold

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'max_rank': self.max_rank,
            'thresholds': self.thresholds,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BBPThresholdTable':
        """Create from dictionary."""
        table = cls(max_rank=data['max_rank'])
        table.thresholds = data['thresholds']
        table._build_table()  # Rebuild inverse cache
        return table


# =============================================================================
# Transition Events
# =============================================================================

class TransitionType(Enum):
    """Type of phase transition."""
    UPGRADE = "upgrade"      # Quality improved, can increase rank
    DOWNGRADE = "downgrade"  # Quality degraded, should decrease rank
    STABLE = "stable"        # No significant change


@dataclass
class TransitionEvent:
    """Event emitted when phase transition detected."""
    timestamp: float
    old_rank: int
    new_rank: int
    quality_before: float
    quality_after: float
    transition_type: TransitionType
    confidence: float
    threshold_crossed: float
    margin: float  # How far past threshold

    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'old_rank': self.old_rank,
            'new_rank': self.new_rank,
            'quality_before': self.quality_before,
            'quality_after': self.quality_after,
            'transition_type': self.transition_type.value,
            'confidence': self.confidence,
            'threshold_crossed': self.threshold_crossed,
            'margin': self.margin,
        }


@dataclass
class RankRecommendation:
    """Recommendation from phase transition analysis."""
    recommended_rank: int
    max_useful_rank: int
    current_quality: float
    threshold_for_current: float
    margin: float
    action: str  # "increase", "decrease", "maintain"
    confidence: float
    reasoning: str


# =============================================================================
# Phase Transition Detector
# =============================================================================

class PhaseTransitionDetector:
    """
    Detect when quality α crosses BBP critical thresholds.

    Monitors quality metric over time and detects:
    1. Upward transitions (quality improving → can increase rank)
    2. Downward transitions (quality degrading → should decrease rank)
    3. Stability (quality stable → maintain current rank)

    Uses hysteresis to prevent oscillation from noise.
    """

    def __init__(
        self,
        bbp_table: Optional[BBPThresholdTable] = None,
        window_size: int = 100,
        transition_threshold: float = 0.05,
        hysteresis: float = 0.02,
        min_samples_for_transition: int = 10,
    ):
        """
        Initialize phase transition detector.

        Args:
            bbp_table: Precomputed BBP thresholds (created if None)
            window_size: Size of quality history window
            transition_threshold: Minimum change to trigger transition
            hysteresis: Buffer zone to prevent oscillation
            min_samples_for_transition: Minimum samples before detecting
        """
        self.bbp_table = bbp_table or BBPThresholdTable.build()
        self.window_size = window_size
        self.transition_threshold = transition_threshold
        self.hysteresis = hysteresis
        self.min_samples = min_samples_for_transition

        # State
        self.quality_history: deque = deque(maxlen=window_size)
        self.current_rank: int = 1
        self.last_transition_time: float = 0
        self.transition_cooldown: float = 1.0  # Seconds between transitions
        self.events: List[TransitionEvent] = []

    def update(
        self,
        alpha: float,
        current_rank: Optional[int] = None,
    ) -> Optional[TransitionEvent]:
        """
        Update detector with new quality measurement.

        Args:
            alpha: Current quality score
            current_rank: Current rank (uses internal state if None)

        Returns:
            TransitionEvent if transition detected, None otherwise
        """
        now = time.time()

        if current_rank is not None:
            self.current_rank = current_rank

        # Store quality
        self.quality_history.append((now, alpha))

        # Need minimum samples
        if len(self.quality_history) < self.min_samples:
            return None

        # Check cooldown
        if now - self.last_transition_time < self.transition_cooldown:
            return None

        # Analyze for transition
        event = self._detect_transition(alpha)

        if event is not None:
            self.last_transition_time = now
            self.current_rank = event.new_rank
            self.events.append(event)

        return event

    def _detect_transition(self, current_alpha: float) -> Optional[TransitionEvent]:
        """Detect if a phase transition has occurred."""
        now = time.time()

        # Get threshold for current rank
        current_threshold = self.bbp_table.get_threshold(self.current_rank)

        # Get threshold for next rank up
        next_threshold = self.bbp_table.get_threshold(self.current_rank + 1)

        # Get recent average quality
        recent_alphas = [a for _, a in list(self.quality_history)[-self.min_samples:]]
        avg_alpha = np.mean(recent_alphas)
        std_alpha = np.std(recent_alphas) if len(recent_alphas) > 1 else 0

        # Check for upgrade (can increase rank)
        if (avg_alpha > next_threshold + self.hysteresis and
            current_alpha > next_threshold and
            std_alpha < self.transition_threshold):

            new_rank = self.bbp_table.get_max_rank_for_quality(avg_alpha)
            new_rank = min(new_rank, self.current_rank + 1)  # Increment by 1 max

            if new_rank > self.current_rank:
                confidence = min(1.0, (avg_alpha - next_threshold) / 0.1)
                return TransitionEvent(
                    timestamp=now,
                    old_rank=self.current_rank,
                    new_rank=new_rank,
                    quality_before=self.quality_history[-2][1] if len(self.quality_history) > 1 else avg_alpha,
                    quality_after=current_alpha,
                    transition_type=TransitionType.UPGRADE,
                    confidence=confidence,
                    threshold_crossed=next_threshold,
                    margin=avg_alpha - next_threshold,
                )

        # Check for downgrade (should decrease rank)
        if (avg_alpha < current_threshold - self.hysteresis and
            self.current_rank > 1):

            # Find appropriate lower rank
            new_rank = self.bbp_table.get_max_rank_for_quality(avg_alpha)
            new_rank = max(1, min(new_rank, self.current_rank - 1))

            if new_rank < self.current_rank:
                confidence = min(1.0, (current_threshold - avg_alpha) / 0.1)
                return TransitionEvent(
                    timestamp=now,
                    old_rank=self.current_rank,
                    new_rank=new_rank,
                    quality_before=self.quality_history[-2][1] if len(self.quality_history) > 1 else avg_alpha,
                    quality_after=current_alpha,
                    transition_type=TransitionType.DOWNGRADE,
                    confidence=confidence,
                    threshold_crossed=current_threshold,
                    margin=avg_alpha - current_threshold,
                )

        return None

    def get_recommended_rank(self, alpha: float) -> RankRecommendation:
        """
        Get recommended rank based on current quality.

        Args:
            alpha: Current quality score

        Returns:
            RankRecommendation with detailed analysis
        """
        max_rank = self.bbp_table.get_max_rank_for_quality(alpha)
        current_threshold = self.bbp_table.get_threshold(self.current_rank)
        margin = alpha - current_threshold

        if max_rank > self.current_rank:
            action = "increase"
            reasoning = f"Quality α={alpha:.3f} exceeds threshold for rank {max_rank}"
        elif max_rank < self.current_rank:
            action = "decrease"
            reasoning = f"Quality α={alpha:.3f} below threshold for current rank {self.current_rank}"
        else:
            action = "maintain"
            reasoning = f"Quality α={alpha:.3f} appropriate for current rank {self.current_rank}"

        # Confidence based on margin
        confidence = min(1.0, abs(margin) / 0.1) if margin != 0 else 0.5

        return RankRecommendation(
            recommended_rank=max_rank,
            max_useful_rank=max_rank,
            current_quality=alpha,
            threshold_for_current=current_threshold,
            margin=margin,
            action=action,
            confidence=confidence,
            reasoning=reasoning,
        )

    def get_quality_stats(self) -> Dict[str, float]:
        """Get statistics on quality history."""
        if not self.quality_history:
            return {'mean': 0, 'std': 0, 'min': 0, 'max': 0, 'count': 0}

        alphas = [a for _, a in self.quality_history]
        return {
            'mean': np.mean(alphas),
            'std': np.std(alphas) if len(alphas) > 1 else 0,
            'min': np.min(alphas),
            'max': np.max(alphas),
            'count': len(alphas),
            'current_rank': self.current_rank,
            'current_threshold': self.bbp_table.get_threshold(self.current_rank),
        }

    def reset(self):
        """Reset detector state."""
        self.quality_history.clear()
        self.current_rank = 1
        self.last_transition_time = 0
        self.events.clear()


# =============================================================================
# Convenience Functions
# =============================================================================

def get_bbp_reference_table() -> Dict[int, float]:
    """
    Get reference table of BBP thresholds for common ranks.

    Returns:
        Dict mapping rank to threshold
    """
    return {
        1: 0.000,
        2: 0.250,
        3: 0.333,
        4: 0.375,
        5: 0.400,
        10: 0.450,
        20: 0.475,
        50: 0.490,
        100: 0.495,
    }


def quality_supports_rank(alpha: float, rank: int) -> bool:
    """
    Check if quality α supports decomposition at given rank.

    Args:
        alpha: Quality score
        rank: Desired rank

    Returns:
        True if α ≥ α_ℓ for this rank
    """
    threshold = compute_bbp_threshold(rank)
    return alpha >= threshold


def get_rank_headroom(alpha: float, current_rank: int) -> int:
    """
    Get how many more ranks the current quality can support.

    Args:
        alpha: Current quality
        current_rank: Current rank

    Returns:
        Number of additional ranks quality can support
    """
    max_rank = compute_bbp_threshold_inverse(alpha)
    return max(0, max_rank - current_rank)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Core functions
    'compute_bbp_threshold',
    'compute_bbp_threshold_inverse',
    'quality_supports_rank',
    'get_rank_headroom',
    'get_bbp_reference_table',

    # Classes
    'BBPThresholdTable',
    'PhaseTransitionDetector',
    'TransitionType',
    'TransitionEvent',
    'RankRecommendation',
]
