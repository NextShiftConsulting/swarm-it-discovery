"""
Ω Policy Framework - Tiered Risk Management for Geometric Compatibility

Ω is the geometric firewall between perception and reasoning.
When it lies, everything lies.

This module implements tiered ω policies that control WHAT YOU DO when ω is
low or ambiguous - without changing WHAT ω MEANS.

ARCHITECTURE:
------------
                    ┌─────────────────────────────────────────┐
                    │           Policy Resolution             │
                    │                                         │
                    │  (consumer_tier, env_tier) → ω_level   │
                    │                                         │
                    │  ω_level + ω_value → action            │
                    └─────────────────────────────────────────┘

CONSUMER TIERS:
--------------
- Tier A (Safety-Critical): Compliance, approvals, irreversible actions
- Tier B (Business-Critical): Analyst workflows, batch reporting
- Tier C (Exploratory): Research sandbox, prototyping, demos
- Tier D (Physical): Memristor, neuromorphic, analog hardware

ENVIRONMENT TIERS:
-----------------
- Env 1 (Stable): Controlled inputs, predictable distributions
- Env 2 (Variable): New domains, shifting data, inconsistent formatting
- Env 3 (Hostile): Untrusted inputs, adversarial patterns, frequent drift

Ω POLICY LEVELS:
---------------
- Ω-L0 (Minimal): ω₀ only, no hard gate, heavy logging
- Ω-L1 (Adaptive): ω₀ gate + borderline refinement + alternate encoding
- Ω-L2 (Strict): Full checks + safe fallback ladder + audits
- Ω-L3 (Physical): Hardware-mandatory gating, no fallback after commit

THEORY ALIGNMENT:
----------------
From "Intelligence as Representation-Solver Compatibility":
    ω = κ(E, S) = geometric compatibility

For software solvers: ω measures "will this work well?"
For physical solvers: ω measures "can this exist stably on hardware?"

This module preserves the ICML framing while enabling production deployment.
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Callable, Any, Tuple
import json
from pathlib import Path


# =============================================================================
# Enums: Consumer Tiers, Environment Tiers, Policy Levels
# =============================================================================

class ConsumerTier(Enum):
    """Risk classification for consumers/tenants."""
    A = "safety_critical"    # Compliance, approvals, irreversible
    B = "business_critical"  # Analyst workflows, batch reporting
    C = "exploratory"        # Research, prototyping, demos
    D = "physical"           # Memristor, neuromorphic, analog hardware


class EnvironmentTier(Enum):
    """Stability classification for execution environments."""
    STABLE = 1    # Controlled inputs, predictable distributions
    VARIABLE = 2  # New domains, shifting data, inconsistent formatting
    HOSTILE = 3   # Untrusted inputs, adversarial patterns, drift


class OmegaLevel(Enum):
    """ω policy strictness levels."""
    L0_MINIMAL = 0   # ω₀ only, no hard gate, heavy logging
    L1_ADAPTIVE = 1  # ω₀ gate + borderline refinement + alternate encoding
    L2_STRICT = 2    # Full checks + safe fallback ladder + audits
    L3_PHYSICAL = 3  # Hardware-mandatory gating, no fallback after commit


class FallbackAction(Enum):
    """Actions in the fallback ladder."""
    PROCEED = auto()           # ω high enough, proceed normally
    RE_ENCODE = auto()         # Canonicalize / alternative encoding view
    SWITCH_GEAR = auto()       # Lower-risk inference mode
    SWITCH_BACKEND = auto()    # Symbolic / brute force / constrained
    RETURN_PRIOR = auto()      # Return prior + explanation
    QUARANTINE = auto()        # Flag for human review
    SIMULATE_FIRST = auto()    # Digital twin before hardware (Tier D)
    REJECT = auto()            # Hard rejection, do not proceed


# =============================================================================
# Threshold Configuration
# =============================================================================

@dataclass
class OmegaThresholds:
    """
    ω thresholds for a specific policy level.

    T_low: Below this, hard fallback (unless L0)
    T_high: Above this, proceed normally
    Borderline [T_low, T_high]: Triggers refinement/re-encode
    """
    t_low: float
    t_high: float

    def classify(self, omega: float) -> str:
        """Classify ω into low/borderline/high."""
        if omega < self.t_low:
            return "low"
        elif omega >= self.t_high:
            return "high"
        else:
            return "borderline"


# Default thresholds per consumer tier
DEFAULT_THRESHOLDS: Dict[ConsumerTier, OmegaThresholds] = {
    ConsumerTier.A: OmegaThresholds(t_low=0.35, t_high=0.70),  # Strict
    ConsumerTier.B: OmegaThresholds(t_low=0.25, t_high=0.60),  # Balanced
    ConsumerTier.C: OmegaThresholds(t_low=0.15, t_high=0.50),  # Permissive
    ConsumerTier.D: OmegaThresholds(t_low=0.40, t_high=0.75),  # Hardware-strict
}


# =============================================================================
# Policy Configuration
# =============================================================================

@dataclass
class OmegaPolicy:
    """
    Complete ω policy for a consumer×environment combination.

    This determines:
    - Which ω signals to compute (ω₀, ω₁, ω₂, ω₃, ω₄)
    - What thresholds to use
    - What actions to take at each ω level
    - What to log
    """
    name: str
    consumer_tier: ConsumerTier
    environment_tier: EnvironmentTier
    omega_level: OmegaLevel
    thresholds: OmegaThresholds

    # Which ω signals to compute
    compute_mahalanobis: bool = True      # ω₁ - always on
    compute_norm: bool = True              # ω₃ - always on
    compute_templates: bool = False        # ω₂ - L1+
    compute_cka: bool = False              # ω₄ - L2+ borderline only

    # Fallback behavior
    fallback_ladder: List[FallbackAction] = field(default_factory=list)
    require_human_review_below: Optional[float] = None

    # Logging
    log_full_decomposition: bool = True
    log_raw_embeddings: bool = False
    sample_rate: float = 1.0  # 1.0 = log all, 0.1 = sample 10%

    # Hardware-specific (Tier D)
    simulate_before_commit: bool = False
    hardware_gate_mandatory: bool = False

    def get_action(self, omega: float, omega_decomposition: Dict[str, float]) -> FallbackAction:
        """
        Determine action based on ω value.

        Args:
            omega: Combined ω value [0, 1]
            omega_decomposition: Individual ω signals for debugging

        Returns:
            FallbackAction to take
        """
        classification = self.thresholds.classify(omega)

        if classification == "high":
            return FallbackAction.PROCEED

        elif classification == "borderline":
            # For borderline, try re-encoding first
            if FallbackAction.RE_ENCODE in self.fallback_ladder:
                return FallbackAction.RE_ENCODE
            elif FallbackAction.SWITCH_GEAR in self.fallback_ladder:
                return FallbackAction.SWITCH_GEAR
            else:
                return FallbackAction.PROCEED  # L0 behavior

        else:  # low
            if self.omega_level == OmegaLevel.L0_MINIMAL:
                # L0: Log but proceed (permissive)
                return FallbackAction.PROCEED

            elif self.omega_level == OmegaLevel.L3_PHYSICAL:
                # Physical: Hard reject, never proceed with bad ω
                return FallbackAction.REJECT

            else:
                # L1/L2: Walk the fallback ladder
                if self.require_human_review_below and omega < self.require_human_review_below:
                    return FallbackAction.QUARANTINE

                # Return first available fallback
                for action in self.fallback_ladder:
                    if action not in [FallbackAction.PROCEED]:
                        return action

                return FallbackAction.RETURN_PRIOR

    def to_dict(self) -> Dict[str, Any]:
        """Serialize policy to dict for config files."""
        return {
            "name": self.name,
            "consumer_tier": self.consumer_tier.value,
            "environment_tier": self.environment_tier.value,
            "omega_level": self.omega_level.name,
            "thresholds": {
                "t_low": self.thresholds.t_low,
                "t_high": self.thresholds.t_high,
            },
            "compute": {
                "mahalanobis": self.compute_mahalanobis,
                "norm": self.compute_norm,
                "templates": self.compute_templates,
                "cka": self.compute_cka,
            },
            "fallback_ladder": [a.name for a in self.fallback_ladder],
            "logging": {
                "full_decomposition": self.log_full_decomposition,
                "raw_embeddings": self.log_raw_embeddings,
                "sample_rate": self.sample_rate,
            },
            "hardware": {
                "simulate_before_commit": self.simulate_before_commit,
                "gate_mandatory": self.hardware_gate_mandatory,
            },
        }


# =============================================================================
# Policy Factory: The Matrix
# =============================================================================

def create_default_policy(
    consumer_tier: ConsumerTier,
    environment_tier: EnvironmentTier,
) -> OmegaPolicy:
    """
    Create default policy based on consumer×environment matrix.

    Matrix:
    -------
    Tier A (Safety-Critical):
        Env 1: Ω-L2
        Env 2: Ω-L2 + quarantine for low-ω
        Env 3: Ω-L2 + always require alternate encoding OR human review

    Tier B (Business-Critical):
        Env 1: Ω-L1
        Env 2: Ω-L1 + tighter drift monitor
        Env 3: Ω-L2-lite (strict gating, fewer expensive checks)

    Tier C (Exploratory):
        Env 1: Ω-L0
        Env 2: Ω-L0 + sampling audits
        Env 3: Ω-L1 (avoid wasting compute, keep permissive)

    Tier D (Physical):
        All Envs: Ω-L3 (mandatory hardware gating)
    """
    thresholds = DEFAULT_THRESHOLDS[consumer_tier]

    # Standard fallback ladder
    standard_ladder = [
        FallbackAction.RE_ENCODE,
        FallbackAction.SWITCH_GEAR,
        FallbackAction.SWITCH_BACKEND,
        FallbackAction.RETURN_PRIOR,
        FallbackAction.QUARANTINE,
    ]

    # Hardware fallback ladder (Tier D)
    hardware_ladder = [
        FallbackAction.RE_ENCODE,
        FallbackAction.SIMULATE_FIRST,
        FallbackAction.SWITCH_BACKEND,  # Fall back to digital
        FallbackAction.REJECT,
    ]

    # Tier D: Physical solvers - always Ω-L3
    if consumer_tier == ConsumerTier.D:
        return OmegaPolicy(
            name=f"physical_{environment_tier.name.lower()}",
            consumer_tier=consumer_tier,
            environment_tier=environment_tier,
            omega_level=OmegaLevel.L3_PHYSICAL,
            thresholds=thresholds,
            compute_mahalanobis=True,
            compute_norm=True,
            compute_templates=True,  # Always check known-stable patterns
            compute_cka=True,        # Full alignment check for hardware
            fallback_ladder=hardware_ladder,
            require_human_review_below=None,  # No human review - just reject
            log_full_decomposition=True,
            log_raw_embeddings=True,  # Keep for hardware debugging
            sample_rate=1.0,
            simulate_before_commit=True,
            hardware_gate_mandatory=True,
        )

    # Tier A: Safety-Critical
    if consumer_tier == ConsumerTier.A:
        if environment_tier == EnvironmentTier.STABLE:
            return OmegaPolicy(
                name="safety_critical_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L2_STRICT,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return OmegaPolicy(
                name="safety_critical_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L2_STRICT,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                require_human_review_below=0.25,  # Quarantine very low ω
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        else:  # HOSTILE
            return OmegaPolicy(
                name="safety_critical_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L2_STRICT,
                thresholds=OmegaThresholds(t_low=0.40, t_high=0.75),  # Tighter
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=True,
                fallback_ladder=standard_ladder,
                require_human_review_below=0.60,  # Human review unless high ω
                log_full_decomposition=True,
                log_raw_embeddings=True,
                sample_rate=1.0,
            )

    # Tier B: Business-Critical
    if consumer_tier == ConsumerTier.B:
        if environment_tier == EnvironmentTier.STABLE:
            return OmegaPolicy(
                name="business_critical_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,  # No CKA for L1
                fallback_ladder=standard_ladder[:3],  # Shorter ladder
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return OmegaPolicy(
                name="business_critical_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,
                fallback_ladder=standard_ladder[:4],
                log_full_decomposition=True,
                sample_rate=1.0,
            )
        else:  # HOSTILE
            # L2-lite: strict gating but fewer expensive checks
            return OmegaPolicy(
                name="business_critical_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L2_STRICT,
                thresholds=OmegaThresholds(t_low=0.30, t_high=0.65),
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,  # Skip CKA for cost
                fallback_ladder=standard_ladder,
                log_full_decomposition=True,
                sample_rate=1.0,
            )

    # Tier C: Exploratory
    if consumer_tier == ConsumerTier.C:
        if environment_tier == EnvironmentTier.STABLE:
            return OmegaPolicy(
                name="exploratory_stable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L0_MINIMAL,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=False,
                compute_cka=False,
                fallback_ladder=[],  # No fallback, just log
                log_full_decomposition=True,
                sample_rate=1.0,  # Log everything for learning
            )
        elif environment_tier == EnvironmentTier.VARIABLE:
            return OmegaPolicy(
                name="exploratory_variable",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L0_MINIMAL,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=False,
                compute_cka=False,
                fallback_ladder=[],
                log_full_decomposition=True,
                sample_rate=0.1,  # Sample to avoid storage blowup
            )
        else:  # HOSTILE
            # Upgrade to L1 to avoid wasting compute
            return OmegaPolicy(
                name="exploratory_hostile",
                consumer_tier=consumer_tier,
                environment_tier=environment_tier,
                omega_level=OmegaLevel.L1_ADAPTIVE,
                thresholds=thresholds,
                compute_mahalanobis=True,
                compute_norm=True,
                compute_templates=True,
                compute_cka=False,
                fallback_ladder=standard_ladder[:2],
                log_full_decomposition=True,
                sample_rate=0.1,
            )

    # Fallback: L1 Adaptive
    return OmegaPolicy(
        name="default",
        consumer_tier=consumer_tier,
        environment_tier=environment_tier,
        omega_level=OmegaLevel.L1_ADAPTIVE,
        thresholds=thresholds,
        compute_mahalanobis=True,
        compute_norm=True,
        compute_templates=True,
        compute_cka=False,
        fallback_ladder=standard_ladder[:3],
        log_full_decomposition=True,
        sample_rate=1.0,
    )


# =============================================================================
# Policy Registry: Load from Config
# =============================================================================

class OmegaPolicyRegistry:
    """
    Registry for named ω policies.

    Policies can be:
    - Created from consumer×environment matrix (default)
    - Loaded from config file
    - Registered programmatically

    Usage:
        >>> registry = OmegaPolicyRegistry()
        >>> policy = registry.get("tenant_financial_approval")
        >>> action = policy.get_action(omega=0.45, decomposition={})
    """

    def __init__(self):
        self._policies: Dict[str, OmegaPolicy] = {}
        self._tenant_mapping: Dict[str, str] = {}  # tenant_id → policy_name

    def register(self, policy: OmegaPolicy):
        """Register a policy by name."""
        self._policies[policy.name] = policy

    def get(self, name: str) -> OmegaPolicy:
        """Get policy by name."""
        if name not in self._policies:
            raise KeyError(f"Policy '{name}' not found. Available: {list(self._policies.keys())}")
        return self._policies[name]

    def get_for_tenant(self, tenant_id: str) -> OmegaPolicy:
        """Get policy for a specific tenant."""
        if tenant_id not in self._tenant_mapping:
            # Default to business_critical_stable
            return create_default_policy(ConsumerTier.B, EnvironmentTier.STABLE)
        return self.get(self._tenant_mapping[tenant_id])

    def map_tenant(self, tenant_id: str, policy_name: str):
        """Map a tenant to a policy."""
        if policy_name not in self._policies:
            raise KeyError(f"Policy '{policy_name}' not found")
        self._tenant_mapping[tenant_id] = policy_name

    def load_from_config(self, config_path: Path):
        """
        Load policies from YAML/JSON config file.

        Expected format:
        ```yaml
        policies:
          tenant_financial_approval:
            consumer_tier: A
            environment_tier: STABLE
            omega_level: L2
            thresholds:
              t_low: 0.35
              t_high: 0.70

        tenant_mapping:
          tenant_123: tenant_financial_approval
          tenant_456: exploratory_stable
        ```
        """
        import yaml

        with open(config_path) as f:
            if config_path.suffix in ['.yaml', '.yml']:
                config = yaml.safe_load(f)
            else:
                config = json.load(f)

        # Load policies
        for name, spec in config.get('policies', {}).items():
            consumer_tier = ConsumerTier[spec.get('consumer_tier', 'B').upper()]
            env_tier = EnvironmentTier[spec.get('environment_tier', 'STABLE').upper()]

            # Start with default, then override
            policy = create_default_policy(consumer_tier, env_tier)
            policy.name = name

            # Override thresholds if specified
            if 'thresholds' in spec:
                policy.thresholds = OmegaThresholds(
                    t_low=spec['thresholds'].get('t_low', policy.thresholds.t_low),
                    t_high=spec['thresholds'].get('t_high', policy.thresholds.t_high),
                )

            # Override omega level if specified
            if 'omega_level' in spec:
                level_name = spec['omega_level']
                if not level_name.startswith('L'):
                    level_name = f"L{level_name}_"
                for level in OmegaLevel:
                    if level_name in level.name:
                        policy.omega_level = level
                        break

            self.register(policy)

        # Load tenant mapping
        for tenant_id, policy_name in config.get('tenant_mapping', {}).items():
            self._tenant_mapping[tenant_id] = policy_name

    def create_default_policies(self):
        """Create and register all default matrix policies."""
        for consumer in ConsumerTier:
            for env in EnvironmentTier:
                policy = create_default_policy(consumer, env)
                self.register(policy)

    def export_config(self, path: Path):
        """Export current policies to config file."""
        config = {
            'policies': {
                name: policy.to_dict()
                for name, policy in self._policies.items()
            },
            'tenant_mapping': self._tenant_mapping,
        }

        with open(path, 'w') as f:
            json.dump(config, f, indent=2)


# =============================================================================
# Decision Table: (tier, env, ω-bin) → action
# =============================================================================

def get_decision_table() -> Dict[Tuple[str, str, str], str]:
    """
    Generate decision table mapping (tier, env, ω-bin) → action.

    This is for documentation/engineering reference.

    Returns:
        Dict mapping (consumer_tier, env_tier, omega_bin) → action_name
    """
    table = {}

    for consumer in ConsumerTier:
        for env in EnvironmentTier:
            policy = create_default_policy(consumer, env)

            for omega_bin in ["low", "borderline", "high"]:
                # Simulate ω values for each bin
                if omega_bin == "low":
                    omega = 0.1
                elif omega_bin == "borderline":
                    omega = (policy.thresholds.t_low + policy.thresholds.t_high) / 2
                else:
                    omega = 0.9

                action = policy.get_action(omega, {})
                table[(consumer.value, env.name, omega_bin)] = action.name

    return table


def print_decision_table():
    """Print decision table in human-readable format."""
    table = get_decision_table()

    print("=" * 80)
    print("Ω DECISION TABLE: (consumer_tier, env_tier, ω-bin) → action")
    print("=" * 80)
    print(f"{'Consumer':<20} {'Environment':<12} {'ω-bin':<12} {'Action':<20}")
    print("-" * 80)

    for (consumer, env, omega_bin), action in sorted(table.items()):
        print(f"{consumer:<20} {env:<12} {omega_bin:<12} {action:<20}")


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    # Enums
    'ConsumerTier',
    'EnvironmentTier',
    'OmegaLevel',
    'FallbackAction',
    # Classes
    'OmegaThresholds',
    'OmegaPolicy',
    'OmegaPolicyRegistry',
    # Functions
    'create_default_policy',
    'get_decision_table',
    'print_decision_table',
    # Constants
    'DEFAULT_THRESHOLDS',
]


if __name__ == "__main__":
    # Demo: print the decision table
    print_decision_table()

    print("\n" + "=" * 80)
    print("EXAMPLE POLICY RESOLUTION")
    print("=" * 80)

    # Create registry with defaults
    registry = OmegaPolicyRegistry()
    registry.create_default_policies()

    # Demo: Safety-critical tenant in hostile environment
    policy = create_default_policy(ConsumerTier.A, EnvironmentTier.HOSTILE)
    print(f"\nPolicy: {policy.name}")
    print(f"  Level: {policy.omega_level.name}")
    print(f"  Thresholds: low={policy.thresholds.t_low}, high={policy.thresholds.t_high}")
    print(f"  Human review below: {policy.require_human_review_below}")

    # Test actions at different ω values
    for omega in [0.2, 0.5, 0.8]:
        action = policy.get_action(omega, {})
        print(f"  ω={omega:.1f} → {action.name}")

    print("\n" + "=" * 80)
    print("MEMRISTOR POLICY (Tier D)")
    print("=" * 80)

    hw_policy = create_default_policy(ConsumerTier.D, EnvironmentTier.VARIABLE)
    print(f"\nPolicy: {hw_policy.name}")
    print(f"  Level: {hw_policy.omega_level.name}")
    print(f"  Hardware gate mandatory: {hw_policy.hardware_gate_mandatory}")
    print(f"  Simulate before commit: {hw_policy.simulate_before_commit}")
    print(f"  Fallback ladder: {[a.name for a in hw_policy.fallback_ladder]}")

    for omega in [0.2, 0.5, 0.8]:
        action = hw_policy.get_action(omega, {})
        print(f"  ω={omega:.1f} → {action.name}")
