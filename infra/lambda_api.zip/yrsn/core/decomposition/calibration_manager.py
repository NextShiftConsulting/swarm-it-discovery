"""
YRSN Calibration Manager
========================

Manages the "Drift-Reset" mechanism for YRSN projection heads.

The Problem:
- Weight-derived projection heads (fast) may drift from actual activations
- Robust PCA on activations (accurate) is too slow for real-time
- Need a hybrid: fast by default, recalibrate when drift detected

The Solution:
- CalibrationManager wraps YRSNProjectionHeads
- Monitors for "muddy" R/S/N distributions or repeated collapse
- Triggers recalibration from activation buffer when needed
- Hot-swaps projection weights without stopping inference

Architecture:
┌─────────────────────────────────────────────────────────────────┐
│                    CalibrationManager                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │ FastPath     │    │ DriftMonitor │    │ SlowPath     │      │
│  │ (Projections)│◄───│ (Trigger)    │───►│ (RobustPCA)  │      │
│  └──────────────┘    └──────────────┘    └──────────────┘      │
│         │                   │                   │               │
│         ▼                   ▼                   ▼               │
│  Weight-derived      Watches R/S/N       Recalibrates from     │
│  O(n²) per token     distributions       activation buffer     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

Usage:
    from yrsn.core.decomposition import CalibrationManager

    manager = CalibrationManager(hidden_dim=256)
    manager.initialize_from_model(model, device)

    # During inference
    metrics = manager.compute_metrics(hidden_states)
    # Automatically triggers recalibration if drift detected
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, Dict, Any, List, Deque
from collections import deque
import time

import torch
import torch.nn as nn
import numpy as np


class CalibrationState(Enum):
    """Current state of the calibration system."""
    WEIGHT_DERIVED = auto()    # Using projections derived from model weights
    DATA_CALIBRATED = auto()   # Using projections calibrated from recent data
    RECALIBRATING = auto()     # Currently running recalibration


@dataclass
class CalibrationConfig:
    """Configuration for drift detection and recalibration triggers."""

    # Buffer settings
    buffer_size: int = 256              # Number of hidden states to keep
    min_samples_for_calibration: int = 64  # Minimum samples needed

    # Drift detection thresholds
    muddy_threshold: float = 0.15       # Max deviation from uniform (0.33) before "muddy"
    confusion_streak_trigger: int = 5   # Consecutive confusion states to trigger
    variance_threshold: float = 0.02    # Min variance in R/S/N (below = muddy)

    # Recalibration settings
    cooldown_seconds: float = 10.0      # Min time between recalibrations
    auto_recalibrate: bool = True       # Enable automatic recalibration

    # Robust PCA settings (for slow path)
    rpca_rank: int = 64                 # Target rank for low-rank component
    rpca_sparse_threshold: float = 0.01 # Threshold for sparse component

    # Topic shift detection (return to generalization)
    topic_shift_noise_threshold: float = 0.40  # High N in calibrated state may be topic shift
    topic_shift_improvement_threshold: float = 0.10  # Generic must be this much better
    enable_topic_shift_detection: bool = True  # Enable automatic return to weights

    # ==========================================================================
    # Statistical Drift Detection (Stage 2 - Confirmation)
    # ==========================================================================
    #
    # Two-Stage Detection Architecture:
    #   Stage 1 (Heuristic): Fast O(1) checks - catches obvious failures
    #   Stage 2 (Statistical): KS test - confirms drift with mathematical rigor
    #
    # Why Both Stages?
    #   - Heuristics alone have false positives (low specificity)
    #   - KS tests alone are expensive (O(W log W)) and need many samples
    #   - Combined: heuristics trigger suspicion, KS confirms => high confidence
    #
    # Kolmogorov-Smirnov Test:
    #   D = max|F_ref(x) - F_cur(x)|  (max CDF deviation)
    #   p-value = P(D > observed | H0: same distribution)
    #   p < 0.05 => reject H0 => significant distributional shift
    #
    # Sample Requirements:
    #   Minimum: ~30 samples for meaningful p-value
    #   Recommended: 50-100 for stable detection
    #   Reference: Saved from training or initial calibration window
    # ==========================================================================
    enable_statistical_drift: bool = True    # Enable KS test confirmation
    ks_significance_level: float = 0.05      # p-value threshold for drift confirmation
    min_samples_for_ks: int = 50             # Minimum samples for KS test
    reference_window_size: int = 100         # Samples to keep as reference distribution


@dataclass
class CalibrationMetrics:
    """Metrics tracking calibration state and history."""

    state: CalibrationState = CalibrationState.WEIGHT_DERIVED
    last_calibration_time: float = 0.0
    calibration_count: int = 0
    confusion_streak: int = 0
    recent_rsn_values: Deque = field(default_factory=lambda: deque(maxlen=20))

    # Performance tracking
    fast_path_calls: int = 0
    slow_path_calls: int = 0
    drift_detections: int = 0
    topic_shift_reversions: int = 0  # Times we reverted due to topic shift

    # ==========================================================================
    # Statistical Drift Detection Metrics (Category 9 Signals)
    # ==========================================================================
    #
    # These track the two-stage drift detection results:
    #   - drift_detected: Stage 1 heuristic triggered (fast, may have false positives)
    #   - drift_confirmed: Stage 2 KS test confirmed (slow, high confidence)
    #
    # KS p-values indicate probability that current and reference distributions
    # are from the same underlying distribution:
    #   p > 0.05: No significant difference (null hypothesis not rejected)
    #   p < 0.05: Significant difference (drift confirmed)
    # ==========================================================================
    drift_confirmed: bool = False           # KS test confirmed drift
    ks_p_value_R: float = 1.0               # p-value for R distribution (1.0 = no drift)
    ks_p_value_S: float = 1.0               # p-value for S distribution
    ks_p_value_N: float = 1.0               # p-value for N distribution
    ks_tests_run: int = 0                   # Number of KS tests performed
    confirmed_drifts: int = 0               # Number of KS-confirmed drifts
    samples_since_calibration: int = 0      # Samples processed since last calibration


class CalibrationManager(nn.Module):
    """
    Manages YRSN projection heads with automatic drift detection and recalibration.

    Provides the "Self-Calibrating YRSN Loop":
    - Fast path (99%): Use weight-derived projections
    - Slow path (1%): Recalibrate from activation buffer when drift detected

    Args:
        hidden_dim: Dimension of hidden states
        config: CalibrationConfig with thresholds and settings
    """

    def __init__(
        self,
        hidden_dim: int,
        projection_dim: Optional[int] = None,
        config: Optional[CalibrationConfig] = None
    ):
        super().__init__()

        self.hidden_dim = hidden_dim
        self.projection_dim = projection_dim or hidden_dim
        self.config = config or CalibrationConfig()

        # Projection heads (will be initialized)
        self.R_head: Optional[nn.Linear] = None
        self.S_head: Optional[nn.Linear] = None
        self.N_head: Optional[nn.Linear] = None

        # Activation buffer for recalibration
        self._activation_buffer: Deque[torch.Tensor] = deque(
            maxlen=self.config.buffer_size
        )

        # Backup of weight-derived projections (for topic shift reversion)
        self._weight_derived_R: Optional[torch.Tensor] = None
        self._weight_derived_S: Optional[torch.Tensor] = None
        self._weight_derived_N: Optional[torch.Tensor] = None

        # State tracking
        self.metrics = CalibrationMetrics()
        self._initialized = False

    def initialize_from_heads(
        self,
        R_head: nn.Linear,
        S_head: nn.Linear,
        N_head: nn.Linear
    ) -> None:
        """
        Initialize from pre-built projection heads.

        This is the preferred method - follows hexagonal architecture by
        accepting projection heads from the adapter layer rather than
        creating them internally.

        Args:
            R_head: Linear projection for Recognition subspace
            S_head: Linear projection for Strangeness subspace
            N_head: Linear projection for Noise subspace
        """
        self.R_head = R_head
        self.S_head = S_head
        self.N_head = N_head

        # Save backup for topic shift reversion
        self._weight_derived_R = self.R_head.weight.data.clone()
        self._weight_derived_S = self.S_head.weight.data.clone()
        self._weight_derived_N = self.N_head.weight.data.clone()

        self.metrics.state = CalibrationState.WEIGHT_DERIVED
        self.metrics.last_calibration_time = time.time()
        self._initialized = True

        print(f"[CalibrationManager] Initialized from projection heads (dim={self.hidden_dim})")

    def initialize_from_model(self, model: nn.Module, device: torch.device) -> None:
        """
        Initialize projection heads from model weights (fast path setup).

        DEPRECATED: This method imports from yrsn.models, violating hexagonal
        architecture. Use initialize_from_heads() instead, with projection
        heads created by an adapter.

        This is the initial "weight-derived" state.
        """
        import warnings
        warnings.warn(
            "initialize_from_model() is deprecated. Use initialize_from_heads() "
            "with projection heads created by an adapter (e.g., from yrsn.adapters).",
            DeprecationWarning,
            stacklevel=2
        )

        # Late import to avoid coupling at module level
        # This should be moved to an adapter in future versions
        from yrsn.models.hrm import YRSNProjectionHeads

        # Create temporary projection heads to derive weights
        temp_heads = YRSNProjectionHeads(
            hidden_dim=self.hidden_dim,
            projection_dim=self.projection_dim,
            use_learned=False
        )
        temp_heads.derive_from_model(model, device)

        # Use the new method
        self.initialize_from_heads(
            R_head=temp_heads.R_head,
            S_head=temp_heads.S_head,
            N_head=temp_heads.N_head
        )

    def add_to_buffer(self, hidden_states: torch.Tensor) -> None:
        """
        Add hidden states to the activation buffer.

        Args:
            hidden_states: [B, L, D] or [B, D] tensor
        """
        # Flatten to [N, D]
        if hidden_states.dim() == 3:
            flat = hidden_states.detach().cpu().view(-1, self.hidden_dim)
        else:
            flat = hidden_states.detach().cpu().view(-1, self.hidden_dim)

        # Add samples to buffer (deque handles max size)
        for i in range(min(flat.size(0), 32)):  # Limit per-call additions
            self._activation_buffer.append(flat[i])

    def compute_metrics(
        self,
        hidden_states: torch.Tensor,
        add_to_buffer: bool = True
    ) -> Dict[str, Any]:
        """
        Compute YRSN metrics with automatic drift detection.

        This is the main entry point. It:
        1. Computes R/S/N using current projection heads (fast)
        2. Checks for drift indicators
        3. Triggers recalibration if needed
        4. Returns metrics

        Args:
            hidden_states: [B, L, D] or [B, D] tensor
            add_to_buffer: Whether to add states to calibration buffer

        Returns:
            Dict with R, S, N, y_score, collapse_risk, calibration_state, etc.
        """
        if not self._initialized:
            raise RuntimeError("CalibrationManager not initialized. Call initialize_from_model() first.")

        # Add to buffer for potential recalibration
        if add_to_buffer:
            self.add_to_buffer(hidden_states)

        # Compute projections (fast path)
        projections = self._project(hidden_states)

        # ⚠️ IMPORTANT: Use per-sample normalization pattern (consistent with yrsn_pipeline.py)
        #
        # WHY: This preserves distribution information across samples. Normalizing per-sample
        #      first, then averaging, is better than computing .norm().mean() which mixes
        #      per-sample and global normalization.
        #
        # ❌ BAD:  R = projections['R'].norm(dim=-1).mean().item()  # WRONG - double reduction
        # ✅ GOOD: Normalize per-sample first, then average (see below)
        R_norm = projections['R'].norm(dim=-1)  # [B] vector (per-sample norms)
        S_norm = projections['S'].norm(dim=-1)  # [B] vector
        N_norm = projections['N'].norm(dim=-1)  # [B] vector

        # Normalize per-sample first (preserves distribution information)
        total_per_sample = R_norm + S_norm + N_norm + 1e-8  # [B] vector
        R_normalized = R_norm / total_per_sample  # [B] vector (per-sample R/S/N)
        S_normalized = S_norm / total_per_sample  # [B] vector
        N_normalized = N_norm / total_per_sample  # [B] vector

        # Average normalized values (gives mean R/S/N across samples)
        R = R_normalized.mean().item()
        S = S_normalized.mean().item()
        N = N_normalized.mean().item()

        # Track for drift detection
        self.metrics.recent_rsn_values.append((R, S, N))
        self.metrics.fast_path_calls += 1

        # Detect collapse
        from yrsn.core.decomposition.collapse import detect_collapse
        collapse_analysis = detect_collapse(R=R, S=S, N=N)

        # Check for drift and trigger recalibration if needed
        drift_detected = self._check_for_drift(R, S, N, collapse_analysis)

        if drift_detected and self.config.auto_recalibrate:
            self._maybe_recalibrate(hidden_states.device)

        # Check for topic shift (overfitting to previous context)
        topic_shift_detected = False
        if self.config.enable_topic_shift_detection:
            topic_shift_detected = self._check_for_topic_shift(
                hidden_states, N, hidden_states.device
            )

        # Compute derived metrics
        y_score = R + 0.5 * S
        collapse_risk = S + 1.5 * N

        return {
            'R': R,
            'S': S,
            'N': N,
            'y_score': y_score,
            'collapse_risk': collapse_risk,
            'collapse_type': collapse_analysis.collapse_type,
            'collapse_severity': collapse_analysis.severity,
            'collapse_analysis': collapse_analysis,
            'calibration_state': self.metrics.state.name,
            'drift_detected': drift_detected,
            'topic_shift_detected': topic_shift_detected,
            'buffer_size': len(self._activation_buffer),
        }

    def _project(self, hidden: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Project hidden states to R/S/N subspaces."""
        is_sequence = hidden.dim() == 3
        if is_sequence:
            B, L, D = hidden.shape
            hidden = hidden.view(B * L, D)

        R_proj = self.R_head(hidden)
        S_proj = self.S_head(hidden)
        N_proj = self.N_head(hidden)

        if is_sequence:
            R_proj = R_proj.view(B, L, -1)
            S_proj = S_proj.view(B, L, -1)
            N_proj = N_proj.view(B, L, -1)

        return {'R': R_proj, 'S': S_proj, 'N': N_proj}

    def _check_for_drift(
        self,
        R: float,
        S: float,
        N: float,
        collapse_analysis
    ) -> bool:
        """
        Check if current R/S/N values indicate drift.

        Drift indicators:
        1. "Muddy" distribution (all values ~0.33)
        2. Repeated confusion states
        3. Low variance in recent values
        """
        from yrsn.core.decomposition.collapse import CollapseType

        # Check 1: Muddy distribution (all near 0.33)
        uniform = 1.0 / 3.0
        max_deviation = max(abs(R - uniform), abs(S - uniform), abs(N - uniform))
        is_muddy = max_deviation < self.config.muddy_threshold

        # Check 2: Confusion streak
        if collapse_analysis.collapse_type == CollapseType.CONFLICT:
            self.metrics.confusion_streak += 1
        else:
            self.metrics.confusion_streak = 0

        confusion_triggered = self.metrics.confusion_streak >= self.config.confusion_streak_trigger

        # Check 3: Low variance in recent values
        low_variance = False
        if len(self.metrics.recent_rsn_values) >= 10:
            recent = list(self.metrics.recent_rsn_values)[-10:]
            r_vals = [v[0] for v in recent]
            s_vals = [v[1] for v in recent]
            n_vals = [v[2] for v in recent]

            r_var = np.var(r_vals)
            s_var = np.var(s_vals)
            n_var = np.var(n_vals)

            low_variance = max(r_var, s_var, n_var) < self.config.variance_threshold

        drift_detected = is_muddy or confusion_triggered or low_variance

        if drift_detected:
            self.metrics.drift_detections += 1

        return drift_detected

    def _confirm_drift_with_ks_test(self) -> bool:
        """
        Stage 2: Statistical confirmation of drift using Kolmogorov-Smirnov test.

        ==========================================================================
        Theoretical Foundation
        ==========================================================================

        The Kolmogorov-Smirnov (KS) test compares two distributions by measuring
        the maximum difference between their empirical cumulative distribution
        functions (ECDFs):

            D = max|F_ref(x) - F_cur(x)|

        Where:
            F_ref(x) = Reference ECDF (from training/initial calibration)
            F_cur(x) = Current ECDF (recent samples)

        The null hypothesis H0: "Both samples come from the same distribution"

        P-value interpretation:
            p > 0.05: Fail to reject H0 - no significant difference
            p < 0.05: Reject H0 - significant distributional shift (drift confirmed)

        ==========================================================================
        Overhead Cost
        ==========================================================================

        - Time complexity: O(W log W) where W = window size (sorting)
        - Only runs when Stage 1 heuristic triggers (amortized cost is low)
        - Requires scipy.stats.ks_2samp

        ==========================================================================
        Sample Requirements
        ==========================================================================

        - Minimum: ~30 samples for meaningful p-value
        - Recommended: 50-100 samples for stable detection
        - Below minimum: Returns False (insufficient evidence)

        Returns:
            True if KS test confirms drift (any R/S/N p-value < significance level)
        """
        if not self.config.enable_statistical_drift:
            return False

        # Check if we have enough samples
        if len(self.metrics.recent_rsn_values) < self.config.min_samples_for_ks:
            return False

        # Check if we have a reference distribution
        if not hasattr(self, '_reference_rsn') or self._reference_rsn is None:
            # First time: save current as reference
            self._reference_rsn = list(self.metrics.recent_rsn_values)
            return False

        if len(self._reference_rsn) < self.config.min_samples_for_ks:
            return False

        try:
            from scipy.stats import ks_2samp
        except ImportError:
            # scipy not available - fall back to heuristic only
            return False

        # Extract R/S/N values from recent and reference
        recent = list(self.metrics.recent_rsn_values)
        reference = self._reference_rsn

        recent_R = [v[0] for v in recent]
        recent_S = [v[1] for v in recent]
        recent_N = [v[2] for v in recent]

        ref_R = [v[0] for v in reference]
        ref_S = [v[1] for v in reference]
        ref_N = [v[2] for v in reference]

        # Run KS tests for each component
        # ks_2samp returns (statistic, p-value)
        _, p_R = ks_2samp(recent_R, ref_R)
        _, p_S = ks_2samp(recent_S, ref_S)
        _, p_N = ks_2samp(recent_N, ref_N)

        # Store p-values in metrics for reporting
        self.metrics.ks_p_value_R = float(p_R)
        self.metrics.ks_p_value_S = float(p_S)
        self.metrics.ks_p_value_N = float(p_N)
        self.metrics.ks_tests_run += 1

        # Drift confirmed if ANY component shows significant shift
        # Using Bonferroni correction: alpha/3 for 3 tests
        # Or simply use the configured significance level for any
        significance = self.config.ks_significance_level

        drift_confirmed = (p_R < significance) or (p_S < significance) or (p_N < significance)

        if drift_confirmed:
            self.metrics.drift_confirmed = True
            self.metrics.confirmed_drifts += 1
            print(f"[CalibrationManager] KS test confirmed drift: "
                  f"p_R={p_R:.4f}, p_S={p_S:.4f}, p_N={p_N:.4f}")
        else:
            self.metrics.drift_confirmed = False

        return drift_confirmed

    def save_reference_distribution(self) -> None:
        """
        Save current R/S/N distribution as reference for future KS tests.

        Call this after training or when you have a "known good" distribution.
        """
        if len(self.metrics.recent_rsn_values) >= self.config.min_samples_for_ks:
            self._reference_rsn = list(self.metrics.recent_rsn_values)
            print(f"[CalibrationManager] Saved reference distribution "
                  f"({len(self._reference_rsn)} samples)")

    def get_calibration_signals(self) -> dict:
        """
        Get Category 9 calibration signals for logging.

        Returns dict matching the YRSN Signal Spec v2.0 Category 9:
            - drift_detected: bool (heuristic)
            - drift_confirmed: bool (KS test)
            - ks_p_value_R/S/N: float
            - calibration_state: str
            - samples_since_calibration: int
        """
        return {
            'drift_detected': self.metrics.drift_detections > 0,
            'drift_confirmed': self.metrics.drift_confirmed,
            'ks_p_value_R': self.metrics.ks_p_value_R,
            'ks_p_value_S': self.metrics.ks_p_value_S,
            'ks_p_value_N': self.metrics.ks_p_value_N,
            'calibration_state': self.metrics.state.name,
            'samples_since_calibration': self.metrics.samples_since_calibration,
        }

    def _check_for_topic_shift(
        self,
        hidden_states: torch.Tensor,
        current_N: float,
        device: torch.device
    ) -> bool:
        """
        Check if high Noise in DATA_CALIBRATED state indicates topic shift.

        The Problem:
        - If we recalibrated while solving Sudoku, projections are tuned to Sudoku
        - If user suddenly asks about poetry, Sudoku-tuned heads see it as "Noise"
        - This is a FALSE POSITIVE - the content is valid, just different

        The Solution:
        - When in DATA_CALIBRATED state with high N, test with weight-derived heads
        - If weight-derived heads see LOWER N, it's a topic shift (not real noise)
        - Revert to weight-derived heads to "return to generalization"

        Returns:
            True if topic shift was detected and we reverted to weights
        """
        # Only applies when we're in DATA_CALIBRATED state
        if self.metrics.state != CalibrationState.DATA_CALIBRATED:
            return False

        # Only trigger if current N is suspiciously high
        if current_N < self.config.topic_shift_noise_threshold:
            return False

        # Compare with weight-derived projections
        generic_N = self._compute_N_with_weights(hidden_states)

        improvement = current_N - generic_N

        # If generic weights see significantly less noise, it's a topic shift
        if improvement > self.config.topic_shift_improvement_threshold:
            print(f"[CalibrationManager] Topic shift detected: "
                  f"calibrated N={current_N:.3f} vs generic N={generic_N:.3f}")
            self._revert_to_weights(device)
            self.metrics.topic_shift_reversions += 1
            return True

        return False

    def _compute_N_with_weights(self, hidden_states: torch.Tensor) -> float:
        """Compute Noise ratio using the backup weight-derived projections."""
        if self._weight_derived_N is None:
            return 1.0  # Can't compare, assume worst case

        # Temporarily use weight-derived N projection
        is_sequence = hidden_states.dim() == 3
        if is_sequence:
            B, L, D = hidden_states.shape
            flat = hidden_states.view(B * L, D)
        else:
            flat = hidden_states

        # Manual projection with backup weights
        N_proj = torch.nn.functional.linear(flat, self._weight_derived_N)
        R_proj = torch.nn.functional.linear(flat, self._weight_derived_R)
        S_proj = torch.nn.functional.linear(flat, self._weight_derived_S)

        # Compute normalized N
        R_strength = R_proj.norm(dim=-1).mean().item()
        S_strength = S_proj.norm(dim=-1).mean().item()
        N_strength = N_proj.norm(dim=-1).mean().item()

        total = R_strength + S_strength + N_strength
        if total > 0:
            return N_strength / total
        return 0.33

    def _revert_to_weights(self, device: torch.device) -> None:
        """Revert projection heads to weight-derived state."""
        if self._weight_derived_R is None:
            return

        with torch.no_grad():
            self.R_head.weight.data = self._weight_derived_R.clone().to(device)
            self.S_head.weight.data = self._weight_derived_S.clone().to(device)
            self.N_head.weight.data = self._weight_derived_N.clone().to(device)

        self.metrics.state = CalibrationState.WEIGHT_DERIVED
        self._activation_buffer.clear()  # Clear specialized buffer
        self.metrics.confusion_streak = 0

        print("[CalibrationManager] Reverted to weight-derived state (topic shift)")

    def _maybe_recalibrate(self, device: torch.device) -> bool:
        """
        Trigger recalibration if conditions are met.

        Returns True if recalibration was performed.
        """
        # Check cooldown
        time_since_last = time.time() - self.metrics.last_calibration_time
        if time_since_last < self.config.cooldown_seconds:
            return False

        # Check buffer size
        if len(self._activation_buffer) < self.config.min_samples_for_calibration:
            return False

        # Perform recalibration
        return self.calibrate_from_buffer(device)

    def calibrate_from_buffer(self, device: torch.device) -> bool:
        """
        Recalibrate projection heads from the activation buffer.

        This is the "slow path" that uses Robust PCA to find the
        true R/S/N subspaces in the current activation distribution.

        Returns True if calibration was successful.
        """
        if len(self._activation_buffer) < self.config.min_samples_for_calibration:
            print(f"[CalibrationManager] Insufficient samples: {len(self._activation_buffer)}/{self.config.min_samples_for_calibration}")
            return False

        self.metrics.state = CalibrationState.RECALIBRATING
        print(f"[CalibrationManager] Recalibrating from {len(self._activation_buffer)} activation samples...")

        try:
            # Stack buffer into matrix [N, D]
            data_matrix = torch.stack(list(self._activation_buffer)).to(device)

            # Run Robust PCA decomposition
            L, S_sparse, N_residual = self._robust_pca_decomposition(data_matrix)

            # Derive new projection matrices via SVD
            R_proj, S_proj, N_proj = self._derive_projections_from_components(
                L, S_sparse, N_residual, device
            )

            # Hot-swap the projection weights
            with torch.no_grad():
                self.R_head.weight.data = R_proj.to(self.R_head.weight.dtype)
                self.S_head.weight.data = S_proj.to(self.S_head.weight.dtype)
                self.N_head.weight.data = N_proj.to(self.N_head.weight.dtype)

            # Update state
            self.metrics.state = CalibrationState.DATA_CALIBRATED
            self.metrics.last_calibration_time = time.time()
            self.metrics.calibration_count += 1
            self.metrics.slow_path_calls += 1
            self.metrics.confusion_streak = 0  # Reset streak

            print(f"[CalibrationManager] Recalibration complete (count={self.metrics.calibration_count})")
            return True

        except Exception as e:
            print(f"[CalibrationManager] Recalibration failed: {e}")
            self.metrics.state = CalibrationState.WEIGHT_DERIVED
            return False

    def _robust_pca_decomposition(
        self,
        data_matrix: torch.Tensor
    ) -> tuple:
        """
        Perform Robust PCA decomposition: M = L + S + N

        Uses Inexact ALM algorithm (same as yrsn-research).

        Args:
            data_matrix: [N, D] tensor of hidden states

        Returns:
            (L, S, N) decomposition tensors
        """
        M = data_matrix.float()
        m, n = M.shape

        # Auto-tune lambda
        lambda_s = 1.0 / np.sqrt(max(m, n))

        # IALM parameters
        M_norm = torch.linalg.norm(M, ord=2)
        Y = M / max(M_norm.item(), torch.max(torch.abs(M)).item() / lambda_s)
        L = torch.zeros_like(M)
        S = torch.zeros_like(M)

        mu = 1.25 / M_norm.item()
        mu_bar = mu * 1e7
        rho = 1.5
        tol = 1e-6
        max_iter = 100  # Reduced for speed

        for k in range(max_iter):
            # Update L via SVD thresholding
            temp = M - S + Y / mu
            U, sigma, Vt = torch.linalg.svd(temp, full_matrices=False)
            sigma_thresh = torch.clamp(sigma - 1 / mu, min=0)

            # Keep only top-k components for efficiency
            rank = min(self.config.rpca_rank, len(sigma_thresh))
            L = U[:, :rank] @ torch.diag(sigma_thresh[:rank]) @ Vt[:rank, :]

            # Update S via soft thresholding
            temp = M - L + Y / mu
            S = torch.sign(temp) * torch.clamp(torch.abs(temp) - lambda_s / mu, min=0)

            # Update dual variable
            residual = M - L - S
            Y = Y + mu * residual

            # Update penalty
            mu = min(rho * mu, mu_bar)

            # Check convergence
            err = torch.linalg.norm(residual, ord='fro') / torch.linalg.norm(M, ord='fro')
            if err < tol:
                break

        # Compute noise residual
        N = M - L - S

        return L, S, N

    def _derive_projections_from_components(
        self,
        L: torch.Tensor,
        S: torch.Tensor,
        N: torch.Tensor,
        device: torch.device
    ) -> tuple:
        """
        Derive projection matrices from R/S/N component matrices.

        Uses SVD to find the principal directions of each component.
        """
        def compute_projection_matrix(component: torch.Tensor, target_dim: int) -> torch.Tensor:
            """Compute projection matrix from component via SVD."""
            if component.numel() == 0 or torch.all(component == 0):
                return torch.eye(target_dim, self.hidden_dim, device=device)

            # SVD to find principal directions
            try:
                U, S_vals, Vh = torch.linalg.svd(component.T, full_matrices=False)

                # Find rank that explains 90% variance
                total_var = S_vals.sum()
                if total_var > 0:
                    cumsum = torch.cumsum(S_vals, dim=0) / total_var
                    rank = min(
                        target_dim,
                        max(1, (cumsum < 0.9).sum().item() + 1)
                    )
                else:
                    rank = min(target_dim, U.shape[1])

                # Projection onto top-k directions
                proj = Vh[:rank, :]  # [rank, hidden_dim]

                # Pad or truncate to target_dim
                if proj.shape[0] < target_dim:
                    padding = torch.zeros(
                        target_dim - proj.shape[0], self.hidden_dim,
                        device=device
                    )
                    proj = torch.cat([proj, padding], dim=0)
                else:
                    proj = proj[:target_dim, :]

                return proj

            except Exception:
                return torch.eye(target_dim, self.hidden_dim, device=device)

        R_proj = compute_projection_matrix(L, self.projection_dim)
        S_proj = compute_projection_matrix(S, self.projection_dim)
        N_proj = compute_projection_matrix(N, self.projection_dim)

        return R_proj, S_proj, N_proj

    def force_recalibrate(self, device: torch.device) -> bool:
        """Force immediate recalibration regardless of cooldown."""
        self.metrics.last_calibration_time = 0  # Reset cooldown
        return self.calibrate_from_buffer(device)

    def reset_to_weights(self, model: nn.Module, device: torch.device) -> None:
        """Reset projection heads back to weight-derived state."""
        self.initialize_from_model(model, device)
        self._activation_buffer.clear()
        self.metrics.confusion_streak = 0
        print("[CalibrationManager] Reset to weight-derived state")

    def get_diagnostics(self) -> Dict[str, Any]:
        """Get diagnostic information about calibration state."""
        return {
            'state': self.metrics.state.name,
            'calibration_count': self.metrics.calibration_count,
            'fast_path_calls': self.metrics.fast_path_calls,
            'slow_path_calls': self.metrics.slow_path_calls,
            'drift_detections': self.metrics.drift_detections,
            'topic_shift_reversions': self.metrics.topic_shift_reversions,
            'confusion_streak': self.metrics.confusion_streak,
            'buffer_size': len(self._activation_buffer),
            'time_since_calibration': time.time() - self.metrics.last_calibration_time,
            'fast_slow_ratio': (
                self.metrics.fast_path_calls / max(1, self.metrics.slow_path_calls)
            ),
        }


# Convenience function
def create_calibrated_projections(
    model: nn.Module,
    device: torch.device,
    hidden_dim: int,
    config: Optional[CalibrationConfig] = None
) -> CalibrationManager:
    """
    Create a CalibrationManager initialized from model weights.

    Args:
        model: The HRM model to derive projections from
        device: Device for tensors
        hidden_dim: Hidden dimension
        config: Optional calibration config

    Returns:
        Initialized CalibrationManager
    """
    manager = CalibrationManager(hidden_dim=hidden_dim, config=config)
    manager.initialize_from_model(model, device)
    return manager


# =============================================================================
# Supervised Calibration Extension
# =============================================================================

class SupervisedCalibrationManager(CalibrationManager):
    """
    CalibrationManager with supervised learning support.

    Extends the drift-reset mechanism with:
    1. Supervised fine-tuning from labeled R/S/N examples
    2. Online learning during inference
    3. Hybrid supervision (drift-reset + labeled data)

    This enables the "Pillar 1 Completion" by adding training loops
    for the projection matrices W_relevance, W_superfluous.

    Usage:
        from yrsn.core.decomposition import SupervisedCalibrationManager

        manager = SupervisedCalibrationManager(hidden_dim=256)
        manager.initialize_from_model(model, device)

        # Enable supervised mode
        manager.enable_supervision(learning_rate=1e-4)

        # During inference with online learning
        metrics = manager.compute_metrics_with_supervision(
            hidden_states,
            rsn_labels=labels,  # Optional supervision
            task_outcomes={'prediction': pred, 'target': target}  # Weak supervision
        )

        # Batch fine-tuning
        loss = manager.supervised_calibration_step(embeddings, labels)
    """

    def __init__(
        self,
        hidden_dim: int,
        projection_dim: Optional[int] = None,
        config: Optional[CalibrationConfig] = None,
        supervision_weight: float = 0.5,
    ):
        super().__init__(hidden_dim, projection_dim, config)

        self.supervision_weight = supervision_weight
        self.supervision_enabled = False

        # Supervision components (lazy initialization)
        self._trainer = None
        self._optimizer = None
        self._loss_fn = None

        # Labeled data buffer for supervision
        self._labeled_buffer: List[tuple] = []
        self._max_labeled_buffer: int = 1000

        # Supervision metrics
        self.supervision_steps = 0
        self.total_supervision_loss = 0.0

    def enable_supervision(
        self,
        learning_rate: float = 1e-4,
        triplet_weight: float = 1.0,
        orthogonality_weight: float = 0.1,
        classification_weight: float = 0.3,
    ) -> None:
        """
        Enable supervised learning mode.

        Args:
            learning_rate: Learning rate for fine-tuning
            triplet_weight: Weight for triplet/contrastive loss
            orthogonality_weight: Weight for orthogonality regularization
            classification_weight: Weight for classification loss
        """
        from .triplet_loss import YRSNCombinedLoss

        if not self._initialized:
            raise RuntimeError("Initialize from model first before enabling supervision")

        # Create combined loss
        self._loss_fn = YRSNCombinedLoss(
            triplet_weight=triplet_weight,
            orthogonality_weight=orthogonality_weight,
            classification_weight=classification_weight,
            use_contrastive=False,
        )

        # Create optimizer for projection heads
        params = []
        if self.R_head is not None:
            params.extend(self.R_head.parameters())
        if self.S_head is not None:
            params.extend(self.S_head.parameters())
        if self.N_head is not None:
            params.extend(self.N_head.parameters())

        self._optimizer = torch.optim.AdamW(params, lr=learning_rate, weight_decay=0.01)

        self.supervision_enabled = True
        print(f"[SupervisedCalibrationManager] Supervision enabled (lr={learning_rate})")

    def disable_supervision(self) -> None:
        """Disable supervised learning mode."""
        self.supervision_enabled = False
        print("[SupervisedCalibrationManager] Supervision disabled")

    def compute_metrics_with_supervision(
        self,
        hidden_states: torch.Tensor,
        rsn_labels: Optional[torch.Tensor] = None,
        task_outcomes: Optional[Dict[str, torch.Tensor]] = None,
        add_to_buffer: bool = True,
        train: bool = True,
    ) -> Dict[str, Any]:
        """
        Compute metrics with optional online supervised learning.

        Args:
            hidden_states: [B, D] or [B, L, D] hidden states
            rsn_labels: [B] explicit R/S/N labels (0=R, 1=S, 2=N)
            task_outcomes: Dict with 'prediction' and 'target' for weak supervision
            add_to_buffer: Whether to add to calibration buffer
            train: Whether to perform training step

        Returns:
            Dict with metrics and training info
        """
        # Standard metrics computation (includes drift detection)
        metrics = self.compute_metrics(hidden_states, add_to_buffer)

        # Online training if supervision enabled and labels provided
        if self.supervision_enabled and train and (rsn_labels is not None or task_outcomes is not None):
            train_metrics = self._online_training_step(
                hidden_states, rsn_labels, task_outcomes
            )
            metrics['training'] = train_metrics
            metrics['supervision_enabled'] = True
        else:
            metrics['supervision_enabled'] = False

        return metrics

    def _online_training_step(
        self,
        hidden_states: torch.Tensor,
        rsn_labels: Optional[torch.Tensor],
        task_outcomes: Optional[Dict[str, torch.Tensor]],
    ) -> Dict[str, float]:
        """Perform single online training step."""
        if self._optimizer is None or self._loss_fn is None:
            return {'error': 'Supervision not properly enabled'}

        device = hidden_states.device

        # Get projections
        projections = self._project(hidden_states)

        # Mean projection for loss computation
        proj_embeddings = (projections['R'] + projections['S'] + projections['N']) / 3

        # Handle sequence dimension
        if proj_embeddings.dim() == 3:
            B, L, D = proj_embeddings.shape
            proj_embeddings = proj_embeddings.view(B * L, D)
            if rsn_labels is not None:
                rsn_labels = rsn_labels.view(-1)

        # Compute loss
        self._optimizer.zero_grad()

        total_loss = torch.tensor(0.0, device=device, requires_grad=True)
        train_metrics = {}

        # Supervised loss if labels available
        if rsn_labels is not None:
            rsn_labels = rsn_labels.to(device)
            loss_output = self._loss_fn.separation_loss(proj_embeddings, rsn_labels)
            total_loss = total_loss + loss_output.total_loss * self.supervision_weight
            train_metrics['supervised_loss'] = loss_output.total_loss.item()

        # Orthogonality regularization
        ortho_loss = self._compute_orthogonality_loss(device)
        total_loss = total_loss + ortho_loss * 0.1
        train_metrics['orthogonality_loss'] = ortho_loss.item()

        # Weak supervision from task outcomes
        if task_outcomes is not None:
            weak_loss = self._compute_weak_supervision_loss(
                hidden_states, task_outcomes, device
            )
            total_loss = total_loss + weak_loss * (1 - self.supervision_weight)
            train_metrics['weak_loss'] = weak_loss.item()

        # Backward pass
        if total_loss.requires_grad:
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(self.R_head.parameters()) +
                list(self.S_head.parameters()) +
                list(self.N_head.parameters()),
                max_norm=1.0
            )
            self._optimizer.step()

        train_metrics['total_loss'] = total_loss.item()
        self.supervision_steps += 1
        self.total_supervision_loss += total_loss.item()

        return train_metrics

    def _compute_orthogonality_loss(self, device: torch.device) -> torch.Tensor:
        """Compute orthogonality loss between R/S/N projection weights."""
        from .triplet_loss import YRSNOrthogonalityLoss

        ortho_loss = YRSNOrthogonalityLoss()

        if self.R_head is None:
            return torch.tensor(0.0, device=device)

        output = ortho_loss(
            self.R_head.weight,
            self.S_head.weight,
            self.N_head.weight,
        )
        return output.total_loss

    def _compute_weak_supervision_loss(
        self,
        hidden_states: torch.Tensor,
        task_outcomes: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> torch.Tensor:
        """Compute weak supervision loss from task outcomes."""
        from .outcome_supervision import OutcomeBasedSupervision

        supervisor = OutcomeBasedSupervision()

        # Generate weak labels
        if hidden_states.dim() == 2:
            hidden_states = hidden_states.unsqueeze(1)  # Add sequence dim

        weak_labels = supervisor.compute_weak_labels(
            hidden_states,
            task_outcomes['prediction'].to(device),
            task_outcomes['target'].to(device),
        )
        weak_labels = weak_labels.squeeze(1)  # Remove sequence dim

        # Compute classification loss
        projections = self._project(hidden_states.squeeze(1))
        proj_embeddings = (projections['R'] + projections['S'] + projections['N']) / 3

        # Simple cross-entropy on weak labels
        # Create simple classifier from projection norms
        R_strength = projections['R'].norm(dim=-1, keepdim=True)
        S_strength = projections['S'].norm(dim=-1, keepdim=True)
        N_strength = projections['N'].norm(dim=-1, keepdim=True)

        logits = torch.cat([R_strength, S_strength, N_strength], dim=-1)
        loss = nn.functional.cross_entropy(logits, weak_labels)

        return loss

    def supervised_calibration_step(
        self,
        embeddings: torch.Tensor,
        rsn_labels: torch.Tensor,
        sample_weights: Optional[torch.Tensor] = None,
    ) -> Dict[str, float]:
        """
        Perform a batch supervised calibration step.

        Used for batch fine-tuning of projection heads on labeled data.

        Args:
            embeddings: [B, D] hidden states
            rsn_labels: [B] R/S/N labels (0=R, 1=S, 2=N)
            sample_weights: [B] optional sample weights

        Returns:
            Dict with loss components
        """
        if not self.supervision_enabled:
            raise RuntimeError("Enable supervision first")

        return self._online_training_step(embeddings, rsn_labels, None)

    def add_labeled_sample(
        self,
        embedding: torch.Tensor,
        rsn_label: int,
        confidence: float = 1.0,
    ) -> None:
        """
        Add a labeled sample to the supervision buffer.

        Args:
            embedding: [D] hidden state
            rsn_label: R/S/N label (0=R, 1=S, 2=N)
            confidence: Label confidence
        """
        if len(self._labeled_buffer) >= self._max_labeled_buffer:
            self._labeled_buffer.pop(0)  # Remove oldest

        self._labeled_buffer.append((
            embedding.detach().cpu(),
            rsn_label,
            confidence
        ))

    def calibrate_with_supervision(
        self,
        device: torch.device,
        num_steps: int = 10,
    ) -> Dict[str, float]:
        """
        Calibrate using both RPCA and supervised learning.

        1. Run standard RPCA calibration
        2. Fine-tune projection heads on labeled examples
        3. Blend weight-derived and learned projections

        Args:
            device: Target device
            num_steps: Number of fine-tuning steps

        Returns:
            Dict with calibration metrics
        """
        metrics = {}

        # Standard calibration
        calibrated = self.calibrate_from_buffer(device)
        metrics['rpca_calibration'] = calibrated

        # Supervised fine-tuning if we have labeled data
        if self.supervision_enabled and len(self._labeled_buffer) > 0:
            total_loss = 0.0

            for step in range(num_steps):
                # Sample batch from labeled buffer
                batch_size = min(32, len(self._labeled_buffer))
                indices = np.random.choice(
                    len(self._labeled_buffer), batch_size, replace=False
                )

                embeddings = torch.stack([
                    self._labeled_buffer[i][0] for i in indices
                ]).to(device)
                labels = torch.tensor([
                    self._labeled_buffer[i][1] for i in indices
                ]).to(device)

                step_metrics = self.supervised_calibration_step(embeddings, labels)
                total_loss += step_metrics.get('total_loss', 0.0)

            metrics['supervised_fine_tuning'] = {
                'num_steps': num_steps,
                'avg_loss': total_loss / max(num_steps, 1),
                'num_labeled_samples': len(self._labeled_buffer),
            }

        return metrics

    def get_supervision_diagnostics(self) -> Dict[str, Any]:
        """Get supervision-specific diagnostics."""
        base_diagnostics = self.get_diagnostics()

        base_diagnostics.update({
            'supervision_enabled': self.supervision_enabled,
            'supervision_steps': self.supervision_steps,
            'avg_supervision_loss': (
                self.total_supervision_loss / max(1, self.supervision_steps)
            ),
            'labeled_buffer_size': len(self._labeled_buffer),
            'supervision_weight': self.supervision_weight,
        })

        return base_diagnostics


def create_supervised_calibration(
    model: nn.Module,
    device: torch.device,
    hidden_dim: int,
    config: Optional[CalibrationConfig] = None,
    supervision_weight: float = 0.5,
    learning_rate: float = 1e-4,
) -> SupervisedCalibrationManager:
    """
    Create a SupervisedCalibrationManager with supervision enabled.

    Args:
        model: The HRM model to derive projections from
        device: Device for tensors
        hidden_dim: Hidden dimension
        config: Optional calibration config
        supervision_weight: Weight for supervised vs unsupervised loss
        learning_rate: Learning rate for supervision

    Returns:
        Initialized SupervisedCalibrationManager with supervision enabled
    """
    manager = SupervisedCalibrationManager(
        hidden_dim=hidden_dim,
        config=config,
        supervision_weight=supervision_weight,
    )
    manager.initialize_from_model(model, device)
    manager.enable_supervision(learning_rate=learning_rate)
    return manager


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "CalibrationState",
    # Config/Metrics
    "CalibrationConfig",
    "CalibrationMetrics",
    # Main Classes
    "CalibrationManager",
    "SupervisedCalibrationManager",
    # Factory functions
    "create_calibrated_projections",
    "create_supervised_calibration",
]
