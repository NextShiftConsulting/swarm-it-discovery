"""
Real-Time Collapse Monitoring with Drift Detection

Implements S4-090 findings:
- RSN-based drift detection (29 steps faster than radius)
- Omega drop detection (15.4% = drift)
- Domain distribution monitoring

Usage:
    from yrsn.core.decomposition.monitor import RealTimeCollapseMonitor

    monitor = RealTimeCollapseMonitor(projection)

    for features in stream:
        status = monitor.update(features)
        if status.drift_detected:
            trigger_recalibration()
        if not status.is_healthy:
            handle_collapse(status.current_analysis)
"""

from dataclasses import dataclass
from typing import List, Tuple, Optional
import numpy as np

from .collapse import (
    CollapseDetector,
    CollapseAnalysis,
    GeometricDomain,
)


@dataclass
class MonitorStatus:
    """Status from real-time collapse monitor."""
    is_healthy: bool
    current_analysis: CollapseAnalysis
    drift_detected: bool
    drift_magnitude: float
    samples_since_baseline: int
    ood_rate: float  # Rolling OOD rate


class RealTimeCollapseMonitor:
    """
    Real-time collapse monitoring with drift detection.

    Implements S4-090 findings:
    - RSN-based drift detection (29 steps faster than radius)
    - Omega drop detection (15.4% = drift)
    - Domain distribution monitoring
    """

    def __init__(
        self,
        projection,
        window_size: int = 100,
        drift_threshold: float = 0.05,
        ood_rate_threshold: float = 0.20,
    ):
        """
        Initialize monitor.

        Args:
            projection: TrainedRSNProjection for computing signals
            window_size: Rolling window for statistics
            drift_threshold: Omega drop threshold for drift (S4-090: 5%)
            ood_rate_threshold: OOD rate threshold for alarm
        """
        self.projection = projection
        self.detector = CollapseDetector()
        self.window_size = window_size
        self.drift_threshold = drift_threshold
        self.ood_rate_threshold = ood_rate_threshold

        # Rolling buffers
        self.omega_history: List[float] = []
        self.rsn_history: List[Tuple[float, float, float]] = []
        self.domain_history: List[GeometricDomain] = []
        self.ood_count = 0
        self.total_count = 0

        # Baseline (set from first samples)
        self.baseline_set = False
        self.baseline_omega: Optional[float] = None
        self.baseline_rsn: Optional[Tuple[float, float, float]] = None

    def update(self, features: np.ndarray) -> MonitorStatus:
        """
        Update monitor with new sample.

        Args:
            features: Feature vector [1, dim] or [dim]

        Returns:
            MonitorStatus with current state
        """
        if features.ndim == 1:
            features = features.reshape(1, -1)

        # Compute RSN signals
        result = self.projection.compute_rsn(features)

        R = float(result['R'])
        S = float(result['S'])
        N = float(result['N'])
        theta = float(result.get('sample_theta', 0))
        scale = float(result.get('sample_radius', 1.0))
        omega = float(result.get('omega', 0.5))
        alpha = float(result.get('alpha', R))

        # Set baseline from first samples
        if not self.baseline_set and len(self.omega_history) >= 10:
            self.baseline_omega = np.mean(self.omega_history)
            self.baseline_rsn = (
                np.mean([r[0] for r in self.rsn_history]),
                np.mean([r[1] for r in self.rsn_history]),
                np.mean([r[2] for r in self.rsn_history]),
            )
            self.detector.set_baseline(self.baseline_omega, self.baseline_rsn)
            self.baseline_set = True

        # Update histories
        self.omega_history.append(omega)
        self.rsn_history.append((R, S, N))

        if len(self.omega_history) > self.window_size:
            self.omega_history.pop(0)
            self.rsn_history.pop(0)

        # Detect collapse
        previous_rsn = self.rsn_history[-2] if len(self.rsn_history) > 1 else None

        analysis = self.detector.detect(
            R=R, S=S, N=N,
            theta=theta,
            scale=scale,
            alpha=alpha,
            omega=omega,
            previous_rsn=previous_rsn,
        )

        # Track domain distribution
        self.domain_history.append(analysis.geometric_domain)
        if len(self.domain_history) > self.window_size:
            self.domain_history.pop(0)

        # Track OOD rate
        self.total_count += 1
        if omega < 0.5:  # OOD threshold from S4-046
            self.ood_count += 1

        ood_rate = self.ood_count / self.total_count if self.total_count > 0 else 0

        # Detect drift (S4-090)
        drift_detected = False
        drift_magnitude = 0.0

        if self.baseline_set:
            omega_drop = self.baseline_omega - np.mean(self.omega_history[-10:])
            if omega_drop > self.drift_threshold:
                drift_detected = True
                drift_magnitude = omega_drop

        return MonitorStatus(
            is_healthy=not analysis.is_collapsed,
            current_analysis=analysis,
            drift_detected=drift_detected,
            drift_magnitude=drift_magnitude,
            samples_since_baseline=self.total_count,
            ood_rate=ood_rate,
        )

    def reset_baseline(self):
        """Reset baseline for recalibration."""
        self.baseline_set = False
        self.baseline_omega = None
        self.baseline_rsn = None
        self.omega_history.clear()
        self.rsn_history.clear()
        self.ood_count = 0
        self.total_count = 0

    def get_domain_distribution(self) -> dict:
        """Get current domain distribution from window."""
        from collections import Counter
        if not self.domain_history:
            return {}
        counts = Counter(d.value for d in self.domain_history)
        total = len(self.domain_history)
        return {k: v / total for k, v in counts.items()}


__all__ = [
    'MonitorStatus',
    'RealTimeCollapseMonitor',
]
