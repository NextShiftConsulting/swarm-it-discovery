"""
RSN Constraint Validation - Pure Mathematical Domain Logic

Pure mathematical functions for validating and enforcing the R+S+N=1 simplex
constraint that is fundamental to YRSN signal decomposition.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements components from:
- §7.4.4: Normalization and Invariant Enforcement
  - §7.4.4.1: Simplex Constraint Enforcement (softmax, projection, iterative)
  - §7.4.4.4: Enforcement During Computation
- §7.5: Metric Computation (alpha, alpha_omega, tau computation)

Relevant patent files:
- docs/specs/patent_spec_section_7_4_decomposition.md (lines 117-213)
- docs/specs/patent_spec_section_7_5_metric_computation.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

┌────────────────────────────────────────────────────────────────────┐
│                       WHAT THIS DOES                                │
├────────────────────────────────────────────────────────────────────┤
│ Enforces the fundamental YRSN constraint: R + S + N = 1            │
│                                                                     │
│ • Validates outputs meet constraint                                │
│ • Projects invalid points to valid simplex                         │
│ • Detects tampering/numerical issues                               │
│ • Computes distances on simplex                                    │
└────────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
The R+S+N=1 constraint is a mathematical invariant that MUST hold for all
YRSN outputs. Violations indicate:
- Numerical instability
- Implementation bugs
- Tampering/adversarial manipulation
- Coordinate system errors

This module provides pure domain logic (zero dependencies) for constraint
enforcement and validation.

DOMAIN LOGIC (Pure Math):
-------------------------
This module contains ONLY pure mathematical functions with zero external
dependencies. No matplotlib, no PyTorch, no infrastructure.

For visualization, see: infrastructure/rendering/matplotlib/rsn_renderer.py
For adapters, see: adapters/visualization/matplotlib_adapter.py

FIRST PRINCIPLES COMPLIANCE:
----------------------------
✓ P1: Pure domain logic (zero infrastructure dependencies)
✓ P3: R+S+N=1 invariant (fundamental constraint)
✓ Hex architecture: Domain layer
✓ Testable: All functions are pure (input → output, no side effects)

USAGE EXAMPLES:
--------------

Example 1: Validate RSN Output
>>> from yrsn.core.decomposition.rsn_constraints import validate_rsn_constraint
>>>
>>> R, S, N = 0.6, 0.3, 0.1
>>> is_valid = validate_rsn_constraint(R, S, N)
>>> print(is_valid)  # True (sums to 1.0)
>>>
>>> R, S, N = 0.6, 0.3, 0.2
>>> is_valid = validate_rsn_constraint(R, S, N)
>>> print(is_valid)  # False (sums to 1.1)

Example 2: Project Invalid Point to Simplex
>>> from yrsn.core.decomposition.rsn_constraints import project_to_simplex
>>>
>>> R, S, N = 0.6, 0.3, 0.2  # Invalid (sum = 1.1)
>>> R_proj, S_proj, N_proj = project_to_simplex(R, S, N)
>>> print(f"Projected: R={R_proj:.3f}, S={S_proj:.3f}, N={N_proj:.3f}")
>>> # Output: R=0.545, S=0.273, N=0.182 (sum = 1.0)

Example 3: Detect Tampering
>>> from yrsn.core.decomposition.rsn_constraints import (
...     compute_constraint_violation, is_tampered
... )
>>>
>>> R, S, N = 0.9, 0.05, 0.05  # Suspicious (R too high)
>>> violation = compute_constraint_violation(R, S, N)
>>> if violation > 1e-3:
...     print(f"WARNING: Constraint violation = {violation:.6f}")
>>>
>>> tampered = is_tampered(R, S, N, threshold=1e-3)
>>> if tampered:
...     print("Tampering detected!")

Example 4: Simplex Distance
>>> from yrsn.core.decomposition.rsn_constraints import simplex_distance
>>>
>>> # Distance between two points on simplex
>>> point1 = (0.7, 0.2, 0.1)
>>> point2 = (0.4, 0.3, 0.3)
>>> dist = simplex_distance(point1, point2)
>>> print(f"Distance: {dist:.3f}")

REFERENCE:
---------
CIP #1: T⁴ Parameterization
docs/CIP_01_T4_PARAMETERIZATION.md
docs/schemas/CERTIFICATE_V2.md
docs/principles/FIRST_PRINCIPLES.md (P3: R+S+N=1 invariant)
"""

from typing import Tuple
import numpy as np


# =============================================================================
# Constraint Validation
# =============================================================================

def validate_rsn_constraint(
    R: float,
    S: float,
    N: float,
    tolerance: float = 1e-6
) -> bool:
    """
    Validate that R+S+N=1 constraint holds.

    Args:
        R: Relevant signal strength [0, 1]
        S: Spurious signal strength [0, 1]
        N: Noise signal strength [0, 1]
        tolerance: Numerical tolerance for floating-point errors

    Returns:
        True if constraint is satisfied within tolerance

    Example:
        >>> validate_rsn_constraint(0.6, 0.3, 0.1)
        True
        >>> validate_rsn_constraint(0.6, 0.3, 0.15)
        False
    """
    total = R + S + N
    violation = abs(total - 1.0)
    return violation < tolerance


def compute_constraint_violation(R: float, S: float, N: float) -> float:
    """
    Compute magnitude of constraint violation.

    Returns:
        |R + S + N - 1.0| (0.0 = perfect, >0 = violation)

    Example:
        >>> compute_constraint_violation(0.6, 0.3, 0.1)
        0.0
        >>> compute_constraint_violation(0.6, 0.3, 0.2)
        0.1
    """
    return abs(R + S + N - 1.0)


def is_tampered(
    R: float,
    S: float,
    N: float,
    threshold: float = 1e-3
) -> bool:
    """
    Detect if RSN values appear tampered (violation > threshold).

    USAGE:
    -----
    Use in certificate validation to detect adversarial manipulation.
    Normal numerical errors are < 1e-6, so threshold=1e-3 catches tampering.

    Args:
        R, S, N: Signal strengths
        threshold: Violation threshold (default 1e-3)

    Returns:
        True if violation exceeds threshold (likely tampering)

    Example:
        >>> is_tampered(0.6, 0.3, 0.1)  # Valid
        False
        >>> is_tampered(0.8, 0.3, 0.2)  # Sum = 1.3 (tampered)
        True
    """
    violation = compute_constraint_violation(R, S, N)
    return violation > threshold


# =============================================================================
# Simplex Projection
# =============================================================================

def project_to_simplex(R: float, S: float, N: float) -> Tuple[float, float, float]:
    """
    Project invalid (R, S, N) to valid simplex.

    ALGORITHM:
    ---------
    If total = 0: Return uniform (1/3, 1/3, 1/3)
    Else: Normalize by total: (R/total, S/total, N/total)

    This preserves RATIOS while enforcing constraint.

    Args:
        R, S, N: Signal strengths (may violate constraint)

    Returns:
        (R_proj, S_proj, N_proj) satisfying R+S+N=1

    Example:
        >>> project_to_simplex(0.6, 0.3, 0.2)  # Sum = 1.1
        (0.545..., 0.272..., 0.181...)
        >>> project_to_simplex(0.0, 0.0, 0.0)  # Degenerate
        (0.333..., 0.333..., 0.333...)
    """
    total = R + S + N

    # Handle degenerate case
    if total == 0.0:
        return (1.0/3.0, 1.0/3.0, 1.0/3.0)

    # Normalize
    R_proj = R / total
    S_proj = S / total
    N_proj = N / total

    return (R_proj, S_proj, N_proj)


def clamp_to_simplex(R: float, S: float, N: float) -> Tuple[float, float, float]:
    """
    Clamp negative values to zero, then project to simplex.

    Use this when inputs might have small negative values due to numerical
    errors (e.g., from optimization).

    Args:
        R, S, N: Signal strengths (may be negative)

    Returns:
        (R_clamped, S_clamped, N_clamped) in valid simplex

    Example:
        >>> clamp_to_simplex(0.7, 0.4, -0.1)  # N negative
        (0.636..., 0.363..., 0.0)
    """
    # Clamp to [0, inf)
    R_pos = max(0.0, R)
    S_pos = max(0.0, S)
    N_pos = max(0.0, N)

    # Project to simplex
    return project_to_simplex(R_pos, S_pos, N_pos)


# =============================================================================
# Simplex Geometry
# =============================================================================

def simplex_distance(
    point1: Tuple[float, float, float],
    point2: Tuple[float, float, float]
) -> float:
    """
    Compute Euclidean distance between two points on simplex.

    NOTE: This is Euclidean distance in the embedded 3D space. For geodesic
    distance on the simplex manifold, use more sophisticated methods.

    Args:
        point1: (R1, S1, N1)
        point2: (R2, S2, N2)

    Returns:
        Euclidean distance

    Example:
        >>> p1 = (0.7, 0.2, 0.1)
        >>> p2 = (0.4, 0.3, 0.3)
        >>> dist = simplex_distance(p1, p2)
        >>> print(f"{dist:.3f}")  # ~0.374
    """
    R1, S1, N1 = point1
    R2, S2, N2 = point2

    diff_R = R2 - R1
    diff_S = S2 - S1
    diff_N = N2 - N1

    return np.sqrt(diff_R**2 + diff_S**2 + diff_N**2)


def barycentric_to_cartesian(R: float, S: float, N: float) -> Tuple[float, float]:
    """
    Convert simplex coordinates to 2D Cartesian (for visualization).

    STANDARD SIMPLEX EMBEDDING:
    ---------------------------
    - R corner: (0, 0)
    - S corner: (1, 0)
    - N corner: (0.5, sqrt(3)/2)

    Args:
        R, S, N: Simplex coordinates (must satisfy R+S+N=1)

    Returns:
        (x, y) Cartesian coordinates

    Example:
        >>> x, y = barycentric_to_cartesian(1.0, 0.0, 0.0)  # R corner
        >>> print(f"({x:.1f}, {y:.1f})")  # (0.0, 0.0)
        >>> x, y = barycentric_to_cartesian(0.0, 1.0, 0.0)  # S corner
        >>> print(f"({x:.1f}, {y:.1f})")  # (1.0, 0.0)
    """
    # Standard triangle vertices
    sqrt3_2 = np.sqrt(3.0) / 2.0

    x = S + 0.5 * N
    y = sqrt3_2 * N

    return (float(x), float(y))


def cartesian_to_barycentric(x: float, y: float) -> Tuple[float, float, float]:
    """
    Convert 2D Cartesian to simplex coordinates (inverse of barycentric_to_cartesian).

    Args:
        x, y: Cartesian coordinates

    Returns:
        (R, S, N) simplex coordinates

    Example:
        >>> R, S, N = cartesian_to_barycentric(0.0, 0.0)  # R corner
        >>> print(f"R={R:.1f}, S={S:.1f}, N={N:.1f}")  # R=1.0, S=0.0, N=0.0
    """
    sqrt3_2 = np.sqrt(3.0) / 2.0

    N = y / sqrt3_2
    S = x - 0.5 * N
    R = 1.0 - S - N

    return (float(R), float(S), float(N))


# =============================================================================
# Quality Metrics
# =============================================================================

def compute_alpha(R: float, S: float, N: float) -> float:
    """
    Compute alpha quality score: α = R / (R + S + N)

    Since R+S+N=1 by constraint, this simplifies to α = R.
    This function is provided for explicit semantic clarity.

    Args:
        R, S, N: Signal strengths

    Returns:
        Alpha quality score [0, 1]

    Example:
        >>> compute_alpha(0.7, 0.2, 0.1)
        0.7
    """
    total = R + S + N
    if total == 0.0:
        return 0.0
    return R / total


def compute_tau(
    R: float,
    S: float,
    N: float,
    omega: float = 1.0,
    prior: float = 0.5,
) -> float:
    """
    Compute tau (temperature) from RSN with P14 conjunction.

    P14 Formula:
        α_ω = α × ω + prior × (1 - ω)
        τ = 1 / α_ω

    Used for temperature scaling in softmax. The omega parameter
    gates alpha based on distributional reliability.

    Args:
        R, S, N: Signal strengths (must sum to 1)
        omega: Reliability coefficient [0, 1]. Default 1.0 = in-distribution.
        prior: Collapse prevention baseline. Default 0.5.

    Returns:
        Tau (temperature) [1, inf)
        Returns inf if alpha_omega <= 0

    Example:
        >>> compute_tau(0.8, 0.1, 0.1)  # alpha=0.8, omega=1.0
        1.25
        >>> compute_tau(0.8, 0.1, 0.1, omega=0.5)  # blended with prior
        1.54  # 1/(0.8*0.5 + 0.5*0.5) = 1/0.65

    See Also:
        yrsn.core.temperature.compute_tau: Canonical implementation
    """
    alpha = compute_alpha(R, S, N)
    # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
    alpha_omega = alpha * omega + (1 - omega) * prior
    if alpha_omega <= 0.0:
        return float('inf')
    return 1.0 / alpha_omega


def is_high_quality(R: float, S: float, N: float, threshold: float = 0.7) -> bool:
    """
    Check if point represents high-quality signal.

    Args:
        R, S, N: Signal strengths
        threshold: Alpha threshold for "high quality"

    Returns:
        True if alpha >= threshold

    Example:
        >>> is_high_quality(0.8, 0.1, 0.1)  # alpha=0.8
        True
        >>> is_high_quality(0.5, 0.3, 0.2)  # alpha=0.5
        False
    """
    alpha = compute_alpha(R, S, N)
    return alpha >= threshold


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Validation
    'validate_rsn_constraint',
    'compute_constraint_violation',
    'is_tampered',

    # Projection
    'project_to_simplex',
    'clamp_to_simplex',

    # Geometry
    'simplex_distance',
    'barycentric_to_cartesian',
    'cartesian_to_barycentric',

    # Quality
    'compute_alpha',
    'compute_tau',
    'is_high_quality',
]
