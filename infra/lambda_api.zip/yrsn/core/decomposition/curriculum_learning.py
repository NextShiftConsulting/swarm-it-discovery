"""
Pillar 4: Curriculum Learning
=============================

Renamed from pillar4_memristor.py to better reflect its primary function.

This module manages curriculum learning and constraint weight management using
memristor-inspired dynamics - it does NOT perform R/S/N projection (see
yrsn_context.hardware.memristor_projection for that).

Key Features:
1. Virtual memristor arrays for constraint weight management
2. Tier-to-model mapping (Actual/Learned/Emergent → memristor models)
3. Bidirectional Pillar 2 ↔ Pillar 4 bridges
4. Sensor-driven constraint modulation
5. Curriculum progression based on constraint satisfaction
6. Human-in-the-loop CLI for constraint tuning
7. RL/Robotics utilities (AdaptiveInference, CreditAssignment, RewardShaper)

Memristor Properties:
- Non-volatility: Constraint state persists
- Analog tuning: Continuous weight values
- History dependence: State reflects past signals
- Threshold behavior: Some changes require minimum signal

Tier-to-Memristor Mapping:
| Tier     | Model                | Behavior                    | Response        |
|----------|---------------------|-----------------------------|-----------------|
| ACTUAL   | Threshold Adaptive  | No change below threshold   | Fatal           |
| LEARNED  | Linear Ion Drift    | Proportional adaptation     | Warning         |
| EMERGENT | Nonlinear Ion Drift | Boundary crystallization    | Advisory        |

Usage:
    from yrsn.core.decomposition.curriculum_learning import (
        VirtualMemristor,
        MemristorConstraintArray,
        Pillar2Pillar4Bridge,
        CurriculumManager,
    )

    # Create memristor-managed constraints
    array = MemristorConstraintArray()
    array.add_constraint("relevance_check", tier=ConstraintTier.ACTUAL)
    array.add_constraint("noise_threshold", tier=ConstraintTier.LEARNED)

    # Bridge with Pillar 2
    bridge = Pillar2Pillar4Bridge()
    curriculum_stage = bridge.quality_to_curriculum_stage(quality=0.7)
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple, Callable, Set, TYPE_CHECKING
from enum import Enum, auto
from collections import deque
import math
import time
import numpy as np
import json

from yrsn.core.decomposition.constraint_taxonomy import (
    ConstraintTier,
    MemristorModel,
    TIER_TO_MEMRISTOR,
    TieredConstraint,
    ViolationSeverity,
)
from yrsn.core.temperature import (
    QualityPhase,
    get_quality_phase,
)

# Hexagonal architecture: Import port interface for type hints
if TYPE_CHECKING:
    from yrsn.ports.gearbox import IGearbox


# =============================================================================
# Memristor Models
# =============================================================================


class MemristorState(Enum):
    """Memristor operational state."""
    RESET = "reset"          # Low resistance state
    SET = "set"              # High resistance state
    INTERMEDIATE = "intermediate"  # Between states


@dataclass
class MemristorParams:
    """Parameters for memristor behavioral model."""
    # Resistance bounds
    R_on: float = 100.0      # Minimum resistance (Ohms)
    R_off: float = 16000.0   # Maximum resistance (Ohms)

    # Device parameters
    D: float = 10e-9         # Device thickness (nm)
    mu_v: float = 1e-14      # Ion mobility (m²/V·s)

    # Model-specific
    p: int = 2               # Window function exponent (Joglekar)
    threshold_v: float = 0.1 # Threshold voltage for threshold-adaptive model

    # Timing
    dt_default: float = 1e-3 # Default time step (s)


@dataclass
class MemristorHistory:
    """Tracking memristor state over time."""
    timestamps: List[float] = field(default_factory=list)
    resistances: List[float] = field(default_factory=list)
    voltages: List[float] = field(default_factory=list)
    currents: List[float] = field(default_factory=list)
    states: List[float] = field(default_factory=list)  # w values

    def record(self, t: float, R: float, V: float, I: float, w: float):
        """Record a data point."""
        self.timestamps.append(t)
        self.resistances.append(R)
        self.voltages.append(V)
        self.currents.append(I)
        self.states.append(w)

    def get_recent(self, n: int = 10) -> Dict[str, List[float]]:
        """Get most recent n records."""
        return {
            "timestamps": self.timestamps[-n:],
            "resistances": self.resistances[-n:],
            "voltages": self.voltages[-n:],
            "currents": self.currents[-n:],
            "states": self.states[-n:],
        }

    def clear(self):
        """Clear history."""
        self.timestamps.clear()
        self.resistances.clear()
        self.voltages.clear()
        self.currents.clear()
        self.states.clear()


class VirtualMemristor:
    """
    Virtual memristor device with configurable behavioral model.

    Implements four models from the Four Pillars document:
    1. LINEAR_ION_DRIFT: Proportional dw/dt = μ_v * R_on * i / D
    2. NONLINEAR_ION_DRIFT: Joglekar window f(w) = 1 - (2w - 1)^(2p)
    3. THRESHOLD_ADAPTIVE: Direction-dependent with threshold
    4. SPINTRONIC: Placeholder for future extension

    Parameters
    ----------
    model : MemristorModel
        Behavioral model to use
    params : MemristorParams, optional
        Device parameters
    initial_w : float
        Initial state variable (0=fully SET, 1=fully RESET)
    """

    def __init__(
        self,
        model: MemristorModel = MemristorModel.LINEAR_ION_DRIFT,
        params: Optional[MemristorParams] = None,
        initial_w: float = 0.5,
    ):
        self.model = model
        self.params = params or MemristorParams()

        # State variables
        self.w = np.clip(initial_w, 0.0, 1.0)  # Normalized state [0, 1]
        self.R = self._compute_resistance()

        # History tracking
        self.history = MemristorHistory()
        self.total_time = 0.0

        # Record initial state
        self.history.record(0.0, self.R, 0.0, 0.0, self.w)

    def _compute_resistance(self) -> float:
        """Compute resistance from state variable."""
        # Linear interpolation between R_on and R_off
        return self.params.R_on + self.w * (self.params.R_off - self.params.R_on)

    def _joglekar_window(self, w: float) -> float:
        """Joglekar window function for boundary effects."""
        return 1.0 - (2.0 * w - 1.0) ** (2 * self.params.p)

    def _biolek_window(self, w: float, i: float) -> float:
        """Biolek window function (direction-dependent)."""
        # Different behavior for positive vs negative current
        if i >= 0:
            return 1.0 - (w - 1.0) ** (2 * self.params.p)
        else:
            return 1.0 - w ** (2 * self.params.p)

    def update(self, voltage: float, dt: Optional[float] = None) -> float:
        """
        Update memristor state based on applied voltage.

        Parameters
        ----------
        voltage : float
            Applied voltage (V)
        dt : float, optional
            Time step (s), uses default if not provided

        Returns
        -------
        float
            New resistance value
        """
        dt = dt or self.params.dt_default
        p = self.params

        # Compute current
        I = voltage / self.R if self.R > 0 else 0.0

        # Compute dw/dt based on model
        # Each model represents a different point on the variance continuum:
        #   NONLINEAR_ION_DRIFT → High variance (exploratory, EMERGENT tier)
        #   LINEAR_ION_DRIFT    → Medium variance (adaptive, LEARNED tier)
        #   BOUNDED_DRIFT       → Low variance (stable, CONSOLIDATED tier)
        #   THRESHOLD_ADAPTIVE  → Zero variance below threshold (fixed, ACTUAL tier)

        if self.model == MemristorModel.NONLINEAR_ION_DRIFT:
            # High variance: Joglekar window allows large changes in middle,
            # but compresses at boundaries - encourages exploration
            window = self._joglekar_window(self.w)
            dw_dt = p.mu_v * p.R_on * I / p.D * window

        elif self.model == MemristorModel.LINEAR_ION_DRIFT:
            # Medium variance: Strukov model, dw/dt proportional to current
            # No window function - linear, predictable adaptation
            dw_dt = p.mu_v * p.R_on * I / p.D

        elif self.model == MemristorModel.BOUNDED_DRIFT:
            # Low variance: Slow adaptation within strict bounds (new for CONSOLIDATED tier)
            # Uses tight Joglekar window (high p) + damping factor
            window = self._joglekar_window(self.w)
            damping = 0.25  # 4x slower than linear
            dw_dt = p.mu_v * p.R_on * I / p.D * window * damping

        elif self.model == MemristorModel.THRESHOLD_ADAPTIVE:
            # Zero variance below threshold: Biolek window + hard threshold
            # Only changes when signal is strong enough - permanent knowledge
            if abs(voltage) < p.threshold_v:
                dw_dt = 0.0  # No change below threshold
            else:
                window = self._biolek_window(self.w, I)
                dw_dt = p.mu_v * p.R_on * I / p.D * window
        else:
            # Default to linear
            dw_dt = p.mu_v * p.R_on * I / p.D

        # Update state
        self.w = np.clip(self.w + dw_dt * dt, 0.0, 1.0)
        self.R = self._compute_resistance()
        self.total_time += dt

        # Record history
        self.history.record(self.total_time, self.R, voltage, I, self.w)

        return self.R

    def get_constraint_weight(self) -> float:
        """
        Get constraint weight from memristor state.

        Maps normalized state w ∈ [0, 1] to weight:
        - w = 0: Maximum weight (fully enforced)
        - w = 1: Minimum weight (relaxed)
        """
        return 1.0 - self.w

    def set_constraint_weight(self, weight: float):
        """
        Set constraint weight by adjusting memristor state.

        Parameters
        ----------
        weight : float
            Desired weight [0, 1]
        """
        self.w = np.clip(1.0 - weight, 0.0, 1.0)
        self.R = self._compute_resistance()

    def reset(self, w: float = 0.5):
        """Reset memristor to specified state."""
        self.w = np.clip(w, 0.0, 1.0)
        self.R = self._compute_resistance()
        self.history.clear()
        self.total_time = 0.0
        self.history.record(0.0, self.R, 0.0, 0.0, self.w)

    def get_state(self) -> Dict[str, Any]:
        """Get current state as dictionary."""
        return {
            "model": self.model.value,
            "w": self.w,
            "R": self.R,
            "weight": self.get_constraint_weight(),
            "total_time": self.total_time,
        }


# =============================================================================
# Memristor Constraint Array
# =============================================================================


@dataclass
class MemristorConstraint:
    """A constraint managed by a virtual memristor."""
    name: str
    tier: ConstraintTier
    memristor: VirtualMemristor
    threshold: float = 0.5
    description: str = ""

    @property
    def model(self) -> MemristorModel:
        """Get memristor model for this constraint's tier."""
        return TIER_TO_MEMRISTOR[self.tier]

    @property
    def weight(self) -> float:
        """Get current constraint weight."""
        return self.memristor.get_constraint_weight()

    def to_tiered_constraint(self) -> TieredConstraint:
        """Convert to TieredConstraint for taxonomy checking."""
        return TieredConstraint(
            name=self.name,
            tier=self.tier,
            threshold=self.threshold * self.weight,  # Scale by memristor weight
            description=self.description,
        )


class MemristorConstraintArray:
    """
    Array of memristor-managed constraints.

    Provides:
    - Constraint weight management via memristors
    - Tier-based model assignment
    - Bulk update operations
    - State persistence

    Usage:
        array = MemristorConstraintArray()
        array.add_constraint("no_hallucination", ConstraintTier.ACTUAL, threshold=0.95)
        array.add_constraint("relevance_min", ConstraintTier.LEARNED, threshold=0.5)

        # Update based on feedback
        array.apply_feedback("no_hallucination", voltage=0.5, duration=0.1)

        # Get all weights
        weights = array.get_weights()
    """

    def __init__(self, params: Optional[MemristorParams] = None):
        """
        Initialize constraint array.

        Parameters
        ----------
        params : MemristorParams, optional
            Shared memristor parameters
        """
        self.params = params or MemristorParams()
        self.constraints: Dict[str, MemristorConstraint] = {}
        self._creation_time = time.time()

    def add_constraint(
        self,
        name: str,
        tier: ConstraintTier,
        threshold: float = 0.5,
        description: str = "",
        initial_weight: float = 1.0,
    ) -> MemristorConstraint:
        """
        Add a new memristor-managed constraint.

        Parameters
        ----------
        name : str
            Unique constraint name
        tier : ConstraintTier
            Constraint tier (determines memristor model)
        threshold : float
            Base threshold for violation
        description : str
            Human-readable description
        initial_weight : float
            Initial constraint weight [0, 1]

        Returns
        -------
        MemristorConstraint
            The created constraint
        """
        model = TIER_TO_MEMRISTOR[tier]
        memristor = VirtualMemristor(
            model=model,
            params=self.params,
            initial_w=1.0 - initial_weight,  # w=0 → weight=1
        )

        constraint = MemristorConstraint(
            name=name,
            tier=tier,
            memristor=memristor,
            threshold=threshold,
            description=description,
        )

        self.constraints[name] = constraint
        return constraint

    def get_constraint(self, name: str) -> Optional[MemristorConstraint]:
        """Get constraint by name."""
        return self.constraints.get(name)

    def get_weights(self) -> Dict[str, float]:
        """Get all constraint weights."""
        return {name: c.weight for name, c in self.constraints.items()}

    def get_weights_by_tier(self, tier: ConstraintTier) -> Dict[str, float]:
        """Get weights for constraints of a specific tier."""
        return {
            name: c.weight
            for name, c in self.constraints.items()
            if c.tier == tier
        }

    def apply_feedback(
        self,
        name: str,
        voltage: float,
        duration: float = 0.01,
        steps: int = 10,
    ):
        """
        Apply feedback signal to a constraint's memristor.

        Parameters
        ----------
        name : str
            Constraint name
        voltage : float
            Feedback voltage (positive = increase weight, negative = decrease)
        duration : float
            Total duration of signal (s)
        steps : int
            Number of update steps
        """
        if name not in self.constraints:
            raise KeyError(f"Constraint not found: {name}")

        constraint = self.constraints[name]
        dt = duration / steps

        for _ in range(steps):
            constraint.memristor.update(voltage, dt)

    def apply_batch_feedback(
        self,
        feedbacks: Dict[str, float],
        duration: float = 0.01,
    ):
        """
        Apply feedback to multiple constraints.

        Parameters
        ----------
        feedbacks : dict
            Mapping of constraint name → voltage
        duration : float
            Duration per constraint
        """
        for name, voltage in feedbacks.items():
            if name in self.constraints:
                self.apply_feedback(name, voltage, duration)

    def relax_all(self, tier: Optional[ConstraintTier] = None, amount: float = 0.1):
        """
        Relax constraints (decrease weights).

        Parameters
        ----------
        tier : ConstraintTier, optional
            Only relax constraints of this tier
        amount : float
            Relaxation amount (applied as negative voltage)
        """
        for name, constraint in self.constraints.items():
            if tier is None or constraint.tier == tier:
                self.apply_feedback(name, voltage=-amount)

    def strengthen_all(self, tier: Optional[ConstraintTier] = None, amount: float = 0.1):
        """
        Strengthen constraints (increase weights).

        Parameters
        ----------
        tier : ConstraintTier, optional
            Only strengthen constraints of this tier
        amount : float
            Strengthening amount (applied as positive voltage)
        """
        for name, constraint in self.constraints.items():
            if tier is None or constraint.tier == tier:
                self.apply_feedback(name, voltage=amount)

    def get_tiered_constraints(self) -> List[TieredConstraint]:
        """Get all constraints as TieredConstraint objects."""
        return [c.to_tiered_constraint() for c in self.constraints.values()]

    def get_state(self) -> Dict[str, Any]:
        """Get complete array state."""
        return {
            "constraints": {
                name: {
                    "tier": c.tier.value,
                    "weight": c.weight,
                    "threshold": c.threshold,
                    "memristor_state": c.memristor.get_state(),
                }
                for name, c in self.constraints.items()
            },
            "creation_time": self._creation_time,
            "total_constraints": len(self.constraints),
        }

    def load_state(self, state: Dict[str, Any]):
        """
        Load state from dictionary.

        Parameters
        ----------
        state : dict
            State dictionary from get_state()
        """
        for name, cstate in state.get("constraints", {}).items():
            tier = ConstraintTier(cstate["tier"])
            if name in self.constraints:
                # Update existing constraint
                self.constraints[name].memristor.set_constraint_weight(cstate["weight"])
            else:
                # Create new constraint
                self.add_constraint(
                    name=name,
                    tier=tier,
                    threshold=cstate.get("threshold", 0.5),
                    initial_weight=cstate["weight"],
                )


# =============================================================================
# Pillar 2 ↔ Pillar 4 Bridge
# =============================================================================


@dataclass
class CurriculumStage:
    """A stage in the curriculum progression."""
    stage_id: int
    name: str
    description: str
    quality_threshold: float  # Minimum quality to enter
    active_tiers: List[ConstraintTier]  # Which constraint tiers are active
    tau_multiplier: float = 1.0  # Tau (τ) adjustment multiplier
    rank_adjustment: int = 0  # Rank adjustment from base


# Default curriculum stages (4 stages aligned with Bloom's Taxonomy and 4 constraint tiers)
# Note: These thresholds are configurable hyperparameters, NOT BBP-derived.
# They can be learned from validation performance or sensor-adapted in real-time.
#
# Stage ↔ Tier alignment:
#   Foundation → EMERGENT (short-term, exploratory)
#   Expansion  → LEARNED (medium-term, being reinforced)
#   Refinement → CONSOLIDATED (long-term, validated)
#   Mastery    → ACTUAL (permanent, core knowledge)
#
DEFAULT_CURRICULUM_STAGES = [
    CurriculumStage(
        stage_id=1,
        name="Foundation",
        description="EMERGENT constraints only (Remember, Understand)",
        quality_threshold=0.0,
        active_tiers=[ConstraintTier.ACTUAL, ConstraintTier.EMERGENT],  # Core + exploratory
        tau_multiplier=1.5,  # Higher tau (more exploration)
        rank_adjustment=-5,
    ),
    CurriculumStage(
        stage_id=2,
        name="Expansion",
        description="Add LEARNED constraints (Apply)",
        quality_threshold=0.4,
        active_tiers=[ConstraintTier.ACTUAL, ConstraintTier.EMERGENT, ConstraintTier.LEARNED],
        tau_multiplier=1.2,
        rank_adjustment=-2,
    ),
    CurriculumStage(
        stage_id=3,
        name="Refinement",
        description="Add CONSOLIDATED constraints (Analyze, Evaluate)",
        quality_threshold=0.6,
        active_tiers=[ConstraintTier.ACTUAL, ConstraintTier.EMERGENT, ConstraintTier.LEARNED, ConstraintTier.CONSOLIDATED],
        tau_multiplier=1.0,
        rank_adjustment=0,
    ),
    CurriculumStage(
        stage_id=4,
        name="Mastery",
        description="All 4 tiers fully active (Create)",
        quality_threshold=0.8,
        active_tiers=[ConstraintTier.ACTUAL, ConstraintTier.CONSOLIDATED, ConstraintTier.LEARNED, ConstraintTier.EMERGENT],
        tau_multiplier=0.7,  # Lower tau (more exploitation)
        rank_adjustment=5,
    ),
]


class Pillar2Pillar4Bridge:
    """
    Bidirectional bridge between Pillar 2 (Adaptive Scaling) and Pillar 4 (Curriculum).

    Pillar 2 → Pillar 4:
    - Temperature τ → constraint relaxation
    - Quality α → curriculum stage
    - Rank ℓ → model capacity
    - Phase transitions → stage advancement

    Pillar 4 → Pillar 2:
    - Memristor state → quality estimation
    - Constraint satisfaction → SNR estimation
    - Learning progress → metrics

    Usage:
        bridge = Pillar2Pillar4Bridge()

        # Pillar 2 → 4
        stage = bridge.quality_to_curriculum_stage(quality=0.5)
        relaxation = bridge.temperature_to_constraint_relaxation(tau=2.0)

        # Pillar 4 → 2
        quality = bridge.memristor_state_to_quality(array)
    """

    def __init__(
        self,
        stages: Optional[List[CurriculumStage]] = None,
        base_tau: float = 1.0,
        base_rank: int = 10,
    ):
        """
        Initialize bridge.

        Parameters
        ----------
        stages : list, optional
            Curriculum stages (uses defaults if not provided)
        base_tau : float
            Base tau (τ = 1/α_ω) for scaling
        base_rank : int
            Base rank for capacity
        """
        self.stages = stages or DEFAULT_CURRICULUM_STAGES
        self.base_tau = base_tau
        self.base_rank = base_rank

        # Sort stages by quality threshold
        self.stages = sorted(self.stages, key=lambda s: s.quality_threshold)

    # =========================================================================
    # Pillar 2 → Pillar 4
    # =========================================================================

    def quality_to_curriculum_stage(self, quality: float) -> CurriculumStage:
        """
        Map quality metric to curriculum stage.

        Parameters
        ----------
        quality : float
            Quality metric α ∈ [0, 1]

        Returns
        -------
        CurriculumStage
            Appropriate curriculum stage
        """
        # Find highest stage that quality qualifies for
        selected = self.stages[0]
        for stage in self.stages:
            if quality >= stage.quality_threshold:
                selected = stage
        return selected

    def tau_to_constraint_relaxation(self, tau: float) -> float:
        """
        Map tau to constraint relaxation factor.

        Higher tau → more relaxed constraints

        Parameters
        ----------
        tau : float
            Tau value (τ = 1/α_ω)

        Returns
        -------
        float
            Relaxation factor (1.0 = no change, >1.0 = relaxed, <1.0 = stricter)
        """
        # Relative to base tau
        return tau / self.base_tau

    # Backward compatibility alias
    temperature_to_constraint_relaxation = tau_to_constraint_relaxation

    def rank_to_model_capacity(self, rank: int) -> Dict[str, int]:
        """
        Map rank to model capacity recommendations.

        Parameters
        ----------
        rank : int
            Recommended rank from Pillar 2

        Returns
        -------
        dict
            Capacity recommendations
        """
        return {
            "max_constraints": min(100, rank * 2),
            "max_emergent": rank,
            "max_learned": rank // 2,
            "suggested_batch_size": min(32, rank),
        }

    def phase_to_stage_transition(
        self,
        old_phase: QualityPhase,
        new_phase: QualityPhase,
    ) -> Optional[Dict[str, Any]]:
        """
        Determine if phase transition triggers stage change.

        Parameters
        ----------
        old_phase, new_phase : QualityPhase
            Previous and current phases

        Returns
        -------
        dict or None
            Stage transition info if triggered
        """
        if old_phase == new_phase:
            return None

        # Map phases to qualities (approximate)
        phase_qualities = {
            QualityPhase.LOW: 0.2,
            QualityPhase.MEDIUM: 0.55,
            QualityPhase.HIGH: 0.85,
        }

        old_q = phase_qualities[old_phase]
        new_q = phase_qualities[new_phase]

        old_stage = self.quality_to_curriculum_stage(old_q)
        new_stage = self.quality_to_curriculum_stage(new_q)

        if old_stage.stage_id != new_stage.stage_id:
            return {
                "from_stage": old_stage,
                "to_stage": new_stage,
                "direction": "advance" if new_stage.stage_id > old_stage.stage_id else "regress",
                "phase_change": f"{old_phase.name} → {new_phase.name}",
            }
        return None

    # =========================================================================
    # Pillar 4 → Pillar 2
    # =========================================================================

    def memristor_state_to_quality(
        self,
        array: MemristorConstraintArray,
    ) -> float:
        """
        Estimate quality from memristor constraint array state.

        Higher weights (stricter constraints) indicate higher expected quality.

        Parameters
        ----------
        array : MemristorConstraintArray
            Constraint array

        Returns
        -------
        float
            Estimated quality α ∈ [0, 1]
        """
        if not array.constraints:
            return 0.5  # Default

        # Weighted average by tier importance
        tier_weights = {
            ConstraintTier.ACTUAL: 3.0,
            ConstraintTier.LEARNED: 2.0,
            ConstraintTier.EMERGENT: 1.0,
        }

        total_weight = 0.0
        weighted_sum = 0.0

        for constraint in array.constraints.values():
            tw = tier_weights[constraint.tier]
            weighted_sum += constraint.weight * tw
            total_weight += tw

        if total_weight == 0:
            return 0.5

        return weighted_sum / total_weight

    def constraint_satisfaction_to_snr(
        self,
        satisfaction_rates: Dict[str, float],
        tier_rates: Optional[Dict[ConstraintTier, float]] = None,
    ) -> float:
        """
        Estimate signal-to-noise ratio from constraint satisfaction.

        Parameters
        ----------
        satisfaction_rates : dict
            Mapping of constraint name → satisfaction rate [0, 1]
        tier_rates : dict, optional
            Aggregate rates by tier

        Returns
        -------
        float
            Estimated SNR (higher = better)
        """
        if not satisfaction_rates:
            return 1.0

        # Average satisfaction is proxy for SNR
        avg_satisfaction = np.mean(list(satisfaction_rates.values()))

        # Convert to SNR-like scale
        # 100% satisfaction → SNR = 10
        # 50% satisfaction → SNR = 1
        # 0% satisfaction → SNR = 0.1
        snr = 10 ** (2 * avg_satisfaction - 1)

        return float(snr)

    def learning_progress_to_metrics(
        self,
        current_stage: CurriculumStage,
        constraint_weights: Dict[str, float],
        satisfaction_history: List[float],
    ) -> Dict[str, float]:
        """
        Compute learning progress metrics for Pillar 2.

        Parameters
        ----------
        current_stage : CurriculumStage
            Current curriculum stage
        constraint_weights : dict
            Current constraint weights
        satisfaction_history : list
            Recent satisfaction rates

        Returns
        -------
        dict
            Metrics for Pillar 2 integration
        """
        avg_weight = np.mean(list(constraint_weights.values())) if constraint_weights else 0.5
        avg_satisfaction = np.mean(satisfaction_history) if satisfaction_history else 0.5

        # Trend (are we improving?)
        if len(satisfaction_history) >= 5:
            recent = satisfaction_history[-5:]
            earlier = satisfaction_history[-10:-5] if len(satisfaction_history) >= 10 else recent
            trend = np.mean(recent) - np.mean(earlier)
        else:
            trend = 0.0

        return {
            "stage_id": current_stage.stage_id,
            "stage_progress": avg_satisfaction,
            "constraint_weight_avg": avg_weight,
            "satisfaction_trend": trend,
            "estimated_quality": self.memristor_state_to_quality(
                MemristorConstraintArray()  # Would need actual array
            ) if False else avg_weight * avg_satisfaction,
            "recommended_tau_mult": current_stage.tau_multiplier,
            "recommended_rank_adj": current_stage.rank_adjustment,
        }


# =============================================================================
# Replay Consolidation (prevents catastrophic forgetting)
# =============================================================================


@dataclass
class ReplayExperience:
    """A single experience for replay."""
    state: Any
    action: Any
    quality: float  # α score
    stage: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


class ReplayBuffer:
    """
    Experience replay buffer for curriculum consolidation.

    Stores high-quality experiences and replays them to prevent
    catastrophic forgetting during curriculum progression.

    Features:
    - Priority sampling based on quality (α)
    - Stage-aware storage (maintains diversity across stages)
    - Configurable capacity with intelligent eviction

    Usage:
        buffer = ReplayBuffer(capacity=1000)

        # Store experience
        buffer.store(state, action, quality=0.8, stage="Expansion")

        # Sample for consolidation
        experiences = buffer.sample(batch_size=32, priority_alpha=0.6)

        # Consolidate (replay to strengthen weights)
        for exp in experiences:
            model.reinforce(exp.state, exp.action)
    """

    def __init__(
        self,
        capacity: int = 10000,
        min_quality_threshold: float = 0.5,
        stage_balance: bool = True,
    ):
        """
        Initialize replay buffer.

        Parameters
        ----------
        capacity : int
            Maximum number of experiences to store
        min_quality_threshold : float
            Minimum quality to store (filters low-quality experiences)
        stage_balance : bool
            If True, maintain balanced representation across stages
        """
        self.capacity = capacity
        self.min_quality_threshold = min_quality_threshold
        self.stage_balance = stage_balance

        self.buffer: deque = deque(maxlen=capacity)
        self.stage_counts: Dict[str, int] = {}

    def store(
        self,
        state: Any,
        action: Any,
        quality: float,
        stage: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Store an experience in the buffer.

        Parameters
        ----------
        state : any
            State representation
        action : any
            Action taken
        quality : float
            Quality score α ∈ [0, 1]
        stage : str
            Curriculum stage name
        metadata : dict, optional
            Additional metadata

        Returns
        -------
        bool
            True if stored, False if rejected (below threshold)
        """
        # Quality gate
        if quality < self.min_quality_threshold:
            return False

        experience = ReplayExperience(
            state=state,
            action=action,
            quality=quality,
            stage=stage,
            metadata=metadata or {},
        )

        self.buffer.append(experience)
        self.stage_counts[stage] = self.stage_counts.get(stage, 0) + 1

        return True

    def sample(
        self,
        batch_size: int = 32,
        priority_alpha: float = 0.6,
        stage_filter: Optional[str] = None,
    ) -> List[ReplayExperience]:
        """
        Sample experiences with priority based on quality.

        Parameters
        ----------
        batch_size : int
            Number of experiences to sample
        priority_alpha : float
            Priority exponent (0 = uniform, 1 = fully prioritized by quality)
        stage_filter : str, optional
            Only sample from this stage

        Returns
        -------
        list of ReplayExperience
            Sampled experiences
        """
        if not self.buffer:
            return []

        # Filter by stage if requested
        candidates = list(self.buffer)
        if stage_filter:
            candidates = [e for e in candidates if e.stage == stage_filter]

        if not candidates:
            return []

        # Compute priorities
        qualities = np.array([e.quality for e in candidates])
        priorities = qualities ** priority_alpha
        priorities /= priorities.sum()

        # Sample
        n_samples = min(batch_size, len(candidates))
        indices = np.random.choice(len(candidates), size=n_samples, replace=False, p=priorities)

        return [candidates[i] for i in indices]

    def sample_balanced(self, per_stage: int = 8) -> List[ReplayExperience]:
        """
        Sample balanced experiences across all stages.

        Parameters
        ----------
        per_stage : int
            Number of samples per stage

        Returns
        -------
        list of ReplayExperience
            Balanced samples
        """
        samples = []
        for stage in self.stage_counts.keys():
            stage_samples = self.sample(batch_size=per_stage, stage_filter=stage)
            samples.extend(stage_samples)
        return samples

    def get_statistics(self) -> Dict[str, Any]:
        """Get buffer statistics."""
        if not self.buffer:
            return {"size": 0, "stages": {}}

        qualities = [e.quality for e in self.buffer]
        return {
            "size": len(self.buffer),
            "capacity": self.capacity,
            "fill_ratio": len(self.buffer) / self.capacity,
            "avg_quality": np.mean(qualities),
            "min_quality": np.min(qualities),
            "max_quality": np.max(qualities),
            "stages": dict(self.stage_counts),
        }

    def clear(self):
        """Clear the buffer."""
        self.buffer.clear()
        self.stage_counts.clear()


@dataclass
class ConsolidationResult:
    """Result of a consolidation phase."""
    n_replayed: int
    avg_quality: float
    stages_consolidated: List[str]
    weight_updates: Dict[str, float]
    duration_ms: float


class ReplayConsolidator:
    """
    Manages replay consolidation after each epoch.

    Consolidation Process:
    1. Sample high-quality experiences from replay buffer
    2. Re-apply them to strengthen memristor weights
    3. Blend old knowledge with new learning

    This prevents catastrophic forgetting by periodically
    reinforcing previously learned patterns.

    Usage:
        consolidator = ReplayConsolidator(buffer, constraint_array)

        # After each epoch
        result = consolidator.consolidate(
            n_samples=64,
            consolidation_strength=0.3
        )

        print(f"Replayed {result.n_replayed} experiences")
    """

    def __init__(
        self,
        replay_buffer: ReplayBuffer,
        constraint_array: Optional["MemristorConstraintArray"] = None,
        consolidation_rate: float = 0.3,
    ):
        """
        Initialize consolidator.

        Parameters
        ----------
        replay_buffer : ReplayBuffer
            Buffer containing experiences to replay
        constraint_array : MemristorConstraintArray, optional
            Constraint array to update during consolidation
        consolidation_rate : float
            How strongly to reinforce (0 = no effect, 1 = full replacement)
        """
        self.buffer = replay_buffer
        self.constraint_array = constraint_array
        self.consolidation_rate = consolidation_rate

        # Track consolidation history
        self.consolidation_history: List[ConsolidationResult] = []

    def consolidate(
        self,
        n_samples: int = 64,
        balanced: bool = True,
        consolidation_strength: Optional[float] = None,
    ) -> ConsolidationResult:
        """
        Perform consolidation by replaying experiences.

        Parameters
        ----------
        n_samples : int
            Number of experiences to replay
        balanced : bool
            If True, sample balanced across stages
        consolidation_strength : float, optional
            Override default consolidation rate

        Returns
        -------
        ConsolidationResult
            Consolidation metrics
        """
        start_time = time.time()
        strength = consolidation_strength or self.consolidation_rate

        # Sample experiences
        if balanced:
            per_stage = max(1, n_samples // max(1, len(self.buffer.stage_counts)))
            experiences = self.buffer.sample_balanced(per_stage=per_stage)
        else:
            experiences = self.buffer.sample(batch_size=n_samples, priority_alpha=0.6)

        if not experiences:
            return ConsolidationResult(
                n_replayed=0,
                avg_quality=0.0,
                stages_consolidated=[],
                weight_updates={},
                duration_ms=0.0,
            )

        # Consolidate by reinforcing constraint weights
        weight_updates = {}
        stages_seen = set()

        for exp in experiences:
            stages_seen.add(exp.stage)

            # Apply consolidation to constraints based on experience quality
            if self.constraint_array:
                # Higher quality experiences strengthen constraints more
                voltage = exp.quality * strength * 0.5  # Positive = strengthen

                for name, constraint in self.constraint_array.constraints.items():
                    # Only consolidate constraints active in this stage
                    constraint.memristor.update(voltage, dt=0.001)
                    weight_updates[name] = weight_updates.get(name, 0) + voltage

        duration_ms = (time.time() - start_time) * 1000
        avg_quality = np.mean([e.quality for e in experiences])

        result = ConsolidationResult(
            n_replayed=len(experiences),
            avg_quality=float(avg_quality),
            stages_consolidated=list(stages_seen),
            weight_updates=weight_updates,
            duration_ms=duration_ms,
        )

        self.consolidation_history.append(result)
        return result

    def get_consolidation_stats(self) -> Dict[str, Any]:
        """Get consolidation statistics."""
        if not self.consolidation_history:
            return {"total_consolidations": 0}

        return {
            "total_consolidations": len(self.consolidation_history),
            "total_replayed": sum(r.n_replayed for r in self.consolidation_history),
            "avg_quality_replayed": np.mean([r.avg_quality for r in self.consolidation_history]),
            "total_duration_ms": sum(r.duration_ms for r in self.consolidation_history),
        }


# =============================================================================
# Curriculum Manager
# =============================================================================


@dataclass
class CurriculumProgress:
    """Tracks curriculum learning progress."""
    current_stage: CurriculumStage
    stage_history: List[Tuple[float, int]] = field(default_factory=list)  # (timestamp, stage_id)
    satisfaction_history: deque = field(default_factory=lambda: deque(maxlen=100))
    quality_history: deque = field(default_factory=lambda: deque(maxlen=100))

    def record(self, satisfaction: float, quality: float):
        """Record a learning step."""
        self.satisfaction_history.append(satisfaction)
        self.quality_history.append(quality)

    def should_advance(self, threshold: float = 0.9, window: int = 10) -> bool:
        """Check if should advance to next stage."""
        if len(self.satisfaction_history) < window:
            return False
        recent = list(self.satisfaction_history)[-window:]
        return np.mean(recent) >= threshold

    def should_regress(self, threshold: float = 0.3, window: int = 10) -> bool:
        """Check if should regress to previous stage."""
        if len(self.satisfaction_history) < window:
            return False
        recent = list(self.satisfaction_history)[-window:]
        return np.mean(recent) < threshold


class CurriculumManager:
    """
    Manages curriculum learning with memristor-based constraints.

    TWO-LEVEL CONTROL ARCHITECTURE
    ==============================
    This manager operates at TWO levels that DO NOT CONFLICT:

    MACRO LEVEL: Stages (this manager's original job)
        - Foundation → Intermediate → Advanced → Mastery
        - Transitions based on SUSTAINED satisfaction over time
        - Controls: "What lesson/topic are we on?"
        - Slow progression (requires consistent performance)

    MICRO LEVEL: Gears (via integrated AdaptiveGearbox)
        - G1 (easy) → G2 → G3 → G4 (expert)
        - Transitions based on IMMEDIATE τ/κ signals with hysteresis
        - Controls: "How hard is THIS problem within the lesson?"
        - Fast adaptation (responds to moment-to-moment performance)

    Example:
        A student in "Advanced" stage (macro) might work on:
        - G2 difficulty problems when warming up
        - G3 difficulty when performing well
        - G1 difficulty after a mistake (gearbox downshifts)

    CONTROL FLOW (don't break this!):
        1. step() receives quality, satisfaction, kappa
        2. Gearbox adjusts gear (micro) based on κ/τ with hysteresis
        3. Stage progression checked (macro) based on sustained satisfaction
        4. Memristor weights updated
        5. Replay consolidation
        6. Return result with both stage AND gear info

    CONFIRMATION (not control):
        - Lyapunov stability (in YRSNCertificate) CONFIRMS decisions
        - Lyapunov does NOT control - gearbox controls

    Reference: docs/papers/gap_analysis/CONTROLLER_ARCHITECTURE_DIAGRAMS.md

    Integrates:
    - MemristorConstraintArray for constraint management
    - Pillar2Pillar4Bridge for cross-pillar communication
    - CurriculumProgress for stage tracking
    - ReplayBuffer + ReplayConsolidator for preventing catastrophic forgetting
    - AdaptiveGearbox for micro-level difficulty control (NEW)

    Training Loop with Consolidation:
        manager = CurriculumManager(enable_replay=True, driving_mode='eco')

        for epoch in range(n_epochs):
            # Training step with κ signal
            result = manager.step(quality=0.6, satisfaction=0.8, kappa=0.75)

            # Store experience for future replay
            manager.store_experience(state, action, quality=0.6)

            # Check both levels
            print(f"Stage: {result['stage']}, Gear: {result['gear']}")
            print(f"Consolidated: {result['consolidation']['n_replayed']} experiences")

    Usage without consolidation:
        manager = CurriculumManager(enable_replay=False)
        result = manager.step(quality=0.6, satisfaction=0.8, kappa=0.75)
    """

    def __init__(
        self,
        stages: Optional[List[CurriculumStage]] = None,
        auto_advance: bool = True,
        auto_regress: bool = True,
        enable_replay: bool = True,
        replay_capacity: int = 10000,
        consolidation_rate: float = 0.3,
        consolidate_every_step: bool = True,
        consolidation_samples: int = 32,
        # Gearbox integration (NEW) - hexagonal architecture
        gearbox: Optional['IGearbox'] = None,
        driving_mode: str = "eco",
    ):
        """
        Initialize curriculum manager.

        Parameters
        ----------
        stages : list, optional
            Curriculum stages
        auto_advance : bool
            Automatically advance stages based on performance
        auto_regress : bool
            Automatically regress stages on poor performance
        enable_replay : bool
            Enable replay buffer and consolidation
        replay_capacity : int
            Maximum experiences to store in replay buffer
        consolidation_rate : float
            How strongly to reinforce during consolidation (0-1)
        consolidate_every_step : bool
            If True, consolidate after every step; if False, call consolidate() manually
        consolidation_samples : int
            Number of experiences to replay per consolidation
        gearbox : IGearbox, optional
            Gearbox controller (port interface) for gear shifting with hysteresis.
            If None, creates AdaptiveGearbox as default implementation.
            Hexagonal architecture: Core depends on port, not concrete adapter.
        driving_mode : str
            Driving mode for gearbox: 'eco', 'sport', 'manual'
        """
        self.stages = stages or DEFAULT_CURRICULUM_STAGES
        self.auto_advance = auto_advance
        self.auto_regress = auto_regress

        # Components
        self.constraint_array = MemristorConstraintArray()
        self.bridge = Pillar2Pillar4Bridge(stages=self.stages)

        # Gearbox integration (NEW) - for κ-guided curriculum control
        # Reference: docs/papers/gap_analysis/RSCT_YRSN_IMPLEMENTATION_APPENDIX.md
        # Hexagonal architecture: Dependency injection with default factory
        self._driving_mode = driving_mode
        if gearbox is None:
            self.gearbox: Optional['IGearbox'] = self._init_gearbox(driving_mode)
        else:
            self.gearbox: Optional['IGearbox'] = gearbox

        # Progress tracking
        self.progress = CurriculumProgress(current_stage=self.stages[0])

        # Replay consolidation (prevents catastrophic forgetting)
        self.enable_replay = enable_replay
        self.consolidate_every_step = consolidate_every_step
        self.consolidation_samples = consolidation_samples

        if enable_replay:
            self.replay_buffer = ReplayBuffer(
                capacity=replay_capacity,
                min_quality_threshold=0.4,  # Only store decent experiences
            )
            self.consolidator = ReplayConsolidator(
                replay_buffer=self.replay_buffer,
                constraint_array=self.constraint_array,
                consolidation_rate=consolidation_rate,
            )
        else:
            self.replay_buffer = None
            self.consolidator = None

        # Event callbacks
        self._on_stage_change: List[Callable] = []

        # Current gear (synced with gearbox)
        self._current_gear: int = 1

    def _init_gearbox(self, driving_mode: str = "eco") -> Optional['IGearbox']:
        """
        Initialize gearbox controller for κ-guided curriculum (default factory).

        The gearbox provides:
        - Hysteresis to prevent gear hunting
        - Driving modes (ECO/SPORT/MANUAL)
        - Auto-shifting based on quality signals

        Hexagonal architecture: Lazy import of concrete adapter as default factory.
        Returns port interface (IGearbox) to maintain architecture purity.

        Reference: src/yrsn/adapters/gearbox/adaptive.py

        Returns
        -------
        IGearbox or None
            AdaptiveGearbox instance if import succeeds, None if gearbox unavailable
        """
        try:
            from yrsn.adapters.gearbox.adaptive import AdaptiveGearbox
            from yrsn.core.gearbox.driving_mode import DrivingMode

            mode_map = {
                'eco': DrivingMode.ECO,
                'sport': DrivingMode.SPORT,
                'manual': DrivingMode.MANUAL,
            }
            mode = mode_map.get(driving_mode.lower(), DrivingMode.ECO)
            return AdaptiveGearbox(mode=mode)
        except ImportError:
            # Gearbox not available - curriculum will work without it
            return None

    def shift_gear(
        self,
        quality: float,
        kappa: Optional[float] = None,
        omega: float = 1.0,
        prior: float = 0.5,
    ) -> Optional[int]:
        """
        Attempt gear shift based on quality/κ signals (MICRO-LEVEL control).

        This is MICRO-level control (within-lesson difficulty adjustment).
        It does NOT affect MACRO-level stage progression.

        Uses AdaptiveGearbox with hysteresis to prevent oscillation.

        Two-Level Architecture:
            MACRO: CurriculumManager.stages (slow, sustained performance)
            MICRO: Gearbox.gears (fast, immediate κ/τ) ← THIS METHOD

        Parameters
        ----------
        quality : float
            Quality signal α (or α_ω from certificate)
        kappa : float, optional
            κ signal from RSCT (if available, used instead of quality)
        omega : float
            Reliability coefficient [0, 1]. Default 1.0 = in-distribution.
        prior : float
            Collapse prevention baseline. Default 0.5.

        Returns
        -------
        int or None
            New gear number if shifted, None if no shift

        Note:
            Lyapunov (in YRSNCertificate) CONFIRMS this decision was stable.
            Lyapunov does NOT control - this method controls.
        """
        if self.gearbox is None:
            return None

        try:
            from yrsn.core.gearbox.shifter import QualitySignals

            # Use κ if provided, otherwise use quality as proxy
            alpha = kappa if kappa is not None else quality
            # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
            alpha_omega = alpha * omega + (1 - omega) * prior
            tau = 1.0 / max(alpha_omega, 0.01)

            signals = QualitySignals(
                alpha=alpha,
                tau=tau,
                collapse_risk=0.0,
            )

            new_gear = self.gearbox.auto_shift(signals)
            if new_gear is not None:
                self._current_gear = new_gear.ordinal
                return new_gear.ordinal

        except ImportError:
            pass

        return None

    @property
    def current_gear(self) -> int:
        """Current gear number (1-4)."""
        return self._current_gear

    def add_constraint(
        self,
        name: str,
        tier: ConstraintTier,
        threshold: float = 0.5,
        description: str = "",
    ):
        """Add a constraint to the curriculum."""
        self.constraint_array.add_constraint(
            name=name,
            tier=tier,
            threshold=threshold,
            description=description,
        )

    def store_experience(
        self,
        state: Any,
        action: Any,
        quality: float,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Store an experience in the replay buffer.

        Call this after each training step to build up the replay buffer.

        Parameters
        ----------
        state : any
            State representation (can be features, observation, etc.)
        action : any
            Action taken (can be prediction, decision, etc.)
        quality : float
            Quality score α for this experience
        metadata : dict, optional
            Additional metadata to store

        Returns
        -------
        bool
            True if stored, False if rejected or replay disabled
        """
        if not self.enable_replay or self.replay_buffer is None:
            return False

        return self.replay_buffer.store(
            state=state,
            action=action,
            quality=quality,
            stage=self.progress.current_stage.name,
            metadata=metadata,
        )

    def consolidate(
        self,
        n_samples: Optional[int] = None,
        balanced: bool = True,
    ) -> Optional[ConsolidationResult]:
        """
        Manually trigger consolidation (replay of past experiences).

        Parameters
        ----------
        n_samples : int, optional
            Number of experiences to replay (uses default if not provided)
        balanced : bool
            If True, sample balanced across stages

        Returns
        -------
        ConsolidationResult or None
            Consolidation metrics, or None if replay disabled
        """
        if not self.enable_replay or self.consolidator is None:
            return None

        return self.consolidator.consolidate(
            n_samples=n_samples or self.consolidation_samples,
            balanced=balanced,
        )

    def step(
        self,
        quality: float,
        satisfaction: float,
        feedback: Optional[Dict[str, float]] = None,
        experience: Optional[Tuple[Any, Any]] = None,
        kappa: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Execute one curriculum step with optional consolidation and gear shifting.

        Parameters
        ----------
        quality : float
            Quality metric α from Pillar 2 (or α_ω from certificate)
        satisfaction : float
            Overall constraint satisfaction rate
        feedback : dict, optional
            Per-constraint feedback (name → voltage)
        experience : tuple of (state, action), optional
            Experience to store in replay buffer
        kappa : float, optional
            RSCT κ signal (encoding-solver compatibility).
            If provided, used for gear shifting instead of quality.

        Returns
        -------
        dict
            Step results including consolidation metrics and gear info

        Control Flow:
            QualitySignals(α/κ, τ) → GearShifter.decide_shift() → auto_shift()
                                              ↓
                              Stage progression + Memristor updates
                                              ↓
                              Replay consolidation
        """
        # =====================================================================
        # GEARBOX CONTROL PHASE (NEW)
        # =====================================================================
        gear_shifted = False
        old_gear = self._current_gear
        new_gear = self.shift_gear(quality, kappa=kappa)
        if new_gear is not None:
            gear_shifted = True

        # Record progress
        self.progress.record(satisfaction, quality)

        # Apply feedback if provided
        if feedback:
            self.constraint_array.apply_batch_feedback(feedback)

        # Store experience if provided
        if experience and self.enable_replay:
            state, action = experience
            self.store_experience(state, action, quality)

        # Check for stage transitions
        old_stage = self.progress.current_stage
        new_stage = old_stage

        if self.auto_advance and self.progress.should_advance():
            # Try to advance
            next_idx = self.stages.index(old_stage) + 1
            if next_idx < len(self.stages):
                candidate = self.stages[next_idx]
                if quality >= candidate.quality_threshold:
                    new_stage = candidate

        if self.auto_regress and self.progress.should_regress():
            # Try to regress
            prev_idx = self.stages.index(old_stage) - 1
            if prev_idx >= 0:
                new_stage = self.stages[prev_idx]

        # Handle stage change
        stage_changed = new_stage != old_stage
        if stage_changed:
            self.progress.stage_history.append((time.time(), new_stage.stage_id))
            self.progress.current_stage = new_stage

            # Notify callbacks
            for callback in self._on_stage_change:
                callback(old_stage, new_stage)

        # =====================================================================
        # REPLAY CONSOLIDATION PHASE
        # =====================================================================
        consolidation_result = None
        if self.enable_replay and self.consolidate_every_step:
            consolidation_result = self.consolidate()

        result = {
            "stage": new_stage.name,
            "stage_id": new_stage.stage_id,
            "stage_changed": stage_changed,
            "quality": quality,
            "satisfaction": satisfaction,
            "active_tiers": [t.value for t in new_stage.active_tiers],
            "tau_mult": new_stage.tau_multiplier,
            "rank_adj": new_stage.rank_adjustment,
            "constraint_weights": self.constraint_array.get_weights(),
            # Gearbox info (NEW)
            "gear": self._current_gear,
            "gear_shifted": gear_shifted,
            "gear_old": old_gear if gear_shifted else None,
            "kappa": kappa,
        }

        # Add consolidation info
        if consolidation_result:
            result["consolidation"] = {
                "n_replayed": consolidation_result.n_replayed,
                "avg_quality": consolidation_result.avg_quality,
                "stages_consolidated": consolidation_result.stages_consolidated,
                "duration_ms": consolidation_result.duration_ms,
            }
        else:
            result["consolidation"] = None

        return result

    def get_replay_stats(self) -> Dict[str, Any]:
        """Get replay buffer and consolidation statistics."""
        if not self.enable_replay:
            return {"enabled": False}

        return {
            "enabled": True,
            "buffer": self.replay_buffer.get_statistics() if self.replay_buffer else {},
            "consolidation": self.consolidator.get_consolidation_stats() if self.consolidator else {},
        }

    def get_active_constraints(self) -> List[MemristorConstraint]:
        """Get constraints active in current stage."""
        active_tiers = self.progress.current_stage.active_tiers
        return [
            c for c in self.constraint_array.constraints.values()
            if c.tier in active_tiers
        ]

    def get_tiered_constraints(self) -> List[TieredConstraint]:
        """Get active constraints as TieredConstraint objects."""
        return [c.to_tiered_constraint() for c in self.get_active_constraints()]

    def on_stage_change(self, callback: Callable):
        """Register callback for stage changes."""
        self._on_stage_change.append(callback)

    def get_pillar2_recommendations(self) -> Dict[str, float]:
        """Get recommendations for Pillar 2 based on curriculum state."""
        stage = self.progress.current_stage
        return {
            "tau_multiplier": stage.tau_multiplier,
            "rank_adjustment": stage.rank_adjustment,
            "constraint_strictness": np.mean([
                c.weight for c in self.get_active_constraints()
            ]) if self.get_active_constraints() else 1.0,
        }

    def apply_pillar2_quality(self, quality: float):
        """
        Apply Pillar 2 quality to adjust constraints.

        High quality → can relax emergent constraints
        Low quality → strengthen actual constraints
        """
        if quality > 0.8:
            # High quality - relax emergent
            self.constraint_array.relax_all(tier=ConstraintTier.EMERGENT, amount=0.05)
        elif quality < 0.3:
            # Low quality - strengthen actual
            self.constraint_array.strengthen_all(tier=ConstraintTier.ACTUAL, amount=0.1)


# =============================================================================
# Sensor-Driven Constraint Modulation
# =============================================================================


@dataclass
class SensorReading:
    """A sensor reading."""
    sensor_id: str
    value: float
    timestamp: float = field(default_factory=time.time)
    unit: str = ""


class SensorConstraintModulator:
    """
    Modulates constraint weights based on sensor readings.

    Enables external signals (temperature, humidity, etc.) to
    influence constraint behavior through memristor dynamics.

    Usage:
        modulator = SensorConstraintModulator(constraint_array)
        modulator.add_mapping("temperature", "coherence",
                             transform=lambda t: (t - 20) / 50)  # 20°C → 0, 70°C → 1

        # Apply sensor reading
        modulator.update(SensorReading("temperature", 35.0))
    """

    def __init__(self, array: MemristorConstraintArray):
        """
        Initialize modulator.

        Parameters
        ----------
        array : MemristorConstraintArray
            Constraint array to modulate
        """
        self.array = array
        self.mappings: Dict[str, List[Tuple[str, Callable]]] = {}  # sensor_id → [(constraint, transform)]
        self.last_readings: Dict[str, SensorReading] = {}

    def add_mapping(
        self,
        sensor_id: str,
        constraint_name: str,
        transform: Callable[[float], float],
    ):
        """
        Add sensor-to-constraint mapping.

        Parameters
        ----------
        sensor_id : str
            Sensor identifier
        constraint_name : str
            Constraint to modulate
        transform : callable
            Function to transform sensor value to voltage
        """
        if sensor_id not in self.mappings:
            self.mappings[sensor_id] = []
        self.mappings[sensor_id].append((constraint_name, transform))

    def update(self, reading: SensorReading):
        """
        Update constraints based on sensor reading.

        Parameters
        ----------
        reading : SensorReading
            Sensor reading to process
        """
        self.last_readings[reading.sensor_id] = reading

        if reading.sensor_id not in self.mappings:
            return

        for constraint_name, transform in self.mappings[reading.sensor_id]:
            voltage = transform(reading.value)
            self.array.apply_feedback(constraint_name, voltage, duration=0.01)

    def update_batch(self, readings: List[SensorReading]):
        """Update with multiple sensor readings."""
        for reading in readings:
            self.update(reading)


# =============================================================================
# Convenience Functions
# =============================================================================


def create_default_curriculum_manager() -> CurriculumManager:
    """Create curriculum manager with default YRSN constraints."""
    manager = CurriculumManager()

    # Actual tier - fatal violations
    manager.add_constraint(
        "no_hallucination",
        ConstraintTier.ACTUAL,
        threshold=0.95,
        description="Must not hallucinate facts",
    )
    manager.add_constraint(
        "relevance_minimum",
        ConstraintTier.ACTUAL,
        threshold=0.3,
        description="Minimum relevance required",
    )

    # Learned tier - warnings
    manager.add_constraint(
        "noise_threshold",
        ConstraintTier.LEARNED,
        threshold=0.4,
        description="Noise should stay below threshold",
    )
    manager.add_constraint(
        "coherence",
        ConstraintTier.LEARNED,
        threshold=0.5,
        description="Content should be coherent",
    )

    # Emergent tier - advisories
    manager.add_constraint(
        "style_consistency",
        ConstraintTier.EMERGENT,
        threshold=0.3,
        description="Style should be consistent",
    )
    manager.add_constraint(
        "conciseness",
        ConstraintTier.EMERGENT,
        threshold=0.2,
        description="Prefer concise responses",
    )

    return manager


def quick_memristor_analysis(
    R: float,
    S: float,
    N: float,
    manager: Optional[CurriculumManager] = None,
) -> Dict[str, Any]:
    """
    Quick analysis using memristor-based curriculum.

    Parameters
    ----------
    R, S, N : float
        YRSN decomposition values
    manager : CurriculumManager, optional
        Existing manager (creates default if not provided)

    Returns
    -------
    dict
        Analysis results
    """
    if manager is None:
        manager = create_default_curriculum_manager()

    # Compute quality (simple relevance mode)
    quality = R

    # Compute satisfaction (inverse of risk)
    risk = S + 1.5 * N
    satisfaction = max(0.0, 1.0 - risk)

    # Step through curriculum
    result = manager.step(quality, satisfaction)

    # Add Pillar 2 recommendations
    result["pillar2_recommendations"] = manager.get_pillar2_recommendations()

    return result


# =============================================================================
# Human-in-the-Loop CLI (NeurIPS 2024 AI Scientist-v2 inspired)
# =============================================================================


class ConstraintTuningCLI:
    """
    Command-line interface for human-in-the-loop constraint tuning.

    WHY THIS EXISTS (AI Scientist-v2 inspired):
    The AI Scientist-v2 paper shows that agentic systems benefit from human
    oversight at key decision points. For YRSN, constraint weights are those
    key points - they determine how strictly rules are enforced.

    This CLI enables:
    1. EXPERT OVERRIDE: Domain experts can adjust weights based on judgment
    2. DEBUGGING: See exactly which constraints are firing and why
    3. EXPERIMENTATION: Try different weight profiles, save/load them
    4. AUDIT TRAIL: All adjustments logged with timestamps and feedback

    Usage:
        cli = ConstraintTuningCLI(constraint_array)
        cli.run()  # Start interactive loop

    Commands:
        list              - Show all constraints with current weights
        set <name> <val>  - Set constraint weight (0.0-1.0)
        undo              - Undo last change
        redo              - Redo undone change
        save <file>       - Save current profile to JSON
        load <file>       - Load profile from JSON
        feedback <text>   - Record feedback (logged with timestamp)
        quit              - Exit CLI

    Example:
        >>> array = MemristorConstraintArray()
        >>> array.add_constraint("budget_limit", ConstraintTier.LEARNED, 1000)
        >>> cli = ConstraintTuningCLI(array)
        >>> cli.cmd_list()  # Show all constraints
        >>> cli.cmd_set("budget_limit", 0.8)  # Adjust weight
        >>> cli.cmd_save("profile_v1.json")  # Save profile
    """

    def __init__(self, array: "MemristorConstraintArray"):
        """
        Initialize CLI with a constraint array to manage.

        Args:
            array: MemristorConstraintArray containing the constraints
                   Each constraint has a virtual memristor controlling its weight
        """
        self.array = array

        # UNDO/REDO STACKS: Enable mistake recovery
        self.undo_stack: List[Dict[str, Any]] = []
        self.redo_stack: List[Dict[str, Any]] = []

        # FEEDBACK LOG: Human notes attached to tuning sessions
        self.feedback_log: List[Tuple[float, str]] = []

    def _snapshot(self) -> Dict[str, Any]:
        """
        Capture current state of all constraints for undo/redo.

        Returns a dict mapping constraint_name → {weight, tier}
        """
        return {
            name: {
                "weight": c.memristor.get_weight(),
                "tier": c.tier,
            }
            for name, c in self.array.constraints.items()
        }

    def _restore(self, snapshot: Dict[str, Any]) -> None:
        """
        Restore constraint states from a snapshot.

        Uses voltage pulses to adjust memristor weights (respects physics model).
        """
        for name, state in snapshot.items():
            if name in self.array.constraints:
                c = self.array.constraints[name]
                current = c.memristor.get_weight()
                delta = state["weight"] - current

                if abs(delta) > 0.01:
                    voltage = delta * 2.0
                    c.memristor.apply_voltage(voltage, duration=0.1)

    def cmd_list(self) -> None:
        """
        List all constraints with their current weights and tiers.

        Output format:
          constraint_name                | weight=0.XXX | tier=YYYY
        """
        print("\nConstraints:")
        print("-" * 60)
        for name, c in self.array.constraints.items():
            weight = c.memristor.get_weight()
            tier = c.tier.value
            print(f"  {name:30s} | weight={weight:.3f} | tier={tier}")
        print()

    def cmd_set(self, name: str, value: float) -> None:
        """
        Set a specific constraint's weight.

        Saves current state to undo stack before making change.
        Weight is clamped to [0.0, 1.0] range.

        Args:
            name: Constraint name (must exist in array)
            value: New weight value (0.0-1.0)
        """
        if name not in self.array.constraints:
            print(f"Error: constraint '{name}' not found")
            return

        # UNDO SUPPORT: Save state before change
        self.undo_stack.append(self._snapshot())
        self.redo_stack.clear()

        # CLAMP to valid range
        value = max(0.0, min(1.0, value))

        # Apply change via memristor voltage pulse
        c = self.array.constraints[name]
        current = c.memristor.get_weight()
        delta = value - current
        voltage = delta * 2.0
        c.memristor.apply_voltage(voltage, duration=0.1)

        print(f"Set {name} = {value:.3f}")

    def cmd_undo(self) -> None:
        """
        Undo the last weight change.

        Pops from undo stack, pushes current state to redo stack.
        """
        if not self.undo_stack:
            print("Nothing to undo")
            return

        self.redo_stack.append(self._snapshot())
        snapshot = self.undo_stack.pop()
        self._restore(snapshot)
        print("Undone")

    def cmd_redo(self) -> None:
        """
        Redo a previously undone change.

        Pops from redo stack, pushes current state to undo stack.
        """
        if not self.redo_stack:
            print("Nothing to redo")
            return

        self.undo_stack.append(self._snapshot())
        snapshot = self.redo_stack.pop()
        self._restore(snapshot)
        print("Redone")

    def cmd_feedback(self, text: str) -> None:
        """
        Record feedback/notes from the human operator.

        Timestamped and logged for audit trail.
        """
        self.feedback_log.append((time.time(), text))
        print(f"Feedback recorded: {text[:50]}...")

    def cmd_save(self, filepath: str) -> None:
        """
        Save current constraint profile to JSON file.

        Includes all constraint weights, tiers, feedback log, and timestamp.
        """
        import json
        profile = {
            "constraints": self._snapshot(),
            "feedback": self.feedback_log,
            "timestamp": time.time(),
        }
        with open(filepath, 'w') as f:
            json.dump(profile, f, indent=2, default=str)
        print(f"Saved to {filepath}")

    def cmd_load(self, filepath: str) -> None:
        """
        Load constraint profile from JSON file.

        Saves current state to undo stack before loading.
        """
        import json
        with open(filepath, 'r') as f:
            profile = json.load(f)

        self.undo_stack.append(self._snapshot())
        self.redo_stack.clear()
        self._restore(profile["constraints"])
        print(f"Loaded from {filepath}")

    def run(self) -> None:
        """
        Run the interactive CLI loop.

        Reads commands from stdin, dispatches to handlers.
        Exits on 'quit', 'exit', EOF, or Ctrl+C.
        """
        print("YRSN Constraint Tuning CLI")
        print("Type 'help' for commands, 'quit' to exit")

        while True:
            try:
                line = input("yrsn> ").strip()
            except (EOFError, KeyboardInterrupt):
                break

            if not line:
                continue

            parts = line.split()
            cmd = parts[0].lower()
            args = parts[1:]

            # COMMAND DISPATCH
            if cmd == "quit" or cmd == "exit":
                break
            elif cmd == "list":
                self.cmd_list()
            elif cmd == "set" and len(args) >= 2:
                try:
                    self.cmd_set(args[0], float(args[1]))
                except ValueError:
                    print(f"Error: invalid value '{args[1]}'")
            elif cmd == "undo":
                self.cmd_undo()
            elif cmd == "redo":
                self.cmd_redo()
            elif cmd == "feedback" and args:
                self.cmd_feedback(" ".join(args))
            elif cmd == "save" and args:
                self.cmd_save(args[0])
            elif cmd == "load" and args:
                self.cmd_load(args[0])
            elif cmd == "help":
                print(self.__doc__)
            else:
                print(f"Unknown command: {cmd}")

        print("Goodbye")

    def get_feedback_log(self) -> List[Tuple[float, str]]:
        """Get all recorded feedback entries."""
        return self.feedback_log.copy()


# =============================================================================
# Realtime Scaling for Robotics and RL (NeurIPS 2025 Theme 3)
# =============================================================================


class AdaptiveInference:
    """
    Adaptive inference using BBP phase transitions to allocate compute.

    NeurIPS 2025 Theme 3: Realtime Scaling for Robotics and RL

    The Problem:
    - Latency constraints: Robotics requires real-time inference
    - Compute allocation: Can't afford full inference every timestep
    - State representation: What to remember vs forget

    YRSN Integration:
    Uses α (quality score = R/(R+S+N)) to decide between full and lite models:
    - High α + tight budget → lite model sufficient
    - Low α → need full model to extract signal

    Phase Transition Decision:
        α_critical = 0.4 (BBP threshold)

        Model_selection = {
            full_model  if α < α_critical OR budget > τ_compute
            lite_model  otherwise
        }

    Usage:
        adaptive = AdaptiveInference(full_model, lite_model)

        # During inference
        result, model_used = adaptive.infer(
            state=observation,
            r_score=0.6, s_score=0.3, n_score=0.1,
            latency_budget_ms=10.0
        )

        # Check statistics
        stats = adaptive.get_statistics()
        print(f"Lite ratio: {stats['lite_ratio']:.2%}")
    """

    def __init__(
        self,
        full_model: Callable,
        lite_model: Callable,
        alpha_critical: float = 0.4,      # BBP threshold
        tight_budget_ms: float = 10.0,    # "Tight" latency budget
        moderate_budget_ms: float = 50.0  # "Moderate" budget threshold
    ):
        """
        Initialize adaptive inference.

        Parameters
        ----------
        full_model : callable
            Full model inference function (expensive, accurate)
        lite_model : callable
            Lite/distilled model inference function (cheap, fast)
        alpha_critical : float
            BBP phase transition threshold. Below this, need full model.
        tight_budget_ms : float
            Latency below this is considered "tight"
        moderate_budget_ms : float
            Latency above this allows full model even at moderate quality
        """
        self.full_model = full_model
        self.lite_model = lite_model
        self.alpha_critical = alpha_critical
        self.tight_budget_ms = tight_budget_ms
        self.moderate_budget_ms = moderate_budget_ms

        # Statistics tracking
        self.full_model_calls = 0
        self.lite_model_calls = 0

    def infer(
        self,
        state: Any,
        r_score: float,
        s_score: float,
        n_score: float,
        latency_budget_ms: float
    ) -> Tuple[Any, str]:
        """
        Perform adaptive inference based on state quality and latency budget.

        Parameters
        ----------
        state : any
            Input state for inference
        r_score, s_score, n_score : float
            YRSN decomposition scores
        latency_budget_ms : float
            Available time budget in milliseconds

        Returns
        -------
        tuple of (model_output, model_used)
            model_used is "full" or "lite"
        """
        # Compute quality score α
        total = r_score + s_score + n_score
        if total > 0:
            alpha = r_score / total
        else:
            alpha = 0.0

        # Decision logic based on phase transitions
        if alpha > self.alpha_critical and latency_budget_ms < self.tight_budget_ms:
            # High quality state, tight budget → lite model sufficient
            self.lite_model_calls += 1
            return self.lite_model(state), "lite"

        elif alpha < self.alpha_critical:
            # Low quality state → need full model to extract signal
            self.full_model_calls += 1
            return self.full_model(state), "full"

        else:
            # Moderate → adaptive based on budget
            if latency_budget_ms > self.moderate_budget_ms:
                self.full_model_calls += 1
                return self.full_model(state), "full"
            else:
                self.lite_model_calls += 1
                return self.lite_model(state), "lite"

    def get_statistics(self) -> Dict[str, Any]:
        """Return inference statistics."""
        total = self.full_model_calls + self.lite_model_calls
        return {
            "full_model_calls": self.full_model_calls,
            "lite_model_calls": self.lite_model_calls,
            "total_calls": total,
            "lite_ratio": self.lite_model_calls / total if total > 0 else 0.0,
            "full_ratio": self.full_model_calls / total if total > 0 else 0.0,
        }

    def reset_statistics(self):
        """Reset call statistics."""
        self.full_model_calls = 0
        self.lite_model_calls = 0


def compute_exploration_rate(
    state_quality_alpha: float,
    tau_scale: float = 1.0,
    omega: float = 1.0,
    quality_prior: float = 0.5,
) -> float:
    """
    Compute exploration rate from quality using τ = 1/α_ω temperature duality.

    NeurIPS 2025: τ = 1/α_ω for Exploration vs Exploitation

    High temperature (low quality) → explore
    Low temperature (high quality) → exploit

    P(explore) = 1 - exp(-τ/τ_scale) where τ = 1/α_ω

    Parameters
    ----------
    state_quality_alpha : float
        Raw quality metric α ∈ (0, 1]
    tau_scale : float
        Scale factor for temperature
    omega : float
        Reliability coefficient (1.0 = in-distribution)
    quality_prior : float
        Prior for α_ω blending when OOD

    Returns
    -------
    float
        Exploration probability [0, 1]
    """
    # Avoid division by zero
    alpha = max(0.01, state_quality_alpha)
    # Use α_ω (reliability-adjusted), NOT raw alpha
    alpha_omega = omega * alpha + (1 - omega) * quality_prior
    tau = 1.0 / max(alpha_omega, 0.01)

    # Map to exploration probability
    exploration_prob = 1.0 - math.exp(-tau / tau_scale)

    return exploration_prob


class MemristorCreditAssignment:
    """
    Credit assignment using memristor resistance-plasticity-decay dynamics.

    NeurIPS 2025 Theme 3: Realtime Scaling for Robotics and RL

    The Problem:
    - Credit assignment: Long temporal horizons blur reward signals
    - Which state-action pairs contributed to success/failure?

    YRSN Integration:
    Provides biologically plausible temporal credit assignment:
    - Plasticity decreases with temporal distance (eligibility traces)
    - Resistance based on confidence/certainty (stable states resist change)
    - Decay prevents stale credit from dominating

    Memristor Dynamics:
        credit_delta = plasticity × (1 - resistance) × final_reward

    where:
        plasticity = exp(-time_since / timescale)
        resistance = confidence(state, action)

    Usage:
        credit = MemristorCreditAssignment()

        # After episode completes
        trajectory = [(s0, a0), (s1, a1), (s2, a2), ...]
        updates = credit.assign_credit(trajectory, final_reward=1.0)

        # Query credit for a state-action pair
        c = credit.get_credit(state, action)
    """

    def __init__(
        self,
        decay_rate: float = 0.95,
        plasticity_timescale: float = 10.0,
        confidence_fn: Optional[Callable] = None
    ):
        """
        Initialize memristor credit assignment.

        Parameters
        ----------
        decay_rate : float
            Decay applied to existing credit each update (0-1)
        plasticity_timescale : float
            Time constant for plasticity decay (steps)
        confidence_fn : callable, optional
            Function (state, action) → confidence [0, 1]
            Higher confidence = higher resistance = less credit change
        """
        self.synaptic_weights: Dict[Any, float] = {}  # (state, action) → credit
        self.decay_rate = decay_rate
        self.plasticity_timescale = plasticity_timescale
        self.confidence_fn = confidence_fn or (lambda s, a: 0.5)

    def assign_credit(
        self,
        trajectory: List[Tuple[Any, Any]],  # List of (state, action) pairs
        final_reward: float
    ) -> Dict[Any, float]:
        """
        Assign credit backwards through trajectory using memristor dynamics.

        Parameters
        ----------
        trajectory : list of (state, action) tuples
            Sequence of state-action pairs from episode
        final_reward : float
            Terminal reward to distribute

        Returns
        -------
        dict
            Mapping of (state, action) to credit assigned this update
        """
        credit_updates = {}

        # Work backwards through trajectory
        for t in reversed(range(len(trajectory))):
            state, action = trajectory[t]

            # Compute eligibility trace (plasticity)
            time_since = len(trajectory) - t
            plasticity = self._compute_plasticity(time_since)

            # Compute resistance (how much state resists change)
            resistance = self._compute_resistance(state, action)

            # Credit update with memristor dynamics
            credit_delta = plasticity * (1 - resistance) * final_reward

            # Apply decay to existing credit
            key = self._make_key(state, action)
            if key in self.synaptic_weights:
                self.synaptic_weights[key] *= self.decay_rate
            else:
                self.synaptic_weights[key] = 0.0

            self.synaptic_weights[key] += credit_delta
            credit_updates[key] = credit_delta

        return credit_updates

    def _compute_plasticity(self, time_since: int) -> float:
        """Plasticity decreases exponentially with temporal distance."""
        return math.exp(-time_since / self.plasticity_timescale)

    def _compute_resistance(self, state: Any, action: Any) -> float:
        """
        Resistance based on confidence/certainty.
        High confidence → high resistance → less credit change
        """
        return self.confidence_fn(state, action)

    def _make_key(self, state: Any, action: Any) -> Any:
        """Create hashable key for state-action pair."""
        # Try to create a hashable representation
        try:
            if hasattr(state, 'tobytes'):
                state_key = hash(state.tobytes())
            else:
                state_key = hash(str(state))

            if hasattr(action, 'tobytes'):
                action_key = hash(action.tobytes())
            else:
                action_key = hash(str(action))

            return (state_key, action_key)
        except:
            return (id(state), id(action))

    def get_credit(self, state: Any, action: Any) -> float:
        """Get current credit for a state-action pair."""
        key = self._make_key(state, action)
        return self.synaptic_weights.get(key, 0.0)

    def get_top_credited(self, n: int = 10) -> List[Tuple[Any, float]]:
        """Get top n state-action pairs by credit."""
        sorted_items = sorted(
            self.synaptic_weights.items(),
            key=lambda x: x[1],
            reverse=True
        )
        return sorted_items[:n]

    def decay_all(self):
        """Apply decay to all stored credits."""
        for key in self.synaptic_weights:
            self.synaptic_weights[key] *= self.decay_rate

    def reset(self):
        """Reset all credit assignments."""
        self.synaptic_weights.clear()


class YRSNRewardShaper:
    """
    Reward shaping using YRSN three-tier constraint hierarchy.

    NeurIPS 2025 Theme 3: Realtime Scaling for Robotics and RL

    Maps constraint tiers to RL reward structure:

    | YRSN Tier | RL Equivalent      | Robotics Example              |
    |-----------|-------------------|-------------------------------|
    | Actual    | Hard constraints  | Joint limits, collision avoid |
    | Learned   | Shaped rewards    | Efficiency, smoothness        |
    | Emergent  | Exploration bonus | Novel states, curiosity       |

    Shaped reward:
        r_shaped = r_base + r_learned + r_emergent

    where:
        r_base: Original environment reward
        r_learned: Value estimate from learned constraints
        r_emergent: Novelty bonus for unseen states

    Hard constraints (Actual tier) return -inf for violations.

    Usage:
        shaper = YRSNRewardShaper(emergent_weight=0.1)

        # Define hard constraints
        constraints = [
            lambda s, a: s.position < max_position,
            lambda s, a: not collision_detected(s),
        ]

        # Shape reward
        shaped_r, components = shaper.shape_reward(
            state, action, base_reward,
            actual_constraints=constraints
        )
    """

    def __init__(
        self,
        emergent_weight: float = 0.1,
        novelty_scale: float = 1.0,
        constraint_checker: Optional[Callable] = None,
        value_estimator: Optional[Callable] = None
    ):
        """
        Initialize reward shaper.

        Parameters
        ----------
        emergent_weight : float
            Weight for exploration/novelty bonus
        novelty_scale : float
            Scale factor for novelty computation
        constraint_checker : callable, optional
            Function to check constraint satisfaction
        value_estimator : callable, optional
            Function to estimate state value (for Learned tier)
        """
        self.emergent_weight = emergent_weight
        self.novelty_scale = novelty_scale
        self.constraint_checker = constraint_checker
        self.value_estimator = value_estimator

        # Track seen states for novelty computation
        self.seen_states: Set[Any] = set()

    def shape_reward(
        self,
        state: Any,
        action: Any,
        base_reward: float,
        actual_constraints: Optional[List[Callable]] = None
    ) -> Tuple[float, Dict[str, float]]:
        """
        Shape reward using three-tier hierarchy.

        Parameters
        ----------
        state : any
            Current state
        action : any
            Action taken
        base_reward : float
            Original environment reward
        actual_constraints : list of callable, optional
            List of hard constraint functions: (state, action) → bool
            Return True if constraint satisfied, False if violated

        Returns
        -------
        tuple of (shaped_reward, component_breakdown)
            component_breakdown has keys: base, learned, emergent, violation
        """
        components = {"base": base_reward}

        # Actual tier: Binary constraint satisfaction
        if actual_constraints:
            for constraint in actual_constraints:
                if not constraint(state, action):
                    return float('-inf'), {"violation": float('-inf')}

        # Learned tier: Adaptive reward component
        learned_bonus = 0.0
        if self.value_estimator:
            learned_bonus = self.value_estimator(state)
        components["learned"] = learned_bonus

        # Emergent tier: Exploration bonus for novel states
        novelty = self._compute_novelty(state)
        emergent_bonus = self.emergent_weight * novelty
        components["emergent"] = emergent_bonus

        # Track state
        self.seen_states.add(self._hash_state(state))

        total = base_reward + learned_bonus + emergent_bonus
        return total, components

    def _compute_novelty(self, state: Any) -> float:
        """Compute novelty score for state (inverse of familiarity)."""
        state_hash = self._hash_state(state)
        if state_hash not in self.seen_states:
            return self.novelty_scale
        return 0.0

    def _hash_state(self, state: Any) -> int:
        """Hash state for tracking."""
        if hasattr(state, 'tobytes'):
            return hash(state.tobytes())
        return hash(str(state))

    def get_exploration_coverage(self) -> int:
        """Get number of unique states visited."""
        return len(self.seen_states)

    def reset_novelty_tracking(self):
        """Reset the novelty tracker (forget seen states)."""
        self.seen_states.clear()


# =============================================================================
# Exports
# =============================================================================


__all__ = [
    # Memristor models
    "MemristorState",
    "MemristorParams",
    "MemristorHistory",
    "VirtualMemristor",

    # Constraint array
    "MemristorConstraint",
    "MemristorConstraintArray",

    # Curriculum
    "CurriculumStage",
    "CurriculumProgress",
    "CurriculumManager",
    "DEFAULT_CURRICULUM_STAGES",

    # Bridge
    "Pillar2Pillar4Bridge",

    # Sensor modulation
    "SensorReading",
    "SensorConstraintModulator",

    # Human-in-the-loop
    "ConstraintTuningCLI",

    # Convenience
    "create_default_curriculum_manager",
    "quick_memristor_analysis",

    # NeurIPS 2025 Theme 3: Realtime Scaling for RL/Robotics
    "AdaptiveInference",
    "compute_exploration_rate",
    "MemristorCreditAssignment",
    "YRSNRewardShaper",
]
