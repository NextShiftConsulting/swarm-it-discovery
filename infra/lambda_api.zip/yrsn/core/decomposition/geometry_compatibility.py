"""
Geometry Compatibility Checker - Estimates κ(E, S) → ω

This module implements the representation-solver compatibility measure from
the theoretical framework:

    D(P, E, S) = Difficulty(Problem, Encoding, Solver)
    κ(E, S) = Compatibility between Encoding and Solver
    ω = normalized κ(E, S) ∈ [0, 1]

When encoder (adapter) and solver (rotor) operate in the same geometric space,
compatibility is high and we trust the α measurement. When geometries mismatch,
compatibility is low and we fall back to prior (P14: α_ω = α×ω + prior×(1-ω)).

GEOMETRY MATCHING CHECKS:
------------------------
1. Dimension match: adapter output dim = rotor input dim
2. Normalization match: both expect L2 normalized features
3. Distribution match: adapter output ∈ rotor training distribution
4. Scale match: feature magnitudes in expected range

USAGE:
------
>>> from yrsn.core.decomposition.geometry_compatibility import GeometryCompatibilityChecker
>>>
>>> checker = GeometryCompatibilityChecker(
...     rotor=trained_rotor,
...     training_stats=rotor_training_stats,  # centroid, covariance
... )
>>>
>>> # Check compatibility BEFORE running full inference
>>> features = adapter(input_data)
>>> omega = checker.estimate_omega(features)
>>>
>>> if omega < 0.5:
...     print("WARNING: Geometry mismatch - adapter/rotor incompatible")
...     print("RSN scores may be unreliable")

THEORY ALIGNMENT:
----------------
From "Intelligence as Representation-Solver Compatibility":
- ω measures whether encoding exposes structure solver can exploit
- High ω: adapter output matches rotor's expected geometry → trust α
- Low ω: geometry mismatch → fall back to prior

This is the EXPLICIT implementation of the theory's κ(E, S) measure.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple, List, Any
from pathlib import Path
import json


@dataclass
class TrainingDistributionStats:
    """
    Statistics from rotor training distribution.

    Used to measure whether new features are "in-distribution"
    for the rotor (geometry compatible).
    """
    centroid: np.ndarray           # Mean of training features [embed_dim]
    covariance: np.ndarray         # Covariance matrix [embed_dim, embed_dim]
    covariance_inv: np.ndarray     # Inverse covariance (precomputed)
    embed_dim: int                 # Expected embedding dimension
    norm_type: str = "l2"          # Expected normalization ('l2', 'none')
    norm_mean: float = 1.0         # Expected norm (1.0 for L2 normalized)
    norm_std: float = 0.01         # Acceptable norm variance
    n_samples: int = 0             # Number of training samples

    @classmethod
    def from_features(cls, features: np.ndarray, norm_type: str = "l2") -> 'TrainingDistributionStats':
        """
        Compute statistics from training features.

        Args:
            features: Training features [N, embed_dim]
            norm_type: Normalization type ('l2' or 'none')

        Returns:
            TrainingDistributionStats for compatibility checking
        """
        features = np.asarray(features)
        if features.ndim == 1:
            features = features.reshape(1, -1)

        centroid = features.mean(axis=0)
        covariance = np.cov(features.T)

        # Handle 1D case
        if covariance.ndim == 0:
            covariance = np.array([[covariance]])

        # Regularize for numerical stability
        covariance += np.eye(covariance.shape[0]) * 1e-6
        covariance_inv = np.linalg.inv(covariance)

        # Compute norm statistics
        norms = np.linalg.norm(features, axis=1)

        return cls(
            centroid=centroid,
            covariance=covariance,
            covariance_inv=covariance_inv,
            embed_dim=features.shape[1],
            norm_type=norm_type,
            norm_mean=float(norms.mean()),
            norm_std=float(norms.std()),
            n_samples=features.shape[0],
        )

    def save(self, path: Path):
        """Save stats to file."""
        path = Path(path)
        np.savez(
            path,
            centroid=self.centroid,
            covariance=self.covariance,
            covariance_inv=self.covariance_inv,
            embed_dim=self.embed_dim,
            norm_type=self.norm_type,
            norm_mean=self.norm_mean,
            norm_std=self.norm_std,
            n_samples=self.n_samples,
        )

    @classmethod
    def load(cls, path: Path) -> 'TrainingDistributionStats':
        """Load stats from file."""
        data = np.load(path)
        return cls(
            centroid=data['centroid'],
            covariance=data['covariance'],
            covariance_inv=data['covariance_inv'],
            embed_dim=int(data['embed_dim']),
            norm_type=str(data['norm_type']),
            norm_mean=float(data['norm_mean']),
            norm_std=float(data['norm_std']),
            n_samples=int(data['n_samples']),
        )


@dataclass
class CompatibilityReport:
    """
    Detailed report of geometry compatibility checks.

    This provides transparency into WHY omega is high or low.
    """
    omega: float                   # Final compatibility score [0, 1]

    # Individual checks
    dim_match: bool                # Dimensions compatible?
    norm_match: bool               # Normalization compatible?
    distribution_match: float      # Distribution compatibility [0, 1]
    scale_match: float             # Scale compatibility [0, 1]

    # Details
    expected_dim: int
    actual_dim: int
    expected_norm: float
    actual_norm: float
    mahalanobis_distance: float

    # Interpretation
    interpretation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            'omega': round(self.omega, 4),
            'checks': {
                'dim_match': self.dim_match,
                'norm_match': self.norm_match,
                'distribution_match': round(self.distribution_match, 4),
                'scale_match': round(self.scale_match, 4),
            },
            'details': {
                'expected_dim': self.expected_dim,
                'actual_dim': self.actual_dim,
                'expected_norm': round(self.expected_norm, 4),
                'actual_norm': round(self.actual_norm, 4),
                'mahalanobis_distance': round(self.mahalanobis_distance, 4),
            },
            'interpretation': self.interpretation,
        }


class GeometryCompatibilityChecker:
    """
    Checks geometry compatibility between adapter (encoder) and rotor (solver).

    Implements κ(E, S) from the representation-solver compatibility framework.
    Output is ω ∈ [0, 1] used in P14: α_ω = α×ω + prior×(1-ω).

    CHECKS PERFORMED:
    ----------------
    1. Dimension match: Hard requirement - must match exactly
    2. Normalization match: Features should be L2 normalized
    3. Distribution match: Mahalanobis distance to training centroid
    4. Scale match: Feature magnitudes in expected range

    OMEGA COMPUTATION:
    -----------------
    ω = dim_ok × norm_ok × distribution_score × scale_score

    If any hard requirement fails (dim, norm), ω = 0.
    Soft requirements (distribution, scale) degrade ω proportionally.
    """

    # Thresholds for soft checks
    MAHALANOBIS_THRESHOLD = 3.0   # Standard deviations
    NORM_TOLERANCE = 0.1          # Acceptable deviation from expected norm

    def __init__(
        self,
        training_stats: Optional[TrainingDistributionStats] = None,
        expected_dim: Optional[int] = None,
        expected_norm_type: str = "l2",
    ):
        """
        Initialize compatibility checker.

        Args:
            training_stats: Statistics from rotor training distribution
            expected_dim: Expected embedding dimension (from training_stats if not provided)
            expected_norm_type: Expected normalization type ('l2' or 'none')
        """
        self.training_stats = training_stats
        self.expected_dim = expected_dim or (training_stats.embed_dim if training_stats else None)
        self.expected_norm_type = expected_norm_type

    def check_dimensions(self, features: np.ndarray) -> Tuple[bool, int, int]:
        """
        Check if feature dimensions match expected.

        Returns:
            (match, expected_dim, actual_dim)
        """
        features = np.asarray(features)
        if features.ndim == 1:
            actual_dim = features.shape[0]
        else:
            actual_dim = features.shape[-1]

        if self.expected_dim is None:
            return True, -1, actual_dim  # Can't check without expected

        match = (actual_dim == self.expected_dim)
        return match, self.expected_dim, actual_dim

    def check_normalization(self, features: np.ndarray) -> Tuple[bool, float, float]:
        """
        Check if features are properly normalized.

        Returns:
            (match, expected_norm, actual_norm)
        """
        features = np.asarray(features)
        if features.ndim == 1:
            features = features.reshape(1, -1)

        norms = np.linalg.norm(features, axis=-1)
        actual_norm = float(norms.mean())

        if self.expected_norm_type == "l2":
            expected_norm = 1.0
            match = abs(actual_norm - expected_norm) < self.NORM_TOLERANCE
        else:
            # No normalization expected - always pass
            expected_norm = actual_norm
            match = True

        return match, expected_norm, actual_norm

    def compute_mahalanobis_distance(self, features: np.ndarray) -> float:
        """
        Compute Mahalanobis distance to training distribution.

        Lower distance = more compatible with training distribution.

        Returns:
            Mahalanobis distance (0 = at centroid, higher = more OOD)
        """
        if self.training_stats is None:
            return 0.0  # Can't compute without training stats

        features = np.asarray(features)
        if features.ndim == 1:
            features = features.reshape(1, -1)

        # Mean features for batch
        mean_features = features.mean(axis=0)

        # Mahalanobis distance
        diff = mean_features - self.training_stats.centroid
        dist = np.sqrt(diff @ self.training_stats.covariance_inv @ diff)

        return float(dist)

    def compute_distribution_score(self, mahalanobis_dist: float) -> float:
        """
        Convert Mahalanobis distance to compatibility score [0, 1].

        Uses sigmoid mapping: score = 1 / (1 + exp(dist - threshold))
        """
        # Sigmoid centered at threshold
        score = 1.0 / (1.0 + np.exp(mahalanobis_dist - self.MAHALANOBIS_THRESHOLD))
        return float(score)

    def compute_scale_score(self, actual_norm: float) -> float:
        """
        Compute scale compatibility score [0, 1].

        Perfect if norm matches expected, degrades with deviation.
        """
        if self.training_stats is None:
            return 1.0  # Can't check without training stats

        expected_norm = self.training_stats.norm_mean
        norm_std = max(self.training_stats.norm_std, 0.01)

        # How many standard deviations from expected?
        z_score = abs(actual_norm - expected_norm) / norm_std

        # Sigmoid mapping
        score = 1.0 / (1.0 + np.exp(z_score - 2.0))
        return float(score)

    def estimate_omega(
        self,
        features: np.ndarray,
        return_report: bool = False,
    ) -> float:
        """
        Estimate ω (compatibility) for given features.

        This is the main entry point for geometry compatibility checking.

        Args:
            features: Adapter output features [N, embed_dim] or [embed_dim]
            return_report: If True, return (omega, CompatibilityReport)

        Returns:
            ω ∈ [0, 1] - compatibility score

        Example:
            >>> omega = checker.estimate_omega(adapter_output)
            >>> if omega < 0.5:
            ...     print("Geometry mismatch!")
        """
        features = np.asarray(features)

        # Check dimensions (hard requirement)
        dim_match, expected_dim, actual_dim = self.check_dimensions(features)

        # Check normalization (hard requirement for L2)
        norm_match, expected_norm, actual_norm = self.check_normalization(features)

        # Compute Mahalanobis distance (soft check)
        if dim_match and self.training_stats is not None:
            mahal_dist = self.compute_mahalanobis_distance(features)
            distribution_score = self.compute_distribution_score(mahal_dist)
        else:
            mahal_dist = float('inf') if not dim_match else 0.0
            distribution_score = 0.0 if not dim_match else 1.0

        # Compute scale score (soft check)
        scale_score = self.compute_scale_score(actual_norm)

        # Compute final omega
        if not dim_match:
            omega = 0.0
            interpretation = f"INCOMPATIBLE: Dimension mismatch ({actual_dim} vs {expected_dim})"
        elif not norm_match:
            omega = 0.1  # Small non-zero to allow graceful degradation
            interpretation = f"DEGRADED: Normalization mismatch (norm={actual_norm:.3f}, expected={expected_norm:.3f})"
        else:
            omega = distribution_score * scale_score
            if omega >= 0.8:
                interpretation = "COMPATIBLE: Features match rotor geometry"
            elif omega >= 0.5:
                interpretation = "MARGINAL: Features partially match rotor geometry"
            else:
                interpretation = "INCOMPATIBLE: Features outside rotor training distribution"

        if return_report:
            report = CompatibilityReport(
                omega=omega,
                dim_match=dim_match,
                norm_match=norm_match,
                distribution_match=distribution_score,
                scale_match=scale_score,
                expected_dim=expected_dim,
                actual_dim=actual_dim,
                expected_norm=expected_norm,
                actual_norm=actual_norm,
                mahalanobis_distance=mahal_dist,
                interpretation=interpretation,
            )
            return omega, report

        return omega

    def validate_adapter_rotor_pair(
        self,
        adapter_output: np.ndarray,
        min_omega: float = 0.5,
    ) -> Tuple[bool, CompatibilityReport]:
        """
        Validate that adapter and rotor are geometrically compatible.

        This is a convenience method for validation pipelines.

        Args:
            adapter_output: Sample output from adapter
            min_omega: Minimum acceptable compatibility

        Returns:
            (is_valid, report)
        """
        omega, report = self.estimate_omega(adapter_output, return_report=True)
        is_valid = omega >= min_omega
        return is_valid, report


def create_compatibility_checker_from_rotor(
    rotor,
    training_features: Optional[np.ndarray] = None,
    stats_path: Optional[Path] = None,
) -> GeometryCompatibilityChecker:
    """
    Create a compatibility checker from a trained rotor.

    Args:
        rotor: Trained HybridSimplexRotor instance
        training_features: Optional features used to train rotor
        stats_path: Optional path to saved training stats

    Returns:
        GeometryCompatibilityChecker configured for this rotor
    """
    # Get expected dimension from rotor
    expected_dim = getattr(rotor, 'embed_dim', None)

    # Load or compute training stats
    if stats_path and Path(stats_path).exists():
        training_stats = TrainingDistributionStats.load(stats_path)
    elif training_features is not None:
        training_stats = TrainingDistributionStats.from_features(training_features)
    else:
        training_stats = None

    return GeometryCompatibilityChecker(
        training_stats=training_stats,
        expected_dim=expected_dim,
        expected_norm_type="l2",
    )


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    'GeometryCompatibilityChecker',
    'TrainingDistributionStats',
    'CompatibilityReport',
    'create_compatibility_checker_from_rotor',
]
