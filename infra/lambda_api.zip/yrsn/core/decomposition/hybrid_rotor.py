"""
HybridSimplexRotor - Geometric RSN Projection with Explicit Rotation

This module provides an alternative projection architecture that:
1. Uses nonlinear encoder for complex manifold mapping
2. Applies explicit rotation (learned theta angle)
3. Maps to RSN simplex via fixed barycentric transformation

The hybrid architecture addresses the "nonlinearity gap" discovered in
EXP-ROTOR-001 Phase B, where pure geometric rotors underperformed on
real CIFAR-10 embeddings.

Key Results (Phase C):
- HYBRID_LARGE: +10% correlation, +79% separation vs MLP baseline
- Interpretable: theta angle provides geometric insight
- Simplex guaranteed: R+S+N=1 by construction

Reference: docs/DOE_ROTOR_PARAMETERIZATION.md
"""

import math
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class RotorVariant(str, Enum):
    """Available HybridSimplexRotor variants."""
    LARGE = "large"       # 107K params, best performance
    COMPACT = "compact"   # 37K params, good balance
    TINY = "tiny"         # 8.5K params, minimal
    PURE = "pure"         # 516 params, pure geometric (no nonlinear encoder)


@dataclass
class RotorConfig:
    """Configuration for HybridSimplexRotor."""
    embed_dim: int = 768
    variant: RotorVariant = RotorVariant.LARGE
    # Large variant
    large_hidden_dim: int = 256
    large_subspace_dim: int = 64
    # Compact variant
    compact_hidden_dim: int = 128
    compact_subspace_dim: int = 32
    # Tiny variant
    tiny_hidden_dim: int = 32
    tiny_subspace_dim: int = 8


class SimplexRotor(nn.Module):
    """
    Pure geometric rotor: Linear projection + single rotation angle.

    Minimal architecture (~516 params for 256D input):
    - Linear: embed_dim -> 2D
    - Rotation: Single theta angle
    - Barycentric map to RSN

    Best for:
    - Synthetic data validation
    - Theoretical exploration
    - Maximum parameter efficiency

    Note: Underperforms on real data due to lack of nonlinear capacity.
    """

    def __init__(self, embed_dim: int = 768):
        super().__init__()
        self.embed_dim = embed_dim
        self.to_2d = nn.Linear(embed_dim, 2)
        self.theta = nn.Parameter(torch.tensor(0.0))
        self.scale = nn.Parameter(torch.tensor(1.0))

    def forward(
        self,
        x: torch.Tensor,
        return_scores: bool = False,
        return_t4: bool = False,
        **kwargs,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass: Project to 2D, rotate, map to RSN simplex.

        Device-agnostic interface: accepts same arguments as MLP projection heads.

        Args:
            x: Input embeddings [batch_size, embed_dim]
            return_scores: If True, include 'scores' key with [B, 3] tensor (MLP-compatible)
            **kwargs: Additional arguments (ignored, for interface compatibility)

        Returns:
            Dict with R, S, N tensors, theta, scale, and per-sample geometric params
        """
        # Project to 2D simplex plane
        uv = self.to_2d(x)

        # Compute per-sample geometric parameters (before rotation)
        sample_theta = torch.atan2(uv[:, 1], uv[:, 0]) * 180 / math.pi  # degrees
        sample_radius = torch.sqrt(uv[:, 0]**2 + uv[:, 1]**2)

        # Apply rotation
        c, s = torch.cos(self.theta), torch.sin(self.theta)
        u_rot = (c * uv[:, 0] - s * uv[:, 1]) * self.scale
        v_rot = (s * uv[:, 0] + c * uv[:, 1]) * self.scale

        # Barycentric map to RSN simplex (vertices at 120 degree angles)
        # This guarantees R+S+N=1 after softmax
        rsn_logits = torch.stack([
            1.0 + u_rot,                          # R vertex
            1.0 - 0.5 * u_rot + 0.866 * v_rot,   # S vertex (sqrt(3)/2 ~ 0.866)
            1.0 - 0.5 * u_rot - 0.866 * v_rot,   # N vertex
        ], dim=-1)
        rsn = F.softmax(rsn_logits, dim=-1)

        result = {
            'R': rsn[:, 0],
            'S': rsn[:, 1],
            'N': rsn[:, 2],
            'theta': self.theta.item() * 180 / math.pi,  # learned rotation (scalar)
            'scale': self.scale.item(),  # learned scale (scalar)
            'sample_theta': sample_theta,  # per-sample angle [batch_size]
            'sample_radius': sample_radius,  # per-sample distance [batch_size]
        }

        if return_scores:
            result['scores'] = rsn  # [batch_size, 3] - MLP-compatible

        if return_t4:
            from .geometric_utils import compute_t4_coordinates
            R_np = rsn[:, 0].detach().cpu().numpy()
            S_np = rsn[:, 1].detach().cpu().numpy()
            N_np = rsn[:, 2].detach().cpu().numpy()
            t4_coords = compute_t4_coordinates(R_np, S_np, N_np)
            result['t4_coordinates'] = t4_coords

        return result

    @property
    def param_count(self) -> int:
        """Total parameter count."""
        return sum(p.numel() for p in self.parameters())

    def get_angle_degrees(self) -> float:
        """Get learned rotation angle in degrees."""
        return self.theta.item() * 180 / math.pi


class HybridSimplexRotor(nn.Module):
    """
    💼 LICENSED - Universal RSN Decomposition Module

    This is the "brain" that decomposes quality into R, S, N scores.
    Customers MUST license this from YRSN. Cannot be reimplemented.

    Simple explanation:
        - Takes feature numbers from any source (text, vision, audio)
        - Breaks them into 3 quality scores: R (relevance), S (spurious), N (noise)
        - Uses geometric rotation math (patented method)
        - Guarantees R + S + N = 1.0 always (simplex constraint)

    What you CAN do:
        ✅ Import and call this class: rotor.forward(features)
        ✅ Pass features from your model
        ✅ Get R/S/N scores back

    What you CANNOT do:
        ❌ Copy or reimplement this rotor
        ❌ Extract the rotation logic
        ❌ "Reverse engineer" this component

    ---

    Hybrid architecture: Nonlinear encoder + Explicit rotor + Barycentric map.

    This architecture addresses the "nonlinearity gap" discovered in Phase B:
    real-world embeddings require nonlinear capacity to map complex semantic
    errors onto the RSN simplex.

    Pipeline:
    1. Nonlinear Encoder: embed_dim -> hidden -> subspace_dim
    2. Project to 2D simplex plane
    3. Apply explicit rotation (learned theta)
    4. Barycentric map to R, S, N (guaranteed R+S+N=1)

    Outputs:
    - R, S, N: Standard RSN decomposition (simplex constraint satisfied)
    - theta: Learned rotation angle (degrees) - interpretable geometric parameter
    - scale: Learned scale parameter

    Performance (CIFAR-10, Phase C):
    - Correlation: 0.675 (+10% vs MLP baseline)
    - Separation: 0.787 (+79% vs MLP baseline)
    - Parameters: 107K (-46% vs MLP baseline)

    Args:
        embed_dim: Input embedding dimension (default 768)
        subspace_dim: Dimension of geometric subspace (default 64)
        hidden_dim: Hidden layer dimension (default 256)
    """

    def __init__(
        self,
        embed_dim: int = 768,
        subspace_dim: int = 64,
        hidden_dim: int = 256,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.subspace_dim = subspace_dim
        self.hidden_dim = hidden_dim

        # Nonlinear encoder: handles complex manifolds in real data
        self.encoder = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, subspace_dim),
        )

        # Project from subspace to 2D for rotation
        self.to_2d = nn.Linear(subspace_dim, 2)

        # Explicit rotor: single interpretable angle
        self.theta = nn.Parameter(torch.tensor(0.0))
        self.scale = nn.Parameter(torch.tensor(1.0))

    def forward(
        self,
        x: torch.Tensor,
        return_scores: bool = False,
        return_t4: bool = False,
        return_entropy: bool = False,
        lambda_entropy: float = 0.3,
        **kwargs,  # Accept additional kwargs for interface compatibility
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass through hybrid architecture.

        Device-agnostic interface: accepts same arguments as MLP projection heads.

        Args:
            x: Input embeddings [batch_size, embed_dim]
            return_scores: If True, include 'scores' key with [B, 3] tensor (MLP-compatible)
            return_t4: If True, compute T⁴ toroidal coordinates
            return_entropy: If True, compute entropy metrics and α_H (expS5_215)
            lambda_entropy: Weight for entropy terms in α_H calculation (default 0.3)
            **kwargs: Additional arguments (ignored, for interface compatibility)

        Returns:
            Dict containing:
            - R, S, N: RSN decomposition tensors [batch_size]
            - scores: (if return_scores=True) [batch_size, 3] stacked R/S/N (MLP-compatible)
            - theta: Learned rotation angle in degrees (scalar, model parameter)
            - scale: Learned scale parameter (scalar, model parameter)
            - sample_theta: Per-sample angle in degrees [batch_size] (geometric position)
            - sample_radius: Per-sample distance from origin [batch_size]
            - entropy: (if return_entropy=True) Dict with H_r, H_s, H_n, H_total
            - alpha_H: (if return_entropy=True) Entropy-enhanced quality metric
        """
        # 1. Nonlinear projection to geometric subspace
        z = self.encoder(x)

        # 2. Project to 2D plane (simplex is 2D in R^3)
        uv = self.to_2d(z)

        # 3. Compute per-sample geometric parameters (before rotation)
        # These are the "effective" geometric positions in the 2D plane
        sample_theta = torch.atan2(uv[:, 1], uv[:, 0]) * 180 / math.pi  # degrees
        sample_radius = torch.sqrt(uv[:, 0]**2 + uv[:, 1]**2)

        # 4. Apply explicit rotation (the learned geometric transform)
        c, s = torch.cos(self.theta), torch.sin(self.theta)
        u_rot = (c * uv[:, 0] - s * uv[:, 1]) * self.scale
        v_rot = (s * uv[:, 0] + c * uv[:, 1]) * self.scale

        # 5. Barycentric map to RSN simplex (R+S+N=1 guaranteed)
        # Vertices of equilateral triangle at 120 degree angles
        rsn_logits = torch.stack([
            1.0 + u_rot,                          # R vertex
            1.0 - 0.5 * u_rot + 0.866 * v_rot,   # S vertex
            1.0 - 0.5 * u_rot - 0.866 * v_rot,   # N vertex
        ], dim=-1)
        rsn = F.softmax(rsn_logits, dim=-1)

        result = {
            'R': rsn[:, 0],
            'S': rsn[:, 1],
            'N': rsn[:, 2],
            'theta': self.theta.item() * 180 / math.pi,  # learned rotation (scalar)
            'scale': self.scale.item(),  # learned scale (scalar)
            'sample_theta': sample_theta,  # per-sample angle [batch_size]
            'sample_radius': sample_radius,  # per-sample distance [batch_size]
        }

        # Provide MLP-compatible 'scores' output for uniform interface
        if return_scores:
            result['scores'] = rsn  # [batch_size, 3] - already normalized via softmax

        if return_t4:
            from .geometric_utils import compute_t4_coordinates
            R_np = rsn[:, 0].detach().cpu().numpy()
            S_np = rsn[:, 1].detach().cpu().numpy()
            N_np = rsn[:, 2].detach().cpu().numpy()
            t4_coords = compute_t4_coordinates(R_np, S_np, N_np)
            result['t4_coordinates'] = t4_coords

        if return_entropy:
            from .entropy_metrics import compute_alpha_entropy_batch
            alpha_H, entropy = compute_alpha_entropy_batch(
                rsn[:, 0], rsn[:, 1], rsn[:, 2],
                lambda_weight=lambda_entropy
            )
            result['entropy'] = entropy
            result['alpha_H'] = alpha_H

        return result

    @property
    def param_count(self) -> int:
        """Total parameter count."""
        return sum(p.numel() for p in self.parameters())

    def get_angle_degrees(self) -> float:
        """Get learned rotation angle in degrees."""
        return self.theta.item() * 180 / math.pi

    def get_geometric_params(self) -> Dict[str, float]:
        """Get all geometric parameters."""
        return {
            'theta_degrees': self.get_angle_degrees(),
            'theta_radians': self.theta.item(),
            'scale': self.scale.item(),
        }


class HybridSimplexRotorCompact(nn.Module):
    """
    Compact hybrid variant: 37K params with good performance.

    Good balance between efficiency and accuracy:
    - Parameters: ~37K (vs 107K for large, 300K for MLP)
    - Correlation: ~88% of MLP baseline
    - Recommended for hardware-constrained deployments
    """

    def __init__(
        self,
        embed_dim: int = 768,
        subspace_dim: int = 32,
        hidden_dim: int = 128,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.subspace_dim = subspace_dim
        self.hidden_dim = hidden_dim

        self.encoder = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, subspace_dim),
        )
        self.to_2d = nn.Linear(subspace_dim, 2)
        self.theta = nn.Parameter(torch.tensor(0.0))
        self.scale = nn.Parameter(torch.tensor(1.0))

    def forward(
        self,
        x: torch.Tensor,
        return_scores: bool = False,
        return_t4: bool = False,
        **kwargs,
    ) -> Dict[str, torch.Tensor]:
        """Device-agnostic interface: accepts same arguments as MLP projection heads."""
        z = self.encoder(x)
        uv = self.to_2d(z)

        # Compute per-sample geometric parameters (before rotation)
        sample_theta = torch.atan2(uv[:, 1], uv[:, 0]) * 180 / math.pi  # degrees
        sample_radius = torch.sqrt(uv[:, 0]**2 + uv[:, 1]**2)

        c, s = torch.cos(self.theta), torch.sin(self.theta)
        u_rot = (c * uv[:, 0] - s * uv[:, 1]) * self.scale
        v_rot = (s * uv[:, 0] + c * uv[:, 1]) * self.scale

        rsn_logits = torch.stack([
            1.0 + u_rot,
            1.0 - 0.5 * u_rot + 0.866 * v_rot,
            1.0 - 0.5 * u_rot - 0.866 * v_rot,
        ], dim=-1)
        rsn = F.softmax(rsn_logits, dim=-1)

        result = {
            'R': rsn[:, 0],
            'S': rsn[:, 1],
            'N': rsn[:, 2],
            'theta': self.theta.item() * 180 / math.pi,  # learned rotation (scalar)
            'scale': self.scale.item(),  # learned scale (scalar)
            'sample_theta': sample_theta,  # per-sample angle [batch_size]
            'sample_radius': sample_radius,  # per-sample distance [batch_size]
        }

        if return_scores:
            result['scores'] = rsn  # [batch_size, 3] - MLP-compatible

        if return_t4:
            from .geometric_utils import compute_t4_coordinates
            R_np = rsn[:, 0].detach().cpu().numpy()
            S_np = rsn[:, 1].detach().cpu().numpy()
            N_np = rsn[:, 2].detach().cpu().numpy()
            t4_coords = compute_t4_coordinates(R_np, S_np, N_np)
            result['t4_coordinates'] = t4_coords

        return result

    @property
    def param_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def get_angle_degrees(self) -> float:
        return self.theta.item() * 180 / math.pi


def create_rotor(
    embed_dim: int = 768,
    variant: Union[RotorVariant, str] = RotorVariant.LARGE,
    config: Optional[RotorConfig] = None,
) -> nn.Module:
    """
    Factory function to create rotor variant.

    Args:
        embed_dim: Input embedding dimension
        variant: Rotor variant (large, compact, tiny, pure)
        config: Optional custom configuration

    Returns:
        Rotor model instance

    Example:
        >>> rotor = create_rotor(embed_dim=768, variant="large")
        >>> out = rotor(torch.randn(10, 768))
        >>> print(f"R={out['R'].mean():.3f}, theta={out['theta']:.1f} deg")
    """
    if isinstance(variant, str):
        variant = RotorVariant(variant.lower())

    config = config or RotorConfig(embed_dim=embed_dim)

    if variant == RotorVariant.LARGE:
        return HybridSimplexRotor(
            embed_dim=embed_dim,
            subspace_dim=config.large_subspace_dim,
            hidden_dim=config.large_hidden_dim,
        )
    elif variant == RotorVariant.COMPACT:
        return HybridSimplexRotorCompact(
            embed_dim=embed_dim,
            subspace_dim=config.compact_subspace_dim,
            hidden_dim=config.compact_hidden_dim,
        )
    elif variant == RotorVariant.TINY:
        return HybridSimplexRotorCompact(
            embed_dim=embed_dim,
            subspace_dim=config.tiny_subspace_dim,
            hidden_dim=config.tiny_hidden_dim,
        )
    elif variant == RotorVariant.PURE:
        return SimplexRotor(embed_dim=embed_dim)
    else:
        raise ValueError(f"Unknown rotor variant: {variant}")


def is_rotor_checkpoint(checkpoint: Dict) -> bool:
    """
    Check if a checkpoint is from a rotor model.

    Args:
        checkpoint: Loaded checkpoint dictionary

    Returns:
        True if checkpoint contains rotor-specific keys
    """
    rotor_keys = {'theta', 'scale', 'encoder.0.weight', 'to_2d.weight'}
    checkpoint_keys = set(checkpoint.keys())

    # Check for model_state_dict wrapper
    if 'model_state_dict' in checkpoint:
        checkpoint_keys = set(checkpoint['model_state_dict'].keys())

    return len(rotor_keys & checkpoint_keys) >= 2


def load_rotor_from_checkpoint(
    checkpoint_path: str,
    embed_dim: int = 768,
    variant: Optional[RotorVariant] = None,
) -> nn.Module:
    """
    Load a rotor model from checkpoint.

    Args:
        checkpoint_path: Path to checkpoint file
        embed_dim: Input embedding dimension
        variant: Optional variant hint (auto-detected if None)

    Returns:
        Loaded rotor model
    """
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)

    # Handle wrapped checkpoints
    state_dict = checkpoint
    if 'model_state_dict' in checkpoint:
        state_dict = checkpoint['model_state_dict']

    # Auto-detect variant from state_dict
    if variant is None:
        if 'encoder.4.weight' in state_dict:
            variant = RotorVariant.LARGE
        elif 'encoder.2.weight' in state_dict:
            variant = RotorVariant.COMPACT
        elif 'encoder.0.weight' not in state_dict:
            variant = RotorVariant.PURE
        else:
            variant = RotorVariant.COMPACT

    model = create_rotor(embed_dim=embed_dim, variant=variant)
    model.load_state_dict(state_dict)

    return model
