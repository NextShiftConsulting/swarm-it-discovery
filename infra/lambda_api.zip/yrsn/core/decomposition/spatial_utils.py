"""
Spatial utilities for collapse detection - minimal implementation.
Phase 3: Spatial Pack support.
"""
import numpy as np
from typing import Optional, Tuple


def compute_occlusion_completeness(
    spatial_embedding: np.ndarray,
    expected_density: float = 1.0
) -> float:
    """
    Compute spatial data completeness (1.0 = complete, 0.0 = fully occluded).
    
    Minimal implementation: uses embedding density as proxy.
    
    Parameters
    ----------
    spatial_embedding : np.ndarray
        Spatial embedding vector
    expected_density : float
        Expected density (default 1.0)
    
    Returns
    -------
    float
        Completeness ratio [0, 1]
    """
    # Simplified: use non-zero ratio as completeness proxy
    actual_density = np.count_nonzero(spatial_embedding) / max(len(spatial_embedding), 1)
    completeness = actual_density / max(expected_density, 0.01)
    return min(1.0, max(0.0, completeness))


def compute_calibration_error(
    spatial_embedding: np.ndarray,
    reference_embedding: Optional[np.ndarray] = None
) -> float:
    """
    Compute spatial calibration error (misalignment).
    
    Minimal implementation: uses embedding distance as proxy.
    
    Parameters
    ----------
    spatial_embedding : np.ndarray
        Spatial embedding vector
    reference_embedding : np.ndarray, optional
        Reference embedding for comparison
    
    Returns
    -------
    float
        Calibration error [0, inf]
    """
    if reference_embedding is None:
        # Use zero vector as reference (no calibration)
        reference_embedding = np.zeros_like(spatial_embedding)
    
    # Compute distance as calibration error
    error = np.linalg.norm(spatial_embedding - reference_embedding)
    return float(error)


def compute_scale_ambiguity(
    spatial_embedding: np.ndarray
) -> float:
    """
    Compute spatial scale ambiguity (depth uncertainty).
    
    Minimal implementation: uses embedding variance as proxy.
    
    Parameters
    ----------
    spatial_embedding : np.ndarray
        Spatial embedding vector
    
    Returns
    -------
    float
        Scale ambiguity [0, inf]
    """
    # Simplified: use variance as scale ambiguity proxy
    variance = np.var(spatial_embedding)
    return float(variance)


def compute_multiview_inconsistency(
    view_embeddings: list
) -> float:
    """
    Compute multi-view inconsistency (multiple cameras don't agree).
    
    Minimal implementation: uses variance across views as proxy.
    
    Parameters
    ----------
    view_embeddings : list of np.ndarray
        Embeddings from multiple views
    
    Returns
    -------
    float
        Inconsistency score [0, inf]
    """
    if len(view_embeddings) < 2:
        return 0.0
    
    # Compute variance across views
    stacked = np.stack(view_embeddings)
    variance = np.var(stacked, axis=0).mean()
    return float(variance)


def compute_depth_estimation_error(
    spatial_embedding: np.ndarray,
    ground_truth_depth: Optional[np.ndarray] = None
) -> float:
    """
    Compute depth estimation error.

    Minimal implementation: uses embedding magnitude as proxy.

    Parameters
    ----------
    spatial_embedding : np.ndarray
        Spatial embedding vector
    ground_truth_depth : np.ndarray, optional
        Ground truth depth for comparison

    Returns
    -------
    float
        Depth estimation error [0, inf]
    """
    if ground_truth_depth is None:
        # Use embedding norm as proxy
        return float(np.linalg.norm(spatial_embedding))

    # Compute error if ground truth available
    error = np.linalg.norm(spatial_embedding - ground_truth_depth)
    return float(error)


def compute_point_cloud_registration_error(
    source_points: np.ndarray,
    target_points: Optional[np.ndarray] = None
) -> float:
    """
    Compute point cloud registration error.

    Minimal implementation: uses point cloud alignment error as proxy.

    Parameters
    ----------
    source_points : np.ndarray
        Source point cloud (N x 3 or embedding)
    target_points : np.ndarray, optional
        Target point cloud for registration

    Returns
    -------
    float
        Registration error [0, 1] (0 = perfect, 1 = failed)
    """
    if target_points is None:
        # Use variance as proxy for registration quality
        # High variance → poor registration
        variance = np.var(source_points)
        return min(1.0, float(variance))

    # Compute alignment error if target available
    if source_points.shape != target_points.shape:
        return 1.0  # Shape mismatch = registration failure

    # Mean squared error as registration metric
    mse = np.mean((source_points - target_points) ** 2)
    # Normalize to [0, 1] range
    error = min(1.0, float(mse))
    return error
