"""
Compositional Kappa (κ) Computation

Implements the compositional κ formula for multi-primitive puzzles:
    κ_composite = min(κ_primitives) × (1 - penalty × (n-1))

Theory:
    - Bottleneck: Weakest primitive limits overall success (serial dependency)
    - Penalty: Combining n things is harder than any single thing

Evidence from YRSN codebase:
    - protocols.py:346-367 uses min() for quality merging
    - base_learner.py:410-492 uses min() for omega computation
    - abl10_killer_g_measurement_PROOF.md:88 states κ(E,S) = min(κ_E, κ_S)

Reference: docs/papers/gap_analysis/gap01_composition_function.md
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import numpy as np


@dataclass
class CompositionResult:
    """Result of compositional κ computation."""
    kappa_composite: float
    kappa_bottleneck: float
    confidence: float
    n_primitives: int
    bottleneck_primitive: Optional[str]
    composition_penalty_applied: float


def compute_compositional_kappa(
    primitive_kappas: Dict[str, float],
    composition_penalty: float = 0.05,
) -> Tuple[float, float]:
    """
    Compute compositional κ using theoretically-grounded bottleneck model.

    Args:
        primitive_kappas: Dict mapping primitive type to κ value
                         e.g., {'KILLER': 0.85, 'KNIGHT': 0.72, 'WHISPER': 0.90}
        composition_penalty: Per-primitive penalty for composition complexity
                            Default 0.05 = 5% penalty per additional primitive

    Returns:
        Tuple of (kappa_composite, confidence)

    Theory:
        κ_composite = κ_bottleneck × (1 - penalty × (n - 1))

        This captures:
        1. Serial dependency: weakest primitive limits overall success
        2. Composition cost: combining n things is harder than any single thing

    Example:
        >>> kappas = {'KILLER': 0.9, 'KNIGHT': 0.8, 'WHISPER': 0.85}
        >>> kappa, conf = compute_compositional_kappa(kappas)
        >>> print(f"κ_composite = {kappa:.3f}")  # 0.720 = 0.8 × 0.9
    """
    if not primitive_kappas:
        return (0.0, 0.0)

    kappas = list(primitive_kappas.values())
    n = len(kappas)

    # Step 1: Compute bottleneck (weakest link)
    kappa_bottleneck = min(kappas)

    # Step 2: Apply composition penalty
    # Each additional primitive beyond the first adds penalty
    composition_factor = max(0.0, 1.0 - composition_penalty * (n - 1))
    kappa_composite = kappa_bottleneck * composition_factor

    # Step 3: Compute confidence
    # Confidence is higher when:
    # - All primitives have similar κ (low variance)
    # - Primitives are well above the composition threshold
    kappa_variance = np.var(kappas) if n > 1 else 0.0
    mean_kappa = np.mean(kappas)
    confidence = float(mean_kappa * (1 - kappa_variance))

    return (kappa_composite, confidence)


def compute_compositional_kappa_detailed(
    primitive_kappas: Dict[str, float],
    composition_penalty: float = 0.05,
) -> CompositionResult:
    """
    Compute compositional κ with detailed breakdown.

    Args:
        primitive_kappas: Dict mapping primitive type to κ value
        composition_penalty: Per-primitive penalty (default 5%)

    Returns:
        CompositionResult with full breakdown
    """
    if not primitive_kappas:
        return CompositionResult(
            kappa_composite=0.0,
            kappa_bottleneck=0.0,
            confidence=0.0,
            n_primitives=0,
            bottleneck_primitive=None,
            composition_penalty_applied=0.0,
        )

    kappas = list(primitive_kappas.values())
    n = len(kappas)

    # Find bottleneck
    kappa_bottleneck = min(kappas)
    bottleneck_primitive = min(primitive_kappas, key=primitive_kappas.get)

    # Composition penalty
    penalty_applied = composition_penalty * (n - 1)
    composition_factor = max(0.0, 1.0 - penalty_applied)
    kappa_composite = kappa_bottleneck * composition_factor

    # Confidence
    kappa_variance = np.var(kappas) if n > 1 else 0.0
    mean_kappa = np.mean(kappas)
    confidence = float(mean_kappa * (1 - kappa_variance))

    return CompositionResult(
        kappa_composite=kappa_composite,
        kappa_bottleneck=kappa_bottleneck,
        confidence=confidence,
        n_primitives=n,
        bottleneck_primitive=bottleneck_primitive,
        composition_penalty_applied=penalty_applied,
    )


def compute_compositional_kappa_weighted(
    primitive_kappas: Dict[str, float],
    primitive_weights: Optional[Dict[str, float]] = None,
    composition_penalty: float = 0.05,
) -> float:
    """
    Weighted compositional κ (Professor's enhancement).

    Some primitives contribute more to difficulty than others.
    Weights can be derived from CTC analysis (D* inflation, break-in frequency).

    Args:
        primitive_kappas: Dict mapping primitive type to κ
        primitive_weights: Dict mapping primitive type to weight (from CTC)
                          Higher weight = more impact on composite κ
        composition_penalty: Per-primitive penalty

    Returns:
        Weighted compositional κ

    Formula:
        κ = min_i(w_i × κ_i) × (1 - c×(n-1))
    """
    if not primitive_kappas:
        return 0.0

    # Default weights from CTC analysis (Gap 01 enhancement)
    if primitive_weights is None:
        primitive_weights = CTC_PRIMITIVE_WEIGHTS

    # Weighted bottleneck
    weighted_kappas = []
    for ptype, kappa in primitive_kappas.items():
        weight = primitive_weights.get(ptype, 1.0)
        weighted_kappas.append(weight * kappa)

    kappa_bottleneck = min(weighted_kappas)

    # Composition penalty
    n = len(primitive_kappas)
    penalty_factor = 1 - composition_penalty * (n - 1)

    return max(0.0, kappa_bottleneck * penalty_factor)


# Default primitive weights derived from CTC analysis
# Higher weight = more impact on composite κ (harder primitives)
CTC_PRIMITIVE_WEIGHTS = {
    'KILLER': 1.2,       # High D* inflation, frequent break-in
    'THERMOMETER': 1.1,
    'KNIGHT': 1.15,
    'WHISPER': 1.1,
    'ARROW': 1.0,        # Baseline
    'KROPKI': 0.9,       # Lower contribution to difficulty
    'DIAGONAL': 0.85,
    'KING': 0.9,
    'RENBAN': 1.0,
    'PALINDROME': 0.95,
}


def predict_kappa_for_novel_puzzle(
    detected_primitives: List[str],
    primitive_kappa_lookup: Dict[str, float],
    composition_penalty: float = 0.05,
    unknown_primitive_kappa: float = 0.4,
) -> Tuple[float, float, List[str]]:
    """
    Predict κ for a novel puzzle BEFORE evaluation.

    Used for curriculum ordering: estimate κ to order by ZPD.

    Args:
        detected_primitives: List of primitive types detected in puzzle
        primitive_kappa_lookup: Historical κ values for each primitive type
        composition_penalty: Per-primitive penalty
        unknown_primitive_kappa: κ to assign to unknown primitives

    Returns:
        Tuple of (predicted_kappa, confidence, unknown_primitives)
    """
    primitive_kappas = {}
    unknown = []

    for prim in detected_primitives:
        if prim in primitive_kappa_lookup:
            primitive_kappas[prim] = primitive_kappa_lookup[prim]
        else:
            primitive_kappas[prim] = unknown_primitive_kappa
            unknown.append(prim)

    kappa, confidence = compute_compositional_kappa(
        primitive_kappas, composition_penalty
    )

    # Reduce confidence if there are unknown primitives
    if unknown:
        confidence *= (1 - 0.2 * len(unknown))

    return (kappa, max(0.0, confidence), unknown)


# Alias for backwards compatibility
bottleneck_kappa = compute_compositional_kappa
