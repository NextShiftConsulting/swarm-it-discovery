"""
YRSN Triplet Loss Functions for R/S/N Subspace Learning

This module implements loss functions for training discriminative R/S/N projections:
- YRSNTripletLoss: Triplet margin loss for subspace separation
- YRSNContrastiveLoss: InfoNCE-style contrastive learning
- YRSNOrthogonalityLoss: Enforce orthogonality between R, S, N subspaces

Mathematical Foundation:
- Triplet loss: L = max(0, d(anchor, positive) - d(anchor, negative) + margin)
- Contrastive loss: L = -log(exp(sim(a,p)/τ) / Σexp(sim(a,n)/τ))
- Orthogonality loss: L = ||W_R^T @ W_S||_F^2 + ||W_R^T @ W_N||_F^2 + ||W_S^T @ W_N||_F^2

Based on research synthesis:
- Triplet loss for metric learning (FaceNet, 2015)
- InfoNCE for representation learning (SimCLR, MoCo)
- Orthogonality constraints for subspace separation
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum


# =============================================================================
# Constants and Configuration
# =============================================================================

class RSNLabel(Enum):
    """Labels for R/S/N classification."""
    RELEVANT = 0
    SUPERFLUOUS = 1
    NOISE = 2


class DistanceFunction(Enum):
    """Distance functions for triplet loss."""
    EUCLIDEAN = "euclidean"
    COSINE = "cosine"
    SQUARED_EUCLIDEAN = "squared_euclidean"


class MiningStrategy(Enum):
    """Triplet mining strategies."""
    ALL = "all"  # Use all valid triplets
    HARD = "hard"  # Hardest positive and negative
    SEMI_HARD = "semi_hard"  # Negatives within margin
    EASY = "easy"  # Easiest negatives (for warm-up)


# =============================================================================
# Mining Curriculum Scheduler
# =============================================================================
#
# Theoretical Foundation (Schroff et al., FaceNet 2015):
#
# Different mining strategies have different learning dynamics:
#
# | Strategy   | Selection                  | Effect                    | When to Use     |
# |------------|----------------------------|---------------------------|-----------------|
# | EASY       | Negatives far from anchor  | Stable gradients, slow    | Early (warm-up) |
# | SEMI_HARD  | Negatives within margin    | Balanced learning         | Main training   |
# | HARD       | Closest negatives          | Fast but can be unstable  | Fine-tuning     |
#
# The curriculum progression:
#   EASY -> SEMI_HARD -> HARD
#
# This is ORTHOGONAL to constraint curriculum (which controls WHAT rules apply).
# Mining curriculum controls HOW triplets are formed within each batch.
#
# Overhead Cost:
#   - Memory: O(1) - just track current step
#   - Compute: None - mining strategy is already computed
#   - This scheduler just changes WHICH strategy is used
#
# =============================================================================

@dataclass
class MiningCurriculumConfig:
    """
    Configuration for mining curriculum scheduler.

    The scheduler transitions through mining strategies based on training step:
        Step 0 to easy_end:        EASY (stable warm-up)
        Step easy_end to hard_start: SEMI_HARD (main learning)
        Step hard_start+:          HARD (fine-tuning)

    Default progression for 100-step training:
        Steps 0-10:   EASY (10%)
        Steps 10-70:  SEMI_HARD (60%)
        Steps 70-100: HARD (30%)
    """
    # Transition points (as fraction of total steps, or absolute steps)
    easy_end_fraction: float = 0.1       # End EASY at 10% of training
    hard_start_fraction: float = 0.7     # Start HARD at 70% of training

    # Alternative: absolute step counts (if set, override fractions)
    easy_end_step: Optional[int] = None
    hard_start_step: Optional[int] = None

    # Total steps (used with fractions)
    total_steps: int = 100

    # Allow manual override
    fixed_strategy: Optional[MiningStrategy] = None


class MiningCurriculumScheduler:
    """
    Scheduler that progresses mining strategy through curriculum.

    ==========================================================================
    Why Mining Curriculum Matters
    ==========================================================================

    1. EASY mining (warm-up):
       - Selects negatives FAR from anchor
       - Gradient signal is strong and consistent
       - Prevents early collapse when embeddings are random
       - Analogous to: "Learn to distinguish cats from cars before cats from dogs"

    2. SEMI_HARD mining (main training):
       - Selects negatives WITHIN margin of anchor-positive distance
       - d(a,p) < d(a,n) < d(a,p) + margin
       - Balanced: challenging but achievable
       - Analogous to: "Learn fine distinctions"

    3. HARD mining (fine-tuning):
       - Selects CLOSEST negatives
       - Can cause instability if used too early (gradient explosion)
       - Best for polishing already-good embeddings
       - Analogous to: "Handle the hardest edge cases"

    ==========================================================================
    Usage
    ==========================================================================

    scheduler = MiningCurriculumScheduler(MiningCurriculumConfig(total_steps=1000))

    for step in range(1000):
        strategy = scheduler.get_strategy(step)
        loss = triplet_loss(embeddings, labels)  # Uses current strategy
        scheduler.step()

    ==========================================================================
    Training-Only Signal (Not in Signal Spec)
    ==========================================================================

    This is internal training diagnostics - logs to TensorBoard, NOT signal spec.
    Per-batch granularity, not per-example.
    """

    def __init__(self, config: Optional[MiningCurriculumConfig] = None):
        self.config = config or MiningCurriculumConfig()
        self.current_step = 0

        # Compute transition points
        if self.config.easy_end_step is not None:
            self._easy_end = self.config.easy_end_step
        else:
            self._easy_end = int(self.config.easy_end_fraction * self.config.total_steps)

        if self.config.hard_start_step is not None:
            self._hard_start = self.config.hard_start_step
        else:
            self._hard_start = int(self.config.hard_start_fraction * self.config.total_steps)

    def get_strategy(self, step: Optional[int] = None) -> MiningStrategy:
        """
        Get the mining strategy for current step.

        Args:
            step: Optional step override. If None, uses internal counter.

        Returns:
            MiningStrategy for this step.
        """
        # Allow fixed strategy override
        if self.config.fixed_strategy is not None:
            return self.config.fixed_strategy

        s = step if step is not None else self.current_step

        if s < self._easy_end:
            return MiningStrategy.EASY
        elif s < self._hard_start:
            return MiningStrategy.SEMI_HARD
        else:
            return MiningStrategy.HARD

    def step(self) -> None:
        """Advance to next step."""
        self.current_step += 1

    def get_diagnostics(self) -> dict:
        """
        Get training diagnostics (for TensorBoard, NOT signal spec).

        Returns:
            dict with mining_strategy, current_step, phase info
        """
        strategy = self.get_strategy()
        return {
            'mining_strategy': strategy.value,
            'current_step': self.current_step,
            'easy_end': self._easy_end,
            'hard_start': self._hard_start,
            'phase': 'easy' if self.current_step < self._easy_end else
                     'semi_hard' if self.current_step < self._hard_start else 'hard',
        }

    def reset(self) -> None:
        """Reset scheduler to step 0."""
        self.current_step = 0


# =============================================================================
# Loss Output Container
# =============================================================================

@dataclass
class RSNLossOutput:
    """Output from R/S/N loss computation."""
    total_loss: torch.Tensor
    component_losses: Dict[str, torch.Tensor]
    metrics: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'total': self.total_loss.item() if self.total_loss.numel() == 1 else self.total_loss.mean().item(),
            'components': {k: v.item() if v.numel() == 1 else v.mean().item()
                          for k, v in self.component_losses.items()},
            'metrics': self.metrics,
        }


# =============================================================================
# Triplet Loss
# =============================================================================

class YRSNTripletLoss(nn.Module):
    """
    Triplet loss for learning discriminative R/S/N subspaces.

    Objective:
    - Pull together embeddings of same RSN class
    - Push apart embeddings of different RSN classes

    L = max(0, d(anchor, positive) - d(anchor, negative) + margin)

    Args:
        margin: Minimum desired distance between positive and negative pairs
        distance_fn: Distance function to use (cosine or euclidean)
        mining_strategy: How to select triplets (all, hard, semi_hard)
        swap: If True, use distance-weighted sampling
    """

    def __init__(
        self,
        margin: float = 0.5,
        distance_fn: str = "cosine",
        mining_strategy: str = "semi_hard",
        swap: bool = False,
        reduction: str = "mean",
    ):
        super().__init__()
        self.margin = margin
        self.distance_fn = DistanceFunction(distance_fn)
        self.mining_strategy = MiningStrategy(mining_strategy)
        self.swap = swap
        self.reduction = reduction

    def _compute_distance(
        self,
        x: torch.Tensor,
        y: torch.Tensor
    ) -> torch.Tensor:
        """Compute pairwise distance between x and y."""
        if self.distance_fn == DistanceFunction.COSINE:
            # Cosine distance = 1 - cosine_similarity
            x_norm = F.normalize(x, p=2, dim=-1)
            y_norm = F.normalize(y, p=2, dim=-1)
            return 1 - torch.sum(x_norm * y_norm, dim=-1)

        elif self.distance_fn == DistanceFunction.EUCLIDEAN:
            return torch.sqrt(torch.sum((x - y) ** 2, dim=-1) + 1e-8)

        else:  # SQUARED_EUCLIDEAN
            return torch.sum((x - y) ** 2, dim=-1)

    def _compute_distance_matrix(
        self,
        embeddings: torch.Tensor
    ) -> torch.Tensor:
        """Compute pairwise distance matrix for all embeddings."""
        if self.distance_fn == DistanceFunction.COSINE:
            embeddings_norm = F.normalize(embeddings, p=2, dim=-1)
            similarity = torch.mm(embeddings_norm, embeddings_norm.t())
            return 1 - similarity

        elif self.distance_fn == DistanceFunction.EUCLIDEAN:
            # Efficient pairwise euclidean distance
            sq_norms = (embeddings ** 2).sum(dim=-1, keepdim=True)
            distances_sq = sq_norms + sq_norms.t() - 2 * torch.mm(embeddings, embeddings.t())
            distances_sq = torch.clamp(distances_sq, min=0)
            return torch.sqrt(distances_sq + 1e-8)

        else:  # SQUARED_EUCLIDEAN
            sq_norms = (embeddings ** 2).sum(dim=-1, keepdim=True)
            return sq_norms + sq_norms.t() - 2 * torch.mm(embeddings, embeddings.t())

    def _mine_triplets_all(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        distance_matrix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Mine all valid triplets."""
        device = embeddings.device
        batch_size = embeddings.shape[0]

        # Create masks for same/different class pairs
        labels = labels.unsqueeze(0)
        labels_t = labels.t()
        same_class = (labels == labels_t).float()
        diff_class = 1 - same_class

        # For each anchor, find all valid (positive, negative) pairs
        # Valid triplet: anchor and positive same class, anchor and negative different class
        anchor_indices = []
        positive_indices = []
        negative_indices = []

        for i in range(batch_size):
            positives = torch.where(same_class[i] == 1)[0]
            positives = positives[positives != i]  # Exclude self
            negatives = torch.where(diff_class[i] == 1)[0]

            if len(positives) > 0 and len(negatives) > 0:
                for p in positives:
                    for n in negatives:
                        anchor_indices.append(i)
                        positive_indices.append(p.item())
                        negative_indices.append(n.item())

        if len(anchor_indices) == 0:
            # No valid triplets found
            return None, None, None, torch.tensor(0, device=device)

        anchor_idx = torch.tensor(anchor_indices, device=device)
        positive_idx = torch.tensor(positive_indices, device=device)
        negative_idx = torch.tensor(negative_indices, device=device)

        return anchor_idx, positive_idx, negative_idx, torch.tensor(len(anchor_indices), device=device)

    def _mine_triplets_hard(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        distance_matrix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Mine hard triplets: hardest positive and hardest negative for each anchor."""
        device = embeddings.device
        batch_size = embeddings.shape[0]

        labels_col = labels.unsqueeze(1)
        labels_row = labels.unsqueeze(0)
        same_class = (labels_col == labels_row).float()
        diff_class = 1 - same_class

        # Mask out self-comparisons for positive mining
        self_mask = torch.eye(batch_size, device=device)
        same_class_no_self = same_class * (1 - self_mask)

        # Hardest positive: furthest same-class example
        # Set different-class distances to -inf so they're not selected
        pos_distances = distance_matrix.clone()
        pos_distances[same_class_no_self == 0] = -float('inf')
        hardest_positive_dist, hardest_positive_idx = pos_distances.max(dim=1)

        # Hardest negative: closest different-class example
        # Set same-class distances to +inf so they're not selected
        neg_distances = distance_matrix.clone()
        neg_distances[diff_class == 0] = float('inf')
        hardest_negative_dist, hardest_negative_idx = neg_distances.min(dim=1)

        # Filter valid triplets (must have at least one positive and one negative)
        valid_mask = (hardest_positive_dist > -float('inf')) & (hardest_negative_dist < float('inf'))
        valid_indices = torch.where(valid_mask)[0]

        if len(valid_indices) == 0:
            return None, None, None, torch.tensor(0, device=device)

        anchor_idx = valid_indices
        positive_idx = hardest_positive_idx[valid_indices]
        negative_idx = hardest_negative_idx[valid_indices]

        return anchor_idx, positive_idx, negative_idx, torch.tensor(len(valid_indices), device=device)

    def _mine_triplets_semi_hard(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        distance_matrix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Mine semi-hard triplets: negatives that are further than the positive
        but still within the margin.

        d(a, p) < d(a, n) < d(a, p) + margin
        """
        device = embeddings.device
        batch_size = embeddings.shape[0]

        labels_col = labels.unsqueeze(1)
        labels_row = labels.unsqueeze(0)
        same_class = (labels_col == labels_row).float()
        diff_class = 1 - same_class

        self_mask = torch.eye(batch_size, device=device)
        same_class_no_self = same_class * (1 - self_mask)

        anchor_indices = []
        positive_indices = []
        negative_indices = []

        for i in range(batch_size):
            # Get positive indices (same class, not self)
            pos_mask = same_class_no_self[i] == 1
            pos_indices = torch.where(pos_mask)[0]

            if len(pos_indices) == 0:
                continue

            # Get distances to positives
            pos_distances = distance_matrix[i, pos_indices]

            # For each positive, find semi-hard negatives
            for j, p_idx in enumerate(pos_indices):
                p_dist = pos_distances[j]

                # Get negative indices (different class)
                neg_mask = diff_class[i] == 1
                neg_indices_all = torch.where(neg_mask)[0]

                if len(neg_indices_all) == 0:
                    continue

                neg_distances = distance_matrix[i, neg_indices_all]

                # Semi-hard: d(a,p) < d(a,n) < d(a,p) + margin
                semi_hard_mask = (neg_distances > p_dist) & (neg_distances < p_dist + self.margin)
                semi_hard_indices = torch.where(semi_hard_mask)[0]

                if len(semi_hard_indices) > 0:
                    # Randomly select one semi-hard negative
                    rand_idx = torch.randint(len(semi_hard_indices), (1,)).item()
                    n_idx = neg_indices_all[semi_hard_indices[rand_idx]]

                    anchor_indices.append(i)
                    positive_indices.append(p_idx.item())
                    negative_indices.append(n_idx.item())

        if len(anchor_indices) == 0:
            # Fall back to hard mining if no semi-hard triplets found
            return self._mine_triplets_hard(embeddings, labels, distance_matrix)

        anchor_idx = torch.tensor(anchor_indices, device=device)
        positive_idx = torch.tensor(positive_indices, device=device)
        negative_idx = torch.tensor(negative_indices, device=device)

        return anchor_idx, positive_idx, negative_idx, torch.tensor(len(anchor_indices), device=device)

    def forward(
        self,
        embeddings: torch.Tensor,
        rsn_labels: torch.Tensor,
    ) -> RSNLossOutput:
        """
        Compute triplet loss for R/S/N subspace learning.

        Args:
            embeddings: [B, D] projected embeddings
            rsn_labels: [B] labels (0=R, 1=S, 2=N)

        Returns:
            RSNLossOutput with loss and metrics
        """
        device = embeddings.device
        batch_size = embeddings.shape[0]

        # Compute pairwise distances
        distance_matrix = self._compute_distance_matrix(embeddings)

        # Mine triplets based on strategy
        if self.mining_strategy == MiningStrategy.ALL:
            anchor_idx, pos_idx, neg_idx, num_triplets = self._mine_triplets_all(
                embeddings, rsn_labels, distance_matrix
            )
        elif self.mining_strategy == MiningStrategy.HARD:
            anchor_idx, pos_idx, neg_idx, num_triplets = self._mine_triplets_hard(
                embeddings, rsn_labels, distance_matrix
            )
        else:  # SEMI_HARD
            anchor_idx, pos_idx, neg_idx, num_triplets = self._mine_triplets_semi_hard(
                embeddings, rsn_labels, distance_matrix
            )

        # Handle case with no valid triplets
        if anchor_idx is None:
            return RSNLossOutput(
                total_loss=torch.tensor(0.0, device=device, requires_grad=True),
                component_losses={'triplet': torch.tensor(0.0, device=device)},
                metrics={
                    'num_triplets': 0,
                    'num_valid_triplets': 0,
                    'avg_pos_dist': 0.0,
                    'avg_neg_dist': 0.0,
                    'separation_ratio': 0.0,
                }
            )

        # Get triplet distances
        pos_dist = distance_matrix[anchor_idx, pos_idx]
        neg_dist = distance_matrix[anchor_idx, neg_idx]

        # Triplet loss with margin
        triplet_loss = F.relu(pos_dist - neg_dist + self.margin)

        # Count valid triplets (non-zero loss)
        num_valid = (triplet_loss > 0).sum().float()

        # Reduce
        if self.reduction == "mean":
            if num_valid > 0:
                loss = triplet_loss.sum() / num_valid
            else:
                loss = triplet_loss.mean()
        elif self.reduction == "sum":
            loss = triplet_loss.sum()
        else:
            loss = triplet_loss

        # Compute metrics
        with torch.no_grad():
            avg_pos_dist = pos_dist.mean().item()
            avg_neg_dist = neg_dist.mean().item()
            separation_ratio = avg_neg_dist / (avg_pos_dist + 1e-8)

        return RSNLossOutput(
            total_loss=loss,
            component_losses={'triplet': loss},
            metrics={
                'num_triplets': num_triplets.item(),
                'num_valid_triplets': num_valid.item(),
                'avg_pos_dist': avg_pos_dist,
                'avg_neg_dist': avg_neg_dist,
                'separation_ratio': separation_ratio,
            }
        )


# =============================================================================
# Contrastive Loss (InfoNCE)
# =============================================================================

class YRSNContrastiveLoss(nn.Module):
    """
    InfoNCE-style contrastive loss for R/S/N representation learning.

    More scalable than triplet loss for large batches. Uses temperature
    scaling for similarity scores.

    L = -log(exp(sim(anchor, positive)/τ) / Σ_i exp(sim(anchor, i)/τ))

    Args:
        temperature: Temperature scaling factor (lower = sharper distribution)
        normalize: Whether to L2-normalize embeddings before computing similarity
    """

    def __init__(
        self,
        temperature: float = 0.07,
        normalize: bool = True,
        reduction: str = "mean",
    ):
        super().__init__()
        self.temperature = temperature
        self.normalize = normalize
        self.reduction = reduction

    def forward(
        self,
        embeddings: torch.Tensor,
        rsn_labels: torch.Tensor,
    ) -> RSNLossOutput:
        """
        Compute InfoNCE contrastive loss.

        Args:
            embeddings: [B, D] projected embeddings
            rsn_labels: [B] labels (0=R, 1=S, 2=N)

        Returns:
            RSNLossOutput with loss and metrics
        """
        device = embeddings.device
        batch_size = embeddings.shape[0]

        if self.normalize:
            embeddings = F.normalize(embeddings, p=2, dim=-1)

        # Compute similarity matrix
        similarity = torch.mm(embeddings, embeddings.t()) / self.temperature

        # Create positive mask (same class pairs)
        labels_col = rsn_labels.unsqueeze(1)
        labels_row = rsn_labels.unsqueeze(0)
        positive_mask = (labels_col == labels_row).float()

        # Remove self-similarity from positives
        self_mask = torch.eye(batch_size, device=device)
        positive_mask = positive_mask * (1 - self_mask)

        # For numerical stability, subtract max from similarity
        similarity_max, _ = similarity.max(dim=1, keepdim=True)
        similarity = similarity - similarity_max.detach()

        # Compute log-sum-exp for denominator (exclude self)
        exp_similarity = torch.exp(similarity) * (1 - self_mask)
        log_sum_exp = torch.log(exp_similarity.sum(dim=1, keepdim=True) + 1e-8)

        # Compute log probability for positive pairs
        log_prob = similarity - log_sum_exp

        # Mean log probability for positive pairs
        num_positives = positive_mask.sum(dim=1)

        # Handle samples with no positives
        has_positives = num_positives > 0

        if not has_positives.any():
            return RSNLossOutput(
                total_loss=torch.tensor(0.0, device=device, requires_grad=True),
                component_losses={'contrastive': torch.tensor(0.0, device=device)},
                metrics={
                    'avg_positive_sim': 0.0,
                    'avg_negative_sim': 0.0,
                    'temperature': self.temperature,
                }
            )

        # Compute loss only for samples with positives
        positive_log_prob = (log_prob * positive_mask).sum(dim=1)
        mean_log_prob = positive_log_prob / (num_positives + 1e-8)

        # Loss is negative log probability
        loss_per_sample = -mean_log_prob
        loss_per_sample = loss_per_sample * has_positives.float()

        if self.reduction == "mean":
            loss = loss_per_sample.sum() / has_positives.float().sum()
        elif self.reduction == "sum":
            loss = loss_per_sample.sum()
        else:
            loss = loss_per_sample

        # Compute metrics
        with torch.no_grad():
            positive_sim = (similarity * positive_mask).sum() / (positive_mask.sum() + 1e-8)
            negative_mask = (1 - positive_mask) * (1 - self_mask)
            negative_sim = (similarity * negative_mask).sum() / (negative_mask.sum() + 1e-8)

        return RSNLossOutput(
            total_loss=loss,
            component_losses={'contrastive': loss},
            metrics={
                'avg_positive_sim': (positive_sim * self.temperature).item(),
                'avg_negative_sim': (negative_sim * self.temperature).item(),
                'temperature': self.temperature,
            }
        )


# =============================================================================
# Orthogonality Loss
# =============================================================================

class YRSNOrthogonalityLoss(nn.Module):
    """
    Enforce orthogonality between R, S, N projection subspaces.

    Loss = ||W_R^T @ W_S||_F^2 + ||W_R^T @ W_N||_F^2 + ||W_S^T @ W_N||_F^2

    This ensures the three subspaces are maximally separated,
    preventing R, S, N from collapsing into overlapping representations.

    Args:
        weight: Scaling factor for the loss
        include_self_orthogonality: If True, also penalize non-orthonormal bases
    """

    def __init__(
        self,
        weight: float = 1.0,
        include_self_orthogonality: bool = False,
    ):
        super().__init__()
        self.weight = weight
        self.include_self_orthogonality = include_self_orthogonality

    def forward(
        self,
        R_weight: torch.Tensor,
        S_weight: torch.Tensor,
        N_weight: torch.Tensor,
    ) -> RSNLossOutput:
        """
        Compute orthogonality loss between projection weights.

        Args:
            R_weight: [out_dim, in_dim] R projection weight matrix
            S_weight: [out_dim, in_dim] S projection weight matrix
            N_weight: [out_dim, in_dim] N projection weight matrix

        Returns:
            RSNLossOutput with orthogonality loss
        """
        device = R_weight.device

        # Compute cross-subspace overlap (should be zero for orthogonal)
        # W_R^T @ W_S computes overlap between R and S subspaces
        RS_overlap = torch.mm(R_weight.t(), S_weight)
        RN_overlap = torch.mm(R_weight.t(), N_weight)
        SN_overlap = torch.mm(S_weight.t(), N_weight)

        # Frobenius norm squared of overlaps
        RS_loss = torch.norm(RS_overlap, p='fro') ** 2
        RN_loss = torch.norm(RN_overlap, p='fro') ** 2
        SN_loss = torch.norm(SN_overlap, p='fro') ** 2

        cross_loss = RS_loss + RN_loss + SN_loss

        # Optional: penalize non-orthonormal basis within each subspace
        self_loss = torch.tensor(0.0, device=device)
        if self.include_self_orthogonality:
            # W^T @ W should be close to identity for orthonormal basis
            R_gram = torch.mm(R_weight.t(), R_weight)
            S_gram = torch.mm(S_weight.t(), S_weight)
            N_gram = torch.mm(N_weight.t(), N_weight)

            identity = torch.eye(R_gram.shape[0], device=device)

            R_self = torch.norm(R_gram - identity, p='fro') ** 2
            S_self = torch.norm(S_gram - identity, p='fro') ** 2
            N_self = torch.norm(N_gram - identity, p='fro') ** 2

            self_loss = (R_self + S_self + N_self) * 0.1  # Lower weight

        total_loss = self.weight * (cross_loss + self_loss)

        return RSNLossOutput(
            total_loss=total_loss,
            component_losses={
                'RS_overlap': RS_loss,
                'RN_overlap': RN_loss,
                'SN_overlap': SN_loss,
                'self_orthogonality': self_loss,
            },
            metrics={
                'RS_overlap_norm': torch.sqrt(RS_loss).item(),
                'RN_overlap_norm': torch.sqrt(RN_loss).item(),
                'SN_overlap_norm': torch.sqrt(SN_loss).item(),
                'total_overlap': torch.sqrt(cross_loss).item(),
            }
        )

    def forward_from_heads(
        self,
        projection_heads: 'YRSNProjectionHeads',
    ) -> RSNLossOutput:
        """
        Convenience method to compute loss directly from projection heads.

        Args:
            projection_heads: YRSNProjectionHeads module

        Returns:
            RSNLossOutput with orthogonality loss
        """
        if projection_heads.R_head is None:
            raise RuntimeError("Projection heads not initialized")

        # Handle both Sequential (MLP) and Linear heads
        if hasattr(projection_heads, 'get_projection_weights'):
            # Use the helper method that extracts first linear layer weights
            weights = projection_heads.get_projection_weights()
            return self.forward(
                weights['R'],
                weights['S'],
                weights['N'],
            )
        elif hasattr(projection_heads.R_head, 'weight'):
            # Direct Linear layer
            return self.forward(
                projection_heads.R_head.weight,
                projection_heads.S_head.weight,
                projection_heads.N_head.weight,
            )
        else:
            # MLP: find first Linear layer in each head
            def get_first_linear_weight(head):
                for module in head.modules():
                    if isinstance(module, nn.Linear):
                        return module.weight
                raise RuntimeError("No Linear layer found in projection head")

            return self.forward(
                get_first_linear_weight(projection_heads.R_head),
                get_first_linear_weight(projection_heads.S_head),
                get_first_linear_weight(projection_heads.N_head),
            )


# =============================================================================
# Combined YRSN Loss
# =============================================================================

class YRSNCombinedLoss(nn.Module):
    """
    Combined loss for R/S/N subspace learning.

    Combines:
    - Triplet loss (or contrastive loss) for class separation
    - Orthogonality loss for subspace independence
    - Optional classification loss for direct supervision

    Args:
        triplet_weight: Weight for triplet/contrastive loss
        orthogonality_weight: Weight for orthogonality loss
        classification_weight: Weight for classification loss
        use_contrastive: If True, use contrastive instead of triplet
        triplet_margin: Margin for triplet loss
        temperature: Temperature for contrastive loss
    """

    def __init__(
        self,
        triplet_weight: float = 1.0,
        orthogonality_weight: float = 0.1,
        classification_weight: float = 0.5,
        use_contrastive: bool = False,
        triplet_margin: float = 0.5,
        temperature: float = 0.07,
    ):
        super().__init__()
        self.triplet_weight = triplet_weight
        self.orthogonality_weight = orthogonality_weight
        self.classification_weight = classification_weight

        if use_contrastive:
            self.separation_loss = YRSNContrastiveLoss(temperature=temperature)
        else:
            self.separation_loss = YRSNTripletLoss(margin=triplet_margin)

        self.orthogonality_loss = YRSNOrthogonalityLoss()
        self.classification_loss = nn.CrossEntropyLoss()

    def forward(
        self,
        embeddings: torch.Tensor,
        rsn_labels: torch.Tensor,
        projection_heads: Optional['YRSNProjectionHeads'] = None,
        classification_logits: Optional[torch.Tensor] = None,
    ) -> RSNLossOutput:
        """
        Compute combined loss.

        Args:
            embeddings: [B, D] projected embeddings
            rsn_labels: [B] labels (0=R, 1=S, 2=N)
            projection_heads: Optional heads for orthogonality loss
            classification_logits: Optional [B, 3] logits for classification

        Returns:
            RSNLossOutput with combined loss and all component metrics
        """
        device = embeddings.device
        total_loss = torch.tensor(0.0, device=device)
        component_losses = {}
        metrics = {}

        # Separation loss (triplet or contrastive)
        sep_output = self.separation_loss(embeddings, rsn_labels)
        sep_loss = sep_output.total_loss * self.triplet_weight
        total_loss = total_loss + sep_loss
        component_losses['separation'] = sep_loss
        metrics.update({f'sep_{k}': v for k, v in sep_output.metrics.items()})

        # Orthogonality loss
        if projection_heads is not None and projection_heads.R_head is not None:
            ortho_output = self.orthogonality_loss.forward_from_heads(projection_heads)
            ortho_loss = ortho_output.total_loss * self.orthogonality_weight
            total_loss = total_loss + ortho_loss
            component_losses['orthogonality'] = ortho_loss
            metrics.update({f'ortho_{k}': v for k, v in ortho_output.metrics.items()})

        # Classification loss
        if classification_logits is not None:
            cls_loss = self.classification_loss(classification_logits, rsn_labels)
            cls_loss = cls_loss * self.classification_weight
            total_loss = total_loss + cls_loss
            component_losses['classification'] = cls_loss

            # Classification accuracy
            with torch.no_grad():
                preds = classification_logits.argmax(dim=-1)
                accuracy = (preds == rsn_labels).float().mean().item()
                metrics['classification_accuracy'] = accuracy

        return RSNLossOutput(
            total_loss=total_loss,
            component_losses=component_losses,
            metrics=metrics,
        )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'RSNLabel',
    'DistanceFunction',
    'MiningStrategy',
    'MiningCurriculumConfig',
    'MiningCurriculumScheduler',
    'RSNLossOutput',
    'YRSNTripletLoss',
    'YRSNContrastiveLoss',
    'YRSNOrthogonalityLoss',
    'YRSNCombinedLoss',
]
