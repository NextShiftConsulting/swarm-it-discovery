"""
Outcome-Based Weak Supervision for R/S/N Learning

This module provides weak supervision signals from downstream task outcomes
to improve R/S/N decomposition quality without explicit labels.

Key concepts:
- If context helped solve task correctly -> likely contains R (relevant)
- If context was used but didn't help -> likely S (superfluous)
- If context hurt performance -> likely N (noise)

Methods:
1. Gradient-based attribution (Integrated Gradients, Attention)
2. Reward signal collection from task outcomes
3. Pseudo-label generation for semi-supervised learning

Based on research synthesis:
- Integrated Gradients (Sundararajan et al., 2017)
- Attention-based attribution
- Reward-weighted learning
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Callable
from enum import Enum
from collections import deque
import numpy as np
import time


# =============================================================================
# Configuration
# =============================================================================

class AttributionMethod(Enum):
    """Methods for computing attribution scores."""
    ATTENTION = "attention"  # Use attention weights directly
    GRADIENT = "gradient"  # Gradient w.r.t. input
    INTEGRATED_GRADIENTS = "integrated_gradients"  # IG method
    GRADIENT_SHAP = "gradient_shap"  # SHAP approximation


@dataclass
class OutcomeRecord:
    """Record of a context-outcome pair for training."""
    context_id: str
    embedding: torch.Tensor
    query_embedding: Optional[torch.Tensor]
    rsn_prediction: Optional[Dict[str, float]]  # Predicted R/S/N scores
    task_success: bool
    confidence: float
    attribution_scores: Optional[torch.Tensor]  # Per-token attributions
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Attribution Methods
# =============================================================================

class AttributionComputer:
    """
    Compute attribution scores for context tokens.

    Attributions indicate how much each token contributed to the
    model's prediction, which we use to infer R/S/N labels.
    """

    def __init__(
        self,
        method: str = "attention",
        num_steps: int = 50,  # For integrated gradients
        baseline_type: str = "zeros",  # or "mean", "random"
    ):
        self.method = AttributionMethod(method)
        self.num_steps = num_steps
        self.baseline_type = baseline_type

    def compute_attention_attribution(
        self,
        attention_weights: torch.Tensor,
        layer_aggregation: str = "mean",
    ) -> torch.Tensor:
        """
        Compute attribution from attention weights.

        Args:
            attention_weights: [num_layers, num_heads, seq_len, seq_len]
            layer_aggregation: How to aggregate across layers ("mean", "last", "max")

        Returns:
            attribution: [seq_len] attribution scores per token
        """
        # Aggregate across heads
        # attention_weights: [L, H, S, S] -> [L, S, S]
        attn = attention_weights.mean(dim=1)

        # Aggregate across layers
        if layer_aggregation == "mean":
            attn = attn.mean(dim=0)
        elif layer_aggregation == "last":
            attn = attn[-1]
        elif layer_aggregation == "max":
            attn = attn.max(dim=0)[0]

        # Sum attention received by each token (column sum)
        # This measures how much each token is attended to
        attribution = attn.sum(dim=0)

        # Normalize
        attribution = attribution / (attribution.sum() + 1e-8)

        return attribution

    def compute_gradient_attribution(
        self,
        embeddings: torch.Tensor,
        model_output: torch.Tensor,
        target_class: Optional[int] = None,
    ) -> torch.Tensor:
        """
        Compute gradient-based attribution.

        Args:
            embeddings: [B, L, D] input embeddings (requires_grad=True)
            model_output: [B, num_classes] model logits
            target_class: Class to compute gradient for (default: predicted class)

        Returns:
            attribution: [B, L] attribution scores per token
        """
        if target_class is None:
            target_class = model_output.argmax(dim=-1)

        # Get output for target class
        if model_output.dim() == 2:
            # [B, num_classes] -> [B]
            B = model_output.shape[0]
            target_output = model_output[torch.arange(B), target_class]
        else:
            target_output = model_output

        # Compute gradients
        grads = torch.autograd.grad(
            outputs=target_output.sum(),
            inputs=embeddings,
            create_graph=False,
            retain_graph=False,
        )[0]

        # Attribution = embedding * gradient (element-wise)
        attribution = (embeddings * grads).sum(dim=-1)  # [B, L]

        # Take absolute value and normalize
        attribution = attribution.abs()
        attribution = attribution / (attribution.sum(dim=-1, keepdim=True) + 1e-8)

        return attribution

    def compute_integrated_gradients(
        self,
        embeddings: torch.Tensor,
        model: nn.Module,
        target_class: Optional[int] = None,
    ) -> torch.Tensor:
        """
        Compute Integrated Gradients attribution.

        IG provides more accurate attributions by integrating gradients
        from a baseline to the input.

        Args:
            embeddings: [B, L, D] input embeddings
            model: Model to compute attribution for
            target_class: Class to compute gradient for

        Returns:
            attribution: [B, L] attribution scores per token
        """
        # Create baseline
        if self.baseline_type == "zeros":
            baseline = torch.zeros_like(embeddings)
        elif self.baseline_type == "mean":
            baseline = embeddings.mean(dim=1, keepdim=True).expand_as(embeddings)
        else:  # random
            baseline = torch.randn_like(embeddings) * 0.1

        # Compute path integrals
        integrated_grads = torch.zeros_like(embeddings)

        for step in range(self.num_steps):
            alpha = step / self.num_steps
            interpolated = baseline + alpha * (embeddings - baseline)
            interpolated.requires_grad_(True)

            output = model(interpolated)

            if target_class is None:
                target_class = output.argmax(dim=-1)

            # Get output for target
            if output.dim() == 2:
                B = output.shape[0]
                target_output = output[torch.arange(B), target_class]
            else:
                target_output = output

            grads = torch.autograd.grad(
                outputs=target_output.sum(),
                inputs=interpolated,
                create_graph=False,
            )[0]

            integrated_grads += grads / self.num_steps

        # Attribution = (input - baseline) * integrated_gradients
        attribution = (embeddings - baseline) * integrated_grads
        attribution = attribution.sum(dim=-1)  # [B, L]

        # Normalize
        attribution = attribution.abs()
        attribution = attribution / (attribution.sum(dim=-1, keepdim=True) + 1e-8)

        return attribution


# =============================================================================
# Outcome-Based Supervision
# =============================================================================

class OutcomeBasedSupervision:
    """
    Generate weak R/S/N labels from downstream task performance.

    Intuition:
    - If context helped solve task -> likely contains R
    - If context was used but didn't help -> likely S
    - If context was noise that hurt performance -> N

    Uses gradient-based attribution to identify which context
    segments contributed to correct/incorrect outcomes.
    """

    def __init__(
        self,
        attribution_method: str = "attention",
        quality_threshold: float = 0.7,  # Above this = R
        noise_threshold: float = 0.3,  # Below this = N
        attribution_computer: Optional[AttributionComputer] = None,
    ):
        self.attribution_method = AttributionMethod(attribution_method)
        self.quality_threshold = quality_threshold
        self.noise_threshold = noise_threshold

        self.attribution_computer = attribution_computer or AttributionComputer(
            method=attribution_method
        )

    def compute_weak_labels(
        self,
        context_embeddings: torch.Tensor,
        task_prediction: torch.Tensor,
        task_target: torch.Tensor,
        attention_weights: Optional[torch.Tensor] = None,
        model: Optional[nn.Module] = None,
    ) -> torch.Tensor:
        """
        Compute weak R/S/N labels from task outcomes.

        Args:
            context_embeddings: [B, L, D] context token embeddings
            task_prediction: [B] or [B, C] model predictions
            task_target: [B] ground truth targets
            attention_weights: Optional attention weights for attribution
            model: Optional model for gradient-based attribution

        Returns:
            weak_labels: [B, L] with 0=R, 1=S, 2=N pseudo-labels
        """
        device = context_embeddings.device
        B, L, D = context_embeddings.shape

        # Compute prediction correctness
        if task_prediction.dim() == 2:
            # Classification: [B, C] -> [B]
            predicted_class = task_prediction.argmax(dim=-1)
            correct = (predicted_class == task_target).float()
        else:
            # Already class indices
            correct = (task_prediction == task_target).float()

        # Compute attribution scores
        if self.attribution_method == AttributionMethod.ATTENTION:
            if attention_weights is None:
                # Fallback to uniform
                attribution = torch.ones(B, L, device=device) / L
            else:
                attribution = self.attribution_computer.compute_attention_attribution(
                    attention_weights
                )
                if attribution.dim() == 1:
                    attribution = attribution.unsqueeze(0).expand(B, -1)

        elif self.attribution_method in [AttributionMethod.GRADIENT, AttributionMethod.INTEGRATED_GRADIENTS]:
            if model is None:
                raise ValueError("Model required for gradient-based attribution")

            context_embeddings.requires_grad_(True)
            output = model(context_embeddings)

            if self.attribution_method == AttributionMethod.GRADIENT:
                attribution = self.attribution_computer.compute_gradient_attribution(
                    context_embeddings, output
                )
            else:
                attribution = self.attribution_computer.compute_integrated_gradients(
                    context_embeddings, model
                )
        else:
            # Default uniform attribution
            attribution = torch.ones(B, L, device=device) / L

        # Convert attribution to R/S/N labels based on outcome
        weak_labels = self.attribution_to_rsn(attribution, correct)

        return weak_labels

    def attribution_to_rsn(
        self,
        attribution_scores: torch.Tensor,
        prediction_correct: torch.Tensor,
    ) -> torch.Tensor:
        """
        Convert attribution scores to R/S/N labels.

        Logic:
        - High attribution + correct -> R (relevant, helped)
        - Low attribution + correct -> S (superfluous, didn't matter)
        - High attribution + incorrect -> N (noise, misled model)
        - Low attribution + incorrect -> S (superfluous, didn't hurt)

        Args:
            attribution_scores: [B, L] importance scores (normalized)
            prediction_correct: [B] bool/float (1.0 = correct)

        Returns:
            rsn_labels: [B, L] with 0=R, 1=S, 2=N
        """
        device = attribution_scores.device
        B, L = attribution_scores.shape

        # Expand correctness to token level
        correct = prediction_correct.unsqueeze(1).expand(B, L)  # [B, L]

        # Initialize all as S (superfluous)
        labels = torch.ones(B, L, dtype=torch.long, device=device)  # 1 = S

        # High attribution tokens
        high_attr = attribution_scores > self.quality_threshold

        # Low attribution tokens
        low_attr = attribution_scores < self.noise_threshold

        # High attribution + correct -> R (0)
        labels[(high_attr) & (correct > 0.5)] = 0

        # High attribution + incorrect -> N (2)
        labels[(high_attr) & (correct <= 0.5)] = 2

        # Low attribution + incorrect -> S (1) [already set]
        # Low attribution + correct -> S (1) [already set]

        # Very low attribution -> N regardless of outcome
        very_low_attr = attribution_scores < self.noise_threshold / 2
        labels[very_low_attr] = 2

        return labels

    def compute_confidence_weights(
        self,
        attribution_scores: torch.Tensor,
        prediction_confidence: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute confidence weights for weak labels.

        Higher confidence = more trustworthy weak label.

        Args:
            attribution_scores: [B, L] attribution scores
            prediction_confidence: [B] model confidence in prediction

        Returns:
            weights: [B, L] confidence weights for training
        """
        B, L = attribution_scores.shape

        # Attribution confidence: how certain we are about the attribution
        # High or low attribution = more certain, middle = less certain
        attr_distance = torch.abs(attribution_scores - 0.5) * 2
        attr_confidence = attr_distance  # [B, L]

        # Model confidence
        model_conf = prediction_confidence.unsqueeze(1).expand(B, L)

        # Combined confidence
        weights = attr_confidence * model_conf

        # Normalize
        weights = weights / (weights.max() + 1e-8)

        return weights


# =============================================================================
# Reward Signal Collector
# =============================================================================

class RewardSignalCollector:
    """
    Collect reward signals from reasoning outcomes for R/S/N refinement.

    Maintains a buffer of context-outcome pairs that can be used for:
    1. Batch training of projection heads
    2. Online learning during inference
    3. Analysis of R/S/N prediction quality

    Integrates with downstream task outcomes to track:
    - Which context segments led to good reasoning
    - Which segments were ignored
    - Which segments caused errors
    """

    def __init__(
        self,
        buffer_size: int = 10000,
        reward_discount: float = 0.99,
        min_confidence: float = 0.5,
    ):
        self.buffer_size = buffer_size
        self.reward_discount = reward_discount
        self.min_confidence = min_confidence

        self.buffer: deque = deque(maxlen=buffer_size)

        # Statistics
        self.total_records = 0
        self.success_count = 0
        self.failure_count = 0

        # Class balance tracking
        self.class_counts = {0: 0, 1: 0, 2: 0}  # R, S, N

    def record_outcome(
        self,
        context_id: str,
        embedding: torch.Tensor,
        rsn_prediction: Optional[Dict[str, float]],
        task_success: bool,
        confidence: float,
        query_embedding: Optional[torch.Tensor] = None,
        attribution_scores: Optional[torch.Tensor] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Record an outcome for future training.

        Args:
            context_id: Unique identifier for the context
            embedding: Context embedding tensor
            rsn_prediction: Predicted R/S/N scores
            task_success: Whether the task was successful
            confidence: Model's confidence in prediction
            query_embedding: Optional query embedding
            attribution_scores: Optional per-token attributions
            metadata: Additional metadata
        """
        if confidence < self.min_confidence:
            return  # Skip low-confidence predictions

        record = OutcomeRecord(
            context_id=context_id,
            embedding=embedding.detach().cpu(),
            query_embedding=query_embedding.detach().cpu() if query_embedding is not None else None,
            rsn_prediction=rsn_prediction,
            task_success=task_success,
            confidence=confidence,
            attribution_scores=attribution_scores.detach().cpu() if attribution_scores is not None else None,
            metadata=metadata or {},
        )

        self.buffer.append(record)
        self.total_records += 1

        if task_success:
            self.success_count += 1
        else:
            self.failure_count += 1

    def generate_training_batch(
        self,
        batch_size: int = 64,
        balance_classes: bool = True,
        balance_outcomes: bool = True,
        device: Optional[torch.device] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Generate a balanced batch for training.

        Args:
            batch_size: Number of samples in batch
            balance_classes: Balance R/S/N classes
            balance_outcomes: Balance success/failure outcomes
            device: Target device for tensors

        Returns:
            embeddings: [B, D] context embeddings
            weak_labels: [B] R/S/N labels (0, 1, 2)
            weights: [B] sample weights for training
        """
        if len(self.buffer) < batch_size:
            batch_size = len(self.buffer)

        if batch_size == 0:
            raise RuntimeError("Buffer is empty")

        # Convert buffer to lists for sampling
        records = list(self.buffer)

        if balance_outcomes:
            # Separate by outcome
            success_records = [r for r in records if r.task_success]
            failure_records = [r for r in records if not r.task_success]

            # Sample equally from each
            n_success = min(len(success_records), batch_size // 2)
            n_failure = min(len(failure_records), batch_size // 2)

            # Adjust if one category is lacking
            if n_success < batch_size // 2:
                n_failure = min(len(failure_records), batch_size - n_success)
            if n_failure < batch_size // 2:
                n_success = min(len(success_records), batch_size - n_failure)

            indices_success = np.random.choice(len(success_records), n_success, replace=False)
            indices_failure = np.random.choice(len(failure_records), n_failure, replace=False)

            sampled = [success_records[i] for i in indices_success] + \
                      [failure_records[i] for i in indices_failure]
        else:
            # Random sampling
            indices = np.random.choice(len(records), batch_size, replace=False)
            sampled = [records[i] for i in indices]

        # Convert to tensors
        embeddings = torch.stack([r.embedding for r in sampled])

        # Generate weak labels from outcomes
        weak_labels = []
        weights = []

        for record in sampled:
            # Determine label based on RSN prediction and outcome
            if record.rsn_prediction is not None:
                r_score = record.rsn_prediction.get('relevant', 0.33)
                s_score = record.rsn_prediction.get('superfluous', 0.33)
                n_score = record.rsn_prediction.get('noise', 0.33)

                if record.task_success:
                    # Success: high R predictions are probably correct
                    if r_score > max(s_score, n_score):
                        label = 0  # R
                    else:
                        label = 1  # S (didn't help but didn't hurt)
                else:
                    # Failure: high N predictions might be correct
                    if n_score > max(r_score, s_score):
                        label = 2  # N
                    elif r_score > s_score:
                        label = 2  # N (was thought to be R but led to failure)
                    else:
                        label = 1  # S
            else:
                # No prediction: use outcome only
                label = 0 if record.task_success else 2

            weak_labels.append(label)
            weights.append(record.confidence)

        weak_labels = torch.tensor(weak_labels, dtype=torch.long)
        weights = torch.tensor(weights, dtype=torch.float)

        # Normalize weights
        weights = weights / (weights.sum() + 1e-8) * len(weights)

        if device is not None:
            embeddings = embeddings.to(device)
            weak_labels = weak_labels.to(device)
            weights = weights.to(device)

        return embeddings, weak_labels, weights

    def get_statistics(self) -> Dict[str, Any]:
        """Get buffer statistics."""
        return {
            'total_records': self.total_records,
            'buffer_size': len(self.buffer),
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'success_rate': self.success_count / max(self.total_records, 1),
            'class_counts': self.class_counts,
        }

    def clear(self) -> None:
        """Clear the buffer."""
        self.buffer.clear()
        self.total_records = 0
        self.success_count = 0
        self.failure_count = 0
        self.class_counts = {0: 0, 1: 0, 2: 0}


# =============================================================================
# Pseudo-Label Generator
# =============================================================================

class PseudoLabelGenerator:
    """
    Generate pseudo-labels for semi-supervised learning.

    Uses a teacher model (or ensemble) to label unlabeled data,
    then filters by confidence threshold.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.8,
        temperature: float = 1.0,
        use_soft_labels: bool = False,
    ):
        self.confidence_threshold = confidence_threshold
        self.temperature = temperature
        self.use_soft_labels = use_soft_labels

    def generate_labels(
        self,
        model: nn.Module,
        embeddings: torch.Tensor,
        return_mask: bool = True,
    ) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor]]:
        """
        Generate pseudo-labels from model predictions.

        Args:
            model: Teacher model for generating labels
            embeddings: [B, D] unlabeled embeddings
            return_mask: Whether to return confidence mask

        Returns:
            labels: [B] or [B, 3] pseudo-labels
            confidences: [B] prediction confidences
            mask: [B] bool mask for high-confidence samples (if return_mask)
        """
        model.eval()
        with torch.no_grad():
            output = model(embeddings)

            if isinstance(output, dict):
                logits = output.get('logits', output.get('probs'))
            else:
                logits = output

            # Apply temperature
            logits = logits / self.temperature
            probs = F.softmax(logits, dim=-1)

            # Get predictions and confidence
            confidences, predictions = probs.max(dim=-1)

            if self.use_soft_labels:
                labels = probs
            else:
                labels = predictions

            mask = None
            if return_mask:
                mask = confidences >= self.confidence_threshold

            return labels, confidences, mask

    def filter_by_confidence(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        confidences: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Filter samples by confidence threshold.

        Args:
            embeddings: [B, D] embeddings
            labels: [B] labels
            confidences: [B] confidences

        Returns:
            filtered_embeddings: [N, D] high-confidence embeddings
            filtered_labels: [N] high-confidence labels
        """
        mask = confidences >= self.confidence_threshold
        return embeddings[mask], labels[mask]


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    'AttributionMethod',
    'OutcomeRecord',
    'AttributionComputer',
    'OutcomeBasedSupervision',
    'RewardSignalCollector',
    'PseudoLabelGenerator',
]
