"""
Extended Degradation Taxonomy (40 Types) for Context Quality ISA (CQ-ISA™) - OP10: DEG_CLASSIFY

This module extends the existing CollapseType (16 types) to a comprehensive
40-type degradation taxonomy for Context Quality ISA compliance.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.9: Degradation Classification
  - §7.9.2: Degradation Types (8 patent-specified types + 24 extended)
  - §7.9.3: Severity Classification (CRITICAL, MAJOR, MINOR, TRACE)
  - §7.9.4: Geometric Domain Mapping (COMPRESSION, NEUTRAL, EXPANSION)

Patent-specified types (§7.9.2):
  HEALTHY, HALLUCINATION, DRIFT, DISTRACTION, POISONING, COLLAPSE, BOUNDARY, CONFLICT

Extended types (24 new, backward compatible):
  Context domain (7), Temporal domain (5), Adversarial domain (4),
  Hardware domain (4), Statistical domain (4)

Relevant patent files:
- docs/specs/patent_spec_section_7_9_degradation_classification.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

Design Principles:
    - EXTENDS existing CollapseType (backward compatible)
    - Adds 24 new degradation types for comprehensive coverage
    - Maps to geometric domains (COMPRESSION, NEUTRAL, EXPANSION)
    - Provides severity classification (CRITICAL, MAJOR, MINOR, TRACE)
    - Includes theta signatures where validated by experiments

Taxonomy Structure:
    1. Original 16 types from collapse.py (S4-validated)
    2. 24 new types covering:
       - Context-specific degradations (7 types)
       - Temporal degradations (5 types)
       - Adversarial degradations (4 types)
       - Hardware degradations (4 types)
       - Statistical degradations (4 types)

Spec: docs/api/specifications/CONTEXT_QUALITY_ISA_v0.1.md OP10
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, List
import numpy as np


# =============================================================================
# EXTENDED DEGRADATION TYPE (40 types)
# =============================================================================

class DegradationType(str, Enum):
    """
    Extended 40-type degradation taxonomy for Context Quality ISA (CQ-ISA™).

    BACKWARD COMPATIBLE: Includes all 16 original CollapseType values.
    EXTENDED: Adds 24 new types for comprehensive coverage.

    Categories:
        - Quality Domain (R/S/N): COMPRESSION-associated
        - Reliability Domain (ω): Mixed domains
        - Representation Domain: Structural issues
        - Uncertainty Domain: Confidence issues
        - Distributional Domain: Drift issues
        - Context Domain (NEW): Context-specific issues
        - Temporal Domain (NEW): Time-dependent issues
        - Adversarial Domain (NEW): Attack-induced issues
        - Hardware Domain (NEW): Physical degradations
        - Statistical Domain (NEW): Mathematical anomalies
    """

    # ==========================================================================
    # ORIGINAL 16 TYPES (from collapse.py)
    # ==========================================================================

    NONE = "NONE"

    # Quality Domain (R/S/N) - typically COMPRESSION
    POISONING = "POISONING"                         # Data poisoning
    DISTRACTION = "DISTRACTION"                     # Distractor features
    CONFLICT = "CONFLICT"                           # Feature conflicts
    CLASH = "CLASH"                                 # Conflicting signals

    # Reliability Domain (ω) - mixed domains
    HALLUCINATION = "HALLUCINATION"                 # θ = +64° (EXPANSION)
    O_POISONING = "O_POISONING"                     # θ = -71° (COMPRESSION)
    DRIFT = "DRIFT"                                 # General drift

    # Representation Domain
    RSN_COLLAPSE = "RSN_COLLAPSE"                   # θ = 48°, scale → 0
    POSTERIOR_COLLAPSE = "POSTERIOR_COLLAPSE"       # Probability collapse
    MODE_COLLAPSE = "MODE_COLLAPSE"                 # Mode collapse

    # Uncertainty Domain
    OVERCONFIDENCE = "OVERCONFIDENCE"               # False certainty
    EPISTEMIC_SPIKE = "EPISTEMIC_SPIKE"             # Knowledge uncertainty
    ALEATORIC_DOMINANCE = "ALEATORIC_DOMINANCE"     # Noise dominance

    # Distributional Domain
    DISTRIBUTIONAL_SHIFT = "DISTRIBUTIONAL_SHIFT"   # Distribution change
    GRADUAL_DRIFT = "GRADUAL_DRIFT"                 # Slow drift

    # ==========================================================================
    # NEW: CONTEXT DOMAIN (7 types)
    # ==========================================================================

    QUERY_MISMATCH = "QUERY_MISMATCH"               # Query-context mismatch
    CONTEXT_FRAGMENTATION = "CONTEXT_FRAGMENTATION" # Fragmented context
    SEMANTIC_INCOHERENCE = "SEMANTIC_INCOHERENCE"   # Incoherent semantics
    INFORMATION_LOSS = "INFORMATION_LOSS"           # Critical info dropped
    REDUNDANCY_OVERFLOW = "REDUNDANCY_OVERFLOW"     # Excessive redundancy
    RELEVANCE_EROSION = "RELEVANCE_EROSION"         # Decreasing relevance
    CONTEXT_STARVATION = "CONTEXT_STARVATION"       # Insufficient context

    # ==========================================================================
    # NEW: TEMPORAL DOMAIN (5 types)
    # ==========================================================================

    TEMPORAL_DISCONTINUITY = "TEMPORAL_DISCONTINUITY" # Time-series break
    RECENCY_BIAS = "RECENCY_BIAS"                   # Over-weighting recent
    HISTORICAL_DECAY = "HISTORICAL_DECAY"           # Historical info loss
    PREDICTION_STALENESS = "PREDICTION_STALENESS"   # Stale predictions
    CONCEPT_DRIFT = "CONCEPT_DRIFT"                 # Concept evolution

    # ==========================================================================
    # NEW: ADVERSARIAL DOMAIN (4 types)
    # ==========================================================================

    PROMPT_INJECTION = "PROMPT_INJECTION"           # Injected prompts
    JAILBREAK_ATTEMPT = "JAILBREAK_ATTEMPT"         # Jailbreak pattern
    EVASION_ATTACK = "EVASION_ATTACK"               # Adversarial evasion
    BACKDOOR_TRIGGER = "BACKDOOR_TRIGGER"           # Backdoor activation

    # ==========================================================================
    # NEW: HARDWARE DOMAIN (4 types)
    # ==========================================================================

    MEMORY_CORRUPTION = "MEMORY_CORRUPTION"         # Memory errors
    COMPUTE_DEGRADATION = "COMPUTE_DEGRADATION"     # Hardware slowdown
    QUANTIZATION_ERROR = "QUANTIZATION_ERROR"       # Precision loss
    THERMAL_THROTTLING = "THERMAL_THROTTLING"       # Temperature-induced

    # ==========================================================================
    # NEW: STATISTICAL DOMAIN (4 types)
    # ==========================================================================

    OUTLIER_CONTAMINATION = "OUTLIER_CONTAMINATION" # Statistical outliers
    VARIANCE_INFLATION = "VARIANCE_INFLATION"       # Excessive variance
    BIAS_AMPLIFICATION = "BIAS_AMPLIFICATION"       # Systematic bias
    CORRELATION_BREAKDOWN = "CORRELATION_BREAKDOWN" # Correlation loss

    # ==========================================================================
    # NEW: DEFENSE DOMAIN (3 types) - from routing/defenses.py bridge
    # ==========================================================================

    GOAL_DRIFT = "GOAL_DRIFT"                       # Goal anchor integrity violation
    SYBIL_ATTACK = "SYBIL_ATTACK"                   # Agent fingerprint clustering
    RATE_LIMITED = "RATE_LIMITED"                   # Token bucket backpressure


# =============================================================================
# DEGRADATION METADATA
# =============================================================================

@dataclass
class DegradationMetadata:
    """
    Metadata for degradation type classification.

    Provides:
        - Geometric domain association
        - Severity classification
        - Theta signature (if validated)
        - Detection confidence threshold
        - Recommended enforcement action
    """
    degradation_type: DegradationType
    geometric_domain: str  # COMPRESSION, NEUTRAL, EXPANSION
    severity: str          # CRITICAL, MAJOR, MINOR, TRACE
    theta_signature: Optional[Dict[str, float]] = None  # {'mean': θ, 'std': σ}
    confidence_threshold: float = 0.7
    enforcement_action: str = "LOG"  # LOG, WARN, BLOCK, ESCALATE
    description: str = ""


# =============================================================================
# DEGRADATION TAXONOMY REGISTRY
# =============================================================================

DEGRADATION_TAXONOMY: Dict[DegradationType, DegradationMetadata] = {
    # =========================================================================
    # ORIGINAL 16 TYPES (from collapse.py with S4 validation)
    # =========================================================================

    DegradationType.NONE: DegradationMetadata(
        degradation_type=DegradationType.NONE,
        geometric_domain="NEUTRAL",
        severity="TRACE",
        theta_signature={'mean': 58.9, 'std': 2.0},
        confidence_threshold=0.95,
        enforcement_action="LOG",
        description="No degradation detected"
    ),

    DegradationType.POISONING: DegradationMetadata(
        degradation_type=DegradationType.POISONING,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        theta_signature={'mean': 58.8, 'std': 2.1},
        confidence_threshold=0.8,
        enforcement_action="BLOCK",
        description="Data poisoning attack detected"
    ),

    DegradationType.DISTRACTION: DegradationMetadata(
        degradation_type=DegradationType.DISTRACTION,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        theta_signature={'mean': 56.4, 'std': 2.3},
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Distractor features present"
    ),

    DegradationType.CONFLICT: DegradationMetadata(
        degradation_type=DegradationType.CONFLICT,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        theta_signature={'mean': 55.9, 'std': 3.2},
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Feature confusion detected"
    ),

    DegradationType.CLASH: DegradationMetadata(
        degradation_type=DegradationType.CLASH,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Conflicting signals detected"
    ),

    DegradationType.HALLUCINATION: DegradationMetadata(
        degradation_type=DegradationType.HALLUCINATION,
        geometric_domain="EXPANSION",
        severity="CRITICAL",
        theta_signature={'mean': 63.9, 'std': 2.0},
        confidence_threshold=0.8,
        enforcement_action="BLOCK",
        description="Model hallucination detected (θ = +64°)"
    ),

    DegradationType.O_POISONING: DegradationMetadata(
        degradation_type=DegradationType.O_POISONING,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        theta_signature={'mean': -71.0, 'std': 33.5},
        confidence_threshold=0.8,
        enforcement_action="BLOCK",
        description="Omega poisoning detected (θ = -71°)"
    ),

    DegradationType.DRIFT: DegradationMetadata(
        degradation_type=DegradationType.DRIFT,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="General drift detected"
    ),

    DegradationType.RSN_COLLAPSE: DegradationMetadata(
        degradation_type=DegradationType.RSN_COLLAPSE,
        geometric_domain="NEUTRAL",
        severity="CRITICAL",
        theta_signature={'mean': 48.0, 'std': 0.2},
        confidence_threshold=0.9,
        enforcement_action="BLOCK",
        description="RSN collapse detected (scale → 0)"
    ),

    DegradationType.POSTERIOR_COLLAPSE: DegradationMetadata(
        degradation_type=DegradationType.POSTERIOR_COLLAPSE,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.85,
        enforcement_action="BLOCK",
        description="Posterior distribution collapse"
    ),

    DegradationType.MODE_COLLAPSE: DegradationMetadata(
        degradation_type=DegradationType.MODE_COLLAPSE,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.85,
        enforcement_action="BLOCK",
        description="Mode collapse detected"
    ),

    DegradationType.OVERCONFIDENCE: DegradationMetadata(
        degradation_type=DegradationType.OVERCONFIDENCE,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Model overconfidence detected"
    ),

    DegradationType.EPISTEMIC_SPIKE: DegradationMetadata(
        degradation_type=DegradationType.EPISTEMIC_SPIKE,
        geometric_domain="EXPANSION",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Epistemic uncertainty spike"
    ),

    DegradationType.ALEATORIC_DOMINANCE: DegradationMetadata(
        degradation_type=DegradationType.ALEATORIC_DOMINANCE,
        geometric_domain="NEUTRAL",
        severity="MINOR",
        confidence_threshold=0.65,
        enforcement_action="LOG",
        description="Aleatoric uncertainty dominance"
    ),

    DegradationType.DISTRIBUTIONAL_SHIFT: DegradationMetadata(
        degradation_type=DegradationType.DISTRIBUTIONAL_SHIFT,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Distribution shift detected"
    ),

    DegradationType.GRADUAL_DRIFT: DegradationMetadata(
        degradation_type=DegradationType.GRADUAL_DRIFT,
        geometric_domain="NEUTRAL",
        severity="MINOR",
        confidence_threshold=0.6,
        enforcement_action="LOG",
        description="Gradual drift in progress"
    ),

    # =========================================================================
    # NEW: CONTEXT DOMAIN (7 types)
    # =========================================================================

    DegradationType.QUERY_MISMATCH: DegradationMetadata(
        degradation_type=DegradationType.QUERY_MISMATCH,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Query does not match context"
    ),

    DegradationType.CONTEXT_FRAGMENTATION: DegradationMetadata(
        degradation_type=DegradationType.CONTEXT_FRAGMENTATION,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Context is fragmented or incomplete"
    ),

    DegradationType.SEMANTIC_INCOHERENCE: DegradationMetadata(
        degradation_type=DegradationType.SEMANTIC_INCOHERENCE,
        geometric_domain="EXPANSION",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Semantic incoherence in context"
    ),

    DegradationType.INFORMATION_LOSS: DegradationMetadata(
        degradation_type=DegradationType.INFORMATION_LOSS,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.8,
        enforcement_action="BLOCK",
        description="Critical information lost"
    ),

    DegradationType.REDUNDANCY_OVERFLOW: DegradationMetadata(
        degradation_type=DegradationType.REDUNDANCY_OVERFLOW,
        geometric_domain="EXPANSION",
        severity="MINOR",
        confidence_threshold=0.65,
        enforcement_action="LOG",
        description="Excessive redundancy in context"
    ),

    DegradationType.RELEVANCE_EROSION: DegradationMetadata(
        degradation_type=DegradationType.RELEVANCE_EROSION,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Relevance decreasing over time"
    ),

    DegradationType.CONTEXT_STARVATION: DegradationMetadata(
        degradation_type=DegradationType.CONTEXT_STARVATION,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.85,
        enforcement_action="BLOCK",
        description="Insufficient context for query"
    ),

    # =========================================================================
    # NEW: TEMPORAL DOMAIN (5 types)
    # =========================================================================

    DegradationType.TEMPORAL_DISCONTINUITY: DegradationMetadata(
        degradation_type=DegradationType.TEMPORAL_DISCONTINUITY,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Time-series discontinuity detected"
    ),

    DegradationType.RECENCY_BIAS: DegradationMetadata(
        degradation_type=DegradationType.RECENCY_BIAS,
        geometric_domain="COMPRESSION",
        severity="MINOR",
        confidence_threshold=0.65,
        enforcement_action="LOG",
        description="Over-weighting recent information"
    ),

    DegradationType.HISTORICAL_DECAY: DegradationMetadata(
        degradation_type=DegradationType.HISTORICAL_DECAY,
        geometric_domain="COMPRESSION",
        severity="MINOR",
        confidence_threshold=0.6,
        enforcement_action="LOG",
        description="Historical information decay"
    ),

    DegradationType.PREDICTION_STALENESS: DegradationMetadata(
        degradation_type=DegradationType.PREDICTION_STALENESS,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Stale predictions detected"
    ),

    DegradationType.CONCEPT_DRIFT: DegradationMetadata(
        degradation_type=DegradationType.CONCEPT_DRIFT,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Concept evolution detected"
    ),

    # =========================================================================
    # NEW: ADVERSARIAL DOMAIN (4 types)
    # =========================================================================

    DegradationType.PROMPT_INJECTION: DegradationMetadata(
        degradation_type=DegradationType.PROMPT_INJECTION,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.85,
        enforcement_action="BLOCK",
        description="Prompt injection attack detected"
    ),

    DegradationType.JAILBREAK_ATTEMPT: DegradationMetadata(
        degradation_type=DegradationType.JAILBREAK_ATTEMPT,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.9,
        enforcement_action="BLOCK",
        description="Jailbreak attempt detected"
    ),

    DegradationType.EVASION_ATTACK: DegradationMetadata(
        degradation_type=DegradationType.EVASION_ATTACK,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.85,
        enforcement_action="BLOCK",
        description="Adversarial evasion attack"
    ),

    DegradationType.BACKDOOR_TRIGGER: DegradationMetadata(
        degradation_type=DegradationType.BACKDOOR_TRIGGER,
        geometric_domain="COMPRESSION",
        severity="CRITICAL",
        confidence_threshold=0.95,
        enforcement_action="ESCALATE",
        description="Backdoor trigger detected"
    ),

    # =========================================================================
    # NEW: HARDWARE DOMAIN (4 types)
    # =========================================================================

    DegradationType.MEMORY_CORRUPTION: DegradationMetadata(
        degradation_type=DegradationType.MEMORY_CORRUPTION,
        geometric_domain="NEUTRAL",
        severity="CRITICAL",
        confidence_threshold=0.9,
        enforcement_action="ESCALATE",
        description="Memory corruption detected"
    ),

    DegradationType.COMPUTE_DEGRADATION: DegradationMetadata(
        degradation_type=DegradationType.COMPUTE_DEGRADATION,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Hardware compute degradation"
    ),

    DegradationType.QUANTIZATION_ERROR: DegradationMetadata(
        degradation_type=DegradationType.QUANTIZATION_ERROR,
        geometric_domain="COMPRESSION",
        severity="MINOR",
        confidence_threshold=0.7,
        enforcement_action="LOG",
        description="Quantization precision loss"
    ),

    DegradationType.THERMAL_THROTTLING: DegradationMetadata(
        degradation_type=DegradationType.THERMAL_THROTTLING,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.8,
        enforcement_action="WARN",
        description="Thermal throttling detected"
    ),

    # =========================================================================
    # NEW: STATISTICAL DOMAIN (4 types)
    # =========================================================================

    DegradationType.OUTLIER_CONTAMINATION: DegradationMetadata(
        degradation_type=DegradationType.OUTLIER_CONTAMINATION,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Statistical outlier contamination"
    ),

    DegradationType.VARIANCE_INFLATION: DegradationMetadata(
        degradation_type=DegradationType.VARIANCE_INFLATION,
        geometric_domain="EXPANSION",
        severity="MINOR",
        confidence_threshold=0.65,
        enforcement_action="LOG",
        description="Excessive variance detected"
    ),

    DegradationType.BIAS_AMPLIFICATION: DegradationMetadata(
        degradation_type=DegradationType.BIAS_AMPLIFICATION,
        geometric_domain="COMPRESSION",
        severity="MAJOR",
        confidence_threshold=0.75,
        enforcement_action="WARN",
        description="Systematic bias amplification"
    ),

    DegradationType.CORRELATION_BREAKDOWN: DegradationMetadata(
        degradation_type=DegradationType.CORRELATION_BREAKDOWN,
        geometric_domain="NEUTRAL",
        severity="MAJOR",
        confidence_threshold=0.7,
        enforcement_action="WARN",
        description="Signal correlation breakdown"
    ),
}


# =============================================================================
# DEGRADATION SIGNAL (OP10 Output)
# =============================================================================

@dataclass
class DegradationSignal:
    """
    Degradation classification result for Context Quality ISA (CQ-ISA™) - OP10: DEG_CLASSIFY.

    Output format for degradation classifier.

    Attributes:
        degradation_type: Primary degradation type
        confidence: Classification confidence (0-1)
        severity: Severity level (CRITICAL, MAJOR, MINOR, TRACE)
        geometric_domain: Associated domain (COMPRESSION, NEUTRAL, EXPANSION)
        theta_deviation: Deviation from expected theta (if applicable)
        enforcement_action: Recommended action (LOG, WARN, BLOCK, ESCALATE)
        secondary_types: Alternative degradation types (ranked by confidence)
    """
    degradation_type: DegradationType
    confidence: float
    severity: str
    geometric_domain: str
    theta_deviation: Optional[float] = None
    enforcement_action: str = "LOG"
    secondary_types: List[tuple] = None  # [(type, confidence), ...]

    def __post_init__(self):
        """Initialize secondary_types if not provided."""
        if self.secondary_types is None:
            self.secondary_types = []

    def to_dict(self) -> Dict:
        """Convert to JSON-serializable dict."""
        return {
            'degradation_type': self.degradation_type.value,
            'confidence': self.confidence,
            'severity': self.severity,
            'geometric_domain': self.geometric_domain,
            'theta_deviation': self.theta_deviation,
            'enforcement_action': self.enforcement_action,
            'secondary_types': [
                {'type': t.value, 'confidence': c}
                for t, c in self.secondary_types
            ],
        }


# =============================================================================
# CLASSIFIER HELPERS
# =============================================================================

def get_degradation_metadata(deg_type: DegradationType) -> DegradationMetadata:
    """
    Get metadata for degradation type.

    Args:
        deg_type: Degradation type

    Returns:
        DegradationMetadata for type

    Raises:
        KeyError: If type not in taxonomy
    """
    return DEGRADATION_TAXONOMY[deg_type]


def get_degradations_by_domain(domain: str) -> List[DegradationType]:
    """
    Get all degradation types for a geometric domain.

    Args:
        domain: Geometric domain (COMPRESSION, NEUTRAL, EXPANSION)

    Returns:
        List of degradation types in domain
    """
    return [
        deg_type
        for deg_type, metadata in DEGRADATION_TAXONOMY.items()
        if metadata.geometric_domain == domain
    ]


def get_degradations_by_severity(severity: str) -> List[DegradationType]:
    """
    Get all degradation types for a severity level.

    Args:
        severity: Severity level (CRITICAL, MAJOR, MINOR, TRACE)

    Returns:
        List of degradation types with severity
    """
    return [
        deg_type
        for deg_type, metadata in DEGRADATION_TAXONOMY.items()
        if metadata.severity == severity
    ]


def classify_by_theta(theta: float, confidence_threshold: float = 0.7) -> Optional[DegradationSignal]:
    """
    Classify degradation by theta signature (if available).

    Uses Gaussian likelihood to match theta to known signatures.

    Args:
        theta: Observed theta value (degrees)
        confidence_threshold: Minimum confidence for classification

    Returns:
        DegradationSignal if classified, None otherwise
    """
    scores = []

    for deg_type, metadata in DEGRADATION_TAXONOMY.items():
        if metadata.theta_signature is None:
            continue

        mean = metadata.theta_signature['mean']
        std = metadata.theta_signature['std']

        # Gaussian likelihood
        deviation = abs(theta - mean)
        likelihood = np.exp(-0.5 * (deviation / std) ** 2)

        scores.append((deg_type, likelihood, deviation))

    if not scores:
        return None

    # Sort by likelihood
    scores.sort(key=lambda x: x[1], reverse=True)
    best_type, best_conf, best_dev = scores[0]

    if best_conf < confidence_threshold:
        return None

    metadata = DEGRADATION_TAXONOMY[best_type]

    return DegradationSignal(
        degradation_type=best_type,
        confidence=float(best_conf),
        severity=metadata.severity,
        geometric_domain=metadata.geometric_domain,
        theta_deviation=float(best_dev),
        enforcement_action=metadata.enforcement_action,
        secondary_types=[(t, float(c)) for t, c, _ in scores[1:4]],
    )


__all__ = [
    'DegradationType',
    'DegradationMetadata',
    'DegradationSignal',
    'DEGRADATION_TAXONOMY',
    'get_degradation_metadata',
    'get_degradations_by_domain',
    'get_degradations_by_severity',
    'classify_by_theta',
]
