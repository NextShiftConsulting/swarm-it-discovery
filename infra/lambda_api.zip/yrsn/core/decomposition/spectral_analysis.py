"""
Spectral Analysis for Phase Transition Detection

This module provides eigenvalue tracking and spectral analysis tools
for detecting phase transitions in R/S/N decomposition.

Key components:
1. EigenvalueTracker - Monitor eigenvalue spectrum over time
2. MarchenkoPasturValidator - Validate against theoretical noise distribution
3. SignalNoiseAnalyzer - Compute SNR and quality metrics from spectrum

The Marchenko-Pastur law describes the limiting distribution of eigenvalues
for large random matrices. Signal components appear as outliers above
this distribution.

Integration with phase_transitions.py:
    - Uses BBP thresholds to interpret spectral analysis results
    - Quality metric α derived from spectral decomposition

Reference: Marchenko & Pastur (1967), Baik, Ben Arous & Péché (2005)
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from collections import deque
import time

from .phase_transitions import (
    compute_bbp_threshold,
    compute_bbp_threshold_inverse,
    BBPThresholdTable,
)


# =============================================================================
# Data Structures
# =============================================================================

@dataclass
class EigenvalueSnapshot:
    """Snapshot of eigenvalue analysis at a point in time."""
    timestamp: float
    eigenvalues: np.ndarray
    signal_count: int  # Number of eigenvalues above noise bulk
    noise_floor: float  # Upper bound of noise bulk
    effective_rank: float  # Participation ratio
    quality_alpha: float  # Signal energy / total energy
    total_energy: float
    signal_energy: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'eigenvalues': self.eigenvalues.tolist(),
            'signal_count': self.signal_count,
            'noise_floor': self.noise_floor,
            'effective_rank': self.effective_rank,
            'quality_alpha': self.quality_alpha,
            'total_energy': self.total_energy,
            'signal_energy': self.signal_energy,
        }


@dataclass
class MPValidationResult:
    """Result of Marchenko-Pastur validation."""
    gamma: float  # Aspect ratio n/p
    lambda_min: float  # Theoretical lower bound
    lambda_max: float  # Theoretical upper bound (noise ceiling)
    num_outliers: int  # Eigenvalues above lambda_max (signal)
    ks_statistic: float  # Kolmogorov-Smirnov test statistic
    p_value: float  # P-value for KS test
    is_valid: bool  # Whether bulk follows MP law
    bulk_eigenvalues: np.ndarray  # Eigenvalues within MP bounds
    outlier_eigenvalues: np.ndarray  # Eigenvalues above MP bounds

    def to_dict(self) -> Dict[str, Any]:
        return {
            'gamma': self.gamma,
            'lambda_min': self.lambda_min,
            'lambda_max': self.lambda_max,
            'num_outliers': self.num_outliers,
            'ks_statistic': self.ks_statistic,
            'p_value': self.p_value,
            'is_valid': self.is_valid,
        }


@dataclass
class SNRAnalysisResult:
    """Result of signal-to-noise ratio analysis."""
    signal_energy: float  # Energy in signal eigenvalues
    noise_energy: float  # Energy in noise eigenvalues
    snr: float  # Signal-to-noise ratio
    snr_db: float  # SNR in decibels
    effective_rank: float  # Participation ratio
    quality_alpha: float  # Signal fraction (α)
    recommended_rank: int  # Based on BBP thresholds
    signal_count: int  # Number of signal components
    noise_floor: float  # Noise ceiling from MP law

    def to_dict(self) -> Dict[str, Any]:
        return {
            'signal_energy': self.signal_energy,
            'noise_energy': self.noise_energy,
            'snr': self.snr,
            'snr_db': self.snr_db,
            'effective_rank': self.effective_rank,
            'quality_alpha': self.quality_alpha,
            'recommended_rank': self.recommended_rank,
            'signal_count': self.signal_count,
            'noise_floor': self.noise_floor,
        }


# =============================================================================
# Marchenko-Pastur Law
# =============================================================================

def compute_mp_bounds(gamma: float, sigma: float = 1.0) -> Tuple[float, float]:
    """
    Compute Marchenko-Pastur distribution bounds.

    For a random matrix with aspect ratio γ = n/p (samples/features)
    and noise variance σ², the eigenvalues concentrate in [λ_-, λ_+].

    λ_± = σ²(1 ± √γ)²

    Args:
        gamma: Aspect ratio n/p (must be > 0)
        sigma: Noise standard deviation (default 1.0)

    Returns:
        (lambda_min, lambda_max) bounds
    """
    if gamma <= 0:
        raise ValueError(f"Gamma must be > 0, got {gamma}")

    sigma_sq = sigma ** 2

    if gamma <= 1:
        lambda_min = sigma_sq * (1 - np.sqrt(gamma)) ** 2
        lambda_max = sigma_sq * (1 + np.sqrt(gamma)) ** 2
    else:
        # For gamma > 1, some eigenvalues are exactly 0
        lambda_min = 0
        lambda_max = sigma_sq * (1 + np.sqrt(gamma)) ** 2

    return lambda_min, lambda_max


def mp_density(x: np.ndarray, gamma: float, sigma: float = 1.0) -> np.ndarray:
    """
    Marchenko-Pastur probability density function.

    ρ(λ) = √((λ_+ - λ)(λ - λ_-)) / (2πγσ²λ)

    Args:
        x: Eigenvalue points to evaluate
        gamma: Aspect ratio
        sigma: Noise standard deviation

    Returns:
        Density values at each point
    """
    lambda_min, lambda_max = compute_mp_bounds(gamma, sigma)
    sigma_sq = sigma ** 2

    density = np.zeros_like(x, dtype=float)
    mask = (x > lambda_min) & (x < lambda_max)

    if np.any(mask):
        x_valid = x[mask]
        density[mask] = (
            np.sqrt((lambda_max - x_valid) * (x_valid - lambda_min))
            / (2 * np.pi * gamma * sigma_sq * x_valid)
        )

    return density


# =============================================================================
# Eigenvalue Tracker (numpy-only version)
# =============================================================================

class EigenvalueTracker:
    """
    Track eigenvalues from decomposition matrices over time.

    This version works with numpy arrays only. For torch tensor support,
    convert to numpy first or use with torch.no_grad().
    """

    def __init__(
        self,
        history_size: int = 100,
        sigma_estimate: float = 1.0,
        outlier_margin: float = 1.1,
    ):
        """
        Initialize eigenvalue tracker.

        Args:
            history_size: Number of snapshots to keep
            sigma_estimate: Initial noise variance estimate
            outlier_margin: Multiplier for lambda_max to identify outliers
        """
        self.history_size = history_size
        self.sigma = sigma_estimate
        self.outlier_margin = outlier_margin

        self.history: deque = deque(maxlen=history_size)
        self._eigenvalue_buffer: List[np.ndarray] = []

    def update(
        self,
        matrix: np.ndarray,
        compute_full: bool = True,
    ) -> EigenvalueSnapshot:
        """
        Compute and store eigenvalues from matrix.

        Args:
            matrix: Input numpy array [B, L, D] or [L, D] or [D, D]
            compute_full: Whether to compute full eigendecomposition

        Returns:
            Snapshot with eigenvalues and analysis
        """
        now = time.time()

        # Compute covariance matrix
        cov = self._compute_covariance(matrix)

        # Compute eigenvalues (sorted descending)
        eigenvalues = np.linalg.eigvalsh(cov)
        eigenvalues = np.sort(eigenvalues)[::-1]  # Descending order

        # Compute aspect ratio
        if len(matrix.shape) == 3:
            n_samples = matrix.shape[0] * matrix.shape[1]
            n_features = matrix.shape[2]
        elif len(matrix.shape) == 2:
            n_samples = matrix.shape[0]
            n_features = matrix.shape[1]
        else:
            n_samples = n_features = matrix.shape[0]

        gamma = n_samples / max(n_features, 1)

        # Compute MP bounds
        _, lambda_max = compute_mp_bounds(gamma, self.sigma)

        # Count signal eigenvalues (above noise)
        noise_ceiling = lambda_max * self.outlier_margin
        signal_mask = eigenvalues > noise_ceiling
        signal_count = int(np.sum(signal_mask))

        # Compute energies
        total_energy = float(np.sum(eigenvalues))
        signal_energy = float(np.sum(eigenvalues[signal_mask])) if signal_count > 0 else 0.0

        # Quality metric
        quality_alpha = signal_energy / max(total_energy, 1e-8)

        # Effective rank (participation ratio)
        effective_rank = self._compute_effective_rank(eigenvalues)

        snapshot = EigenvalueSnapshot(
            timestamp=now,
            eigenvalues=eigenvalues,
            signal_count=signal_count,
            noise_floor=noise_ceiling,
            effective_rank=effective_rank,
            quality_alpha=quality_alpha,
            total_energy=total_energy,
            signal_energy=signal_energy,
        )

        self.history.append(snapshot)
        return snapshot

    def _compute_covariance(self, matrix: np.ndarray) -> np.ndarray:
        """Compute covariance matrix from input."""
        # Flatten to [N, D]
        if len(matrix.shape) == 3:
            flat = matrix.reshape(-1, matrix.shape[-1])
        elif len(matrix.shape) == 2:
            flat = matrix
        else:
            return matrix

        # Center
        flat = flat - flat.mean(axis=0)

        # Covariance
        n = flat.shape[0]
        cov = flat.T @ flat / max(n - 1, 1)

        return cov

    def _compute_effective_rank(self, eigenvalues: np.ndarray) -> float:
        """Compute effective rank (participation ratio)."""
        eigenvalues = np.abs(eigenvalues)
        total = np.sum(eigenvalues)
        total_sq = np.sum(eigenvalues ** 2)

        if total_sq < 1e-10:
            return 1.0

        return (total ** 2) / total_sq

    def get_signal_rank(self) -> int:
        """Get estimated number of signal components from latest snapshot."""
        if not self.history:
            return 1
        return self.history[-1].signal_count

    def get_noise_floor(self) -> float:
        """Get noise floor from latest snapshot."""
        if not self.history:
            return 1.0
        return self.history[-1].noise_floor

    def get_quality_trend(self, window: int = 10) -> Dict[str, float]:
        """Get quality trend over recent history."""
        if not self.history:
            return {'mean': 0, 'std': 0, 'trend': 0, 'count': 0}

        recent = list(self.history)[-window:]
        alphas = [s.quality_alpha for s in recent]

        mean_alpha = np.mean(alphas)
        std_alpha = np.std(alphas) if len(alphas) > 1 else 0

        # Simple linear trend
        if len(alphas) >= 3:
            x = np.arange(len(alphas))
            trend = np.polyfit(x, alphas, 1)[0]
        else:
            trend = 0

        return {
            'mean': float(mean_alpha),
            'std': float(std_alpha),
            'trend': float(trend),
            'count': len(alphas),
        }

    def reset(self):
        """Reset tracker state."""
        self.history.clear()
        self._eigenvalue_buffer.clear()


# =============================================================================
# Marchenko-Pastur Validator
# =============================================================================

class MarchenkoPasturValidator:
    """Validate eigenvalue distribution against Marchenko-Pastur law."""

    def __init__(
        self,
        significance_level: float = 0.05,
        min_samples_for_ks: int = 20,
    ):
        self.significance_level = significance_level
        self.min_samples_for_ks = min_samples_for_ks

    def validate(
        self,
        eigenvalues: np.ndarray,
        gamma: float,
        sigma: float = 1.0,
    ) -> MPValidationResult:
        """Validate eigenvalue distribution against MP law."""
        eigenvalues = np.sort(eigenvalues)[::-1]

        # Compute bounds
        lambda_min, lambda_max = compute_mp_bounds(gamma, sigma)

        # Identify bulk vs outliers
        bulk_mask = (eigenvalues >= lambda_min * 0.9) & (eigenvalues <= lambda_max * 1.1)
        outlier_mask = eigenvalues > lambda_max * 1.1

        bulk_eigenvalues = eigenvalues[bulk_mask]
        outlier_eigenvalues = eigenvalues[outlier_mask]
        num_outliers = len(outlier_eigenvalues)

        # KS test against MP distribution (if enough samples)
        ks_statistic = 0.0
        p_value = 1.0
        is_valid = True

        if len(bulk_eigenvalues) >= self.min_samples_for_ks:
            try:
                from scipy import stats
                normalized = (bulk_eigenvalues - lambda_min) / (lambda_max - lambda_min)
                normalized = np.clip(normalized, 0, 1)
                ks_statistic, p_value = stats.kstest(normalized, 'uniform')
                is_valid = p_value > self.significance_level
            except ImportError:
                pass

        return MPValidationResult(
            gamma=gamma,
            lambda_min=lambda_min,
            lambda_max=lambda_max,
            num_outliers=num_outliers,
            ks_statistic=ks_statistic,
            p_value=p_value,
            is_valid=is_valid,
            bulk_eigenvalues=bulk_eigenvalues,
            outlier_eigenvalues=outlier_eigenvalues,
        )

    def count_outliers(
        self,
        eigenvalues: np.ndarray,
        gamma: float,
        sigma: float = 1.0,
        margin: float = 1.1,
    ) -> int:
        """Count eigenvalues above MP upper bound (signal components)."""
        _, lambda_max = compute_mp_bounds(gamma, sigma)
        return int(np.sum(eigenvalues > lambda_max * margin))

    def estimate_sigma(
        self,
        eigenvalues: np.ndarray,
        gamma: float,
        percentile: float = 50,
    ) -> float:
        """Estimate noise variance from eigenvalue distribution."""
        median_eig = np.percentile(eigenvalues, percentile)
        factor = (1 + np.sqrt(gamma)) ** 2 / 2
        sigma_sq = median_eig / factor
        return np.sqrt(max(sigma_sq, 1e-8))


# =============================================================================
# Signal-to-Noise Analyzer
# =============================================================================

class SignalNoiseAnalyzer:
    """
    Analyze signal-to-noise ratio from spectral decomposition.

    Combines eigenvalue analysis with BBP thresholds to provide
    actionable quality metrics and rank recommendations.
    """

    def __init__(
        self,
        bbp_table: Optional[BBPThresholdTable] = None,
        outlier_margin: float = 1.1,
    ):
        self.bbp_table = bbp_table or BBPThresholdTable.build()
        self.outlier_margin = outlier_margin
        self.mp_validator = MarchenkoPasturValidator()

    def analyze(
        self,
        eigenvalues: np.ndarray,
        gamma: float = 1.0,
        sigma: Optional[float] = None,
    ) -> SNRAnalysisResult:
        """Perform full SNR analysis on eigenvalue spectrum."""
        eigenvalues = np.sort(np.abs(eigenvalues))[::-1]

        if sigma is None:
            sigma = self.mp_validator.estimate_sigma(eigenvalues, gamma)

        _, lambda_max = compute_mp_bounds(gamma, sigma)
        noise_floor = lambda_max * self.outlier_margin

        signal_mask = eigenvalues > noise_floor
        signal_eigenvalues = eigenvalues[signal_mask]
        noise_eigenvalues = eigenvalues[~signal_mask]

        signal_count = len(signal_eigenvalues)
        signal_energy = float(np.sum(signal_eigenvalues))
        noise_energy = float(np.sum(noise_eigenvalues))
        total_energy = signal_energy + noise_energy

        snr = signal_energy / max(noise_energy, 1e-8)
        snr_db = 10 * np.log10(max(snr, 1e-8))

        quality_alpha = signal_energy / max(total_energy, 1e-8)
        effective_rank = self._compute_effective_rank(eigenvalues)
        recommended_rank = self.bbp_table.get_max_rank_for_quality(quality_alpha)

        return SNRAnalysisResult(
            signal_energy=signal_energy,
            noise_energy=noise_energy,
            snr=snr,
            snr_db=snr_db,
            effective_rank=effective_rank,
            quality_alpha=quality_alpha,
            recommended_rank=recommended_rank,
            signal_count=signal_count,
            noise_floor=noise_floor,
        )

    def _compute_effective_rank(self, eigenvalues: np.ndarray) -> float:
        """Compute effective rank (participation ratio)."""
        eigenvalues = np.abs(eigenvalues)
        total = np.sum(eigenvalues)
        total_sq = np.sum(eigenvalues ** 2)

        if total_sq < 1e-10:
            return 1.0

        return (total ** 2) / total_sq

    def compute_quality_alpha(self, eigenvalues: np.ndarray, gamma: float = 1.0) -> float:
        """Compute quality metric α from spectral analysis."""
        result = self.analyze(eigenvalues, gamma)
        return result.quality_alpha

    def get_rank_recommendation(
        self,
        eigenvalues: np.ndarray,
        gamma: float = 1.0,
        current_rank: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Get rank recommendation based on spectral analysis."""
        result = self.analyze(eigenvalues, gamma)

        recommendation = {
            'recommended_rank': result.recommended_rank,
            'quality_alpha': result.quality_alpha,
            'signal_count': result.signal_count,
            'snr': result.snr,
            'snr_db': result.snr_db,
        }

        if current_rank is not None:
            if result.recommended_rank > current_rank:
                recommendation['action'] = 'increase'
                recommendation['reason'] = f'Quality α={result.quality_alpha:.3f} supports higher rank'
            elif result.recommended_rank < current_rank:
                recommendation['action'] = 'decrease'
                recommendation['reason'] = f'Quality α={result.quality_alpha:.3f} suggests lower rank'
            else:
                recommendation['action'] = 'maintain'
                recommendation['reason'] = f'Current rank appropriate for α={result.quality_alpha:.3f}'

        return recommendation


# =============================================================================
# Convenience Functions
# =============================================================================

def quick_spectral_analysis(
    matrix: np.ndarray,
    gamma: Optional[float] = None,
) -> SNRAnalysisResult:
    """
    Quick spectral analysis of a matrix.

    Args:
        matrix: Input numpy array [B, L, D] or [L, D] or [D, D]
        gamma: Aspect ratio (computed if None)

    Returns:
        SNR analysis result
    """
    tracker = EigenvalueTracker()
    snapshot = tracker.update(matrix)

    # Compute gamma if not provided
    if gamma is None:
        if len(matrix.shape) == 3:
            n = matrix.shape[0] * matrix.shape[1]
            p = matrix.shape[2]
        elif len(matrix.shape) == 2:
            n, p = matrix.shape
        else:
            n = p = matrix.shape[0]
        gamma = n / max(p, 1)

    analyzer = SignalNoiseAnalyzer()
    return analyzer.analyze(snapshot.eigenvalues, gamma)


def estimate_quality_from_matrix(matrix: np.ndarray) -> float:
    """
    Estimate quality α from a numpy matrix.

    Args:
        matrix: [B, L, D] or [L, D] matrix

    Returns:
        Quality metric α
    """
    result = quick_spectral_analysis(matrix)
    return result.quality_alpha


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Data structures
    'EigenvalueSnapshot',
    'MPValidationResult',
    'SNRAnalysisResult',

    # MP law functions
    'compute_mp_bounds',
    'mp_density',

    # Classes
    'EigenvalueTracker',
    'MarchenkoPasturValidator',
    'SignalNoiseAnalyzer',

    # Convenience functions
    'quick_spectral_analysis',
    'estimate_quality_from_matrix',
]
