"""
RSN-First Monitoring Pattern
============================

Implements the RSN-First monitoring pipeline discovered in expS4_000:
- RSN detects anomalies at Step 1 (MOST SENSITIVE)
- Geometric signals cross threshold at Step 30
- RSN leads geometric signals by 29 steps

Architecture rationale:
    RSN → DETECTION (sensitive, "when is something wrong?")
    Theta → CLASSIFICATION (interpretable, "what type of problem?")
    Scale → SEVERITY (magnitude, "how severe?")

The key insight is that RSN divergence from baseline is the most sensitive
signal for detecting distribution drift. Geometric signals (theta, radius)
are better for classifying the TYPE of problem after RSN flags it.

Usage:
    from yrsn.core.decomposition.rsn_first_monitor import (
        RSNFirstMonitor,
        compute_rsn_divergence,
    )

    # Create monitor with calibrated threshold (0.1 gives Step 1 detection)
    monitor = RSNFirstMonitor(divergence_threshold=0.1)

    # Set baseline from healthy model state
    monitor.set_baseline(R=0.624, S=0.376, N=0.000)

    # Monitor each inference
    result = monitor.check(
        R=0.45, S=0.35, N=0.20,
        theta=-15.0,  # Optional: for type classification
        scale=0.8,    # Optional: for severity
    )

    if result.is_alert:
        print(f"ALERT: {result.collapse_type}, severity={result.severity}")

Reference:
    docs/CRITICAL_DISCOVERY_RSN_SENSITIVITY.md
    docs/ARCHITECTURE_RSN_FIRST_PATTERN.md
    series_004/proofs/expS4_000_theta_collapse_validation_PROOF.md
"""

from dataclasses import dataclass, field
from typing import Tuple, Dict, Any, Optional, Deque, List
from collections import deque
import time
import numpy as np

from yrsn.core.decomposition.collapse import CollapseType
from yrsn.core.decomposition.collapse import (
    classify_geometric_domain,
    classify_severity,
    GeometricDomain,
    Severity,
)


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class RSNBaseline:
    """
    Healthy RSN baseline for divergence computation.

    The baseline represents the "healthy" or "expected" RSN distribution
    from which divergence is measured. Should be set from a known-good
    model state (e.g., validation set performance).

    Attributes:
        R: Baseline Relevant component value
        S: Baseline Superfluous component value
        N: Baseline Noise component value
        timestamp: When baseline was set
        sample_count: Number of samples used to compute baseline
    """
    R: float
    S: float
    N: float
    timestamp: float = field(default_factory=time.time)
    sample_count: int = 1

    def as_tuple(self) -> Tuple[float, float, float]:
        """Return baseline as (R, S, N) tuple."""
        return (self.R, self.S, self.N)


@dataclass
class RSNAlert:
    """
    Alert from RSN-First monitoring.

    Contains the divergence measurement and, if alert triggered,
    the classified type and severity.

    Attributes:
        divergence: RSN divergence from baseline (L1 norm)
        threshold: Alert threshold (default 0.1)
        collapse_type: Classified collapse type (if theta provided and alert)
        severity: Classified severity (if scale provided and alert)
        geometric_domain: Geometric domain classification (if theta provided)
        timestamp: When this alert was generated
    """
    divergence: float
    threshold: float
    collapse_type: Optional[CollapseType] = None
    severity: Optional[Severity] = None
    geometric_domain: Optional[GeometricDomain] = None
    timestamp: float = field(default_factory=time.time)

    @property
    def is_alert(self) -> bool:
        """True if divergence exceeds threshold."""
        return self.divergence > self.threshold

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'divergence': self.divergence,
            'threshold': self.threshold,
            'is_alert': self.is_alert,
            'collapse_type': self.collapse_type.value if self.collapse_type else None,
            'severity': self.severity.value if self.severity else None,
            'geometric_domain': self.geometric_domain.value if self.geometric_domain else None,
            'timestamp': self.timestamp,
        }


# =============================================================================
# Core Functions
# =============================================================================


def compute_rsn_divergence(
    current: Tuple[float, float, float],
    baseline: Tuple[float, float, float],
) -> float:
    """
    Compute RSN divergence from baseline.

    Uses L1 norm (sum of absolute differences) which gives good sensitivity
    for drift detection. Calibrated threshold of 0.1 detects drift at Step 1
    in expS4_000 experiments.

    This is the MOST SENSITIVE drift signal - 29 steps faster than geometric
    signals (theta, radius).

    Args:
        current: (R, S, N) current RSN values
        baseline: (R, S, N) baseline RSN values

    Returns:
        divergence: Sum of absolute differences

    Example:
        >>> compute_rsn_divergence((0.5, 0.3, 0.2), (0.6, 0.3, 0.1))
        0.2  # |0.5-0.6| + |0.3-0.3| + |0.2-0.1| = 0.1 + 0 + 0.1
    """
    r, s, n = current
    r0, s0, n0 = baseline
    return abs(r - r0) + abs(s - s0) + abs(n - n0)


def detect_rsn_drift(
    current: Tuple[float, float, float],
    baseline: Tuple[float, float, float],
    threshold: float = 0.1,
) -> bool:
    """
    Simple drift detection using RSN divergence.

    Args:
        current: (R, S, N) current RSN values
        baseline: (R, S, N) baseline RSN values
        threshold: Divergence threshold (default 0.1, calibrated for Step 1 detection)

    Returns:
        True if divergence exceeds threshold (drift detected)
    """
    return compute_rsn_divergence(current, baseline) > threshold


# =============================================================================
# RSNFirstMonitor Class
# =============================================================================


class RSNFirstMonitor:
    """
    RSN-First monitoring pipeline.

    Implements the key finding from expS4_000: RSN is 29 steps more sensitive
    than geometric signals for drift detection.

    Pipeline order:
        1. RSN divergence check (SENSITIVE - primary alarm, Step 1 detection)
        2. Theta classification (INTERPRETABLE - what TYPE of problem)
        3. Scale severity (MAGNITUDE - how severe)

    The critical insight is that theta classification only happens AFTER
    RSN triggers an alert. This matches the finding: RSN detects drift first,
    then theta explains what type of drift.

    Attributes:
        divergence_threshold: Alert threshold (default 0.1)
        baseline: RSN baseline (must be set before monitoring)
        history: Recent alert history
    """

    def __init__(
        self,
        divergence_threshold: float = 0.1,
        history_size: int = 100,
    ):
        """
        Initialize RSN-First monitor.

        Args:
            divergence_threshold: Alert threshold for RSN divergence.
                Calibrated value of 0.1 gives Step 1 detection in expS4_000.
            history_size: Maximum alerts to keep in history.
        """
        self.divergence_threshold = divergence_threshold
        self.baseline: Optional[RSNBaseline] = None
        self.history: Deque[RSNAlert] = deque(maxlen=history_size)

    def set_baseline(
        self,
        R: float,
        S: float,
        N: float,
        sample_count: int = 1,
    ) -> None:
        """
        Set RSN baseline from healthy state.

        Should be called with RSN values from a known-good model state,
        typically computed on a validation set.

        Args:
            R: Baseline Relevant component
            S: Baseline Superfluous component
            N: Baseline Noise component
            sample_count: Number of samples used to compute baseline
        """
        self.baseline = RSNBaseline(
            R=R, S=S, N=N,
            sample_count=sample_count,
        )

    def set_baseline_from_batch(
        self,
        R_batch: np.ndarray,
        S_batch: np.ndarray,
        N_batch: np.ndarray,
    ) -> None:
        """
        Set baseline from batch of healthy samples.

        Uses mean of batch as baseline. Useful when you have multiple
        samples from a healthy model state.

        Args:
            R_batch: Array of R values from healthy samples
            S_batch: Array of S values from healthy samples
            N_batch: Array of N values from healthy samples
        """
        self.baseline = RSNBaseline(
            R=float(np.mean(R_batch)),
            S=float(np.mean(S_batch)),
            N=float(np.mean(N_batch)),
            sample_count=len(R_batch),
        )

    def check(
        self,
        R: float,
        S: float,
        N: float,
        theta: Optional[float] = None,
        scale: Optional[float] = None,
        correlation: Optional[float] = None,
    ) -> RSNAlert:
        """
        RSN-First monitoring check.

        Order of operations:
            1. RSN divergence check (SENSITIVE - primary alarm)
            2. If RSN triggered, use theta for type classification
            3. If RSN triggered, use scale for severity assessment

        This order matches the expS4_000 finding: RSN detects drift 29 steps
        before geometric signals. Theta classification only happens AFTER
        RSN flags an issue.

        Args:
            R: Current Relevant component value
            S: Current Superfluous component value
            N: Current Noise component value
            theta: Optional sample_theta for type classification (degrees)
            scale: Optional scale for severity assessment
            correlation: Optional N-error correlation for severity

        Returns:
            RSNAlert with divergence, type (if alert), and severity (if alert)
        """
        # ===========================================================
        # STEP 0: Handle no baseline
        # ===========================================================
        if self.baseline is None:
            alert = RSNAlert(
                divergence=0.0,
                threshold=self.divergence_threshold,
            )
            self.history.append(alert)
            return alert

        # ===========================================================
        # STEP 1: RSN DIVERGENCE (Primary Sensitivity Channel)
        # ===========================================================
        # This is 29 steps faster than geometric signals!
        current_rsn = (R, S, N)
        baseline_rsn = self.baseline.as_tuple()
        divergence = compute_rsn_divergence(current_rsn, baseline_rsn)

        alert = RSNAlert(
            divergence=divergence,
            threshold=self.divergence_threshold,
        )

        # ===========================================================
        # STEP 2: THETA CLASSIFICATION (Interpretability Channel)
        # ===========================================================
        # Only meaningful AFTER RSN flags an issue
        if alert.is_alert and theta is not None:
            # Classify geometric domain
            alert.geometric_domain = classify_geometric_domain(theta)

            # Map extreme theta values to specific collapse types
            # Based on expS4_000 findings:
            # - O_POISONING: theta ~ -71° (dramatically negative)
            # - HALLUCINATION: theta ~ +64° (high positive)
            # - RSN_COLLAPSE: theta ~ +48° (moderate positive, specific range)
            if theta < -50:
                alert.collapse_type = CollapseType.O_POISONING
            elif theta > 60:
                alert.collapse_type = CollapseType.HALLUCINATION
            elif 45 < theta < 52:
                alert.collapse_type = CollapseType.RSN_COLLAPSE
            # Other types require more context (R/S/N patterns) for classification

        # ===========================================================
        # STEP 3: SCALE SEVERITY (Magnitude Channel)
        # ===========================================================
        # Only meaningful AFTER RSN flags an issue
        if alert.is_alert and scale is not None:
            alert.severity = classify_severity(scale, correlation)

        self.history.append(alert)
        return alert

    def get_alert_rate(self, window: Optional[int] = None) -> float:
        """
        Get alert rate over recent history.

        Args:
            window: Number of recent alerts to consider.
                If None, uses entire history.

        Returns:
            Fraction of alerts that triggered (0.0 to 1.0)
        """
        if len(self.history) == 0:
            return 0.0

        if window is None:
            alerts = list(self.history)
        else:
            alerts = list(self.history)[-window:]

        if len(alerts) == 0:
            return 0.0

        return sum(1 for a in alerts if a.is_alert) / len(alerts)

    def get_mean_divergence(self, window: Optional[int] = None) -> float:
        """
        Get mean divergence over recent history.

        Args:
            window: Number of recent alerts to consider.
                If None, uses entire history.

        Returns:
            Mean divergence value
        """
        if len(self.history) == 0:
            return 0.0

        if window is None:
            alerts = list(self.history)
        else:
            alerts = list(self.history)[-window:]

        if len(alerts) == 0:
            return 0.0

        return float(np.mean([a.divergence for a in alerts]))

    def get_collapse_type_distribution(
        self,
        window: Optional[int] = None,
    ) -> Dict[str, int]:
        """
        Get distribution of collapse types in alert history.

        Args:
            window: Number of recent alerts to consider.

        Returns:
            Dictionary mapping collapse type name to count
        """
        if window is None:
            alerts = list(self.history)
        else:
            alerts = list(self.history)[-window:]

        distribution: Dict[str, int] = {}
        for alert in alerts:
            if alert.is_alert and alert.collapse_type is not None:
                type_name = alert.collapse_type.value
                distribution[type_name] = distribution.get(type_name, 0) + 1

        return distribution

    def reset_history(self) -> None:
        """Clear alert history."""
        self.history.clear()

    def reset_baseline(self) -> None:
        """Clear baseline (will require set_baseline before monitoring)."""
        self.baseline = None
