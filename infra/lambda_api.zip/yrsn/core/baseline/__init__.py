"""
Baseline Registry for Context Quality ISA (CQ-ISA™) - OP08: BASELINE_GET.

This module provides baseline fingerprint storage and retrieval for drift detection.
Implements hex architecture with pluggable storage backends.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.8: Environmental Validation Context
  - §7.8.5: Baseline References (baseline storage, retrieval, compatibility checking)
- §7.7: Fingerprint Embedding
  - Storage of higher-dimensional fingerprints (32-byte T⁴ fingerprints)

Key features:
- Baseline externality (ISA principle: baselines from external store)
- Write-once, read-many semantics
- Version management and metadata tracking
- Pluggable storage backends (hex architecture)

ISA Integration:
- OP08: BASELINE_GET - Auditable baseline retrieval

Relevant patent files:
- docs/specs/patent_spec_section_7_8_environmental_context.md
- docs/specs/patent_spec_section_7_7_fingerprint_embedding.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

Design Principles:
    - Hex Architecture: Core domain + pluggable adapters
    - Storage Backend Agnostic: In-memory, file, database
    - Baseline Externality: Baselines always from external store (ISA principle)
    - Immutable Fingerprints: Baselines are write-once, read-many
    - Version Management: Track baseline versions and metadata

Usage:
    from yrsn.core.baseline import BaselineRegistry, InMemoryBaselineStore

    # Create registry with in-memory store
    store = InMemoryBaselineStore()
    registry = BaselineRegistry(store)

    # Store baseline fingerprint
    registry.store_baseline(
        baseline_id="production_v1",
        fingerprint=fp_bytes,
        metadata={'version': '1.0', 'timestamp': '2025-01-26'}
    )

    # Retrieve baseline (OP08: BASELINE_GET)
    fp = registry.get_baseline("production_v1")

Spec: docs/api/specifications/CONTEXT_QUALITY_ISA_v0.1.md OP08
"""

from dataclasses import dataclass, field
from typing import Dict, Optional, List, Protocol
from datetime import datetime
import json
from pathlib import Path


# =============================================================================
# BASELINE METADATA
# =============================================================================

@dataclass
class BaselineMetadata:
    """
    Metadata for baseline fingerprint.

    Attributes:
        baseline_id: Unique baseline identifier
        fingerprint: 32-byte T⁴ fingerprint
        created_at: Creation timestamp
        version: Baseline version (e.g., "1.0", "production")
        description: Human-readable description
        tags: Tags for categorization (e.g., ["production", "2025-Q1"])
        checksum: SHA256 checksum of fingerprint (for integrity)
    """
    baseline_id: str
    fingerprint: bytes
    created_at: datetime
    version: str = "1.0"
    description: str = ""
    tags: List[str] = field(default_factory=list)
    checksum: Optional[str] = None

    def __post_init__(self):
        """Compute checksum if not provided."""
        if self.checksum is None:
            import hashlib
            self.checksum = hashlib.sha256(self.fingerprint).hexdigest()

    def to_dict(self) -> Dict:
        """Serialize to JSON-compatible dict."""
        return {
            'baseline_id': self.baseline_id,
            'fingerprint': self.fingerprint.hex(),
            'created_at': self.created_at.isoformat(),
            'version': self.version,
            'description': self.description,
            'tags': self.tags,
            'checksum': self.checksum,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "BaselineMetadata":
        """Deserialize from dict."""
        return cls(
            baseline_id=data['baseline_id'],
            fingerprint=bytes.fromhex(data['fingerprint']),
            created_at=datetime.fromisoformat(data['created_at']),
            version=data.get('version', '1.0'),
            description=data.get('description', ''),
            tags=data.get('tags', []),
            checksum=data.get('checksum'),
        )


# =============================================================================
# BASELINE STORE PROTOCOL (Hex: Port)
# =============================================================================

class BaselineStore(Protocol):
    """
    Protocol for baseline storage backend (hex architecture port).

    Implementations can use:
    - In-memory dict (testing, development)
    - File system (simple persistence)
    - SQLite (structured storage)
    - S3/Cloud Storage (production)
    - Redis (distributed cache)
    """

    def store(self, metadata: BaselineMetadata) -> None:
        """Store baseline fingerprint with metadata."""
        ...

    def retrieve(self, baseline_id: str) -> Optional[BaselineMetadata]:
        """Retrieve baseline fingerprint by ID."""
        ...

    def list_baselines(self, tags: Optional[List[str]] = None) -> List[str]:
        """List baseline IDs, optionally filtered by tags."""
        ...

    def delete(self, baseline_id: str) -> bool:
        """Delete baseline (returns True if existed)."""
        ...

    def exists(self, baseline_id: str) -> bool:
        """Check if baseline exists."""
        ...


# =============================================================================
# IN-MEMORY STORE (Hex: Adapter)
# =============================================================================

class InMemoryBaselineStore:
    """
    In-memory baseline store (for testing and development).

    NOT recommended for production (data lost on restart).
    Use FileBaselineStore or database-backed store in production.
    """

    def __init__(self):
        self._baselines: Dict[str, BaselineMetadata] = {}

    def store(self, metadata: BaselineMetadata) -> None:
        """Store baseline in memory."""
        self._baselines[metadata.baseline_id] = metadata

    def retrieve(self, baseline_id: str) -> Optional[BaselineMetadata]:
        """Retrieve baseline from memory."""
        return self._baselines.get(baseline_id)

    def list_baselines(self, tags: Optional[List[str]] = None) -> List[str]:
        """List baseline IDs, optionally filtered by tags."""
        if tags is None:
            return list(self._baselines.keys())

        # Filter by tags
        return [
            baseline_id
            for baseline_id, metadata in self._baselines.items()
            if any(tag in metadata.tags for tag in tags)
        ]

    def delete(self, baseline_id: str) -> bool:
        """Delete baseline from memory."""
        if baseline_id in self._baselines:
            del self._baselines[baseline_id]
            return True
        return False

    def exists(self, baseline_id: str) -> bool:
        """Check if baseline exists in memory."""
        return baseline_id in self._baselines

    def clear(self) -> None:
        """Clear all baselines (for testing)."""
        self._baselines.clear()


# =============================================================================
# FILE STORE (Hex: Adapter)
# =============================================================================

class FileBaselineStore:
    """
    File-based baseline store (simple persistence).

    Stores baselines as JSON files in directory:
        baselines/
        ├── production_v1.json
        ├── staging_v2.json
        └── ...

    Suitable for:
    - Small to medium deployments
    - Local development
    - Simple persistence needs
    """

    def __init__(self, baselines_dir: Path):
        """
        Initialize file store.

        Args:
            baselines_dir: Directory to store baseline files
        """
        self.baselines_dir = Path(baselines_dir)
        self.baselines_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, baseline_id: str) -> Path:
        """Get file path for baseline ID."""
        # Sanitize baseline_id for filesystem
        safe_id = baseline_id.replace('/', '_').replace('\\', '_')
        return self.baselines_dir / f"{safe_id}.json"

    def store(self, metadata: BaselineMetadata) -> None:
        """Store baseline to file."""
        path = self._get_path(metadata.baseline_id)
        with open(path, 'w') as f:
            json.dump(metadata.to_dict(), f, indent=2)

    def retrieve(self, baseline_id: str) -> Optional[BaselineMetadata]:
        """Retrieve baseline from file."""
        path = self._get_path(baseline_id)
        if not path.exists():
            return None

        with open(path, 'r') as f:
            data = json.load(f)
            return BaselineMetadata.from_dict(data)

    def list_baselines(self, tags: Optional[List[str]] = None) -> List[str]:
        """List baseline IDs from directory."""
        baseline_ids = []

        for path in self.baselines_dir.glob("*.json"):
            baseline_id = path.stem

            # Filter by tags if provided
            if tags is not None:
                metadata = self.retrieve(baseline_id)
                if metadata and any(tag in metadata.tags for tag in tags):
                    baseline_ids.append(baseline_id)
            else:
                baseline_ids.append(baseline_id)

        return baseline_ids

    def delete(self, baseline_id: str) -> bool:
        """Delete baseline file."""
        path = self._get_path(baseline_id)
        if path.exists():
            path.unlink()
            return True
        return False

    def exists(self, baseline_id: str) -> bool:
        """Check if baseline file exists."""
        return self._get_path(baseline_id).exists()


# =============================================================================
# BASELINE REGISTRY (Hex: Core Domain)
# =============================================================================

class BaselineRegistry:
    """
    Baseline registry for Context Quality ISA (CQ-ISA™) - OP08: BASELINE_GET.

    Hex Architecture: CORE DOMAIN
    - Defines WHAT baseline management is (not HOW it's stored)
    - Pluggable storage backends (in-memory, file, database)
    - Enforces baseline immutability and version management

    Example:
        >>> store = InMemoryBaselineStore()
        >>> registry = BaselineRegistry(store)
        >>> registry.store_baseline("prod_v1", fp_bytes)
        >>> fp = registry.get_baseline("prod_v1")
    """

    def __init__(self, store: BaselineStore):
        """
        Initialize baseline registry.

        Args:
            store: Storage backend implementation
        """
        self.store = store

    def store_baseline(
        self,
        baseline_id: str,
        fingerprint: bytes,
        version: str = "1.0",
        description: str = "",
        tags: Optional[List[str]] = None,
    ) -> BaselineMetadata:
        """
        Store baseline fingerprint (write-once).

        Args:
            baseline_id: Unique baseline identifier
            fingerprint: 32-byte T⁴ fingerprint
            version: Baseline version
            description: Human-readable description
            tags: Tags for categorization

        Returns:
            BaselineMetadata

        Raises:
            ValueError: If fingerprint is not 32 bytes
            KeyError: If baseline_id already exists (immutability)
        """
        # Validate fingerprint
        if len(fingerprint) != 32:
            raise ValueError(f"Fingerprint must be 32 bytes, got {len(fingerprint)}")

        # Check for existing baseline (immutability)
        if self.store.exists(baseline_id):
            raise KeyError(f"Baseline '{baseline_id}' already exists (baselines are immutable)")

        # Create metadata
        metadata = BaselineMetadata(
            baseline_id=baseline_id,
            fingerprint=fingerprint,
            created_at=datetime.now(),
            version=version,
            description=description,
            tags=tags or [],
        )

        # Store
        self.store.store(metadata)

        return metadata

    def get_baseline(self, baseline_id: str) -> bytes:
        """
        Retrieve baseline fingerprint (OP08: BASELINE_GET).

        Args:
            baseline_id: Baseline identifier

        Returns:
            32-byte fingerprint

        Raises:
            KeyError: If baseline not found
        """
        metadata = self.store.retrieve(baseline_id)
        if metadata is None:
            raise KeyError(f"Baseline '{baseline_id}' not found")

        return metadata.fingerprint

    def get_baseline_metadata(self, baseline_id: str) -> BaselineMetadata:
        """
        Retrieve baseline metadata (fingerprint + metadata).

        Args:
            baseline_id: Baseline identifier

        Returns:
            BaselineMetadata

        Raises:
            KeyError: If baseline not found
        """
        metadata = self.store.retrieve(baseline_id)
        if metadata is None:
            raise KeyError(f"Baseline '{baseline_id}' not found")

        return metadata

    def list_baselines(self, tags: Optional[List[str]] = None) -> List[str]:
        """
        List baseline IDs, optionally filtered by tags.

        Args:
            tags: Optional tags to filter by

        Returns:
            List of baseline IDs
        """
        return self.store.list_baselines(tags=tags)

    def delete_baseline(self, baseline_id: str) -> bool:
        """
        Delete baseline (use with caution).

        Note: Baselines should be immutable in production.
        Only use delete for cleanup or testing.

        Args:
            baseline_id: Baseline identifier

        Returns:
            True if baseline existed and was deleted
        """
        return self.store.delete(baseline_id)

    def baseline_exists(self, baseline_id: str) -> bool:
        """
        Check if baseline exists.

        Args:
            baseline_id: Baseline identifier

        Returns:
            True if baseline exists
        """
        return self.store.exists(baseline_id)


__all__ = [
    'BaselineMetadata',
    'BaselineStore',
    'BaselineRegistry',
    'InMemoryBaselineStore',
    'FileBaselineStore',
]
