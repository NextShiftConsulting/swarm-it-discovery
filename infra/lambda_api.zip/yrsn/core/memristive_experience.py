"""
MemristiveExperienceLayer - Temperature-coupled adaptive memory for YRSN.

This module provides a unified interface for experience-based learning
that uses AdaptiveTemperatureConfig to couple temperature (τ) with:
- Learning rate (high τ → more plasticity)
- Decision thresholds (high τ → more conservative)
- Memory protection (low τ → stronger EWC)

The layer can be used standalone or as the backend for IARS's IMemoryProvider.

Architecture (3 distinct problems unified):
    YRSN (Context Engineering) → AdaptiveTemperatureConfig
                                        ↓
    Temperature τ = f(α) ───────┬───────────────────┐
                               ↓                   ↓
    Memristor Layer ←── learning_rate ──→ Decision Thresholds
    (memory IS computation)              (routing streams)

Author: YRSN Framework (Rudy Martin)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Tuple
from enum import Enum
import numpy as np

from .adaptive_config import (
    AdaptiveTemperatureConfig,
    ActivationMode,
    TemperatureMode,
    QualityPhase,
    Stream,
    CollapseType,
    TemperatureResult,
    production_config,
)


# =============================================================================
# EXPERIENCE TYPES
# =============================================================================

@dataclass
class Experience:
    """A single learning experience."""
    context: np.ndarray           # Encoded context vector
    R: float                      # Quality score
    S: float                      # Superfluous score
    N: float                      # Noise score
    category: str                 # Request category
    amount: float                 # Request amount
    predicted_stream: Stream      # What was predicted
    actual_stream: Stream         # What actually happened
    was_override: bool            # Human changed the decision
    temperature: float            # τ at prediction time
    reward: float                 # Learning signal (-1 to 1)
    timestamp: float = 0.0        # For replay prioritization
    priority: float = 1.0         # Replay priority


@dataclass
class MemoryPrediction:
    """Result of querying the experience layer."""
    stream: Stream
    confidence: float
    label_probabilities: Dict[str, float]
    temperature_result: TemperatureResult
    phase: QualityPhase
    margin: float                 # Gap between top two labels
    collapse_type: CollapseType
    collapse_risk: float
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# ABSTRACT MEMORY PORT (for dependency injection)
# =============================================================================

class IExperienceMemory(ABC):
    """
    Interface for experience memory implementations.

    This allows swapping between:
    - In-memory replay buffer (fast, ephemeral)
    - Memristor array (persistent, hardware-like)
    - External storage (database, distributed)
    """

    @abstractmethod
    def store(self, experience: Experience) -> None:
        """Store an experience."""
        ...

    @abstractmethod
    def retrieve_similar(
        self,
        context: np.ndarray,
        k: int = 10
    ) -> List[Tuple[Experience, float]]:
        """Retrieve k most similar experiences with similarity scores."""
        ...

    @abstractmethod
    def sample_batch(self, batch_size: int) -> List[Experience]:
        """Sample a batch for replay learning."""
        ...

    @abstractmethod
    def update_priorities(self, experiences: List[Experience], td_errors: List[float]) -> None:
        """Update replay priorities based on TD errors."""
        ...

    @abstractmethod
    def consolidate(self, task_id: str) -> None:
        """Consolidate current experiences into protected memory."""
        ...


# =============================================================================
# IN-MEMORY EXPERIENCE BUFFER
# =============================================================================

class InMemoryExperienceBuffer(IExperienceMemory):
    """Simple in-memory experience buffer with prioritized replay."""

    def __init__(self, capacity: int = 10000, alpha: float = 0.6):
        self.capacity = capacity
        self.alpha = alpha  # Priority exponent
        self.experiences: List[Experience] = []
        self.priorities: np.ndarray = np.zeros(capacity)
        self._position = 0
        self._max_priority = 1.0

    def store(self, experience: Experience) -> None:
        experience.priority = self._max_priority

        if len(self.experiences) < self.capacity:
            self.experiences.append(experience)
            self.priorities[len(self.experiences) - 1] = self._max_priority
        else:
            self.experiences[self._position] = experience
            self.priorities[self._position] = self._max_priority

        self._position = (self._position + 1) % self.capacity

    def retrieve_similar(
        self,
        context: np.ndarray,
        k: int = 10
    ) -> List[Tuple[Experience, float]]:
        if not self.experiences:
            return []

        # Compute cosine similarities
        similarities = []
        for exp in self.experiences:
            sim = np.dot(context, exp.context) / (
                np.linalg.norm(context) * np.linalg.norm(exp.context) + 1e-8
            )
            similarities.append((exp, float(sim)))

        # Sort by similarity
        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:k]

    def sample_batch(self, batch_size: int) -> List[Experience]:
        if len(self.experiences) < batch_size:
            return self.experiences.copy()

        # Prioritized sampling
        n = len(self.experiences)
        priorities = self.priorities[:n] ** self.alpha
        probs = priorities / priorities.sum()

        indices = np.random.choice(n, size=batch_size, replace=False, p=probs)
        return [self.experiences[i] for i in indices]

    def update_priorities(self, experiences: List[Experience], td_errors: List[float]) -> None:
        for exp, td in zip(experiences, td_errors):
            try:
                idx = self.experiences.index(exp)
                priority = abs(td) + 1e-6
                self.priorities[idx] = priority
                self._max_priority = max(self._max_priority, priority)
            except ValueError:
                pass  # Experience not found (may have been evicted)

    def consolidate(self, task_id: str) -> None:
        # Boost priorities for recent experiences
        n = len(self.experiences)
        for i in range(n):
            self.priorities[i] *= 1.1  # Small boost


# =============================================================================
# MEMRISTIVE EXPERIENCE LAYER
# =============================================================================

class MemristiveExperienceLayer:
    """
    Temperature-coupled experience layer using AdaptiveTemperatureConfig.

    This is the integration point between:
    - YRSN context quality (R, S, N)
    - Temperature-quality duality (τ = f(α))
    - Memristive learning (τ modulates plasticity)

    Usage:
        config = production_config()
        layer = MemristiveExperienceLayer(config)

        # Predict routing based on experience
        prediction = layer.predict(R=0.8, S=0.1, N=0.1, category="travel")

        # Learn from outcome
        layer.record_outcome(
            R=0.8, S=0.1, N=0.1, category="travel",
            predicted=Stream.GREEN, actual=Stream.YELLOW,
            was_override=True
        )
    """

    def __init__(
        self,
        config: Optional[AdaptiveTemperatureConfig] = None,
        memory: Optional[IExperienceMemory] = None,
        context_dim: int = 256
    ):
        self.config = config or production_config()
        self.memory = memory or InMemoryExperienceBuffer()
        self.context_dim = context_dim

        # Statistics
        self.total_predictions = 0
        self.correct_predictions = 0
        self._step = 0

        # Category codebook for encoding
        self._category_vectors: Dict[str, np.ndarray] = {}
        self._rng = np.random.RandomState(42)

    def _encode_context(
        self,
        R: float,
        S: float,
        N: float,
        category: str,
        amount: float = 0.0
    ) -> np.ndarray:
        """
        Encode context into a high-dimensional vector.

        Uses thermometer encoding for ordinal values (R, S, N, amount)
        and random vectors for categorical (category).
        """
        dim = self.context_dim

        # Allocate dimensions
        r_dims = dim // 2          # 50% for R (most important)
        cat_dims = dim // 4        # 25% for category
        other_dims = dim - r_dims - cat_dims  # 25% for S, N, amount

        # Thermometer encode R
        r_vec = self._thermometer_encode(R, r_dims)

        # Random vector for category (stable per category)
        if category not in self._category_vectors:
            self._category_vectors[category] = self._rng.randn(cat_dims)
        cat_vec = self._category_vectors[category]

        # Thermometer encode S, N, amount
        s_dims = other_dims // 3
        n_dims = other_dims // 3
        amt_dims = other_dims - s_dims - n_dims

        s_vec = self._thermometer_encode(S, s_dims)
        n_vec = self._thermometer_encode(N, n_dims)
        amt_vec = self._thermometer_encode(
            np.clip(np.log10(max(amount, 1)) / 6, 0, 1),
            amt_dims
        )

        # Concatenate
        vec = np.concatenate([r_vec, cat_vec, s_vec, n_vec, amt_vec])

        # Pad/truncate to exact dim
        if len(vec) < dim:
            vec = np.concatenate([vec, np.zeros(dim - len(vec))])
        elif len(vec) > dim:
            vec = vec[:dim]

        return vec.astype(np.float32)

    def _thermometer_encode(self, value: float, dim: int) -> np.ndarray:
        """Thermometer encoding: value → first k positions are 1."""
        value = np.clip(value, 0, 1)
        k = int(value * dim)
        vec = np.zeros(dim, dtype=np.float32)
        vec[:k] = 1.0
        return vec

    def predict(
        self,
        R: float,
        S: float,
        N: float,
        category: str = "default",
        amount: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None
    ) -> MemoryPrediction:
        """
        Predict routing based on learned experiences.

        Uses temperature-quality duality:
        - Compute τ from R using configured activation
        - Query similar experiences
        - Weight predictions by similarity and temperature
        - Apply phase-based decision logic
        """
        cfg = self.config

        # Compute temperature from quality
        tau = cfg.compute_tau(alpha=R)
        phase = cfg.get_phase(R)

        # Build temperature result
        temp_result = TemperatureResult(
            tau=tau,
            alpha=R,
            mode=cfg.mode,
            step=self._step
        )

        # Check for collapse
        collapse_type, collapse_risk = cfg.detect_collapse(R, S, N)

        # Encode context
        context = self._encode_context(R, S, N, category, amount)

        # Retrieve similar experiences
        similar = self.memory.retrieve_similar(context, k=10)

        if not similar:
            # No experience - use quality-based default
            stream = cfg.get_stream(confidence=0.5, R=R, N=N, tau=tau)
            return MemoryPrediction(
                stream=stream,
                confidence=0.5,
                label_probabilities={"GREEN": 0.33, "YELLOW": 0.34, "RED": 0.33},
                temperature_result=temp_result,
                phase=phase,
                margin=0.0,
                collapse_type=collapse_type,
                collapse_risk=collapse_risk,
                metadata={"source": "prior", "similar_found": 0}
            )

        # Aggregate predictions from similar experiences
        label_scores: Dict[str, float] = {"GREEN": 0.0, "YELLOW": 0.0, "RED": 0.0}
        total_weight = 0.0

        for exp, similarity in similar:
            # Weight by similarity and inverse temperature (sharper when τ low)
            weight = similarity * (1.0 / tau)
            label_scores[exp.actual_stream.value] += weight
            total_weight += weight

        # Normalize to probabilities
        if total_weight > 0:
            for label in label_scores:
                label_scores[label] /= total_weight

        # Apply softmax with temperature
        probs = cfg.softmax(label_scores, tau=tau)

        # Get best label and margin
        sorted_probs = sorted(probs.values(), reverse=True)
        best_label = max(probs, key=probs.get)
        confidence = probs[best_label]
        margin = sorted_probs[0] - sorted_probs[1] if len(sorted_probs) > 1 else 1.0

        # Apply phase-based routing
        stream = self._apply_phase_routing(
            label=best_label,
            confidence=confidence,
            margin=margin,
            phase=phase,
            tau=tau,
            collapse_type=collapse_type
        )

        self.total_predictions += 1
        self._step += 1

        return MemoryPrediction(
            stream=stream,
            confidence=confidence,
            label_probabilities=probs,
            temperature_result=temp_result,
            phase=phase,
            margin=margin,
            collapse_type=collapse_type,
            collapse_risk=collapse_risk,
            metadata={
                "source": "experience",
                "similar_found": len(similar),
                "best_similarity": similar[0][1] if similar else 0.0
            }
        )

    def _apply_phase_routing(
        self,
        label: str,
        confidence: float,
        margin: float,
        phase: QualityPhase,
        tau: float,
        collapse_type: CollapseType
    ) -> Stream:
        """
        Apply phase-based routing decision.

        Phase I (HIGH):   Trust memory directly
        Phase II (MEDIUM): Require margin
        Phase III (LOW):  Conservative - default RED
        """
        # Collapse override
        if collapse_type in [CollapseType.CONFLICT, CollapseType.POISONING]:
            return Stream.RED

        if phase == QualityPhase.HIGH:
            # High quality - trust the label
            return Stream(label.lower())

        elif phase == QualityPhase.MEDIUM:
            # Medium quality - require margin
            if margin > 0.05:
                return Stream(label.lower())
            return Stream.YELLOW

        else:
            # Low quality - conservative
            if label == "RED":
                return Stream.RED
            elif margin > 0.10:
                return Stream(label.lower())
            return Stream.RED

    def record_outcome(
        self,
        R: float,
        S: float,
        N: float,
        category: str,
        amount: float,
        predicted: Stream,
        actual: Stream,
        was_override: bool,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Learn from an outcome.

        Overrides are high-value learning signals - they indicate the
        memory system was wrong and should update.
        """
        cfg = self.config

        # Compute temperature
        tau = cfg.compute_tau(alpha=R)

        # Get learning rate from config (τ-coupled)
        learning_rate = cfg.get_memristor_learning_rate(tau)

        # Encode context
        context = self._encode_context(R, S, N, category, amount)

        # Compute reward
        if predicted == actual:
            reward = 1.0
            self.correct_predictions += 1
        elif was_override:
            reward = -1.0  # Strong negative signal for override
        elif (predicted == Stream.GREEN and actual == Stream.RED) or \
             (predicted == Stream.RED and actual == Stream.GREEN):
            reward = -0.8  # Opposite extremes
        else:
            reward = -0.2  # Adjacent categories

        # Create experience
        experience = Experience(
            context=context,
            R=R, S=S, N=N,
            category=category,
            amount=amount,
            predicted_stream=predicted,
            actual_stream=actual,
            was_override=was_override,
            temperature=tau,
            reward=reward,
            priority=abs(reward) + 1.0  # Higher priority for surprises
        )

        # Store in memory
        self.memory.store(experience)

        return {
            "learning_rate": learning_rate,
            "reward": reward,
            "temperature": tau,
            "was_override": was_override,
            "accuracy": self.correct_predictions / max(1, self.total_predictions)
        }

    def get_confidence_boost(
        self,
        R: float,
        S: float,
        N: float,
        category: str,
        amount: float = 0.0
    ) -> float:
        """
        Get confidence boost from similar successful experiences.

        Returns multiplier >= 1.0 based on similar past cases with good outcomes.
        """
        context = self._encode_context(R, S, N, category, amount)
        similar = self.memory.retrieve_similar(context, k=5)

        if not similar:
            return 1.0

        # Count successful similar cases (predicted == actual)
        successes = sum(
            1 for exp, sim in similar
            if exp.predicted_stream == exp.actual_stream and sim > 0.7
        )

        # Boost: 1.0 + 0.05 per successful similar case (max 1.25)
        return min(1.25, 1.0 + 0.05 * successes)

    def batch_learn(self, batch_size: int = 32) -> Dict[str, Any]:
        """
        Perform batch learning from experience replay.

        Uses temperature-modulated learning:
        - Sample experiences weighted by priority
        - Compute TD errors
        - Update priorities for future sampling
        """
        experiences = self.memory.sample_batch(batch_size)

        if not experiences:
            return {"learned": False}

        # Compute TD errors (simplified)
        td_errors = []
        for exp in experiences:
            # TD error = |reward - confidence|
            # (proxy for how surprising the outcome was)
            td = abs(exp.reward) * (2.0 if exp.was_override else 1.0)
            td_errors.append(td)

        # Update priorities
        self.memory.update_priorities(experiences, td_errors)

        return {
            "learned": True,
            "batch_size": len(experiences),
            "avg_td_error": float(np.mean(td_errors)),
            "override_count": sum(1 for e in experiences if e.was_override)
        }

    def consolidate(self, task_id: str = "current") -> None:
        """Consolidate current learning."""
        self.memory.consolidate(task_id)

    def get_statistics(self) -> Dict[str, Any]:
        """Get layer statistics."""
        return {
            "total_predictions": self.total_predictions,
            "correct_predictions": self.correct_predictions,
            "accuracy": self.correct_predictions / max(1, self.total_predictions),
            "step": self._step,
            "experience_count": len(self.memory.experiences)
            if hasattr(self.memory, 'experiences') else 0
        }


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_experience_layer(
    mode: str = "production",
    context_dim: int = 256,
    memory_capacity: int = 10000
) -> MemristiveExperienceLayer:
    """
    Create a MemristiveExperienceLayer with preset configuration.

    Parameters
    ----------
    mode : str
        "production", "learning", "shadow", or "conservative"
    context_dim : int
        Dimension of context vectors
    memory_capacity : int
        Maximum experiences to store

    Returns
    -------
    MemristiveExperienceLayer
        Configured experience layer
    """
    from .adaptive_config import (
        production_config,
        learning_config,
        shadow_config,
        conservative_config,
    )

    configs = {
        "production": production_config,
        "learning": learning_config,
        "shadow": shadow_config,
        "conservative": conservative_config,
    }

    config_fn = configs.get(mode, production_config)
    config = config_fn() if callable(config_fn) else production_config()

    memory = InMemoryExperienceBuffer(capacity=memory_capacity)

    return MemristiveExperienceLayer(
        config=config,
        memory=memory,
        context_dim=context_dim
    )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "Experience",
    "MemoryPrediction",
    "IExperienceMemory",
    "InMemoryExperienceBuffer",
    "MemristiveExperienceLayer",
    "create_experience_layer",
]
