"""Abstract base classes for context retrieval and processing."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from yrsn.core.types import ContextBlock


class ContextRetriever(ABC):
    """
    Abstract base class for context retrieval at different precision levels.

    Implementations should handle retrieval from various sources (vector DBs,
    search engines, knowledge bases, etc.) at different quality/speed tradeoffs.
    """

    @abstractmethod
    def retrieve(self, query: str, k: int = 5) -> List[ContextBlock]:
        """
        Retrieve context blocks relevant to the query.

        Args:
            query: The query string to retrieve context for
            k: Maximum number of context blocks to retrieve

        Returns:
            List of ContextBlock objects ordered by relevance
        """
        pass


class ContextProcessor(ABC):
    """
    Abstract base class for processing context blocks.

    Implementations handle operations like merging, filtering, ranking,
    and transforming context blocks.
    """

    @abstractmethod
    def process(
        self,
        context: List[ContextBlock],
        query: str,
        metadata: Dict[str, Any],
    ) -> List[ContextBlock]:
        """
        Process a list of context blocks.

        Args:
            context: List of context blocks to process
            query: The original query for context
            metadata: Additional metadata for processing

        Returns:
            Processed list of context blocks
        """
        pass


class LLMClient(ABC):
    """
    Abstract base class for LLM interactions.

    This abstraction allows the library to work with different LLM providers
    (OpenAI, Anthropic, local models, etc.) without tight coupling.
    """

    @abstractmethod
    def complete(self, prompt: str, **kwargs: Any) -> str:
        """
        Generate a completion for the given prompt.

        Args:
            prompt: The input prompt
            **kwargs: Additional provider-specific parameters

        Returns:
            The generated completion text
        """
        pass

    @abstractmethod
    def embed(self, text: str, **kwargs: Any) -> List[float]:
        """
        Generate an embedding vector for the given text.

        Args:
            text: The input text to embed
            **kwargs: Additional provider-specific parameters

        Returns:
            Embedding vector as list of floats
        """
        pass
