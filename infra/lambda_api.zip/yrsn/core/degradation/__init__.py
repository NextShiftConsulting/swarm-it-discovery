"""
Degradation diagnosis and classification.

This module implements the 9-grid decision matrix that combines:
- Layer 1 (α: content quality) from 6D YRSN block
- Layer 2 (κ: geometric compatibility) from RSCT block

See:
    docs/papers/gap_analysis/CONTROLLER_ARCHITECTURE_DIAGRAMS.md (Section 6)
"""

from yrsn.core.degradation.diagnosis import (
    DegradationType,
    QualityLevel,
    DiagnosisResult,
    DegradationDiagnoser,
)

__all__ = [
    "DegradationType",
    "QualityLevel",
    "DiagnosisResult",
    "DegradationDiagnoser",
]
