"""
Degradation Diagnosis - 9-Grid Decision Matrix

Implements the decision table from CONTROLLER_ARCHITECTURE_DIAGRAMS.md (Section 6).
Combines Layer 1 (α: content quality) and Layer 2 (κ: encoding-solver compatibility)
to diagnose degradation types and recommend actions.

Reference:
    docs/papers/gap_analysis/CONTROLLER_ARCHITECTURE_DIAGRAMS.md

Theory:
    α (alpha) = R/(R+S+N) - content quality [0,1]
    κ (kappa) = D*/D - geometric compatibility [0,1]
    σ (sigma) = instability estimate [0,1]

Decision Grid (3×3 = 9 scenarios when α, κ ∈ {HIGH, MED, LOW}):
    Full table below at line 100
"""

from dataclasses import dataclass
from enum import Enum, auto
from typing import Tuple, Optional
import numpy as np


class DegradationType(Enum):
    """Degradation types from RSCT theory."""
    NONE = auto()                  # No degradation (trust output)
    GEOMETRY_MISMATCH = auto()     # Content OK, solver can't use it
    CONTENT_DEGRADATION = auto()   # Interface works, input is bad
    TOTAL_FAILURE = auto()         # Nothing works
    UNSTABLE = auto()              # Metrics unreliable
    PARTIAL_MATCH = auto()         # Solver exploits some structure
    MILD_CONTENT_ISSUE = auto()    # Content slightly degraded
    MILD_GEOMETRY_ISSUE = auto()   # Encoding slightly mismatched
    BALANCED_DEGRADATION = auto()  # Both content and encoding degrade together
    UNKNOWN = auto()               # Cannot diagnose (κ not available)


class QualityLevel(Enum):
    """Quality classification levels."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class DiagnosisResult:
    """Result of degradation diagnosis."""
    degradation_type: DegradationType
    confidence: float  # [0, 1]
    recommended_action: str
    explanation: str

    # Measurements
    alpha: float
    kappa: float
    sigma: float
    alpha_level: QualityLevel
    kappa_level: QualityLevel


class DegradationDiagnoser:
    """
    9-Grid degradation diagnosis combining Layer 1 (α) and Layer 2 (κ).

    Thresholds (calibrated from Series 004/005 experiments):
        α_high: 0.7    # Clean content
        α_med:  0.4    # Acceptable content
        κ_high: 0.7    # Good encoding-solver match
        κ_med:  0.4    # Acceptable match
        σ_high: 0.3    # Instability threshold

    Usage:
        diagnoser = DegradationDiagnoser()
        result = diagnoser.diagnose(alpha=0.8, kappa=0.3, sigma=0.1)
        print(f"Type: {result.degradation_type.name}")
        print(f"Action: {result.recommended_action}")
    """

    def __init__(
        self,
        alpha_high: float = 0.7,
        alpha_med: float = 0.4,
        kappa_high: float = 0.7,
        kappa_med: float = 0.4,
        sigma_high: float = 0.3,
    ):
        """
        Initialize diagnoser with calibrated thresholds.

        Args:
            alpha_high: Threshold for HIGH content quality
            alpha_med: Threshold for MEDIUM content quality
            kappa_high: Threshold for HIGH geometric compatibility
            kappa_med: Threshold for MEDIUM geometric compatibility
            sigma_high: Threshold for instability (above = unstable)
        """
        self.alpha_high = alpha_high
        self.alpha_med = alpha_med
        self.kappa_high = kappa_high
        self.kappa_med = kappa_med
        self.sigma_high = sigma_high

    def _classify_level(self, value: float, high: float, med: float) -> QualityLevel:
        """Classify value into HIGH/MED/LOW."""
        if value >= high:
            return QualityLevel.HIGH
        elif value >= med:
            return QualityLevel.MEDIUM
        else:
            return QualityLevel.LOW

    def diagnose(
        self,
        alpha: float,
        kappa: float,
        sigma: Optional[float] = None,
    ) -> DiagnosisResult:
        """
        Diagnose degradation type from Layer 1 (α) and Layer 2 (κ).

        Args:
            alpha: Content quality (R/(R+S+N)) [0, 1]
            kappa: Geometric compatibility (D*/D) [0, 1]
            sigma: Instability estimate (optional) [0, 1]

        Returns:
            DiagnosisResult with type, confidence, action, explanation

        9-Grid Decision Table:
        ┌─────────┬─────────┬─────────┬─────────────────────┬──────────────────────┐
        │ α Level │ κ Level │ σ       │ Degradation Type    │ Action               │
        ├─────────┼─────────┼─────────┼─────────────────────┼──────────────────────┤
        │ HIGH    │ HIGH    │ Low     │ NONE                │ Trust output         │
        │ HIGH    │ MED     │ Low     │ PARTIAL_MATCH       │ Augment encoding     │
        │ HIGH    │ LOW     │ Low     │ GEOMETRY_MISMATCH   │ Change encoding E    │
        ├─────────┼─────────┼─────────┼─────────────────────┼──────────────────────┤
        │ MED     │ HIGH    │ Low     │ MILD_CONTENT_ISSUE  │ Clean input          │
        │ MED     │ MED     │ Low     │ BALANCED_DEGRADATION│ Clean + augment      │
        │ MED     │ LOW     │ Low     │ GEOMETRY_MISMATCH   │ Change encoding E    │
        ├─────────┼─────────┼─────────┼─────────────────────┼──────────────────────┤
        │ LOW     │ HIGH    │ Low     │ CONTENT_DEGRADATION │ Clean input/filter   │
        │ LOW     │ MED     │ Low     │ CONTENT_DEGRADATION │ Clean input/filter   │
        │ LOW     │ LOW     │ Low     │ TOTAL_FAILURE       │ Reject/fallback      │
        ├─────────┼─────────┼─────────┼─────────────────────┼──────────────────────┤
        │ ANY     │ ANY     │ High    │ UNSTABLE            │ Increase samples     │
        └─────────┴─────────┴─────────┴─────────────────────┴──────────────────────┘
        """
        # Classify levels
        alpha_level = self._classify_level(alpha, self.alpha_high, self.alpha_med)
        kappa_level = self._classify_level(kappa, self.kappa_high, self.kappa_med)

        # Check instability FIRST (overrides all)
        if sigma is not None and sigma >= self.sigma_high:
            return DiagnosisResult(
                degradation_type=DegradationType.UNSTABLE,
                confidence=1.0 - ((sigma - self.sigma_high) / (1.0 - self.sigma_high)),
                recommended_action="Increase samples, widen prior, or reject",
                explanation=f"Instability σ={sigma:.3f} ≥ {self.sigma_high} → metrics unreliable",
                alpha=alpha,
                kappa=kappa,
                sigma=sigma or 0.0,
                alpha_level=alpha_level,
                kappa_level=kappa_level,
            )

        # 9-Grid decision logic (sigma is LOW)
        if alpha_level == QualityLevel.HIGH:
            if kappa_level == QualityLevel.HIGH:
                # ✅ BEST CASE: High content, high compatibility
                return DiagnosisResult(
                    degradation_type=DegradationType.NONE,
                    confidence=min(alpha, kappa),
                    recommended_action="Trust output - proceed normally",
                    explanation=f"α={alpha:.3f} HIGH, κ={kappa:.3f} HIGH → clean content + good interface",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )
            elif kappa_level == QualityLevel.MEDIUM:
                # ⚠️ Content good, encoding partially works
                return DiagnosisResult(
                    degradation_type=DegradationType.PARTIAL_MATCH,
                    confidence=0.7,
                    recommended_action="Augment encoding or switch to symbolic solver",
                    explanation=f"α={alpha:.3f} HIGH, κ={kappa:.3f} MED → solver exploits some structure but not optimal",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )
            else:  # kappa_level == QualityLevel.LOW
                # ❌ Content good, but encoding BAD
                return DiagnosisResult(
                    degradation_type=DegradationType.GEOMETRY_MISMATCH,
                    confidence=alpha - kappa,  # High alpha, low kappa = high confidence
                    recommended_action="Change encoding (E1→E2→E3) or switch solver",
                    explanation=f"α={alpha:.3f} HIGH, κ={kappa:.3f} LOW → content OK but solver can't use it",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )

        elif alpha_level == QualityLevel.MEDIUM:
            if kappa_level == QualityLevel.HIGH:
                # ⚠️ Content slightly degraded, but encoding works
                return DiagnosisResult(
                    degradation_type=DegradationType.MILD_CONTENT_ISSUE,
                    confidence=kappa - alpha,
                    recommended_action="Clean input, apply noise filtering, or canonicalize",
                    explanation=f"α={alpha:.3f} MED, κ={kappa:.3f} HIGH → interface works, input slightly noisy",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )
            elif kappa_level == QualityLevel.MEDIUM:
                # ⚠️ Both degraded moderately
                return DiagnosisResult(
                    degradation_type=DegradationType.BALANCED_DEGRADATION,
                    confidence=(alpha + kappa) / 2,
                    recommended_action="Clean input AND augment encoding",
                    explanation=f"α={alpha:.3f} MED, κ={kappa:.3f} MED → both content and encoding moderately degraded",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )
            else:  # kappa_level == QualityLevel.LOW
                # ❌ Encoding mismatch dominates
                return DiagnosisResult(
                    degradation_type=DegradationType.GEOMETRY_MISMATCH,
                    confidence=0.7,
                    recommended_action="Change encoding (priority) or clean input",
                    explanation=f"α={alpha:.3f} MED, κ={kappa:.3f} LOW → encoding mismatch is primary issue",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )

        else:  # alpha_level == QualityLevel.LOW
            if kappa_level == QualityLevel.HIGH or kappa_level == QualityLevel.MEDIUM:
                # ❌ Content BAD, encoding works (or partially works)
                return DiagnosisResult(
                    degradation_type=DegradationType.CONTENT_DEGRADATION,
                    confidence=kappa,  # Encoding reliability indicates this is content issue
                    recommended_action="Clean input, filter noise, or reject",
                    explanation=f"α={alpha:.3f} LOW, κ={kappa:.3f} {kappa_level.value.upper()} → interface works, input is severely degraded",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )
            else:  # kappa_level == QualityLevel.LOW
                # ❌❌ TOTAL FAILURE
                return DiagnosisResult(
                    degradation_type=DegradationType.TOTAL_FAILURE,
                    confidence=1.0 - max(alpha, kappa),  # Confidence in failure
                    recommended_action="REJECT - fallback to prior/default",
                    explanation=f"α={alpha:.3f} LOW, κ={kappa:.3f} LOW → both content and encoding failed",
                    alpha=alpha,
                    kappa=kappa,
                    sigma=sigma or 0.0,
                    alpha_level=alpha_level,
                    kappa_level=kappa_level,
                )

    def diagnose_from_certificate(self, certificate: "YRSNCertificate") -> DiagnosisResult:
        """
        Diagnose degradation from a YRSNCertificate.

        Args:
            certificate: YRSNCertificate with α, κ, σ fields

        Returns:
            DiagnosisResult

        Note:
            If κ is None (Layer 2 not computed), returns UNKNOWN degradation type.
            Cannot diagnose geometry compatibility without κ.
        """
        alpha = certificate.alpha

        # Check if κ is available (Layer 2 computed)
        if certificate.kappa is None:
            # Cannot diagnose geometry compatibility without κ
            return DiagnosisResult(
                degradation_type=DegradationType.UNKNOWN,
                confidence=0.0,
                recommended_action="Skip supervisory gate - proceed with quality-only control (κ not available)",
                explanation="Layer 2 (RSCT) not computed - cannot assess encoding-solver compatibility",
                alpha=alpha,
                kappa=0.0,  # Placeholder
                sigma=0.0,
                alpha_level=self._classify_level(alpha, self.alpha_high, self.alpha_med),
                kappa_level=QualityLevel.MEDIUM,  # Unknown, use middle value
            )

        kappa = certificate.kappa
        sigma = certificate.sigma if certificate.sigma is not None else 0.0

        return self.diagnose(alpha=alpha, kappa=kappa, sigma=sigma)

    def get_action_priority(self, result: DiagnosisResult) -> int:
        """
        Get action priority (lower = more urgent).

        Returns:
            1-5 priority level (1 = critical, 5 = normal)
        """
        if result.degradation_type == DegradationType.TOTAL_FAILURE:
            return 1  # CRITICAL: Must reject
        elif result.degradation_type == DegradationType.UNSTABLE:
            return 1  # CRITICAL: Unreliable metrics
        elif result.degradation_type == DegradationType.CONTENT_DEGRADATION:
            return 2  # HIGH: Bad input
        elif result.degradation_type == DegradationType.GEOMETRY_MISMATCH:
            return 2  # HIGH: Wrong encoding
        elif result.degradation_type == DegradationType.BALANCED_DEGRADATION:
            return 3  # MEDIUM: Fix both
        elif result.degradation_type == DegradationType.MILD_CONTENT_ISSUE:
            return 4  # LOW: Minor input issue
        elif result.degradation_type == DegradationType.PARTIAL_MATCH:
            return 4  # LOW: Suboptimal but workable
        elif result.degradation_type == DegradationType.UNKNOWN:
            return 5  # NORMAL: Skip supervisory gate, proceed with quality-only
        else:  # NONE
            return 5  # NORMAL: No action needed


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "DegradationType",
    "QualityLevel",
    "DiagnosisResult",
    "DegradationDiagnoser",
]
