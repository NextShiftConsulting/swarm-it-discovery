"""
YRSN Domain Layer
=================

Domain as a first-class concept in YRSN.

A Domain defines the INTERPRETATION context for collapse signals,
without changing the detection math.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.8: Environmental Validation Context
  - §7.8.2: Domain Specification (5 domain types)
  - §7.8.3: Threshold Configuration (SafetyEnvelope, ObservabilityLimits)
  - §7.8.5: Temporal Scope (decision timescales)

Implemented domain types (§7.8.2):
  1. RealTimePhysicalDomain (robotics, 10ms timescale)
  2. SlowPhysicalDomain (industrial, 1-minute timescale)
  3. AdversarialDomain (security, 100ms timescale)
  4. SymbolicDomain (LLMs, 5-second timescale)
  5. QuantumDomain (quantum computing, 1-second timescale)

Context components:
  - SafetyEnvelope: Latency, confidence, risk limits
  - ObservabilityLimits: Measurable signals, delays
  - TransitionProfile: Hysteresis, activation modes
  - HarmModel: Collapse-to-harm mapping

Relevant patent files:
- docs/specs/patent_spec_section_7_8_environmental_context.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

From First Principles:
    "Domains organize WHY a collapse occurred, not HOW to fix it."
    "Domains never change detection math."

Domain Characteristics:
    - Timescale of decisions
    - Acceptable error tradeoffs
    - Harm model (what failure costs)
    - Safety envelope
    - Observability limits

Domain Types (5 total):
    I.   Real-Time Physical (robotics, autonomous vehicles)
    II.  Slow Physical (industrial processes, HVAC)
    III. Adversarial (cybersecurity, fraud detection)
    IV.  Symbolic/Tool-Based (LLM agents, RAG pipelines)
    V.   Quantum/Probabilistic-Physical (quantum computing, ensembles)

Key Distinction:
    Physical wavefunction collapse is NOT YRSN collapse.
    YRSN collapse is epistemic: "our inference assumptions are no longer trustworthy."

Usage:
    from yrsn.core.domain import Domain, SymbolicDomain, QuantumDomain

    domain = SymbolicDomain()
    print(domain.interpret_collapse(collapse_signal))
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, Dict, Any

try:
    from typing import Protocol, runtime_checkable
except ImportError:
    from typing_extensions import Protocol, runtime_checkable


class CollapseAxis(str, Enum):
    """
    The three orthogonal collapse axes (PCA-friendly).

    Axes represent independent dimensions of failure - like principal
    components, they are orthogonal. A collapse projects onto exactly
    one axis based on its root cause.

    QUALITY axis:
        Failures in R/S/N composition.
        "The signal mix is wrong."
        Collapses: POISONING, DISTRACTION, CONFLICT, CLASH

    RELIABILITY axis:
        Failures in distributional validity (ω/OOD).
        "The distribution assumptions are broken."
        Collapses: HALLUCINATION, O_POISONING, DRIFT

    REPRESENTATION axis:
        Failures in model internal capacity.
        "The model can't distinguish signal from noise."
        Collapses: POSTERIOR_COLLAPSE, MODE_COLLAPSE, RSN_COLLAPSE
    """

    QUALITY = "quality"           # R/S/N composition failures
    RELIABILITY = "reliability"   # ω/OOD validity failures
    REPRESENTATION = "representation"  # Internal capacity failures


class HarmLevel(str, Enum):
    """Harm levels for domain-specific risk assessment."""

    NEGLIGIBLE = "negligible"   # No significant impact
    MINOR = "minor"             # Easily recoverable
    MODERATE = "moderate"       # Requires intervention
    SEVERE = "severe"           # Significant damage possible
    CATASTROPHIC = "catastrophic"  # Irreversible harm


@dataclass
class SafetyEnvelope:
    """
    Safety constraints for a domain.

    Defines the boundaries within which operation is considered safe.
    """

    max_latency_ms: Optional[float] = None  # Maximum acceptable latency
    min_confidence: float = 0.5             # Minimum confidence to proceed
    max_risk_score: float = 0.7             # Maximum acceptable risk
    requires_human_approval: bool = False   # Human-in-the-loop required
    can_halt: bool = True                   # System can halt on collapse
    can_degrade: bool = True                # System can degrade gracefully


@dataclass
class ObservabilityLimits:
    """
    What can be observed in this domain.

    Different domains have different visibility into system state.
    """

    can_measure_r: bool = True     # Can measure relevant signal
    can_measure_s: bool = True     # Can measure superfluous signal
    can_measure_n: bool = True     # Can measure noise
    can_measure_omega: bool = True # Can measure reliability
    measurement_delay_ms: float = 0.0  # Delay in measurements
    ensemble_size: Optional[int] = None  # For quantum: shot count


class ActivationMode(str, Enum):
    """
    Temperature activation modes (transition curve shapes).

    These define the mathematical relationship τ = f(α).
    The CHOICE of mode is policy; the math is measurement.
    """

    LINEAR = "linear"      # τ = 1/α (sharp, direct)
    POWER = "power"        # τ = 1/α^k (amplified, default k=2)
    LOG = "log"            # τ = 1/log(1+cα) (compressed)
    SIGMOID = "sigmoid"    # τ = bounded S-curve (smooth)


@dataclass
class TransitionProfile:
    """
    How phase transitions behave in a domain.

    This is POLICY - it controls transition response shape.
    The detector measures crossings; the profile controls response.

    Example separation:
        MEASUREMENT: "Quality crossed threshold 0.70 → 0.68"
        POLICY:      "In adversarial domain, downgrade immediately (no hysteresis)"

    Different domains need different transition behaviors:
        Real-Time Physical: Sharp transitions (can't tolerate boundary uncertainty)
        Slow Physical:      Gradual transitions (systems need time to stabilize)
        Adversarial:        Conservative (fast downgrade, slow upgrade)
        Symbolic:           Balanced (standard hysteresis)
        Quantum:            Ensemble-based (single crossings meaningless)
    """

    # Hysteresis: buffer zone to prevent oscillation at boundaries
    # 0.0 = sharp (transition exactly at threshold)
    # 0.1 = gradual (need to cross threshold + 10% to trigger)
    hysteresis: float = 0.02

    # Cooldown: minimum time between transitions
    cooldown_seconds: float = 1.0

    # Asymmetric bias: how cautious about upgrades vs downgrades
    # 1.0 = symmetric (same threshold both directions)
    # 2.0 = conservative (need 2x evidence to upgrade vs downgrade)
    # 0.5 = aggressive (upgrade easily, downgrade slowly)
    upgrade_bias: float = 1.0

    # Activation mode: shape of τ = f(α) curve
    activation_mode: ActivationMode = ActivationMode.POWER

    # Minimum samples before allowing transition
    min_samples: int = 10

    # For ensemble-based domains (quantum): require statistical significance
    ensemble_threshold: Optional[float] = None  # p-value for transition


@runtime_checkable
class Domain(Protocol):
    """
    Protocol for YRSN domains.

    A Domain provides interpretation context for YRSN signals
    without changing the underlying detection math.

    First Principle: Domains never change detection math.
    """

    @property
    def name(self) -> str:
        """Domain name for identification."""
        ...

    @property
    def timescale_ms(self) -> float:
        """Characteristic decision timescale in milliseconds."""
        ...

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        """Maps collapse types to harm levels in this domain."""
        ...

    @property
    def safety_envelope(self) -> SafetyEnvelope:
        """Safety constraints for this domain."""
        ...

    @property
    def observability(self) -> ObservabilityLimits:
        """What can be observed in this domain."""
        ...

    @property
    def transition_profile(self) -> TransitionProfile:
        """
        How phase transitions should behave in this domain.

        This is POLICY - controls transition response shape.
        Different domains need different transition behaviors.
        """
        ...

    def interpret_novelty(self, o_score: float) -> str:
        """
        How novelty (O) is interpreted in this domain.

        Different domains treat novelty differently:
        - Adversarial: novelty is suspicious by default
        - Symbolic: novelty may be valuable
        - Quantum: novelty is expected
        """
        ...


# =============================================================================
# Domain Implementations
# =============================================================================


@dataclass
class RealTimePhysicalDomain:
    """
    Domain Type I: Real-Time Physical Systems.

    Characteristics:
    - Tight latency constraints
    - Hard safety boundaries
    - Partial observability
    - Continuous actuation

    Examples: Robotics, autonomous vehicles, embedded control

    In this domain, collapse often means: slow down or stop.
    """

    name: str = "real_time_physical"
    timescale_ms: float = 10.0  # 10ms decision loop

    safety_envelope: SafetyEnvelope = field(default_factory=lambda: SafetyEnvelope(
        max_latency_ms=50.0,
        min_confidence=0.8,
        max_risk_score=0.5,
        requires_human_approval=False,
        can_halt=True,
        can_degrade=True,
    ))

    observability: ObservabilityLimits = field(default_factory=lambda: ObservabilityLimits(
        can_measure_r=True,
        can_measure_s=True,
        can_measure_n=True,
        can_measure_omega=True,
        measurement_delay_ms=5.0,
    ))

    # SHARP transitions: can't tolerate boundary uncertainty
    transition_profile: TransitionProfile = field(default_factory=lambda: TransitionProfile(
        hysteresis=0.005,           # Nearly zero - react immediately
        cooldown_seconds=0.1,       # Very short - real-time response
        upgrade_bias=1.5,           # Slightly conservative on upgrades
        activation_mode=ActivationMode.LINEAR,  # Direct, predictable
        min_samples=3,              # Few samples - need fast decisions
    ))

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        return {
            "POISONING": HarmLevel.CATASTROPHIC,    # Bad sensor = crash
            "DISTRACTION": HarmLevel.SEVERE,        # Overload = missed obstacle
            "CONFLICT": HarmLevel.CATASTROPHIC,    # Contradictions = wrong action
            "HALLUCINATION": HarmLevel.CATASTROPHIC,  # False confidence = disaster
            "DRIFT": HarmLevel.MODERATE,            # Gradual, can adapt
        }

    def interpret_novelty(self, o_score: float) -> str:
        if o_score > 0.7:
            return "High novelty: slow down, increase sensing"
        elif o_score > 0.4:
            return "Moderate novelty: proceed with caution"
        else:
            return "Low novelty: nominal operation"


@dataclass
class SlowPhysicalDomain:
    """
    Domain Type II: Slow Physical Systems.

    Characteristics:
    - Slow dynamics
    - Long calibration horizons
    - Drift-dominated failure modes
    - Human-in-the-loop supervision

    Examples: Industrial processes, energy systems, HVAC, manufacturing
    """

    name: str = "slow_physical"
    timescale_ms: float = 60000.0  # 1 minute decision loop

    safety_envelope: SafetyEnvelope = field(default_factory=lambda: SafetyEnvelope(
        max_latency_ms=30000.0,
        min_confidence=0.6,
        max_risk_score=0.6,
        requires_human_approval=True,
        can_halt=True,
        can_degrade=True,
    ))

    observability: ObservabilityLimits = field(default_factory=lambda: ObservabilityLimits(
        can_measure_r=True,
        can_measure_s=True,
        can_measure_n=True,
        can_measure_omega=True,
        measurement_delay_ms=1000.0,
    ))

    # GRADUAL transitions: systems need time to stabilize
    transition_profile: TransitionProfile = field(default_factory=lambda: TransitionProfile(
        hysteresis=0.10,            # Large buffer - avoid oscillation
        cooldown_seconds=60.0,      # 1 minute - match system dynamics
        upgrade_bias=1.0,           # Symmetric - no rush either way
        activation_mode=ActivationMode.LOG,  # Compressed - smooth response
        min_samples=50,             # Many samples - statistical confidence
    ))

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        return {
            "POISONING": HarmLevel.MODERATE,    # Gradual, detectable
            "DISTRACTION": HarmLevel.MINOR,     # Low impact
            "CONFLICT": HarmLevel.MODERATE,    # Human can intervene
            "DRIFT": HarmLevel.SEVERE,          # Main concern in slow systems
            "HALLUCINATION": HarmLevel.MODERATE,
        }

    def interpret_novelty(self, o_score: float) -> str:
        if o_score > 0.5:
            return "Novelty detected: check for regime change"
        else:
            return "Normal operation"


@dataclass
class AdversarialDomain:
    """
    Domain Type III: Adversarial Systems.

    Characteristics:
    - Strategic adversaries
    - Intentional distribution shift
    - High cost of false negatives

    Examples: Cybersecurity, fraud detection, abuse prevention

    Key principle: Novelty is suspicious by default.
    """

    name: str = "adversarial"
    timescale_ms: float = 100.0  # 100ms for real-time detection

    safety_envelope: SafetyEnvelope = field(default_factory=lambda: SafetyEnvelope(
        max_latency_ms=500.0,
        min_confidence=0.7,
        max_risk_score=0.4,  # Conservative
        requires_human_approval=False,
        can_halt=True,
        can_degrade=True,
    ))

    observability: ObservabilityLimits = field(default_factory=lambda: ObservabilityLimits(
        can_measure_r=True,
        can_measure_s=True,
        can_measure_n=True,
        can_measure_omega=True,
        measurement_delay_ms=10.0,
    ))

    # CONSERVATIVE transitions: fast downgrade, slow upgrade (assume worst)
    transition_profile: TransitionProfile = field(default_factory=lambda: TransitionProfile(
        hysteresis=0.01,            # Small buffer - react to threats quickly
        cooldown_seconds=0.5,       # Short - need rapid response
        upgrade_bias=3.0,           # Very conservative - 3x evidence to upgrade
        activation_mode=ActivationMode.POWER,  # Amplified - magnify small changes
        min_samples=5,              # Quick decisions but some confidence
    ))

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        return {
            "POISONING": HarmLevel.CATASTROPHIC,  # Adversarial injection
            "O_POISONING": HarmLevel.CATASTROPHIC,  # OOD attack
            "DISTRACTION": HarmLevel.SEVERE,      # Decoy/noise attack
            "DRIFT": HarmLevel.SEVERE,            # Concept drift attack
            "HALLUCINATION": HarmLevel.MODERATE,
        }

    def interpret_novelty(self, o_score: float) -> str:
        # In adversarial domain, novelty is suspicious
        if o_score > 0.3:
            return "SUSPICIOUS: Novelty in adversarial context - investigate"
        else:
            return "Known pattern - proceed with monitoring"


@dataclass
class SymbolicDomain:
    """
    Domain Type IV: Symbolic / Tool-Based Systems.

    Characteristics:
    - Event-driven decisions
    - No physical harm, but high semantic risk
    - Tool failures are silent

    Examples: LLM agents, RAG pipelines, workflow automation

    Key principle: Collapse usually means hand off to a human.
    """

    name: str = "symbolic"
    timescale_ms: float = 5000.0  # 5 second response time

    safety_envelope: SafetyEnvelope = field(default_factory=lambda: SafetyEnvelope(
        max_latency_ms=30000.0,
        min_confidence=0.5,
        max_risk_score=0.7,
        requires_human_approval=False,
        can_halt=False,  # Usually degrade, not halt
        can_degrade=True,
    ))

    observability: ObservabilityLimits = field(default_factory=lambda: ObservabilityLimits(
        can_measure_r=True,
        can_measure_s=True,
        can_measure_n=True,
        can_measure_omega=True,  # Via OOD detectors
        measurement_delay_ms=100.0,
    ))

    # BALANCED transitions: standard behavior, no special requirements
    transition_profile: TransitionProfile = field(default_factory=lambda: TransitionProfile(
        hysteresis=0.02,            # Standard buffer
        cooldown_seconds=1.0,       # Standard cooldown
        upgrade_bias=1.0,           # Symmetric
        activation_mode=ActivationMode.POWER,  # Default power mode
        min_samples=10,             # Standard sample requirement
    ))

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        return {
            "POISONING": HarmLevel.MODERATE,      # Bad retrieval
            "DISTRACTION": HarmLevel.MINOR,       # Verbose but manageable
            "CONFLICT": HarmLevel.MODERATE,      # Conflicting sources
            "HALLUCINATION": HarmLevel.SEVERE,    # LLM making things up
            "DRIFT": HarmLevel.MINOR,             # Context evolution
        }

    def interpret_novelty(self, o_score: float) -> str:
        # In symbolic domain, novelty may be valuable
        if o_score > 0.7:
            return "High novelty: validate carefully, but may be valuable"
        elif o_score > 0.4:
            return "Moderate novelty: cross-reference sources"
        else:
            return "Familiar content: standard processing"


@dataclass
class QuantumDomain:
    """
    Domain Type V: Quantum / Probabilistic-Physical Systems.

    Characteristics:
    - Measurement is intrinsically destructive
    - State is probabilistic, not directly observable
    - Ensemble statistics dominate over single outcomes
    - Irreducible uncertainty is expected, not noise

    Key Distinction:
        Physical wavefunction collapse is NOT YRSN collapse.
        YRSN collapse remains epistemic: loss of trust in inference assumptions.

    Sound Bite:
        "Quantum uncertainty is expected; only broken statistics are surprising."

    Examples: Quantum computing, quantum sensing, probabilistic inference

    Typical Signals:
    - Outcome distributions over repeated measurements
    - Fidelity and calibration metrics
    - Noise channel parameters
    - Decoherence and drift rates
    """

    name: str = "quantum"
    timescale_ms: float = 1000.0  # 1s for ensemble collection

    safety_envelope: SafetyEnvelope = field(default_factory=lambda: SafetyEnvelope(
        max_latency_ms=60000.0,  # Can wait for statistics
        min_confidence=0.6,
        max_risk_score=0.6,
        requires_human_approval=False,
        can_halt=True,
        can_degrade=True,
    ))

    observability: ObservabilityLimits = field(default_factory=lambda: ObservabilityLimits(
        can_measure_r=True,  # Via ensemble statistics
        can_measure_s=True,  # Structured noise patterns
        can_measure_n=True,  # Decoherence
        can_measure_omega=True,  # Fidelity metrics
        measurement_delay_ms=500.0,
        ensemble_size=1000,  # Default shot count
    ))

    # ENSEMBLE-BASED transitions: single measurements meaningless
    transition_profile: TransitionProfile = field(default_factory=lambda: TransitionProfile(
        hysteresis=0.05,            # Moderate - statistical noise expected
        cooldown_seconds=5.0,       # Wait for ensemble collection
        upgrade_bias=1.0,           # Symmetric
        activation_mode=ActivationMode.SIGMOID,  # Smooth, bounded response
        min_samples=100,            # Need statistical significance
        ensemble_threshold=0.05,    # p < 0.05 for transition
    ))

    @property
    def harm_model(self) -> Dict[str, HarmLevel]:
        return {
            "POISONING": HarmLevel.MODERATE,      # Bad calibration
            "DISTRACTION": HarmLevel.MINOR,       # Extra qubits
            "CONFLICT": HarmLevel.MODERATE,      # Entanglement issues
            "DRIFT": HarmLevel.SEVERE,            # Decoherence drift
            "RSN_COLLAPSE": HarmLevel.SEVERE,     # Can't distinguish signal
        }

    def interpret_novelty(self, o_score: float) -> str:
        # In quantum domain, irreducible uncertainty is expected
        if o_score > 0.8:
            return "Distribution shift: check for calibration drift"
        elif o_score > 0.5:
            return "Moderate deviation: may need recalibration"
        else:
            return "Within expected quantum variance"


# =============================================================================
# Factory Functions
# =============================================================================


def get_domain(name: str) -> Domain:
    """
    Get a domain by name.

    Parameters
    ----------
    name : str
        Domain name: 'real_time_physical', 'slow_physical',
        'adversarial', 'symbolic', 'quantum'

    Returns
    -------
    Domain
        Domain instance
    """
    domains = {
        'real_time_physical': RealTimePhysicalDomain,
        'slow_physical': SlowPhysicalDomain,
        'adversarial': AdversarialDomain,
        'symbolic': SymbolicDomain,
        'quantum': QuantumDomain,
    }

    if name not in domains:
        raise ValueError(f"Unknown domain: {name}. Available: {list(domains.keys())}")

    return domains[name]()


def list_domains() -> list:
    """List available domain names."""
    return [
        'real_time_physical',
        'slow_physical',
        'adversarial',
        'symbolic',
        'quantum',
    ]


__all__ = [
    # Enums
    'CollapseAxis',
    'HarmLevel',
    'ActivationMode',
    # Data classes
    'SafetyEnvelope',
    'ObservabilityLimits',
    'TransitionProfile',
    # Protocol
    'Domain',
    # Implementations
    'RealTimePhysicalDomain',
    'SlowPhysicalDomain',
    'AdversarialDomain',
    'SymbolicDomain',
    'QuantumDomain',
    # Factory
    'get_domain',
    'list_domains',
]
