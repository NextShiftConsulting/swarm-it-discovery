"""
Sparse Distributed Memory (SDM) - Kanerva's content-addressable memory.

SDM is a mathematical model of human long-term memory that:
1. Stores patterns in high-dimensional binary space
2. Retrieves patterns from partial/noisy cues
3. Provides graceful degradation with noise
4. Has massive capacity with good retrieval

Key insight: In high dimensions, random binary vectors are almost
always far apart (near-orthogonal), enabling robust storage.

YRSN Integration:
- Address = encoded context vector (from any domain)
- Data = decision/output vector
- Counters = accumulated experience (memristive weights)

Reference: Kanerva, P. (1988). Sparse Distributed Memory.
Part of yrsn-context core memory layer.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple
import numpy as np


@dataclass
class SDMConfig:
    """Configuration for Sparse Distributed Memory."""

    # Dimensions
    address_dim: int = 1024     # Dimension of address space (binary)
    data_dim: int = 256         # Dimension of stored data
    num_locations: int = 1000   # Number of hard locations (M << 2^n)

    # Access parameters
    access_radius: int = 451    # Hamming distance for activation
    # Default ~44% of dim gives ~1000 activated for 1M locations

    # Counter parameters
    counter_max: int = 127      # Maximum counter value
    counter_min: int = -128     # Minimum counter value

    # Learning
    learning_rate: float = 1.0  # How much to increment/decrement counters

    # Initialization
    seed: Optional[int] = None


@dataclass
class SDMLocation:
    """A single hard location in SDM."""
    address: np.ndarray         # Binary address vector
    counters: np.ndarray        # Integer counters for data storage
    access_count: int = 0       # How often this location was accessed


class SparseDistributedMemory:
    """
    Sparse Distributed Memory implementation.

    Architecture:
    - N = 2^n possible addresses (address_dim = n)
    - M << N hard locations (num_locations = M)
    - Each location has:
      - Hard address (random binary vector)
      - Counter array (one per data dimension)

    Operations:
    - Write: Find locations within access_radius, increment/decrement counters
    - Read: Find locations within access_radius, sum counters, threshold

    Generic usage:
    - Address = encoded context vector (any features)
    - Data = output/decision vector
    - Counters = memristive weights (accumulated experience)
    """

    def __init__(self, config: Optional[SDMConfig] = None):
        self.config = config or SDMConfig()
        self.rng = np.random.RandomState(self.config.seed)

        # Initialize hard locations with random addresses
        self.locations: List[SDMLocation] = []
        self._init_locations()

    def _init_locations(self) -> None:
        """Initialize random hard locations."""
        cfg = self.config

        for _ in range(cfg.num_locations):
            # Random binary address
            address = self.rng.randint(0, 2, cfg.address_dim).astype(np.int8)

            # Zero-initialized counters
            counters = np.zeros(cfg.data_dim, dtype=np.int16)

            self.locations.append(SDMLocation(
                address=address,
                counters=counters,
                access_count=0
            ))

    def hamming_distance(self, a: np.ndarray, b: np.ndarray) -> int:
        """Compute Hamming distance between two binary vectors."""
        return int(np.sum(a != b))

    def _get_activated_locations(
        self,
        address: np.ndarray,
        radius: Optional[int] = None
    ) -> List[Tuple[int, SDMLocation, int]]:
        """
        Find locations within Hamming radius of address.

        Returns list of (index, location, distance) tuples.
        """
        radius = radius if radius is not None else self.config.access_radius
        activated = []

        for i, loc in enumerate(self.locations):
            dist = self.hamming_distance(address, loc.address)
            if dist <= radius:
                activated.append((i, loc, dist))

        return activated

    def write(
        self,
        address: np.ndarray,
        data: np.ndarray,
        weight: float = 1.0
    ) -> int:
        """
        Write data to memory at given address.

        Parameters
        ----------
        address : np.ndarray
            Binary address vector (n-dimensional)
        data : np.ndarray
            Data to store (bipolar {-1, +1} or binary {0, 1})
        weight : float
            Learning weight (for prioritized learning)

        Returns
        -------
        int
            Number of locations activated
        """
        cfg = self.config

        # Ensure binary address
        address = (address > 0).astype(np.int8)

        # Convert data to bipolar for counter update
        if np.all((data == 0) | (data == 1)):
            data_bipolar = 2 * data - 1  # {0,1} → {-1,+1}
        else:
            data_bipolar = np.sign(data)

        # Find activated locations
        activated = self._get_activated_locations(address)

        # Update counters at each activated location
        for idx, loc, dist in activated:
            # Weight update by distance (closer = stronger)
            dist_weight = 1.0 - (dist / self.config.access_radius)
            update = cfg.learning_rate * weight * dist_weight * data_bipolar

            # Update counters with clipping
            new_counters = loc.counters + update.astype(np.int16)
            loc.counters = np.clip(
                new_counters,
                cfg.counter_min,
                cfg.counter_max
            ).astype(np.int16)

            loc.access_count += 1

        return len(activated)

    def read(
        self,
        address: np.ndarray,
        radius: Optional[int] = None
    ) -> Tuple[np.ndarray, float]:
        """
        Read from memory at given address.

        Parameters
        ----------
        address : np.ndarray
            Binary address vector (query)
        radius : int, optional
            Custom access radius (defaults to config)

        Returns
        -------
        tuple[np.ndarray, float]
            (retrieved_data, confidence)
            - retrieved_data: Bipolar {-1, +1} vector
            - confidence: Average absolute counter value (0-1)
        """
        # Ensure binary address
        address = (address > 0).astype(np.int8)

        # Find activated locations
        activated = self._get_activated_locations(address, radius)

        if not activated:
            # No matching locations - return zeros with zero confidence
            return np.zeros(self.config.data_dim), 0.0

        # Sum counters from all activated locations
        counter_sum = np.zeros(self.config.data_dim, dtype=np.float32)

        for idx, loc, dist in activated:
            # Weight by inverse distance
            dist_weight = 1.0 - (dist / (self.config.access_radius + 1))
            counter_sum += loc.counters * dist_weight

        # Threshold to get bipolar output
        data = np.sign(counter_sum)
        data[data == 0] = 1  # Resolve ties

        # Confidence = normalized average absolute counter
        avg_abs_counter = np.mean(np.abs(counter_sum)) / len(activated)
        confidence = min(1.0, avg_abs_counter / self.config.counter_max)

        return data, confidence

    def read_continuous(
        self,
        address: np.ndarray,
        radius: Optional[int] = None
    ) -> Tuple[np.ndarray, float]:
        """
        Read continuous values (not thresholded).

        Useful for getting soft predictions.
        """
        address = (address > 0).astype(np.int8)
        activated = self._get_activated_locations(address, radius)

        if not activated:
            return np.zeros(self.config.data_dim), 0.0

        counter_sum = np.zeros(self.config.data_dim, dtype=np.float32)

        for idx, loc, dist in activated:
            dist_weight = 1.0 - (dist / (self.config.access_radius + 1))
            counter_sum += loc.counters * dist_weight

        # Normalize to [-1, 1]
        max_possible = len(activated) * self.config.counter_max
        normalized = counter_sum / max_possible if max_possible > 0 else counter_sum

        confidence = min(1.0, np.mean(np.abs(normalized)))

        return normalized, confidence

    def load_apriori(
        self,
        patterns: List[Tuple[np.ndarray, np.ndarray]],
        weight: float = 10.0
    ) -> int:
        """
        Load a priori memories (historical patterns).

        These get high weight to establish strong initial memories.

        Parameters
        ----------
        patterns : list of (address, data) tuples
            Historical patterns to pre-load
        weight : float
            Learning weight (high = strong memories)

        Returns
        -------
        int
            Number of patterns loaded
        """
        for address, data in patterns:
            self.write(address, data, weight=weight)

        return len(patterns)

    def similarity_search(
        self,
        query: np.ndarray,
        top_k: int = 5
    ) -> List[Tuple[int, float, np.ndarray]]:
        """
        Find k most similar stored patterns.

        Parameters
        ----------
        query : np.ndarray
            Query address
        top_k : int
            Number of results

        Returns
        -------
        list of (location_idx, similarity, data)
        """
        query = (query > 0).astype(np.int8)

        # Compute distances to all locations
        distances = []
        for i, loc in enumerate(self.locations):
            dist = self.hamming_distance(query, loc.address)
            sim = 1.0 - (dist / self.config.address_dim)
            distances.append((i, sim, loc))

        # Sort by similarity (descending)
        distances.sort(key=lambda x: x[1], reverse=True)

        # Return top-k with their stored data
        results = []
        for i, sim, loc in distances[:top_k]:
            data = np.sign(loc.counters)
            data[data == 0] = 1
            results.append((i, sim, data))

        return results

    def get_statistics(self) -> Dict[str, Any]:
        """Get memory statistics."""
        access_counts = [loc.access_count for loc in self.locations]
        counter_magnitudes = [
            np.mean(np.abs(loc.counters))
            for loc in self.locations
        ]

        return {
            "num_locations": len(self.locations),
            "address_dim": self.config.address_dim,
            "data_dim": self.config.data_dim,
            "access_radius": self.config.access_radius,
            "total_writes": sum(access_counts),
            "mean_access_count": np.mean(access_counts),
            "max_access_count": max(access_counts),
            "locations_never_accessed": sum(1 for c in access_counts if c == 0),
            "mean_counter_magnitude": np.mean(counter_magnitudes),
            "max_counter_magnitude": max(counter_magnitudes),
        }

    def save_state(self) -> Dict[str, Any]:
        """Save memory state for persistence."""
        return {
            "config": self.config.__dict__,
            "locations": [
                {
                    "address": loc.address.tolist(),
                    "counters": loc.counters.tolist(),
                    "access_count": loc.access_count
                }
                for loc in self.locations
            ]
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load memory state from saved dict."""
        self.locations = []
        for loc_dict in state["locations"]:
            self.locations.append(SDMLocation(
                address=np.array(loc_dict["address"], dtype=np.int8),
                counters=np.array(loc_dict["counters"], dtype=np.int16),
                access_count=loc_dict["access_count"]
            ))

    def clear(self) -> None:
        """Clear all memories (reset counters to zero)."""
        for loc in self.locations:
            loc.counters = np.zeros(self.config.data_dim, dtype=np.int16)
            loc.access_count = 0
