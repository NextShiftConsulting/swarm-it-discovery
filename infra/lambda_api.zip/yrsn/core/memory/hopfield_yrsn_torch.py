"""
YRSN-Enhanced Hopfield Memory - PyTorch Implementation

Same YRSN architecture as hopfield_yrsn.py, but with PyTorch autograd
for proper gradient computation and GPU acceleration.

Architecture:
    Input → FeatureExtractor → R/S/N Decomposition → Weighted Hopfield → Class

Key Innovation (preserved from numpy version):
    Standard Hopfield: attention = softmax(β * X^T @ query)
    YRSN Hopfield:     attention = softmax(β * X^T @ (w_R*R + w_S*S + w_N*N))

Where w_R >> w_S > w_N, so signal dominates over noise.

Usage:
    from yrsn.core.memory import HopfieldYRSNTorch

    model = HopfieldYRSNTorch(input_dim=54, hidden_dim=256)
    model.fit(X_train, y_train, X_val, y_val)
    predictions = model.predict(X_test)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Tuple
import numpy as np


@dataclass
class YRSNHopfieldConfig:
    """Configuration for YRSN-enhanced Hopfield memory."""

    # Dimensions
    input_dim: int = 54
    hidden_dim: int = 256

    # R/S/N ratios (should sum to 1.0)
    r_ratio: float = 0.5
    s_ratio: float = 0.35
    n_ratio: float = 0.15

    # R/S/N attention weights (the key innovation!)
    r_weight: float = 2.0
    s_weight: float = 1.0
    n_weight: float = 0.1

    # Hopfield
    n_prototypes_per_class: int = 10
    beta: float = 10.0

    # Training
    epochs: int = 200
    batch_size: int = 128
    lr: float = 0.001
    weight_decay: float = 1e-4
    patience: int = 25

    # Architecture
    n_layers: int = 2
    dropout: float = 0.1

    # Regularization
    r_reg: float = 0.001    # L2 on R
    s_reg: float = 0.01     # L1 sparsity on S
    n_reg: float = 0.1      # Heavy L2 on N

    def __post_init__(self):
        total = self.r_ratio + self.s_ratio + self.n_ratio
        self.r_ratio /= total
        self.s_ratio /= total
        self.n_ratio /= total

        self.r_dim = int(self.hidden_dim * self.r_ratio)
        self.s_dim = int(self.hidden_dim * self.s_ratio)
        self.n_dim = self.hidden_dim - self.r_dim - self.s_dim


class RSNProjection(nn.Module):
    """Projects features into R/S/N subspaces."""

    def __init__(self, input_dim: int, r_dim: int, s_dim: int, n_dim: int):
        super().__init__()
        self.r_dim = r_dim
        self.s_dim = s_dim
        self.n_dim = n_dim

        self.proj_r = nn.Linear(input_dim, r_dim)
        self.proj_s = nn.Linear(input_dim, s_dim)
        self.proj_n = nn.Linear(input_dim, n_dim)

        # Initialize with small weights
        nn.init.xavier_uniform_(self.proj_r.weight, gain=0.5)
        nn.init.xavier_uniform_(self.proj_s.weight, gain=0.5)
        nn.init.xavier_uniform_(self.proj_n.weight, gain=0.1)  # N starts smaller

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Project to R, S, N subspaces."""
        R = self.proj_r(x)
        S = self.proj_s(x)
        N = self.proj_n(x)
        return R, S, N

    def forward_weighted(
        self,
        x: torch.Tensor,
        r_weight: float,
        s_weight: float,
        n_weight: float
    ) -> torch.Tensor:
        """Project and combine with R/S/N weights."""
        R, S, N = self.forward(x)
        return torch.cat([R * r_weight, S * s_weight, N * n_weight], dim=-1)


class FeatureExtractor(nn.Module):
    """MLP feature extractor."""

    def __init__(self, input_dim: int, hidden_dim: int, n_layers: int = 2, dropout: float = 0.1):
        super().__init__()

        layers = []
        dims = [input_dim] + [hidden_dim] * n_layers

        for i in range(n_layers):
            layers.append(nn.Linear(dims[i], dims[i+1]))
            if i < n_layers - 1:
                layers.append(nn.ReLU())
                layers.append(nn.Dropout(dropout))

        self.net = nn.Sequential(*layers)

        # Initialize
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class HopfieldYRSNTorch(nn.Module):
    """
    YRSN-Enhanced Hopfield Memory with PyTorch autograd.

    Key features:
    1. Learnable feature extraction (MLP)
    2. R/S/N signal decomposition
    3. Weighted Hopfield attention (R boosted, N suppressed)
    4. Learnable prototypes per class

    The R/S/N weighting ensures the model focuses on signal while ignoring noise.
    """

    def __init__(self, config: Optional[YRSNHopfieldConfig] = None, **kwargs):
        super().__init__()

        if config is None:
            config = YRSNHopfieldConfig(**kwargs)
        self.config = config
        self.c = config

        # Feature extractor
        self.feature_extractor = FeatureExtractor(
            config.input_dim, config.hidden_dim, config.n_layers, config.dropout
        )

        # R/S/N projection
        self.rsn_projection = RSNProjection(
            config.hidden_dim, config.r_dim, config.s_dim, config.n_dim
        )

        # Prototypes (initialized during fit)
        self.prototypes = None  # nn.Parameter
        self.proto_labels = None
        self.classes = []
        self.n_classes = 0

        # Training state
        self._fitted = False
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def _initialize_prototypes(self, X: torch.Tensor, y: torch.Tensor):
        """Initialize prototypes from training data."""
        self.classes = sorted(list(set(y.cpu().numpy())))
        self.n_classes = len(self.classes)
        n_proto = self.c.n_prototypes_per_class
        total_dim = self.c.r_dim + self.c.s_dim + self.c.n_dim

        # Compute weighted features for initialization
        with torch.no_grad():
            features = self.feature_extractor(X)
            weighted = self.rsn_projection.forward_weighted(
                features, self.c.r_weight, self.c.s_weight, self.c.n_weight
            )

        prototypes = []
        labels = []

        for c in self.classes:
            mask = (y == c)
            class_features = weighted[mask]

            if len(class_features) >= n_proto:
                # Diverse sampling
                indices = self._diverse_sample(class_features, n_proto)
                protos = class_features[indices]
            else:
                # Repeat if not enough
                repeat = (n_proto // len(class_features)) + 1
                protos = class_features.repeat(repeat, 1)[:n_proto]

            # Normalize
            protos = F.normalize(protos, dim=-1)
            prototypes.append(protos)
            labels.extend([c] * n_proto)

        self.prototypes = nn.Parameter(torch.cat(prototypes, dim=0))
        self.proto_labels = torch.tensor(labels, device=self.device)

    def _diverse_sample(self, X: torch.Tensor, n: int) -> torch.Tensor:
        """Farthest point sampling."""
        n_samples = len(X)
        if n >= n_samples:
            return torch.arange(n_samples, device=X.device)

        selected = [torch.randint(n_samples, (1,)).item()]

        for _ in range(n - 1):
            min_dists = torch.full((n_samples,), float('inf'), device=X.device)
            for idx in selected:
                dists = torch.norm(X - X[idx], dim=1)
                min_dists = torch.minimum(min_dists, dists)
            min_dists[selected] = -1
            selected.append(min_dists.argmax().item())

        return torch.tensor(selected, device=X.device)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass with R/S/N decomposition.

        Returns:
            logits: (batch, n_classes)
            info: dict with R, S, N, attention
        """
        # Feature extraction
        features = self.feature_extractor(x)

        # R/S/N decomposition
        R, S, N = self.rsn_projection(features)

        # Weighted combination
        weighted = torch.cat([
            R * self.c.r_weight,
            S * self.c.s_weight,
            N * self.c.n_weight
        ], dim=-1)

        # Normalize
        weighted_norm = F.normalize(weighted, dim=-1)

        # Normalize prototypes
        protos_norm = F.normalize(self.prototypes, dim=-1)

        # Hopfield attention
        similarities = weighted_norm @ protos_norm.T  # (batch, n_protos)
        attention = F.softmax(self.c.beta * similarities, dim=-1)

        # Aggregate to class logits
        logits = torch.zeros(x.shape[0], self.n_classes, device=x.device)
        for ci, c in enumerate(self.classes):
            class_mask = (self.proto_labels == c).float()
            logits[:, ci] = (attention * class_mask).sum(dim=-1)

        info = {
            'R': R, 'S': S, 'N': N,
            'weighted': weighted,
            'attention': attention,
        }

        return logits, info

    def compute_loss(
        self,
        logits: torch.Tensor,
        y: torch.Tensor,
        info: Dict[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute loss with R/S/N regularization.

        Loss = CE + λ_r*||R||² + λ_s*||S||₁ + λ_n*||N||²
        """
        # Cross-entropy
        ce_loss = F.cross_entropy(logits, y)

        # R/S/N regularization
        r_reg = self.c.r_reg * torch.mean(info['R'] ** 2)
        s_reg = self.c.s_reg * torch.mean(torch.abs(info['S']))  # L1 sparsity
        n_reg = self.c.n_reg * torch.mean(info['N'] ** 2)  # Heavy L2

        total_loss = ce_loss + r_reg + s_reg + n_reg

        losses = {
            'total': total_loss.item(),
            'ce': ce_loss.item(),
            'r_reg': r_reg.item(),
            's_reg': s_reg.item(),
            'n_reg': n_reg.item(),
        }

        return total_loss, losses

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: Optional[np.ndarray] = None,
        y_val: Optional[np.ndarray] = None,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """Train the model."""
        self.to(self.device)

        # Convert to tensors
        X_train_t = torch.tensor(X_train, dtype=torch.float32, device=self.device)
        y_train_t = torch.tensor(y_train, dtype=torch.long, device=self.device)

        if X_val is None:
            X_val, y_val = X_train, y_train
        X_val_t = torch.tensor(X_val, dtype=torch.float32, device=self.device)
        y_val_t = torch.tensor(y_val, dtype=torch.long, device=self.device)

        # Initialize prototypes
        self._initialize_prototypes(X_train_t, y_train_t)
        self._fitted = True

        # DataLoader
        dataset = TensorDataset(X_train_t, y_train_t)
        loader = DataLoader(dataset, batch_size=self.c.batch_size, shuffle=True)

        # Optimizer
        optimizer = torch.optim.AdamW(
            self.parameters(),
            lr=self.c.lr,
            weight_decay=self.c.weight_decay
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=self.c.epochs, eta_min=self.c.lr * 0.01
        )

        # Training state
        best_acc = 0.0
        best_state = None
        patience_counter = 0
        history = {'loss': [], 'train_acc': [], 'val_acc': []}

        if verbose:
            print(f"Training YRSN Hopfield (PyTorch)")
            print(f"  Device: {self.device}")
            print(f"  R/S/N dims: {self.c.r_dim}/{self.c.s_dim}/{self.c.n_dim}")
            print(f"  R/S/N weights: {self.c.r_weight}/{self.c.s_weight}/{self.c.n_weight}")
            print(f"  Prototypes: {self.c.n_prototypes_per_class} per class")
            print("-" * 60)

        for epoch in range(self.c.epochs):
            # Train
            self.train()
            epoch_loss = 0.0

            for X_batch, y_batch in loader:
                optimizer.zero_grad()

                logits, info = self.forward(X_batch)
                loss, _ = self.compute_loss(logits, y_batch, info)

                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.parameters(), 1.0)
                optimizer.step()

                # Re-normalize prototypes
                with torch.no_grad():
                    self.prototypes.data = F.normalize(self.prototypes.data, dim=-1)

                epoch_loss += loss.item()

            epoch_loss /= len(loader)
            scheduler.step()

            # Evaluate
            train_acc = self.score(X_train, y_train)
            val_acc = self.score(X_val, y_val)

            history['loss'].append(epoch_loss)
            history['train_acc'].append(train_acc)
            history['val_acc'].append(val_acc)

            if val_acc > best_acc:
                best_acc = val_acc
                best_state = {k: v.cpu().clone() for k, v in self.state_dict().items()}
                patience_counter = 0
            else:
                patience_counter += 1

            if verbose and (epoch + 1) % 20 == 0:
                print(f"  Epoch {epoch+1:3d}: loss={epoch_loss:.4f}, "
                      f"train={train_acc:.1%}, val={val_acc:.1%}, best={best_acc:.1%}")

            if patience_counter >= self.c.patience:
                if verbose:
                    print(f"  Early stopping at epoch {epoch + 1}")
                break

        # Restore best
        if best_state:
            self.load_state_dict(best_state)
            self.to(self.device)

        if verbose:
            print("-" * 60)
            print(f"  Best validation accuracy: {best_acc:.1%}")

        return {
            'best_accuracy': best_acc,
            'epochs': epoch + 1,
            'history': history,
        }

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels."""
        self.eval()
        with torch.no_grad():
            X_t = torch.tensor(X, dtype=torch.float32, device=self.device)
            logits, _ = self.forward(X_t)
            preds = logits.argmax(dim=-1).cpu().numpy()
        return np.array([self.classes[i] for i in preds])

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities."""
        self.eval()
        with torch.no_grad():
            X_t = torch.tensor(X, dtype=torch.float32, device=self.device)
            logits, _ = self.forward(X_t)
            probs = F.softmax(logits, dim=-1).cpu().numpy()
        return probs

    def score(self, X: np.ndarray, y: np.ndarray) -> float:
        """Compute accuracy."""
        preds = self.predict(X)
        return np.mean(preds == y)

    def decompose(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Decompose input into R/S/N components."""
        self.eval()
        with torch.no_grad():
            X_t = torch.tensor(X, dtype=torch.float32, device=self.device)
            features = self.feature_extractor(X_t)
            R, S, N = self.rsn_projection(features)
        return R.cpu().numpy(), S.cpu().numpy(), N.cpu().numpy()

    def get_rsn_metrics(self, X: np.ndarray) -> Dict[str, float]:
        """Get R/S/N quality metrics."""
        R, S, N = self.decompose(X)

        r_strength = np.mean(np.linalg.norm(R, axis=1))
        s_sparsity = np.mean(np.abs(S) < 0.1)
        n_magnitude = np.mean(np.linalg.norm(N, axis=1))

        total = r_strength + np.mean(np.linalg.norm(S, axis=1)) + n_magnitude
        signal_ratio = r_strength / (total + 1e-8)

        return {
            'r_strength': float(r_strength),
            's_sparsity': float(s_sparsity),
            'n_magnitude': float(n_magnitude),
            'signal_ratio': float(signal_ratio),
        }

    # =========================================================================
    # State Persistence (IConsolidatable interface)
    # =========================================================================

    def save_state(self) -> Dict[str, Any]:
        """
        Save model state for persistence.

        Returns:
            Dict containing model weights, config, and training state
        """
        return {
            'config': {
                'input_dim': self.config.input_dim,
                'hidden_dim': self.config.hidden_dim,
                'r_ratio': self.config.r_ratio,
                's_ratio': self.config.s_ratio,
                'n_ratio': self.config.n_ratio,
                'r_weight': self.config.r_weight,
                's_weight': self.config.s_weight,
                'n_weight': self.config.n_weight,
                'n_prototypes_per_class': self.config.n_prototypes_per_class,
                'beta': self.config.beta,
            },
            'state_dict': {k: v.cpu().numpy() for k, v in self.state_dict().items()},
            'classes': self.classes,
            'n_classes': self.n_classes,
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """
        Load model state from saved dict.

        Args:
            state: From save_state()
        """
        # Restore classes
        self.classes = state.get('classes', [])
        self.n_classes = state.get('n_classes', 0)

        # Restore model weights
        state_dict = {
            k: torch.tensor(v, device=self.device)
            for k, v in state['state_dict'].items()
        }
        self.load_state_dict(state_dict)


# =============================================================================
# Factory
# =============================================================================

def create_hopfield_yrsn_torch(
    input_dim: int = 54,
    hidden_dim: int = 256,
    **kwargs
) -> HopfieldYRSNTorch:
    """Create YRSN Hopfield with PyTorch backend."""
    return HopfieldYRSNTorch(config=YRSNHopfieldConfig(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        **kwargs
    ))


__all__ = [
    'YRSNHopfieldConfig',
    'RSNProjection',
    'FeatureExtractor',
    'HopfieldYRSNTorch',
    'create_hopfield_yrsn_torch',
]
