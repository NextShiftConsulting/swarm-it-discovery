"""
UniversalBaseLearner - BaseLearner with universal defaults.

This class provides default implementations for all abstract methods,
making BaseLearner usable out-of-the-box without requiring subclassing.

Key Features:
- Automatic input type detection and encoding
- Automatic quality computation via YRSN decomposition
- Default binary reward function
- Works with text, dict, list, numpy arrays
"""

from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
from .base_learner import BaseLearner, BaseLearnerConfig, PredictionResult, LearningResult


class UniversalBaseLearner(BaseLearner):
    """
    BaseLearner with universal defaults - works out-of-the-box.
    
    Provides default implementations for:
    - encode_context(): Automatic encoding from common input types
    - compute_quality(): Automatic quality via YRSN decomposition
    - compute_reward(): Default binary reward (correct=+1, incorrect=-1)
    
    Usage:
        from yrsn.core.memory import UniversalBaseLearner, BaseLearnerConfig
        
        # Works with any input type
        learner = UniversalBaseLearner(
            labels=["A", "B", "C"],
            config=BaseLearnerConfig(enable_control_constraints=True)
        )
        
        # Automatic encoding and quality computation
        result = learner.predict(content="text here", query="question")
    """
    
    def __init__(
        self,
        labels: List[str],
        config: Optional[BaseLearnerConfig] = None
    ):
        """
        Initialize UniversalBaseLearner.
        
        Args:
            labels: List of valid labels for this domain
            config: Optional configuration (defaults created if None)
        """
        # Set LABELS before calling super().__init__()
        self.LABELS = labels
        
        super().__init__(config)
        
        # Initialize universal encoder
        self._encoder_dim = config.context_dim if config else 256
    
    def encode_context(self, **kwargs) -> Tuple[np.ndarray, np.ndarray]:
        """
        Universal context encoding - works with any input type.
        
        Supported input types:
        - str: Text content
        - dict: {"content": str, "query": str, ...}
        - list: List of strings
        - np.ndarray: Direct vector input
        
        Args:
            **kwargs: Input data (content, text, query, embedding, etc.)
        
        Returns:
            Tuple of (context_vector, binary_address)
        """
        # Extract content from various possible keys
        content = kwargs.get('content') or kwargs.get('text') or kwargs.get('input')
        query = kwargs.get('query', '')
        
        # Handle different input types
        if content is None:
            # Try to extract from kwargs directly
            if 'embedding' in kwargs:
                embedding = kwargs['embedding']
                if isinstance(embedding, (list, np.ndarray)):
                    vec = np.array(embedding, dtype=np.float32)
                    if vec.ndim > 1:
                        vec = vec.flatten()
                    # Pad or truncate to context_dim
                    if len(vec) > self._encoder_dim:
                        vec = vec[:self._encoder_dim]
                    else:
                        vec = np.pad(vec, (0, self._encoder_dim - len(vec)), 'constant')
                    return vec, self._vector_to_binary(vec)
        
        # Convert to string if needed
        if content is None:
            # Fallback: use kwargs as string representation
            content = str(kwargs)
        elif not isinstance(content, str):
            if isinstance(content, dict):
                content = content.get('content', content.get('text', str(content)))
            elif isinstance(content, (list, tuple)):
                content = ' '.join(str(x) for x in content)
            else:
                content = str(content)
        
        # Simple hash-based encoding (can be improved with actual embeddings)
        context_vec = self._text_to_vector(content, query)
        binary_addr = self._vector_to_binary(context_vec)
        
        return context_vec, binary_addr
    
    def _text_to_vector(self, text: str, query: str = '') -> np.ndarray:
        """
        Convert text to vector using simple hash-based encoding.
        
        TODO: Replace with actual embedding model if available.
        """
        # Combine text and query
        combined = f"{text} {query}".strip()
        
        # Simple hash-based encoding
        vec = np.zeros(self._encoder_dim, dtype=np.float32)
        
        # Use character-level hashing
        for i, char in enumerate(combined[:self._encoder_dim * 10]):
            idx = hash(char) % self._encoder_dim
            vec[idx] += 1.0
        
        # Normalize
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        
        return vec
    
    def _vector_to_binary(self, vec: np.ndarray) -> np.ndarray:
        """Convert float vector to binary address."""
        # Threshold at 0 to create binary vector
        binary = (vec > 0).astype(np.int32)
        return binary
    
    def compute_quality(self, **kwargs) -> float:
        """
        Universal quality computation via YRSN decomposition.
        
        Automatically extracts content and query, then runs YRSN decomposition
        to compute quality α = R/(R+S+N).
        
        Args:
            **kwargs: Input data (content, text, query, etc.)
        
        Returns:
            Quality score α in [0, 1]
        """
        from yrsn.core import decompose
        
        # Extract content and query
        content = kwargs.get('content') or kwargs.get('text') or kwargs.get('input', '')
        query = kwargs.get('query', '')
        
        # Convert to string if needed
        if not isinstance(content, str):
            if isinstance(content, dict):
                content = content.get('content', content.get('text', str(content)))
            elif isinstance(content, (list, tuple)):
                content = ' '.join(str(x) for x in content)
            else:
                content = str(content)
        
        # Run YRSN decomposition
        try:
            score = decompose(content, query=query)
            return score.alpha
        except Exception:
            # Fallback: return neutral quality if decomposition fails
            return 0.5
    
    def compute_reward(
        self,
        predicted: str,
        actual: str,
        feedback: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        Default binary reward function.
        
        - Correct prediction: +1.0
        - Incorrect prediction: -1.0
        - Optional reward shaping via feedback
        
        Args:
            predicted: Predicted label
            actual: Ground truth label
            feedback: Optional feedback dict with 'reward_boost' key
        
        Returns:
            Reward value
        """
        # Base binary reward
        base_reward = 1.0 if predicted == actual else -1.0
        
        # Apply reward shaping if provided
        if feedback and 'reward_boost' in feedback:
            base_reward *= feedback['reward_boost']
        
        # Apply confidence boost if provided
        if feedback and 'confidence' in feedback:
            confidence = feedback['confidence']
            base_reward *= (0.5 + 0.5 * confidence)  # Scale by confidence
        
        return base_reward
    
    def apply_routing(
        self,
        label: str,
        confidence: float,
        margin: float,
        tau: float,
        phase: str,
        **kwargs
    ) -> str:
        """
        Default routing logic - returns label as-is.
        
        Subclasses can override for domain-specific routing.
        
        Args:
            label: Best label from memory
            confidence: Confidence in label
            margin: Gap to second-best
            tau: Current temperature
            phase: Quality phase
        
        Returns:
            Final routing decision
        """
        # Default: trust the memory system
        return label



