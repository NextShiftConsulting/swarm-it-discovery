"""
Prediction methods for EWC and Replay layers.

These layers are currently only used for learning, but can contribute
to predictions in the ensemble:

1. Replay: k-NN prediction from similar past experiences
2. EWC: Prediction from stored task memories (if available)
"""

from typing import Dict, List, Optional, Tuple, Any
import numpy as np
from collections import Counter

from .replay import PrioritizedReplayBuffer, Experience
from .ewc import ElasticWeightConsolidation


def predict_from_replay(
    replay: PrioritizedReplayBuffer,
    context: np.ndarray,
    labels: List[str],
    k: int = 5,
    similarity_threshold: float = 0.7
) -> Tuple[Optional[str], float, Dict[str, float]]:
    """
    Predict label from Replay buffer using k-nearest neighbors.
    
    Finds k most similar past experiences and predicts based on their outcomes.
    
    Args:
        replay: PrioritizedReplayBuffer instance
        context: Current context vector
        labels: List of all possible labels
        k: Number of neighbors to consider
        similarity_threshold: Minimum similarity to consider
    
    Returns:
        Tuple of (best_label, confidence, label_probabilities)
        Returns (None, 0.0, {}) if no similar experiences found
    """
    if len(replay.experiences) == 0:
        return None, 0.0, {label: 0.0 for label in labels}
    
    # Find k most similar experiences
    similarities = []
    for exp in replay.experiences:
        # Cosine similarity
        dot_product = np.dot(context, exp.context)
        norm_context = np.linalg.norm(context)
        norm_exp = np.linalg.norm(exp.context)
        
        if norm_context > 0 and norm_exp > 0:
            similarity = dot_product / (norm_context * norm_exp)
            if similarity >= similarity_threshold:
                similarities.append((similarity, exp))
    
    if not similarities:
        return None, 0.0, {label: 0.0 for label in labels}
    
    # Sort by similarity and take top k
    similarities.sort(key=lambda x: x[0], reverse=True)
    top_k = similarities[:k]
    
    # Weight by similarity and priority
    label_scores: Dict[str, float] = {label: 0.0 for label in labels}
    total_weight = 0.0
    
    for similarity, exp in top_k:
        # Weight = similarity * priority
        weight = similarity * exp.priority
        outcome = exp.outcome
        
        if outcome in label_scores:
            label_scores[outcome] += weight
            total_weight += weight
    
    # Normalize to probabilities
    if total_weight > 0:
        label_probs = {label: score / total_weight for label, score in label_scores.items()}
    else:
        label_probs = {label: 1.0 / len(labels) for label in labels}
    
    # Get best label
    best_label = max(label_probs, key=label_probs.get)
    confidence = label_probs[best_label]
    
    return best_label, confidence, label_probs


def predict_from_ewc(
    ewc: ElasticWeightConsolidation,
    context: np.ndarray,
    labels: List[str]
) -> Tuple[Optional[str], float, Dict[str, float]]:
    """
    Predict label from EWC task memories.
    
    EWC stores optimal weights for past tasks. We can use these to make
    predictions by finding the task whose weights best match the current context.
    
    Note: This is a simplified approach. A full implementation would require
    a model architecture to use the stored weights.
    
    Args:
        ewc: ElasticWeightConsolidation instance
        context: Current context vector
        labels: List of all possible labels
        (Note: EWC doesn't store labels directly, so this is limited)
    
    Returns:
        Tuple of (best_label, confidence, label_probabilities)
        Returns (None, 0.0, {}) if no task memories available
    """
    if not ewc.task_memories:
        return None, 0.0, {label: 0.0 for label in labels}
    
    # EWC stores optimal weights, not predictions directly
    # This is a limitation: we can't directly predict from EWC weights
    # without a model architecture.
    
    # Option 1: Use current weights (if they're set)
    # This assumes weights have been learned and can be used for prediction
    if ewc.weights is not None and len(ewc.weights) > 0:
        # Simple dot product prediction (assumes weights are label vectors)
        # This is a placeholder - actual implementation depends on model architecture
        if len(ewc.weights) == len(context):
            # Assume weights are label vectors
            scores = np.dot(context, ewc.weights)
            
            # Map to labels (this is a simplification)
            # In practice, you'd need a proper model architecture
            label_probs = {label: 0.0 for label in labels}
            
            # If weights match label count, use directly
            if len(labels) == len(ewc.weights):
                for i, label in enumerate(labels):
                    label_probs[label] = float(scores[i])
            else:
                # Fallback: uniform distribution weighted by task importance
                total_importance = sum(m.importance for m in ewc.task_memories)
                uniform_prob = 1.0 / len(labels)
                
                # Weight by average task importance
                avg_importance = total_importance / len(ewc.task_memories) if ewc.task_memories else 1.0
                for label in labels:
                    label_probs[label] = uniform_prob * avg_importance
            
            # Normalize
            total = sum(label_probs.values())
            if total > 0:
                label_probs = {k: v / total for k, v in label_probs.items()}
            else:
                label_probs = {label: 1.0 / len(labels) for label in labels}
            
            best_label = max(label_probs, key=label_probs.get)
            confidence = label_probs[best_label]
            
            return best_label, confidence, label_probs
    
    # No weights available
    return None, 0.0, {label: 0.0 for label in labels}


def combine_all_layer_predictions(
    sdm_label: Optional[str],
    sdm_conf: float,
    hopfield_probs: Dict[str, float],
    replay_label: Optional[str],
    replay_conf: float,
    replay_probs: Dict[str, float],
    ewc_label: Optional[str],
    ewc_conf: float,
    ewc_probs: Dict[str, float],
    weights: Dict[str, float],
    labels: List[str]
) -> Dict[str, float]:
    """
    Combine predictions from all 4 layers: SDM, Hopfield, Replay, EWC.
    
    Args:
        sdm_label: SDM predicted label
        sdm_conf: SDM confidence
        hopfield_probs: Hopfield label probabilities
        replay_label: Replay predicted label (from k-NN)
        replay_conf: Replay confidence
        replay_probs: Replay label probabilities
        ewc_label: EWC predicted label (if available)
        ewc_conf: EWC confidence
        ewc_probs: EWC label probabilities
        weights: Layer weights {'sdm', 'hopfield', 'replay', 'ewc'}
        labels: List of all possible labels
    
    Returns:
        Combined label probabilities
    """
    # Initialize with small prior
    combined = {label: 0.01 for label in labels}
    
    # SDM contribution
    if sdm_label and sdm_label in combined:
        combined[sdm_label] += weights.get('sdm', 0.0) * sdm_conf
    
    # Hopfield contribution
    hop_weight = weights.get('hopfield', 0.0)
    for label, prob in hopfield_probs.items():
        if label in combined:
            combined[label] += hop_weight * prob
    
    # Replay contribution (k-NN from similar experiences)
    if replay_label and replay_label in combined:
        replay_weight = weights.get('replay', 0.0)
        combined[replay_label] += replay_weight * replay_conf
    
    # Also add Replay probabilities (weighted)
    replay_weight = weights.get('replay', 0.0)
    for label, prob in replay_probs.items():
        if label in combined:
            combined[label] += replay_weight * prob * 0.5  # Half weight for probabilities
    
    # EWC contribution (from task memories)
    if ewc_label and ewc_label in combined:
        ewc_weight = weights.get('ewc', 0.0)
        combined[ewc_label] += ewc_weight * ewc_conf
    
    # Also add EWC probabilities
    ewc_weight = weights.get('ewc', 0.0)
    for label, prob in ewc_probs.items():
        if label in combined:
            combined[label] += ewc_weight * prob * 0.5  # Half weight for probabilities
    
    # Normalize
    total = sum(combined.values())
    if total > 0:
        combined = {k: v / total for k, v in combined.items()}
    
    return combined



