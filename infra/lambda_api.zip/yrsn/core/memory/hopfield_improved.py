"""
Improved Hopfield Network with Collapse Prevention
==================================================

Adds stability mechanisms to prevent single-class dominance:
- Per-class memory quotas (balanced capacity)
- Gated writes (only store if adds novelty)
- Temperature-controlled retrieval (soften or abstain when quality flags indicate overlap)

Based on insights from medical classification collapse incident.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict, Any
from collections import defaultdict
import numpy as np

from .hopfield import (
    ModernHopfieldNetwork,
    HopfieldConfig,
    StoredPattern,
)


@dataclass
class ImprovedHopfieldConfig(HopfieldConfig):
    """Extended config with collapse prevention mechanisms."""
    
    # Per-class quotas
    use_class_quotas: bool = True
    quota_per_class: int = 100  # N slots per class (balanced capacity)
    quota_enforcement: str = "strict"  # "strict" or "soft" (soft allows overflow)
    
    # Gated writes
    use_gated_writes: bool = True
    novelty_threshold: float = 0.3  # Minimum dissimilarity to existing same-class patterns
    similarity_metric: str = "cosine"  # "cosine" or "euclidean"
    
    # Temperature-controlled retrieval
    use_temp_controlled_retrieval: bool = True
    overlap_softening_factor: float = 0.5  # Reduce β when overlap detected
    min_retrieval_confidence: float = 0.6  # Minimum confidence for retrieval


class ImprovedHopfieldNetwork(ModernHopfieldNetwork):
    """
    Enhanced Hopfield Network with collapse prevention.
    
    Prevents single-class dominance through:
    1. Per-class memory quotas
    2. Gated writes (novelty checking)
    3. Temperature-controlled retrieval
    """
    
    def __init__(self, config: Optional[ImprovedHopfieldConfig] = None):
        super().__init__(config or ImprovedHopfieldConfig())
        self.config: ImprovedHopfieldConfig = self.config
        
        # Per-class tracking
        self._class_counts: Dict[str, int] = defaultdict(int)
        self._class_patterns: Dict[str, List[int]] = defaultdict(list)  # label -> pattern indices
        
    def store(
        self,
        pattern: np.ndarray,
        label: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        strength: float = 1.0,
        check_novelty: bool = True,
    ) -> Optional[int]:
        """
        Store a pattern with gated writes and quota management.
        
        Parameters
        ----------
        pattern : np.ndarray
            Pattern vector to store
        label : str
            Pattern label (class identifier)
        metadata : dict, optional
            Additional metadata
        strength : float
            Pattern strength
        check_novelty : bool
            Whether to check novelty before storing
            
        Returns
        -------
        int or None
            Index of stored pattern, or None if rejected
        """
        # Normalize pattern
        norm = np.linalg.norm(pattern)
        if norm > 0:
            pattern = pattern / norm
        else:
            return None  # Reject zero patterns
        
        # Check per-class quota
        if self.config.use_class_quotas:
            if not self._check_quota(label):
                # Quota exceeded - remove oldest pattern of this class
                if self.config.quota_enforcement == "strict":
                    removed = self._remove_oldest_of_class(label)
                    if removed is None:
                        return None  # Can't remove, reject new pattern
                # Soft enforcement allows overflow (just log)
        
        # Check novelty (gated write)
        if self.config.use_gated_writes and check_novelty:
            if not self._is_novel(pattern, label):
                # Pattern too similar to existing same-class patterns
                return None  # Reject duplicate
        
        # Store pattern
        stored = StoredPattern(
            pattern=pattern.astype(np.float32),
            label=label,
            metadata=(metadata or {}).copy(),
            strength=strength
        )
        
        pattern_idx = len(self.patterns)
        self.patterns.append(stored)
        self._matrix_dirty = True
        
        # Update class tracking
        self._class_counts[label] += 1
        self._class_patterns[label].append(pattern_idx)
        
        # Trim if exceeding global max
        if len(self.patterns) > self.config.max_patterns:
            # Remove oldest/weakest pattern across all classes
            self.patterns.sort(key=lambda p: p.strength)
            removed_pattern = self.patterns.pop(0)
            self._class_counts[removed_pattern.label] -= 1
            # Update indices in class_patterns
            for label, indices in self._class_patterns.items():
                self._class_patterns[label] = [
                    idx - 1 if idx > 0 else None
                    for idx in indices
                    if idx != 0
                ]
                self._class_patterns[label] = [idx for idx in self._class_patterns[label] if idx is not None]
        
        return pattern_idx
    
    def _check_quota(self, label: str) -> bool:
        """Check if class has quota available."""
        return self._class_counts[label] < self.config.quota_per_class
    
    def _remove_oldest_of_class(self, label: str) -> Optional[int]:
        """Remove oldest pattern of given class."""
        if label not in self._class_patterns or not self._class_patterns[label]:
            return None
        
        # Find oldest pattern of this class (lowest index = oldest)
        oldest_idx = min(self._class_patterns[label])
        
        # Remove it
        removed = self.patterns.pop(oldest_idx)
        self._class_counts[label] -= 1
        self._class_patterns[label].remove(oldest_idx)
        
        # Update indices for all classes
        for lbl, indices in self._class_patterns.items():
            self._class_patterns[lbl] = [idx - 1 if idx > oldest_idx else idx for idx in indices]
        
        self._matrix_dirty = True
        return oldest_idx
    
    def _is_novel(self, pattern: np.ndarray, label: str) -> bool:
        """
        Check if pattern is novel (sufficiently different from existing same-class patterns).
        
        Returns True if pattern should be stored (is novel).
        """
        if label not in self._class_patterns or not self._class_patterns[label]:
            return True  # No existing patterns of this class, always novel
        
        # Compare with existing same-class patterns
        existing_indices = self._class_patterns[label]
        if not existing_indices:
            return True
        
        existing_patterns = np.array([self.patterns[idx].pattern for idx in existing_indices])
        
        # Compute similarities
        if self.config.similarity_metric == "cosine":
            # Cosine similarity (patterns already normalized)
            similarities = existing_patterns @ pattern
        else:  # euclidean
            distances = np.linalg.norm(existing_patterns - pattern, axis=1)
            similarities = 1.0 / (1.0 + distances)  # Convert distance to similarity
        
        max_similarity = np.max(similarities)
        
        # Novel if max similarity is below threshold
        # (i.e., dissimilarity = 1 - similarity > novelty_threshold)
        return (1.0 - max_similarity) >= self.config.novelty_threshold
    
    def retrieve(
        self,
        query: np.ndarray,
        beta: Optional[float] = None,
        return_soft: bool = False,
        quality_flags: Optional[Dict[str, bool]] = None,
    ) -> Tuple[StoredPattern, float, np.ndarray]:
        """
        Retrieve pattern with temperature-controlled retrieval.
        
        Parameters
        ----------
        query : np.ndarray
            Query vector
        beta : float, optional
            Inverse temperature (1/τ from YRSN)
        return_soft : bool
            If True, return soft attention weights
        quality_flags : dict, optional
            Quality flags indicating overlap/poison/halluc
            Keys: "overlap", "poison", "halluc", "ood"
            
        Returns
        -------
        tuple[StoredPattern, float, np.ndarray]
            (best_pattern, confidence, attention_weights)
        """
        if not self.patterns:
            raise ValueError("No patterns stored")
        
        beta = beta if beta is not None else self.config.beta
        
        # Temperature-controlled retrieval: soften if overlap detected
        if self.config.use_temp_controlled_retrieval and quality_flags:
            if quality_flags.get("overlap", False) or quality_flags.get("poison", False):
                # Soften retrieval (reduce β = increase τ)
                beta = beta * self.config.overlap_softening_factor
        
        # Normalize query
        norm = np.linalg.norm(query)
        if norm > 0:
            query = query / norm
        
        # Run dynamics to converge
        final_state, _ = self.update(query, beta)
        
        # Compute attention weights
        X = self._build_pattern_matrix()
        similarities = X.T @ final_state
        exp_sim = np.exp(beta * (similarities - np.max(similarities)))
        attention = exp_sim / np.sum(exp_sim)
        
        # Best matching pattern
        best_idx = np.argmax(attention)
        confidence = float(attention[best_idx])
        
        # Check minimum confidence threshold
        if confidence < self.config.min_retrieval_confidence:
            # Confidence too low - return uniform distribution (abstain)
            uniform_attention = np.ones(len(self.patterns)) / len(self.patterns)
            return self.patterns[0], 1.0 / len(self.patterns), uniform_attention
        
        if return_soft:
            return self.patterns[best_idx], confidence, attention
        else:
            return self.patterns[best_idx], confidence, attention
    
    def get_class_distribution(self) -> Dict[str, int]:
        """Get current distribution of patterns per class."""
        return dict(self._class_counts)
    
    def get_class_balance_ratio(self) -> float:
        """
        Get class balance ratio (1.0 = perfectly balanced, 0.0 = completely imbalanced).
        
        Uses entropy: H = -Σ p_i log(p_i), normalized by max entropy log(n_classes)
        """
        if not self._class_counts:
            return 1.0
        
        total = sum(self._class_counts.values())
        if total == 0:
            return 1.0
        
        # Compute entropy
        probs = [count / total for count in self._class_counts.values()]
        entropy = -sum(p * np.log(p + 1e-10) for p in probs)
        
        # Normalize by max entropy (log of number of classes)
        n_classes = len(self._class_counts)
        max_entropy = np.log(n_classes) if n_classes > 1 else 1.0
        
        return entropy / max_entropy if max_entropy > 0 else 1.0
    
    def get_retrieval_mass_by_class(self, query: np.ndarray, beta: Optional[float] = None) -> Dict[str, float]:
        """
        Get retrieval mass (attention sum) per class.
        
        Useful for collapse detection: if one class dominates, collapse risk is high.
        """
        if not self.patterns:
            return {}
        
        _, _, attention = self.retrieve(query, beta, return_soft=True)
        
        # Aggregate attention by class
        class_masses = defaultdict(float)
        for i, pattern in enumerate(self.patterns):
            class_masses[pattern.label] += attention[i]
        
        return dict(class_masses)

