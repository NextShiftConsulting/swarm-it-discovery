"""
ConsolidationManager - Unified save/load across all YRSN memory layers.

Handles task transition persistence for:
- Memristor projection state (R/S/N weights)
- Experience replay buffer
- Hopfield patterns
- EWC Fisher matrices
- VLA node state

Usage:
    from yrsn.core.memory import ConsolidationManager

    # Create manager
    manager = ConsolidationManager(checkpoint_dir="./checkpoints")

    # Register components
    manager.register_memristor(projection)
    manager.register_replay_buffer(buffer)
    manager.register_vla_node(node)

    # Save all state on task transition
    manager.consolidate(task_id="pick_place")

    # Restore for new task (or same task resume)
    manager.restore(task_id="pick_place")
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Protocol, runtime_checkable
from pathlib import Path
import logging
import time

logger = logging.getLogger(__name__)


@runtime_checkable
class IConsolidatable(Protocol):
    """Interface for components that can be consolidated."""

    def save_state(self) -> Dict[str, Any]:
        """Save component state."""
        ...

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load component state."""
        ...


@dataclass
class ConsolidationConfig:
    """Configuration for consolidation manager."""

    checkpoint_dir: str = "./yrsn_checkpoints"
    compress: bool = True
    format: str = "pickle"  # "pickle", "json", "msgpack"
    max_checkpoints_per_task: int = 5  # Rolling window
    auto_consolidate_interval: int = 0  # 0 = disabled, N = every N ticks


@dataclass
class ConsolidationResult:
    """Result of a consolidation operation."""

    task_id: str
    timestamp: float
    path: Path
    components_saved: List[str]
    size_bytes: int
    duration_ms: float


class ConsolidationManager:
    """
    Unified manager for saving/loading all YRSN memory layers.

    Coordinates persistence across:
    - Memristor projections (hardware-faithful R/S/N)
    - Experience replay buffers (prioritized learning)
    - Hopfield networks (pattern memory)
    - EWC matrices (continual learning)
    - VLA nodes (control state)

    Supports:
    - Task-based checkpointing (save when switching tasks)
    - Rolling checkpoint window (limit disk usage)
    - Auto-consolidation (periodic saves during long tasks)
    - Cross-task transfer (load from different task)
    """

    def __init__(self, config: Optional[ConsolidationConfig] = None):
        self.config = config or ConsolidationConfig()
        self._checkpoint_dir = Path(self.config.checkpoint_dir)
        self._checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # Registered components
        self._memristors: Dict[str, Any] = {}
        self._replay_buffers: Dict[str, Any] = {}
        self._hopfield_nets: Dict[str, Any] = {}
        self._ewc_modules: Dict[str, Any] = {}
        self._vla_nodes: Dict[str, Any] = {}
        self._custom: Dict[str, IConsolidatable] = {}

        # State tracking
        self._tick_count = 0
        self._last_consolidation_tick = 0
        self._consolidation_history: List[ConsolidationResult] = []

    # =========================================================================
    # Registration
    # =========================================================================

    def register_memristor(self, name: str, projection: Any) -> None:
        """Register a memristor projection for consolidation."""
        self._memristors[name] = projection
        logger.debug(f"Registered memristor: {name}")

    def register_replay_buffer(self, name: str, buffer: Any) -> None:
        """Register a replay buffer for consolidation."""
        self._replay_buffers[name] = buffer
        logger.debug(f"Registered replay buffer: {name}")

    def register_hopfield(self, name: str, network: Any) -> None:
        """Register a Hopfield network for consolidation."""
        self._hopfield_nets[name] = network
        logger.debug(f"Registered Hopfield network: {name}")

    def register_ewc(self, name: str, module: Any) -> None:
        """Register an EWC module for consolidation."""
        self._ewc_modules[name] = module
        logger.debug(f"Registered EWC module: {name}")

    def register_vla_node(self, name: str, node: Any) -> None:
        """Register a VLA quality node for consolidation."""
        self._vla_nodes[name] = node
        logger.debug(f"Registered VLA node: {name}")

    def register_custom(self, name: str, component: IConsolidatable) -> None:
        """Register any component implementing IConsolidatable."""
        self._custom[name] = component
        logger.debug(f"Registered custom component: {name}")

    # =========================================================================
    # Consolidation (Save)
    # =========================================================================

    def consolidate(
        self,
        task_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ConsolidationResult:
        """
        Save all registered component states for a task.

        Args:
            task_id: Identifier for the task/skill
            metadata: Optional additional metadata

        Returns:
            ConsolidationResult with save details
        """
        from yrsn.hardware.serialization import save_memristor_state

        start_time = time.time()
        components_saved = []

        # Build unified state
        state = {
            "task_id": task_id,
            "timestamp": time.time(),
            "tick_count": self._tick_count,
            "components": {},
        }

        # Save memristors
        for name, proj in self._memristors.items():
            try:
                if hasattr(proj, "save_state"):
                    state["components"][f"memristor:{name}"] = proj.save_state()
                    components_saved.append(f"memristor:{name}")
            except Exception as e:
                logger.warning(f"Failed to save memristor {name}: {e}")

        # Save replay buffers
        for name, buffer in self._replay_buffers.items():
            try:
                if hasattr(buffer, "save_state"):
                    state["components"][f"replay:{name}"] = buffer.save_state()
                    components_saved.append(f"replay:{name}")
            except Exception as e:
                logger.warning(f"Failed to save replay buffer {name}: {e}")

        # Save Hopfield networks
        for name, net in self._hopfield_nets.items():
            try:
                if hasattr(net, "save_state"):
                    state["components"][f"hopfield:{name}"] = net.save_state()
                    components_saved.append(f"hopfield:{name}")
            except Exception as e:
                logger.warning(f"Failed to save Hopfield net {name}: {e}")

        # Save EWC modules
        for name, module in self._ewc_modules.items():
            try:
                if hasattr(module, "save_state"):
                    state["components"][f"ewc:{name}"] = module.save_state()
                    components_saved.append(f"ewc:{name}")
            except Exception as e:
                logger.warning(f"Failed to save EWC module {name}: {e}")

        # Save VLA nodes
        for name, node in self._vla_nodes.items():
            try:
                if hasattr(node, "save_checkpoint"):
                    # VLA nodes have their own checkpoint method
                    node.save_checkpoint()
                    components_saved.append(f"vla_node:{name}")
            except Exception as e:
                logger.warning(f"Failed to save VLA node {name}: {e}")

        # Save custom components
        for name, component in self._custom.items():
            try:
                state["components"][f"custom:{name}"] = component.save_state()
                components_saved.append(f"custom:{name}")
            except Exception as e:
                logger.warning(f"Failed to save custom component {name}: {e}")

        # Add metadata
        if metadata:
            state["metadata"] = metadata

        # Determine checkpoint path
        timestamp_str = time.strftime("%Y%m%d_%H%M%S")
        checkpoint_path = self._checkpoint_dir / f"{task_id}_{timestamp_str}.pkl.gz"

        # Save to file
        save_memristor_state(
            state,
            checkpoint_path,
            format=self.config.format,
            compress=self.config.compress,
        )

        # Cleanup old checkpoints
        self._cleanup_old_checkpoints(task_id)

        # Record result
        duration_ms = (time.time() - start_time) * 1000
        result = ConsolidationResult(
            task_id=task_id,
            timestamp=time.time(),
            path=checkpoint_path,
            components_saved=components_saved,
            size_bytes=checkpoint_path.stat().st_size,
            duration_ms=duration_ms,
        )
        self._consolidation_history.append(result)
        self._last_consolidation_tick = self._tick_count

        logger.info(
            f"Consolidated {len(components_saved)} components for '{task_id}' "
            f"({result.size_bytes} bytes, {duration_ms:.1f}ms)"
        )

        return result

    def _cleanup_old_checkpoints(self, task_id: str) -> None:
        """Remove old checkpoints beyond the rolling window."""
        pattern = f"{task_id}_*.pkl.gz"
        checkpoints = sorted(self._checkpoint_dir.glob(pattern))

        if len(checkpoints) > self.config.max_checkpoints_per_task:
            to_remove = checkpoints[:-self.config.max_checkpoints_per_task]
            for path in to_remove:
                try:
                    path.unlink()
                    logger.debug(f"Removed old checkpoint: {path}")
                except Exception as e:
                    logger.warning(f"Failed to remove checkpoint {path}: {e}")

    # =========================================================================
    # Restoration (Load)
    # =========================================================================

    def restore(
        self,
        task_id: str,
        checkpoint_path: Optional[Path] = None,
    ) -> bool:
        """
        Restore all registered component states for a task.

        Args:
            task_id: Identifier for the task/skill
            checkpoint_path: Optional specific checkpoint, else uses latest

        Returns:
            True if restoration successful
        """
        from yrsn.hardware.serialization import load_memristor_state

        # Find checkpoint
        if checkpoint_path is None:
            checkpoint_path = self._find_latest_checkpoint(task_id)
            if checkpoint_path is None:
                logger.warning(f"No checkpoint found for task: {task_id}")
                return False

        try:
            state = load_memristor_state(checkpoint_path)
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            return False

        components = state.get("components", {})
        restored_count = 0

        # Restore memristors
        for name, proj in self._memristors.items():
            key = f"memristor:{name}"
            if key in components and hasattr(proj, "load_state"):
                try:
                    proj.load_state(components[key])
                    restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore memristor {name}: {e}")

        # Restore replay buffers
        for name, buffer in self._replay_buffers.items():
            key = f"replay:{name}"
            if key in components and hasattr(buffer, "load_state"):
                try:
                    buffer.load_state(components[key])
                    restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore replay buffer {name}: {e}")

        # Restore Hopfield networks
        for name, net in self._hopfield_nets.items():
            key = f"hopfield:{name}"
            if key in components and hasattr(net, "load_state"):
                try:
                    net.load_state(components[key])
                    restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore Hopfield net {name}: {e}")

        # Restore EWC modules
        for name, module in self._ewc_modules.items():
            key = f"ewc:{name}"
            if key in components and hasattr(module, "load_state"):
                try:
                    module.load_state(components[key])
                    restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore EWC module {name}: {e}")

        # Restore VLA nodes (they handle their own loading)
        for name, node in self._vla_nodes.items():
            if hasattr(node, "load_checkpoint"):
                try:
                    if node.load_checkpoint():
                        restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore VLA node {name}: {e}")

        # Restore custom components
        for name, component in self._custom.items():
            key = f"custom:{name}"
            if key in components:
                try:
                    component.load_state(components[key])
                    restored_count += 1
                except Exception as e:
                    logger.warning(f"Failed to restore custom component {name}: {e}")

        self._tick_count = state.get("tick_count", 0)

        logger.info(
            f"Restored {restored_count} components for '{task_id}' "
            f"from {checkpoint_path}"
        )

        return restored_count > 0

    def _find_latest_checkpoint(self, task_id: str) -> Optional[Path]:
        """Find the most recent checkpoint for a task."""
        pattern = f"{task_id}_*.pkl.gz"
        checkpoints = sorted(self._checkpoint_dir.glob(pattern))
        return checkpoints[-1] if checkpoints else None

    # =========================================================================
    # Auto-consolidation
    # =========================================================================

    def tick(self) -> Optional[ConsolidationResult]:
        """
        Called each control cycle. Auto-consolidates if interval reached.

        Returns:
            ConsolidationResult if auto-consolidation triggered, else None
        """
        self._tick_count += 1

        if self.config.auto_consolidate_interval > 0:
            ticks_since_last = self._tick_count - self._last_consolidation_tick
            if ticks_since_last >= self.config.auto_consolidate_interval:
                return self.consolidate(task_id="auto")

        return None

    # =========================================================================
    # Query Methods
    # =========================================================================

    def list_checkpoints(self, task_id: Optional[str] = None) -> List[Path]:
        """List available checkpoints, optionally filtered by task."""
        if task_id:
            pattern = f"{task_id}_*.pkl.gz"
        else:
            pattern = "*.pkl.gz"
        return sorted(self._checkpoint_dir.glob(pattern))

    def get_registered_components(self) -> Dict[str, List[str]]:
        """Get names of all registered components by type."""
        return {
            "memristors": list(self._memristors.keys()),
            "replay_buffers": list(self._replay_buffers.keys()),
            "hopfield_nets": list(self._hopfield_nets.keys()),
            "ewc_modules": list(self._ewc_modules.keys()),
            "vla_nodes": list(self._vla_nodes.keys()),
            "custom": list(self._custom.keys()),
        }

    def get_consolidation_history(self) -> List[ConsolidationResult]:
        """Get history of consolidation operations."""
        return self._consolidation_history.copy()


__all__ = [
    "ConsolidationManager",
    "ConsolidationConfig",
    "ConsolidationResult",
    "IConsolidatable",
]
