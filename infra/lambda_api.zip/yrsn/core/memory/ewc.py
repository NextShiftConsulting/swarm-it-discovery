"""
Elastic Weight Consolidation (EWC) - Memory protection for continual learning.

TERMINOLOGY NOTE:
    λ = 1/τ_α where τ_α is YRSN's quality-derived signal (NOT LLM temperature!)
    τ_α EMERGES from R/S/N decomposition, it is NOT a hyperparameter.

EWC prevents catastrophic forgetting by protecting important weights:
    L_total = L_new + (λ/2) Σᵢ Fᵢ(θᵢ - θᵢ*)²

Where:
    - Fᵢ = Fisher information (importance of weight i)
    - θᵢ* = optimal weight for previous tasks
    - λ = regularization strength

YRSN Integration:
    - Fᵢ = "resistance" (high F = hard to change, like memristor)
    - θᵢ* = a priori memory (loaded from historical data)
    - λ = 1/τ (temperature controls plasticity!)

Temperature coupling:
    - Low τ (high quality) → high λ → strong protection → less forgetting
    - High τ (low quality) → low λ → weak protection → more plasticity

Reference: Kirkpatrick et al. (2017). "Overcoming catastrophic forgetting"
Part of yrsn-context core memory layer.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple
import numpy as np


@dataclass
class EWCConfig:
    """Configuration for Elastic Weight Consolidation."""

    # Regularization
    base_lambda: float = 1000.0   # Base regularization strength
    temperature_scaling: bool = True  # Scale λ by 1/τ

    # Fisher estimation
    fisher_gamma: float = 0.95    # Decay for online Fisher estimation
    fisher_min: float = 1e-6      # Minimum Fisher value (numerical stability)
    fisher_max: float = 1e6       # Maximum Fisher value

    # Memory management
    num_tasks: int = 10           # Number of past tasks to remember
    consolidation_threshold: float = 0.1  # Min change to trigger consolidation


@dataclass
class TaskMemory:
    """Memory of a past task."""
    task_id: str
    optimal_weights: np.ndarray   # θ* for this task
    fisher_info: np.ndarray       # F for this task
    importance: float = 1.0       # Task importance weight
    timestamp: int = 0            # When task was learned


class ElasticWeightConsolidation:
    """
    EWC implementation for protecting memristive weights.

    The core idea: weights that were important for previous tasks
    (high Fisher information) should be "resistant" to change.

    This is directly memristive:
    - Fisher = accumulated "charge" from gradient flow
    - High Fisher = high resistance to weight change
    - λ = 1/τ couples memory protection to data quality
    """

    def __init__(self, weight_dim: int, config: Optional[EWCConfig] = None):
        self.weight_dim = weight_dim
        self.config = config or EWCConfig()

        # Current weights
        self.weights = np.zeros(weight_dim, dtype=np.float32)

        # Online Fisher information (current task)
        self.online_fisher = np.zeros(weight_dim, dtype=np.float32)

        # Task memories
        self.task_memories: List[TaskMemory] = []

        # Current task tracking
        self.current_task_id: Optional[str] = None
        self.update_count = 0

    def set_weights(self, weights: np.ndarray) -> None:
        """Set current weight values."""
        self.weights = weights.astype(np.float32).copy()

    def get_weights(self) -> np.ndarray:
        """Get current weights."""
        return self.weights.copy()

    def update_fisher(
        self,
        gradient: np.ndarray,
        class_weight: float = 1.0
    ) -> None:
        """
        Update online Fisher information with optional class balancing.

        Fisher ≈ E[g²] where g is gradient.
        Online: F_new = γF_old + (1-γ) * w * g²

        Parameters
        ----------
        gradient : np.ndarray
            Gradient of loss w.r.t. weights
        class_weight : float
            Weight for this sample's class (use inverse frequency for balance).
            For balanced sampling: weight = n_samples / (n_classes * n_samples_in_class)
            This prevents majority classes from dominating Fisher information.
        """
        cfg = self.config

        # Online Fisher update with class weighting
        # Higher weight for minority classes → balanced importance estimation
        self.online_fisher = (
            cfg.fisher_gamma * self.online_fisher +
            (1 - cfg.fisher_gamma) * class_weight * gradient**2
        )

        # Clip for numerical stability
        self.online_fisher = np.clip(
            self.online_fisher,
            cfg.fisher_min,
            cfg.fisher_max
        )

        self.update_count += 1

    def consolidate_task(
        self,
        task_id: str,
        importance: float = 1.0
    ) -> None:
        """
        Consolidate current task into memory.

        Call this after learning a task to "freeze" the important weights.

        Parameters
        ----------
        task_id : str
            Identifier for the task
        importance : float
            How important is this task (affects λ weighting)
        """
        cfg = self.config

        # Create task memory
        memory = TaskMemory(
            task_id=task_id,
            optimal_weights=self.weights.copy(),
            fisher_info=self.online_fisher.copy(),
            importance=importance,
            timestamp=self.update_count
        )

        self.task_memories.append(memory)

        # Trim old memories if exceeding limit
        if len(self.task_memories) > cfg.num_tasks:
            # Remove least important or oldest
            self.task_memories.sort(
                key=lambda m: m.importance * (1.0 / (self.update_count - m.timestamp + 1))
            )
            self.task_memories.pop(0)

        # Reset online Fisher for new task
        self.online_fisher = np.zeros(self.weight_dim, dtype=np.float32)
        self.current_task_id = None

    def compute_penalty(
        self,
        weights: np.ndarray,
        tau: float = 1.0
    ) -> Tuple[float, np.ndarray]:
        """
        Compute EWC penalty for given weights.

        L_ewc = (λ/2) Σₜ Σᵢ Fᵢᵗ(θᵢ - θᵢ*ᵗ)²

        Parameters
        ----------
        weights : np.ndarray
            Current weight values
        tau : float
            τ_α (quality-derived adaptive signal) from YRSN, default 1/α²

        Returns
        -------
        tuple[float, np.ndarray]
            (total_penalty, gradient_of_penalty)
        """
        cfg = self.config

        if not self.task_memories:
            return 0.0, np.zeros(self.weight_dim)

        # λ scales with inverse temperature
        if cfg.temperature_scaling:
            effective_lambda = cfg.base_lambda / tau
        else:
            effective_lambda = cfg.base_lambda

        total_penalty = 0.0
        gradient = np.zeros(self.weight_dim, dtype=np.float32)

        for memory in self.task_memories:
            # Weight difference from optimal
            delta = weights - memory.optimal_weights

            # Penalty for this task
            task_penalty = 0.5 * memory.importance * np.sum(
                memory.fisher_info * delta**2
            )
            total_penalty += effective_lambda * task_penalty

            # Gradient contribution
            gradient += effective_lambda * memory.importance * memory.fisher_info * delta

        return float(total_penalty), gradient

    def apply_gradient_with_ewc(
        self,
        gradient: np.ndarray,
        learning_rate: float,
        tau: float = 1.0,
        class_weight: float = 1.0
    ) -> np.ndarray:
        """
        Apply gradient with EWC penalty.

        Modified gradient: g_ewc = g_task + ∇L_ewc

        Parameters
        ----------
        gradient : np.ndarray
            Task gradient (from current objective)
        learning_rate : float
            Learning rate
        tau : float
            Temperature from YRSN
        class_weight : float
            Weight for class balancing in Fisher computation.
            Use compute_class_weights() to get balanced weights.

        Returns
        -------
        np.ndarray
            New weights after update
        """
        # Update Fisher with this gradient (class-weighted for balance)
        self.update_fisher(gradient, class_weight=class_weight)

        # Compute EWC penalty gradient
        _, ewc_gradient = self.compute_penalty(self.weights, tau)

        # Combined gradient
        total_gradient = gradient + ewc_gradient

        # Update weights
        self.weights = self.weights - learning_rate * total_gradient

        return self.weights.copy()

    @staticmethod
    def compute_class_weights(y: np.ndarray) -> Dict[int, float]:
        """
        Compute balanced class weights for Fisher estimation.

        Weight = n_samples / (n_classes * n_samples_in_class)

        This ensures minority classes contribute equally to Fisher information,
        preventing catastrophic forgetting when using balanced sampling.

        Parameters
        ----------
        y : np.ndarray
            Class labels

        Returns
        -------
        Dict[int, float]
            Mapping from class label to weight

        Example
        -------
        >>> y = np.array([0, 0, 0, 0, 1])  # 4:1 imbalance
        >>> weights = EWC.compute_class_weights(y)
        >>> weights[0]  # 5 / (2 * 4) = 0.625
        >>> weights[1]  # 5 / (2 * 1) = 2.5  # Minority boosted!
        """
        classes, counts = np.unique(y, return_counts=True)
        n_samples = len(y)
        n_classes = len(classes)

        weights = {}
        for c, count in zip(classes, counts):
            weights[int(c)] = n_samples / (n_classes * count)

        return weights

    def get_importance_mask(self, threshold: float = 0.5) -> np.ndarray:
        """
        Get binary mask of important weights.

        Weights with high cumulative Fisher are marked as important.
        """
        if not self.task_memories:
            return np.zeros(self.weight_dim, dtype=bool)

        # Sum Fisher across all tasks
        total_fisher = np.zeros(self.weight_dim)
        for memory in self.task_memories:
            total_fisher += memory.fisher_info * memory.importance

        # Normalize
        if np.max(total_fisher) > 0:
            normalized = total_fisher / np.max(total_fisher)
        else:
            normalized = total_fisher

        return normalized > threshold

    def get_plasticity(self, tau: float = 1.0) -> np.ndarray:
        """
        Get per-weight plasticity (inverse of protection).

        High plasticity = weight can change easily
        Low plasticity = weight is protected

        Parameters
        ----------
        tau : float
            Temperature (high τ = more plasticity)

        Returns
        -------
        np.ndarray
            Plasticity values in [0, 1]
        """
        cfg = self.config

        if not self.task_memories:
            return np.ones(self.weight_dim)

        # Sum weighted Fisher
        total_fisher = np.zeros(self.weight_dim)
        for memory in self.task_memories:
            total_fisher += memory.fisher_info * memory.importance

        # Compute protection (normalized Fisher)
        max_fisher = np.max(total_fisher)
        if max_fisher > 0:
            protection = total_fisher / max_fisher
        else:
            protection = np.zeros(self.weight_dim)

        # Plasticity = 1 - protection, modulated by temperature
        # High τ → more plasticity (override protection)
        plasticity = 1.0 - protection * (1.0 / tau)

        return np.clip(plasticity, 0, 1)

    def load_apriori(
        self,
        weights: np.ndarray,
        task_id: str = "apriori",
        importance: float = 2.0,
        fisher: Optional[np.ndarray] = None
    ) -> None:
        """
        Load a priori memories with high importance.

        These represent historical knowledge that should be protected.

        Parameters
        ----------
        weights : np.ndarray
            Optimal weights from historical data
        task_id : str
            Identifier for this a priori knowledge
        importance : float
            How important (higher = more protection)
        fisher : np.ndarray, optional
            Pre-computed Fisher (if None, use uniform high value)
        """
        if fisher is None:
            # Uniform high Fisher for a priori (all weights important)
            fisher = np.ones(self.weight_dim) * self.config.fisher_max * 0.1

        memory = TaskMemory(
            task_id=task_id,
            optimal_weights=weights.astype(np.float32).copy(),
            fisher_info=fisher.astype(np.float32),
            importance=importance,
            timestamp=0  # A priori is "oldest"
        )

        self.task_memories.insert(0, memory)  # Add at beginning

    def get_statistics(self) -> Dict[str, Any]:
        """Get EWC statistics."""
        if not self.task_memories:
            return {
                "num_tasks": 0,
                "weight_dim": self.weight_dim,
            }

        # Aggregate Fisher
        total_fisher = np.zeros(self.weight_dim)
        for m in self.task_memories:
            total_fisher += m.fisher_info * m.importance

        return {
            "num_tasks": len(self.task_memories),
            "weight_dim": self.weight_dim,
            "task_ids": [m.task_id for m in self.task_memories],
            "mean_fisher": float(np.mean(total_fisher)),
            "max_fisher": float(np.max(total_fisher)),
            "protected_ratio": float(np.mean(total_fisher > self.config.fisher_min * 10)),
            "update_count": self.update_count,
        }

    def save_state(self) -> Dict[str, Any]:
        """Save EWC state."""
        return {
            "config": self.config.__dict__,
            "weights": self.weights.tolist(),
            "online_fisher": self.online_fisher.tolist(),
            "update_count": self.update_count,
            "task_memories": [
                {
                    "task_id": m.task_id,
                    "optimal_weights": m.optimal_weights.tolist(),
                    "fisher_info": m.fisher_info.tolist(),
                    "importance": m.importance,
                    "timestamp": m.timestamp,
                }
                for m in self.task_memories
            ]
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load EWC state."""
        self.weights = np.array(state["weights"], dtype=np.float32)
        self.online_fisher = np.array(state["online_fisher"], dtype=np.float32)
        self.update_count = state["update_count"]
        self.task_memories = [
            TaskMemory(
                task_id=m["task_id"],
                optimal_weights=np.array(m["optimal_weights"], dtype=np.float32),
                fisher_info=np.array(m["fisher_info"], dtype=np.float32),
                importance=m["importance"],
                timestamp=m["timestamp"],
            )
            for m in state["task_memories"]
        ]

    def clear(self) -> None:
        """Clear all memories."""
        self.weights = np.zeros(self.weight_dim, dtype=np.float32)
        self.online_fisher = np.zeros(self.weight_dim, dtype=np.float32)
        self.task_memories = []
        self.update_count = 0
