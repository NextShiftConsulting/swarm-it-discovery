"""
YRSN Memory - Continual learning and memory systems.

Prevent catastrophic forgetting and enable lifelong learning.

Available Memory Systems:
    EWC            - Elastic Weight Consolidation (importance-weighted)
    Hopfield       - Modern Hopfield Networks (associative memory)
    HopfieldYRSN   - YRSN-Enhanced Hopfield with R/S/N decomposition (RECOMMENDED)
    SDM            - Sparse Distributed Memory
    Replay         - Experience replay buffer

Example:
    from yrsn.core.memory import HopfieldYRSN, create_hopfield_yrsn

    # RECOMMENDED: YRSN-Enhanced Hopfield with R/S/N decomposition (PyTorch)
    memory = HopfieldYRSN(input_dim=54, hidden_dim=256)
    memory.fit(X_train, y_train)
    predictions = memory.predict(X_test)

    # Or use factory function
    memory = create_hopfield_yrsn(input_dim=54)

    # Legacy: Pure Hopfield (for pattern completion only)
    from yrsn.core.memory import Hopfield
    hopfield = Hopfield(pattern_dim=512)
    hopfield.store(pattern, label="example")

WARNING - DO NOT USE NUMPY FOR GRADIENT COMPUTATION:
    Manual numpy gradient implementations are error-prone and produce
    significantly worse results (48% vs 78% on Forest Cover Type).
    Always use PyTorch autograd for any gradient-based learning.
    The numpy hopfield_yrsn.py was deleted for this reason (2024-12).
"""

# Elastic Weight Consolidation (native implementation)
from .ewc import (
    ElasticWeightConsolidation as EWC,
    EWCConfig,
    TaskMemory,
)
HAS_EWC = True
compute_fisher_information = None  # Not implemented in native version

# Hopfield Networks (native implementation)
from .hopfield import (
    ModernHopfieldNetwork as Hopfield,
    HopfieldConfig,
    StoredPattern,
)
HAS_HOPFIELD = True
ModernHopfieldLayer = ModernHopfieldNetwork = Hopfield  # Aliases

# YRSN-Enhanced Hopfield (PyTorch - ONLY USE THIS, NOT NUMPY)
# WARNING: numpy gradient implementations are buggy (48% vs 78% accuracy).
# The numpy version was deleted. Do not recreate it.
from .hopfield_yrsn_torch import (
    HopfieldYRSNTorch,
    YRSNHopfieldConfig,
    create_hopfield_yrsn_torch,
)
HAS_HOPFIELD_YRSN = True
# Aliases for convenience
HopfieldYRSN = HopfieldWithYRSN = HopfieldYRSNTorch
create_hopfield_yrsn = create_hopfield_memory = create_hopfield_yrsn_torch

# Sparse Distributed Memory (native implementation)
from .sdm import (
    SparseDistributedMemory,
    SDMConfig,
    SDMLocation,
)
HAS_SDM = True
SDM = SparseDistributedMemory  # Alias

# Experience Replay (native implementation)
from .replay import (
    PrioritizedReplayBuffer,
    ReplayConfig,
    Experience,
)
HAS_REPLAY = True
ReplayBuffer = PrioritizedReplay = PrioritizedReplayBuffer  # Aliases

# Base Learner (native implementation)
from .base_learner import (
    BaseLearner,
    BaseLearnerConfig,
    PredictionResult,
    LearningResult,
)
from .universal_base_learner import (
    UniversalBaseLearner,
)
HAS_BASE = True
LearnerConfig = BaseLearnerConfig  # Alias for compatibility

# Consolidation Manager (unified save/load across memory layers)
from .consolidation import (
    ConsolidationManager,
    ConsolidationConfig,
    ConsolidationResult,
    IConsolidatable,
)
HAS_CONSOLIDATION = True



def list_memory_systems():
    """List available memory systems."""
    available = ["BaseLearner", "UniversalBaseLearner"]  # Always available (native)
    if HAS_EWC:
        available.append("EWC")
    if HAS_HOPFIELD:
        available.append("Hopfield")
    if HAS_SDM:
        available.append("SDM")
    if HAS_REPLAY:
        available.append("ReplayBuffer")
    if HAS_CONSOLIDATION:
        available.append("ConsolidationManager")
    return available


__all__ = [
    # EWC
    "EWC",
    "EWCConfig",
    "compute_fisher_information",
    # Hopfield (legacy)
    "Hopfield",
    "HopfieldConfig",
    "ModernHopfieldLayer",
    # YRSN Hopfield (PyTorch only - DO NOT USE NUMPY)
    "HopfieldYRSN",
    "HopfieldWithYRSN",
    "HopfieldYRSNTorch",
    "YRSNHopfieldConfig",
    "create_hopfield_yrsn",
    "create_hopfield_memory",
    "create_hopfield_yrsn_torch",
    # SDM
    "SDM",
    "SDMConfig",
    "SparseDistributedMemory",
    # Replay
    "ReplayBuffer",
    "PrioritizedReplay",
    "ReplayConfig",
    # Base Learner
    "BaseLearner",
    "BaseLearnerConfig",
    "LearnerConfig",  # Alias
    "PredictionResult",
    "LearningResult",
    # Universal Base Learner
    "UniversalBaseLearner",
    # Consolidation Manager
    "ConsolidationManager",
    "ConsolidationConfig",
    "ConsolidationResult",
    "IConsolidatable",
    # Utils
    "list_memory_systems",
    # Availability flags
    "HAS_EWC",
    "HAS_HOPFIELD",
    "HAS_HOPFIELD_YRSN",
    "HAS_SDM",
    "HAS_REPLAY",
    "HAS_BASE",
    "HAS_UNIVERSAL",
    "HAS_CONSOLIDATION",
]
