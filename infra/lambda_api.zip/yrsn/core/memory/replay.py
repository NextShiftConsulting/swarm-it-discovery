"""
Prioritized Experience Replay - Online learning from past experiences.

Key insight: Not all experiences are equally valuable for learning.
Experiences with high "surprise" (|prediction - outcome|) teach more.

YRSN Integration:
- Experience = (context, decision, feedback) from any domain
- Priority = |confidence - actual_outcome| (TD error)
- High priority = model was surprised → learn more from this case

Memristive behavior:
- Priority decays over time (like charge leakage)
- Boosted when similar patterns recur (reinforcement)

Reference: Schaul et al. (2015). "Prioritized Experience Replay"
Part of yrsn-context core memory layer.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple
import numpy as np
from collections import deque
import heapq


@dataclass
class ReplayConfig:
    """Configuration for Prioritized Experience Replay."""

    # Buffer parameters
    capacity: int = 10000         # Maximum experiences to store
    min_priority: float = 1e-6   # Minimum priority (avoid zero)

    # Prioritization
    alpha: float = 0.6           # Priority exponent (0 = uniform, 1 = full priority)
    beta: float = 0.4            # Importance sampling exponent
    beta_increment: float = 0.001  # Increase beta over time toward 1.0

    # Decay
    priority_decay: float = 0.99  # Priority decay per step
    recency_bonus: float = 0.1   # Bonus for recent experiences

    # Sampling
    batch_size: int = 32         # Default batch size


@dataclass
class Experience:
    """A single experience in the replay buffer."""

    # Context (what was the situation)
    context: np.ndarray          # Encoded context vector
    context_raw: Dict[str, Any]  # Raw context for debugging

    # Action (what did AI decide)
    action: str                  # Decision/action taken (any string)
    confidence: float            # AI confidence

    # Outcome (what was the feedback)
    outcome: str                 # Human decision or ground truth
    reward: float                # -1 (wrong), 0 (partial), +1 (correct)

    # Metadata
    timestamp: int = 0
    priority: float = 1.0
    td_error: float = 0.0        # |predicted - actual|

    def __lt__(self, other: "Experience") -> bool:
        """For heap ordering (max-heap via negative priority)."""
        return self.priority > other.priority


class SumTree:
    """
    Sum tree for efficient priority-based sampling.

    Enables O(log n) sampling proportional to priority.
    Leaf nodes store priorities, internal nodes store sums.
    """

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = [None] * capacity
        self.write_idx = 0
        self.n_entries = 0

    def _propagate(self, idx: int, change: float) -> None:
        """Propagate priority change up the tree."""
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)

    def _retrieve(self, idx: int, s: float) -> int:
        """Find leaf index for cumulative sum s."""
        left = 2 * idx + 1
        right = left + 1

        if left >= len(self.tree):
            return idx

        if s <= self.tree[left]:
            return self._retrieve(left, s)
        else:
            return self._retrieve(right, s - self.tree[left])

    def total(self) -> float:
        """Total priority sum."""
        return self.tree[0]

    def add(self, priority: float, data: Any) -> None:
        """Add data with priority."""
        idx = self.write_idx + self.capacity - 1

        self.data[self.write_idx] = data
        self.update(idx, priority)

        self.write_idx = (self.write_idx + 1) % self.capacity
        self.n_entries = min(self.n_entries + 1, self.capacity)

    def update(self, idx: int, priority: float) -> None:
        """Update priority at tree index."""
        change = priority - self.tree[idx]
        self.tree[idx] = priority
        self._propagate(idx, change)

    def get(self, s: float) -> Tuple[int, float, Any]:
        """Get (tree_idx, priority, data) for cumulative sum s."""
        idx = self._retrieve(0, s)
        data_idx = idx - self.capacity + 1
        return idx, self.tree[idx], self.data[data_idx]

    def max_priority(self) -> float:
        """Maximum priority in tree."""
        if self.n_entries == 0:
            return 1.0  # Default priority for empty tree
        return max(self.tree[self.capacity - 1:self.capacity - 1 + self.n_entries])


class PrioritizedReplayBuffer:
    """
    Prioritized Experience Replay buffer.

    Samples experiences proportional to their TD error (priority).
    High-error experiences are sampled more often.

    Generic usage:
    - High priority = model was surprised by feedback
    - These cases teach the model the most
    - Priority decays over time (memristive!)
    """

    def __init__(self, config: Optional[ReplayConfig] = None):
        self.config = config or ReplayConfig()
        self.tree = SumTree(self.config.capacity)
        self.experiences: deque = deque(maxlen=self.config.capacity)
        self.step = 0

    def add(
        self,
        context: np.ndarray,
        action: str,
        confidence: float,
        outcome: str,
        reward: float,
        context_raw: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Add experience to buffer.

        Parameters
        ----------
        context : np.ndarray
            Encoded context vector
        action : str
            AI routing decision
        confidence : float
            AI confidence in decision
        outcome : str
            Human/ground truth decision
        reward : float
            Reward signal (-1, 0, +1)
        context_raw : dict, optional
            Raw context for debugging
        """
        # Compute TD error (surprise)
        td_error = abs(reward - confidence)

        # Initial priority = max priority (new experiences get sampled)
        max_priority = self.tree.max_priority()
        if max_priority == 0:
            max_priority = 1.0

        experience = Experience(
            context=context.astype(np.float32),
            context_raw=context_raw or {},
            action=action,
            confidence=confidence,
            outcome=outcome,
            reward=reward,
            timestamp=self.step,
            priority=max_priority,
            td_error=td_error
        )

        self.tree.add(max_priority, experience)
        self.experiences.append(experience)
        self.step += 1

    def sample(
        self,
        batch_size: Optional[int] = None
    ) -> Tuple[List[Experience], np.ndarray, List[int]]:
        """
        Sample batch of experiences proportional to priority.

        Returns
        -------
        tuple[list[Experience], np.ndarray, list[int]]
            (experiences, importance_weights, tree_indices)
        """
        batch_size = batch_size or self.config.batch_size
        cfg = self.config

        experiences = []
        indices = []
        priorities = []

        # Divide priority range into segments
        segment = self.tree.total() / batch_size

        # Increase beta over time (toward 1.0)
        beta = min(1.0, cfg.beta + cfg.beta_increment * self.step)

        for i in range(batch_size):
            # Sample from segment
            a = segment * i
            b = segment * (i + 1)
            s = np.random.uniform(a, b)

            idx, priority, exp = self.tree.get(s)

            if exp is not None:
                experiences.append(exp)
                indices.append(idx)
                priorities.append(priority)

        if not experiences:
            return [], np.array([]), []

        # Importance sampling weights
        priorities = np.array(priorities)
        probs = priorities / self.tree.total()
        weights = (self.tree.n_entries * probs) ** (-beta)
        weights = weights / weights.max()  # Normalize

        return experiences, weights, indices

    def update_priorities(
        self,
        indices: List[int],
        td_errors: List[float]
    ) -> None:
        """
        Update priorities based on new TD errors.

        Call after learning from batch to update priorities.
        """
        cfg = self.config

        for idx, td_error in zip(indices, td_errors):
            priority = (abs(td_error) + cfg.min_priority) ** cfg.alpha
            self.tree.update(idx, priority)

    def decay_priorities(self) -> None:
        """
        Apply priority decay (memristive charge leakage).

        Call periodically to decay old experiences.
        """
        cfg = self.config

        for i in range(self.tree.capacity - 1, self.tree.capacity - 1 + self.tree.n_entries):
            current = self.tree.tree[i]
            decayed = current * cfg.priority_decay + cfg.min_priority
            self.tree.update(i, decayed)

    def boost_similar(
        self,
        context: np.ndarray,
        threshold: float = 0.8,
        boost: float = 1.5
    ) -> int:
        """
        Boost priority of similar experiences.

        When a pattern recurs, boost related memories.
        This is memristive: recurring patterns reinforce.

        Parameters
        ----------
        context : np.ndarray
            Current context
        threshold : float
            Similarity threshold
        boost : float
            Priority multiplier

        Returns
        -------
        int
            Number of experiences boosted
        """
        boosted = 0

        for i, exp in enumerate(self.experiences):
            if exp is None:
                continue

            # Cosine similarity
            sim = np.dot(context, exp.context)
            norm = np.linalg.norm(context) * np.linalg.norm(exp.context)
            if norm > 0:
                sim = sim / norm

            if sim > threshold:
                # Boost priority
                tree_idx = i + self.tree.capacity - 1
                current = self.tree.tree[tree_idx]
                self.tree.update(tree_idx, current * boost)
                boosted += 1

        return boosted

    def get_high_priority(self, top_k: int = 10) -> List[Experience]:
        """Get top-k highest priority experiences."""
        exp_list = [(e.priority, e) for e in self.experiences if e is not None]
        exp_list.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in exp_list[:top_k]]

    def get_recent(self, n: int = 10) -> List[Experience]:
        """Get n most recent experiences."""
        return list(self.experiences)[-n:]

    def get_by_action(self, action: str) -> List[Experience]:
        """Get experiences with specific action."""
        return [e for e in self.experiences if e is not None and e.action == action]

    def compute_statistics(self) -> Dict[str, Any]:
        """Compute buffer statistics."""
        if not self.experiences:
            return {"size": 0}

        valid_exp = [e for e in self.experiences if e is not None]

        if not valid_exp:
            return {"size": 0}

        priorities = [e.priority for e in valid_exp]
        td_errors = [e.td_error for e in valid_exp]
        rewards = [e.reward for e in valid_exp]

        action_counts = {}
        for e in valid_exp:
            action_counts[e.action] = action_counts.get(e.action, 0) + 1

        return {
            "size": len(valid_exp),
            "capacity": self.config.capacity,
            "total_priority": float(self.tree.total()),
            "mean_priority": float(np.mean(priorities)),
            "max_priority": float(np.max(priorities)),
            "mean_td_error": float(np.mean(td_errors)),
            "mean_reward": float(np.mean(rewards)),
            "action_distribution": action_counts,
            "step": self.step,
        }

    def save_state(self) -> Dict[str, Any]:
        """Save buffer state."""
        return {
            "config": self.config.__dict__,
            "step": self.step,
            "experiences": [
                {
                    "context": e.context.tolist(),
                    "context_raw": e.context_raw,
                    "action": e.action,
                    "confidence": e.confidence,
                    "outcome": e.outcome,
                    "reward": e.reward,
                    "timestamp": e.timestamp,
                    "priority": e.priority,
                    "td_error": e.td_error,
                }
                for e in self.experiences if e is not None
            ]
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load buffer state."""
        self.step = state["step"]
        self.tree = SumTree(self.config.capacity)
        self.experiences = deque(maxlen=self.config.capacity)

        for e_dict in state["experiences"]:
            exp = Experience(
                context=np.array(e_dict["context"], dtype=np.float32),
                context_raw=e_dict["context_raw"],
                action=e_dict["action"],
                confidence=e_dict["confidence"],
                outcome=e_dict["outcome"],
                reward=e_dict["reward"],
                timestamp=e_dict["timestamp"],
                priority=e_dict["priority"],
                td_error=e_dict["td_error"],
            )
            self.tree.add(exp.priority, exp)
            self.experiences.append(exp)

    def clear(self) -> None:
        """Clear all experiences."""
        self.tree = SumTree(self.config.capacity)
        self.experiences = deque(maxlen=self.config.capacity)
        self.step = 0
