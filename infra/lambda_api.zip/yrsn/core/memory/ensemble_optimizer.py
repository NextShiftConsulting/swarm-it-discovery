"""
Ensemble Optimization for BaseLearner 4-Layer Memory System.

Implements Strategy 3: Optimize the ensemble to compete with XGBoost.

Key improvements:
1. Learnable layer weights (validation-based tuning)
2. Quality-aware dynamic weighting
3. Online weight adaptation
4. Sophisticated combination methods
5. EWC and Replay prediction contributions (NEW!)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import numpy as np
from collections import deque

from .base_learner import BaseLearner, BaseLearnerConfig, PredictionResult
from .ensemble_predictions import (
    predict_from_replay,
    predict_from_ewc,
    combine_all_layer_predictions
)


class EnsembleMethod(str, Enum):
    """Ensemble combination methods."""
    FIXED = "fixed"  # Current simple fixed weights
    QUALITY_AWARE = "quality_aware"  # Weight by quality (alpha)
    ONLINE_ADAPTIVE = "online_adaptive"  # Weight by layer performance
    ATTENTION = "attention"  # Neural attention (future)
    STACKING = "stacking"  # Meta-learner (future)


@dataclass
class EnsembleOptimizerConfig:
    """Configuration for ensemble optimization."""
    method: EnsembleMethod = EnsembleMethod.QUALITY_AWARE
    
    # Initial weights (will be adapted)
    initial_sdm_weight: float = 0.3
    initial_hopfield_weight: float = 0.4
    initial_ewc_weight: float = 0.0  # Not used in current prediction
    initial_replay_weight: float = 0.0  # Not used in current prediction
    
    # Online adaptation
    adaptation_rate: float = 0.1  # EMA alpha for weight updates
    min_samples_for_adaptation: int = 10  # Minimum samples before adapting
    
    # Quality-aware thresholds
    high_quality_threshold: float = 0.7  # Alpha > this: trust SDM more
    low_quality_threshold: float = 0.4  # Alpha < this: trust Hopfield more


class EnsembleOptimizer:
    """
    Optimizes ensemble weights for BaseLearner's 4-layer memory system.
    
    Provides multiple strategies:
    1. Quality-aware: Weight layers based on context quality (alpha)
    2. Online adaptive: Track layer performance, update weights
    3. Fixed: Use static weights (baseline)
    """
    
    def __init__(self, config: Optional[EnsembleOptimizerConfig] = None):
        self.config = config or EnsembleOptimizerConfig()
        
        # Current weights
        self.weights = {
            'sdm': self.config.initial_sdm_weight,
            'hopfield': self.config.initial_hopfield_weight,
            'ewc': self.config.initial_ewc_weight,
            'replay': self.config.initial_replay_weight,
        }
        
        # Layer performance tracking (for online adaptation)
        self.layer_stats = {
            'sdm': {'correct': 0, 'total': 0, 'accuracy': 0.5},
            'hopfield': {'correct': 0, 'total': 0, 'accuracy': 0.5},
        }
        
        # Weight history
        self.weight_history: deque = deque(maxlen=1000)
    
    def compute_weights(
        self,
        alpha: float,
        tau: float,
        sdm_confidence: float,
        hopfield_confidence: float,
        has_hopfield_patterns: bool,
        has_replay_experiences: bool = False,
        has_ewc_memories: bool = False
    ) -> Dict[str, float]:
        """
        Compute ensemble weights based on configured method.
        
        Args:
            alpha: Quality score R/(R+S+N)
            tau: Temperature 1/alpha
            sdm_confidence: SDM prediction confidence
            hopfield_confidence: Hopfield prediction confidence
            has_hopfield_patterns: Whether Hopfield has stored patterns
            has_replay_experiences: Whether Replay buffer has experiences
            has_ewc_memories: Whether EWC has task memories
        
        Returns:
            Dict of layer weights (normalized to sum to 1.0)
        """
        if self.config.method == EnsembleMethod.FIXED:
            return self._compute_fixed_weights(
                has_hopfield_patterns, has_replay_experiences, has_ewc_memories
            )
        elif self.config.method == EnsembleMethod.QUALITY_AWARE:
            return self._compute_quality_aware_weights(
                alpha, tau, sdm_confidence, hopfield_confidence,
                has_hopfield_patterns, has_replay_experiences, has_ewc_memories
            )
        elif self.config.method == EnsembleMethod.ONLINE_ADAPTIVE:
            return self._compute_online_adaptive_weights(
                alpha, tau, sdm_confidence, hopfield_confidence,
                has_hopfield_patterns, has_replay_experiences, has_ewc_memories
            )
        else:
            raise ValueError(f"Unsupported method: {self.config.method}")
    
    def _compute_fixed_weights(
        self,
        has_hopfield_patterns: bool,
        has_replay_experiences: bool = False,
        has_ewc_memories: bool = False
    ) -> Dict[str, float]:
        """Fixed weights (current baseline)."""
        w_sdm = self.config.initial_sdm_weight
        w_hop = self.config.initial_hopfield_weight * (2.0 if has_hopfield_patterns else 0.0)
        w_replay = self.config.initial_replay_weight if has_replay_experiences else 0.0
        w_ewc = self.config.initial_ewc_weight if has_ewc_memories else 0.0
        
        # Normalize
        total = w_sdm + w_hop + w_replay + w_ewc
        if total < 0.01:
            # Fallback: equal weights for available layers
            available = sum([
                1 if has_hopfield_patterns else 0,
                1 if has_replay_experiences else 0,
                1 if has_ewc_memories else 0,
                1  # SDM always available
            ])
            if available > 0:
                w_sdm = w_hop = w_replay = w_ewc = 1.0 / available
            else:
                w_sdm, w_hop, w_replay, w_ewc = 0.5, 0.5, 0.0, 0.0
        else:
            w_sdm /= total
            w_hop /= total
            w_replay /= total
            w_ewc /= total
        
        return {
            'sdm': w_sdm,
            'hopfield': w_hop,
            'replay': w_replay,
            'ewc': w_ewc,
        }
    
    def _compute_quality_aware_weights(
        self,
        alpha: float,
        tau: float,
        sdm_confidence: float,
        hopfield_confidence: float,
        has_hopfield_patterns: bool,
        has_replay_experiences: bool = False,
        has_ewc_memories: bool = False
    ) -> Dict[str, float]:
        """
        Quality-aware weighting strategy.
        
        High quality (alpha > 0.7): Trust SDM more (a priori knowledge is reliable)
        Medium quality (0.4 < alpha < 0.7): Balance SDM and Hopfield
        Low quality (alpha < 0.4): Trust Hopfield more (pattern completion may help)
        """
        cfg = self.config
        
        # Base weights by quality
        if alpha > cfg.high_quality_threshold:
            # High quality: SDM a priori knowledge is reliable
            base_sdm = 0.6
            base_hop = 0.4
        elif alpha > cfg.low_quality_threshold:
            # Medium quality: Balanced
            base_sdm = 0.4
            base_hop = 0.6
        else:
            # Low quality: Hopfield pattern completion may help
            base_sdm = 0.2
            base_hop = 0.8
        
        # Adjust by confidence (higher confidence = more weight)
        w_sdm = base_sdm * sdm_confidence
        w_hop = base_hop * hopfield_confidence
        
        # Temperature adjustment: High tau (low quality) = more exploration
        # Boost both layers slightly in uncertain conditions
        tau_boost = 1.0 + 0.1 * (tau - 1.0)  # tau=1.0 -> no boost, tau=2.0 -> +10%
        w_sdm *= tau_boost
        w_hop *= tau_boost
        
        # If Hopfield has no patterns, reduce its weight
        if not has_hopfield_patterns:
            w_hop *= 0.5
        
        # Normalize
        total = w_sdm + w_hop
        if total < 0.01:
            w_sdm, w_hop = 0.5, 0.5
        else:
            w_sdm /= total
            w_hop /= total
        
        return {
            'sdm': w_sdm,
            'hopfield': w_hop,
            'ewc': 0.0,
            'replay': 0.0,
        }
    
    def _compute_online_adaptive_weights(
        self,
        alpha: float,
        tau: float,
        sdm_confidence: float,
        hopfield_confidence: float,
        has_hopfield_patterns: bool,
        has_replay_experiences: bool = False,
        has_ewc_memories: bool = False
    ) -> Dict[str, float]:
        """
        Online adaptive weighting based on layer performance.
        
        Weights are updated based on historical accuracy of each layer.
        """
        # Get current layer accuracies
        sdm_acc = self.layer_stats['sdm']['accuracy']
        hop_acc = self.layer_stats['hopfield']['accuracy']
        replay_acc = self.layer_stats.get('replay', {}).get('accuracy', 0.5)
        ewc_acc = self.layer_stats.get('ewc', {}).get('accuracy', 0.5)
        
        # Weight by accuracy (better layers get more weight)
        w_sdm = sdm_acc * sdm_confidence
        w_hop = hop_acc * hopfield_confidence
        w_replay = replay_acc if has_replay_experiences else 0.0
        w_ewc = ewc_acc if has_ewc_memories else 0.0
        
        # Quality adjustment: In high quality, trust SDM more
        if alpha > self.config.high_quality_threshold:
            w_sdm *= 1.2
            w_ewc *= 1.1  # EWC also benefits from high quality
        elif alpha < self.config.low_quality_threshold:
            w_hop *= 1.2
            w_replay *= 1.1  # Replay helps in low quality
        
        # If Hopfield has no patterns, reduce its weight
        if not has_hopfield_patterns:
            w_hop *= 0.5
        
        # Normalize
        total = w_sdm + w_hop + w_replay + w_ewc
        if total < 0.01:
            # Fallback: equal weights for available layers
            available = sum([
                1 if has_hopfield_patterns else 0,
                1 if has_replay_experiences else 0,
                1 if has_ewc_memories else 0,
                1  # SDM always available
            ])
            if available > 0:
                w_sdm = w_hop = w_replay = w_ewc = 1.0 / available
            else:
                w_sdm, w_hop, w_replay, w_ewc = 0.5, 0.5, 0.0, 0.0
        else:
            w_sdm /= total
            w_hop /= total
            w_replay /= total
            w_ewc /= total
        
        return {
            'sdm': w_sdm,
            'hopfield': w_hop,
            'replay': w_replay,
            'ewc': w_ewc,
        }
    
    def update_layer_stats(
        self,
        layer: str,
        was_correct: bool
    ):
        """
        Update layer performance statistics.
        
        Args:
            layer: 'sdm' or 'hopfield'
            was_correct: Whether the layer's prediction was correct
        """
        if layer not in self.layer_stats:
            return
        
        stats = self.layer_stats[layer]
        stats['correct'] += was_correct
        stats['total'] += 1
        
        # Update accuracy (exponential moving average)
        if stats['total'] > 0:
            new_acc = stats['correct'] / stats['total']
            old_acc = stats['accuracy']
            
            # EMA update
            alpha = self.config.adaptation_rate
            stats['accuracy'] = alpha * new_acc + (1 - alpha) * old_acc
    
    def get_layer_accuracy(self, layer: str) -> float:
        """Get current accuracy estimate for a layer."""
        if layer in self.layer_stats:
            return self.layer_stats[layer]['accuracy']
        return 0.5  # Default
    
    def reset_stats(self):
        """Reset layer statistics (useful for testing)."""
        for layer in self.layer_stats:
            self.layer_stats[layer] = {'correct': 0, 'total': 0, 'accuracy': 0.5}
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get optimizer statistics."""
        return {
            'method': self.config.method.value,
            'current_weights': self.weights.copy(),
            'layer_stats': {
                layer: stats.copy() 
                for layer, stats in self.layer_stats.items()
            },
            'weight_history_length': len(self.weight_history),
        }


def combine_predictions_with_optimizer(
    optimizer: EnsembleOptimizer,
    sdm_label: str,
    sdm_conf: float,
    hopfield_probs: Dict[str, float],
    alpha: float,
    tau: float,
    labels: List[str]
) -> Dict[str, float]:
    """
    Combine SDM and Hopfield predictions using ensemble optimizer.
    
    This is a drop-in replacement for BaseLearner._combine_predictions.
    
    Args:
        optimizer: EnsembleOptimizer instance
        sdm_label: SDM predicted label
        sdm_conf: SDM confidence
        hopfield_probs: Hopfield label probabilities
        alpha: Quality score
        tau: Temperature
        labels: List of all possible labels
    
    Returns:
        Combined label probabilities
    """
    has_patterns = len(hopfield_probs) > 0
    hop_conf = max(hopfield_probs.values()) if hopfield_probs else 0.0
    
    # Get weights from optimizer
    weights = optimizer.compute_weights(
        alpha=alpha,
        tau=tau,
        sdm_confidence=sdm_conf,
        hopfield_confidence=hop_conf,
        has_hopfield_patterns=has_patterns
    )
    
    # Initialize with small prior
    combined = {label: 0.01 for label in labels}
    
    # SDM contribution
    if sdm_label in combined:
        combined[sdm_label] += weights['sdm'] * sdm_conf
    
    # Hopfield contribution
    for label, prob in hopfield_probs.items():
        if label in combined:
            combined[label] += weights['hopfield'] * prob
    
    # Normalize
    total = sum(combined.values())
    if total > 0:
        combined = {k: v / total for k, v in combined.items()}
    
    return combined

