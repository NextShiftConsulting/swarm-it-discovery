"""
Modern Hopfield Network - Energy-based pattern completion and attractor dynamics.

TERMINOLOGY NOTE:
    β = 1/τ_α where τ_α is YRSN's quality-derived signal (NOT LLM temperature!)
    τ_α EMERGES from R/S/N decomposition, it is NOT a hyperparameter.

Classical Hopfield (1982): E = -½ Σᵢⱼ wᵢⱼ sᵢ sⱼ
- Linear storage capacity: ~0.14N patterns
- Binary states: {-1, +1}

Modern Hopfield (Ramsauer et al., 2020): E = -lse(β, X^T ξ) + ½||ξ||²
- Exponential storage capacity
- Continuous states
- Equivalent to transformer attention!

YRSN Integration:
- Stored patterns = labeled decisions (any domain)
- Query = current context vector
- Retrieval = pattern completion → decision
- β (inverse temperature) = 1/τ from YRSN quality!
  - High β (low τ, high quality) → sharp retrieval
  - Low β (high τ, low quality) → soft retrieval

Reference: Ramsauer et al. (2020). "Hopfield Networks is All You Need"
Part of yrsn-context core memory layer.
"""

from dataclasses import dataclass
from typing import Optional, List, Tuple, Dict, Any
import numpy as np

# Note: Applications can define their own attractor types as strings.
# Example: "approve", "review", "reject" or any domain-specific labels.


@dataclass
class HopfieldConfig:
    """Configuration for Modern Hopfield Network."""

    # Dimensions
    pattern_dim: int = 256      # Dimension of stored patterns
    max_patterns: int = 1000    # Maximum number of patterns to store

    # Dynamics
    beta: float = 1.0           # Inverse temperature (1/τ)
    num_iterations: int = 10    # Update iterations for convergence
    convergence_threshold: float = 1e-4  # Stop when change < threshold

    # Modern Hopfield parameters
    use_modern: bool = True     # Use modern (exponential) vs classical
    separation_factor: float = 3.0  # For well-separated patterns

    # Initialization
    seed: Optional[int] = None


@dataclass
class StoredPattern:
    """A stored pattern (memory) in the Hopfield network."""
    pattern: np.ndarray         # The pattern vector
    label: str                  # Pattern label (any domain-specific string)
    metadata: Dict[str, Any]    # Additional info
    strength: float = 1.0       # Pattern strength (for weighted storage)


class ModernHopfieldNetwork:
    """
    Modern Hopfield Network with exponential storage capacity.

    Energy function (Modern):
        E(ξ) = -lse(β, X^T ξ) + ½||ξ||² + const

    Where:
        - ξ = query/state vector
        - X = matrix of stored patterns (columns)
        - β = inverse temperature
        - lse = log-sum-exp (smooth max)

    Update rule (gradient descent on E):
        ξ_new = X softmax(β X^T ξ)

    This is exactly transformer attention with:
        - X = keys = values
        - ξ = query
        - β = 1/√d_k (scaled dot-product attention)

    Temperature coupling (YRSN):
        - β = 1/τ (inverse temperature from quality)
        - High β (low τ, high quality) → sharp retrieval → confident decision
        - Low β (high τ, low quality) → soft retrieval → uncertain decision
    """

    def __init__(self, config: Optional[HopfieldConfig] = None):
        self.config = config or HopfieldConfig()
        self.rng = np.random.RandomState(self.config.seed)

        # Stored patterns
        self.patterns: List[StoredPattern] = []

        # Pattern matrix (for efficient computation)
        self._pattern_matrix: Optional[np.ndarray] = None
        self._matrix_dirty = True

    def store(
        self,
        pattern: np.ndarray,
        label: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        strength: float = 1.0
    ) -> int:
        """
        Store a pattern in the network.

        Parameters
        ----------
        pattern : np.ndarray
            Pattern vector to store
        label : str
            Pattern label (any string identifier)
        metadata : dict, optional
            Additional metadata
        strength : float
            Pattern strength (for weighted storage)

        Returns
        -------
        int
            Index of stored pattern
        """
        # Normalize pattern
        norm = np.linalg.norm(pattern)
        if norm > 0:
            pattern = pattern / norm

        stored = StoredPattern(
            pattern=pattern.astype(np.float32),
            label=label,
            metadata=metadata or {},
            strength=strength
        )

        self.patterns.append(stored)
        self._matrix_dirty = True

        # Trim if exceeding max
        if len(self.patterns) > self.config.max_patterns:
            # Remove oldest/weakest pattern
            self.patterns.sort(key=lambda p: p.strength)
            self.patterns.pop(0)

        return len(self.patterns) - 1

    def _build_pattern_matrix(self) -> np.ndarray:
        """Build matrix of stored patterns (columns)."""
        if self._matrix_dirty or self._pattern_matrix is None:
            if not self.patterns:
                self._pattern_matrix = np.zeros((self.config.pattern_dim, 1))
            else:
                patterns = [p.pattern for p in self.patterns]
                self._pattern_matrix = np.column_stack(patterns)
            self._matrix_dirty = False
        return self._pattern_matrix

    def energy(self, state: np.ndarray, beta: Optional[float] = None) -> float:
        """
        Compute energy of a state.

        E(ξ) = -lse(β, X^T ξ) + ½||ξ||²

        Lower energy = more stable state = closer to stored pattern.
        """
        beta = beta if beta is not None else self.config.beta
        X = self._build_pattern_matrix()

        # Similarities to stored patterns
        similarities = X.T @ state  # (num_patterns,)

        # Log-sum-exp (smooth max)
        lse = (1/beta) * np.log(np.sum(np.exp(beta * similarities)))

        # Energy
        return -lse + 0.5 * np.linalg.norm(state)**2

    def update(
        self,
        state: np.ndarray,
        beta: Optional[float] = None,
        num_iterations: Optional[int] = None
    ) -> Tuple[np.ndarray, List[float]]:
        """
        Update state to minimize energy (retrieve pattern).

        ξ_new = X softmax(β X^T ξ)

        Parameters
        ----------
        state : np.ndarray
            Current state (query)
        beta : float, optional
            Inverse temperature (default: config.beta)
        num_iterations : int, optional
            Number of update steps

        Returns
        -------
        tuple[np.ndarray, list[float]]
            (final_state, energy_history)
        """
        beta = beta if beta is not None else self.config.beta
        num_iterations = num_iterations or self.config.num_iterations

        X = self._build_pattern_matrix()
        current = state.copy().astype(np.float32)

        energy_history = []

        for _ in range(num_iterations):
            # Compute similarities
            similarities = X.T @ current  # (num_patterns,)

            # Softmax with temperature
            exp_sim = np.exp(beta * (similarities - np.max(similarities)))
            attention = exp_sim / np.sum(exp_sim)

            # Update: weighted combination of patterns
            new_state = X @ attention

            # Normalize
            norm = np.linalg.norm(new_state)
            if norm > 0:
                new_state = new_state / norm

            # Track energy
            energy_history.append(self.energy(new_state, beta))

            # Check convergence
            if np.linalg.norm(new_state - current) < self.config.convergence_threshold:
                current = new_state
                break

            current = new_state

        return current, energy_history

    def retrieve(
        self,
        query: np.ndarray,
        beta: Optional[float] = None,
        return_soft: bool = False
    ) -> Tuple[StoredPattern, float, np.ndarray]:
        """
        Retrieve pattern most similar to query.

        Parameters
        ----------
        query : np.ndarray
            Query vector (partial/noisy pattern)
        beta : float, optional
            Inverse temperature (1/τ from YRSN)
        return_soft : bool
            If True, return soft attention weights

        Returns
        -------
        tuple[StoredPattern, float, np.ndarray]
            (best_pattern, confidence, attention_weights)
        """
        if not self.patterns:
            raise ValueError("No patterns stored")

        beta = beta if beta is not None else self.config.beta

        # Normalize query
        norm = np.linalg.norm(query)
        if norm > 0:
            query = query / norm

        # Run dynamics to converge
        final_state, _ = self.update(query, beta)

        # Compute attention weights (soft retrieval)
        X = self._build_pattern_matrix()
        similarities = X.T @ final_state
        exp_sim = np.exp(beta * (similarities - np.max(similarities)))
        attention = exp_sim / np.sum(exp_sim)

        # Best matching pattern
        best_idx = np.argmax(attention)
        confidence = float(attention[best_idx])

        return self.patterns[best_idx], confidence, attention

    def retrieve_by_label(
        self,
        query: np.ndarray,
        beta: Optional[float] = None
    ) -> Tuple[str, float, Dict[str, float]]:
        """
        Retrieve and return label with confidence.

        Useful when patterns have categorical labels.

        Returns
        -------
        tuple[str, float, dict]
            (best_label, confidence, label_probabilities)
        """
        if not self.patterns:
            return "UNKNOWN", 0.0, {}

        beta = beta if beta is not None else self.config.beta

        # Normalize query
        norm = np.linalg.norm(query)
        if norm > 0:
            query = query / norm

        # Get attention weights
        X = self._build_pattern_matrix()
        similarities = X.T @ query
        exp_sim = np.exp(beta * (similarities - np.max(similarities)))
        attention = exp_sim / np.sum(exp_sim)

        # Aggregate by label
        label_probs: Dict[str, float] = {}
        for i, pattern in enumerate(self.patterns):
            label = pattern.label
            if label not in label_probs:
                label_probs[label] = 0.0
            label_probs[label] += attention[i]

        # Best label
        best_label = max(label_probs, key=label_probs.get)
        confidence = label_probs[best_label]

        return best_label, confidence, label_probs

    def store_attractor(
        self,
        label: str,
        prototype: np.ndarray,
        num_variants: int = 10,
        noise_std: float = 0.1
    ) -> None:
        """
        Store an attractor with variants.

        Creates multiple patterns around a prototype to form a basin of attraction.

        Parameters
        ----------
        label : str
            Label for this attractor (any domain-specific string)
        prototype : np.ndarray
            Prototype pattern
        num_variants : int
            Number of variant patterns to store
        noise_std : float
            Standard deviation of noise for variants
        """
        # Store prototype with high strength
        self.store(
            prototype,
            label=label,
            metadata={"is_prototype": True},
            strength=2.0
        )

        # Store noisy variants
        for _ in range(num_variants):
            variant = prototype + self.rng.randn(len(prototype)) * noise_std
            self.store(
                variant,
                label=label,
                metadata={"is_prototype": False},
                strength=1.0
            )

    def compute_basin_overlap(self) -> Dict[str, float]:
        """
        Compute overlap between attractor basins.

        Returns overlap matrix as dict for analysis.
        """
        labels = list(set(p.label for p in self.patterns))
        overlaps = {}

        for l1 in labels:
            for l2 in labels:
                if l1 <= l2:  # Symmetric
                    # Get patterns with each label
                    p1 = [p.pattern for p in self.patterns if p.label == l1]
                    p2 = [p.pattern for p in self.patterns if p.label == l2]

                    if p1 and p2:
                        # Mean cosine similarity
                        sims = []
                        for a in p1:
                            for b in p2:
                                sim = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
                                sims.append(sim)
                        overlaps[f"{l1}-{l2}"] = float(np.mean(sims))

        return overlaps

    def get_statistics(self) -> Dict[str, Any]:
        """Get network statistics."""
        label_counts = {}
        for p in self.patterns:
            label_counts[p.label] = label_counts.get(p.label, 0) + 1

        return {
            "num_patterns": len(self.patterns),
            "pattern_dim": self.config.pattern_dim,
            "beta": self.config.beta,
            "label_distribution": label_counts,
            "basin_overlap": self.compute_basin_overlap() if self.patterns else {},
        }

    def save_state(self) -> Dict[str, Any]:
        """Save network state."""
        return {
            "config": self.config.__dict__,
            "patterns": [
                {
                    "pattern": p.pattern.tolist(),
                    "label": p.label,
                    "metadata": p.metadata,
                    "strength": p.strength
                }
                for p in self.patterns
            ]
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Load network state."""
        self.patterns = []
        for p_dict in state["patterns"]:
            self.patterns.append(StoredPattern(
                pattern=np.array(p_dict["pattern"], dtype=np.float32),
                label=p_dict["label"],
                metadata=p_dict["metadata"],
                strength=p_dict["strength"]
            ))
        self._matrix_dirty = True

    def clear(self) -> None:
        """Clear all stored patterns."""
        self.patterns = []
        self._pattern_matrix = None
        self._matrix_dirty = True
