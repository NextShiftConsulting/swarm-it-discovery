"""
BaseLearner - Abstract base class for τ_α-coupled learning.

TERMINOLOGY NOTE:
    τ_α (tau_alpha) = YRSN's quality-derived adaptive signal (EMERGENT)
    LLM temperature = API hyperparameter you CHOOSE (EXTERNAL)

    These are DIFFERENT concepts! τ_α EMERGES from R/S/N decomposition:
        Y → (R,S,N) → α = R/(R+S+N) → α_ω → τ_α = 1/α²

This provides the core 4-layer learning architecture:
1. SDM (Sparse Distributed Memory) - A priori knowledge
2. Hopfield (Modern Hopfield Network) - Pattern completion
3. EWC (Elastic Weight Consolidation) - Memory protection
4. Replay (Prioritized Experience Replay) - Online learning

All layers are coupled by τ_α (quality-derived adaptive signal).
τ_α = f(α_ω) where f is domain-specific (default: 1/α²).
NOTE: τ_α functions like temperature but is DERIVED from quality, not arbitrary.

Applications extend this class to define:
- Their own labels/decisions (not hardcoded GREEN/YELLOW/RED)
- Their own reward functions
- Their own context encoding
- Their own routing logic

Example:
    class MedicalTriageLearner(BaseLearner):
        LABELS = ["GREEN", "YELLOW", "RED"]

        def compute_reward(self, predicted, actual, feedback):
            ...

    class LLMRoutingLearner(BaseLearner):
        LABELS = ["fast", "balanced", "strong", "specialist"]

        def compute_reward(self, predicted, actual, feedback):
            ...

Part of yrsn core memory layer.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple, Generic, TypeVar, TYPE_CHECKING
import numpy as np

from .sdm import SparseDistributedMemory, SDMConfig
from .hopfield import ModernHopfieldNetwork, HopfieldConfig
from .ewc import ElasticWeightConsolidation, EWCConfig
from .replay import PrioritizedReplayBuffer, ReplayConfig, Experience

if TYPE_CHECKING:
    from yrsn.ports.reliability import IReliabilityMonitor


# Type variable for label type (subclasses define their own)
LabelT = TypeVar('LabelT', bound=str)


@dataclass
class BaseLearnerConfig:
    """
    Configuration for BaseLearner.

    Subclasses can extend this with domain-specific settings.
    """
    # Dimensions
    context_dim: int = 256
    binary_dim: int = 1024

    # Layer weights (contribution to final prediction)
    sdm_weight: float = 0.3
    hopfield_weight: float = 0.4
    ewc_weight: float = 0.2
    replay_weight: float = 0.1

    # Temperature parameters
    base_temperature: float = 1.0
    min_temperature: float = 0.1
    max_temperature: float = 10.0
    temperature_mode: str = "power"  # linear, power, log, sigmoid

    # Learning parameters
    learning_rate: float = 0.01
    batch_size: int = 32
    learn_every_n_steps: int = 10

    # Layer configs (optional overrides)
    sdm_config: Optional[SDMConfig] = None
    hopfield_config: Optional[HopfieldConfig] = None
    ewc_config: Optional[EWCConfig] = None
    replay_config: Optional[ReplayConfig] = None

    # Control-theoretic parameters (OPTIONAL - for collapse resistance)
    enable_control_constraints: bool = False  # Default: disabled (backward compatible)
    alpha_min: float = 0.4  # Safety threshold (barrier function)
    tau_pred_max: float = 2.5  # Max τ for prediction
    tau_write_max: float = 2.0  # Max τ for memory writes
    stability_epsilon: float = 0.05  # Degradation tolerance
    quality_prior: float = 0.5  # Prior for α_ω computation (Claim 2)
    
    # Omega (reliability) parameters
    omega_default: float = 1.0  # Default reliability (1.0 = in-distribution)
    compute_omega: bool = False  # Whether to compute omega from context

    # Random seed
    seed: Optional[int] = None


@dataclass
class PredictionResult:
    """Result of a prediction from the learner."""
    label: str                          # Predicted label
    confidence: float                   # Confidence in prediction
    label_probabilities: Dict[str, float]  # All label probabilities
    temperature: float                  # τ at prediction time
    phase: str                          # Quality phase (high/medium/low)
    margin: float                       # Gap between top two labels
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LearningResult:
    """Result of a learning step."""
    reward: float
    temperature: float
    was_correct: bool
    batch_learned: bool = False
    batch_stats: Dict[str, Any] = field(default_factory=dict)


class BaseLearner(ABC):
    """
    Abstract base class for τ_α-coupled 4-layer learning.

    Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │                      BaseLearner                             │
    │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
    │  │   SDM   │  │Hopfield │  │   EWC   │  │ Replay  │        │
    │  │(a priori)│  │(patterns)│  │(protect)│  │(online) │        │
    │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘        │
    │       │            │            │            │              │
    │       └────────────┴─────┬──────┴────────────┘              │
    │                          │                                   │
    │                τ_α = f(α_ω) = 1/α²                           │
    │         (quality-derived adaptive signal)                    │
    └──────────────────────────────────────────────────────────────┘

    Subclasses must implement:
    - LABELS: List of valid labels for this domain
    - encode_context(): Convert domain input to vector
    - compute_reward(): Define reward signal
    - apply_routing(): Domain-specific decision logic
    """

    # Subclasses MUST override this
    LABELS: List[str] = []

    def __init__(
        self,
        config: Optional[BaseLearnerConfig] = None,
        reliability_monitor: Optional["IReliabilityMonitor"] = None,
    ):
        if not self.LABELS:
            raise ValueError("Subclass must define LABELS class attribute")

        self.config = config or BaseLearnerConfig()
        self.rng = np.random.RandomState(self.config.seed)

        # Initialize 4 layers
        self._init_layers()

        # Sense Bus connection (hexagonal architecture)
        # Provides signals 4-7 for enhanced ω computation
        self.reliability_monitor = reliability_monitor

        # State tracking
        self.step = 0
        self.total_predictions = 0
        self.correct_predictions = 0

        # Track last alpha for stability checks
        self._last_alpha = self.config.quality_prior
        self._last_alpha_omega = self.config.quality_prior

    def _init_layers(self) -> None:
        """Initialize the 4 memory layers."""
        cfg = self.config

        # Layer 1: SDM
        sdm_cfg = cfg.sdm_config or SDMConfig(
            address_dim=cfg.binary_dim,
            data_dim=cfg.context_dim,
            num_locations=1000,
            access_radius=int(cfg.binary_dim * 0.44)
        )
        self.sdm = SparseDistributedMemory(sdm_cfg)

        # Layer 2: Hopfield
        hopfield_cfg = cfg.hopfield_config or HopfieldConfig(
            pattern_dim=cfg.context_dim,
            max_patterns=1000,
            beta=1.0 / cfg.base_temperature
        )
        self.hopfield = ModernHopfieldNetwork(hopfield_cfg)

        # Layer 3: EWC
        ewc_cfg = cfg.ewc_config or EWCConfig(
            base_lambda=1000.0,
            temperature_scaling=True
        )
        self.ewc = ElasticWeightConsolidation(cfg.context_dim, ewc_cfg)

        # Layer 4: Replay
        replay_cfg = cfg.replay_config or ReplayConfig(
            capacity=10000,
            batch_size=cfg.batch_size
        )
        self.replay = PrioritizedReplayBuffer(replay_cfg)

    # =========================================================================
    # ABSTRACT METHODS - Subclasses must implement
    # =========================================================================

    @abstractmethod
    def encode_context(self, **kwargs) -> Tuple[np.ndarray, np.ndarray]:
        """
        Encode domain-specific input into context vectors.

        Returns:
            tuple: (continuous_context, binary_address)
            - continuous_context: Float vector for Hopfield/EWC
            - binary_address: Binary vector for SDM
        """
        ...

    @abstractmethod
    def compute_reward(
        self,
        predicted: str,
        actual: str,
        feedback: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        Compute reward signal for learning.

        Args:
            predicted: The predicted label
            actual: The actual/correct label
            feedback: Optional additional feedback (domain-specific)

        Returns:
            float: Reward in [-1, 1] range typically
        """
        ...

    @abstractmethod
    def compute_quality(self, **kwargs) -> float:
        """
        Compute quality score α from input.

        This determines τ_α (adaptive signal): τ_α = f(α_ω) (default: 1/α²)

        Returns:
            float: Quality score α in (0, 1]
        """
        ...

    def apply_routing(
        self,
        label: str,
        confidence: float,
        margin: float,
        tau: float,
        phase: str
    ) -> str:
        """
        Apply domain-specific routing logic.

        Default implementation: trust the label directly.
        Override for phase-based or margin-based routing.

        Args:
            label: Best label from memory
            confidence: Confidence in label
            margin: Gap to second-best label
            tau: Current temperature
            phase: Quality phase (high/medium/low)

        Returns:
            str: Final routing decision (must be in LABELS)
        """
        return label

    # =========================================================================
    # TEMPERATURE COMPUTATION
    # =========================================================================

    def compute_temperature(self, alpha: float) -> float:
        """
        Compute temperature τ from quality α.

        DEPRECATED: Use compute_temperature_with_safety() for control constraints.
        This method is kept for backward compatibility.

        Modes:
        - linear:  τ = 1/α
        - power:   τ = 1/α^k (k=2)
        - log:     τ = 1/log(1 + 10α)
        - sigmoid: Bounded smooth mapping
        """
        # Use new method with default omega for backward compatibility
        return self.compute_temperature_with_safety(alpha, omega=None)

    def get_phase(self, tau: float) -> str:
        """Get quality phase from temperature."""
        if tau < 1.43:
            return "high"
        elif tau < 2.50:
            return "medium"
        else:
            return "low"

    # =========================================================================
    # CONTROL-THEORETIC STABILITY (Collapse Resistance)
    # =========================================================================
    
    def compute_alpha_omega(self, alpha: float, omega: Optional[float] = None) -> float:
        """
        Compute reliability-adjusted quality α_ω (Claim 2).
        
        Formula: α_ω = ω·α + (1-ω)·prior
        
        This provides collapse resistance by preventing α from reaching zero.
        
        Args:
            alpha: Raw quality α = R/(R+S+N)
            omega: Reliability coefficient (None = use config default)
        
        Returns:
            Reliability-adjusted quality α_ω
        """
        omega = omega if omega is not None else self.config.omega_default
        
        # Direct formula when we only have alpha (not R/S/N)
        # α_ω = ω·α + (1-ω)·prior
        # This prevents α from collapsing to zero by blending with prior
        return omega * alpha + (1 - omega) * self.config.quality_prior
    
    def compute_omega(self, **kwargs) -> float:
        """
        Compute reliability coefficient ω from context using adaptive 7-signal approach.

        ADAPTIVE SIGNAL INCLUSION:
        -------------------------
        This function adapts to different usage scenarios by detecting which signals
        are providing meaningful information vs. which are saturated (always 0 or 1).
        
        - In "learning system" mode: SDM/Hopfield are trained and provide varied signals
        - In "OOD detection" mode: SDM may return 0 (no matches), so only replay similarity is used
        - Signals that are saturated (<=0.01 or >=0.99) are EXCLUDED from computation
        - This allows the function to gracefully handle both scenarios with ONE implementation
        
        The 7 Signals (Sense Bus integration):
        1. SDM read confidence - low means pattern is far from stored addresses
        2. Hopfield retrieval energy - high means pattern doesn't match prototypes
        3. Replay buffer similarity - distance to nearest stored experience (always useful)
        4. Consistency - variance of recent α values (from reliability monitor)
        5. Trend - direction of α movement (from reliability monitor)
        6. Decision stability - how often predictions change (from reliability monitor)
        7. Hidden coherence - feature similarity across time (from reliability monitor)

        Signals 1-3 are computed locally from memory layers.
        Signals 4-7 are obtained from IReliabilityMonitor (Sense Bus) if available.
        
        SATURATION DETECTION:
        --------------------
        A signal is considered "saturated" if it's <=0.01 or >=0.99, meaning it's
        not providing discriminative information. Saturated signals are excluded
        from the geometric mean to prevent them from dominating the result.
        
        Example scenarios:
        - SDM=0.0, Hopfield=1.0, Replay=0.3 → Only Replay used → ω=0.3
        - SDM=0.7, Hopfield=0.6, Replay=0.4 → All used → ω=geomean(0.7,0.6,0.4)

        Returns:
            ω in [0, 1] where:
            - 1.0 = in-distribution (trust measurement)
            - < 0.5 = out-of-distribution (reduce confidence)

        Subclasses can override for domain-specific OOD detection.
        """
        if not self.config.compute_omega:
            return self.config.omega_default

        try:
            # Encode context for OOD checks
            context, binary_addr = self.encode_context(**kwargs)
        except Exception:
            # Can't encode -> treat as OOD
            return 0.3

        # Threshold for detecting saturated signals (not providing information)
        SATURATION_LOW = 0.01
        SATURATION_HIGH = 0.99
        
        def is_informative(signal_value: float) -> bool:
            """Check if signal is providing discriminative information (not saturated)."""
            return SATURATION_LOW < signal_value < SATURATION_HIGH

        # === Signals 1-3: Core OOD signals (local to memory layers) ===
        core_signals = []

        # Signal 1: SDM read confidence
        # NOTE: SDM may return 0 if binary addresses don't match stored patterns
        # In this case, we exclude it rather than letting it kill omega
        try:
            _, sdm_confidence = self.sdm.read(binary_addr)
            sdm_omega = float(np.clip(sdm_confidence, 0, 1))
            if is_informative(sdm_omega):
                core_signals.append(sdm_omega)
            # If saturated (0 or 1), signal is excluded - it's not providing useful info
        except Exception:
            pass

        # Signal 2: Hopfield retrieval confidence
        # NOTE: Hopfield may return 1.0 if it's not discriminating between patterns
        # In this case, we exclude it
        try:
            _, hopfield_conf, _ = self.hopfield.retrieve_by_label(context, beta=1.0)
            hopfield_omega = float(np.clip(hopfield_conf, 0, 1))
            if is_informative(hopfield_omega):
                core_signals.append(hopfield_omega)
            # If saturated (0 or 1), signal is excluded - it's not providing useful info
        except Exception:
            pass

        # Signal 3: Replay buffer similarity (distance-based)
        # NOTE: This is the most reliable signal for OOD detection - always include if available
        # It computes exp(-distance/scale) which naturally varies with input similarity
        #
        # IMPORTANT: Scale must be based on TRAINING data distances, not test data norm!
        # Using test data norm causes OOD samples with large norms to get artificially high omega.
        # Instead, we use median inter-sample distance from stored experiences as the scale.
        try:
            if hasattr(self.replay, 'experiences') and len(self.replay.experiences) > 0:
                # Use up to 500 experiences for better coverage (was 100)
                experiences = list(self.replay.experiences)[:500]
                if experiences:
                    stored_contexts = np.array([e.context for e in experiences if e is not None])
                    if len(stored_contexts) > 0:
                        # Compute distance to nearest stored experience
                        distances = np.linalg.norm(stored_contexts - context, axis=1)
                        min_dist = np.min(distances)
                        
                        # Compute scale from stored data (median inter-sample distance)
                        # This is cached after first computation for efficiency
                        if not hasattr(self, '_omega_scale') or self._omega_scale is None or self._omega_scale == float('inf'):
                            # Need at least 2 samples to compute inter-sample distance
                            if len(stored_contexts) >= 2:
                                # Sample up to 50 pairs to estimate median distance
                                n_samples = min(50, len(stored_contexts))
                                sample_idx = np.random.choice(len(stored_contexts), n_samples, replace=False)
                                sample_dists = []
                                for i in sample_idx:
                                    other_dists = np.linalg.norm(stored_contexts - stored_contexts[i], axis=1)
                                    other_dists[i] = np.inf  # Exclude self
                                    min_other = np.min(other_dists)
                                    if min_other < float('inf'):
                                        sample_dists.append(min_other)
                                if sample_dists:
                                    self._omega_scale = float(np.median(sample_dists))
                                else:
                                    # Fallback: use mean norm of stored contexts
                                    self._omega_scale = float(np.mean(np.linalg.norm(stored_contexts, axis=1)))
                            else:
                                # Single sample: use its norm as scale
                                self._omega_scale = float(np.linalg.norm(stored_contexts[0]))
                            
                            # Ensure scale is reasonable (not too small or inf)
                            if self._omega_scale < 0.01 or self._omega_scale == float('inf'):
                                self._omega_scale = 10.0  # Default reasonable scale
                        
                        scale = self._omega_scale
                        replay_omega = float(np.exp(-min_dist / scale))
                        # Always include replay similarity - it's distance-based and reliable
                        core_signals.append(replay_omega)
        except Exception:
            pass

        # === Signals 4-7: Sense Bus signals (from reliability monitor) ===
        # These signals "fade in" as temporal history builds up
        sense_signals = []

        if self.reliability_monitor is not None:
            try:
                reliability_signals = self.reliability_monitor.get_reliability_signals(n=5)
                # Only include signals that are informative (not saturated)
                for signal_value, signal_name in [
                    (reliability_signals.consistency, "consistency"),
                    (reliability_signals.trend, "trend"),
                    (reliability_signals.decision_stability, "decision_stability"),
                    (reliability_signals.hidden_coherence, "hidden_coherence"),
                ]:
                    if signal_value is not None and is_informative(signal_value):
                        sense_signals.append(signal_value)
            except Exception:
                pass

        # === Combine all informative signals ===
        all_signals = core_signals + sense_signals

        if not all_signals:
            return self.config.omega_default

        # Use geometric mean (sensitive to low values - any low signal pulls down ω)
        # Since saturated signals are excluded, this now works correctly for both:
        # - Learning systems (multiple signals contribute)
        # - OOD detection (only replay similarity contributes when SDM/Hopfield saturated)
        omega = float(np.exp(np.mean(np.log(np.array(all_signals) + 1e-8))))

        return float(np.clip(omega, 0.0, 1.0))

    def compute_omega_detailed(self, **kwargs) -> Dict[str, Any]:
        """
        Compute ω with detailed signal breakdown (for debugging/observability).

        Returns all 7 signals individually plus the combined ω.
        Use this when you need to understand why ω is low.

        Returns:
            Dict with individual signals and combined omega:
            - sdm_confidence: Signal 1
            - hopfield_confidence: Signal 2
            - replay_similarity: Signal 3
            - consistency: Signal 4 (from reliability monitor)
            - trend: Signal 5 (from reliability monitor)
            - decision_stability: Signal 6 (from reliability monitor)
            - hidden_coherence: Signal 7 (from reliability monitor)
            - omega: Combined ω value
            - signal_count: Number of signals used
        """
        result = {
            "sdm_confidence": None,
            "hopfield_confidence": None,
            "replay_similarity": None,
            "consistency": None,
            "trend": None,
            "decision_stability": None,
            "hidden_coherence": None,
            "omega": self.config.omega_default,
            "signal_count": 0,
        }

        if not self.config.compute_omega:
            return result

        try:
            context, binary_addr = self.encode_context(**kwargs)
        except Exception:
            result["omega"] = 0.3
            return result

        all_signals = []

        # Signal 1: SDM
        try:
            _, sdm_confidence = self.sdm.read(binary_addr)
            result["sdm_confidence"] = float(np.clip(sdm_confidence, 0, 1))
            all_signals.append(result["sdm_confidence"])
        except Exception:
            pass

        # Signal 2: Hopfield
        try:
            _, hopfield_conf, _ = self.hopfield.retrieve_by_label(context, beta=1.0)
            result["hopfield_confidence"] = float(np.clip(hopfield_conf, 0, 1))
            all_signals.append(result["hopfield_confidence"])
        except Exception:
            pass

        # Signal 3: Replay (distance-based - most reliable for OOD)
        try:
            if hasattr(self.replay, 'experiences') and len(self.replay.experiences) > 0:
                # Use up to 500 experiences for better coverage
                experiences = list(self.replay.experiences)[:500]
                if experiences:
                    stored_contexts = np.array([e.context for e in experiences if e is not None])
                    if len(stored_contexts) > 0:
                        distances = np.linalg.norm(stored_contexts - context, axis=1)
                        min_dist = np.min(distances)
                        # Use cached omega_scale if available, else use context norm
                        scale = getattr(self, '_omega_scale', None)
                        if scale is None or scale <= 0:
                            scale = np.linalg.norm(context) + 1e-8
                        result["replay_similarity"] = float(np.exp(-min_dist / scale))
                        all_signals.append(result["replay_similarity"])
        except Exception:
            pass

        # Signals 4-7: Sense Bus
        if self.reliability_monitor is not None:
            try:
                reliability_signals = self.reliability_monitor.get_reliability_signals(n=5)
                result["consistency"] = reliability_signals.consistency
                result["trend"] = reliability_signals.trend
                result["decision_stability"] = reliability_signals.decision_stability
                result["hidden_coherence"] = reliability_signals.hidden_coherence
                all_signals.extend([
                    reliability_signals.consistency,
                    reliability_signals.trend,
                    reliability_signals.decision_stability,
                    reliability_signals.hidden_coherence,
                ])
            except Exception:
                pass

        # Combine
        result["signal_count"] = len(all_signals)
        if all_signals:
            result["omega"] = float(np.exp(np.mean(np.log(np.array(all_signals) + 1e-8))))
            result["omega"] = float(np.clip(result["omega"], 0.0, 1.0))

        return result
    
    def compute_temperature_with_safety(self, alpha: float, omega: Optional[float] = None) -> float:
        """
        Compute τ with safety constraints (control discipline).
        
        This replaces the simple τ = 1/α with:
        1. α_ω computation (reliability-adjusted)
        2. Safety barrier enforcement
        3. Bounded τ output
        
        Args:
            alpha: Raw quality α
            omega: Reliability coefficient (None = use config default)
        
        Returns:
            Bounded temperature τ with safety constraints
        """
        # Compute α_ω
        alpha_omega = self.compute_alpha_omega(alpha, omega)
        
        # Base temperature
        tau_base = 1.0 / alpha_omega if alpha_omega > 0 else self.config.max_temperature
        
        # Apply safety constraints if enabled
        if self.config.enable_control_constraints:
            # Safety barrier check
            h = alpha_omega - self.config.alpha_min
            
            if h < 0:
                # Safety violation → force conservative behavior
                tau = self.config.max_temperature
            else:
                # Safe → clamp to bounds
                tau = np.clip(tau_base, self.config.min_temperature, self.config.max_temperature)
        else:
            # No constraints → use base temperature with simple bounds
            tau = np.clip(tau_base, self.config.min_temperature, self.config.max_temperature)
        
        return tau
    
    def safety_barrier(self, alpha: float, omega: Optional[float] = None) -> float:
        """
        Barrier function: h(x) = α_ω - α_min.
        
        Returns:
            Barrier value (positive = safe, negative = unsafe)
        """
        alpha_omega = self.compute_alpha_omega(alpha, omega)
        return alpha_omega - self.config.alpha_min
    
    def can_predict(self, alpha: float, tau: float, omega: Optional[float] = None) -> bool:
        """
        Check if prediction is safe (barrier function + τ constraint).
        
        Returns:
            True if prediction is allowed, False if should abstain
        """
        if not self.config.enable_control_constraints:
            return True  # No constraints → always allow
        
        h = self.safety_barrier(alpha, omega)
        return h >= 0 and tau <= self.config.tau_pred_max
    
    def can_learn(self, alpha: float, alpha_prev: float, tau: float, omega: Optional[float] = None) -> bool:
        """
        Check if learning is safe (barrier improvement + τ constraint).
        
        Learning is allowed only if:
        1. Barrier is improving (non-degrading)
        2. τ is below write threshold
        
        Returns:
            True if learning is allowed, False if should skip
        """
        if not self.config.enable_control_constraints:
            return True  # No constraints → always allow
        
        h_current = self.safety_barrier(alpha, omega)
        h_prev = self.safety_barrier(alpha_prev, omega)
        
        # Barrier must be improving (non-degrading)
        barrier_improving = h_current >= h_prev - self.config.stability_epsilon
        tau_safe = tau <= self.config.tau_write_max
        
        return barrier_improving and tau_safe

    # =========================================================================
    # PREDICTION
    # =========================================================================

    def predict(self, **kwargs) -> PredictionResult:
        """
        Make a prediction using the 4-layer memory system.
        
        ⚠️  HEXAGONAL ARCHITECTURE COMPLIANCE:
        This method now ALWAYS returns a prediction + quality signal.
        It DOES NOT enforce abstention (that's control, belongs in adapters).
        
        The prediction includes a 'safety_signal' in metadata with:
        - recommended_action: 'ABSTAIN' or 'PROCEED'
        - reason: Why abstention is recommended
        - barrier_value: Safety barrier h(α, ω)
        
        CONSUMERS CHOOSE whether to use the prediction or abstain based on signal.
        
        OLD BEHAVIOR (WRONG):
        - Enforced abstention by returning label="ABSTAIN"
        - Control logic in core (violates hex architecture)
        
        NEW BEHAVIOR (CORRECT):
        - Always returns best prediction
        - Includes safety signal in metadata
        - Consumer decides whether to use prediction or abstain

        Args:
            **kwargs: Domain-specific inputs passed to encode_context()

        Returns:
            PredictionResult with label, confidence, safety signal in metadata
        """
        cfg = self.config

        # Get quality and compute α_ω
        alpha = self.compute_quality(**kwargs)
        omega = self.compute_omega(**kwargs)
        alpha_omega = self.compute_alpha_omega(alpha, omega)
        
        # Compute temperature with safety constraints
        tau = self.compute_temperature_with_safety(alpha, omega)
        phase = self.get_phase(tau)
        beta = 1.0 / tau  # Inverse temperature for Hopfield

        # Assess safety (SIGNAL, not CONTROL)
        can_predict_safely = self.can_predict(alpha, tau, omega)
        safety_signal = {
            "recommended_action": "PROCEED" if can_predict_safely else "ABSTAIN",
            "reason": "safety_ok" if can_predict_safely else "safety_barrier_violated",
            "barrier_value": self.safety_barrier(alpha, omega),
            "alpha": alpha,
            "alpha_omega": alpha_omega,
            "omega": omega,
            "tau": tau,
            "tau_pred_max": cfg.tau_pred_max,
            "can_predict_safely": can_predict_safely,
        }

        # Encode context
        context, binary_addr = self.encode_context(**kwargs)

        # Query Layer 1: SDM
        sdm_result, sdm_confidence = self.sdm.read(binary_addr)
        sdm_label, sdm_label_conf = self._vector_to_label(sdm_result)

        # Query Layer 2: Hopfield
        hopfield_label, hopfield_conf, hopfield_probs = self.hopfield.retrieve_by_label(
            context, beta=beta
        )

        # Combine predictions
        label_probs = self._combine_predictions(
            sdm_label, sdm_label_conf,
            hopfield_probs,
            tau
        )

        # Get best label and margin
        sorted_labels = sorted(label_probs.items(), key=lambda x: x[1], reverse=True)
        best_label = sorted_labels[0][0]
        confidence = sorted_labels[0][1]
        margin = sorted_labels[0][1] - sorted_labels[1][1] if len(sorted_labels) > 1 else 1.0

        # Apply domain-specific routing
        final_label = self.apply_routing(best_label, confidence, margin, tau, phase)

        # Boost similar memories (memristive reinforcement)
        self.replay.boost_similar(context, threshold=0.8, boost=1.2)

        self.step += 1
        self.total_predictions += 1

        # Return prediction + safety signal (consumer decides whether to use)
        return PredictionResult(
            label=final_label,
            confidence=confidence,
            label_probabilities=label_probs,
            temperature=tau,
            phase=phase,
            margin=margin,
            metadata={
                "alpha": alpha,
                "alpha_omega": alpha_omega,
                "omega": omega,
                "sdm_label": sdm_label,
                "sdm_confidence": sdm_label_conf,
                "hopfield_label": hopfield_label,
                "hopfield_confidence": hopfield_conf,
                # NEW: Safety signal (measurement, not control)
                "safety_signal": safety_signal,
            }
        )

    def _vector_to_label(self, vec: np.ndarray) -> Tuple[str, float]:
        """Convert output vector to label with confidence."""
        n_labels = len(self.LABELS)
        segment_size = len(vec) // n_labels

        scores = {}
        for i, label in enumerate(self.LABELS):
            start = i * segment_size
            end = start + segment_size
            scores[label] = float(np.mean(vec[start:end]))

        best_label = max(scores, key=scores.get)

        # Softmax for confidence
        exp_scores = {k: np.exp(v) for k, v in scores.items()}
        total = sum(exp_scores.values())
        confidence = exp_scores[best_label] / total if total > 0 else 0.5

        return best_label, confidence

    def _label_to_vector(self, label: str) -> np.ndarray:
        """Convert label to bipolar vector."""
        dim = self.config.context_dim
        n_labels = len(self.LABELS)
        segment_size = dim // n_labels

        vec = np.full(dim, -1.0)

        try:
            idx = self.LABELS.index(label)
            start = idx * segment_size
            end = start + segment_size
            vec[start:end] = 1.0
        except ValueError:
            pass  # Unknown label

        return vec

    def _combine_predictions(
        self,
        sdm_label: str,
        sdm_conf: float,
        hopfield_probs: Dict[str, float],
        tau: float
    ) -> Dict[str, float]:
        """Combine SDM and Hopfield predictions."""
        cfg = self.config

        # Initialize with small prior
        combined = {label: 0.01 for label in self.LABELS}

        # SDM contribution
        if sdm_label in combined:
            combined[sdm_label] += cfg.sdm_weight * sdm_conf

        # Hopfield contribution (weighted more when it has patterns)
        has_patterns = len(self.hopfield.patterns) > 0
        hop_weight = cfg.hopfield_weight * 2 if has_patterns else 0.0

        for label, prob in hopfield_probs.items():
            if label in combined:
                combined[label] += hop_weight * prob

        # Normalize
        total = sum(combined.values())
        if total > 0:
            combined = {k: v / total for k, v in combined.items()}

        return combined

    # =========================================================================
    # LEARNING
    # =========================================================================

    def learn(
        self,
        predicted: str,
        actual: str,
        feedback: Optional[Dict[str, Any]] = None,
        **context_kwargs
    ) -> LearningResult:
        """
        Learn from a prediction outcome.
        
        With control constraints enabled, this will skip learning if:
        - Barrier is degrading (h_current < h_prev - ε)
        - τ exceeds write threshold

        Args:
            predicted: Label that was predicted
            actual: Ground truth label
            feedback: Optional domain-specific feedback
            **context_kwargs: Context for computing quality

        Returns:
            LearningResult with reward, temperature, and stats
        """
        cfg = self.config

        # Get current and previous quality
        alpha_current = self.compute_quality(**context_kwargs)
        alpha_prev = self._last_alpha
        omega = self.compute_omega(**context_kwargs)
        alpha_omega_current = self.compute_alpha_omega(alpha_current, omega)
        
        # Compute temperature with safety constraints
        tau = self.compute_temperature_with_safety(alpha_current, omega)
        
        # Check if learning is safe (if constraints enabled)
        if not self.can_learn(alpha_current, alpha_prev, tau, omega):
            # Safety violation → skip learning
            return LearningResult(
                reward=0.0,
                temperature=tau,
                was_correct=False,
                batch_learned=False,
                batch_stats={
                    "alpha": alpha_current,
                    "alpha_omega": alpha_omega_current,
                    "alpha_prev": alpha_prev,
                    "omega": omega,
                    "reason": "learning_blocked_by_safety",
                    "h_current": self.safety_barrier(alpha_current, omega),
                    "h_prev": self.safety_barrier(alpha_prev, omega),
                    "tau": tau,
                    "tau_write_max": self.config.tau_write_max,
                }
            )
        
        # Use alpha_current for rest of method
        alpha = alpha_current

        # Encode context
        context, binary_addr = self.encode_context(**context_kwargs)

        # Compute reward
        reward = self.compute_reward(predicted, actual, feedback)
        was_correct = predicted == actual

        if was_correct:
            self.correct_predictions += 1

        # Layer 2: Store in Hopfield (Hebbian learning)
        strength = abs(reward) + 0.5  # Higher strength for surprising outcomes
        self.hopfield.store(
            pattern=context,
            label=actual,
            metadata={"reward": reward, "predicted": predicted},
            strength=strength
        )

        # Layer 4: Add to Replay buffer
        self.replay.add(
            context=context,
            action=predicted,
            confidence=0.5,  # Could be passed from prediction
            outcome=actual,
            reward=reward,
            context_raw=context_kwargs
        )

        # Periodic batch learning
        batch_learned = False
        batch_stats = {}

        if self.step % cfg.learn_every_n_steps == 0:
            batch_stats = self._batch_learn(tau)
            batch_learned = batch_stats.get("batch_learned", False)

        # Update last alpha for next iteration
        self._last_alpha = alpha_current
        self._last_alpha_omega = alpha_omega_current

        # Add stability stats to batch_stats
        batch_stats.update({
            "alpha": alpha_current,
            "alpha_omega": alpha_omega_current,
            "omega": omega,
            "tau": tau,
        })

        return LearningResult(
            reward=reward,
            temperature=tau,
            was_correct=was_correct,
            batch_learned=batch_learned,
            batch_stats=batch_stats
        )

    def _batch_learn(self, tau: float) -> Dict[str, Any]:
        """Batch learning from replay buffer with EWC protection."""
        cfg = self.config

        # Sample batch
        experiences, weights, indices = self.replay.sample()

        if not experiences:
            return {"batch_learned": False}

        # Compute gradients
        gradients = []
        td_errors = []

        for exp, weight in zip(experiences, weights):
            # Target: vector for correct outcome
            target = self._label_to_vector(exp.outcome)

            # Gradient: direction toward correct outcome
            grad = weight * (target - exp.context) * cfg.learning_rate
            gradients.append(grad)

            # TD error for priority update
            td_error = abs(exp.reward)
            td_errors.append(td_error)

        # Average gradient
        avg_gradient = np.mean(gradients, axis=0)

        # Layer 3: Apply EWC-protected update
        if self.ewc.task_memories:
            self.ewc.apply_gradient_with_ewc(
                gradient=avg_gradient,
                learning_rate=cfg.learning_rate,
                tau=tau
            )
        else:
            # No EWC protection yet - just update
            self.ewc.update_fisher(avg_gradient)

        # Update replay priorities
        self.replay.update_priorities(indices, td_errors)

        # Periodic priority decay
        if self.step % 100 == 0:
            self.replay.decay_priorities()

        return {
            "batch_learned": True,
            "batch_size": len(experiences),
            "avg_td_error": float(np.mean(td_errors)),
        }

    # =========================================================================
    # A PRIORI LOADING
    # =========================================================================

    def load_apriori(
        self,
        historical_data: List[Dict[str, Any]],
        importance: float = 2.0
    ) -> Dict[str, int]:
        """
        Load a priori knowledge from historical data.

        Args:
            historical_data: List of dicts with context kwargs + "outcome" key
            importance: Weight for these memories (higher = more protected)

        Returns:
            Statistics about loaded data
        """
        sdm_patterns = []
        hopfield_counts = {label: 0 for label in self.LABELS}

        for record in historical_data:
            # Extract outcome
            outcome = record.pop("outcome", self.LABELS[0])

            # Encode context (remaining keys are context kwargs)
            context, binary_addr = self.encode_context(**record)

            # Restore outcome to record
            record["outcome"] = outcome

            # SDM: Store address→outcome association
            data = self._label_to_vector(outcome)
            sdm_patterns.append((binary_addr, data))

            # Hopfield: Store pattern
            self.hopfield.store(
                pattern=context,
                label=outcome,
                metadata={"source": "apriori"},
                strength=importance
            )
            hopfield_counts[outcome] = hopfield_counts.get(outcome, 0) + 1

        # Load into SDM
        self.sdm.load_apriori(sdm_patterns, weight=importance * 5)

        # Initialize EWC from mean context
        if historical_data:
            contexts = []
            for record in historical_data:
                outcome = record.pop("outcome", self.LABELS[0])
                ctx, _ = self.encode_context(**record)
                record["outcome"] = outcome
                contexts.append(ctx)

            mean_context = np.mean(contexts, axis=0)
            self.ewc.load_apriori(
                weights=mean_context,
                task_id="historical_baseline",
                importance=importance
            )

        return {
            "sdm_patterns": len(sdm_patterns),
            "hopfield_patterns": sum(hopfield_counts.values()),
            "hopfield_by_label": hopfield_counts,
        }

    # =========================================================================
    # CONSOLIDATION & STATISTICS
    # =========================================================================

    def consolidate(self, task_id: str = "current") -> None:
        """Consolidate current learning into protected memory."""
        importance = 1.0 + (self.correct_predictions / max(1, self.total_predictions))
        self.ewc.consolidate_task(task_id, importance=importance)

    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        return {
            "step": self.step,
            "total_predictions": self.total_predictions,
            "correct_predictions": self.correct_predictions,
            "accuracy": self.correct_predictions / max(1, self.total_predictions),
            "labels": self.LABELS,
            "sdm": self.sdm.get_statistics(),
            "hopfield": self.hopfield.get_statistics(),
            "ewc": self.ewc.get_statistics(),
            "replay": self.replay.compute_statistics(),
        }

    def save_state(self) -> Dict[str, Any]:
        """Save complete learner state."""
        return {
            "config": {
                "context_dim": self.config.context_dim,
                "binary_dim": self.config.binary_dim,
                "learning_rate": self.config.learning_rate,
                "temperature_mode": self.config.temperature_mode,
            },
            "step": self.step,
            "total_predictions": self.total_predictions,
            "correct_predictions": self.correct_predictions,
            "sdm": self.sdm.save_state(),
            "hopfield": self.hopfield.save_state(),
            "ewc": self.ewc.save_state(),
            "replay": self.replay.save_state(),
            # OMEGA STATE: Required for compute_omega() to work after reload
            # Without this, omega will return omega_default until replay is repopulated
            "_omega_scale": getattr(self, '_omega_scale', None),
        }

    def load_state(self, state: Dict[str, Any]) -> None:
        """
        Load learner state.
        
        IMPORTANT: This restores the replay buffer and omega scale, which are
        required for compute_omega() to work correctly. If loading a state that
        was saved before omega was computed, omega will use default values until
        new data is learned.
        """
        self.step = state["step"]
        self.total_predictions = state["total_predictions"]
        self.correct_predictions = state["correct_predictions"]
        self.sdm.load_state(state["sdm"])
        self.hopfield.load_state(state["hopfield"])
        self.ewc.load_state(state["ewc"])
        self.replay.load_state(state["replay"])
        # Restore omega scale (critical for compute_omega to work)
        self._omega_scale = state.get("_omega_scale", None)

    def clear(self) -> None:
        """Clear all memories and reset (including omega state)."""
        self.sdm.clear()
        self.hopfield.clear()
        self.ewc.clear()
        self.replay.clear()
        self.step = 0
        self.total_predictions = 0
        self.correct_predictions = 0
        # Reset omega scale - will be recomputed when replay is repopulated
        self._omega_scale = None

    # =========================================================================
    # OMEGA STATE MANAGEMENT
    # =========================================================================
    # 
    # IMPORTANT: compute_omega() depends on the REPLAY BUFFER being populated
    # with training data. Without training data in the replay buffer, omega
    # will return the default value (omega_default) or compute poorly.
    #
    # The omega computation uses:
    # 1. Replay buffer experiences - for distance-based similarity (Signal 3)
    # 2. _omega_scale - calibrated from inter-sample distances in replay buffer
    #
    # If you're using omega for OOD detection, you MUST:
    # 1. Call learn() with training data to populate the replay buffer, OR
    # 2. Load a saved state that includes replay buffer + omega scale
    #
    # Example for OOD detection:
    #     # Option 1: Learn from training data
    #     for embedding in training_embeddings:
    #         learner.learn(predicted="ID", actual="ID", embedding=embedding)
    #     omega = learner.compute_omega(embedding=test_embedding)
    #
    #     # Option 2: Save/load state
    #     state = learner.save_state()  # After training
    #     # ... later ...
    #     learner.load_state(state)
    #     omega = learner.compute_omega(embedding=test_embedding)  # Works!
    # =========================================================================

    def get_omega_state(self) -> Dict[str, Any]:
        """
        Get the state required for compute_omega() to work.
        
        This is useful for saving/loading omega state separately from full state,
        or for inspecting the omega configuration.
        
        Returns:
            Dict with:
            - omega_scale: Calibrated scale for distance-to-omega conversion
            - replay_size: Number of experiences in replay buffer
            - omega_ready: Whether omega computation is properly initialized
        """
        replay_size = len(self.replay.experiences) if hasattr(self.replay, 'experiences') else 0
        omega_scale = getattr(self, '_omega_scale', None)
        
        return {
            "omega_scale": omega_scale,
            "replay_size": replay_size,
            "omega_ready": replay_size > 0 and omega_scale is not None and omega_scale != float('inf'),
        }

    def ensure_omega_ready(self, min_samples: int = 10) -> bool:
        """
        Check if omega computation is properly initialized.
        
        Call this before using compute_omega() in production to ensure
        the replay buffer is populated and omega scale is calibrated.
        
        Args:
            min_samples: Minimum number of samples required in replay buffer
            
        Returns:
            True if omega is ready to use, False if more training data needed
            
        Raises:
            Warning: If omega is not ready, logs a warning with instructions
        """
        state = self.get_omega_state()
        
        if not state["omega_ready"]:
            import warnings
            warnings.warn(
                f"compute_omega() not ready: replay_size={state['replay_size']}, "
                f"omega_scale={state['omega_scale']}. "
                f"Call learn() with training data first, or load a saved state."
            )
            return False
            
        if state["replay_size"] < min_samples:
            import warnings
            warnings.warn(
                f"compute_omega() has only {state['replay_size']} samples "
                f"(recommended: {min_samples}+). Results may be unreliable."
            )
            return False
            
        return True