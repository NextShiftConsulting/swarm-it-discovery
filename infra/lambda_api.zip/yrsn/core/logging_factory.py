"""
YRSN Centralized Logging Factory
================================

Provides consistent logging configuration across all YRSN modules.

Usage:
    from yrsn.core.logging_factory import get_logger

    logger = get_logger(__name__)
    logger.info("Processing started")

Configuration:
    Set environment variables to customize:
    - YRSN_LOG_LEVEL: DEBUG, INFO, WARNING, ERROR (default: INFO)
    - YRSN_LOG_FORMAT: "simple" or "detailed" (default: simple)
    - YRSN_LOG_FILE: Path to log file (optional)
"""

import logging
import os
import sys
from typing import Optional


# =============================================================================
# Configuration from Environment
# =============================================================================

_LOG_LEVEL = os.environ.get("YRSN_LOG_LEVEL", "INFO").upper()
_LOG_FORMAT = os.environ.get("YRSN_LOG_FORMAT", "simple")
_LOG_FILE = os.environ.get("YRSN_LOG_FILE", None)

# Format strings
_SIMPLE_FORMAT = "%(levelname)s - %(name)s - %(message)s"
_DETAILED_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s"

# Cache of configured loggers
_configured_loggers: set = set()


# =============================================================================
# Logger Factory
# =============================================================================


def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """
    Get a configured logger for a YRSN module.

    Args:
        name: Logger name (typically __name__)
        level: Optional override for log level

    Returns:
        Configured logging.Logger instance

    Example:
        from yrsn.core.logging_factory import get_logger
        logger = get_logger(__name__)
        logger.info("Hello from YRSN")
    """
    logger = logging.getLogger(name)

    # Only configure once per logger
    if name in _configured_loggers:
        return logger

    # Set level
    log_level = getattr(logging, level or _LOG_LEVEL, logging.INFO)
    logger.setLevel(log_level)

    # Don't add handlers if already has them (e.g., from parent)
    if not logger.handlers and not logger.parent.handlers:
        # Console handler
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(log_level)

        # Format
        format_str = _DETAILED_FORMAT if _LOG_FORMAT == "detailed" else _SIMPLE_FORMAT
        formatter = logging.Formatter(format_str)
        console_handler.setFormatter(formatter)

        logger.addHandler(console_handler)

        # File handler if configured
        if _LOG_FILE:
            try:
                file_handler = logging.FileHandler(_LOG_FILE)
                file_handler.setLevel(log_level)
                file_handler.setFormatter(logging.Formatter(_DETAILED_FORMAT))
                logger.addHandler(file_handler)
            except Exception as e:
                logger.warning(f"Could not create log file {_LOG_FILE}: {e}")

    _configured_loggers.add(name)
    return logger


def configure_root_logger(
    level: str = "INFO",
    format_style: str = "simple",
    log_file: Optional[str] = None,
) -> None:
    """
    Configure the root YRSN logger.

    Call this once at application startup for global configuration.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        format_style: "simple" or "detailed"
        log_file: Optional path to log file
    """
    global _LOG_LEVEL, _LOG_FORMAT, _LOG_FILE

    _LOG_LEVEL = level.upper()
    _LOG_FORMAT = format_style
    _LOG_FILE = log_file

    # Configure root yrsn logger
    root_logger = logging.getLogger("yrsn")
    root_logger.setLevel(getattr(logging, _LOG_LEVEL, logging.INFO))

    # Clear existing handlers
    root_logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler(sys.stderr)
    format_str = _DETAILED_FORMAT if _LOG_FORMAT == "detailed" else _SIMPLE_FORMAT
    console_handler.setFormatter(logging.Formatter(format_str))
    root_logger.addHandler(console_handler)

    # File handler
    if log_file:
        try:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(logging.Formatter(_DETAILED_FORMAT))
            root_logger.addHandler(file_handler)
        except Exception as e:
            root_logger.warning(f"Could not create log file: {e}")


def set_log_level(level: str) -> None:
    """
    Set log level for all YRSN loggers.

    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR)
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    yrsn_logger = logging.getLogger("yrsn")
    yrsn_logger.setLevel(log_level)

    for handler in yrsn_logger.handlers:
        handler.setLevel(log_level)


def silence_yrsn_logs() -> None:
    """Silence all YRSN logs (useful for testing)."""
    logging.getLogger("yrsn").setLevel(logging.CRITICAL)


def enable_debug_logs() -> None:
    """Enable debug logs for all YRSN modules."""
    set_log_level("DEBUG")


__all__ = [
    "get_logger",
    "configure_root_logger",
    "set_log_level",
    "silence_yrsn_logs",
    "enable_debug_logs",
]
