"""
Reservoir-based Signal-Noise Separator for YRSN
================================================

Decomposes temporal signals into R, S, N components using
reservoir computing for prediction-based separation.

Decomposition process:
1. Train ESN to predict next value (captures deterministic dynamics)
2. Prediction → R (Relevant, predictable signal)
3. Residual → S + N (unpredictable component)
4. Separate S (structured) from N (unstructured) via autocorrelation

Noise type identification:
- Additive: E[||ψ|| | q̂] = constant
- Multiplicative: E[||ψ|| | q̂] ∝ ||q̂||

Usage:
    from yrsn.core.reservoir import ReservoirSignalSeparator

    separator = ReservoirSignalSeparator()
    result = separator.decompose(time_series)

    # YRSN ratios
    R, S, N = result.to_yrsn()

    # Noise type
    print(result.noise_type)  # 'additive' or 'multiplicative'
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass

from .echo_state import EchoStateNetwork, ESNConfig


@dataclass
class SeparationResult:
    """
    Result of reservoir-based signal separation.

    Attributes
    ----------
    R : np.ndarray
        Relevant component (predictable signal)
    S : np.ndarray
        Superfluous component (structured residual)
    N : np.ndarray
        Noise component (unstructured residual)
    noise_type : str
        Detected noise type: 'additive', 'multiplicative', or 'unknown'
    prediction_error : float
        Mean squared prediction error
    signal_ratio : float
        Energy ratio of signal to total
    info : dict
        Additional diagnostic information
    """
    R: np.ndarray
    S: np.ndarray
    N: np.ndarray
    noise_type: str
    prediction_error: float
    signal_ratio: float
    info: Dict[str, Any]

    def to_yrsn(self) -> Tuple[float, float, float]:
        """
        Convert to YRSN ratios based on energy.

        Returns
        -------
        tuple of (R, S, N)
            Where R + S + N = 1.0
        """
        r_energy = np.sum(self.R ** 2)
        s_energy = np.sum(self.S ** 2)
        n_energy = np.sum(self.N ** 2)

        total = r_energy + s_energy + n_energy
        if total == 0:
            return (0.33, 0.33, 0.34)

        return (
            r_energy / total,
            s_energy / total,
            n_energy / total
        )

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary (without large arrays)."""
        R_ratio, S_ratio, N_ratio = self.to_yrsn()
        return {
            'yrsn': {'R': R_ratio, 'S': S_ratio, 'N': N_ratio},
            'noise_type': self.noise_type,
            'prediction_error': self.prediction_error,
            'signal_ratio': self.signal_ratio,
            'lengths': {
                'R': len(self.R),
                'S': len(self.S),
                'N': len(self.N)
            },
            'info': self.info
        }


class ReservoirSignalSeparator:
    """
    RC-based signal-noise separator for YRSN decomposition.

    Uses Echo State Networks to decompose temporal signals into:
    - R: Deterministic/predictable component
    - S: Structured but unpredictable patterns
    - N: Pure stochastic noise

    Parameters
    ----------
    reservoir_size : int
        Size of ESN reservoir (default 500)
    spectral_radius : float
        ESN spectral radius (default 0.9)
    leak_rate : float
        ESN leak rate (default 0.3)
    structure_threshold : float
        Autocorrelation threshold for S/N separation (default 2.0)
    esn_config : dict, optional
        Full ESN configuration override

    Examples
    --------
    >>> separator = ReservoirSignalSeparator()
    >>> result = separator.decompose(noisy_signal)
    >>> R, S, N = result.to_yrsn()
    >>> print(f"Signal quality: {R:.1%}")
    >>> print(f"Noise type: {result.noise_type}")
    """

    def __init__(
        self,
        reservoir_size: int = 500,
        spectral_radius: float = 0.9,
        leak_rate: float = 0.3,
        structure_threshold: float = 2.0,
        esn_config: Optional[Dict[str, Any]] = None
    ):
        # ESN configuration
        self.esn_config = esn_config or {
            'reservoir_size': reservoir_size,
            'spectral_radius': spectral_radius,
            'leak_rate': leak_rate
        }

        self.structure_threshold = structure_threshold
        self.esn: Optional[EchoStateNetwork] = None

    def decompose(
        self,
        X: np.ndarray,
        warmup: int = 100
    ) -> SeparationResult:
        """
        Decompose time series into R, S, N components.

        Parameters
        ----------
        X : np.ndarray
            Input time series (1D array)
        warmup : int
            ESN warmup period (default 100)

        Returns
        -------
        SeparationResult
            Decomposition with R, S, N arrays and diagnostics
        """
        X = np.asarray(X).flatten().astype(np.float64)

        if len(X) < warmup + 50:
            raise ValueError(
                f"Sequence too short: {len(X)} < {warmup + 50}. "
                f"Need at least warmup + 50 samples."
            )

        # Create and train ESN
        self.esn = EchoStateNetwork(**self.esn_config)
        self.esn.fit(X, warmup=warmup)

        # Separate signal and residual
        signal, residual = self.esn.separate(X)

        # Identify noise type
        noise_type = self._identify_noise_type(signal, residual)

        # Separate structured (S) from unstructured (N)
        S, N = self._separate_structured_noise(residual)

        # Compute metrics
        prediction_error = np.mean(residual ** 2)
        signal_energy = np.sum(signal ** 2)
        total_energy = signal_energy + np.sum(residual ** 2)
        signal_ratio = signal_energy / total_energy if total_energy > 0 else 0

        # Diagnostic info
        info = {
            'sequence_length': len(X),
            'output_length': len(signal),
            'esn_info': self.esn.get_info(),
            'residual_std': np.std(residual),
            'residual_autocorr': self._autocorr(residual, max_lag=10).tolist()
        }

        return SeparationResult(
            R=signal,
            S=S,
            N=N,
            noise_type=noise_type,
            prediction_error=prediction_error,
            signal_ratio=signal_ratio,
            info=info
        )

    def _identify_noise_type(
        self,
        signal: np.ndarray,
        residual: np.ndarray
    ) -> str:
        """
        Identify additive vs multiplicative noise.

        Additive: E[||ψ|| | q̂] = constant (flat relationship)
        Multiplicative: E[||ψ|| | q̂] ∝ ||q̂|| (increasing relationship)

        Parameters
        ----------
        signal : np.ndarray
            Predicted signal
        residual : np.ndarray
            Prediction residual

        Returns
        -------
        str
            'additive', 'multiplicative', or 'unknown'
        """
        if len(signal) < 50:
            return 'unknown'

        # Bin by signal magnitude
        abs_signal = np.abs(signal)
        try:
            bins = np.percentile(abs_signal, [20, 40, 60, 80])
        except (IndexError, ValueError):
            return 'unknown'

        bin_indices = np.digitize(abs_signal, bins)

        # Compute conditional residual magnitude
        cond_residual_std = []
        bin_centers = []

        for b in range(5):
            mask = bin_indices == b
            count = np.sum(mask)
            if count > 5:
                cond_residual_std.append(np.std(residual[mask]))
                bin_centers.append(np.mean(abs_signal[mask]))

        if len(cond_residual_std) < 3:
            return 'unknown'

        # Check correlation between signal magnitude and residual magnitude
        cond_residual_std = np.array(cond_residual_std)
        bin_centers = np.array(bin_centers)

        # Normalize for correlation
        if np.std(bin_centers) > 1e-10 and np.std(cond_residual_std) > 1e-10:
            corr = np.corrcoef(bin_centers, cond_residual_std)[0, 1]

            if corr > 0.6:
                return 'multiplicative'
            elif corr < 0.3:
                return 'additive'

        return 'unknown'

    def _separate_structured_noise(
        self,
        residual: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Separate structured (S) from unstructured (N) in residual.

        Uses autocorrelation to detect temporal structure.
        If significant autocorrelation exists, apply low-pass filter
        to extract structured component.

        Parameters
        ----------
        residual : np.ndarray
            Prediction residual

        Returns
        -------
        S : np.ndarray
            Structured component
        N : np.ndarray
            Unstructured noise
        """
        if len(residual) < 30:
            return np.zeros_like(residual), residual

        # Compute autocorrelation
        acf = self._autocorr(residual, max_lag=min(30, len(residual) // 3))

        # Threshold for significant autocorrelation
        threshold = self.structure_threshold / np.sqrt(len(residual))

        # Check for significant autocorrelation at lags 1-20
        significant_lags = np.where(np.abs(acf[1:21]) > threshold)[0]

        if len(significant_lags) >= 2:
            # Has temporal structure - extract via smoothing
            S = self._smooth_signal(residual, window=5)
            N = residual - S
        else:
            # Pure noise
            S = np.zeros_like(residual)
            N = residual

        return S, N

    def _smooth_signal(
        self,
        x: np.ndarray,
        window: int = 5
    ) -> np.ndarray:
        """
        Simple moving average smoothing.

        Parameters
        ----------
        x : np.ndarray
            Input signal
        window : int
            Smoothing window size

        Returns
        -------
        np.ndarray
            Smoothed signal
        """
        kernel = np.ones(window) / window
        # Pad to maintain length
        pad_width = window // 2
        x_padded = np.pad(x, pad_width, mode='edge')
        smoothed = np.convolve(x_padded, kernel, mode='valid')

        # Ensure same length
        if len(smoothed) > len(x):
            smoothed = smoothed[:len(x)]
        elif len(smoothed) < len(x):
            smoothed = np.pad(smoothed, (0, len(x) - len(smoothed)), mode='edge')

        return smoothed

    @staticmethod
    def _autocorr(x: np.ndarray, max_lag: int = 50) -> np.ndarray:
        """
        Compute normalized autocorrelation function.

        Parameters
        ----------
        x : np.ndarray
            Input signal
        max_lag : int
            Maximum lag to compute

        Returns
        -------
        np.ndarray
            Autocorrelation values for lags 0 to max_lag
        """
        x = x - np.mean(x)
        n = len(x)

        if n < 2:
            return np.array([1.0])

        # Use numpy correlate
        result = np.correlate(x, x, mode='full')
        result = result[n - 1:]  # Keep positive lags only

        # Normalize
        if result[0] > 0:
            result = result / result[0]

        return result[:min(max_lag + 1, len(result))]


# =============================================================================
# Integration with YRSN Framework
# =============================================================================

def temporal_decompose(
    X: np.ndarray,
    reservoir_size: int = 500,
    warmup: int = 100
) -> SeparationResult:
    """
    Decompose time series into YRSN components.

    Convenience function for reservoir-based temporal decomposition.

    Parameters
    ----------
    X : np.ndarray
        Input time series
    reservoir_size : int
        ESN reservoir size (default 500)
    warmup : int
        ESN warmup period (default 100)

    Returns
    -------
    SeparationResult
        Contains R, S, N arrays and to_yrsn() method

    Examples
    --------
    >>> result = temporal_decompose(stock_prices)
    >>> R, S, N = result.to_yrsn()
    >>> print(f"Signal: {R:.1%}, Structure: {S:.1%}, Noise: {N:.1%}")
    """
    separator = ReservoirSignalSeparator(reservoir_size=reservoir_size)
    return separator.decompose(X, warmup=warmup)


def temporal_yrsn_quality(X: np.ndarray, **kwargs) -> Tuple[float, float, float]:
    """
    Get YRSN ratios for time series.

    Direct convenience function that returns (R, S, N) tuple.

    Parameters
    ----------
    X : np.ndarray
        Input time series
    **kwargs
        Arguments passed to temporal_decompose

    Returns
    -------
    tuple of (R, S, N)
        YRSN ratios
    """
    result = temporal_decompose(X, **kwargs)
    return result.to_yrsn()
