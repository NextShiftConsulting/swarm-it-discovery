"""
Reservoir Computing for Temporal YRSN Decomposition
====================================================

Echo State Networks (ESN) for signal-noise separation in time series.

Extends YRSN to temporal data:
- R(t): Predictable/deterministic signal component
- S(t): Structured but unpredictable patterns
- N(t): Pure stochastic noise

The ESN learns to predict the next value in a sequence. The prediction
captures deterministic dynamics (R), while the residual contains S + N.

Usage:
    from yrsn.core.reservoir import (
        ReservoirSignalSeparator,
        temporal_decompose,
        temporal_yrsn_quality
    )

    # Full decomposition
    separator = ReservoirSignalSeparator()
    result = separator.decompose(time_series)
    R, S, N = result.to_yrsn()

    # Quick YRSN ratios
    R, S, N = temporal_yrsn_quality(time_series)

    # Noise type identification
    print(result.noise_type)  # 'additive' or 'multiplicative'

Integration with AdaptiveBackend:
    from yrsn.core.reservoir import temporal_decompose
    from yrsn.core.optimization import AdaptiveBackend

    result = temporal_decompose(optimization_trajectory)
    backend.update_yrsn_quality(*result.to_yrsn())
"""

from .echo_state import (
    EchoStateNetwork,
    ESNConfig,
    create_esn,
)

from .signal_separator import (
    ReservoirSignalSeparator,
    SeparationResult,
    temporal_decompose,
    temporal_yrsn_quality,
)

__all__ = [
    # Echo State Network
    "EchoStateNetwork",
    "ESNConfig",
    "create_esn",
    # Signal Separator
    "ReservoirSignalSeparator",
    "SeparationResult",
    # Convenience functions
    "temporal_decompose",
    "temporal_yrsn_quality",
]
