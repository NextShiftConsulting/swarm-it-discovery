"""
Echo State Network for Signal-Noise Separation
===============================================

Reservoir computing implementation for temporal YRSN decomposition.

An Echo State Network (ESN) uses a fixed random recurrent reservoir
to project inputs into a high-dimensional space, then learns a simple
linear readout to predict/reconstruct signals.

State update:
    r(t+1) = (1-α)r(t) + α·tanh(A·r(t) + W_in·x(t))

Readout:
    y(t) = W_out·r(t)

For signal-noise separation:
    - Trained to predict x(t+1) from r(t)
    - Prediction q̂ captures deterministic component (R)
    - Residual ψ = x - q̂ contains S + N

Usage:
    from yrsn.core.reservoir import EchoStateNetwork

    esn = EchoStateNetwork(reservoir_size=500)
    esn.fit(time_series)

    # Separate signal and noise
    signal, residual = esn.separate(time_series)

References:
- Lukoševičius & Jaeger (2009). Reservoir Computing Approaches
- arXiv:2404.04870 - Signal-noise separation using unsupervised RC
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class ESNConfig:
    """Configuration for Echo State Network."""
    reservoir_size: int = 500
    spectral_radius: float = 0.9
    input_scaling: float = 0.5
    leak_rate: float = 0.3
    sparsity: float = 0.9
    regularization: float = 1e-6
    random_seed: Optional[int] = None


class EchoStateNetwork:
    """
    Echo State Network for signal processing and separation.

    The ESN uses a random recurrent reservoir to capture temporal
    dynamics, with a trained linear readout for prediction.

    Parameters
    ----------
    reservoir_size : int
        Number of reservoir neurons (default 500)
    spectral_radius : float
        Spectral radius of reservoir matrix. Must be < 1 for
        echo state property (default 0.9)
    input_scaling : float
        Scaling factor for input weights (default 0.5)
    leak_rate : float
        Leaky integration rate α ∈ (0, 1]. Higher = faster
        dynamics (default 0.3)
    sparsity : float
        Fraction of zero weights in reservoir (default 0.9)
    regularization : float
        Ridge regression regularization λ (default 1e-6)
    random_seed : int, optional
        Random seed for reproducibility

    Examples
    --------
    >>> esn = EchoStateNetwork(reservoir_size=500)
    >>> esn.fit(training_data)
    >>> predictions = esn.predict(test_data)

    >>> # Signal-noise separation
    >>> signal, residual = esn.separate(noisy_data)
    """

    def __init__(
        self,
        reservoir_size: int = 500,
        spectral_radius: float = 0.9,
        input_scaling: float = 0.5,
        leak_rate: float = 0.3,
        sparsity: float = 0.9,
        regularization: float = 1e-6,
        random_seed: Optional[int] = None
    ):
        self.N = reservoir_size
        self.spectral_radius = spectral_radius
        self.input_scaling = input_scaling
        self.alpha = leak_rate
        self.sparsity = sparsity
        self.reg = regularization

        if random_seed is not None:
            np.random.seed(random_seed)

        # Initialize reservoir
        self._init_reservoir()

        # Readout weights (learned)
        self.W_out: Optional[np.ndarray] = None

        # Training state
        self._trained = False
        self._last_state: Optional[np.ndarray] = None

    def _init_reservoir(self):
        """Initialize reservoir with desired spectral radius."""
        # Random sparse reservoir matrix
        A = np.random.randn(self.N, self.N)

        # Apply sparsity mask
        mask = np.random.rand(self.N, self.N) > self.sparsity
        A = A * mask

        # Scale to desired spectral radius
        eigenvalues = np.linalg.eigvals(A)
        rho = np.max(np.abs(eigenvalues))
        if rho > 0:
            self.A = A * (self.spectral_radius / rho)
        else:
            self.A = A

        # Input weights (single input dimension)
        self.W_in = np.random.randn(self.N, 1) * self.input_scaling

    @property
    def is_trained(self) -> bool:
        """Whether the network has been trained."""
        return self._trained

    def fit(
        self,
        X: np.ndarray,
        warmup: int = 100
    ) -> 'EchoStateNetwork':
        """
        Train readout weights on input sequence.

        Learns to predict next value: x(t+1) = W_out @ r(t)

        Parameters
        ----------
        X : np.ndarray
            Training time series (1D array)
        warmup : int
            Number of initial steps to discard (reservoir warmup)

        Returns
        -------
        self
            Trained network
        """
        X = np.asarray(X).flatten()

        if len(X) < warmup + 10:
            raise ValueError(f"Sequence too short: {len(X)} < {warmup + 10}")

        # Collect reservoir states
        states = self._collect_states(X)

        # Discard warmup period
        R = states[warmup:-1]   # States at time t
        Y = X[warmup + 1:]      # Targets at time t+1

        # Ridge regression: W_out = (R^T R + λI)^{-1} R^T Y
        RtR = R.T @ R + self.reg * np.eye(self.N)
        RtY = R.T @ Y

        self.W_out = np.linalg.solve(RtR, RtY)
        self._trained = True
        self._last_state = states[-1]

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict/reconstruct signal component.

        Parameters
        ----------
        X : np.ndarray
            Input time series

        Returns
        -------
        np.ndarray
            Predicted signal (one step ahead predictions)
        """
        if not self._trained:
            raise RuntimeError("Network not trained. Call fit() first.")

        X = np.asarray(X).flatten()
        states = self._collect_states(X)

        return states @ self.W_out

    def separate(
        self,
        X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Separate signal and noise components.

        The ESN prediction captures the deterministic/predictable
        component (signal), while the residual contains noise and
        any unpredictable structure.

        Parameters
        ----------
        X : np.ndarray
            Input time series

        Returns
        -------
        signal : np.ndarray
            Reconstructed deterministic signal (R component)
        residual : np.ndarray
            Residual (S + N components)

        Notes
        -----
        Output arrays are shorter than input by 1 due to prediction
        alignment (predicting x(t+1) from state at t).
        """
        if not self._trained:
            raise RuntimeError("Network not trained. Call fit() first.")

        X = np.asarray(X).flatten()
        predictions = self.predict(X)

        # Align: prediction[t] predicts X[t+1]
        signal = predictions[:-1]
        residual = X[1:] - signal

        return signal, residual

    def _collect_states(self, X: np.ndarray) -> np.ndarray:
        """
        Run reservoir and collect all states.

        Parameters
        ----------
        X : np.ndarray
            Input sequence

        Returns
        -------
        np.ndarray
            Reservoir states, shape (len(X), reservoir_size)
        """
        T = len(X)
        states = np.zeros((T, self.N))
        r = np.zeros(self.N)

        W_in_flat = self.W_in.flatten()

        for t in range(T):
            # Leaky integration with tanh nonlinearity
            pre_activation = self.A @ r + W_in_flat * X[t]
            r = (1 - self.alpha) * r + self.alpha * np.tanh(pre_activation)
            states[t] = r

        return states

    def forecast(
        self,
        X: np.ndarray,
        horizon: int = 10
    ) -> np.ndarray:
        """
        Generate multi-step forecast.

        Parameters
        ----------
        X : np.ndarray
            Seed sequence to initialize reservoir state
        horizon : int
            Number of steps to forecast

        Returns
        -------
        np.ndarray
            Forecasted values
        """
        if not self._trained:
            raise RuntimeError("Network not trained. Call fit() first.")

        X = np.asarray(X).flatten()

        # Initialize with seed sequence
        states = self._collect_states(X)
        r = states[-1]

        # Generate forecast
        forecast = np.zeros(horizon)
        x_prev = X[-1]

        W_in_flat = self.W_in.flatten()

        for t in range(horizon):
            # Predict next value
            y = r @ self.W_out

            # Update state with prediction as input
            pre_activation = self.A @ r + W_in_flat * x_prev
            r = (1 - self.alpha) * r + self.alpha * np.tanh(pre_activation)

            forecast[t] = y
            x_prev = y

        return forecast

    def get_info(self) -> Dict[str, Any]:
        """Get network information and statistics."""
        return {
            'reservoir_size': self.N,
            'spectral_radius': self.spectral_radius,
            'leak_rate': self.alpha,
            'sparsity': self.sparsity,
            'trained': self._trained,
            'reservoir_density': np.mean(self.A != 0),
            'reservoir_norm': np.linalg.norm(self.A, 'fro'),
        }

    def state_dict(self) -> Dict[str, Any]:
        """Export network state for serialization."""
        return {
            'A': self.A,
            'W_in': self.W_in,
            'W_out': self.W_out,
            'config': {
                'reservoir_size': self.N,
                'spectral_radius': self.spectral_radius,
                'input_scaling': self.input_scaling,
                'leak_rate': self.alpha,
                'sparsity': self.sparsity,
                'regularization': self.reg,
            }
        }

    @classmethod
    def from_state_dict(cls, state: Dict[str, Any]) -> 'EchoStateNetwork':
        """Load network from state dict."""
        config = state['config']
        esn = cls(**config)
        esn.A = state['A']
        esn.W_in = state['W_in']
        esn.W_out = state['W_out']
        esn._trained = state['W_out'] is not None
        return esn


# =============================================================================
# Convenience Functions
# =============================================================================

def create_esn(
    size: str = 'medium',
    spectral_radius: float = 0.9,
    random_seed: Optional[int] = None
) -> EchoStateNetwork:
    """
    Create ESN with preset size configuration.

    Parameters
    ----------
    size : str
        'small' (100), 'medium' (500), 'large' (1000), 'xlarge' (2000)
    spectral_radius : float
        Spectral radius (default 0.9)
    random_seed : int, optional
        Random seed

    Returns
    -------
    EchoStateNetwork
    """
    sizes = {
        'small': 100,
        'medium': 500,
        'large': 1000,
        'xlarge': 2000
    }

    if size not in sizes:
        raise ValueError(f"Size must be one of {list(sizes.keys())}")

    return EchoStateNetwork(
        reservoir_size=sizes[size],
        spectral_radius=spectral_radius,
        random_seed=random_seed
    )
