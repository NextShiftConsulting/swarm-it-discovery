"""
💼 LICENSED CORE LOGIC

This folder contains the "secret sauce" - RSN decomposition, certificates, quality measurement.
Customers MUST LICENSE this code from YRSN. Cannot be reimplemented.

What you CAN do:
✅ Import and use these classes (call decompose, create certificates)
✅ Pass your data to the rotor
✅ Get quality scores back (R, S, N, alpha, tau)

What you CANNOT do:
❌ Copy this implementation
❌ Rewrite the rotor yourself
❌ Modify this code without permission
❌ "Reimplement" this logic in your own system

Simple explanation:
    This is like Windows or macOS - you pay for a license to USE it.
    You can call the functions, but you can't copy the code.

Key components:
- HybridSimplexRotor: Decomposes features into R/S/N (the "brain")
- YRSNCertificate: Quality certificate with 6D metrics
- decompose(): Main function to analyze quality
- detect_collapse(): Identifies quality failure patterns

=======================================
YRSN Core - Context Quality Measurement
=======================================

QUICKSTART (copy-paste ready)
-----------------------------

Basic usage (90% of users):

    >>> from yrsn.core import decompose, detect_collapse
    >>>
    >>> # Analyze context quality
    >>> score = decompose(context_text, query=user_query)
    >>> print(f"Quality α = {score.alpha:.2f}")
    >>> print(f"Temperature τ = {score.tau:.2f}")
    >>>
    >>> # Check for collapse
    >>> if score.alpha < 0.4:
    ...     collapse = detect_collapse(score.R, score.S, score.N)
    ...     print(f"Collapse: {collapse.collapse_type}")

With domain hint (9% of users):

    >>> from yrsn.core import decompose
    >>> from yrsn.core._defaults import get_domain_preset
    >>>
    >>> preset = get_domain_preset("adversarial")  # or: realtime, industrial, symbolic, quantum
    >>> score = decompose(context, query, domain=preset.name)

Full control (1% of users):

    >>> from yrsn.core._defaults import TauMode, ActivationMode, DOMAIN_PRESETS
    >>> # See _defaults.py for all options

KEY CONCEPTS
------------
- α (alpha): Quality ratio = R/(R+S+N). Higher = better context.
- τ (tau): Temperature derived from α. Domain-specific activation.
- ω (omega): Reliability coefficient. Low = OOD, don't trust α.
- collapse: When quality degrades below thresholds.

DEFAULTS (work for most cases)
------------------------------
- ALPHA_HIGH = 0.70 (above = HIGH quality)
- ALPHA_LOW = 0.40 (below = LOW quality)
- TAU_MODE = DERIVED (quality-responsive)
- ACTIVATION = POWER (τ = 1/α²)

See yrsn.core._defaults for full list with rationale.

MODULES
-------
- decomposition/  R/S/N separation algorithms
- temperature/    Quality->Temperature mapping
- _defaults.py    All defaults with rationale (START HERE for customization)
"""

from typing import Tuple, Optional
from dataclasses import dataclass

# Production modules (measurement only)
from yrsn.core.data_wiring_validator import DataWiringValidator, validate_experiment_setup

# BACKWARD COMPATIBILITY: QualityGate moved to adapters
# Import here with deprecation warning
import warnings
try:
    from yrsn.adapters.experiment import QualityGate, QualityGateError, GateMode
    
    def _deprecated_quality_gate_import():
        warnings.warn(
            "Importing QualityGate from yrsn.core is deprecated. "
            "Use 'from yrsn.adapters.experiment import QualityGate' instead. "
            "QualityGate is CONTROL (belongs in adapters), not MEASUREMENT (core).",
            DeprecationWarning,
            stacklevel=3
        )
    
    # Wrap QualityGate to show warning on first use
    _OriginalQualityGate = QualityGate
    class QualityGate(_OriginalQualityGate):
        def __init__(self, *args, **kwargs):
            _deprecated_quality_gate_import()
            super().__init__(*args, **kwargs)
            
except ImportError:
    pass

# Import defaults (START HERE for customization)
from yrsn.core._defaults import (
    # Thresholds
    ALPHA_HIGH_THRESHOLD,
    ALPHA_LOW_THRESHOLD,
    TAU_MIN,
    TAU_MAX,
    TAU_FALLBACK,
    OMEGA_THRESHOLD,
    # Modes
    TauMode,
    # Presets
    DOMAIN_PRESETS,
    get_domain_preset,
    get_defaults_summary,
)

# Import from decomposition module
from yrsn.core.decomposition import (
    DecompositionScore,
    DecompositionMethod,
    DecomposerConfig,
    HeuristicDecomposer,
    decompose,
    compute_yrsn,
    decompose_matrix,         # v2.7+ convenience
    decompose_embedding,      # v2.7+ convenience
    clear_projection_cache,   # v2.7+ cache management
    # Reliability-adjusted quality (Claim 2)
    compute_alpha_omega,
    compute_quality_from_score,
)

# Alias for compatibility
YRSNScore = DecompositionScore

# Import from collapse detection
from yrsn.core.decomposition.collapse import (
    CollapseType,
    Severity,
    CollapseSignature,
    CollapseAnalysis,
    CollapseDetector,
    detect_collapse as _detect_collapse,
    get_collapse_summary,
    detect_collapse_phase_aware,
)

# Import from Robust PCA
from yrsn.core.decomposition.pca import (
    RPCAMethod,
    RPCAResult,
    RobustPCA,
    robust_pca,
    decompose_to_yrsn,
)

# Import from temperature module
from yrsn.core.temperature import (
    ActivationMode,
    QualityPhase,
    TemperatureParams,
    map_quality_to_temperature,
    get_quality_phase,
    get_phase_characteristics,
    compute_y_score,
    compute_risk_score,
    softmax_with_temperature,
    # Temperature from α_ω (Claim 2/4)
    compute_tau_from_alpha_omega,
    compute_tau,
    TAU_CRITICAL_1,
    TAU_CRITICAL_2,
    ALPHA_HIGH_THRESHOLD,
    ALPHA_LOW_THRESHOLD,
    quality_to_temperature,
    tau_from_alpha,
)

# Import from domain module
from yrsn.core.domain import (
    CollapseAxis,
    HarmLevel,
    ActivationMode,
    SafetyEnvelope,
    ObservabilityLimits,
    TransitionProfile,
    Domain,
    RealTimePhysicalDomain,
    SlowPhysicalDomain,
    AdversarialDomain,
    SymbolicDomain,
    QuantumDomain,
    get_domain,
    list_domains,
)

# Import from signal validator (Signal Specification v2.0)
from yrsn.core.signal_validator import (
    ValidationResult,
    SignalValidator,
    validate_rsn,
    validate_output,
    pytest_signal_validator,
)

# Import from certificate (6D Quality Certificate)
from yrsn.core.certificate import (
    YRSNCertificate,
    OracleValidation,
    YRSNCertificateBatch,
    create_certificate_from_batch,
)

# Import from signal spec (Signal Specification v2.0 Implementation)
from yrsn.core.signal_spec import (
    # Version
    SPEC_VERSION,
    # Request
    YRSNRequest,
    YRSNScope,
    YRSNInput,
    YRSNOptions,
    ScopeLevel,
    InputKind,
    create_request,
    # Response
    YRSNResponse,
    Status,
    Provenance,
    ExampleSignals,
    Decomposition,
    Quality,
    Temperature,
    Prediction,
    Learning,
    Memory,
    LayerWeights,
    Uncertainty,
    Calibration,
    AggregateSignals,
    TrainingSignals,
    Phase,
    CalibrationState,
    create_response,
    # Computation
    compute_signal,
    # Serialization
    request_to_dict,
    response_to_dict,
    dict_to_request,
    # Adapters
    from_signal_log,
    from_prediction_result,
    to_signal_log_dict,
)


# =============================================================================
# Legacy compatibility wrapper
# =============================================================================


@dataclass
class CollapseResult:
    """
    Result of collapse detection (legacy wrapper).

    For full functionality, use CollapseAnalysis from decomposition.collapse.
    For recommendations, use yrsn.policy.interpret_collapse().
    """

    collapse_type: CollapseType
    severity: Severity
    confidence: float
    # Note: recommendation removed per first principles (policy != measurement)


def compute_quality(r: float, s: float, n: float, omega: float = 1.0) -> float:
    """
    Compute reliability-adjusted quality α_ω.

    Wrapper for compute_alpha_omega() from yrsn.core.decomposition.

    Patent Reference: Claim 2 - "Reliability-Adjusted Quality"

    Formula:
        α = R / (R + S + N)
        α_ω = ω × α + (1 - ω) × prior

    Args:
        r: Relevant signal (R)
        s: Superfluous signal (S)
        n: Noise (N)
        omega: Reliability coefficient (1.0 = in-distribution)

    Returns:
        Reliability-adjusted quality α_ω

    See Also:
        yrsn.core.decomposition.compute_alpha_omega: Canonical implementation
    """
    return compute_alpha_omega(r, s, n, omega)


def compute_temperature(alpha: float, omega: float = 1.0) -> float:
    """
    Compute temperature τ from quality and reliability.

    Wrapper for compute_tau() from yrsn.core.temperature.

    Patent Reference: Claim 2/4 - "Temperature Derivation"

    Formula:
        α_ω = ω × α + (1 - ω) × prior
        τ = 1 / α_ω

    This is MEASUREMENT math, not policy:
    - The α_ω <= 0 check gates validity, not actions
    - Returns inf when quality is undefined

    Args:
        alpha: Raw quality ratio (R/(R+S+N))
        omega: Reliability coefficient (1.0 = in-distribution)

    Returns:
        Temperature τ

    See Also:
        yrsn.core.temperature.compute_tau: Canonical implementation
        yrsn.core.temperature.compute_tau_from_alpha_omega: From pre-computed α_ω
    """
    return compute_tau(alpha, omega)


def detect_collapse(r: float, s: float, n: float) -> CollapseResult:
    """
    Detect quality collapse patterns.

    For full functionality, use detect_collapse from yrsn.core.decomposition.collapse.
    For recommendations/remedies, use yrsn.policy.interpret_collapse().

    Args:
        r: Relevant signal
        s: Superfluous signal
        n: Noise

    Returns:
        CollapseResult with type, severity, confidence
    """
    analysis = _detect_collapse(r, s, n)

    return CollapseResult(
        collapse_type=analysis.collapse_type,
        severity=analysis.severity,
        confidence=analysis.confidence,
    )


def quality_gate(alpha: float, threshold: float = 0.5) -> bool:
    """
    DEPRECATED: Use yrsn.adapters.experiment.QualityGate instead.
    
    Gate by quality threshold.
    
    ⚠️  This function is DEPRECATED and will be removed in a future version.
    ⚠️  Use yrsn.adapters.experiment.QualityGate for gating logic.
    
    WHY DEPRECATED:
    --------------
    Gating (returning True/False to control flow) is CONTROL, not MEASUREMENT.
    Per hexagonal architecture, control belongs in adapters.
    
    MIGRATION:
    ---------
    OLD: if quality_gate(alpha, 0.5): ...
    NEW: from yrsn.adapters.experiment import QualityGate
         gate = QualityGate(mode='simple')
         if gate.check(alpha, 0.5).passed: ...

    Args:
        alpha: Quality ratio
        threshold: Minimum quality

    Returns:
        True if quality >= threshold
    """
    import warnings
    warnings.warn(
        "quality_gate() is deprecated. "
        "Use yrsn.adapters.experiment.QualityGate instead. "
        "Per hexagonal architecture, gating (control) belongs in adapters, not core. "
        "See: docs/HEX_ARCHITECTURE_DEEP_AUDIT.md",
        DeprecationWarning,
        stacklevel=2
    )
    return alpha >= threshold


class YRSN:
    """
    Unified YRSN analysis object.

    Simple API for Y=R+S+N decomposition.

    Example:
        y = YRSN("Your content", query="optional query")
        print(y.R, y.S, y.N)
        print(y.alpha, y.omega, y.tau)
    """

    def __init__(
        self,
        content: str,
        query: str = "",
        omega: float = 1.0,
        backend: str = "heuristic",
    ):
        """
        Analyze content.

        Args:
            content: Text content to analyze
            query: Optional query for relevance
            omega: Reliability (1 = in-distribution)
            backend: Decomposition backend
        """
        self.content = content
        self.query = query
        self._omega = omega
        self.backend = backend

        # Compute decomposition using new module
        self._score = decompose(content, query, method=backend)
        self._r = self._score.relevant
        self._s = self._score.superfluous
        self._n = self._score.noise

    @property
    def R(self) -> float:
        """Relevant signal."""
        return self._r

    @property
    def S(self) -> float:
        """Superfluous signal."""
        return self._s

    @property
    def N(self) -> float:
        """Noise."""
        return self._n

    @property
    def alpha(self) -> float:
        """Quality ratio alpha = R/(R+S+N)."""
        return compute_quality(self._r, self._s, self._n, self._omega)

    @property
    def omega(self) -> float:
        """Reliability omega (1 = in-distribution)."""
        return self._omega

    @property
    def tau(self) -> float:
        """Temperature tau = 1/alpha_omega."""
        return compute_temperature(self.alpha, self._omega)

    @property
    def quality(self) -> float:
        """Alias for alpha."""
        return self.alpha

    @property
    def y_score(self) -> float:
        """Y-score: R + 0.5*S."""
        return self._score.y_score

    @property
    def risk_score(self) -> float:
        """Risk score: S + 1.5*N."""
        return self._score.risk_score

    def gate(self, threshold: float = 0.5) -> bool:
        """Check if quality >= threshold."""
        return quality_gate(self.alpha, threshold)

    def detect_collapse(self) -> CollapseResult:
        """Detect collapse pattern."""
        return detect_collapse(self._r, self._s, self._n)

    def get_phase(self) -> QualityPhase:
        """Get quality phase (HIGH, MEDIUM, LOW)."""
        return get_quality_phase(self.alpha)


# =============================================================================
# Routing (from yrsn-tools)
# =============================================================================

from enum import Enum


class ModelTier(Enum):
    """Model tiers for routing."""
    FAST = "fast"
    BALANCED = "balanced"
    QUALITY = "quality"


@dataclass
class RoutingDecision:
    """Result of route_request."""
    tier: ModelTier
    temperature: float
    reasoning: dict


def select_model_tier(quality: float) -> ModelTier:
    """Select model tier based on quality."""
    if quality >= 0.7:
        return ModelTier.FAST
    elif quality >= 0.4:
        return ModelTier.BALANCED
    else:
        return ModelTier.QUALITY


def route_request(
    query: str,
    context: str,
    available_models: Optional[list] = None,
) -> RoutingDecision:
    """
    DEPRECATED: Use yrsn.adapters.routing instead.
    
    Route request to appropriate model tier based on context quality.
    
    ⚠️  This function is DEPRECATED and will be removed in a future version.
    ⚠️  Use yrsn.adapters.routing for routing logic.
    
    WHY DEPRECATED:
    --------------
    Routing (deciding which model to use) is CONTROL, not MEASUREMENT.
    Per hexagonal architecture, control belongs in adapters.
    
    Core should emit: {'quality': 0.7, 'recommended_tier': 'SMALL'}
    Adapter decides: "Route to SMALL model"
    
    MIGRATION:
    ---------
    OLD: decision = route_request(query, context)
    NEW: from yrsn.adapters.routing import ModelRouter
         signal = assess_quality(context, query)
         router = ModelRouter()
         decision = router.route(signal)

    Note: This returns MEASUREMENT (tier, temperature) not POLICY.
    Model selection from available_models is the caller's responsibility.
    """
    import warnings
    warnings.warn(
        "route_request() is deprecated. "
        "Use yrsn.adapters.routing instead. "
        "Per hexagonal architecture, routing (control) belongs in adapters, not core. "
        "See: docs/HEX_ARCHITECTURE_DEEP_AUDIT.md",
        DeprecationWarning,
        stacklevel=2
    )
    # Compute quality using decomposition
    score = decompose(context, query=query)
    quality = score.alpha

    tier = select_model_tier(quality)
    temperature = map_quality_to_temperature(quality, mode="power")

    # Filter available models by tier if provided, otherwise return tier only
    # Note: No hardcoded model names - that's policy, not measurement
    tier_models = []
    if available_models:
        # Caller provides their own model list - we just filter by tier
        tier_models = available_models

    return RoutingDecision(
        tier=tier,
        temperature=temperature,
        reasoning={
            "quality": quality,
            "available_models": tier_models,
        }
    )


__all__ = [
    # ==========================================================================
    # Decomposition
    # ==========================================================================
    "DecompositionScore",
    "YRSNScore",  # Alias for DecompositionScore
    "DecompositionMethod",
    "DecomposerConfig",
    "HeuristicDecomposer",
    "decompose",
    "compute_yrsn",
    "decompose_matrix",         # v2.7+ convenience
    "decompose_embedding",      # v2.7+ convenience
    "clear_projection_cache",   # v2.7+ cache management
    # Reliability-adjusted quality (Claim 2)
    "compute_alpha_omega",
    "compute_quality_from_score",
    # ==========================================================================
    # Collapse Detection
    # ==========================================================================
    "CollapseType",
    "Severity",
    "CollapseSignature",
    "CollapseAnalysis",
    "CollapseDetector",
    "CollapseResult",  # Legacy wrapper
    "detect_collapse",
    "get_collapse_summary",
    "detect_collapse_phase_aware",
    # ==========================================================================
    # Robust PCA
    # ==========================================================================
    "RPCAMethod",
    "RPCAResult",
    "RobustPCA",
    "robust_pca",
    "decompose_to_yrsn",
    # ==========================================================================
    # Temperature
    # ==========================================================================
    "ActivationMode",
    "QualityPhase",
    "TemperatureParams",
    "map_quality_to_temperature",
    "get_quality_phase",
    "get_phase_characteristics",
    "compute_y_score",
    "compute_risk_score",
    "softmax_with_temperature",
    # Temperature from α_ω (Claim 2/4)
    "compute_tau_from_alpha_omega",
    "compute_tau",
    "TAU_CRITICAL_1",
    "TAU_CRITICAL_2",
    "ALPHA_HIGH_THRESHOLD",
    "ALPHA_LOW_THRESHOLD",
    "quality_to_temperature",
    "tau_from_alpha",
    # ==========================================================================
    # Domain (First-Class Concept)
    # ==========================================================================
    "CollapseAxis",
    "HarmLevel",
    "ActivationMode",
    "SafetyEnvelope",
    "ObservabilityLimits",
    "TransitionProfile",
    "Domain",
    "RealTimePhysicalDomain",
    "SlowPhysicalDomain",
    "AdversarialDomain",
    "SymbolicDomain",
    "QuantumDomain",
    "get_domain",
    "list_domains",
    # ==========================================================================
    # Core Functions
    # ==========================================================================
    "compute_quality",
    "compute_temperature",
    "quality_gate",
    # ==========================================================================
    # Production Modules (Measurement Only)
    # ==========================================================================
    "DataWiringValidator",  # Validate data flow between modules
    "validate_experiment_setup",  # Convenience validator function
    # Note: QualityGate moved to yrsn.adapters.experiment (it's control, not measurement)
    # Kept here for backward compatibility with deprecation warning
    # ==========================================================================
    # Main Class
    # ==========================================================================
    "YRSN",
    # ==========================================================================
    # Routing
    # ==========================================================================
    "ModelTier",
    "RoutingDecision",
    "select_model_tier",
    "route_request",
    # ==========================================================================
    # Signal Validation (Spec v2.0)
    # ==========================================================================
    "ValidationResult",
    "SignalValidator",
    "validate_rsn",
    "validate_output",
    "pytest_signal_validator",
    # ==========================================================================
    # Signal Specification v2.0 Implementation
    # ==========================================================================
    "SPEC_VERSION",
    # Request
    "YRSNRequest",
    "YRSNScope",
    "YRSNInput",
    "YRSNOptions",
    "ScopeLevel",
    "InputKind",
    "create_request",
    # Response
    "YRSNResponse",
    "Status",
    "Provenance",
    "ExampleSignals",
    "Decomposition",
    "Quality",
    "Temperature",
    "Prediction",
    "Learning",
    "Memory",
    "LayerWeights",
    "Uncertainty",
    "Calibration",
    "AggregateSignals",
    "TrainingSignals",
    "Phase",
    "CalibrationState",
    "create_response",
    # Computation
    "compute_signal",
    # Serialization
    "request_to_dict",
    "response_to_dict",
    "dict_to_request",
    # Adapters
    "from_signal_log",
    "from_prediction_result",
    "to_signal_log_dict",
    # ==========================================================================
    # Certificate (6D Quality Certificate + Oracle-Free Helpers)
    # ==========================================================================
    "YRSNCertificate",
    "OracleValidation",
    "YRSNCertificateBatch",
    "create_certificate_from_batch",
]
