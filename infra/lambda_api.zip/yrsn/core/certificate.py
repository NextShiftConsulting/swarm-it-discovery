"""
YRSN Quality Certificate - The 6D Signal with Oracle-Free Helpers + Lyapunov Stability

The certificate is the core YRSN output that enables hardware health monitoring,
quality gating, adaptive control, and FORMAL STABILITY GUARANTEES without
requiring ground truth labels.

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.11: Structured Context Integrity Certificate
  - §7.11.2: Functional Requirements (completeness, self-description, verifiability)
  - §7.11.3: Certificate Components (degradation type, severity, provenance, context)
- §7.9: Degradation Classification (degradation type integration)
- §7.10: Fragility State Assignment (stability characterization)
- §7.5: Metric Computation (6D signal: R, S, N, alpha, omega, tau)

Relevant patent files:
- docs/specs/patent_spec_section_7_11_certificate_structure.md
- docs/specs/patent_spec_section_7_9_degradation_classification.md
- docs/specs/patent_spec_section_7_10_fragility_states.md

EXTENDED FEATURES (beyond patent spec):
- Lyapunov stability verification (V, V̇, stability margin)
- Formal stability guarantees under gearbox control
- Gearbox control action recommendations

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                     YRSNCertificate                             │
    │  ┌──────────────────────────────────────────────────────────┐  │
    │  │              CORE 6D (Always Present)                     │  │
    │  │  R, S, N, alpha, omega, tau                              │  │
    │  └──────────────────────────────────────────────────────────┘  │
    │  ┌──────────────────────────────────────────────────────────┐  │
    │  │           DERIVED HELPERS (Oracle-Free)                   │  │
    │  │  alpha_omega, quality_score, uncertainty, health_score   │  │
    │  │  degradation_type, severity_value, fragility_state       │  │
    │  │  (§7.9/§7.10/§7.11 - computed from 6D, no labels)        │  │
    │  └──────────────────────────────────────────────────────────┘  │
    │  ┌──────────────────────────────────────────────────────────┐  │
    │  │          TEMPORAL HELPERS (Require Baseline)              │  │
    │  │  n_delta, n_trend, drift_detected                        │  │
    │  └──────────────────────────────────────────────────────────┘  │
    │  ┌──────────────────────────────────────────────────────────┐  │
    │  │          LYAPUNOV HELPERS (Require T⁴ + Baseline)        │  │
    │  │  V, V_dot, is_stable, is_converging, lyapunov_margin    │  │
    │  │  recommended_gear                                        │  │
    │  └──────────────────────────────────────────────────────────┘  │
    └─────────────────────────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────────────────────────┐
    │              OracleValidation (SEPARATE - Requires Labels)      │
    │  n_error_correlation, centroid_separation, roc_auc, pr_auc     │
    └─────────────────────────────────────────────────────────────────┘

Key Principles:

    1. ORACLE-FREE: The certificate provides health signals without
       needing ground truth. Critical for Claim C2-c (oracle-free
       degradation detection).

    2. LYAPUNOV STABILITY: When T⁴ coordinates are provided, the
       certificate computes formal stability guarantees:
       - V(x) = d_T⁴(current, baseline) is the Lyapunov function
       - V̇ ≤ 0 under gearbox control proves stability
       - This differentiates YRSN from ad-hoc monitoring approaches

    OracleValidation is for research/offline validation ONLY.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple, TYPE_CHECKING
from datetime import datetime
from enum import Enum
import numpy as np

if TYPE_CHECKING:
    from yrsn.core.decomposition.collapse import CollapseConfig
    from yrsn.core.decomposition.pillar_configs import Pillar3Config
    from yrsn.core.routing.defenses import DefenseCheckResult


# =============================================================================
# FRAGILITY STATE ENUM (§7.10) - DEPRECATED
# =============================================================================
# DEPRECATION NOTE: FragilityState conflates three orthogonal concepts:
#   1. Admissibility (authorization gate - BLOCKS execution)
#   2. Quality envelope (diagnostic - informational)
#   3. Lyapunov stability (trajectory convergence - advisory)
#
# Use the three new enums below for clarity. FragilityState kept for
# backward compatibility during migration.
# =============================================================================

class FragilityState(str, Enum):
    """
    DEPRECATED: Use QualityEnvelopeState, AdmissibilityState, or LyapunovState.

    Fragility states per Patent Spec §7.10.

    Characterizes the stability, robustness, and vulnerability of the
    current context quality state. Oracle-free - computed from variance,
    coherence, and boundary proximity.

    Reference: docs/specs/patent_spec_section_7_10_fragility_states.md
    """
    STABLE = "STABLE"              # Within envelope, no warning
    INSTABILITY = "INSTABILITY"    # High variance in metrics (§7.10.3.1)
    CONFLICT = "CONFLICT"          # Low coherence, sources disagree (§7.10.3.2)
    BOUNDARY_RISK = "BOUNDARY_RISK"  # Near threshold boundaries (§7.10.3.3)
    COLLAPSE = "COLLAPSE"          # Critical failure state (§7.10.3.4)


# =============================================================================
# THREE ORTHOGONAL STABILITY CONCEPTS (Architectural Clarity)
# =============================================================================
# Reference: docs/analysis/Three_Stability_Concepts_Clarification.md
#
# FOUR-LAYER ARCHITECTURE:
#   Layer 1: RSN (R, S, N) - Content integrity decomposition
#   Layer 2: κ (kappa) - Encoding-solver compatibility ⭐ CRITICAL LAYER
#   Layer 3: Multimodal (κ_H, κ_L, κ_interface) - Hierarchical κ composition
#   Layer 4: Lyapunov (V, V̇) - Trajectory stability verification
#
# These three ORTHOGONAL stability concepts span the layers:
#
# 1. ADMISSIBILITY (E ∈ E_adm)
#    Purpose: Authorization gate - is encoding SUITABLE for execution?
#    Checks: Layer 1 (RSN: α, N) + Layer 2 (κ, σ_scalar) ⭐
#    Decision: REJECT / RE_ENCODE / ALLOW
#    Type: BLOCKING ✅ (forward-looking)
#
# 2. QUALITY ENVELOPE (§7.10)
#    Purpose: Diagnostic - WHAT is the quality state?
#    Checks: Layer 1-2 (Variance, coherence, boundary proximity)
#    Decision: Classification (informational)
#    Type: NON-BLOCKING ❌ (diagnostic)
#
# 3. LYAPUNOV STABILITY (V̇ ≤ 0)
#    Purpose: Verification - is trajectory CONVERGING over time?
#    Checks: Layer 4 (V, V̇: chordal distance, derivative)
#    Decision: Advisory
#    Type: NON-BLOCKING ❌ (backward-looking)
#
# Only ADMISSIBILITY gates execution. Quality envelope and Lyapunov inform.
# κ (Layer 2) is THE critical encoding-solver compatibility check!
# =============================================================================

class AdmissibilityState(str, Enum):
    """
    Admissibility gate - BLOCKS execution if not ADMISSIBLE.

    Determines if encoding is suitable for solver execution based on:
    - RSN quality (R, N thresholds)
    - κ compatibility (encoding-solver match)
    - σ stability (instability < critical threshold)

    This is the ONLY gate that blocks execution (REJECT/RE_ENCODE).
    Quality envelope and Lyapunov are informational only.
    """
    ADMISSIBLE = "ADMISSIBLE"          # Passes all checks - safe to execute
    INCOMPATIBLE = "INCOMPATIBLE"      # Low κ - encoding doesn't match solver
    UNSTABLE = "UNSTABLE"              # High σ - system too unstable
    UNSAFE = "UNSAFE"                  # High N or noise collapsed - dangerous


class QualityEnvelopeState(str, Enum):
    """
    Quality envelope diagnostic (§7.10) - NON-BLOCKING.

    Renamed from FragilityState for clarity. This is about quality diagnostics,
    not Lyapunov stability.

    Characterizes variance, coherence, and boundary proximity.
    Oracle-free - computed from certificate metrics.

    This does NOT gate execution - it's informational/diagnostic only.
    """
    NOMINAL = "NOMINAL"                # Within envelope, no warning (was STABLE)
    INSTABILITY = "INSTABILITY"        # High variance in metrics (§7.10.3.1)
    CONFLICT = "CONFLICT"              # Low coherence, sources disagree (§7.10.3.2)
    BOUNDARY_RISK = "BOUNDARY_RISK"    # Near threshold boundaries (§7.10.3.3)
    COLLAPSED = "COLLAPSED"            # Critical failure state (§7.10.3.4 - was COLLAPSE)


class LyapunovState(str, Enum):
    """
    Lyapunov trajectory stability (Layer 4) - ADVISORY ONLY.

    Determines if the system trajectory is converging over time.
    Based on V̇ (time derivative of chordal distance).

    This does NOT gate execution - it's advisory/verification only.
    """
    CONVERGING = "CONVERGING"          # V̇ < 0 - trajectory converging (stable)
    EQUILIBRIUM = "EQUILIBRIUM"        # V̇ ≈ 0 - at equilibrium point
    DIVERGING = "DIVERGING"            # V̇ > 0 - trajectory diverging (unstable)


class DegradationType(str, Enum):
    """
    Degradation types per Patent Spec §7.9.

    Classifies the type of context quality degradation based on observable
    signals. Oracle-free - computed from R, S, N, α, ω without labels.

    Reference: docs/specs/patent_spec_section_7_9_degradation_classification.md
    """
    HEALTHY = "HEALTHY"            # No degradation detected
    DRIFT = "DRIFT"                # Distribution shift (§7.9.4.1)
    POISONING = "POISONING"        # High noise, data contamination (§7.9.4.1)
    DISTRACTION = "DISTRACTION"    # High S, irrelevant signal dominance (§7.9.4.1)
    CONFLICT = "CONFLICT"          # Contradictory signals (§7.9.4.1)
    HALLUCINATION = "HALLUCINATION"  # High α, low ω - confident but wrong (§7.9.4.1)
    BOUNDARY = "BOUNDARY"          # Near operational envelope edges (§7.9.4.1)
    COLLAPSE = "COLLAPSE"          # No dominant signal, R≈S≈N (§7.9.4.1)
    # Defense-layer degradation types (from routing/defenses.py bridge)
    GOAL_DRIFT = "GOAL_DRIFT"      # Goal anchor integrity violation
    SYBIL_ATTACK = "SYBIL_ATTACK"  # Agent fingerprint clustering detected
    RATE_LIMITED = "RATE_LIMITED"  # Token bucket backpressure triggered


# =============================================================================
# THRESHOLD BUNDLE & CLASSIFICATION RESULT (§7.9/§7.10/§7.11)
# =============================================================================

@dataclass(frozen=True)
class CertificateThresholds:
    """
    Bundle of threshold configs for certificate classification.

    This enables threshold injection for classification methods.
    Certificate depends only on config TYPES, not on _defaults.py constants.

    Both configs live in yrsn.core.decomposition - that's the canonical path.
    """
    collapse: 'CollapseConfig'
    pillar3: 'Pillar3Config'


@dataclass(frozen=True)
class CertificateClassification:
    """
    Result of certificate classification (§7.9/§7.10/§7.11).

    Returned by YRSNCertificate.classify() - pure computation result.
    Contains enums directly; serialize to .value only at edges.

    This is the TRIPARTITE CHECK - all three fields must be present and valid:
    - degradation_type (§7.9): WHAT degraded
    - fragility_state (§7.10): HOW precarious the state is
    - severity_value (§7.11): HOW BAD the degradation is
    """
    fragility_state: FragilityState
    severity_value: float
    degradation_type: DegradationType


def assert_tripartite_classification(cls: CertificateClassification) -> None:
    """
    Assert the tripartite classification is complete and valid.

    The tripartite check ensures:
    1. All three components present (degradation_type, fragility_state, severity_value)
    2. All components well-typed (enums are enums, float is float)
    3. Severity is bounded [0, 1]

    Args:
        cls: CertificateClassification to validate

    Raises:
        AssertionError: If any component is missing, wrong type, or out of bounds

    Usage:
        cls = cert.classify(thresholds)
        assert_tripartite_classification(cls)  # Gate enforced
    """
    # Type checks (must contain all three, must be well-typed)
    assert isinstance(cls.degradation_type, DegradationType), \
        f"degradation_type must be DegradationType enum, got {type(cls.degradation_type)}"
    assert isinstance(cls.fragility_state, FragilityState), \
        f"fragility_state must be FragilityState enum, got {type(cls.fragility_state)}"
    assert isinstance(cls.severity_value, (int, float)), \
        f"severity_value must be numeric, got {type(cls.severity_value)}"

    # Value checks (must be bounded)
    assert 0.0 <= cls.severity_value <= 1.0, \
        f"severity_value must be in [0,1], got {cls.severity_value}"


# =============================================================================
# CONSTANTS
# =============================================================================

# Certificate schema version (ISA v0.2 compliance)
# Used in to_v0_2() and ISA.cert_mint() for consistent versioning
# Update this when certificate structure changes (breaking changes)
CERTIFICATE_SCHEMA_VERSION = "v2.1.0"  # v2.1: Added modality support

# Supported modalities for Universal Rotor v2
SUPPORTED_MODALITIES = ("text", "vision", "audio", "multimodal")


# =============================================================================
# FILE ORGANIZATION
# =============================================================================
#
# This file is organized into ORACLE-FREE and ORACLE-REQUIRED sections:
#
#   ORACLE-FREE (production use, no ground truth needed):
#   ├── YRSNCertificate        - The 6D certificate with helpers
#   ├── YRSNCertificateBatch   - Batch processing of certificates
#   └── create_certificate_from_batch()
#
#   ORACLE-REQUIRED (research/validation only, needs ground truth labels):
#   ├── OracleValidation       - Metrics requiring labels (MCC, AUC, etc.)
#   ├── derive_metrics_from_confusion_matrix()
#   └── validate_batch_with_oracle()
#
# The separation ensures production code never accidentally depends on
# ground truth labels, which are unavailable in deployment.
#
# =============================================================================


# =============================================================================
# CORE CERTIFICATE (Oracle-Free)
# =============================================================================

@dataclass(frozen=True)
class YRSNCertificate:
    """
    YRSN 6D Quality Certificate with Oracle-Free Helpers + Lyapunov Stability.

    The certificate provides hardware health, quality signals, and formal
    stability guarantees WITHOUT requiring ground truth labels.

    Core 6D Components:
        R: Relevant signal strength [0,1]
        S: Superfluous signal strength [0,1]
        N: Noise signal strength [0,1] - KEY DEGRADATION INDICATOR
        alpha: Quality/reliability metric [0,1]
        omega: In-distribution confidence [0,1]
        tau: Plasticity modulator [1, inf]

    Derived Helpers (computed from 6D, oracle-free):
        alpha_omega: Blended quality score
        quality_score: Normalized quality [0,1]
        uncertainty: Inverse of quality [0,1]
        health_score: Hardware health from N [0,1]

    Temporal Helpers (require baseline, but NOT ground truth):
        n_delta: Deviation from N baseline
        n_trend: Direction of N change
        drift_detected: Boolean flag

    Lyapunov Helpers (require T⁴ coordinates + baseline):
        V: Lyapunov function value (T⁴ distance from baseline)
        V_dot: Time derivative estimate (stability indicator)
        is_lyapunov_stable: True if V̇ ≤ 0 (Lyapunov stable - trajectory converging)
        is_converging: True if V̇ < -ε (system is converging)
        lyapunov_margin: Distance from instability (1.5 - V)
        recommended_gear: Control action that maintains V̇ ≤ 0

    The Lyapunov helpers provide formal stability guarantees:
        - V(x) = d_T⁴(current, baseline) is the Lyapunov function
        - Under gearbox control, V̇ ≤ 0 is guaranteed
        - This proves bounded drift and convergence to stable region

    Usage:
        # Basic certificate (oracle-free health/quality)
        cert = YRSNCertificate(R=0.6, S=0.25, N=0.15, alpha=0.6, omega=0.9, tau=1.8)

        if cert.health_score < 0.5:
            trigger_maintenance()

        # With Lyapunov stability (requires T⁴ coordinates)
        cert = cert.with_t4(current_t4, baseline_t4, prev_V)

        if cert.is_stable:
            print(f"System stable, V={cert.V:.4f}, margin={cert.lyapunov_margin:.4f}")
        else:
            print(f"Instability: V̇={cert.V_dot:.4f}, shift to {cert.recommended_gear}")

        # Full verification report
        report = cert.verify_lyapunov()
        if report['satisfied']:
            print("All Lyapunov conditions hold")
    """

    # =========================================================================
    # CORE 6D (Always Required) - YRSN BLOCK
    # "What's IN z?" - Content quality from decomposition
    # =========================================================================
    R: float  # Relevant component [0,1]
    S: float  # Superfluous component [0,1]
    N: float  # Noise component [0,1] - rises with degradation
    alpha: float  # Quality metric = R/(R+S+N) [0,1]
    omega: float  # In-distribution confidence [0,1] (original YRSN field)
    tau: float  # Plasticity modulator = 1/α_ω [1, inf]

    # =========================================================================
    # P14 BLOCK (Collapse Prevention Prior)
    # "How do we prevent collapse when ω → 0?"
    # Reference: docs/primary/FORMULA_REFERENCE.md P14
    # =========================================================================
    prior: float = 0.5  # Quality prior for α_ω collapse prevention [0,1]

    # =========================================================================
    # RSCT BLOCK (Geometric Compatibility) - NEW
    # "Can solver S USE representation z?" - Interface quality
    # Reference: docs/papers/gap_analysis/RSCT_YRSN_IMPLEMENTATION_APPENDIX.md
    # =========================================================================
    # κ(E,S) = D*/D where:
    #   D* = reference difficulty (optimal expert steps)
    #   D = actual steps with encoding E and solver S
    # Note: κ is separate from ω. Use alpha_kappa property when you want
    # to blend α with κ instead of ω: α_κ = α×κ + prior×(1-κ)

    # Scalar representations (for Oobleck thresholds)
    kappa: Optional[float] = None  # κ-Scalar: magnitude for Step 7.5 [0,1]
    sigma: Optional[float] = None  # σ-Scalar: magnitude for Oobleck [0,1]

    # Simplex representations (for composition analysis)
    kappa_vector: Optional[Tuple[float, float, float]] = None  # κ-Simplex: (κ_A, κ_E, κ_T) sum=1
    sigma_vector: Optional[Tuple[float, float, float]] = None  # σ-Simplex: (σ_var, σ_growth, σ_entropy) sum=1

    # Individual κ-Simplex components (for diagnostics)
    kappa_A: Optional[float] = None  # Algorithmic alignment (normalized)
    kappa_E: Optional[float] = None  # Information efficiency (normalized)
    kappa_T: Optional[float] = None  # Search tractability (normalized)

    # Individual σ-Simplex components (for diagnostics)
    sigma_var: Optional[float] = None  # Activation variance (normalized)
    sigma_growth: Optional[float] = None  # Trajectory divergence (normalized)
    sigma_entropy: Optional[float] = None  # Distributional uncertainty (normalized)

    # Provenance fields
    d_star: Optional[float] = None  # Reference difficulty D*
    d_actual: Optional[float] = None  # Actual difficulty D
    encoding_type: Optional[str] = None  # E1/E2/E3/E4/E5 (provenance)
    solver_type: Optional[str] = None  # HRMV/TRM/LLM/Quantum (provenance)

    # =========================================================================
    # P16 BLOCK (Hash Integrity)
    # "How do we prevent tampering with invariant specifications?"
    # Reference: docs/primary/FORMULA_REFERENCE.md P16
    # =========================================================================
    inv_spec_blob: Optional[str] = None  # Serialized invariant spec (JSON)
    inv_spec_hash: Optional[str] = None  # SHA-256 hash of blob
    hash_valid: Optional[bool] = None  # Computed in __post_init__

    # =========================================================================
    # HIERARCHY BLOCK (Optional - for HRM/TRM architectures)
    # "Where is the bottleneck?" - Level-wise compatibility
    # =========================================================================
    kappa_H: Optional[float] = None  # H-level (high) compatibility
    kappa_L: Optional[float] = None  # L-level (low) compatibility
    kappa_interface: Optional[float] = None  # H→L stitching quality
    sigma_H: Optional[float] = None  # H-level stability
    sigma_L: Optional[float] = None  # L-level stability

    # =========================================================================
    # DERIVED HELPERS (Oracle-Free, computed from 6D + RSCT)
    # =========================================================================
    # Basic quality helpers
    alpha_omega: Optional[float] = None  # omega * alpha + (1-omega) * prior
    quality_score: Optional[float] = None  # Normalized quality [0,1]
    uncertainty: Optional[float] = None  # 1 - quality_score [0,1]
    health_score: Optional[float] = None  # 1 - N (higher = healthier)

    # §7.9/§7.10/§7.11 Classification helpers (Oracle-Free)
    # These fulfill the patent spec requirements while remaining oracle-free.
    # Computed from θ angle, N, variance, coherence - no ground truth labels needed.
    degradation_type: Optional[str] = None  # §7.9: DegradationType value (e.g., "DRIFT", "HALLUCINATION")
    severity_value: Optional[float] = None  # §7.11.3.2: Degradation intensity [0.0, 1.0]
    fragility_state: Optional[str] = None  # §7.10: FragilityState value (e.g., "STABLE", "COLLAPSE")

    # §7.11.4.2 Coherence (from phasor summation, §7.7.4)
    # Used for CONFLICT detection per §7.10.4.4
    # CONFLICTED = coherence < 0.4, MODERATE = 0.4-0.7, COHERENT = >= 0.7
    coherence: Optional[float] = None  # Phasor coherence [0,1]

    # =========================================================================
    # TEMPORAL HELPERS (Require baseline, NOT ground truth)
    # =========================================================================
    n_baseline: Optional[float] = None  # Expected N for healthy hardware
    n_delta: Optional[float] = None  # N - n_baseline
    n_trend: Optional[str] = None  # "rising", "stable", "falling"
    drift_detected: Optional[bool] = None  # N significantly above baseline

    # =========================================================================
    # LYAPUNOV HELPERS (Require T⁴ coordinates + baseline)
    # =========================================================================
    # These fields provide formal stability guarantees when T⁴ data is available.
    # V(x) = d_T⁴(current, baseline) is the Lyapunov function.
    # Under gearbox control, we prove V̇ ≤ 0 (stability).
    #
    # Reference: Lyapunov stability theory for adaptive control systems.
    # =========================================================================
    t4_coords: Optional[np.ndarray] = None  # Current T⁴ coordinates [θ, φ, α_t4, ω_t4]
    t4_baseline: Optional[np.ndarray] = None  # Baseline T⁴ coordinates
    V: Optional[float] = None  # Lyapunov function value: d_T⁴(current, baseline)
    V_dot: Optional[float] = None  # Time derivative estimate (from history)
    V_prev: Optional[float] = None  # Previous V value (for V_dot estimation)
    is_lyapunov_stable: Optional[bool] = None  # True if V̇ ≤ 0 (Lyapunov stability)
    is_stable: Optional[bool] = None  # DEPRECATED: Use is_lyapunov_stable (backward compat)
    is_converging: Optional[bool] = None  # True if V̇ < -ε (strict decrease)
    lyapunov_margin: Optional[float] = None  # Distance from instability (1.5 - V)
    recommended_gear: Optional[str] = None  # Gear that maintains V̇ ≤ 0

    # =========================================================================
    # MODALITY SUPPORT (Universal Rotor v2)
    # =========================================================================
    # These fields enable multi-modal deployment modes per:
    # docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md
    modality: Optional[str] = None  # 'text', 'vision', 'audio', 'multimodal'
    feature_extractor_version: Optional[str] = None  # e.g., 'text_projection_v2.pt'
    rotor_version: Optional[str] = None  # e.g., 'universal_rotor_v2.pt'

    # =========================================================================
    # PKI-STYLE GOVERNANCE (Standard Certificate Properties)
    # =========================================================================
    policy_id: Optional[str] = None  # Which rulebook/threshold set defined this classification
    expires_at: Optional[datetime] = None  # Validity window end (None = never expires)

    # =========================================================================
    # DEFENSE BLOCK (From routing/defenses.py - Bidirectional Bridge)
    # Stamps defense layer signals onto certificate for audit trail
    # Reference: docs/primary/FORMULA_REFERENCE.md §5 Defense Stack
    # =========================================================================
    defense_goal_valid: Optional[bool] = None      # Goal anchor check passed
    defense_is_sybil: Optional[bool] = None        # Sybil attack detected
    defense_rate_limited: Optional[bool] = None    # Rate limit triggered
    defense_pressure: Optional[float] = None       # Aggregate defense pressure [0,1]
    defense_manager_healthy: Optional[bool] = None # Manager redundancy healthy
    defense_check_timestamp: Optional[str] = None  # When defense was checked (ISO format)

    # =========================================================================
    # METADATA
    # =========================================================================
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    backend: str = "unknown"

    # =========================================================================
    # EXTRAS (Extensible kwargs for derived values)
    # =========================================================================
    # Any oracle-free derived value can be stored here without modifying
    # the class definition. Useful for multimodal diagnostics, experimental
    # metrics, and domain-specific extensions.
    #
    # Common extras:
    #   - entropy: RSN distribution entropy -Σp·log(p)
    #   - hierarchy_gap: |κ_H - κ_L| modality disagreement
    #   - contrarian: 1 - κ (trust-the-skeptic signal)
    #   - dominant_modality: 'text' or 'vision'
    #   - text_rsn: (R, S, N) from text modality
    #   - vision_rsn: (R, S, N) from vision modality
    # =========================================================================
    extras: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Compute derived helpers from core 6D + RSCT + P14/P16."""
        # RSCT Integration: Compute kappa from D*/D if provided
        if self.kappa is None and self.d_star is not None and self.d_actual is not None and self.d_actual > 0:
            object.__setattr__(self, 'kappa', min(1.0, self.d_star / self.d_actual))

        # P14: Alpha-omega blend with configurable prior
        # α_ω = α×ω + prior×(1-ω)
        # The prior prevents collapse when ω → 0
        if self.alpha_omega is None or self.alpha_omega == 0.0:
            a_w = self.omega * self.alpha + (1.0 - self.omega) * self.prior
            object.__setattr__(self, 'alpha_omega', a_w)

        # P16: Hash integrity verification
        if self.inv_spec_blob is not None and self.inv_spec_hash is not None:
            import hashlib
            computed = hashlib.sha256(self.inv_spec_blob.encode('utf-8')).hexdigest()
            hv = (computed == self.inv_spec_hash)
            object.__setattr__(self, 'hash_valid', hv)

        # Quality score (normalized alpha_omega)
        if self.quality_score is None:
            object.__setattr__(self, 'quality_score', float(np.clip(self.alpha_omega, 0, 1)))

        # Uncertainty (inverse of quality)
        if self.uncertainty is None:
            object.__setattr__(self, 'uncertainty', 1.0 - self.quality_score)

        # Health score (inverse of N - lower N = healthier)
        if self.health_score is None:
            object.__setattr__(self, 'health_score', 1.0 - float(np.clip(self.N, 0, 1)))

        # §7.9/§7.10/§7.11 Classification helpers (Oracle-Free)
        # NOTE: Classification is now computed ON-DEMAND via classify() method.
        # Legacy auto-fill is DISABLED. Callers should use:
        #   cls = cert.classify(thresholds)  # or cert.classify_default()
        #   cert.apply_classification(cls)   # if mutation needed
        # This ensures thresholds are explicitly provided and testable.

        # Temporal helpers (if baseline provided)
        if self.n_baseline is not None:
            if self.n_delta is None:
                object.__setattr__(self, 'n_delta', self.N - self.n_baseline)

            if self.n_trend is None:
                if self.n_delta > 0.02:
                    object.__setattr__(self, 'n_trend', "rising")
                elif self.n_delta < -0.02:
                    object.__setattr__(self, 'n_trend', "falling")
                else:
                    object.__setattr__(self, 'n_trend', "stable")

            if self.drift_detected is None:
                object.__setattr__(self, 'drift_detected', self.n_delta > 0.05)  # 5% threshold

        # Lyapunov helpers (if T⁴ coordinates provided)
        if self.t4_coords is not None and self.t4_baseline is not None:
            self._compute_lyapunov_helpers()

        # Lyapunov stability classification (Layer 4) - runs even without t4_coords
        # if V_dot is provided directly
        if self.V_dot is not None:
            lyapunov_stable = self.V_dot <= 0.0

            # Set is_lyapunov_stable (new field)
            if self.is_lyapunov_stable is None:
                object.__setattr__(self, 'is_lyapunov_stable', lyapunov_stable)

            # Backward compatibility: keep is_stable synced with is_lyapunov_stable
            if self.is_stable is None:
                object.__setattr__(self, 'is_stable', lyapunov_stable)

        # Backward compatibility fallback: if is_stable was set but is_lyapunov_stable wasn't,
        # sync them (for old code that sets is_stable explicitly)
        if self.is_stable is not None and self.is_lyapunov_stable is None:
            object.__setattr__(self, 'is_lyapunov_stable', self.is_stable)

    # =========================================================================
    # RSCT HELPERS (κ-based quality metrics)
    # Reference: docs/papers/gap_analysis/RSCT_YRSN_IMPLEMENTATION_APPENDIX.md
    # =========================================================================

    @property
    def alpha_kappa(self) -> Optional[float]:
        """
        Compute α_κ using kappa instead of omega.

        α_κ = α×κ + prior×(1-κ)

        Use this when you want RSCT geometric compatibility (κ)
        to weight the content quality (α) instead of omega.

        Returns None if kappa not set.
        """
        if self.kappa is None:
            return None
        quality_prior = 0.5
        return self.kappa * self.alpha + (1 - self.kappa) * quality_prior

    @property
    def tau_kappa(self) -> Optional[float]:
        """
        Compute τ_κ = 1/α_κ (temperature using kappa).

        Use this for gearbox control when you want κ-based
        temperature instead of ω-based.

        Returns None if kappa not set.
        """
        ak = self.alpha_kappa
        if ak is None:
            return None
        return 1.0 / max(ak, 0.01)

    # =========================================================================
    # MULTIMODAL HELPERS (Derived from hierarchy fields or extras)
    # =========================================================================

    @property
    def entropy(self) -> float:
        """
        RSN distribution entropy: -Σp·log(p)

        Higher entropy = more uncertain/spread distribution.
        Max entropy (uniform) ≈ 1.099, Min (pure R) = 0.
        """
        if 'entropy' in self.extras:
            return self.extras['entropy']
        probs = np.array([self.R, self.S, self.N])
        probs = np.clip(probs, 1e-10, 1.0)
        return float(-np.sum(probs * np.log(probs)))

    @property
    def hierarchy_gap(self) -> Optional[float]:
        """
        |κ_H - κ_L| - Disagreement between high-level and low-level quality.

        High gap = modalities disagree = trust domain expert.
        Returns None if hierarchy fields not set.
        """
        if 'hierarchy_gap' in self.extras:
            return self.extras['hierarchy_gap']
        if self.kappa_H is not None and self.kappa_L is not None:
            return abs(self.kappa_H - self.kappa_L)
        return None

    @property
    def contrarian(self) -> Optional[float]:
        """
        1 - κ (agreement) = contrarian signal.

        High contrarian = modalities disagree = one likely right.
        Use this to trust the skeptical modality.
        """
        if 'contrarian' in self.extras:
            return self.extras['contrarian']
        if self.kappa is not None:
            return 1.0 - self.kappa
        return None

    @property
    def dominant_modality(self) -> Optional[str]:
        """
        Which modality has higher R (quality signal).

        Returns 'text', 'vision', 'tie', or None if not multimodal.
        """
        if 'dominant_modality' in self.extras:
            return self.extras['dominant_modality']
        if self.kappa_H is not None and self.kappa_L is not None:
            if self.kappa_H > self.kappa_L:
                return 'text'
            elif self.kappa_L > self.kappa_H:
                return 'vision'
            return 'tie'
        return None

    @property
    def is_multimodal(self) -> bool:
        """
        True if this certificate has multimodal hierarchy data.

        Multimodal certificates have at least two of:
        - kappa_H (text/high-level compatibility)
        - kappa_L (vision/low-level compatibility)
        - kappa_interface (cross-modal fusion)

        Reference: SDK weak_modality diagnostic requires this check.
        """
        count = sum(1 for k in [self.kappa_H, self.kappa_L, self.kappa_interface] if k is not None)
        return count >= 2

    @property
    def weak_modality(self) -> Optional[str]:
        """
        Identify which modality is causing kappa_gate to be low.

        Returns:
            'text' if kappa_H is weakest (dragging gate down)
            'vision' if kappa_L is weakest
            'interface' if kappa_interface is weakest
            None if single-modal or all equal

        This is the diagnostic inverse of dominant_modality:
        - dominant_modality = highest κ (strongest source)
        - weak_modality = lowest κ (bottleneck causing gate rejection)

        Use Case: When kappa_gate < threshold, this tells you WHERE to focus
        remediation efforts (re-encode text, improve vision signal, or fix
        cross-modal alignment).

        Reference: SDK diagnose_multimodal() pattern
        """
        if not self.is_multimodal:
            return None

        kappas = {
            'text': self.kappa_H,
            'vision': self.kappa_L,
            'interface': self.kappa_interface,
        }
        valid = {k: v for k, v in kappas.items() if v is not None}
        if not valid:
            return None

        # Find the minimum (weakest link)
        weakest = min(valid, key=valid.get)

        # Check if all are equal (no single weak link)
        values = list(valid.values())
        if len(set(values)) == 1:
            return None

        return weakest

    def diagnose(self) -> Dict[str, Any]:
        """
        Generate diagnostic dict explaining certificate state.

        Returns comprehensive diagnostic information for:
        - Multimodal certificates: identifies weak modality, health status per modality
        - Single-modal: returns minimal dict indicating not multimodal

        Health thresholds:
        - healthy: κ >= 0.7
        - degraded: 0.4 <= κ < 0.7
        - critical: κ < 0.4

        Returns:
            Dict with:
            - multimodal: bool
            - kappa_gate: float (enforcement scalar)
            - weak_modality: str or None
            - weak_value: float or None
            - health: Dict[str, str] per modality
            - hierarchy_gap: float or None
            - is_desynced: bool (True if any modality critical)

        Reference: SDK diagnose_multimodal() - this belongs in core so
        both yrsn and downstream SDKs share the same diagnostic logic.
        """
        if not self.is_multimodal:
            return {'multimodal': False}

        weak = self.weak_modality
        weak_value = None
        if weak == 'text':
            weak_value = self.kappa_H
        elif weak == 'vision':
            weak_value = self.kappa_L
        elif weak == 'interface':
            weak_value = self.kappa_interface

        # Health status per modality
        health = {}
        for name, value in [('text', self.kappa_H), ('vision', self.kappa_L), ('interface', self.kappa_interface)]:
            if value is None:
                continue
            if value >= 0.7:
                health[name] = 'healthy'
            elif value >= 0.4:
                health[name] = 'degraded'
            else:
                health[name] = 'critical'

        return {
            'multimodal': True,
            'kappa_gate': self.kappa_gate,
            'weak_modality': weak,
            'weak_value': weak_value,
            'health': health,
            'hierarchy_gap': self.hierarchy_gap,
            'is_desynced': any(h == 'critical' for h in health.values()),
        }

    # =========================================================================
    # P14/P16 DISCRETIZATION PROPERTIES (For UnifiedQualityController grids)
    # =========================================================================

    @property
    def alpha_state(self) -> str:
        """
        3-level α discretization for dual grid lookup.

        HIGH: α ≥ 0.6 (strong content quality)
        MODERATE: 0.3 ≤ α < 0.6 (adequate content quality)
        LOW: α < 0.3 (weak content quality)

        Reference: unified_quality_controller.py §7
        """
        if self.alpha >= 0.6:
            return "HIGH"
        if self.alpha >= 0.3:
            return "MODERATE"
        return "LOW"

    @property
    def kappa_state(self) -> str:
        """
        3-level κ discretization for α×κ grid (RSCT compatibility).

        HIGH: κ ≥ 0.6 (strong solver-representation compatibility)
        MODERATE: 0.3 ≤ κ < 0.6 (moderate compatibility)
        LOW: κ < 0.3 (poor compatibility)
        UNKNOWN: κ is None (no RSCT metadata available)

        Reference: unified_quality_controller.py §7
        """
        if self.kappa is None:
            return "UNKNOWN"
        if self.kappa >= 0.6:
            return "HIGH"
        if self.kappa >= 0.3:
            return "MODERATE"
        return "LOW"

    @property
    def omega_state(self) -> str:
        """
        3-level ω discretization for α×ω fallback grid.

        HIGH: ω ≥ 0.6 (strong distributional reliability)
        MODERATE: 0.3 ≤ ω < 0.6 (moderate reliability)
        LOW: ω < 0.3 (weak reliability)

        Reference: unified_quality_controller.py §7
        """
        if self.omega >= 0.6:
            return "HIGH"
        if self.omega >= 0.3:
            return "MODERATE"
        return "LOW"

    # =========================================================================
    # MULTI-DIMENSIONAL GRID PROPERTIES (Patent §V.C.6.1)
    # ESL-Friendly 5-Name Standard for Vector Access
    # =========================================================================

    @property
    def integrity_rsn(self) -> Dict[str, float]:
        """
        Safety Gate: RSN integrity check (Stage 1).

        Returns RSN components as dict for pattern matching.
        Multi-dimensional grid uses this to identify which component
        is dominant (R, S, or N).

        Reference: multi_dimensional_grid.py identify_rsn_pattern()
        """
        return {'r': self.R, 's': self.S, 'n': self.N}

    @property
    def kappa_modal(self) -> Optional[Dict[str, float]]:
        """
        Source Health: Modal compatibility scores (multimodal only).

        Returns κ components for each modality:
        - 'text': Text encoding-solver compatibility (κ_H)
        - 'vision': Vision encoding-solver compatibility (κ_L)
        - 'interface': Cross-modal fusion quality (κ_interface)

        None if single-modal (no hierarchy fields).

        Key Insight: Grid needs to know WHICH modality is weak,
        not just min(). This preserves diagnostic information.

        Reference: multi_dimensional_grid.py identify_kappa_pattern()
        """
        if self.kappa_H is None and self.kappa_L is None and self.kappa_interface is None:
            return None
        return {
            'text': self.kappa_H,
            'vision': self.kappa_L,
            'interface': self.kappa_interface
        }

    @property
    def kappa_gate(self) -> Optional[float]:
        """
        Enforcement Scalar: Weakest link for blocking decisions.

        For multimodal: min(kappa_modal.values()) - zero-trust
        For single-modal: self.kappa

        This is the scalar used in Step 7.5 enforcement checks,
        but the grid ALSO needs kappa_modal for pattern diagnosis.

        Reference: multi_dimensional_grid.py SupervisoryController
        """
        # Use self.kappa if available (single-modal or pre-computed)
        if self.kappa is not None:
            return self.kappa
        # For multimodal, compute min() on the fly
        if self.kappa_modal is not None:
            return min(self.kappa_modal.values())
        return None

    @property
    def kappa_diag(self) -> Optional[Dict[str, float]]:
        """
        Diagnostics: Why is κ low? (logs only, NOT for gating).

        Returns normalized κ-simplex components:
        - 'align': Algorithmic alignment (κ_A)
        - 'efficiency': Information efficiency (κ_E)
        - 'tractability': Search tractability (κ_T)

        These are post-hoc diagnostic decompositions,
        NOT source health measurements (use kappa_modal for that).

        None if diagnostic components not computed.

        Reference: Gemini's 5-name standard
        """
        if self.kappa_A is None or self.kappa_E is None or self.kappa_T is None:
            return None
        return {
            'align': self.kappa_A,
            'efficiency': self.kappa_E,
            'tractability': self.kappa_T
        }

    @property
    def is_noise_collapsed(self) -> bool:
        """
        Asymmetric Safety: True if N > (R × 0.8).

        Conservative trigger threshold - detects approaching
        noise collapse before symmetric N > R threshold.

        This implements Type I error prevention: better to
        falsely reject good data than execute on noise.

        Reference: multi_dimensional_grid.py identify_rsn_pattern()
        """
        return self.N > (self.R * 0.8)

    @property
    def is_noise_dominant(self) -> bool:
        """
        Symmetric Check: True if N > R.

        Standard noise dominance check.

        Reference: For comparison with asymmetric threshold
        """
        return self.N > self.R

    # =========================================================================
    # THREE ORTHOGONAL STABILITY CONCEPTS (Computed Properties)
    # =========================================================================
    # Reference: docs/analysis/Three_Stability_Concepts_Clarification.md
    #
    # These three properties are COMPLETELY INDEPENDENT:
    # 1. admissibility_state - Authorization gate (BLOCKS execution)
    # 2. quality_envelope_state - Quality diagnostic (informational)
    # 3. lyapunov_state - Trajectory verification (advisory)
    # =========================================================================

    @property
    def admissibility_state(self) -> AdmissibilityState:
        """
        Compute admissibility state - AUTHORIZATION GATE.

        Four-Layer Architecture Check:
        - Layer 1: RSN quality (R, N thresholds) → UNSAFE if N > 0.5
        - Layer 2: κ compatibility (encoding-solver match) → INCOMPATIBLE if κ < 0.3 ⭐
        - Layer 2: σ stability (instability threshold) → UNSTABLE if σ > 0.7

        Returns:
            AdmissibilityState enum (ADMISSIBLE, INCOMPATIBLE, UNSTABLE, UNSAFE)

        This is the ONLY gate that blocks execution (REJECT/RE_ENCODE).
        Quality envelope and Lyapunov are informational/advisory only.

        κ (Layer 2) is THE critical check - encoding must match solver!
        """
        # UNSAFE: High noise or noise collapsed (asymmetric safety)
        if self.N > 0.5 or self.is_noise_collapsed:
            return AdmissibilityState.UNSAFE

        # INCOMPATIBLE: Low κ (encoding doesn't match solver)
        if self.kappa is not None and self.kappa < 0.3:
            return AdmissibilityState.INCOMPATIBLE

        # UNSTABLE: High σ (system too unstable)
        if self.sigma is not None and self.sigma > 0.7:
            return AdmissibilityState.UNSTABLE

        # ADMISSIBLE: Passes all checks
        return AdmissibilityState.ADMISSIBLE

    @property
    def is_admissible(self) -> bool:
        """
        Boolean check: Is encoding admissible for execution?

        Returns:
            True if admissibility_state == ADMISSIBLE, False otherwise

        This is the BLOCKING gate. Only this property determines
        whether execution should be allowed (REJECT/RE_ENCODE if False).
        """
        return self.admissibility_state == AdmissibilityState.ADMISSIBLE

    @property
    def quality_envelope_state(self) -> QualityEnvelopeState:
        """
        Compute quality envelope state - DIAGNOSTIC (§7.10).

        Maps fragility_state to quality envelope classification.
        This is informational/diagnostic only - does NOT gate execution.

        Returns:
            QualityEnvelopeState enum (NOMINAL, INSTABILITY, CONFLICT, BOUNDARY_RISK, COLLAPSED)

        Reference: §7.10 fragility state classification
        """
        # If fragility_state is available, use it
        if self.fragility_state is not None:
            fragility_enum = self.fragility_state_enum
            if fragility_enum == FragilityState.STABLE:
                return QualityEnvelopeState.NOMINAL
            elif fragility_enum == FragilityState.INSTABILITY:
                return QualityEnvelopeState.INSTABILITY
            elif fragility_enum == FragilityState.CONFLICT:
                return QualityEnvelopeState.CONFLICT
            elif fragility_enum == FragilityState.BOUNDARY_RISK:
                return QualityEnvelopeState.BOUNDARY_RISK
            elif fragility_enum == FragilityState.COLLAPSE:
                return QualityEnvelopeState.COLLAPSED

        # Fallback: compute from basic metrics
        if self.N > 0.5:
            return QualityEnvelopeState.COLLAPSED
        elif self.alpha < 0.3:
            return QualityEnvelopeState.BOUNDARY_RISK
        else:
            return QualityEnvelopeState.NOMINAL

    @property
    def lyapunov_state(self) -> Optional[LyapunovState]:
        """
        Compute Lyapunov stability state - VERIFICATION (Layer 4).

        Determines if trajectory is converging based on V̇.
        This is advisory/verification only - does NOT gate execution.

        Returns:
            LyapunovState enum (CONVERGING, EQUILIBRIUM, DIVERGING) or None

        Reference: Layer 4 Lyapunov stability verification
        """
        if self.V_dot is None:
            return None

        # V̇ < -0.01: Strict convergence
        if self.V_dot < -0.01:
            return LyapunovState.CONVERGING

        # V̇ ≈ 0: Equilibrium (within tolerance)
        if abs(self.V_dot) <= 0.01:
            return LyapunovState.EQUILIBRIUM

        # V̇ > 0: Diverging (unstable)
        return LyapunovState.DIVERGING

    # =========================================================================
    # P14/P16 VERIFICATION METHOD
    # =========================================================================

    def verify(self) -> Dict[str, bool]:
        """
        O(1) certificate verification (P14/P16 compliance + structural checks).

        Returns dict of all verification checks:
        - simplex_valid: R+S+N = 1 within tolerance
        - range_valid: All core signals in [0,1]
        - alpha_omega_consistent: α_ω = α×ω + prior×(1-ω) holds
        - hash_integrity: P16 hash verification (if fields present)
        - kappa_range_valid: κ in [0,1] (if present)
        - sigma_range_valid: σ in [0,1] (if present)

        Reference:
        - P14: Alpha-omega canonical formula
        - P16: Hash integrity verification
        - unified_quality_controller.py §6 YRSNCertificate.verify()

        Example:
            cert = YRSNCertificate(R=0.8, S=0.15, N=0.05, alpha=0.8, omega=0.9, tau=1.2)
            checks = cert.verify()
            if not all(checks.values()):
                print(f"Failed checks: {[k for k,v in checks.items() if not v]}")
        """
        import math
        checks = {}

        # Structural: simplex constraint
        simplex_sum = self.R + self.S + self.N
        checks["simplex_valid"] = math.isclose(simplex_sum, 1.0, abs_tol=1e-6)

        # Structural: range constraints
        checks["range_valid"] = all(
            0 <= v <= 1 for v in [self.R, self.S, self.N, self.alpha, self.omega, self.prior]
        )

        # P14: alpha_omega consistency
        expected_a_w = self.omega * self.alpha + (1.0 - self.omega) * self.prior
        checks["alpha_omega_consistent"] = math.isclose(
            self.alpha_omega, expected_a_w, abs_tol=1e-6
        )

        # P16: hash integrity (if fields present)
        if self.inv_spec_blob is not None and self.inv_spec_hash is not None:
            import hashlib
            computed = hashlib.sha256(self.inv_spec_blob.encode('utf-8')).hexdigest()
            checks["hash_integrity"] = (computed == self.inv_spec_hash)

        # RSCT: optional field range checks
        if self.kappa is not None:
            checks["kappa_range_valid"] = 0 <= self.kappa <= 1
        if self.sigma is not None:
            checks["sigma_range_valid"] = 0 <= self.sigma <= 1

        return checks

    # =========================================================================
    # FACTORY METHODS
    # =========================================================================

    @classmethod
    def from_multimodal(
        cls,
        text_rsn: Dict[str, float],
        vision_rsn: Dict[str, float],
        fused_rsn: Dict[str, float],
        agreement: float,
        omega: float = 0.9,
        t4_baseline: np.ndarray = None,
        V_prev: float = None,
        **kwargs
    ) -> "YRSNCertificate":
        """
        Factory method to create certificate from multimodal decomposition.

        Args:
            text_rsn: {'R': float, 'S': float, 'N': float} from text
            vision_rsn: {'R': float, 'S': float, 'N': float} from vision
            fused_rsn: {'R': float, 'S': float, 'N': float} fused result
            agreement: Cross-modal agreement score (cosine similarity)
            omega: In-distribution confidence (default 0.9)
            t4_baseline: Optional baseline T⁴ coordinates for Lyapunov V
            V_prev: Optional previous V value for V_dot computation
            **kwargs: Additional extras to store

        Returns:
            YRSNCertificate with all multimodal diagnostics populated,
            including T⁴ coordinates and Lyapunov V/V_dot
        """
        from yrsn.core.decomposition.geometric_utils import compute_t4_coordinates
        # Ghost #3 fix: Import instability computation for sigma_H/sigma_L
        from yrsn.core.decomposition.instability_computation import (
            compute_sigma_from_rsn,
            InstabilityDomain
        )
        # Ghost #1 fix: Import phasor coherence for multi-source conflict detection
        from yrsn.core.decomposition.phasor_coherence import (
            PhasorSource,
            compute_phasor_coherence
        )

        R, S, N = fused_rsn['R'], fused_rsn['S'], fused_rsn['N']
        alpha = R  # α = R for quality

        # Compute T⁴ coordinates from fused RSN
        t4_dict = compute_t4_coordinates(R, S, N)
        t4_coords = np.array([
            float(t4_dict['simplex_theta']),
            float(t4_dict['phi_simplex']),
            float(t4_dict['alpha_t4']),
            float(t4_dict['omega_t4']),
        ])

        # Default baseline: ideal point (high R, low S, low N)
        # R=0.9, S=0.05, N=0.05 → specific T⁴ position
        if t4_baseline is None:
            baseline_dict = compute_t4_coordinates(0.9, 0.05, 0.05)
            t4_baseline = np.array([
                float(baseline_dict['simplex_theta']),
                float(baseline_dict['phi_simplex']),
                float(baseline_dict['alpha_t4']),
                float(baseline_dict['omega_t4']),
            ])

        # Determine dominant modality
        if text_rsn['R'] > vision_rsn['R']:
            dominant = 'text'
        elif vision_rsn['R'] > text_rsn['R']:
            dominant = 'vision'
        else:
            dominant = 'tie'

        # Build extras
        extras = {
            'text_rsn': text_rsn,
            'vision_rsn': vision_rsn,
            'dominant_modality': dominant,
            'hierarchy_gap': abs(text_rsn['R'] - vision_rsn['R']),
            'contrarian': 1.0 - agreement,
            **kwargs
        }

        # Ghost #3 fix: Compute hierarchical sigma (instability per modality)
        # Follows same pattern as kappa_H/kappa_L computation
        sigma_H_components = compute_sigma_from_rsn(
            text_rsn['R'], text_rsn['S'], text_rsn['N'],
            domain=InstabilityDomain.QUALITY
        )
        sigma_L_components = compute_sigma_from_rsn(
            vision_rsn['R'], vision_rsn['S'], vision_rsn['N'],
            domain=InstabilityDomain.QUALITY
        )

        # Ghost #1 fix: Compute phasor coherence for multi-source conflict detection
        # Treat text and vision as two phasor sources
        # Amplitude = R (quality), Phase = simplex angle (from T⁴ coordinates)
        text_t4 = compute_t4_coordinates(text_rsn['R'], text_rsn['S'], text_rsn['N'])
        vision_t4 = compute_t4_coordinates(vision_rsn['R'], vision_rsn['S'], vision_rsn['N'])

        text_phasor = PhasorSource(
            amplitude=text_rsn['R'],
            phase=float(text_t4['simplex_theta']),  # Angle in simplex (0-360°)
            source_id='text'
        )
        vision_phasor = PhasorSource(
            amplitude=vision_rsn['R'],
            phase=float(vision_t4['simplex_theta']),
            source_id='vision'
        )

        # Compute coherence between modalities
        phasor_result = compute_phasor_coherence([text_phasor, vision_phasor])
        coherence = phasor_result.coherence

        # Source Health (κ-Modal Simplex): Compositional breakdown
        # κ_H: Text/semantic encoding-solver compatibility
        # κ_L: Vision/perception encoding-solver compatibility
        # κ_interface: Cross-modal fusion quality
        # Tables from expS5_220: domain accuracy per modality
        kappa_H = cls._compute_empirical_kappa(text_rsn, {'R': 0.129, 'S': 0.250, 'N': 0.667})
        kappa_L = cls._compute_empirical_kappa(vision_rsn, {'R': 0.710, 'S': 0.062, 'N': 0.407})
        kappa_interface = agreement

        # Execution Score (κ-Gate): Weakest-link composition
        # If ANY modality fails, system blocks execution (zero-trust)
        kappa_gate = min(kappa_H, kappa_L, kappa_interface)

        return cls(
            R=R, S=S, N=N,
            alpha=alpha,
            omega=omega,
            tau=1.0 / max(alpha, 0.01),
            # RSCT fields
            kappa=kappa_gate,  # Execution Score (the enforcement gate)
            sigma=abs(text_rsn['R'] - vision_rsn['R']),
            # Source Health (κ-Modal Simplex) - Compositional breakdown
            kappa_H=kappa_H,
            kappa_L=kappa_L,
            kappa_interface=kappa_interface,
            # Ghost #3 fix: Hierarchical sigma (instability per modality)
            sigma_H=sigma_H_components.sigma_combined,
            sigma_L=sigma_L_components.sigma_combined,
            # Ghost #1 fix: Phasor coherence (multi-source conflict detection)
            coherence=coherence,
            # T⁴ coordinates for Lyapunov V
            t4_coords=t4_coords,
            t4_baseline=t4_baseline,
            V_prev=V_prev,
            # Modality
            modality='multimodal',
            # Extras
            extras=extras,
        )

    def with_kappa(
        self,
        kappa: float = None,
        d_star: float = None,
        d_actual: float = None,
        encoding_type: str = None,
        solver_type: str = None,
    ) -> "YRSNCertificate":
        """
        Return new certificate with RSCT kappa values set.

        Example:
            cert = YRSNCertificate(R=0.7, S=0.2, N=0.1, alpha=0.7, omega=0.9, tau=1.4)
            cert_rsct = cert.with_kappa(d_star=30, d_actual=40, solver_type='HRMV')
            print(cert_rsct.kappa)  # 0.75
            print(cert_rsct.alpha_kappa)  # blended quality using κ
        """
        from dataclasses import replace

        updates = {}

        if d_star is not None:
            updates['d_star'] = d_star
        if d_actual is not None:
            updates['d_actual'] = d_actual

        # Compute kappa from D*/D if not provided directly
        if kappa is not None:
            updates['kappa'] = kappa
        else:
            # Use updated values if provided, otherwise use existing
            _d_star = d_star if d_star is not None else self.d_star
            _d_actual = d_actual if d_actual is not None else self.d_actual
            if _d_star is not None and _d_actual is not None and _d_actual > 0:
                updates['kappa'] = min(1.0, _d_star / _d_actual)

        if encoding_type is not None:
            updates['encoding_type'] = encoding_type
        if solver_type is not None:
            updates['solver_type'] = solver_type

        return replace(self, **updates)

    def with_defense_result(
        self,
        defense_result: 'DefenseCheckResult',
    ) -> "YRSNCertificate":
        """
        Return new certificate with defense signals stamped.

        Output Bridge: Records defense layer decisions onto certificate
        for audit trail and downstream consumption by UnifiedQualityController.

        Example:
            defense_result = defense_stack.check_all(agent_id, goal, certificate=cert)
            cert = cert.with_defense_result(defense_result)
            print(cert.defense_goal_valid)   # True/False
            print(cert.defense_pressure)      # 0.0 - 1.0

        Args:
            defense_result: DefenseCheckResult from DefenseStack.check_all()

        Returns:
            New YRSNCertificate with defense fields populated
        """
        from dataclasses import replace

        return replace(
            self,
            defense_goal_valid=defense_result.goal_valid,
            defense_is_sybil=defense_result.is_sybil,
            defense_rate_limited=defense_result.rate_limited,
            defense_pressure=defense_result.pressure_contribution,
            defense_manager_healthy=defense_result.manager_healthy,
            defense_check_timestamp=datetime.now().isoformat(),
        )

    # =========================================================================
    # LYAPUNOV COMPUTATION (Internal)
    # =========================================================================

    def _compute_lyapunov_helpers(self) -> None:
        """
        Compute Lyapunov stability helpers from T⁴ coordinates.

        The Lyapunov function V(x) = d_chordal(x, x*) measures distance
        from current state to baseline on the T⁴ manifold.

        Stability thresholds (from DriftMonitor):
            V < 0.2: NOMINAL (1st gear territory)
            V ∈ [0.2, 0.5): JITTER (2nd gear)
            V ∈ [0.5, 1.0): DRIFT warning (3rd gear)
            V ∈ [1.0, 1.5): DRIFT critical (3rd gear + alert)
            V ≥ 1.5: COLLAPSE (REVERSE / block)
        """
        # Compute V = chordal distance on T⁴
        if self.V is None:
            object.__setattr__(self, 'V', self._chordal_distance_t4(
                np.asarray(self.t4_coords),
                np.asarray(self.t4_baseline)
            ))

        # Compute V_dot from previous value (if available)
        if self.V_prev is not None and self.V_dot is None:
            object.__setattr__(self, 'V_dot', self.V - self.V_prev)  # Discrete approximation

        # Lyapunov stability classification (Layer 4)
        if self.V_dot is not None:
            lyapunov_stable = self.V_dot <= 0.0

            # Set is_lyapunov_stable (new field)
            if self.is_lyapunov_stable is None:
                object.__setattr__(self, 'is_lyapunov_stable', lyapunov_stable)

            # Backward compatibility: keep is_stable synced with is_lyapunov_stable
            if self.is_stable is None:
                object.__setattr__(self, 'is_stable', lyapunov_stable)

            if self.is_converging is None:
                object.__setattr__(self, 'is_converging', self.V_dot < -0.01)  # Strict decrease

        # Backward compatibility fallback: if is_stable was set but is_lyapunov_stable wasn't,
        # sync them (for old code that sets is_stable explicitly)
        if self.is_stable is not None and self.is_lyapunov_stable is None:
            object.__setattr__(self, 'is_lyapunov_stable', self.is_stable)

        # Lyapunov margin: distance from collapse threshold (1.5)
        if self.lyapunov_margin is None:
            object.__setattr__(self, 'lyapunov_margin', 1.5 - self.V)

        # Recommended gear based on V (control law)
        if self.recommended_gear is None:
            object.__setattr__(self, 'recommended_gear', self._gear_from_lyapunov(self.V))

    @staticmethod
    def _compute_empirical_kappa(rsn: Dict[str, float], kappa_table: Dict[str, float]) -> float:
        """
        Compute empirical κ using domain accuracy tables.

        FIX for R-as-κ bug: Instead of using R directly as κ, compute
        expected domain accuracy given the RSN distribution.

        κ = Σ_d (P(domain=d) × Accuracy(modality, d))
          = R × κ_R + S × κ_S + N × κ_N

        Tables from expS5_220:
        - KAPPA_TEXT = {'R': 0.129, 'S': 0.250, 'N': 0.667}
        - KAPPA_VISION = {'R': 0.710, 'S': 0.062, 'N': 0.407}

        Args:
            rsn: {'R': float, 'S': float, 'N': float}
            kappa_table: Domain accuracy per domain for this modality

        Returns:
            Expected κ [0, 1]
        """
        return (
            rsn.get('R', 0.0) * kappa_table.get('R', 0.5) +
            rsn.get('S', 0.0) * kappa_table.get('S', 0.5) +
            rsn.get('N', 0.0) * kappa_table.get('N', 0.5)
        )

    @staticmethod
    def _chordal_distance_t4(x: np.ndarray, y: np.ndarray) -> float:
        """
        Compute chordal distance on T⁴ = S¹ × S¹ × S¹ × S¹.

        Uses the formula: d = √(Σᵢ (1 - cos(xᵢ - yᵢ)))

        This is the proper distance metric on the torus that:
        - Handles angular wraparound correctly
        - Is bounded [0, 2√2] for each dimension
        - Satisfies triangle inequality

        Args:
            x: Current T⁴ coordinates [θ, φ, α_t4, ω_t4] in degrees
            y: Baseline T⁴ coordinates [θ, φ, α_t4, ω_t4] in degrees

        Returns:
            Chordal distance (scalar)
        """
        # Convert to radians
        x_rad = np.deg2rad(x)
        y_rad = np.deg2rad(y)

        # Chordal distance: sqrt(sum((1 - cos(diff))^2))
        diff = x_rad - y_rad
        chordal_components = 1.0 - np.cos(diff)
        return float(np.sqrt(np.sum(chordal_components ** 2)))

    @staticmethod
    def _gear_from_lyapunov(V: float) -> str:
        """
        Determine recommended gear from Lyapunov function value.

        This is the control law that guarantees V̇ ≤ 0:
        - Low V → precision gear (gradient, V̇ < 0 guaranteed)
        - Medium V → balanced gear
        - High V → exploration gear (find new basin)
        - Critical V → REVERSE (emergency recovery)

        Args:
            V: Lyapunov function value (T⁴ distance)

        Returns:
            Recommended gear string
        """
        if V < 0.2:
            return "1st"  # Precision: gradient descent, V̇ < 0
        elif V < 0.5:
            return "2nd"  # Balanced: guided refinement
        elif V < 1.0:
            return "3rd"  # Explore: find better basin
        elif V < 1.5:
            return "3rd"  # Still explore, but with warning
        else:
            return "R"    # REVERSE: emergency recovery

    # =========================================================================
    # CLASSIFICATION API (§7.9/§7.10/§7.11) - Threshold-Injectable
    # =========================================================================

    @staticmethod
    def default_thresholds() -> CertificateThresholds:
        """
        Canonical defaults (CollapseConfig/Pillar3Config own their defaults).

        Returns:
            CertificateThresholds with default CollapseConfig and Pillar3Config
        """
        from yrsn.core.decomposition.collapse import CollapseConfig
        from yrsn.core.decomposition.pillar_configs import Pillar3Config
        return CertificateThresholds(
            collapse=CollapseConfig(),
            pillar3=Pillar3Config(),
        )

    def classify(self, thresholds: CertificateThresholds) -> CertificateClassification:
        """
        Compute all classification fields using provided thresholds.

        This is a PURE method - does not mutate the certificate.
        Use apply_classification() to stamp results onto the certificate.

        Args:
            thresholds: CertificateThresholds bundle with collapse and pillar3 configs

        Returns:
            CertificateClassification with fragility_state, severity_value, degradation_type
        """
        return CertificateClassification(
            fragility_state=self.compute_fragility_state(thresholds.collapse, thresholds.pillar3),
            severity_value=self.compute_severity_value(thresholds.pillar3),
            degradation_type=self.compute_degradation_type(thresholds.collapse),
        )

    def classify_default(self) -> CertificateClassification:
        """Classify using canonical defaults."""
        return self.classify(self.default_thresholds())

    def apply_classification(self, cls: CertificateClassification) -> None:
        """
        Explicitly stamp classification onto certificate (mutation).

        Stores .value strings for backward compatibility with serialization.

        Args:
            cls: CertificateClassification result from classify()
        """
        object.__setattr__(self, 'fragility_state', cls.fragility_state.value)
        object.__setattr__(self, 'severity_value', cls.severity_value)
        object.__setattr__(self, 'degradation_type', cls.degradation_type.value)

    # =========================================================================
    # PURE COMPUTE METHODS (Return Enums, Use Config Thresholds)
    # =========================================================================

    def compute_fragility_state(
        self,
        collapse: 'CollapseConfig',
        pillar3: 'Pillar3Config',
    ) -> FragilityState:
        """
        §7.10 Fragility using EVC-configurable thresholds.

        Priority order per §7.10.4.2:
        COLLAPSE > CONFLICT > INSTABILITY > BOUNDARY_RISK > STABLE

        Args:
            collapse: CollapseConfig with threshold values
            pillar3: Pillar3Config with severity/constraint values

        Returns:
            FragilityState enum
        """
        # §7.10.4.3: Check COLLAPSE first (most severe)
        if self._is_fragility_collapse(collapse, pillar3):
            return FragilityState.COLLAPSE
        # §7.10.4.4: Check CONFLICT
        if self._is_fragility_conflict(collapse):
            return FragilityState.CONFLICT
        # §7.10.4.5: Check INSTABILITY (requires history)
        if self._is_instability():
            return FragilityState.INSTABILITY
        # §7.10.4.6: Check BOUNDARY_RISK
        if self._is_boundary_risk(collapse):
            return FragilityState.BOUNDARY_RISK
        # No fragility detected
        return FragilityState.STABLE

    def compute_severity_value(self, config: 'Pillar3Config') -> float:
        """
        §7.11.3.2 Severity value [0, 1] with linear interpolation.

        Uses Pillar3Config severity thresholds for tier boundaries.

        Args:
            config: Pillar3Config with severity_*_threshold values

        Returns:
            Severity value in [0.0, 1.0]
        """
        x = self.N
        t0 = config.severity_low_threshold
        t1 = config.severity_medium_threshold
        t2 = config.severity_high_threshold
        t3 = config.severity_critical_threshold

        if x <= t0:
            return 0.0
        if x >= t3:
            return 1.0
        if x <= t1:
            return (x - t0) / (t1 - t0) * 0.5
        if x <= t2:
            return 0.5 + (x - t1) / (t2 - t1) * 0.25
        return 0.75 + (x - t2) / (t3 - t2) * 0.25

    def compute_degradation_type(self, config: 'CollapseConfig') -> DegradationType:
        """
        §7.9 Degradation type classification.

        Priority order per §7.9.5.3:
        POISONING > COLLAPSE > HALLUCINATION > CONFLICT > DRIFT > DISTRACTION > BOUNDARY > HEALTHY

        Args:
            config: CollapseConfig with threshold values

        Returns:
            DegradationType enum
        """
        # Priority 1: POISONING - safety-critical, check first
        if self._is_poisoning(config):
            return DegradationType.POISONING
        # Priority 2: COLLAPSE - system cannot proceed
        if self._is_collapse_degradation(config):
            return DegradationType.COLLAPSE
        # Priority 3: HALLUCINATION - high risk of confident errors
        if self._is_hallucination(config):
            return DegradationType.HALLUCINATION
        # Priority 4: CONFLICT - cannot resolve quality state
        if self._is_conflict(config):
            return DegradationType.CONFLICT
        # Priority 5: DRIFT - systematic issue
        if self._is_drift(config):
            return DegradationType.DRIFT
        # Priority 6: DISTRACTION - quality issue, manageable
        if self._is_distraction(config):
            return DegradationType.DISTRACTION
        # Priority 7: BOUNDARY - warning state
        if self._is_boundary(config):
            return DegradationType.BOUNDARY
        # Priority 8: HEALTHY - default if no issues
        return DegradationType.HEALTHY

    # =========================================================================
    # DEGRADATION TYPE HELPERS (uses CollapseConfig - NO HARDCODED VALUES)
    # =========================================================================

    def _is_collapse_degradation(self, config: 'CollapseConfig') -> bool:
        """
        §7.9.4.1 COLLAPSE: No dominant signal, R≈S≈N or critically low quality.
        Uses rsn_collapse_delta for near-uniform check, error_alpha_low for quality.
        """
        rsn_range = max(self.R, self.S, self.N) - min(self.R, self.S, self.N)
        return rsn_range < config.rsn_collapse_delta and self.alpha < config.error_alpha_low

    def _is_poisoning(self, config: 'CollapseConfig') -> bool:
        """§7.9.4.1 POISONING: High noise (N > poisoning_n threshold)."""
        return self.N > config.poisoning_n

    def _is_conflict(self, config: 'CollapseConfig') -> bool:
        """
        §7.9.4.1 CONFLICT: Contradictory signals, near-uniform RSN.
        Different from COLLAPSE: CONFLICT has moderate alpha, COLLAPSE has low alpha.
        """
        rsn_range = max(self.R, self.S, self.N) - min(self.R, self.S, self.N)
        return rsn_range < config.rsn_collapse_delta and self.alpha >= config.error_alpha_low

    def _is_distraction(self, config: 'CollapseConfig') -> bool:
        """§7.9.4.1 DISTRACTION: High S (S > distraction_s threshold)."""
        return self.S > config.distraction_s

    def _is_drift(self, config: 'CollapseConfig') -> bool:
        """§7.9.4.1 DRIFT: Low reliability (omega < drift_omega threshold)."""
        return self.omega < config.drift_omega

    def _is_hallucination(self, config: 'CollapseConfig') -> bool:
        """
        §7.9.4.1 HALLUCINATION: High α with low ω.
        Confident but unreliable - uses hallucination_alpha and hallucination_omega.
        """
        return self.alpha > config.hallucination_alpha and self.omega < config.hallucination_omega

    def _is_boundary(self, config: 'CollapseConfig') -> bool:
        """
        §7.9.4.1 BOUNDARY: Near operational envelope edges.
        R below healthy_r indicates low relevance edge.
        R above (1 - healthy_n_max) indicates suspiciously high relevance.
        """
        r_too_low = self.R < config.healthy_r
        r_too_high = self.R > (1.0 - config.healthy_n_max)  # 1 - 0.28 = 0.72
        return r_too_low or r_too_high

    # =========================================================================
    # FRAGILITY STATE HELPERS (uses CollapseConfig + Pillar3Config)
    # =========================================================================

    def _is_fragility_collapse(self, config: 'CollapseConfig', p3: 'Pillar3Config') -> bool:
        """
        §7.10.3.4 COLLAPSE fragility: N > actual_max_noise or alpha < actual_min_quality.
        Uses Pillar3Config actual constraints (fatal violations).
        """
        return self.N > p3.actual_max_noise or self.alpha < p3.actual_min_quality

    def _is_fragility_conflict(self, config: 'CollapseConfig') -> bool:
        """
        §7.10.4.4 CONFLICT fragility: Sources disagree.

        Per spec: if coherence < thresholds.CONFLICT.min_coherence: return true
        Uses conflict_coherence_threshold from config (default 0.4 per phasor_coherence.py)

        Fallback: if coherence not available, uses near-uniform RSN as proxy.
        """
        # Primary: use coherence per §7.10.4.4
        if self.coherence is not None:
            return self.coherence < config.conflict_coherence_threshold

        # Fallback: near-uniform RSN with low alpha suggests conflict
        rsn_range = max(self.R, self.S, self.N) - min(self.R, self.S, self.N)
        return rsn_range < config.rsn_collapse_delta and self.alpha < config.error_alpha_low

    def _is_boundary_risk(self, config: 'CollapseConfig') -> bool:
        """
        §7.10.3.3 BOUNDARY_RISK: Near threshold boundaries.
        N within rsn_collapse_delta of healthy_n_max, or low lyapunov_margin.
        """
        n_near_boundary = abs(self.N - config.healthy_n_max) < config.rsn_collapse_delta
        # Lyapunov margin check uses dedicated threshold (no magic multiplier)
        lyap_near_boundary = (self.lyapunov_margin is not None and
                              self.lyapunov_margin < config.lyapunov_boundary_margin)
        return n_near_boundary or lyap_near_boundary

    def _is_instability(self) -> bool:
        """§7.10.3.1 INSTABILITY: High variance - uses n_trend as proxy."""
        return self.n_trend == "rising"

    # =========================================================================
    # TYPED ENUM PROPERTIES (for new code)
    # =========================================================================

    @property
    def fragility_state_enum(self) -> Optional[FragilityState]:
        """Return fragility_state as enum (None if not classified)."""
        if self.fragility_state is None:
            return None
        return FragilityState(self.fragility_state)

    @property
    def degradation_type_enum(self) -> Optional[DegradationType]:
        """Return degradation_type as enum (None if not classified)."""
        if self.degradation_type is None:
            return None
        return DegradationType(self.degradation_type)

    # =========================================================================
    # PKI-STYLE VALIDITY METHODS
    # =========================================================================

    def is_expired(self) -> bool:
        """
        Check if certificate has expired.

        Returns False if no expiry is set (certificate never expires).
        """
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at

    def is_valid(self) -> bool:
        """
        Check if certificate is currently valid (not expired).

        A certificate with no expires_at is always valid.
        """
        return not self.is_expired()

    # =========================================================================
    # ORACLE-FREE METHODS
    # =========================================================================

    def is_healthy(self, n_threshold: float = 0.2, alpha_threshold: float = 0.5) -> bool:
        """
        Check if certificate indicates healthy hardware.

        ORACLE-FREE: Uses only certificate values, no ground truth.
        """
        return self.N < n_threshold and self.alpha > alpha_threshold

    def needs_refresh(self, n_critical: float = 0.3, alpha_critical: float = 0.3) -> bool:
        """
        Check if hardware needs refresh.

        ORACLE-FREE: Uses only certificate values.
        """
        return self.N > n_critical or self.alpha < alpha_critical

    def get_refresh_urgency(self) -> float:
        """
        Compute refresh urgency from certificate.

        ORACLE-FREE: Uses tau to modulate urgency.
        High tau = high uncertainty = more urgent refresh.

        Returns:
            Urgency score [0, 1]
        """
        # Tau typically in [1, 10], normalize to [0, 1]
        tau_factor = min(1.0, (self.tau - 1.0) / 9.0)

        # Weight by N (degradation signal)
        n_factor = min(1.0, self.N * 3)  # Scale N to [0, 1]

        return tau_factor * n_factor

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary (all oracle-free values).

        NOTE: This method returns the internal representation (v0.1 format).
        For ISA operations requiring v0.2 schema with context fields, use to_v0_2() instead.

        WARNING: This dict will FAIL validation with certificate_validator.validate_certificate()
        because it lacks required context fields (E401-E406). This is intentional - use to_v0_2()
        for validated certificates.
        """
        result = {
            # Core 6D
            'R': self.R,
            'S': self.S,
            'N': self.N,
            'alpha': self.alpha,
            'omega': self.omega,
            'tau': self.tau,
            # Derived helpers (basic)
            'alpha_omega': self.alpha_omega,
            'quality_score': self.quality_score,
            'uncertainty': self.uncertainty,
            'health_score': self.health_score,
            # Derived helpers (§7.9/§7.10/§7.11 classification)
            'degradation_type': self.degradation_type,
            'severity_value': self.severity_value,
            'fragility_state': self.fragility_state,
            # Temporal helpers
            'n_baseline': self.n_baseline,
            'n_delta': self.n_delta,
            'n_trend': self.n_trend,
            'drift_detected': self.drift_detected,
            # Modality (Universal Rotor v2)
            'modality': self.modality,
            'feature_extractor_version': self.feature_extractor_version,
            'rotor_version': self.rotor_version,
            # Metadata
            'timestamp': self.timestamp,
            'backend': self.backend,
        }

        # Lyapunov helpers (if computed)
        if self.V is not None:
            result.update({
                'V': self.V,
                'V_dot': self.V_dot,
                'is_stable': self.is_stable,
                'is_converging': self.is_converging,
                'lyapunov_margin': self.lyapunov_margin,
                'recommended_gear': self.recommended_gear,
            })

        return result

    def to_v0_2(
        self,
        domain: str,
        inv_spec_hash: str,
        inv_spec_blob: Dict[str, Any],
        baseline_id: Optional[str] = None,
        fingerprint: Optional[bytes] = None,
        enforcement: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Export to v0.2 compliant certificate with required context fields.

        FIX 2026-01-26: Created to resolve E401-E406 validation errors.
        The internal representation (to_dict()) lacks required ISA v0.2 context fields.
        This method wraps measurements with proper v0.2 schema for ISA operations.

        Required context fields (from certificate_validator.py):
        - E401: 'context' field
        - E402: 'domain' in context
        - E403: 'inv_spec_hash' in context
        - E404: 'inv_spec_blob' in context
        - E405: 'baseline_id' in context (optional, defaults to 'none')
        - E406: 'schema_version' in context

        Args:
            domain: Certificate domain ('symbolic', 'robotics', 'adversarial', etc.)
            inv_spec_hash: SHA-256 hash of inv_spec_blob (for integrity)
            inv_spec_blob: Full invariant specification dict
            baseline_id: Optional baseline reference ID
            fingerprint: Optional T⁴ fingerprint (32 bytes), defaults to placeholder
            enforcement: Optional enforcement actions taken

        Returns:
            Dict in v0.2 schema format, passes validate_certificate()

        Example:
            >>> from yrsn.core.domain import get_domain_invariants
            >>> from yrsn.api.certificate_validator import compute_inv_spec_hash, validate_certificate
            >>>
            >>> cert = YRSNCertificate(R=0.6, S=0.3, N=0.1, alpha=0.6, omega=0.9, tau=1.2)
            >>> inv = get_domain_invariants('symbolic')
            >>> inv_blob = asdict(inv)
            >>> inv_hash = compute_inv_spec_hash(inv_blob)
            >>>
            >>> v2_cert = cert.to_v0_2(
            ...     domain='symbolic',
            ...     inv_spec_hash=inv_hash,
            ...     inv_spec_blob=inv_blob
            ... )
            >>> validate_certificate(v2_cert)  # SUCCESS - no errors

        Reference:
            - Patent Spec §7.11: Certificate Structure Requirements
            - ISA v0.2 §0: Certificate as Port
            - src/yrsn/api/isa.py:771-848 (cert_mint implementation)
            - docs/fixes/2026-01-26_certificate_integrity_validation.md
        """
        return {
            'measurements': {
                'R': self.R,
                'S': self.S,
                'N': self.N,
                'alpha': self.alpha,
                'omega': self.omega,
                'tau': self.tau,
            },
            # §7.9/§7.10/§7.11 Classification (Oracle-Free)
            'classification': {
                'degradation_type': self.degradation_type,  # §7.9, §7.11.3.1
                'severity_value': self.severity_value,      # §7.11.3.2
                'fragility_state': self.fragility_state,    # §7.10
            },
            'context': {
                'domain': domain,
                'inv_spec_hash': inv_spec_hash,
                'inv_spec_blob': inv_spec_blob,
                'baseline_id': baseline_id or 'none',
                'schema_version': CERTIFICATE_SCHEMA_VERSION,
                'timestamp': self.timestamp,
                # PKI-style governance
                'policy_id': self.policy_id,
                'expires_at': self.expires_at.isoformat() if self.expires_at else None,
                # Modality provenance (Universal Rotor v2)
                'modality': self.modality,
                'feature_extractor_version': self.feature_extractor_version,
                'rotor_version': self.rotor_version,
            },
            'fingerprint': fingerprint.hex() if fingerprint else '0' * 64,
            'enforcement': enforcement or [],
        }

    def to_cqc_mas(self, agent_id: str) -> Dict[str, Any]:
        """
        Export to CQC_MAS certificate format for multi-agent coordination.

        Created 2026-01-26 for Series 006 experiments (expS6_001, expS6_100).
        Exports 6D metrics + T⁴ toroidal coordinates for three-stage gateway validation.

        Args:
            agent_id: Identifier of the agent issuing this certificate

        Returns:
            Dict with measurements (R/S/N/alpha/omega/tau) + T⁴ coords + metadata

        Example:
            >>> cert = YRSNCertificate(R=0.7, S=0.2, N=0.1, alpha=0.8, omega=0.9, tau=1.2)
            >>> cqc_mas_cert = cert.to_cqc_mas(agent_id="agent_A")
            >>> print(cqc_mas_cert['simplex_theta'])  # T⁴ coordinate
            240.0

        Reference:
            - exp/series_006/WIRING_WALKTHROUGH.md § Step 4
            - exp/series_006/T4_COORDINATE_CLARIFICATION.md § Option 2
        """
        # Compute T⁴ toroidal coordinates
        from yrsn.core.decomposition.geometric_utils import compute_t4_coordinates

        # compute_t4_coordinates() uses SCALAR MODE here:
        # - Input: scalar floats (self.R, self.S, self.N)
        # - Output: Dict with 0-dimensional numpy arrays (wrapped scalars)
        # - Must use float() to extract, NOT indexing like [0]
        #
        # See docs/specs/t4_dual_mode_api.md for full API specification
        t4 = compute_t4_coordinates(self.R, self.S, self.N)

        return {
            # Core 6D measurements
            'R': float(self.R),
            'S': float(self.S),
            'N': float(self.N),
            'alpha': float(self.alpha),
            'omega': float(self.omega),
            'tau': float(self.tau),

            # T⁴ toroidal coordinates (4D torus)
            # IMPORTANT: float() extracts value from 0-d numpy array
            # DO NOT use [0] indexing - that causes IndexError on 0-d arrays!
            'simplex_theta': float(t4['simplex_theta']),  # WHERE on simplex [0, 360)
            'phi_simplex': float(t4['phi_simplex']),      # HOW FAR from balance [0, 360)
            'alpha_t4': float(t4['alpha_t4']),            # Quality angle [0, 180)
            'omega_t4': float(t4['omega_t4']),            # OOD angle [0, 90]

            # §7.9/§7.10/§7.11 Classification (Oracle-Free)
            'degradation_type': self.degradation_type,
            'severity_value': self.severity_value,
            'fragility_state': self.fragility_state,

            # Metadata
            'issuer': agent_id,
            'timestamp': self.timestamp if isinstance(self.timestamp, (int, float)) else 0.0,
            # Modality provenance (Universal Rotor v2)
            'modality': self.modality,
            'feature_extractor_version': self.feature_extractor_version,
            'rotor_version': self.rotor_version,
        }

    def verify_lyapunov(self) -> Dict[str, Any]:
        """
        Verify Lyapunov stability conditions.

        Returns a verification report with:
        - satisfied: True if all Lyapunov conditions hold
        - conditions: Dict of individual condition results
        - recommendation: Action to take if unstable

        Lyapunov Conditions:
        1. V ≥ 0 (positive semi-definite)
        2. V = 0 at baseline (zero at equilibrium)
        3. V̇ ≤ 0 (non-increasing along trajectories)
        4. V < 1.5 (within operational envelope)
        """
        if self.V is None:
            return {
                'satisfied': None,
                'conditions': {},
                'recommendation': 'Provide T⁴ coordinates to enable Lyapunov verification',
            }

        conditions = {
            'positive_definite': self.V >= 0,
            'within_envelope': self.V < 1.5,
            'non_increasing': self.V_dot is None or self.V_dot <= 0,
            'margin_positive': self.lyapunov_margin is not None and self.lyapunov_margin > 0,
        }

        satisfied = all(conditions.values())

        if satisfied:
            recommendation = f"System stable. Continue in {self.recommended_gear} gear."
        elif not conditions['within_envelope']:
            recommendation = "COLLAPSE RISK: Shift to REVERSE for emergency recovery."
        elif not conditions['non_increasing']:
            recommendation = f"V increasing (V̇={self.V_dot:.4f}). Downshift to {self.recommended_gear}."
        else:
            recommendation = f"Check system. Recommended gear: {self.recommended_gear}"

        return {
            'satisfied': satisfied,
            'conditions': conditions,
            'V': self.V,
            'V_dot': self.V_dot,
            'lyapunov_margin': self.lyapunov_margin,
            'recommendation': recommendation,
        }

    def with_t4(
        self,
        t4_coords: np.ndarray,
        t4_baseline: np.ndarray,
        V_prev: Optional[float] = None,
    ) -> 'YRSNCertificate':
        """
        Create new certificate with T⁴ coordinates (enables Lyapunov helpers).

        This is the factory method for adding Lyapunov stability analysis
        to an existing certificate.

        Args:
            t4_coords: Current T⁴ coordinates [θ, φ, α_t4, ω_t4] in degrees
            t4_baseline: Baseline T⁴ coordinates [θ, φ, α_t4, ω_t4] in degrees
            V_prev: Previous Lyapunov value (for V̇ estimation)

        Returns:
            New YRSNCertificate with Lyapunov helpers computed

        Example:
            cert = YRSNCertificate.from_rsn_dict(rsn_result)
            cert_with_lyap = cert.with_t4(current_t4, baseline_t4, prev_V)

            if cert_with_lyap.is_stable:
                print(f"System stable, V={cert_with_lyap.V:.4f}")
            else:
                print(f"Instability detected, V̇={cert_with_lyap.V_dot:.4f}")
        """
        return YRSNCertificate(
            # Core 6D
            R=self.R,
            S=self.S,
            N=self.N,
            alpha=self.alpha,
            omega=self.omega,
            tau=self.tau,
            # Temporal
            n_baseline=self.n_baseline,
            # Lyapunov
            t4_coords=np.asarray(t4_coords),
            t4_baseline=np.asarray(t4_baseline),
            V_prev=V_prev,
            # Metadata
            backend=self.backend,
        )

    @classmethod
    def from_rsn_dict(
        cls,
        rsn: Dict[str, Any],
        n_baseline: Optional[float] = None,
        t4_coords: Optional[np.ndarray] = None,
        t4_baseline: Optional[np.ndarray] = None,
        modality: Optional[str] = None,
        feature_extractor_version: Optional[str] = None,
        rotor_version: Optional[str] = None,
    ) -> 'YRSNCertificate':
        """
        Create certificate from RSN computation result.

        Args:
            rsn: Dict with R, S, N, alpha, omega, tau from compute_rsn()
            n_baseline: Optional baseline N for temporal helpers
            t4_coords: Optional current T⁴ coordinates for Lyapunov helpers
            t4_baseline: Optional baseline T⁴ coordinates for Lyapunov helpers
            modality: Optional modality identifier ('text', 'vision', 'audio')
            feature_extractor_version: Optional feature extractor checkpoint name
            rotor_version: Optional rotor checkpoint name
        """
        return cls(
            R=float(rsn['R']),
            S=float(rsn['S']),
            N=float(rsn['N']),
            alpha=float(rsn['alpha']),
            omega=float(rsn.get('omega', 1.0)),
            tau=float(rsn.get('tau', 1.0)),
            n_baseline=n_baseline,
            t4_coords=np.asarray(t4_coords) if t4_coords is not None else None,
            t4_baseline=np.asarray(t4_baseline) if t4_baseline is not None else None,
            modality=modality,
            feature_extractor_version=feature_extractor_version,
            rotor_version=rotor_version,
            backend=rsn.get('backend', 'unknown'),
        )


# =============================================================================
# CERTIFICATE BATCH (Oracle-Free)
# =============================================================================
# YRSNCertificateBatch is PURELY oracle-free. It aggregates certificate
# statistics without requiring ground truth labels.
#
# To validate a batch against ground truth (research only), use the
# standalone function validate_batch_with_oracle() defined below.
# =============================================================================

@dataclass
class YRSNCertificateBatch:
    """
    Batch of certificates with aggregate statistics.

    All helpers remain oracle-free.
    """
    certificates: List[YRSNCertificate]

    # Aggregate statistics (oracle-free)
    mean_R: float = 0.0
    mean_S: float = 0.0
    mean_N: float = 0.0
    mean_alpha: float = 0.0
    mean_health_score: float = 0.0
    mean_severity: float = 0.0  # §7.11.3.2 aggregate severity

    std_N: float = 0.0
    std_alpha: float = 0.0

    def __post_init__(self):
        if self.certificates:
            self.mean_R = np.mean([c.R for c in self.certificates])
            self.mean_S = np.mean([c.S for c in self.certificates])
            self.mean_N = np.mean([c.N for c in self.certificates])
            self.mean_alpha = np.mean([c.alpha for c in self.certificates])
            self.mean_health_score = np.mean([c.health_score for c in self.certificates])
            self.mean_severity = np.mean([c.severity_value for c in self.certificates if c.severity_value is not None])
            self.std_N = np.std([c.N for c in self.certificates])
            self.std_alpha = np.std([c.alpha for c in self.certificates])

    def get_unhealthy_fraction(self, n_threshold: float = 0.2) -> float:
        """Fraction of certificates indicating unhealthy hardware."""
        unhealthy = sum(1 for c in self.certificates if c.N > n_threshold)
        return unhealthy / len(self.certificates) if self.certificates else 0.0


def create_certificate_from_batch(
    rsn_batch: Dict[str, np.ndarray],
    n_baseline: Optional[float] = None,
) -> YRSNCertificate:
    """
    Create single certificate from batch RSN results (using means).
    """
    return YRSNCertificate(
        R=float(np.mean(rsn_batch['R'])),
        S=float(np.mean(rsn_batch['S'])),
        N=float(np.mean(rsn_batch['N'])),
        alpha=float(np.mean(rsn_batch['alpha'])),
        omega=float(np.mean(rsn_batch.get('omega', np.ones_like(rsn_batch['R'])))),
        tau=float(np.mean(rsn_batch['tau'])),
        n_baseline=n_baseline,
    )


# =============================================================================
#
#                    ⚠️  ORACLE-REQUIRED SECTION BELOW  ⚠️
#
# Everything below this line REQUIRES ground truth labels and should ONLY
# be used for research, validation, and offline analysis.
#
# DO NOT use in production - labels are not available at inference time.
#
# =============================================================================


# =============================================================================
# ORACLE VALIDATION (Requires Ground Truth - Research/Offline Only)
# =============================================================================

@dataclass
class OracleValidation:
    """
    Validation metrics that REQUIRE ground truth labels.

    These are NOT part of the certificate. They are for:
    - Research and experimentation
    - Offline validation
    - Model development

    In production, you typically don't have ground truth.
    The certificate must work WITHOUT these metrics.

    STATISTICAL NOTE:
        YRSN operates on a simplex (R + S + N = 1). Traditional threshold-based
        classification metrics (F1, precision/recall at optimized threshold) are
        inappropriate because:
        1. Threshold optimization on evaluation data causes data leakage
        2. Simplex geometry means we should measure correlation/separation, not
           binary classification at arbitrary cutoffs

        We use threshold-FREE metrics:
        - Spearman correlation: Does N rank errors correctly?
        - Centroid separation: Are errors/non-errors geometrically separated?
        - ROC-AUC / PR-AUC: Threshold-free ranking quality

        See: docs/SIMPLEX_VALIDATION.md for full statistical justification.

    Usage:
        validation = OracleValidation.compute(
            R=rsn['R'], S=rsn['S'], N=rsn['N'],
            is_error=ground_truth_labels,
        )
        print(f"N-error correlation: {validation.n_error_correlation}")
        print(f"Centroid separation: {validation.centroid_separation}")
    """

    # Simplex-aware metrics (threshold-free)
    n_error_correlation: Optional[float] = None  # Spearman(N, is_error)
    alpha_error_correlation: Optional[float] = None  # Spearman(alpha, is_error) - should be negative
    centroid_separation: Optional[float] = None  # L2 distance between error/non-error centroids in RSN

    # Centroid positions (for visualization)
    error_centroid: Optional[Dict[str, float]] = None  # Mean R, S, N for errors
    nonerror_centroid: Optional[Dict[str, float]] = None  # Mean R, S, N for non-errors

    # Ranking metrics (threshold-free)
    roc_auc: Optional[float] = None  # ROC Area Under Curve
    pr_auc: Optional[float] = None  # Precision-Recall AUC

    # Confusion matrix diagnostics (threshold-based, for debugging only)
    mcc: Optional[float] = None  # Matthews Correlation Coefficient [-1, 1]
    confusion_matrix: Optional[Dict[str, int]] = None  # {'TP': n, 'FP': n, 'TN': n, 'FN': n}
    threshold_used: Optional[float] = None  # N threshold for binary classification

    # Metadata
    n_samples: int = 0
    n_errors: int = 0
    error_rate: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    @classmethod
    def compute(
        cls,
        R: np.ndarray,
        S: np.ndarray,
        N: np.ndarray,
        is_error: np.ndarray,
        alpha: Optional[np.ndarray] = None,
    ) -> 'OracleValidation':
        """
        Compute simplex-aware validation metrics from RSN and ground truth.

        REQUIRES GROUND TRUTH - Not for production use.

        Args:
            R: Relevant component [0,1]
            S: Superfluous component [0,1]
            N: Noise component [0,1] - should correlate with errors
            is_error: Ground truth error labels
            alpha: Optional quality score (if not provided, uses 1-N)
        """
        from scipy.stats import spearmanr

        is_error = np.asarray(is_error).astype(bool)
        R = np.asarray(R)
        S = np.asarray(S)
        N = np.asarray(N)

        if alpha is None:
            alpha = 1.0 - N  # Default: alpha inversely related to noise

        # Spearman correlations (threshold-free)
        n_corr, _ = spearmanr(N, is_error.astype(float))
        alpha_corr, _ = spearmanr(alpha, is_error.astype(float))

        # Centroid separation in RSN simplex
        error_mask = is_error
        nonerror_mask = ~is_error

        if np.sum(error_mask) > 0 and np.sum(nonerror_mask) > 0:
            error_centroid = {
                'R': float(np.mean(R[error_mask])),
                'S': float(np.mean(S[error_mask])),
                'N': float(np.mean(N[error_mask])),
            }
            nonerror_centroid = {
                'R': float(np.mean(R[nonerror_mask])),
                'S': float(np.mean(S[nonerror_mask])),
                'N': float(np.mean(N[nonerror_mask])),
            }

            # L2 distance between centroids
            separation = np.sqrt(
                (error_centroid['R'] - nonerror_centroid['R'])**2 +
                (error_centroid['S'] - nonerror_centroid['S'])**2 +
                (error_centroid['N'] - nonerror_centroid['N'])**2
            )
        else:
            error_centroid = None
            nonerror_centroid = None
            separation = None

        # AUC metrics (threshold-free ranking)
        roc_auc, pr_auc = None, None
        if int(np.sum(is_error)) >= 2:
            try:
                from sklearn.metrics import roc_auc_score, average_precision_score
                # N should be HIGH for errors, so use N directly
                roc_auc = float(roc_auc_score(is_error.astype(int), N))
                pr_auc = float(average_precision_score(is_error.astype(int), N))
            except ImportError:
                pass

        # Confusion matrix + MCC (threshold-based, for diagnostics)
        mcc, cm, threshold = None, None, None
        if error_centroid is not None and nonerror_centroid is not None:
            # Use midpoint between centroids as threshold
            threshold = (error_centroid['N'] + nonerror_centroid['N']) / 2.0
            predicted_error = N >= threshold

            tp = int(np.sum(predicted_error & is_error))
            fp = int(np.sum(predicted_error & ~is_error))
            tn = int(np.sum(~predicted_error & ~is_error))
            fn = int(np.sum(~predicted_error & is_error))

            cm = {'TP': tp, 'FP': fp, 'TN': tn, 'FN': fn}

            # MCC = (TP*TN - FP*FN) / sqrt((TP+FP)(TP+FN)(TN+FP)(TN+FN))
            denom = np.sqrt((tp+fp) * (tp+fn) * (tn+fp) * (tn+fn))
            if denom > 0:
                mcc = float((tp * tn - fp * fn) / denom)
            else:
                mcc = 0.0

        return cls(
            n_error_correlation=float(n_corr) if not np.isnan(n_corr) else None,
            alpha_error_correlation=float(alpha_corr) if not np.isnan(alpha_corr) else None,
            centroid_separation=float(separation) if separation is not None else None,
            error_centroid=error_centroid,
            nonerror_centroid=nonerror_centroid,
            roc_auc=roc_auc,
            pr_auc=pr_auc,
            mcc=mcc,
            confusion_matrix=cm,
            threshold_used=threshold,
            n_samples=len(N),
            n_errors=int(np.sum(is_error)),
            error_rate=float(np.mean(is_error)),
        )


# =============================================================================
# CONFUSION MATRIX UTILITIES (Oracle-Required)
# =============================================================================
# These utilities operate on confusion matrices from OracleValidation.
# They derive additional metrics (F1, Jaccard, etc.) on-demand.
# =============================================================================

def derive_metrics_from_confusion_matrix(cm: Dict[str, int]) -> Dict[str, float]:
    """
    Derive additional classification metrics from confusion matrix.

    Use this when you need F1, Jaccard, precision, recall, etc.
    These are derived on-demand rather than stored.

    Args:
        cm: Confusion matrix dict with 'TP', 'FP', 'TN', 'FN' keys

    Returns:
        Dict with derived metrics: precision, recall, f1, jaccard, accuracy, specificity
    """
    tp, fp, tn, fn = cm['TP'], cm['FP'], cm['TN'], cm['FN']
    total = tp + fp + tn + fn

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    accuracy = (tp + tn) / total if total > 0 else 0.0

    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    jaccard = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0.0

    return {
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'jaccard': jaccard,
        'accuracy': accuracy,
        'specificity': specificity,
    }


def validate_batch_with_oracle(
    batch: YRSNCertificateBatch,
    is_error: np.ndarray,
) -> OracleValidation:
    """
    Compute OracleValidation from a certificate batch + ground truth labels.

    This is a standalone function (not a method) to keep YRSNCertificateBatch
    purely oracle-free.

    Args:
        batch: YRSNCertificateBatch with certificates
        is_error: Ground truth error labels (same length as certificates)

    Returns:
        OracleValidation with all metrics including mcc and confusion_matrix

    Example:
        batch = YRSNCertificateBatch(certificates=[cert1, cert2, ...])
        validation = validate_batch_with_oracle(batch, is_error_labels)
        print(f"MCC: {validation.mcc}")

        # Derive additional metrics if needed
        if validation.confusion_matrix:
            extras = derive_metrics_from_confusion_matrix(validation.confusion_matrix)
            print(f"F1: {extras['f1']}")
    """
    if not batch.certificates:
        raise ValueError("No certificates in batch")

    R = np.array([c.R for c in batch.certificates])
    S = np.array([c.S for c in batch.certificates])
    N = np.array([c.N for c in batch.certificates])
    alpha = np.array([c.alpha for c in batch.certificates])

    return OracleValidation.compute(
        R=R, S=S, N=N,
        is_error=is_error,
        alpha=alpha,
    )


