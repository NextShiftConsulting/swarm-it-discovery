"""
💼 LICENSED CORE LOGIC - CQC_MAS Metrics

Multi-Agent Coordination Quality Metrics
Customers MUST LICENSE this code from YRSN. Cannot be reimplemented.

What you CAN do:
✅ Import and call these functions
✅ Pass coordination data to compute metrics
✅ Get CER, NAF, CAAS scores back

What you CANNOT do:
❌ Copy or reimplement these metrics
❌ Reverse engineer the algorithms
❌ Modify without permission

Simple explanation:
    These metrics measure multi-agent coordination quality:
    - CER (Coordination Efficiency Ratio): Does cooperation help or hurt?
    - NAF (Noise Amplification Factor): How noise scales with agents
    - CAAS (Cross-Agent Alignment Score): Are agents aligned?

Based on:
    CooperBench failure taxonomy (arxiv 2601.13295v1) mapped to
    YRSN signal certificate framework.

---

YRSN Metrics Module: CooperBench-Informed Calculations
======================================================

Metrics derived from CooperBench failure taxonomy analysis.
These metrics are theoretically derived and can be used immediately.
Empirical calibration with CooperBench traces would improve accuracy.

Author: Next Shift Consulting LLC
Date: January 2026
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from scipy.stats import entropy
import time


# =============================================================================
# THRESHOLD CONFIGURATION
# =============================================================================

@dataclass
class YRSNThresholds:
    """
    Threshold configuration derived from CooperBench failure rates.
    
    Source derivation:
    - tau_R: From ~20% unresponsiveness failure rate
    - tau_S: From ~25% repetition failure rate  
    - tau_N: From ~55% combined hallucination+incorrectness rate
    - tau_align: From ~33% incorrect expectation rate
    - tau_fulfill: Commitment fulfillment standard
    """
    tau_R: float = 0.60        # Minimum R-density required
    tau_S: float = 0.20        # Maximum S-ratio allowed
    tau_N: float = 0.15        # Maximum N-ratio allowed (strict)
    tau_align: float = 0.67    # Minimum cross-agent alignment
    tau_fulfill: float = 0.80  # Commitment fulfillment threshold
    
    @classmethod
    def from_failure_rates(cls, 
                           unresponsiveness: float = 0.20,
                           repetition: float = 0.25,
                           hallucination: float = 0.25,
                           incorrectness: float = 0.30,
                           expectation_failure: float = 0.33,
                           safety_margin: float = 0.95):
        """
        Derive thresholds from empirical failure rates.
        """
        # tau_R: Prevent R-insufficiency
        tau_R = 1 - (unresponsiveness * (1 - safety_margin))
        tau_R = min(0.80, max(0.50, tau_R))  # Bound to reasonable range
        
        # tau_S: Limit superfluous overhead
        tau_S = repetition  # Direct mapping
        
        # tau_N: Combined noise threshold
        combined_noise = hallucination + incorrectness
        tau_N = (1 - combined_noise) * (1 - safety_margin)
        tau_N = min(0.25, max(0.10, tau_N))  # Strict bounds
        
        # tau_align: Cross-agent alignment
        tau_align = 1 - expectation_failure
        
        return cls(
            tau_R=round(tau_R, 2),
            tau_S=round(tau_S, 2),
            tau_N=round(tau_N, 2),
            tau_align=round(tau_align, 2)
        )


# Default thresholds
DEFAULT_THRESHOLDS = YRSNThresholds()


# =============================================================================
# CORE METRICS
# =============================================================================

def coordination_efficiency_ratio(success_coop: float, success_solo: float) -> float:
    """
    CER = Success_coop / Success_solo
    
    CooperBench baseline: CER ≈ 0.5 (cooperation halves performance)
    YRSN target: CER > 1.0 (cooperation improves performance)
    
    Args:
        success_coop: Success rate with multi-agent cooperation
        success_solo: Success rate with single agent
        
    Returns:
        CER ratio (>1 means cooperation helps, <1 means it hurts)
    """
    if success_solo == 0:
        return float('inf') if success_coop > 0 else 0.0
    return success_coop / success_solo


def predicted_CER(n_agents: int, cert_effectiveness: float) -> float:
    """
    Predict CER improvement from certificate gating.
    
    Args:
        n_agents: Number of cooperating agents
        cert_effectiveness: Fraction of noise successfully filtered (0 to 1)
        
    Returns:
        Predicted CER improvement factor
    """
    if n_agents < 2:
        return 1.0
    
    # Without certificates: noise scales linearly
    noise_factor_uncertified = n_agents
    
    # With certificates: noise is bounded by leakage
    noise_factor_certified = 1 + (1 - cert_effectiveness) * (n_agents - 1)
    
    return noise_factor_uncertified / noise_factor_certified


def noise_amplification_factor(n_agents: int, 
                                certificate_gating: bool = False,
                                cert_N_rejection_rate: float = 0.0) -> float:
    """
    NAF: Quantifies how noise scales in multi-agent systems.
    
    Without certificates: NAF = n (linear accumulation)
    With certificates: NAF ≈ 1 + (1 - rejection_rate) * (n - 1)
    
    Args:
        n_agents: Number of agents
        certificate_gating: Whether certificates are used
        cert_N_rejection_rate: Fraction of noise rejected by certificates
        
    Returns:
        Noise amplification factor (lower is better)
    """
    if n_agents < 1:
        return 0.0
    
    if not certificate_gating:
        return float(n_agents)
    
    leaked_noise_per_agent = 1 - cert_N_rejection_rate
    return 1 + leaked_noise_per_agent * (n_agents - 1)


def cross_agent_alignment_score(R_vector_a: np.ndarray, 
                                 R_vector_b: np.ndarray) -> float:
    """
    CAAS: Measures whether two agents share understanding of relevant signal.
    
    CooperBench's "incorrect expectations" failures = low CAAS.
    
    Args:
        R_vector_a: Relevance vector from agent A
        R_vector_b: Relevance vector from agent B
        
    Returns:
        Alignment score (0 to 1, higher is better)
    """
    R_vector_a = np.asarray(R_vector_a, dtype=float)
    R_vector_b = np.asarray(R_vector_b, dtype=float)
    
    dot_product = np.dot(R_vector_a, R_vector_b)
    norm_a = np.linalg.norm(R_vector_a)
    norm_b = np.linalg.norm(R_vector_b)
    
    if norm_a == 0 or norm_b == 0:
        return 0.0
    
    return float(dot_product / (norm_a * norm_b))


# =============================================================================
# SIGNAL CERTIFICATE
# =============================================================================

@dataclass
class SignalCertificate:
    """
    YRSN Signal Certificate for gated communication.
    """
    R_component: np.ndarray
    S_component: np.ndarray
    N_component: np.ndarray
    timestamp: float = field(default_factory=time.time)
    issuer: str = ""
    
    @property
    def R_density(self) -> float:
        """Fraction of signal that is relevant."""
        total = self.R_magnitude + self.S_magnitude + self.N_magnitude
        return self.R_magnitude / total if total > 0 else 0.0
    
    @property
    def S_ratio(self) -> float:
        """Fraction of signal that is superfluous."""
        total = self.R_magnitude + self.S_magnitude + self.N_magnitude
        return self.S_magnitude / total if total > 0 else 0.0
    
    @property
    def N_ratio(self) -> float:
        """Fraction of signal that is noise."""
        total = self.R_magnitude + self.S_magnitude + self.N_magnitude
        return self.N_magnitude / total if total > 0 else 0.0
    
    @property
    def R_magnitude(self) -> float:
        return float(np.linalg.norm(self.R_component))
    
    @property
    def S_magnitude(self) -> float:
        return float(np.linalg.norm(self.S_component))
    
    @property
    def N_magnitude(self) -> float:
        return float(np.linalg.norm(self.N_component))
    
    def is_valid(self, thresholds: YRSNThresholds = DEFAULT_THRESHOLDS) -> bool:
        """Check if certificate meets all thresholds."""
        return (
            self.R_density >= thresholds.tau_R and
            self.S_ratio <= thresholds.tau_S and
            self.N_ratio <= thresholds.tau_N
        )
    
    def validation_report(self, 
                          thresholds: YRSNThresholds = DEFAULT_THRESHOLDS) -> Dict:
        """Detailed validation breakdown."""
        return {
            'valid': self.is_valid(thresholds),
            'R_density': self.R_density,
            'R_threshold': thresholds.tau_R,
            'R_pass': self.R_density >= thresholds.tau_R,
            'S_ratio': self.S_ratio,
            'S_threshold': thresholds.tau_S,
            'S_pass': self.S_ratio <= thresholds.tau_S,
            'N_ratio': self.N_ratio,
            'N_threshold': thresholds.tau_N,
            'N_pass': self.N_ratio <= thresholds.tau_N,
        }


def generate_signal_certificate(message_embedding: np.ndarray,
                                 R_projection: np.ndarray,
                                 S_projection: np.ndarray,
                                 N_projection: np.ndarray,
                                 issuer: str = "") -> SignalCertificate:
    """
    Generate a signal certificate by decomposing message into R, S, N components.
    
    Args:
        message_embedding: Vector representation of message
        R_projection: Projection matrix for relevance subspace
        S_projection: Projection matrix for superfluous subspace
        N_projection: Projection matrix for noise subspace
        issuer: Agent identifier
        
    Returns:
        SignalCertificate with decomposed components
    """
    message_embedding = np.asarray(message_embedding, dtype=float)
    
    R_component = R_projection @ message_embedding
    S_component = S_projection @ message_embedding
    N_component = N_projection @ message_embedding
    
    return SignalCertificate(
        R_component=R_component,
        S_component=S_component,
        N_component=N_component,
        issuer=issuer
    )


# =============================================================================
# COMMITMENT TRACKING
# =============================================================================

@dataclass
class CommitmentCertificate:
    """
    Certificate for tracking agent commitments.
    Addresses CooperBench's "commitment deviation" failures.
    """
    commitment_text: str
    R_component: np.ndarray
    issuer: str
    timestamp: float = field(default_factory=time.time)
    fulfilled: bool = False
    fulfillment_score: float = 0.0
    
    def verify_fulfillment(self, 
                           action_R: np.ndarray,
                           threshold: float = 0.8) -> bool:
        """
        Verify if an action fulfills this commitment.
        
        Args:
            action_R: R-component of the action taken
            threshold: Minimum overlap required
            
        Returns:
            True if commitment fulfilled
        """
        action_R = np.asarray(action_R, dtype=float)
        
        dot_product = np.dot(action_R, self.R_component)
        norm_action = np.linalg.norm(action_R)
        norm_commit = np.linalg.norm(self.R_component)
        
        if norm_action == 0 or norm_commit == 0:
            self.fulfillment_score = 0.0
            self.fulfilled = False
            return False
        
        self.fulfillment_score = dot_product / (norm_action * norm_commit)
        self.fulfilled = self.fulfillment_score >= threshold
        
        return self.fulfilled


class CommitmentTracker:
    """
    Tracks commitment fulfillment to quantify deviation rate (CCFR).
    """
    
    def __init__(self, fulfillment_threshold: float = 0.8):
        self.commitments: List[CommitmentCertificate] = []
        self.fulfillment_threshold = fulfillment_threshold
        
    def register_commitment(self, commitment: CommitmentCertificate):
        """Register a new commitment."""
        self.commitments.append(commitment)
        
    def verify_action(self, 
                      commitment_id: int,
                      action_R: np.ndarray) -> bool:
        """Verify an action against a specific commitment."""
        if commitment_id >= len(self.commitments):
            return False
        return self.commitments[commitment_id].verify_fulfillment(
            action_R, self.fulfillment_threshold
        )
    
    @property
    def fulfilled_count(self) -> int:
        return sum(1 for c in self.commitments if c.fulfilled)
    
    @property
    def violated_count(self) -> int:
        return sum(1 for c in self.commitments if not c.fulfilled and c.fulfillment_score > 0)
    
    @property
    def CCFR(self) -> float:
        """Commitment Certificate Fulfillment Rate."""
        total = self.fulfilled_count + self.violated_count
        return self.fulfilled_count / total if total > 0 else 1.0


# =============================================================================
# INFORMATION-THEORETIC METRICS
# =============================================================================

def signal_entropy(component_vector: np.ndarray) -> float:
    """
    Entropy of signal component distribution.
    Lower entropy = more concentrated/predictable signal.
    """
    component_vector = np.asarray(component_vector, dtype=float)
    p = np.abs(component_vector)
    p_sum = np.sum(p)
    
    if p_sum == 0:
        return 0.0
    
    p = p / p_sum
    return float(entropy(p + 1e-10))


def mutual_information_R(R_a: np.ndarray, R_b: np.ndarray, bins: int = 20) -> float:
    """
    I(R_a; R_b) - Mutual information between agents' relevance signals.
    
    High MI = agents have aligned understanding of what's relevant.
    CooperBench failures suggest low MI in failed coordination.
    """
    R_a = np.asarray(R_a, dtype=float).flatten()
    R_b = np.asarray(R_b, dtype=float).flatten()
    
    if len(R_a) != len(R_b):
        raise ValueError("R vectors must have same length")
    
    if len(R_a) < 2:
        return 0.0
    
    # Discretize for MI calculation
    hist_2d, _, _ = np.histogram2d(R_a, R_b, bins=bins)
    p_joint = hist_2d / (hist_2d.sum() + 1e-10)
    p_a = p_joint.sum(axis=1)
    p_b = p_joint.sum(axis=0)
    
    H_a = entropy(p_a + 1e-10)
    H_b = entropy(p_b + 1e-10)
    H_joint = entropy(p_joint.flatten() + 1e-10)
    
    return float(max(0, H_a + H_b - H_joint))


def channel_capacity_with_filtering(base_capacity: float,
                                     N_ratio: float,
                                     cert_rejection_rate: float) -> float:
    """
    Effective channel capacity after noise filtering.
    
    Shannon-inspired: C_eff = C * (1 - N_leaked)
    """
    N_leaked = N_ratio * (1 - cert_rejection_rate)
    return base_capacity * (1 - N_leaked)


# =============================================================================
# COMPOSITE HEALTH SCORE
# =============================================================================

def yrsn_coordination_health(
    R_density: float,
    S_ratio: float,
    N_ratio: float,
    alignment_score: float,
    fulfillment_rate: float,
    thresholds: YRSNThresholds = DEFAULT_THRESHOLDS,
    weights: Optional[Dict[str, float]] = None
) -> float:
    """
    Composite score for multi-agent coordination health.
    
    Range: 0 (failing) to 1 (optimal)
    
    Args:
        R_density: Relevance density (higher is better)
        S_ratio: Superfluous ratio (lower is better)
        N_ratio: Noise ratio (lower is better)
        alignment_score: Cross-agent alignment (higher is better)
        fulfillment_rate: Commitment fulfillment (higher is better)
        thresholds: YRSN threshold configuration
        weights: Custom component weights
        
    Returns:
        Health score from 0 to 1
    """
    if weights is None:
        weights = {
            'R': 0.30,      # Relevance most critical
            'S': 0.15,      # Efficiency matters
            'N': 0.25,      # Noise is dangerous
            'align': 0.20,  # Cross-agent alignment
            'commit': 0.10  # Commitment integrity
        }
    
    # Component scores (0 to 1, higher is better)
    R_score = min(R_density / thresholds.tau_R, 1.0)
    S_score = max(0, 1.0 - S_ratio / thresholds.tau_S) if thresholds.tau_S > 0 else 1.0
    N_score = max(0, 1.0 - N_ratio / thresholds.tau_N) if thresholds.tau_N > 0 else 1.0
    
    # Weighted composite
    health = (
        weights['R'] * R_score +
        weights['S'] * S_score +
        weights['N'] * N_score +
        weights['align'] * alignment_score +
        weights['commit'] * fulfillment_rate
    )
    
    return min(1.0, max(0.0, health))


# =============================================================================
# COORDINATION MONITOR
# =============================================================================

@dataclass
class MessageMetrics:
    """Metrics for a single message in multi-agent communication."""
    timestamp: float
    sender: str
    receiver: str
    R_density: float
    S_ratio: float
    N_ratio: float
    certificate_valid: bool
    alignment_with_prior: Optional[float] = None


class YRSNCoordinationMonitor:
    """
    Real-time monitoring for multi-agent coordination systems.
    """
    
    def __init__(self, 
                 thresholds: YRSNThresholds = DEFAULT_THRESHOLDS,
                 decomposer=None):
        self.thresholds = thresholds
        self.decomposer = decomposer  # Plug in actual decomposition model
        self.metrics_history: List[MessageMetrics] = []
        self.alerts: List[Dict] = []
        self.agent_R_history: Dict[str, List[np.ndarray]] = {}
        
    def process_message(self, 
                        sender: str,
                        receiver: str,
                        certificate: SignalCertificate) -> MessageMetrics:
        """
        Process a message and record metrics.
        """
        # Calculate alignment with sender's prior messages
        alignment = None
        if sender in self.agent_R_history and len(self.agent_R_history[sender]) > 0:
            prior_R = self.agent_R_history[sender][-1]
            alignment = cross_agent_alignment_score(prior_R, certificate.R_component)
        
        # Track R-history for alignment calculations
        if sender not in self.agent_R_history:
            self.agent_R_history[sender] = []
        self.agent_R_history[sender].append(certificate.R_component)
        
        metrics = MessageMetrics(
            timestamp=time.time(),
            sender=sender,
            receiver=receiver,
            R_density=certificate.R_density,
            S_ratio=certificate.S_ratio,
            N_ratio=certificate.N_ratio,
            certificate_valid=certificate.is_valid(self.thresholds),
            alignment_with_prior=alignment
        )
        
        self.metrics_history.append(metrics)
        
        # Generate alerts
        if certificate.N_ratio > self.thresholds.tau_N:
            self._alert('NOISE_THRESHOLD', sender, receiver, certificate.N_ratio)
        
        if certificate.R_density < self.thresholds.tau_R:
            self._alert('R_INSUFFICIENCY', sender, receiver, certificate.R_density)
            
        if certificate.S_ratio > self.thresholds.tau_S:
            self._alert('S_OVERFLOW', sender, receiver, certificate.S_ratio)
            
        return metrics
    
    def _alert(self, alert_type: str, sender: str, receiver: str, value: float):
        """Record an alert."""
        self.alerts.append({
            'timestamp': time.time(),
            'type': alert_type,
            'sender': sender,
            'receiver': receiver,
            'value': value
        })
    
    def get_coordination_health(self) -> float:
        """Calculate overall coordination health from history."""
        if not self.metrics_history:
            return 1.0
        
        recent = self.metrics_history[-10:]  # Last 10 messages
        
        avg_R = np.mean([m.R_density for m in recent])
        avg_S = np.mean([m.S_ratio for m in recent])
        avg_N = np.mean([m.N_ratio for m in recent])
        
        alignments = [m.alignment_with_prior for m in recent if m.alignment_with_prior is not None]
        avg_align = np.mean(alignments) if alignments else 0.5
        
        valid_rate = sum(1 for m in recent if m.certificate_valid) / len(recent)
        
        return yrsn_coordination_health(
            avg_R, avg_S, avg_N, avg_align, valid_rate, self.thresholds
        )
    
    def summary(self) -> Dict:
        """Generate monitoring summary."""
        if not self.metrics_history:
            return {'status': 'no_data'}
        
        return {
            'total_messages': len(self.metrics_history),
            'total_alerts': len(self.alerts),
            'alert_breakdown': {
                'noise': sum(1 for a in self.alerts if a['type'] == 'NOISE_THRESHOLD'),
                'r_insufficiency': sum(1 for a in self.alerts if a['type'] == 'R_INSUFFICIENCY'),
                's_overflow': sum(1 for a in self.alerts if a['type'] == 'S_OVERFLOW'),
            },
            'valid_certificate_rate': sum(1 for m in self.metrics_history if m.certificate_valid) / len(self.metrics_history),
            'coordination_health': self.get_coordination_health(),
            'avg_metrics': {
                'R_density': np.mean([m.R_density for m in self.metrics_history]),
                'S_ratio': np.mean([m.S_ratio for m in self.metrics_history]),
                'N_ratio': np.mean([m.N_ratio for m in self.metrics_history]),
            }
        }


# =============================================================================
# COOPERBENCH MAPPING UTILITIES
# =============================================================================

def map_cooperbench_symptom_to_yrsn(symptom: str) -> Dict[str, str]:
    """
    Map CooperBench failure symptom to YRSN component diagnosis.
    """
    mapping = {
        'repetition': {
            'yrsn_component': 'S (Superfluous)',
            'diagnosis': 'High S-ratio consuming budget without contribution',
            'remediation': 'Apply S-bounded certificate gating'
        },
        'unresponsiveness': {
            'yrsn_component': 'R (Relevant)',
            'diagnosis': 'R-insufficiency breaking feedback loop',
            'remediation': 'Enforce tau_R minimum threshold'
        },
        'incorrectness': {
            'yrsn_component': 'N masquerading as R',
            'diagnosis': 'Noise classified as relevant signal',
            'remediation': 'Improve N-detection in decomposition'
        },
        'hallucination': {
            'yrsn_component': 'N (Noise)',
            'diagnosis': 'Pure noise injection corrupting shared state',
            'remediation': 'Strict tau_N rejection threshold'
        }
    }
    
    return mapping.get(symptom.lower(), {
        'yrsn_component': 'Unknown',
        'diagnosis': 'Symptom not in mapping',
        'remediation': 'Manual analysis required'
    })


def estimate_threshold_improvement(
    baseline_failure_rate: float,
    symptom_distribution: Dict[str, float],
    cert_effectiveness: float
) -> Dict[str, float]:
    """
    Estimate improvement from certificate gating based on symptom distribution.
    
    Args:
        baseline_failure_rate: Overall failure rate without certificates
        symptom_distribution: Dict mapping symptoms to their fraction of failures
        cert_effectiveness: How well certificates filter each component
        
    Returns:
        Estimated metrics after certificate gating
    """
    # Calculate which failures would be prevented
    preventable = 0.0
    
    for symptom, fraction in symptom_distribution.items():
        if symptom in ['repetition', 'unresponsiveness', 'incorrectness', 'hallucination']:
            preventable += fraction * cert_effectiveness
    
    new_failure_rate = baseline_failure_rate * (1 - preventable)
    
    return {
        'baseline_failure_rate': baseline_failure_rate,
        'predicted_failure_rate': new_failure_rate,
        'improvement_factor': baseline_failure_rate / new_failure_rate if new_failure_rate > 0 else float('inf'),
        'preventable_fraction': preventable
    }


# =============================================================================
# EXAMPLE USAGE
# =============================================================================

if __name__ == "__main__":
    # Example: Calculate metrics from CooperBench-style data
    
    print("=" * 60)
    print("YRSN Metrics - CooperBench Informed")
    print("=" * 60)
    
    # 1. Derive thresholds from CooperBench failure rates
    thresholds = YRSNThresholds.from_failure_rates(
        unresponsiveness=0.20,
        repetition=0.25,
        hallucination=0.25,
        incorrectness=0.30,
        expectation_failure=0.33
    )
    print(f"\nDerived Thresholds:")
    print(f"  tau_R (min relevance):  {thresholds.tau_R}")
    print(f"  tau_S (max superfluous): {thresholds.tau_S}")
    print(f"  tau_N (max noise):       {thresholds.tau_N}")
    print(f"  tau_align (min alignment): {thresholds.tau_align}")
    
    # 2. Coordination Efficiency Ratio
    print(f"\nCoordination Efficiency Ratio (CER):")
    cer_baseline = coordination_efficiency_ratio(0.25, 0.50)
    print(f"  CooperBench baseline: {cer_baseline:.2f} (cooperation halves performance)")
    
    cer_predicted = predicted_CER(n_agents=2, cert_effectiveness=0.9)
    print(f"  YRSN predicted (90% cert effectiveness): {cer_predicted:.2f}x improvement")
    
    # 3. Noise Amplification Factor
    print(f"\nNoise Amplification Factor (NAF):")
    naf_no_cert = noise_amplification_factor(2, certificate_gating=False)
    naf_with_cert = noise_amplification_factor(2, certificate_gating=True, cert_N_rejection_rate=0.9)
    print(f"  Without certificates: {naf_no_cert:.1f}")
    print(f"  With 90% N-rejection: {naf_with_cert:.2f}")
    
    # 4. Estimate improvement
    print(f"\nEstimated Improvement from Certificate Gating:")
    improvement = estimate_threshold_improvement(
        baseline_failure_rate=0.75,  # 25% success = 75% failure
        symptom_distribution={
            'repetition': 0.25,
            'unresponsiveness': 0.20,
            'incorrectness': 0.30,
            'hallucination': 0.25
        },
        cert_effectiveness=0.85
    )
    print(f"  Baseline failure rate: {improvement['baseline_failure_rate']:.0%}")
    print(f"  Predicted failure rate: {improvement['predicted_failure_rate']:.1%}")
    print(f"  Improvement factor: {improvement['improvement_factor']:.2f}x")
    
    # 5. Example certificate validation
    print(f"\nExample Certificate Validation:")
    cert = SignalCertificate(
        R_component=np.array([0.8, 0.6, 0.5]),
        S_component=np.array([0.1, 0.1, 0.05]),
        N_component=np.array([0.05, 0.02, 0.03]),
        issuer="Agent_A"
    )
    report = cert.validation_report(thresholds)
    print(f"  R_density: {report['R_density']:.2%} (threshold: {report['R_threshold']:.0%}) {'✓' if report['R_pass'] else '✗'}")
    print(f"  S_ratio:   {report['S_ratio']:.2%} (threshold: {report['S_threshold']:.0%}) {'✓' if report['S_pass'] else '✗'}")
    print(f"  N_ratio:   {report['N_ratio']:.2%} (threshold: {report['N_threshold']:.0%}) {'✓' if report['N_pass'] else '✗'}")
    print(f"  Valid: {report['valid']}")
    
    # 6. Health score
    print(f"\nCoordination Health Score:")
    health = yrsn_coordination_health(
        R_density=0.75,
        S_ratio=0.15,
        N_ratio=0.10,
        alignment_score=0.82,
        fulfillment_rate=0.90,
        thresholds=thresholds
    )
    print(f"  Health: {health:.2%}")
