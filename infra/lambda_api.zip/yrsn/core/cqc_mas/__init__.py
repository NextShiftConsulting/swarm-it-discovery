"""
💼 LICENSED CORE LOGIC - CQC_MAS (Context Quality Certificate Multi-Agent Systems)

Multi-agent coordination metrics and certificate framework.
Customers MUST LICENSE this code from YRSN. Cannot be reimplemented.

What you CAN do:
✅ Import and use these metrics (call functions)
✅ Pass coordination data to compute CER, NAF, CAAS
✅ Get certificate validation results

What you CANNOT do:
❌ Copy or reimplement these metrics
❌ Reverse engineer the coordination algorithms
❌ Modify this code without permission

Simple explanation:
    This is the "coordination brain" for multi-agent systems.
    - Measures coordination efficiency (CER)
    - Detects noise amplification (NAF)
    - Validates agent alignment (CAAS)
    - Issues quality certificates for gated communication

Based on:
    CooperBench failure taxonomy mapped to YRSN signal framework.
    Implements patent claims for multi-consumer coordination.
"""

from yrsn.core.cqc_mas.metrics import (
    # Thresholds (CooperBench-derived)
    YRSNThresholds,

    # Metrics
    coordination_efficiency_ratio,
    noise_amplification_factor,
    cross_agent_alignment_score,

    # Certificate
    SignalCertificate,
    generate_signal_certificate,

    # Health/Validation
    yrsn_coordination_health,
)

# Provide convenient aliases for common metrics
compute_cer = coordination_efficiency_ratio
compute_naf = noise_amplification_factor
compute_caas = cross_agent_alignment_score

__all__ = [
    # Thresholds
    'YRSNThresholds',

    # Metrics (full names)
    'coordination_efficiency_ratio',
    'noise_amplification_factor',
    'cross_agent_alignment_score',

    # Metrics (aliases)
    'compute_cer',
    'compute_naf',
    'compute_caas',

    # Certificate
    'SignalCertificate',
    'generate_signal_certificate',

    # Health/Validation
    'yrsn_coordination_health',
]
