"""
YRSN Tool Decorator: Create quality-aware tools for any framework.

The @tool decorator wraps functions with YRSN quality measurement,
making them compatible with CrewAI, LangChain, MCP, or direct use.

This is the integration layer - works with your existing stack.
"""

from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union
import inspect


@dataclass
class YRSNTool:
    """
    A YRSN-enhanced tool that can be used directly or exported.

    Attributes:
        name: Tool name
        description: Tool description
        func: The wrapped function
        category: Tool category (quality, routing, retrieval, etc.)
        tags: Tool tags for filtering
        schema: JSON schema for parameters
    """
    name: str
    description: str
    func: Callable
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    schema: Dict[str, Any] = field(default_factory=dict)

    def __call__(self, *args, **kwargs) -> Any:
        """Execute the tool."""
        return self.func(*args, **kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "tags": self.tags,
            "schema": self.schema,
        }

    def to_openai(self) -> Dict[str, Any]:
        """Export as OpenAI function calling format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.schema,
            }
        }

    def to_anthropic(self) -> Dict[str, Any]:
        """Export as Anthropic tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.schema,
        }

    def to_mcp(self) -> Dict[str, Any]:
        """Export as MCP tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.schema,
        }


# Registry of all tools
_tool_registry: Dict[str, YRSNTool] = {}


def _generate_schema(func: Callable) -> Dict[str, Any]:
    """Generate JSON schema from function signature."""
    sig = inspect.signature(func)
    doc = inspect.getdoc(func) or ""

    properties = {}
    required = []

    # Parse docstring for parameter descriptions
    param_docs = {}
    in_args = False
    for line in doc.split("\n"):
        line = line.strip()
        if line.lower().startswith("args:"):
            in_args = True
            continue
        if line.lower().startswith("returns:"):
            in_args = False
            continue
        if in_args and ":" in line:
            parts = line.split(":", 1)
            param_name = parts[0].strip()
            param_desc = parts[1].strip() if len(parts) > 1 else ""
            param_docs[param_name] = param_desc

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue

        # Determine type
        annotation = param.annotation
        if annotation == inspect.Parameter.empty:
            json_type = "string"
        elif annotation == str:
            json_type = "string"
        elif annotation == int:
            json_type = "integer"
        elif annotation == float:
            json_type = "number"
        elif annotation == bool:
            json_type = "boolean"
        elif annotation == list or (hasattr(annotation, "__origin__") and annotation.__origin__ == list):
            json_type = "array"
        elif annotation == dict or (hasattr(annotation, "__origin__") and annotation.__origin__ == dict):
            json_type = "object"
        else:
            json_type = "string"

        prop = {"type": json_type}

        # Add description from docstring
        if name in param_docs:
            prop["description"] = param_docs[name]

        # Add default if present
        if param.default != inspect.Parameter.empty:
            prop["default"] = param.default
        else:
            required.append(name)

        properties[name] = prop

    schema = {
        "type": "object",
        "properties": properties,
    }

    if required:
        schema["required"] = required

    return schema


F = TypeVar("F", bound=Callable)


def tool(
    name: Optional[str] = None,
    description: Optional[str] = None,
    category: str = "general",
    tags: Optional[List[str]] = None,
) -> Callable[[F], YRSNTool]:
    """
    Decorator to create a YRSN tool from a function.

    The tool can be used directly, or exported to various formats
    (OpenAI, Anthropic, MCP, CrewAI, LangChain).

    Args:
        name: Tool name (defaults to function name)
        description: Tool description (defaults to docstring)
        category: Tool category for organization
        tags: Tags for filtering

    Returns:
        YRSNTool wrapper

    Example:
        @tool(category="quality", tags=["analysis"])
        def check_quality(text: str, threshold: float = 0.5) -> dict:
            '''Check text quality against threshold.

            Args:
                text: The text to check
                threshold: Minimum quality score

            Returns:
                Quality analysis result
            '''
            from yrsn_tools import compute_quality, quality_gate
            quality = compute_quality(text)
            return {
                "quality": quality,
                "passed": quality_gate(text, threshold),
            }

        # Use directly
        result = check_quality("Some text")

        # Export to OpenAI
        openai_tool = check_quality.to_openai()

        # Export to MCP
        mcp_tool = check_quality.to_mcp()
    """
    def decorator(func: F) -> YRSNTool:
        tool_name = name or func.__name__
        tool_desc = description or inspect.getdoc(func) or f"Tool: {tool_name}"

        # Extract first paragraph of docstring
        if "\n\n" in tool_desc:
            tool_desc = tool_desc.split("\n\n")[0]

        schema = _generate_schema(func)

        yrsn_tool = YRSNTool(
            name=tool_name,
            description=tool_desc,
            func=func,
            category=category,
            tags=tags or [],
            schema=schema,
        )

        # Register globally
        _tool_registry[tool_name] = yrsn_tool

        return yrsn_tool

    return decorator


def get_tool(name: str) -> Optional[YRSNTool]:
    """Get a registered tool by name."""
    return _tool_registry.get(name)


def list_tools(category: Optional[str] = None, tags: Optional[List[str]] = None) -> List[YRSNTool]:
    """List registered tools, optionally filtered by category or tags."""
    tools = list(_tool_registry.values())

    if category:
        tools = [t for t in tools if t.category == category]

    if tags:
        tools = [t for t in tools if any(tag in t.tags for tag in tags)]

    return tools


def export_all_openai() -> List[Dict[str, Any]]:
    """Export all tools in OpenAI format."""
    return [t.to_openai() for t in _tool_registry.values()]


def export_all_anthropic() -> List[Dict[str, Any]]:
    """Export all tools in Anthropic format."""
    return [t.to_anthropic() for t in _tool_registry.values()]


def export_all_mcp() -> Dict[str, Any]:
    """Export all tools as MCP manifest."""
    return {
        "name": "yrsn-tools",
        "version": "0.1.0",
        "description": "YRSN quality-aware context tools",
        "tools": [t.to_mcp() for t in _tool_registry.values()],
    }
