"""
CertificateBinder - Signs and anchors certificates.

This module provides the CertificateBinder class which creates cryptographically
bound certificates with Ed25519 and optional Dilithium (post-quantum) signatures.

Patent Reference: §7.11.4.7 (Integrity Protection)
"""

import hashlib
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .canonical import compute_payload_hash
from .bound_certificate import BoundCertificate, BlockchainAnchor

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate

# Optional: Post-quantum cryptography (ML-DSA-65 = Dilithium3, NIST FIPS 204)
try:
    from pqcrypto.sign.ml_dsa_65 import sign as dilithium_sign
    PQ_AVAILABLE = True
except ImportError:
    PQ_AVAILABLE = False


class CertificateBinder:
    """
    Signs and anchors YRSN certificates.

    Creates BoundCertificate instances with:
    - Ed25519 signature (always)
    - Dilithium signature (optional, if pqcrypto available)
    - Blockchain anchor (optional, mock by default)

    Example:
        >>> from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        >>> private_key = Ed25519PrivateKey.generate()
        >>> binder = CertificateBinder(private_key)
        >>> bound = binder.bind(cert)
        >>> assert bound.verify_ed25519(private_key.public_key())
    """

    def __init__(self, ed25519_private: Ed25519PrivateKey,
                 dilithium_keypair: Optional[tuple] = None):
        """
        Initialize binder with signing keys.

        Args:
            ed25519_private: Ed25519 private key for signing
            dilithium_keypair: Optional (public, private) tuple for Dilithium
        """
        self.ed25519_private = ed25519_private
        self.ed25519_public = ed25519_private.public_key()

        if dilithium_keypair and PQ_AVAILABLE:
            self.dilithium_public, self.dilithium_private = dilithium_keypair
        else:
            self.dilithium_public = None
            self.dilithium_private = None

    @property
    def has_pq(self) -> bool:
        """Check if post-quantum signing is available."""
        return self.dilithium_private is not None and PQ_AVAILABLE

    def bind(self, cert: 'YRSNCertificate',
             include_pq: bool = True,
             include_blockchain: bool = False) -> BoundCertificate:
        """
        Create cryptographically bound certificate.

        The payload is NOT modified. Bindings are additive proofs.

        Args:
            cert: YRSNCertificate to bind
            include_pq: Include Dilithium signature if available
            include_blockchain: Include mock blockchain anchor

        Returns:
            BoundCertificate with signatures and optional anchor
        """
        # Step 1: Compute canonical hash
        payload_hash = compute_payload_hash(cert)

        # Step 2: Ed25519 signature (always)
        sig_ed25519 = self.ed25519_private.sign(payload_hash)

        # Step 3: Dilithium signature (optional)
        sig_dilithium = None
        if include_pq and self.dilithium_private and PQ_AVAILABLE:
            sig_dilithium = dilithium_sign(self.dilithium_private, payload_hash)

        # Step 4: Blockchain anchor (optional, mock for now)
        anchor = None
        if include_blockchain:
            anchor = self._mock_blockchain_anchor(payload_hash)

        return BoundCertificate(
            payload=cert,
            payload_hash=payload_hash.hex(),
            signature_ed25519=sig_ed25519,
            signature_dilithium=sig_dilithium,
            blockchain_anchor=anchor
        )

    def _mock_blockchain_anchor(self, payload_hash: bytes) -> BlockchainAnchor:
        """
        Create mock blockchain anchor for testing.

        In production, replace with real blockchain submission:
        - Ethereum: Submit to contract or OP_RETURN equivalent
        - Bitcoin: OP_RETURN with hash
        - Polygon: Low-cost alternative

        Args:
            payload_hash: Hash to anchor

        Returns:
            Mock BlockchainAnchor
        """
        # Deterministic mock tx_hash for reproducibility
        tx_hash = hashlib.sha256(payload_hash + b"mock_tx_v1").hexdigest()

        return BlockchainAnchor(
            chain_id="mock_testnet_v1",
            tx_hash=tx_hash,
            block_number=12345678,
            block_timestamp=datetime.now(timezone.utc).isoformat(),
        )


def is_pq_available() -> bool:
    """Check if post-quantum cryptography is available."""
    return PQ_AVAILABLE
