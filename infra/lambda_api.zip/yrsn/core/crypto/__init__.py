"""
Cryptographic binding for YRSN certificates.

This module provides tamper-evident, future-proof integrity guarantees:

- **Ed25519 signatures**: Classical digital signatures (always available)
- **Dilithium signatures**: Post-quantum signatures (optional, requires pqcrypto)
- **Blockchain anchoring**: Timestamp proof via hash commitment (optional)
- **Tamper detection**: SHA-256 integrity verification
- **Zero-Knowledge Proofs**: Privacy-preserving verification on T⁴ (CIP #7)

Usage:
    >>> from yrsn.core.crypto import CertificateBinder, BoundCertificate
    >>> from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    >>>
    >>> # Generate key (in production: load from secure storage)
    >>> private_key = Ed25519PrivateKey.generate()
    >>>
    >>> # Bind certificate
    >>> binder = CertificateBinder(private_key)
    >>> bound = binder.bind(cert)
    >>>
    >>> # Verify
    >>> assert bound.verify_integrity()  # Tamper detection
    >>> assert bound.verify_ed25519(private_key.public_key())  # Authenticity

Zero-Knowledge Proofs (CIP #7):
    >>> from yrsn.core.crypto.zk import ZKProver, ProofSystem
    >>>
    >>> # Create post-quantum prover
    >>> prover = ZKProver.create(system=ProofSystem.STARK)
    >>>
    >>> # Prove quality threshold without revealing actual value
    >>> proof = prover.prove_quality_threshold(cert, threshold=0.7)
    >>> assert proof.is_post_quantum  # STARK provides quantum resistance

Patent Reference:
- §7.11.4.7 (Integrity Protection)
- CIP #7 (Zero-Knowledge Proofs on T⁴)
"""

from .canonical import canonical_serialize, compute_payload_hash
from .bound_certificate import BoundCertificate, BlockchainAnchor
from .binder import CertificateBinder, is_pq_available

__all__ = [
    # Canonical serialization
    'canonical_serialize',
    'compute_payload_hash',

    # Bound certificate
    'BoundCertificate',
    'BlockchainAnchor',

    # Binder
    'CertificateBinder',
    'is_pq_available',
]
