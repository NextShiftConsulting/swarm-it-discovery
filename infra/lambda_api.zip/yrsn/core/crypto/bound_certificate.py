"""
BoundCertificate - Certificate with cryptographic bindings.

This module provides the BoundCertificate class which wraps a YRSNCertificate
with cryptographic proofs (signatures, timestamps) for integrity and authenticity.

Design Principles:
- Payload is IMMUTABLE after creation
- Bindings are ADDITIVE proofs (never modify payload)
- All bindings reference the same canonical payload hash

Patent Reference: §7.11.4.7 (Integrity Protection)
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, TYPE_CHECKING

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .canonical import compute_payload_hash


@dataclass
class BlockchainAnchor:
    """
    Proof of existence on a blockchain.

    Proves the certificate hash existed NO LATER THAN the block timestamp.
    """
    chain_id: str           # e.g., "ethereum", "bitcoin", "polygon"
    tx_hash: str            # Transaction hash (proof of inclusion)
    block_number: int       # Block number
    block_timestamp: str    # ISO timestamp from block
    merkle_root: Optional[str] = None  # If batched via Merkle tree
    merkle_proof: Optional[List[str]] = None  # Leaf-to-root path

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for storage/transmission."""
        return {
            'chain_id': self.chain_id,
            'tx_hash': self.tx_hash,
            'block_number': self.block_number,
            'block_timestamp': self.block_timestamp,
            'merkle_root': self.merkle_root,
            'merkle_proof': self.merkle_proof,
        }


@dataclass
class BoundCertificate:
    """
    Certificate with cryptographic bindings (§7.11.4.7).

    The payload is IMMUTABLE. Bindings are ADDITIVE proofs that reference
    the same canonical payload_hash.

    Attributes:
        payload: The original YRSNCertificate (never modified)
        payload_hash: SHA-256 of canonical serialization (hex-encoded)
        signature_ed25519: Ed25519 signature over payload_hash
        signature_dilithium: Dilithium (post-quantum) signature (optional)
        blockchain_anchor: Timestamp proof via blockchain (optional)
    """
    payload: 'YRSNCertificate'
    payload_hash: str                          # Hex-encoded SHA-256
    signature_ed25519: Optional[bytes] = None  # 64 bytes
    signature_dilithium: Optional[bytes] = None  # ~2420 bytes
    blockchain_anchor: Optional[BlockchainAnchor] = None

    def verify_integrity(self) -> bool:
        """
        Verify payload hash matches current payload.

        This detects any tampering with the payload after signing.

        Returns:
            True if payload hash is valid, False if tampered
        """
        expected = compute_payload_hash(self.payload).hex()
        return expected == self.payload_hash

    def verify_ed25519(self, public_key: 'Ed25519PublicKey') -> bool:
        """
        Verify Ed25519 signature.

        Args:
            public_key: Ed25519 public key to verify against

        Returns:
            True if signature is valid, False otherwise
        """
        if self.signature_ed25519 is None:
            return False
        try:
            public_key.verify(
                self.signature_ed25519,
                bytes.fromhex(self.payload_hash)
            )
            return True
        except Exception:
            return False

    def verify_dilithium(self, public_key: bytes) -> bool:
        """
        Verify Dilithium (post-quantum) signature.

        Args:
            public_key: Dilithium public key bytes

        Returns:
            True if signature is valid, False otherwise
        """
        try:
            from pqcrypto.sign.ml_dsa_65 import verify as dilithium_verify
        except ImportError:
            return False

        if self.signature_dilithium is None:
            return False
        try:
            # ML-DSA verify signature: (public_key, message, signature)
            # Returns True if valid, False otherwise
            return dilithium_verify(
                public_key,
                bytes.fromhex(self.payload_hash),
                self.signature_dilithium
            )
        except Exception:
            return False

    def verify_hybrid(self, ed25519_pub: 'Ed25519PublicKey',
                      dilithium_pub: bytes) -> bool:
        """
        Verify HYBRID signature (Ed25519 AND Dilithium must BOTH be valid).

        This is the recommended verification for maximum security:
        - If Ed25519 is broken (e.g., by quantum computer), Dilithium protects
        - If Dilithium is broken (e.g., cryptanalysis), Ed25519 protects
        - Attacker must break BOTH to forge

        Args:
            ed25519_pub: Ed25519 public key
            dilithium_pub: Dilithium public key

        Returns:
            True only if BOTH signatures are valid
        """
        # All three checks must pass for hybrid verification
        integrity_ok = self.verify_integrity()
        ed25519_ok = self.verify_ed25519(ed25519_pub)
        dilithium_ok = self.verify_dilithium(dilithium_pub)

        return integrity_ok and ed25519_ok and dilithium_ok

    def verify_all(self, ed25519_pub: 'Ed25519PublicKey',
                   dilithium_pub: Optional[bytes] = None) -> Dict[str, Any]:
        """
        Verify all available bindings.

        Args:
            ed25519_pub: Ed25519 public key
            dilithium_pub: Dilithium public key (optional)

        Returns:
            Dict with verification results for each binding type
        """
        results = {
            'integrity': self.verify_integrity(),
            'ed25519': self.verify_ed25519(ed25519_pub),
            'has_blockchain_anchor': self.blockchain_anchor is not None,
        }

        if dilithium_pub is not None:
            results['dilithium'] = self.verify_dilithium(dilithium_pub)
            results['hybrid'] = (
                results['integrity'] and
                results['ed25519'] and
                results['dilithium']
            )

        return results

    def has_timestamp_proof(self) -> bool:
        """Check if ANY timestamp proof exists."""
        return self.blockchain_anchor is not None

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize for storage/transmission.

        Note: Payload is serialized separately (canonical form).
        """
        return {
            'payload_hash': self.payload_hash,
            'signature_ed25519': self.signature_ed25519.hex() if self.signature_ed25519 else None,
            'signature_dilithium': self.signature_dilithium.hex() if self.signature_dilithium else None,
            'blockchain_anchor': self.blockchain_anchor.to_dict() if self.blockchain_anchor else None,
        }
