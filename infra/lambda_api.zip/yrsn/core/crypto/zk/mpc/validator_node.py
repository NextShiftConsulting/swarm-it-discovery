"""
Validator Node for Distributed Quality Aggregation

Each validator node computes local quality metrics, generates ZK proofs,
and creates secret shares for secure aggregation.

CLAIM 19 SPECIFICATION:
- Compute local α, κ, ω metrics
- Generate ZK proof of correct computation
- Create additive shares for MPC aggregation
- Never reveal raw metrics to other validators
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any
import time
import secrets
import hashlib

from .secret_sharing import AdditiveSecretSharing, Share, generate_commitment, GOLDILOCKS_PRIME
from .aggregator import ValidatorSubmission


@dataclass
class ValidatorMetrics:
    """Quality metrics computed by a validator."""
    alpha: float  # R / (R + N) quality ratio
    kappa: float  # D* / D compatibility ratio
    omega: float  # Temporal stability
    timestamp: float = field(default_factory=time.time)


@dataclass
class LocalComputationResult:
    """Result of local metric computation with proof and shares."""
    metrics: ValidatorMetrics
    alpha_shares: List[Share]
    kappa_shares: List[Share]
    omega_shares: List[Share]
    proof_bytes: bytes
    commitment: bytes
    nonce: bytes


class ValidatorNode:
    """
    Individual validator node in the MPC network.

    Each validator:
    1. Receives input data (e.g., model embeddings, training gradients)
    2. Computes local quality metrics (α, κ, ω)
    3. Generates ZK proof that computation is correct
    4. Creates secret shares for secure aggregation
    5. Submits shares and proof to aggregator

    The aggregator can reconstruct average metrics without learning
    any individual validator's values.
    """

    def __init__(
        self,
        node_id: int,
        n_validators: int,
        precision: int = 18,
    ):
        """
        Initialize validator node.

        Args:
            node_id: Unique identifier for this validator
            n_validators: Total number of validators in network
            precision: Decimal places for float-to-int conversion
        """
        self.id = node_id
        self.n = n_validators
        self.precision = precision

        # Secret sharing for metric distribution
        self.sharing = AdditiveSecretSharing(n_validators)

        # Track local computations
        self._last_computation: Optional[LocalComputationResult] = None

    def compute_metrics(
        self,
        r: float,
        s: float,
        n: float,
        d_star: float,
        d_actual: float,
        omega: float = 1.0,
    ) -> ValidatorMetrics:
        """
        Compute quality metrics from decomposition.

        Args:
            r: Relevance component
            s: Spurious component
            n: Noise component
            d_star: Optimal distance
            d_actual: Actual distance
            omega: Temporal stability (default 1.0)

        Returns:
            Computed metrics
        """
        # Validate normalization
        total = r + s + n
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"R + S + N must equal 1, got {total}")

        # Compute α = R / (R + N)
        if r + n > 0:
            alpha = r / (r + n)
        else:
            alpha = 0.0

        # Compute κ = D* / D
        if d_actual > 0:
            kappa = d_star / d_actual
        else:
            kappa = 1.0  # Perfect if no actual distance

        # Clamp values to [0, 1]
        alpha = max(0.0, min(1.0, alpha))
        kappa = max(0.0, min(1.0, kappa))
        omega = max(0.0, min(1.0, omega))

        return ValidatorMetrics(
            alpha=alpha,
            kappa=kappa,
            omega=omega,
        )

    def compute_and_share(
        self,
        r: float,
        s: float,
        n: float,
        d_star: float,
        d_actual: float,
        omega: float = 1.0,
    ) -> LocalComputationResult:
        """
        Compute metrics, create shares, and generate proof.

        This is the main entry point for validators participating
        in secure aggregation.

        Args:
            r, s, n: RSN decomposition values
            d_star, d_actual: Distance metrics
            omega: Temporal stability

        Returns:
            LocalComputationResult with shares and proof
        """
        # Compute metrics
        metrics = self.compute_metrics(r, s, n, d_star, d_actual, omega)

        # Convert to integers for secret sharing
        alpha_int = self._float_to_int(metrics.alpha)
        kappa_int = self._float_to_int(metrics.kappa)
        omega_int = self._float_to_int(metrics.omega)

        # Create secret shares
        alpha_shares = self.sharing.share(alpha_int)
        kappa_shares = self.sharing.share(kappa_int)
        omega_shares = self.sharing.share(omega_int)

        # Generate commitment to private values
        commitment, nonce = self._generate_commitment(
            r, s, n, d_star, d_actual, omega
        )

        # Generate ZK proof (placeholder - actual proof via Plonky2)
        proof_bytes = self._generate_proof(
            r, s, n, d_star, d_actual, omega,
            metrics, commitment, nonce
        )

        result = LocalComputationResult(
            metrics=metrics,
            alpha_shares=alpha_shares,
            kappa_shares=kappa_shares,
            omega_shares=omega_shares,
            proof_bytes=proof_bytes,
            commitment=commitment,
            nonce=nonce,
        )

        self._last_computation = result
        return result

    def create_submission(self) -> ValidatorSubmission:
        """
        Create submission for aggregator from last computation.

        Returns:
            ValidatorSubmission ready for aggregation
        """
        if self._last_computation is None:
            raise RuntimeError("No computation performed yet")

        return ValidatorSubmission(
            validator_id=self.id,
            alpha_shares=self._last_computation.alpha_shares,
            kappa_shares=self._last_computation.kappa_shares,
            omega_shares=self._last_computation.omega_shares,
            proof_bytes=self._last_computation.proof_bytes,
            commitment=self._last_computation.commitment,
        )

    def _float_to_int(self, value: float) -> int:
        """Convert float to integer for secret sharing."""
        scaled = int(value * (10 ** self.precision))
        return scaled % GOLDILOCKS_PRIME

    def _generate_commitment(
        self,
        r: float, s: float, n: float,
        d_star: float, d_actual: float, omega: float
    ) -> Tuple[bytes, bytes]:
        """Generate cryptographic commitment to private values."""
        nonce = secrets.token_bytes(32)

        # Encode all values
        data = b''
        for v in [r, s, n, d_star, d_actual, omega]:
            data += v.to_bytes(8, 'big', signed=False) if isinstance(v, int) else \
                    int(v * (10 ** self.precision)).to_bytes(32, 'big')

        data += nonce
        commitment = hashlib.sha256(data).digest()

        return commitment, nonce

    def _generate_proof(
        self,
        r: float, s: float, n: float,
        d_star: float, d_actual: float, omega: float,
        metrics: ValidatorMetrics,
        commitment: bytes,
        nonce: bytes,
    ) -> bytes:
        """
        Generate ZK proof of correct computation.

        In production, this calls the Plonky2 prover via yrsn_zk.
        For now, we generate a placeholder proof.

        The proof demonstrates:
        1. R + S + N = 1 (normalization)
        2. α = R / (R + N) computed correctly
        3. κ = D* / D computed correctly
        4. Values are bound to commitment
        """
        # Placeholder: In production, use yrsn_zk.QualityThresholdProver
        # try:
        #     from yrsn_zk import QualityThresholdProver
        #     prover = QualityThresholdProver()
        #     return prover.prove(r, s, n, alpha_min=0.0)
        # except ImportError:
        #     pass

        # Placeholder proof structure
        proof_data = {
            'validator_id': self.id,
            'commitment': commitment.hex(),
            'timestamp': time.time(),
            # In production: actual STARK proof bytes
        }

        # Simple hash-based placeholder
        proof_input = f"{self.id}:{commitment.hex()}:{time.time()}".encode()
        return hashlib.sha256(proof_input).digest()


class ValidatorNetwork:
    """
    Coordinate multiple validator nodes.

    Utility class for simulating or managing a network of validators.
    """

    def __init__(self, n_validators: int):
        """Create a network of n validators."""
        self.n = n_validators
        self.validators = [
            ValidatorNode(node_id=i, n_validators=n_validators)
            for i in range(n_validators)
        ]

    def simulate_round(
        self,
        metrics_data: List[Dict[str, float]]
    ) -> List[ValidatorSubmission]:
        """
        Simulate one round of computation across all validators.

        Args:
            metrics_data: List of dicts with r, s, n, d_star, d_actual, omega
                         per validator

        Returns:
            List of submissions from all validators
        """
        if len(metrics_data) != self.n:
            raise ValueError(f"Need {self.n} metrics, got {len(metrics_data)}")

        submissions = []
        for i, data in enumerate(metrics_data):
            result = self.validators[i].compute_and_share(
                r=data.get('r', 0.6),
                s=data.get('s', 0.25),
                n=data.get('n', 0.15),
                d_star=data.get('d_star', 1.0),
                d_actual=data.get('d_actual', 1.25),
                omega=data.get('omega', 1.0),
            )
            submissions.append(self.validators[i].create_submission())

        return submissions
