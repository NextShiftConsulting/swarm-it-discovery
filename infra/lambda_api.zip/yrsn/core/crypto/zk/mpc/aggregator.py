"""
Secure MPC Aggregator for YRSN Quality Metrics

Implements Byzantine-fault tolerant aggregation of quality metrics
from distributed validators.

CLAIM 19 SPECIFICATION:
- Aggregate α, κ, ω metrics from n validators
- Require 2/3 majority agreement (Byzantine tolerance)
- Generate aggregated ZK proof
- Never reveal individual validator metrics
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any
from enum import Enum
import asyncio
import time

from .secret_sharing import (
    AdditiveSecretSharing,
    ShamirSecretSharing,
    Share,
    GOLDILOCKS_PRIME,
)


class ConsensusStatus(Enum):
    """Status of consensus achievement."""
    PENDING = "pending"
    ACHIEVED = "achieved"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class ValidatorSubmission:
    """Submission from a single validator."""
    validator_id: int
    alpha_shares: List[Share]
    kappa_shares: List[Share]
    omega_shares: List[Share]
    proof_bytes: bytes  # ZK proof of correct computation
    commitment: bytes  # Hash commitment to private values
    timestamp: float = field(default_factory=time.time)


@dataclass
class AggregatedResult:
    """Result of secure aggregation."""
    avg_alpha: float
    avg_kappa: float
    avg_omega: float
    n_validators: int
    consensus_status: ConsensusStatus
    aggregated_proof: Optional[bytes] = None
    validator_agreements: Dict[str, List[Tuple[int, int]]] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class SecureMPCAggregator:
    """
    Secure Multi-Party Computation Aggregator.

    Aggregates quality metrics from distributed validators using secret sharing
    while preserving privacy of individual validator values.

    Byzantine Fault Tolerance:
    - Requires t = ceil(2n/3) validators to agree
    - Detects and excludes malicious validators
    - Produces proof of correct aggregation
    """

    def __init__(
        self,
        n_validators: int,
        byzantine_threshold: Optional[int] = None,
        epsilon_alpha: float = 0.1,
        epsilon_kappa: float = 0.1,
        timeout_seconds: float = 30.0,
    ):
        """
        Initialize aggregator.

        Args:
            n_validators: Total number of validators
            byzantine_threshold: Minimum validators for consensus (default: ceil(2n/3))
            epsilon_alpha: Maximum allowed α disagreement
            epsilon_kappa: Maximum allowed κ disagreement
            timeout_seconds: Timeout for collecting submissions
        """
        self.n = n_validators
        self.t = byzantine_threshold or ((2 * n_validators + 2) // 3)  # ceil(2n/3)
        self.epsilon_alpha = epsilon_alpha
        self.epsilon_kappa = epsilon_kappa
        self.timeout = timeout_seconds

        # Secret sharing for reconstruction
        self.additive_ss = AdditiveSecretSharing(n_validators)
        self.shamir_ss = ShamirSecretSharing(n_validators, self.t)

        # Collected submissions
        self.submissions: Dict[int, ValidatorSubmission] = {}

        # Precision for float conversion
        self.precision = 18

    async def collect_submission(self, submission: ValidatorSubmission) -> bool:
        """
        Collect a submission from a validator.

        Args:
            submission: Validator's submission with shares and proof

        Returns:
            True if submission accepted
        """
        if submission.validator_id in self.submissions:
            return False  # Already submitted

        if submission.validator_id < 0 or submission.validator_id >= self.n:
            return False  # Invalid validator ID

        # Verify ZK proof (placeholder - actual verification via Plonky2)
        # if not self._verify_submission_proof(submission):
        #     return False

        self.submissions[submission.validator_id] = submission
        return True

    async def aggregate_quality(
        self,
        submissions: Optional[Dict[int, ValidatorSubmission]] = None
    ) -> AggregatedResult:
        """
        Aggregate quality metrics from collected submissions.

        Args:
            submissions: Optional dict of submissions (uses self.submissions if None)

        Returns:
            AggregatedResult with averaged metrics and consensus status
        """
        if submissions is not None:
            self.submissions = submissions

        if len(self.submissions) < self.t:
            return AggregatedResult(
                avg_alpha=0.0,
                avg_kappa=0.0,
                avg_omega=0.0,
                n_validators=len(self.submissions),
                consensus_status=ConsensusStatus.FAILED,
            )

        # Check for Byzantine agreement
        agreements = self._check_byzantine_agreement()

        if not self._has_consensus(agreements):
            return AggregatedResult(
                avg_alpha=0.0,
                avg_kappa=0.0,
                avg_omega=0.0,
                n_validators=len(self.submissions),
                consensus_status=ConsensusStatus.FAILED,
                validator_agreements=agreements,
            )

        # Reconstruct aggregated values
        avg_alpha = self._aggregate_metric('alpha')
        avg_kappa = self._aggregate_metric('kappa')
        avg_omega = self._aggregate_metric('omega')

        # Generate aggregated proof
        aggregated_proof = self._generate_aggregated_proof()

        return AggregatedResult(
            avg_alpha=avg_alpha,
            avg_kappa=avg_kappa,
            avg_omega=avg_omega,
            n_validators=len(self.submissions),
            consensus_status=ConsensusStatus.ACHIEVED,
            aggregated_proof=aggregated_proof,
            validator_agreements=agreements,
        )

    def _aggregate_metric(self, metric_name: str) -> float:
        """
        Aggregate a single metric using additive secret sharing.

        For additive shares, we can sum the shares from each validator
        and then divide by the number of validators.
        """
        # Collect shares for this metric
        all_shares: List[List[Share]] = []
        for sub in self.submissions.values():
            if metric_name == 'alpha':
                all_shares.append(sub.alpha_shares)
            elif metric_name == 'kappa':
                all_shares.append(sub.kappa_shares)
            elif metric_name == 'omega':
                all_shares.append(sub.omega_shares)

        if not all_shares:
            return 0.0

        n_validators = len(all_shares)

        # For additive sharing, each validator's shares sum to their value
        # Sum all shares column-wise, then reconstruct
        aggregated_shares = []
        for party_idx in range(self.n):
            party_sum = 0
            for validator_shares in all_shares:
                if party_idx < len(validator_shares):
                    party_sum = (party_sum + validator_shares[party_idx].value) % self.additive_ss.p

            aggregated_shares.append(Share(
                party_id=party_idx,
                value=party_sum,
                threshold=self.n
            ))

        # Reconstruct the sum
        total_sum = self.additive_ss.reconstruct(aggregated_shares)

        # Convert back to float and divide by number of validators
        avg = (total_sum / (10 ** self.precision)) / n_validators

        return avg

    def _check_byzantine_agreement(self) -> Dict[str, List[Tuple[int, int]]]:
        """
        Check for Byzantine agreement among validators.

        Identifies pairs of validators that agree within epsilon.
        """
        agreements = {
            'alpha': [],
            'kappa': [],
        }

        validators = list(self.submissions.keys())

        # Note: In a real implementation, we would compare values
        # without revealing them using ZK range proofs.
        # For now, we assume validators that submitted are in agreement.
        for i, v1 in enumerate(validators):
            for v2 in validators[i+1:]:
                # Assume agreement if both submitted (placeholder)
                agreements['alpha'].append((v1, v2))
                agreements['kappa'].append((v1, v2))

        return agreements

    def _has_consensus(self, agreements: Dict[str, List[Tuple[int, int]]]) -> bool:
        """
        Check if we have sufficient agreement for consensus.

        Requires at least t validators to form a clique.
        """
        n_submitted = len(self.submissions)

        # Simple check: if we have t submissions, assume consensus
        # In production, would check for actual agreement clique
        return n_submitted >= self.t

    def _generate_aggregated_proof(self) -> bytes:
        """
        Generate an aggregated ZK proof.

        This proof demonstrates:
        1. At least t validators participated
        2. Each validator's individual proof was valid
        3. Aggregation was performed correctly
        """
        # Placeholder: concatenate validator proofs
        # In production, would use recursive STARK composition
        proof_parts = []
        for sub in self.submissions.values():
            proof_parts.append(sub.proof_bytes)

        if not proof_parts:
            return b''

        # Simple aggregation: hash all proofs together
        import hashlib
        combined = b''.join(proof_parts)
        return hashlib.sha256(combined).digest()

    def reset(self):
        """Clear all collected submissions."""
        self.submissions.clear()


class StreamingAggregator(SecureMPCAggregator):
    """
    Streaming version of MPC aggregator.

    Allows continuous aggregation as validators submit shares,
    with periodic output of aggregated results.
    """

    def __init__(self, *args, window_seconds: float = 60.0, **kwargs):
        super().__init__(*args, **kwargs)
        self.window = window_seconds
        self._lock = asyncio.Lock()
        self._results_queue: asyncio.Queue[AggregatedResult] = asyncio.Queue()

    async def submit_and_aggregate(
        self,
        submission: ValidatorSubmission
    ) -> Optional[AggregatedResult]:
        """
        Submit and potentially trigger aggregation.

        Returns result if aggregation was performed, None otherwise.
        """
        async with self._lock:
            accepted = await self.collect_submission(submission)
            if not accepted:
                return None

            # Check if we have enough submissions
            if len(self.submissions) >= self.t:
                result = await self.aggregate_quality()
                self.reset()
                return result

        return None

    async def run_continuous(self):
        """
        Run continuous aggregation loop.

        Aggregates whenever threshold is reached or window expires.
        """
        last_aggregate_time = time.time()

        while True:
            await asyncio.sleep(1.0)  # Check every second

            current_time = time.time()
            should_aggregate = False

            async with self._lock:
                # Time-based trigger
                if current_time - last_aggregate_time >= self.window:
                    should_aggregate = len(self.submissions) >= 1

                # Threshold-based trigger
                if len(self.submissions) >= self.t:
                    should_aggregate = True

                if should_aggregate and self.submissions:
                    result = await self.aggregate_quality()
                    await self._results_queue.put(result)
                    self.reset()
                    last_aggregate_time = current_time

    async def get_result(self) -> AggregatedResult:
        """Get next aggregated result from queue."""
        return await self._results_queue.get()
