"""
Multi-Party Computation (MPC) Module for YRSN Quality Metrics

This module implements secure multi-party computation for aggregating
quality metrics from distributed validators without revealing individual values.

CLAIM 19 IMPLEMENTATION:
-----------------------
- Secret sharing of quality metrics (α, κ, ω)
- Byzantine-fault tolerant aggregation (2/3 majority)
- Zero-knowledge proof integration for validator correctness

Components:
- AdditiveSecretSharing: Split secrets into additive shares
- SecureMPCAggregator: Aggregate shares from multiple validators
- ValidatorNode: Individual validator that computes and shares metrics

Example:
    >>> from yrsn.core.crypto.zk.mpc import SecureMPCAggregator, ValidatorNode
    >>>
    >>> # Create aggregator for 5 validators
    >>> aggregator = SecureMPCAggregator(n_validators=5, threshold=4)
    >>>
    >>> # Each validator computes local metrics and creates shares
    >>> validators = [ValidatorNode(i, n_validators=5) for i in range(5)]
    >>> shares = [v.compute_and_share(input_data) for v in validators]
    >>>
    >>> # Aggregate shares to get average without revealing individuals
    >>> avg_alpha, proof = await aggregator.aggregate_quality(shares)
"""

from .secret_sharing import AdditiveSecretSharing, ShamirSecretSharing, Share
from .aggregator import SecureMPCAggregator, ValidatorSubmission, AggregatedResult
from .validator_node import ValidatorNode, ValidatorMetrics, ValidatorNetwork

__all__ = [
    'AdditiveSecretSharing',
    'ShamirSecretSharing',
    'Share',
    'SecureMPCAggregator',
    'ValidatorSubmission',
    'AggregatedResult',
    'ValidatorNode',
    'ValidatorMetrics',
    'ValidatorNetwork',
]
