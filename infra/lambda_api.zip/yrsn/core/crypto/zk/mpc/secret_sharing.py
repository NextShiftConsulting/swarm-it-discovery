"""
Secret Sharing Schemes for MPC

Implements additive and Shamir secret sharing for secure multi-party
computation of quality metrics.

Security Properties:
- Information-theoretic security: Any t-1 shares reveal nothing about secret
- Perfect reconstruction: Any t shares perfectly reconstruct the secret
- Linearity: Shares can be added without reconstruction (for aggregation)
"""

from dataclasses import dataclass
from typing import List, Tuple, Optional
import secrets
import hashlib


# Large prime for modular arithmetic (Goldilocks prime from Plonky2)
GOLDILOCKS_PRIME = 2**64 - 2**32 + 1

# Alternative: 256-bit prime for high security
PRIME_256 = 2**256 - 189


@dataclass
class Share:
    """A single share of a secret."""
    party_id: int
    value: int
    threshold: int  # t in t-of-n scheme


class AdditiveSecretSharing:
    """
    Additive Secret Sharing Scheme.

    Simple and efficient for summation-only MPC.
    Each share is a random value, and shares sum to the secret.

    Properties:
    - n-of-n reconstruction (all shares needed)
    - Linear: sum of shares = sum of secrets
    - Very fast (no polynomial evaluation)
    """

    def __init__(self, n_parties: int, prime: int = GOLDILOCKS_PRIME):
        """
        Initialize additive secret sharing.

        Args:
            n_parties: Number of parties to share among
            prime: Prime modulus for finite field arithmetic
        """
        self.n = n_parties
        self.p = prime

    def share(self, secret: int) -> List[Share]:
        """
        Split secret into n additive shares.

        Args:
            secret: Integer value to share (must be < p)

        Returns:
            List of n shares that sum to secret mod p
        """
        if secret >= self.p:
            raise ValueError(f"Secret {secret} must be < prime {self.p}")

        # Generate n-1 random shares
        shares = []
        running_sum = 0
        for i in range(self.n - 1):
            value = secrets.randbelow(self.p)
            shares.append(Share(party_id=i, value=value, threshold=self.n))
            running_sum = (running_sum + value) % self.p

        # Last share is secret - sum of other shares
        last_value = (secret - running_sum) % self.p
        shares.append(Share(party_id=self.n - 1, value=last_value, threshold=self.n))

        return shares

    def reconstruct(self, shares: List[Share]) -> int:
        """
        Reconstruct secret from all n shares.

        Args:
            shares: All n shares

        Returns:
            Original secret value
        """
        if len(shares) != self.n:
            raise ValueError(f"Need all {self.n} shares, got {len(shares)}")

        total = sum(s.value for s in shares) % self.p
        return total

    def share_float(self, value: float, precision: int = 18) -> List[Share]:
        """
        Share a floating point value.

        Args:
            value: Float in [0, 1] to share
            precision: Decimal places to preserve

        Returns:
            List of shares
        """
        # Scale to integer
        scaled = int(value * (10 ** precision))
        return self.share(scaled)

    def reconstruct_float(self, shares: List[Share], precision: int = 18) -> float:
        """
        Reconstruct float from shares.

        Args:
            shares: All shares
            precision: Decimal places used in sharing

        Returns:
            Original float value
        """
        scaled = self.reconstruct(shares)
        return scaled / (10 ** precision)


class ShamirSecretSharing:
    """
    Shamir's (t, n) Threshold Secret Sharing.

    More complex but supports t-of-n reconstruction.
    Based on polynomial interpolation over finite fields.

    Properties:
    - t-of-n reconstruction (any t shares suffice)
    - Information-theoretic security (t-1 shares reveal nothing)
    - Linear: sum of shares = share of sum
    """

    def __init__(self, n_parties: int, threshold: int, prime: int = GOLDILOCKS_PRIME):
        """
        Initialize Shamir secret sharing.

        Args:
            n_parties: Total number of parties
            threshold: Minimum shares needed to reconstruct
            prime: Prime modulus
        """
        if threshold > n_parties:
            raise ValueError(f"Threshold {threshold} cannot exceed n_parties {n_parties}")

        self.n = n_parties
        self.t = threshold
        self.p = prime

    def share(self, secret: int) -> List[Share]:
        """
        Split secret using degree-(t-1) polynomial.

        The polynomial f(x) has:
        - f(0) = secret
        - Random coefficients a_1, ..., a_{t-1}
        - Share i = f(i) for i = 1, ..., n

        Args:
            secret: Value to share

        Returns:
            n shares, any t of which can reconstruct
        """
        if secret >= self.p:
            raise ValueError(f"Secret must be < {self.p}")

        # Generate random polynomial coefficients
        # f(x) = secret + a_1*x + a_2*x^2 + ... + a_{t-1}*x^{t-1}
        coeffs = [secret]
        for _ in range(self.t - 1):
            coeffs.append(secrets.randbelow(self.p))

        # Evaluate polynomial at points 1, 2, ..., n
        shares = []
        for i in range(1, self.n + 1):
            value = self._eval_poly(coeffs, i)
            shares.append(Share(party_id=i, value=value, threshold=self.t))

        return shares

    def reconstruct(self, shares: List[Share]) -> int:
        """
        Reconstruct secret using Lagrange interpolation.

        Args:
            shares: At least t shares

        Returns:
            Original secret
        """
        if len(shares) < self.t:
            raise ValueError(f"Need at least {self.t} shares, got {len(shares)}")

        # Use first t shares
        shares = shares[:self.t]

        # Lagrange interpolation at x=0
        secret = 0
        for i, share_i in enumerate(shares):
            xi = share_i.party_id
            yi = share_i.value

            # Compute Lagrange basis polynomial L_i(0)
            numerator = 1
            denominator = 1
            for j, share_j in enumerate(shares):
                if i != j:
                    xj = share_j.party_id
                    numerator = (numerator * (-xj)) % self.p
                    denominator = (denominator * (xi - xj)) % self.p

            # Compute L_i(0) * y_i
            lagrange = (yi * numerator * self._mod_inverse(denominator)) % self.p
            secret = (secret + lagrange) % self.p

        return secret

    def _eval_poly(self, coeffs: List[int], x: int) -> int:
        """Evaluate polynomial at point x using Horner's method."""
        result = 0
        for c in reversed(coeffs):
            result = (result * x + c) % self.p
        return result

    def _mod_inverse(self, a: int) -> int:
        """Compute modular inverse using extended Euclidean algorithm."""
        return pow(a, self.p - 2, self.p)  # Fermat's little theorem

    def share_float(self, value: float, precision: int = 18) -> List[Share]:
        """Share a floating point value."""
        scaled = int(value * (10 ** precision))
        return self.share(scaled)

    def reconstruct_float(self, shares: List[Share], precision: int = 18) -> float:
        """Reconstruct float from shares."""
        scaled = self.reconstruct(shares)
        return scaled / (10 ** precision)


def generate_commitment(value: int, nonce: bytes = None) -> Tuple[bytes, bytes]:
    """
    Generate a cryptographic commitment to a value.

    Args:
        value: Value to commit to
        nonce: Optional random nonce (generated if not provided)

    Returns:
        Tuple of (commitment, nonce)
    """
    if nonce is None:
        nonce = secrets.token_bytes(32)

    data = value.to_bytes(32, 'big') + nonce
    commitment = hashlib.sha256(data).digest()

    return commitment, nonce


def verify_commitment(commitment: bytes, value: int, nonce: bytes) -> bool:
    """
    Verify a commitment.

    Args:
        commitment: The commitment to verify
        value: Claimed value
        nonce: The nonce used in commitment

    Returns:
        True if commitment is valid
    """
    expected, _ = generate_commitment(value, nonce)
    return secrets.compare_digest(commitment, expected)
