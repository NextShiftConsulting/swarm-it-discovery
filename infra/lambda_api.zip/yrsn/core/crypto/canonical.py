"""
Canonical serialization for deterministic hashing.

This module provides deterministic JSON serialization for YRSN certificates,
ensuring that the same certificate always produces the same hash regardless
of Python version, platform, or serialization order.

Patent Reference: §7.11.4.7 (Integrity Protection)
"""

import json
import hashlib
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


def canonical_serialize(cert: 'YRSNCertificate') -> str:
    """
    Deterministic JSON serialization for hashing.

    Canonicalization Rules:
    1. Sorted keys (alphabetical, reproducible ordering)
    2. No whitespace (compact)
    3. Floats to 10 decimal places (avoid FP variance)
    4. datetime as ISO format
    5. Enums as .value
    6. None values omitted

    Args:
        cert: YRSNCertificate to serialize

    Returns:
        Canonical JSON string (deterministic)

    Example:
        >>> cert1 = YRSNCertificate(R=0.6, S=0.3, N=0.1, ...)
        >>> cert2 = YRSNCertificate(R=0.6, S=0.3, N=0.1, ...)
        >>> canonical_serialize(cert1) == canonical_serialize(cert2)
        True
    """
    def serialize_value(v):
        if v is None:
            return None
        if isinstance(v, float):
            return round(v, 10)
        elif isinstance(v, datetime):
            return v.isoformat()
        elif hasattr(v, 'value'):  # Enum
            return v.value
        return v

    # Build canonical payload dict
    # Include all fields that define the certificate's semantic content
    d = {
        # Core 6D measurements
        'R': serialize_value(cert.R),
        'S': serialize_value(cert.S),
        'N': serialize_value(cert.N),
        'alpha': serialize_value(cert.alpha),
        'omega': serialize_value(cert.omega),
        'tau': serialize_value(cert.tau),

        # Classification (tripartite)
        'degradation_type': serialize_value(getattr(cert, 'degradation_type', None)),
        'fragility_state': serialize_value(getattr(cert, 'fragility_state', None)),
        'severity_value': serialize_value(getattr(cert, 'severity_value', None)),

        # Threshold provenance
        'policy_id': cert.policy_id,

        # Validity
        'expires_at': serialize_value(cert.expires_at),
        'timestamp': cert.timestamp,
    }

    # Remove None values for compactness
    d = {k: v for k, v in d.items() if v is not None}

    return json.dumps(d, sort_keys=True, separators=(',', ':'))


def compute_payload_hash(cert: 'YRSNCertificate') -> bytes:
    """
    Compute SHA-256 hash of canonical certificate.

    Args:
        cert: YRSNCertificate to hash

    Returns:
        32-byte SHA-256 hash

    Example:
        >>> cert = YRSNCertificate(R=0.6, S=0.3, N=0.1, ...)
        >>> h = compute_payload_hash(cert)
        >>> len(h)
        32
    """
    canonical = canonical_serialize(cert)
    return hashlib.sha256(canonical.encode('utf-8')).digest()
