"""
YRSN Oobleck Module: Stress-Adaptive Plasticity with Geometric Foundations

This module implements shear-thickening (non-Newtonian) behavior for YRSN
quality-driven plasticity control, grounded in proper geometric foundations.

Key Components:
---------------
1. GeometricShearForce: Computes F_s using T⁴ manifold geodesic velocity
2. SimplexGradientProjection: Projects gradients onto R+S+N=1 tangent space
3. StressAdaptivePlasticity: Asymmetric lock/unlock dynamics

Theoretical Foundations:
------------------------
- BCM sliding threshold (Bienenstock, Cooper, Munro, 1982)
- Metaplasticity (Abraham & Bear, 1996)
- EWC weight protection (Kirkpatrick et al., 2017)
- Surprise-based learning (Iigaya et al., 2016)
- Fast rate detector (Zenke et al., 2013)
- Riemannian optimization on simplices (arXiv:2503.24075)

Novel Contributions:
--------------------
- Geometric F_s: Shear force from T⁴ geodesic velocity
- Simplex-aware gradients: Projections that respect R+S+N=1
- Asymmetric dynamics: Fast solidification, slow relaxation

See: docs/design/OOBLECK_PRIOR_WORK.md
"""

from .geometric_shear import (
    GeometricShearForce,
    compute_t4_velocity,
    simplex_gradient_projection,
    simplex_tangent_projection,
)

__all__ = [
    "GeometricShearForce",
    "compute_t4_velocity",
    "simplex_gradient_projection",
    "simplex_tangent_projection",
]
