"""
Geometric Shear Force and Simplex Constraint Projections

This module provides the mathematical foundations for stress-adaptive plasticity
using proper differential geometry on the YRSN manifolds.

KEY CONCEPTS:
=============

1. GEOMETRIC SHEAR FORCE (F_s)
   ---------------------------
   Instead of naive |Δα| + |Δτ|, compute the geodesic velocity on T⁴:

   F_s = ||dX/dt||_T⁴ = √(Σᵢ (2 - 2·cos(Δθᵢ))) / Δt

   This respects the toroidal topology where 10° and 350° are 20° apart.

2. SIMPLEX GRADIENT PROJECTION
   ----------------------------
   The R/S/N decomposition lives on the probability simplex: R + S + N = 1.

   Any gradient must be projected onto the tangent space of this simplex,
   otherwise updates will violate the constraint.

   Projection formula:
       proj(g) = g - (g · n)n  where n = (1, 1, 1) / √3

   This is Riemannian optimization on the simplex manifold.

3. CONSTRAINT-AWARE LEARNING
   --------------------------
   When learning R/S/N weights, we must:
   (a) Compute Euclidean gradient ∇L
   (b) Project onto simplex tangent space: grad_simplex = proj(∇L)
   (c) Retract back to simplex: normalize(W + η·grad_simplex)

REFERENCES:
-----------
- Riemannian Optimization on Oblique Manifold (arXiv:2503.24075, 2025)
- Survey of Geometric Optimization for Deep Learning (ACM Computing Surveys)
- Geodesics on the Torus (rdrop.com/~half/math/torus)
- YRSN T⁴ Geometric Framework (docs/CIP_01_T4_PARAMETERIZATION.md)
"""

import numpy as np
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
from collections import deque


# =============================================================================
# SIMPLEX GEOMETRY
# =============================================================================

def simplex_normal() -> np.ndarray:
    """
    Return the normal vector to the probability simplex R + S + N = 1.

    The simplex is the plane { (R, S, N) : R + S + N = 1, R,S,N >= 0 }.
    Its normal vector is (1, 1, 1) / √3.

    Returns:
        Unit normal vector to the simplex
    """
    return np.array([1.0, 1.0, 1.0]) / np.sqrt(3.0)


def simplex_tangent_projection(vector: np.ndarray) -> np.ndarray:
    """
    Project a vector onto the tangent space of the probability simplex.

    The tangent space of the simplex R + S + N = 1 consists of all vectors
    (v_R, v_S, v_N) such that v_R + v_S + v_N = 0.

    Projection removes the component normal to the simplex:
        proj(v) = v - (v · n)n  where n = (1,1,1)/√3

    Args:
        vector: 3D vector (gradient or direction)

    Returns:
        Projected vector in simplex tangent space (sum = 0)

    Example:
        >>> g = np.array([0.3, 0.5, 0.2])  # Sum = 1.0
        >>> proj = simplex_tangent_projection(g)
        >>> print(f"Sum: {proj.sum():.6f}")  # 0.0 (on tangent space)
    """
    n = simplex_normal()
    # Remove normal component
    normal_component = np.dot(vector, n) * n
    return vector - normal_component


def simplex_gradient_projection(gradient: np.ndarray) -> np.ndarray:
    """
    Project a gradient onto the simplex tangent space for constrained optimization.

    This is the key operation for Riemannian gradient descent on the simplex.
    After projection, the gradient points in a direction that stays on the simplex.

    Args:
        gradient: Euclidean gradient ∇L with shape (3,) or (N, 3)

    Returns:
        Riemannian gradient on simplex tangent space

    Reference:
        arXiv:2503.24075 - Riemannian Optimization on Oblique Manifold
    """
    if gradient.ndim == 1:
        return simplex_tangent_projection(gradient)
    else:
        # Batch projection
        return np.apply_along_axis(simplex_tangent_projection, 1, gradient)


def simplex_retraction(point: np.ndarray, tangent_vector: np.ndarray,
                       step_size: float = 1.0) -> np.ndarray:
    """
    Retract from tangent space back onto the simplex.

    After taking a step in the tangent direction, project back onto the simplex
    by normalizing to sum to 1 and clipping to [0, 1].

    Args:
        point: Current point on simplex (R, S, N)
        tangent_vector: Tangent direction (should sum to ~0)
        step_size: Step size for the update

    Returns:
        New point on simplex satisfying R + S + N = 1, R,S,N >= 0

    Note:
        This uses Euclidean retraction (normalize). For higher precision,
        exponential map retraction could be used, but normalize is standard.
    """
    # Take step in tangent direction
    new_point = point + step_size * tangent_vector

    # Clip to non-negative
    new_point = np.maximum(new_point, 0.0)

    # Normalize to sum to 1
    total = new_point.sum()
    if total > 0:
        new_point = new_point / total
    else:
        # Degenerate case: return uniform
        new_point = np.array([1/3, 1/3, 1/3])

    return new_point


# =============================================================================
# T⁴ GEODESIC VELOCITY
# =============================================================================

def compute_t4_velocity(
    coords_current: Dict[str, float],
    coords_previous: Dict[str, float],
    dt: float = 1.0
) -> float:
    """
    Compute geodesic velocity on T⁴ manifold.

    The T⁴ coordinates are (simplex_theta, phi_simplex, alpha, omega).
    The velocity is computed using chordal distance rate of change.

    FORMULA:
    --------
    velocity = d_chordal / dt

    where d_chordal = √(Σᵢ (2 - 2·cos(Δθᵢ)))

    This respects toroidal topology: 10° → 350° is 20° change, not 340°.

    Args:
        coords_current: Current T⁴ coordinates (degrees)
        coords_previous: Previous T⁴ coordinates (degrees)
        dt: Time step

    Returns:
        Geodesic velocity (rate of change on manifold)

    Reference:
        docs/CIP_01_T4_PARAMETERIZATION.md
        YRSN geometric_utils.t4_chordal_distance
    """
    keys = ['simplex_theta', 'phi_simplex', 'alpha', 'omega']

    # Compute chordal distance squared
    d_squared = 0.0
    for key in keys:
        theta1 = coords_current.get(key, 0.0)
        theta2 = coords_previous.get(key, 0.0)

        # Convert to radians
        delta_rad = np.deg2rad(theta1 - theta2)

        # Chordal distance component: 2 - 2*cos(Δθ) = 4*sin²(Δθ/2)
        d_squared += 2.0 - 2.0 * np.cos(delta_rad)

    # Velocity = distance / time
    distance = np.sqrt(d_squared)
    velocity = distance / max(dt, 1e-6)

    return velocity


# =============================================================================
# GEOMETRIC SHEAR FORCE
# =============================================================================

@dataclass
class ShearState:
    """Current state of the geometric shear force computation."""
    shear_force: float          # F_s: rate of change on manifold
    t4_velocity: float          # Geodesic velocity on T⁴
    simplex_velocity: float     # Rate of change on R/S/N simplex
    stress: float               # Accumulated stress [0, 1]
    regime: str                 # "liquid", "transition", "solid"
    plasticity_multiplier: float  # Effective plasticity [0.1, 1.0]


class GeometricShearForce:
    """
    Compute shear force using proper T⁴ geometry and simplex constraints.

    Unlike naive |Δα| + |Δτ|, this computes:
    1. Geodesic velocity on T⁴ (respects toroidal topology)
    2. Velocity on R/S/N simplex (respects constraint manifold)
    3. Combined shear force for stress-adaptive plasticity

    The shear force F_s is analogous to constraint shear in non-Newtonian fluids:
    - Low F_s: viscous (liquid) behavior - normal learning
    - High F_s: solid behavior - protect weights

    Theoretical Foundations:
    ------------------------
    - T⁴ geodesic distance (YRSN patent §7.6)
    - Riemannian optimization on simplices (arXiv:2503.24075)
    - BCM metaplasticity (Bienenstock, Cooper, Munro, 1982)
    - Surprise-based learning (Iigaya et al., 2016)

    Example:
        >>> shear = GeometricShearForce()
        >>> state = shear.update(
        ...     t4_coords={'simplex_theta': 45, 'phi_simplex': 90, 'alpha': 120, 'omega': 30},
        ...     rsn=(0.6, 0.25, 0.15)
        ... )
        >>> print(f"Regime: {state.regime}, Plasticity: {state.plasticity_multiplier:.2f}")
    """

    def __init__(
        self,
        window_size: int = 10,
        stress_threshold: float = 0.3,
        lock_speed: float = 0.8,
        unlock_speed: float = 0.1,
        t4_weight: float = 0.6,
        simplex_weight: float = 0.4,
    ):
        """
        Initialize geometric shear force computer.

        Args:
            window_size: History window for smoothing
            stress_threshold: F_s threshold for phase transition
            lock_speed: Speed of solidification (fast)
            unlock_speed: Speed of relaxation (slow)
            t4_weight: Weight for T⁴ velocity in combined F_s
            simplex_weight: Weight for simplex velocity in combined F_s
        """
        self.window_size = window_size
        self.stress_threshold = stress_threshold
        self.lock_speed = lock_speed
        self.unlock_speed = unlock_speed
        self.t4_weight = t4_weight
        self.simplex_weight = simplex_weight

        # History
        self._t4_history: deque = deque(maxlen=window_size)
        self._rsn_history: deque = deque(maxlen=window_size)
        self._timestamps: deque = deque(maxlen=window_size)

        # State
        self._stress: float = 0.0
        self._step: int = 0

    def update(
        self,
        t4_coords: Optional[Dict[str, float]] = None,
        rsn: Optional[Tuple[float, float, float]] = None,
        alpha: Optional[float] = None,
        kappa: Optional[float] = None,
        tau: Optional[float] = None,
        timestamp: Optional[float] = None,
    ) -> ShearState:
        """
        Update shear force with new observations.

        Accepts EITHER:
        - t4_coords + rsn (full geometric computation)
        - alpha/kappa/tau (simplified computation, backwards compatible)

        Args:
            t4_coords: T⁴ coordinates dict
            rsn: (R, S, N) tuple on probability simplex
            alpha: Quality signal [0, 1]
            kappa: Compatibility signal [0, 1]
            tau: Temperature signal
            timestamp: Optional timestamp

        Returns:
            ShearState with all computed values
        """
        import time as time_module
        current_time = timestamp or time_module.time()
        self._step += 1

        # Compute velocities
        t4_velocity = 0.0
        simplex_velocity = 0.0

        # T⁴ velocity (if coords provided)
        if t4_coords is not None:
            self._t4_history.append(t4_coords)
            if len(self._t4_history) >= 2:
                dt = current_time - self._timestamps[-1] if self._timestamps else 1.0
                t4_velocity = compute_t4_velocity(
                    self._t4_history[-1],
                    self._t4_history[-2],
                    dt=max(dt, 1e-6)
                )

        # Simplex velocity (if RSN provided)
        if rsn is not None:
            rsn_array = np.array(rsn)
            self._rsn_history.append(rsn_array)
            if len(self._rsn_history) >= 2:
                delta_rsn = self._rsn_history[-1] - self._rsn_history[-2]
                simplex_velocity = np.linalg.norm(delta_rsn)

        # Fallback: use alpha/kappa/tau
        if t4_coords is None and rsn is None:
            # Create pseudo-T⁴ coords from simplified signals
            pseudo_coords = {
                'simplex_theta': (alpha or 0.5) * 180,  # Map [0,1] to [0,180]
                'phi_simplex': (kappa or 0.5) * 180 if kappa else 90,
                'alpha': (alpha or 0.5) * 180,
                'omega': 45,  # Default
            }
            self._t4_history.append(pseudo_coords)
            if len(self._t4_history) >= 2:
                dt = current_time - self._timestamps[-1] if self._timestamps else 1.0
                t4_velocity = compute_t4_velocity(
                    self._t4_history[-1],
                    self._t4_history[-2],
                    dt=max(dt, 1e-6)
                )

        self._timestamps.append(current_time)

        # Combined shear force
        shear_force = (
            self.t4_weight * t4_velocity +
            self.simplex_weight * simplex_velocity
        )

        # Sigmoidal stress response (phase transition)
        target_stress = 1.0 / (1.0 + np.exp(-10.0 * (shear_force - self.stress_threshold)))

        # Asymmetric dynamics: fast lock, slow unlock
        if target_stress > self._stress:
            speed = self.lock_speed
        else:
            speed = self.unlock_speed

        self._stress = (1.0 - speed) * self._stress + speed * target_stress

        # Determine regime
        if self._stress < 0.2:
            regime = "liquid"
        elif self._stress > 0.7:
            regime = "solid"
        else:
            regime = "transition"

        # Plasticity multiplier
        plasticity_multiplier = max(0.1, 1.0 - self._stress * 0.9)

        return ShearState(
            shear_force=shear_force,
            t4_velocity=t4_velocity,
            simplex_velocity=simplex_velocity,
            stress=self._stress,
            regime=regime,
            plasticity_multiplier=plasticity_multiplier,
        )

    def reset(self):
        """Reset all history and state."""
        self._t4_history.clear()
        self._rsn_history.clear()
        self._timestamps.clear()
        self._stress = 0.0
        self._step = 0


# =============================================================================
# CONSTRAINT-AWARE WEIGHT UPDATE
# =============================================================================

def constrained_rsn_update(
    W_R: np.ndarray,
    W_S: np.ndarray,
    W_N: np.ndarray,
    grad_R: np.ndarray,
    grad_S: np.ndarray,
    grad_N: np.ndarray,
    learning_rate: float = 0.01,
    stress_multiplier: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Update R/S/N projection weights while respecting simplex constraint.

    For each position in the weight matrices, the (R, S, N) values must
    satisfy R + S + N = 1. This function:
    1. Stacks gradients into simplex gradient
    2. Projects onto simplex tangent space
    3. Updates weights
    4. Retracts back to simplex

    Args:
        W_R, W_S, W_N: Current weight matrices (same shape)
        grad_R, grad_S, grad_N: Euclidean gradients
        learning_rate: Base learning rate
        stress_multiplier: Oobleck plasticity multiplier [0.1, 1.0]

    Returns:
        Updated (W_R, W_S, W_N) satisfying simplex constraint

    Reference:
        arXiv:2503.24075 - Riemannian Optimization on Oblique Manifold
    """
    effective_lr = learning_rate * stress_multiplier

    # Process element-wise (or vectorized for efficiency)
    new_W_R = np.zeros_like(W_R)
    new_W_S = np.zeros_like(W_S)
    new_W_N = np.zeros_like(W_N)

    # Flatten for vectorized processing
    flat_shape = W_R.shape
    W_R_flat = W_R.flatten()
    W_S_flat = W_S.flatten()
    W_N_flat = W_N.flatten()
    grad_R_flat = grad_R.flatten()
    grad_S_flat = grad_S.flatten()
    grad_N_flat = grad_N.flatten()

    for i in range(len(W_R_flat)):
        # Current point on simplex
        point = np.array([W_R_flat[i], W_S_flat[i], W_N_flat[i]])

        # Euclidean gradient
        grad = np.array([grad_R_flat[i], grad_S_flat[i], grad_N_flat[i]])

        # Project gradient onto simplex tangent space
        grad_projected = simplex_tangent_projection(grad)

        # Retract to simplex
        new_point = simplex_retraction(point, -grad_projected, effective_lr)

        new_W_R.flat[i] = new_point[0]
        new_W_S.flat[i] = new_point[1]
        new_W_N.flat[i] = new_point[2]

    return new_W_R, new_W_S, new_W_N


def validate_simplex_constraint(R: np.ndarray, S: np.ndarray, N: np.ndarray,
                                 tolerance: float = 1e-6) -> bool:
    """
    Validate that R + S + N = 1 everywhere.

    Args:
        R, S, N: Arrays of same shape
        tolerance: Allowed deviation from 1.0

    Returns:
        True if constraint is satisfied everywhere
    """
    total = R + S + N
    return np.allclose(total, 1.0, atol=tolerance)
