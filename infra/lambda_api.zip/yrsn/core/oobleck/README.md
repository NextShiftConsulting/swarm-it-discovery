# YRSN Oobleck Module

**Stress-Adaptive Plasticity with Geometric Foundations**

## Overview

This module implements shear-thickening (non-Newtonian) behavior for YRSN quality-driven plasticity control. When quality signals change rapidly, plasticity is reduced to protect learned weights.

## Key Concept

Like physical oobleck (cornstarch + water):
- **Low stress (gradual changes):** Liquid behavior → normal learning
- **High stress (rapid changes):** Solid behavior → protect weights

## Files

| File | Purpose |
|------|---------|
| `__init__.py` | Exports main classes |
| `geometric_shear.py` | T⁴ geodesic velocity + simplex projection |

## Quick Start

```python
from yrsn.core.oobleck import GeometricShearForce

# From YRSNCertificate
cert = decompose(embedding)

# Create shear force computer
shear = GeometricShearForce()

# Update with certificate values
state = shear.update(
    alpha=cert.alpha,
    kappa=cert.kappa,
    tau=cert.tau
)

# Check regime
if state.regime == "solid":
    print("Protecting weights - rapid quality change detected")

# Get plasticity multiplier for learning rate
lr_effective = base_lr * state.plasticity_multiplier
```

## Key Classes

### `GeometricShearForce`
Computes shear force using T⁴ geodesic velocity (respects toroidal topology).

### `simplex_tangent_projection()`
Projects gradients onto R+S+N=1 tangent space for constraint-aware updates.

### `simplex_retraction()`
Maps points back to probability simplex after gradient step.

## Design Documents

- `docs/design/GEOMETRIC_SHEAR_DESIGN.md` - Full design specification
- `docs/design/OOBLECK_PRIOR_WORK.md` - Theoretical foundations

## Theoretical Foundations

- BCM sliding threshold (Bienenstock, Cooper, Munro, 1982)
- Elastic Weight Consolidation (Kirkpatrick et al., 2017)
- Surprise-based learning (Iigaya et al., 2016)
- Fast rate detector (Zenke et al., 2013)
- Riemannian optimization on simplices (arXiv:2503.24075)

## Standalone Usage (No Memristor)

Use GeometricShearForce directly for any learning system that needs stress-adaptive plasticity:

```python
from yrsn.core.oobleck import GeometricShearForce

# Create shear force computer (standalone - no memristor needed)
shear = GeometricShearForce(
    stress_threshold=0.3,   # When to start solidifying
    lock_speed=0.8,         # Fast lock on stress
    unlock_speed=0.1,       # Slow recovery
)

# In your training loop - use with ANY optimizer
for batch in dataloader:
    # Get current quality signals (from your system)
    quality = compute_quality(model, batch)
    kappa = solver.compatibility_ratio()
    tau = curriculum.current_tau()

    # Update stress state
    state = shear.update(alpha=quality, kappa=kappa, tau=tau)

    # Modulate learning rate based on regime
    effective_lr = base_lr * state.plasticity_multiplier

    # Use with standard PyTorch optimizer
    for param_group in optimizer.param_groups:
        param_group['lr'] = effective_lr

    # Normal training step
    loss = criterion(model(batch), targets)
    loss.backward()
    optimizer.step()

    # Monitor regime
    if state.regime == "solid":
        print(f"Step {step}: Protected (stress={state.stress:.2f})")
```

This works with any optimizer (Adam, SGD, etc.) without needing VirtualMemristor.

## Integration with VirtualMemristor

When using hardware memristor abstraction:

```python
# Option 1: Naive (backwards compatible)
memristor.compute_stress(tau, alpha, dt)

# Option 2: Geometric (recommended when T⁴ coords available)
memristor.compute_stress_geometric(t4_coords, rsn, alpha, kappa, tau)
```
