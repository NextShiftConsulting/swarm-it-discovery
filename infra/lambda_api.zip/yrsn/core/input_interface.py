"""
Input Interface Module - Formal Implementation

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.3: Input Reception Module
  - §7.3.2: Functional Requirements (multi-format input, validation, normalization)
  - §7.3.3: Input Processing (format detection, type checking)
  - §7.3.4: Validation Rules (range checking, shape validation)
  - §7.3.5: Normalization (standardization for decomposition)

Key patent compliance features:
- Multi-format input support (images, embeddings, text, matrices)
- Automatic format detection and validation
- Normalization for decomposition processing
- Batched processing support

Relevant patent files:
- docs/specs/patent_spec_section_7_3_input_reception.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

┌────────────────────────────────────────────────────────────────────┐
│                       WHAT THIS DOES                                │
├────────────────────────────────────────────────────────────────────┤
│ Formalizes the Input Interface pattern (Patent §7.3):              │
│   • Accepts contextual input data in arbitrary form                │
│   • Validates input meets processing requirements                  │
│   • Normalizes input for decomposition                             │
│   • Provides unified interface for all input types                 │
│                                                                     │
│ This module wraps existing informal implementations in             │
│ frequency_rsn.py and trained_projection.py with a formal           │
│ protocol-based interface.                                          │
└────────────────────────────────────────────────────────────────────┘

WHY THIS EXISTS:
---------------
The patent spec §7.3 describes an "Input Reception Module" that accepts
arbitrary contextual input data and prepares it for decomposition. Previously,
this functionality was distributed across multiple modules informally.

This module formalizes the interface to:
1. Provide clear API contract (Protocol)
2. Enable easier testing and mocking
3. Support pluggable input handlers (hex architecture)
4. Complete patent spec module coverage

DESIGN:
-------
Uses Protocol (typing) for interface definition, allowing multiple
implementations without inheritance. This aligns with hex architecture
and enables dependency injection.

USAGE EXAMPLES:
--------------

Example 1: Use with Image Input
>>> from yrsn.core.input_interface import StandardInputInterface
>>> import numpy as np
>>> from PIL import Image
>>>
>>> # Create interface
>>> interface = StandardInputInterface()
>>>
>>> # Accept and process image
>>> image = np.array(Image.open('photo.jpg'))
>>> context = interface.accept(image)
>>> print(context.format)  # "image"
>>> print(context.shape)   # (224, 224, 3)
>>>
>>> # Validate
>>> is_valid = interface.validate(context)
>>> print(is_valid)  # True
>>>
>>> # Normalize for decomposition
>>> normalized = interface.normalize(context)
>>> # Ready for decomposition!

Example 2: Use with Embedding Input
>>> # Accept embeddings from a model
>>> embeddings = model.encode(text)  # [768] vector
>>> context = interface.accept(embeddings)
>>> print(context.format)  # "embedding"
>>>
>>> if interface.validate(context):
>>>     normalized = interface.normalize(context)
>>>     # Ready for RSN projection

Example 3: Batch Processing
>>> images = [np.array(Image.open(p)) for p in image_paths]
>>> contexts = [interface.accept(img) for img in images]
>>> valid_contexts = [c for c in contexts if interface.validate(c)]
>>> normalized_batch = [interface.normalize(c) for c in valid_contexts]

Example 4: Custom Input Handler (Hex Architecture)
>>> from yrsn.core.input_interface import InputInterface, ContextData
>>>
>>> class CustomVideoInterface(InputInterface):
>>>     '''Custom handler for video frames.'''
>>>
>>>     def accept(self, data: Any) -> ContextData:
>>>         # Extract frames from video
>>>         frames = extract_frames(data)
>>>         return ContextData(
>>>             data=frames,
>>>             format='video',
>>>             metadata={'fps': 30, 'duration': len(frames)/30}
>>>         )
>>>
>>>     def validate(self, context: ContextData) -> bool:
>>>         # Validate video properties
>>>         return len(context.data) > 0 and context.format == 'video'
>>>
>>>     def normalize(self, context: ContextData) -> NormalizedContext:
>>>         # Normalize video frames
>>>         frames_normalized = [normalize_frame(f) for f in context.data]
>>>         return NormalizedContext(data=frames_normalized, format='video')

INTEGRATION WITH EXISTING CODE:
-------------------------------
This module provides a formal wrapper around existing implementations:

1. frequency_rsn.FrequencyBasedRSN.compute_rsn(image)
   → Now accessible via StandardInputInterface for images

2. trained_projection.TrainedRSNProjection.compute_rsn(embeddings)
   → Now accessible via StandardInputInterface for embeddings

The existing implementations continue to work as before, but now there's
also a formal interface for new code.

FIRST PRINCIPLES COMPLIANCE:
----------------------------
✓ P1: Pure domain logic (input processing is domain logic)
✓ Hex architecture: Protocol (port) + StandardInputInterface (adapter)
✓ Testable: All methods pure (input → output)
✓ Patent §7.3: Formal implementation of Input Reception Module
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Union, List, Protocol, runtime_checkable
from enum import Enum
import numpy as np


# =============================================================================
# CONTEXT DATA STRUCTURES (Patent §7.3.3)
# =============================================================================

class InputFormat(str, Enum):
    """
    Supported input formats (Patent §7.3.2).

    The Input Reception Module accepts contextual data in various forms.
    """
    IMAGE = "image"              # Image data (HWC or CHW format)
    EMBEDDING = "embedding"      # Feature embeddings from models
    TEXT = "text"                # Raw text (requires encoding)
    MATRIX = "matrix"            # Arbitrary matrix/tensor
    MULTIMODAL = "multimodal"    # Mixed modalities
    UNKNOWN = "unknown"          # Format not yet determined


@dataclass
class ContextData:
    """
    Raw contextual input data (Patent §7.3.3).

    Output of InputInterface.accept() - represents validated input
    with detected format and metadata.

    Attributes:
        data: The actual input data (ndarray, tensor, text, etc)
        format: Detected input format
        metadata: Additional context (shape, dtype, source, etc)
        raw_input: Optional reference to original input
    """
    data: Any
    format: InputFormat
    metadata: Dict[str, Any] = field(default_factory=dict)
    raw_input: Optional[Any] = None


@dataclass
class NormalizedContext:
    """
    Normalized contextual data ready for decomposition (Patent §7.3.5).

    Output of InputInterface.normalize() - standardized representation
    suitable for R/S/N decomposition.

    Attributes:
        data: Normalized data (typically ndarray)
        format: Input format (preserved from ContextData)
        shape: Data shape after normalization
        dtype: Data type after normalization
        metadata: Carried-forward metadata
    """
    data: np.ndarray
    format: InputFormat
    shape: tuple
    dtype: np.dtype
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# INPUT INTERFACE PROTOCOL (Patent §7.3 - Port)
# =============================================================================

@runtime_checkable
class InputInterface(Protocol):
    """
    Input Reception Module Protocol (Patent §7.3).

    Defines the contract for accepting, validating, and normalizing
    contextual input data for decomposition processing.

    This is a Protocol (structural typing), enabling multiple implementations
    without inheritance. Aligns with hex architecture: this is a "port"
    that can have multiple "adapters" (implementations).

    Required Methods (Patent §7.3.2):
    - accept():    Accept raw input and detect format
    - validate():  Validate input meets processing requirements
    - normalize(): Normalize input for decomposition

    Patent Reference: §7.3.2 - Functional Requirements
    """

    def accept(self, data: Any) -> ContextData:
        """
        Accept raw contextual input and detect format (Patent §7.3.3).

        Args:
            data: Raw input data in arbitrary form (image, embedding, text, etc)

        Returns:
            ContextData with detected format and metadata

        Patent Reference: §7.3.3 - Input Processing
        """
        ...

    def validate(self, context: ContextData) -> bool:
        """
        Validate input meets processing requirements (Patent §7.3.4).

        Checks:
        - Format is supported
        - Shape is valid for decomposition
        - Data type is numeric
        - Range is appropriate ([0, 1] or [-1, 1])

        Args:
            context: ContextData to validate

        Returns:
            True if valid, False otherwise

        Patent Reference: §7.3.4 - Validation Rules
        """
        ...

    def normalize(self, context: ContextData) -> NormalizedContext:
        """
        Normalize input for decomposition processing (Patent §7.3.5).

        Standardizes:
        - Data type (float32)
        - Range ([0, 1] normalized)
        - Shape (consistent dimensions)
        - Format (ndarray)

        Args:
            context: ContextData to normalize

        Returns:
            NormalizedContext ready for decomposition

        Patent Reference: §7.3.5 - Normalization
        """
        ...


# =============================================================================
# STANDARD INPUT INTERFACE IMPLEMENTATION (Patent §7.3 - Adapter)
# =============================================================================

class StandardInputInterface:
    """
    Standard implementation of Input Reception Module (Patent §7.3).

    Provides format detection, validation, and normalization for common
    input types: images, embeddings, text, matrices.

    This is the default "adapter" for the InputInterface "port" in
    hexagonal architecture.

    Usage:
        interface = StandardInputInterface()

        # Accept input
        context = interface.accept(image)

        # Validate
        if interface.validate(context):
            # Normalize
            normalized = interface.normalize(context)
            # Ready for decomposition!

    Patent Compliance:
    - §7.3.2: Multi-format input acceptance
    - §7.3.3: Automatic format detection
    - §7.3.4: Validation rules enforced
    - §7.3.5: Normalization for decomposition
    """

    def __init__(self, strict_validation: bool = True):
        """
        Initialize standard input interface.

        Args:
            strict_validation: If True, enforce strict validation rules.
                               If False, allow some flexibility (e.g., auto-fix ranges).
        """
        self.strict_validation = strict_validation

    def accept(self, data: Any) -> ContextData:
        """
        Accept raw input and detect format (Patent §7.3.3).

        Automatic format detection:
        - ndarray with 2-4 dims → IMAGE
        - ndarray with 1-2 dims → EMBEDDING or MATRIX
        - str → TEXT
        - dict with multiple modalities → MULTIMODAL

        Args:
            data: Raw input data

        Returns:
            ContextData with detected format

        Patent Reference: §7.3.3 - Input Processing
        """
        metadata = {}

        # Detect format based on type and shape
        if isinstance(data, np.ndarray):
            metadata['shape'] = data.shape
            metadata['dtype'] = str(data.dtype)

            ndim = data.ndim
            if ndim >= 2 and ndim <= 4:
                # 2D: grayscale image, 3D: RGB image, 4D: batch of images
                format_type = InputFormat.IMAGE
                metadata['image_dims'] = ndim
            elif ndim == 1:
                # 1D: feature vector / embedding
                format_type = InputFormat.EMBEDDING
                metadata['embedding_dim'] = data.shape[0]
            else:
                # Arbitrary matrix
                format_type = InputFormat.MATRIX
                metadata['matrix_shape'] = data.shape

        elif isinstance(data, str):
            format_type = InputFormat.TEXT
            metadata['text_length'] = len(data)

        elif isinstance(data, dict) and 'image' in data and 'text' in data:
            format_type = InputFormat.MULTIMODAL
            metadata['modalities'] = list(data.keys())

        else:
            # Try to convert to ndarray
            try:
                data_arr = np.asarray(data)
                return self.accept(data_arr)  # Recurse with ndarray
            except (ValueError, TypeError):
                format_type = InputFormat.UNKNOWN

        return ContextData(
            data=data,
            format=format_type,
            metadata=metadata,
            raw_input=data
        )

    def validate(self, context: ContextData) -> bool:
        """
        Validate input meets processing requirements (Patent §7.3.4).

        Validation checks:
        1. Format is supported (not UNKNOWN)
        2. Data is numeric (for image/embedding/matrix)
        3. Shape is valid for decomposition
        4. Range is appropriate (finite values)

        Args:
            context: ContextData to validate

        Returns:
            True if valid, False otherwise

        Patent Reference: §7.3.4 - Validation Rules
        """
        # Check format is supported
        if context.format == InputFormat.UNKNOWN:
            return False

        # TEXT format: validate text exists
        if context.format == InputFormat.TEXT:
            return isinstance(context.data, str) and len(context.data) > 0

        # MULTIMODAL: validate each modality
        if context.format == InputFormat.MULTIMODAL:
            if not isinstance(context.data, dict):
                return False
            # Validate each modality recursively
            for key, value in context.data.items():
                sub_context = self.accept(value)
                if not self.validate(sub_context):
                    return False
            return True

        # Numeric formats: IMAGE, EMBEDDING, MATRIX
        if not isinstance(context.data, np.ndarray):
            try:
                context.data = np.asarray(context.data)
            except (ValueError, TypeError):
                return False

        data = context.data

        # Check data is numeric
        if not np.issubdtype(data.dtype, np.number):
            return False

        # Check for finite values (no inf/nan)
        if not np.all(np.isfinite(data)):
            return False

        # Format-specific validation
        if context.format == InputFormat.IMAGE:
            # Images: 2D, 3D, or 4D
            if data.ndim < 2 or data.ndim > 4:
                return False
            # Check reasonable image dimensions (not too large)
            if self.strict_validation:
                max_dim = 4096  # 4K resolution
                if any(dim > max_dim for dim in data.shape):
                    return False

        elif context.format == InputFormat.EMBEDDING:
            # Embeddings: 1D or 2D (batch)
            if data.ndim < 1 or data.ndim > 2:
                return False
            # Check reasonable embedding dimension
            if self.strict_validation:
                max_embed_dim = 10000
                embed_dim = data.shape[-1]
                if embed_dim > max_embed_dim:
                    return False

        elif context.format == InputFormat.MATRIX:
            # Matrix: any dimensionality, but check size
            if self.strict_validation:
                max_elements = 10_000_000  # 10M elements
                if data.size > max_elements:
                    return False

        return True

    def normalize(self, context: ContextData) -> NormalizedContext:
        """
        Normalize input for decomposition (Patent §7.3.5).

        Normalization steps:
        1. Convert to ndarray (float32)
        2. Normalize range to [0, 1]
        3. Standardize shape format
        4. Preserve metadata

        Args:
            context: ContextData to normalize

        Returns:
            NormalizedContext ready for decomposition

        Raises:
            ValueError: If context fails validation

        Patent Reference: §7.3.5 - Normalization
        """
        # Validate first
        if not self.validate(context):
            raise ValueError(f"Invalid context: format={context.format}, "
                           f"data type={type(context.data)}")

        # Handle TEXT: requires encoding (not implemented here, would need model)
        if context.format == InputFormat.TEXT:
            raise NotImplementedError(
                "Text normalization requires embedding model. "
                "Please encode text to embeddings first, then pass to interface."
            )

        # Handle MULTIMODAL: normalize each modality
        if context.format == InputFormat.MULTIMODAL:
            normalized_modalities = {}
            for key, value in context.data.items():
                sub_context = self.accept(value)
                normalized_sub = self.normalize(sub_context)
                normalized_modalities[key] = normalized_sub

            # For multimodal, return first modality as primary
            # (In practice, would need modality fusion strategy)
            primary_key = list(normalized_modalities.keys())[0]
            primary = normalized_modalities[primary_key]
            primary.metadata['multimodal_keys'] = list(normalized_modalities.keys())
            return primary

        # Convert to ndarray
        data = np.asarray(context.data, dtype=np.float32)

        # Normalize range to [0, 1]
        data_min = data.min()
        data_max = data.max()

        if data_max - data_min > 1e-8:  # Avoid division by zero
            # Check if already in [0, 1]
            if data_min >= 0.0 and data_max <= 1.0:
                data_normalized = data  # Already normalized
            # Check if in [0, 255] (typical image range)
            elif data_min >= 0.0 and data_max <= 255.0:
                data_normalized = data / 255.0
            # Check if in [-1, 1] (some embeddings)
            elif data_min >= -1.0 and data_max <= 1.0:
                data_normalized = (data + 1.0) / 2.0  # Map to [0, 1]
            else:
                # General case: min-max normalization
                data_normalized = (data - data_min) / (data_max - data_min)
        else:
            # Constant value: set to 0.5 (middle of [0, 1])
            data_normalized = np.full_like(data, 0.5, dtype=np.float32)

        # Create normalized context
        return NormalizedContext(
            data=data_normalized,
            format=context.format,
            shape=data_normalized.shape,
            dtype=data_normalized.dtype,
            metadata={
                **context.metadata,
                'normalized': True,
                'original_range': (float(data_min), float(data_max)),
            }
        )


# =============================================================================
# BATCH PROCESSING UTILITIES (Patent §7.3.8)
# =============================================================================

def accept_batch(interface: InputInterface,
                 batch: List[Any]) -> List[ContextData]:
    """
    Accept batch of inputs (Patent §7.3.8 - Batched Processing).

    Args:
        interface: InputInterface implementation
        batch: List of raw inputs

    Returns:
        List of ContextData

    Example:
        >>> images = [img1, img2, img3]
        >>> contexts = accept_batch(interface, images)
    """
    return [interface.accept(data) for data in batch]


def validate_batch(interface: InputInterface,
                   contexts: List[ContextData]) -> List[bool]:
    """
    Validate batch of contexts.

    Args:
        interface: InputInterface implementation
        contexts: List of ContextData

    Returns:
        List of validation results (True/False)

    Example:
        >>> valid_flags = validate_batch(interface, contexts)
        >>> valid_contexts = [c for c, v in zip(contexts, valid_flags) if v]
    """
    return [interface.validate(context) for context in contexts]


def normalize_batch(interface: InputInterface,
                    contexts: List[ContextData]) -> List[NormalizedContext]:
    """
    Normalize batch of contexts (Patent §7.3.8).

    Args:
        interface: InputInterface implementation
        contexts: List of ContextData

    Returns:
        List of NormalizedContext

    Example:
        >>> normalized = normalize_batch(interface, contexts)
    """
    return [interface.normalize(context) for context in contexts]


def process_batch(interface: InputInterface,
                  batch: List[Any],
                  skip_invalid: bool = True) -> List[NormalizedContext]:
    """
    Complete batch processing pipeline (Patent §7.3).

    Convenience function: accept → validate → normalize.

    Args:
        interface: InputInterface implementation
        batch: List of raw inputs
        skip_invalid: If True, skip invalid inputs. If False, raise on invalid.

    Returns:
        List of NormalizedContext for valid inputs

    Example:
        >>> images = [img1, img2, img3]
        >>> normalized = process_batch(interface, images)
        >>> # Ready for decomposition!
    """
    contexts = accept_batch(interface, batch)

    if skip_invalid:
        # Filter to valid contexts only
        valid_contexts = [c for c in contexts if interface.validate(c)]
    else:
        # Validate all, raise if any invalid
        valid_flags = validate_batch(interface, contexts)
        if not all(valid_flags):
            invalid_indices = [i for i, v in enumerate(valid_flags) if not v]
            raise ValueError(f"Invalid inputs at indices: {invalid_indices}")
        valid_contexts = contexts

    return normalize_batch(interface, valid_contexts)


# =============================================================================
# STREAMING INPUT SUPPORT (Patent §7.3.8)
# =============================================================================

@dataclass
class StreamState:
    """
    Stream state for continuous input processing (Patent §7.3.8.2).

    Maintains state for streaming inputs including buffer management,
    timing information, and cumulative statistics.

    Attributes:
        stream_id: Unique identifier for the stream
        buffer: Accumulated items not yet processed
        last_processed_timestamp: Timestamp of last processed window
        window_count: Number of windows processed
        cumulative_statistics: Running statistics of stream
        created_at: Stream creation timestamp
        total_items_received: Total items received since stream start

    Patent Reference: §7.3.8.2 - Stream State Management
    """
    stream_id: str
    buffer: List[Any] = field(default_factory=list)
    last_processed_timestamp: Optional[float] = None
    window_count: int = 0
    cumulative_statistics: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=lambda: __import__('time').time())
    total_items_received: int = 0

    def add_item(self, item: Any) -> None:
        """Add an item to the buffer."""
        self.buffer.append(item)
        self.total_items_received += 1

    def clear_buffer(self, keep_last_n: int = 0) -> None:
        """Clear buffer, optionally keeping last N items for overlap."""
        if keep_last_n > 0 and len(self.buffer) >= keep_last_n:
            self.buffer = self.buffer[-keep_last_n:]
        else:
            self.buffer = []

    def update_statistics(self, key: str, value: Any) -> None:
        """Update cumulative statistics."""
        self.cumulative_statistics[key] = value


@dataclass
class StreamWindow:
    """
    A window of data extracted from a continuous stream (Patent §7.3.8.1).

    Represents a segment of continuous stream data for processing.

    Attributes:
        window_id: Unique identifier for this window
        stream_id: Parent stream identifier
        data: Items in this window
        window_index: Sequential window number
        start_timestamp: When first item in window was received
        end_timestamp: When last item in window was received
        overlap_items: Number of items shared with previous window

    Patent Reference: §7.3.8.1 - Stream Windowing
    """
    window_id: str
    stream_id: str
    data: List[Any]
    window_index: int
    start_timestamp: float
    end_timestamp: float
    overlap_items: int = 0

    @property
    def size(self) -> int:
        """Number of items in window."""
        return len(self.data)

    @property
    def duration(self) -> float:
        """Window duration in seconds."""
        return self.end_timestamp - self.start_timestamp


def stream_windowing(
    stream: List[Any],
    window_size: int,
    overlap: int = 0,
    stream_id: str = "default"
) -> List[StreamWindow]:
    """
    Segment continuous streams into windows for processing (Patent §7.3.8.1).

    This function implements the windowing algorithm from the patent spec,
    segmenting a continuous stream into overlapping or non-overlapping windows.

    Args:
        stream: List of items from continuous stream
        window_size: Number of items per window
        overlap: Number of items to overlap between windows (default 0)
        stream_id: Identifier for the stream

    Returns:
        List of StreamWindow objects

    Example:
        >>> items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        >>> windows = stream_windowing(items, window_size=4, overlap=2)
        >>> len(windows)
        4
        >>> windows[0].data
        [1, 2, 3, 4]
        >>> windows[1].data
        [3, 4, 5, 6]

    Patent Reference: §7.3.8.1 - Stream Windowing

    Algorithm from patent spec:
        for item in stream:
            buffer.append(item)
            if len(buffer) >= window_size:
                window = buffer[-window_size:]
                windows.append(window)
                buffer = buffer[-(window_size - overlap):]  # retain overlap
    """
    import time
    import uuid

    if window_size <= 0:
        raise ValueError("window_size must be positive")
    if overlap < 0 or overlap >= window_size:
        raise ValueError("overlap must be >= 0 and < window_size")

    windows = []
    buffer = []
    window_index = 0
    current_time = time.time()

    step = window_size - overlap

    for i, item in enumerate(stream):
        buffer.append(item)

        if len(buffer) >= window_size:
            # Extract window
            window_data = buffer[-window_size:]

            window = StreamWindow(
                window_id=f"{stream_id}_{window_index}_{uuid.uuid4().hex[:8]}",
                stream_id=stream_id,
                data=window_data.copy(),
                window_index=window_index,
                start_timestamp=current_time + (i - window_size + 1) * 0.001,
                end_timestamp=current_time + i * 0.001,
                overlap_items=overlap if window_index > 0 else 0
            )
            windows.append(window)
            window_index += 1

            # Retain overlap for next window
            if overlap > 0:
                buffer = buffer[-overlap:]
            else:
                buffer = []

    return windows


class StreamingInputInterface:
    """
    Streaming input interface for continuous data (Patent §7.3.8).

    Extends the standard input interface with streaming capabilities:
    - Windowing for continuous streams
    - State management across windows
    - Cumulative statistics tracking

    This class wraps StandardInputInterface and adds streaming-specific
    functionality for handling continuous sensor data, real-time feeds,
    and other streaming input sources.

    Usage:
        >>> interface = StreamingInputInterface(window_size=100, overlap=20)
        >>>
        >>> # Feed continuous data
        >>> for sensor_reading in sensor_stream:
        ...     windows = interface.feed(sensor_reading)
        ...     for window in windows:
        ...         # Process each complete window
        ...         normalized = interface.process_window(window)
        >>>
        >>> # Get final incomplete window if needed
        >>> final_window = interface.flush()

    Patent Reference: §7.3.8 - Streaming Input Support
    """

    def __init__(
        self,
        window_size: int = 100,
        overlap: int = 0,
        stream_id: Optional[str] = None,
        strict_validation: bool = True
    ):
        """
        Initialize streaming input interface.

        Args:
            window_size: Number of items per window
            overlap: Number of items to overlap between windows
            stream_id: Optional stream identifier (auto-generated if not provided)
            strict_validation: Enable strict validation rules

        Patent Reference: §7.3.8 - Streaming Input Support
        """
        import uuid

        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if overlap < 0 or overlap >= window_size:
            raise ValueError("overlap must be >= 0 and < window_size")

        self._window_size = window_size
        self._overlap = overlap
        self._base_interface = StandardInputInterface(strict_validation=strict_validation)

        # Initialize stream state (§7.3.8.2)
        self._state = StreamState(
            stream_id=stream_id or f"stream_{uuid.uuid4().hex[:8]}"
        )

    @property
    def stream_id(self) -> str:
        """Get stream identifier."""
        return self._state.stream_id

    @property
    def state(self) -> StreamState:
        """Get current stream state."""
        return self._state

    @property
    def window_size(self) -> int:
        """Get window size."""
        return self._window_size

    @property
    def overlap(self) -> int:
        """Get overlap size."""
        return self._overlap

    @property
    def buffer_size(self) -> int:
        """Get current buffer size."""
        return len(self._state.buffer)

    def feed(self, item: Any) -> List[StreamWindow]:
        """
        Feed a single item into the stream (Patent §7.3.8).

        Adds item to buffer and returns any complete windows.

        Args:
            item: Single input item (sensor reading, data point, etc.)

        Returns:
            List of complete StreamWindow objects (may be empty)

        Example:
            >>> interface = StreamingInputInterface(window_size=4, overlap=1)
            >>> for i in range(10):
            ...     windows = interface.feed(i)
            ...     if windows:
            ...         print(f"Window ready: {windows[0].data}")
        """
        import time
        import uuid

        self._state.add_item(item)
        windows = []

        # Check if we have a complete window
        if len(self._state.buffer) >= self._window_size:
            window_data = self._state.buffer[-self._window_size:]
            current_time = time.time()

            window = StreamWindow(
                window_id=f"{self._state.stream_id}_{self._state.window_count}_{uuid.uuid4().hex[:8]}",
                stream_id=self._state.stream_id,
                data=window_data.copy(),
                window_index=self._state.window_count,
                start_timestamp=self._state.last_processed_timestamp or current_time,
                end_timestamp=current_time,
                overlap_items=self._overlap if self._state.window_count > 0 else 0
            )
            windows.append(window)

            # Update state
            self._state.window_count += 1
            self._state.last_processed_timestamp = current_time
            self._state.clear_buffer(keep_last_n=self._overlap)

        return windows

    def feed_batch(self, items: List[Any]) -> List[StreamWindow]:
        """
        Feed multiple items into the stream.

        Args:
            items: List of input items

        Returns:
            List of complete StreamWindow objects
        """
        all_windows = []
        for item in items:
            windows = self.feed(item)
            all_windows.extend(windows)
        return all_windows

    def flush(self) -> Optional[StreamWindow]:
        """
        Flush remaining buffer as partial window.

        Call this at end of stream to get any remaining items
        that don't form a complete window.

        Returns:
            StreamWindow with remaining items, or None if buffer empty
        """
        import time
        import uuid

        if not self._state.buffer:
            return None

        current_time = time.time()
        window = StreamWindow(
            window_id=f"{self._state.stream_id}_{self._state.window_count}_partial_{uuid.uuid4().hex[:8]}",
            stream_id=self._state.stream_id,
            data=self._state.buffer.copy(),
            window_index=self._state.window_count,
            start_timestamp=self._state.last_processed_timestamp or current_time,
            end_timestamp=current_time,
            overlap_items=0
        )

        self._state.buffer = []
        return window

    def process_window(self, window: StreamWindow) -> List[NormalizedContext]:
        """
        Process a window through the standard input interface.

        Args:
            window: StreamWindow to process

        Returns:
            List of NormalizedContext for each item in window
        """
        return process_batch(self._base_interface, window.data, skip_invalid=True)

    def reset(self) -> None:
        """Reset stream state for new stream."""
        import uuid

        self._state = StreamState(
            stream_id=f"stream_{uuid.uuid4().hex[:8]}"
        )

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get cumulative stream statistics.

        Returns:
            Dictionary with stream statistics
        """
        return {
            'stream_id': self._state.stream_id,
            'total_items_received': self._state.total_items_received,
            'windows_processed': self._state.window_count,
            'buffer_size': len(self._state.buffer),
            'window_size': self._window_size,
            'overlap': self._overlap,
            'created_at': self._state.created_at,
            'last_processed': self._state.last_processed_timestamp,
            **self._state.cumulative_statistics
        }


def create_streaming_interface(
    window_size: int = 100,
    overlap: int = 0,
    stream_id: Optional[str] = None,
    strict: bool = True
) -> StreamingInputInterface:
    """
    Factory function for creating streaming input interface.

    Args:
        window_size: Number of items per window
        overlap: Number of items to overlap between windows
        stream_id: Optional stream identifier
        strict: Enable strict validation rules

    Returns:
        StreamingInputInterface instance

    Example:
        >>> interface = create_streaming_interface(window_size=50, overlap=10)
        >>> for reading in sensor_data:
        ...     windows = interface.feed(reading)
    """
    return StreamingInputInterface(
        window_size=window_size,
        overlap=overlap,
        stream_id=stream_id,
        strict_validation=strict
    )


# =============================================================================
# CONVENIENCE FACTORY
# =============================================================================

def create_input_interface(strict: bool = True) -> InputInterface:
    """
    Factory function for creating standard input interface.

    Args:
        strict: Enable strict validation rules

    Returns:
        InputInterface implementation (StandardInputInterface)

    Example:
        >>> interface = create_input_interface()
        >>> context = interface.accept(image)
    """
    return StandardInputInterface(strict_validation=strict)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Enums
    'InputFormat',

    # Data structures
    'ContextData',
    'NormalizedContext',

    # Protocol (port)
    'InputInterface',

    # Implementation (adapter)
    'StandardInputInterface',

    # Batch utilities
    'accept_batch',
    'validate_batch',
    'normalize_batch',
    'process_batch',

    # Streaming support (§7.3.8)
    'StreamState',
    'StreamWindow',
    'StreamingInputInterface',
    'stream_windowing',
    'create_streaming_interface',

    # Factory
    'create_input_interface',
]
