"""
YRSN Gearbox Calibrator - Learn Gear Thresholds from Data

Follows the YRSN principle: "the system adapts to whatever data it encounters."

The Problem:
    Hardcoded tau thresholds (0, 1.0, 1.43, 2.5, inf) don't match actual
    rotor output distributions. Result: all samples end up in 4th gear.

The Solution:
    Observe tau distribution during warmup, compute percentile-based
    thresholds, apply calibrated boundaries to gearbox.

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    GearboxCalibrator                            │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
    │  │ observe_tau  │    │  calibrate   │    │  boundaries  │      │
    │  │ (warmup)     │───►│ (percentiles)│───►│  (frozen)    │      │
    │  └──────────────┘    └──────────────┘    └──────────────┘      │
    │         │                   │                   │               │
    │         ▼                   ▼                   ▼               │
    │  Collect tau          Compute q25,q50,q75   Apply to gearbox   │
    │  until N samples      with guardrails       for tau→gear map   │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘

Usage:
    from yrsn.core.gearbox.gearbox_calibrator import (
        GearboxCalibrator,
        GearboxCalibrationConfig,
    )

    calibrator = GearboxCalibrator()

    # During warmup
    for cert in certificates:
        calibrator.observe_tau(cert.tau)

    # Calibrate when ready
    if calibrator.ready():
        result = calibrator.calibrate()
        print(f"Boundaries: {result.boundaries}")

Reference:
    Mirrors patterns from:
    - core/decomposition/calibration_manager.py
    - hardware/adaptive_calibration.py
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple, Dict
import math
import time


@dataclass(frozen=True)
class GearboxCalibrationConfig:
    """
    Configuration for gearbox calibration.

    Attributes:
        enabled: Whether calibration is active
        warmup_samples: Minimum tau samples before calibration
        quantiles: Percentile boundaries (b1, b2, b3) for 4 gears
        winsor_limits: Outlier clipping percentiles (lo, hi)
        min_gap: Minimum separation between boundaries
    """
    enabled: bool = True

    # Warmup
    warmup_samples: int = 512

    # Quantile boundaries between gears (b1, b2, b3)
    # Default: equal population per gear (25% each)
    quantiles: Tuple[float, float, float] = (0.25, 0.50, 0.75)

    # Winsorize tau to avoid extreme outliers dominating
    winsor_limits: Tuple[float, float] = (0.01, 0.99)

    # Minimum separation between boundaries to avoid degenerate thresholds
    min_gap: float = 1e-6


@dataclass(frozen=True)
class GearboxCalibrationResult:
    """
    Result of gearbox calibration.

    Attributes:
        created_at_unix: Timestamp of calibration
        n_seen: Number of tau samples observed
        tau_min: Minimum observed tau
        tau_max: Maximum observed tau
        q_values: Dictionary of quantile values
        boundaries: Tuple (b1, b2, b3) defining gear ranges:
            - 1st gear: (-inf, b1]
            - 2nd gear: (b1, b2]
            - 3rd gear: (b2, b3]
            - 4th gear: (b3, +inf)
    """
    created_at_unix: float
    n_seen: int
    tau_min: float
    tau_max: float
    q_values: Dict[str, float]
    boundaries: Tuple[float, float, float]

    def to_dict(self) -> Dict:
        """Serialize for logging/saving."""
        return asdict(self)

    def describe(self) -> str:
        """Human-readable summary."""
        b1, b2, b3 = self.boundaries
        return (
            f"GearboxCalibration(n={self.n_seen}, "
            f"tau=[{self.tau_min:.2f}, {self.tau_max:.2f}], "
            f"boundaries=[{b1:.2f}, {b2:.2f}, {b3:.2f}])"
        )


class GearboxCalibrator:
    """
    Observe tau during warmup. Compute calibrated gear boundaries from tau quantiles.

    Mirrors existing YRSN calibration style: observe -> calibrate -> freeze/apply.

    Lifecycle:
        1. WARMUP: observe_tau() collects samples
        2. READY: ready() returns True when enough samples
        3. CALIBRATED: calibrate() computes boundaries, freezes state

    Example:
        >>> calibrator = GearboxCalibrator()
        >>> for tau in tau_values:
        ...     calibrator.observe_tau(tau)
        >>> if calibrator.ready():
        ...     result = calibrator.calibrate()
        ...     print(result.boundaries)
    """

    def __init__(self, cfg: Optional[GearboxCalibrationConfig] = None):
        """
        Initialize calibrator.

        Args:
            cfg: Configuration (uses defaults if None)
        """
        self.cfg = cfg or GearboxCalibrationConfig()
        self._taus: List[float] = []
        self._result: Optional[GearboxCalibrationResult] = None

    @property
    def is_enabled(self) -> bool:
        """Whether calibration is enabled."""
        return bool(self.cfg.enabled)

    @property
    def is_calibrated(self) -> bool:
        """Whether calibration has been performed."""
        return self._result is not None

    @property
    def n_seen(self) -> int:
        """Number of tau samples observed."""
        return len(self._taus) if not self.is_calibrated else self._result.n_seen

    def observe_tau(self, tau: float) -> None:
        """
        Add a tau observation during warmup.

        Args:
            tau: Temperature value from certificate

        Note:
            Silently ignores if disabled, already calibrated, or invalid tau.
        """
        if not self.is_enabled or self.is_calibrated:
            return
        if tau is None or not math.isfinite(tau):
            return
        self._taus.append(float(tau))

    def observe_certificate(self, cert) -> None:
        """
        Add observation from a YRSNCertificate.

        Args:
            cert: Certificate with .tau attribute
        """
        tau = getattr(cert, 'tau', None)
        if tau is not None:
            self.observe_tau(tau)

    def ready(self) -> bool:
        """
        Check if enough samples for calibration.

        Returns:
            True if enabled, not yet calibrated, and sufficient samples
        """
        return (
            self.is_enabled
            and (not self.is_calibrated)
            and len(self._taus) >= int(self.cfg.warmup_samples)
        )

    def get_result(self) -> Optional[GearboxCalibrationResult]:
        """Get calibration result (None if not calibrated)."""
        return self._result

    def calibrate(self) -> GearboxCalibrationResult:
        """
        Compute calibrated gear boundaries from observed tau distribution.

        Uses percentile-based thresholds with guardrails:
        1. Winsorize outliers
        2. Compute quantiles
        3. Enforce monotonicity and minimum gaps

        Returns:
            GearboxCalibrationResult with boundaries

        Raises:
            RuntimeError: If disabled, already calibrated, or insufficient samples
        """
        if not self.is_enabled:
            raise RuntimeError("GearboxCalibrator is disabled.")
        if self.is_calibrated:
            return self._result  # type: ignore[return-value]
        if len(self._taus) < max(16, int(self.cfg.warmup_samples)):
            raise RuntimeError(
                f"Not enough tau samples to calibrate: {len(self._taus)} < {self.cfg.warmup_samples}"
            )

        taus_sorted = sorted(self._taus)

        def q(p: float) -> float:
            """Compute quantile with linear interpolation."""
            if p <= 0.0:
                return taus_sorted[0]
            if p >= 1.0:
                return taus_sorted[-1]
            idx = p * (len(taus_sorted) - 1)
            lo = int(math.floor(idx))
            hi = int(math.ceil(idx))
            if lo == hi:
                return taus_sorted[lo]
            frac = idx - lo
            return taus_sorted[lo] * (1 - frac) + taus_sorted[hi] * frac

        # Winsorize: clip to percentile limits
        q_lo, q_hi = self.cfg.winsor_limits
        tau_lo = q(q_lo)
        tau_hi = q(q_hi)

        taus_w = [min(max(t, tau_lo), tau_hi) for t in taus_sorted]
        taus_sorted = sorted(taus_w)  # Recompute on winsorized

        # Compute quantile boundaries
        bq1, bq2, bq3 = self.cfg.quantiles
        b1 = q(bq1)
        b2 = q(bq2)
        b3 = q(bq3)

        # Guardrails: ensure finite
        b1, b2, b3 = float(b1), float(b2), float(b3)
        if not (math.isfinite(b1) and math.isfinite(b2) and math.isfinite(b3)):
            raise RuntimeError("Calibration produced non-finite boundaries.")

        # Guardrails: ensure monotonic
        if not (b1 < b2 < b3):
            # Fallback: spread around median if quantiles collapse
            med = q(0.5)
            eps = max(self.cfg.min_gap, 1e-3)
            b1, b2, b3 = med - 2 * eps, med, med + 2 * eps

        # Guardrails: ensure minimum gaps
        if (b2 - b1) < self.cfg.min_gap:
            b2 = b1 + self.cfg.min_gap
        if (b3 - b2) < self.cfg.min_gap:
            b3 = b2 + self.cfg.min_gap

        # Build result
        result = GearboxCalibrationResult(
            created_at_unix=time.time(),
            n_seen=len(self._taus),
            tau_min=min(self._taus),
            tau_max=max(self._taus),
            q_values={
                f"q{int(bq1*100):02d}": b1,
                f"q{int(bq2*100):02d}": b2,
                f"q{int(bq3*100):02d}": b3,
                f"q{int(q_lo*100):02d}": tau_lo,
                f"q{int(q_hi*100):02d}": tau_hi,
            },
            boundaries=(b1, b2, b3),
        )

        self._result = result
        return result

    def reset(self) -> None:
        """Reset calibrator to initial state (for recalibration)."""
        self._taus.clear()
        self._result = None


__all__ = [
    "GearboxCalibrationConfig",
    "GearboxCalibrationResult",
    "GearboxCalibrator",
]
