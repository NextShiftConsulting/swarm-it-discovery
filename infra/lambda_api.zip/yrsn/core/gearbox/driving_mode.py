"""
YRSN Gearbox - Driving Mode Configurations

Defines the three driving modes that control gear shifting behavior:
- SPORT: Aggressive shifting, minimal hysteresis, low-latency edge robotics
- ECO: Conservative shifting, wider hysteresis, high-reliability medical AI
- MANUAL: No auto-shifting, explicit control for research/debugging

Each mode configures:
- Hysteresis: τ buffer before shifting (prevents "gear hunting")
- Upshift delay: Time before allowing upshift after quality improvement
- Downshift aggression: How quickly to downshift on quality degradation

Reference:
    Commercial value in docs/CIP_03_PLATFORM_ARCHITECTURE.md
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict


class DrivingMode(Enum):
    """
    Driving modes controlling gear shifting behavior.

    SPORT: Aggressive, fast-responding for edge/robotics (< 5ms latency)
    ECO: Conservative, stability-focused for medical/safety-critical
    MANUAL: Explicit control only, no auto-shifting
    """
    SPORT = "sport"
    ECO = "eco"
    MANUAL = "manual"


@dataclass(frozen=True)
class DrivingModeConfig:
    """
    Configuration for a driving mode's shifting behavior.

    Attributes:
        mode: The driving mode
        hysteresis: τ buffer before shifting (larger = less frequent shifts)
        upshift_delay: Seconds to wait before upshifting (stability check)
        downshift_aggression: 0-1, how quickly to downshift on quality drop
            0.0 = never auto-downshift
            0.5 = moderate responsiveness
            1.0 = immediate downshift on any quality drop

    Note:
        These values are tuned for the τ thresholds:
        - 1st: τ < 1.0
        - 2nd: τ ∈ [1.0, 1.43)
        - 3rd: τ ∈ [1.43, 2.5)
        - 4th: τ ≥ 2.5
    """
    mode: DrivingMode
    hysteresis: float           # τ buffer before shifting
    upshift_delay: float        # Seconds to wait before upshifting
    downshift_aggression: float # 0-1, how quickly to downshift

    def effective_threshold(self, base_threshold: float, direction: str) -> float:
        """
        Compute effective threshold with hysteresis.

        Args:
            base_threshold: The base τ threshold (e.g., 1.43 for 3rd gear)
            direction: "up" for upshift, "down" for downshift

        Returns:
            Adjusted threshold with hysteresis buffer
        """
        if direction == "up":
            # Need to exceed threshold + hysteresis to upshift
            return base_threshold + self.hysteresis
        else:
            # Need to drop below threshold - hysteresis to downshift
            return base_threshold - self.hysteresis


# =============================================================================
# Standard Driving Mode Configurations
# =============================================================================

DRIVING_MODE_CONFIGS: Dict[DrivingMode, DrivingModeConfig] = {
    DrivingMode.SPORT: DrivingModeConfig(
        mode=DrivingMode.SPORT,
        hysteresis=0.05,          # Minimal buffer, shift at boundaries
        upshift_delay=0.0,        # No delay, immediate upshift
        downshift_aggression=1.0, # Immediate downshift on quality drop
    ),

    DrivingMode.ECO: DrivingModeConfig(
        mode=DrivingMode.ECO,
        hysteresis=0.2,           # Wide buffer, stable gear selection
        upshift_delay=2.0,        # 2 seconds of stable quality before upshift
        downshift_aggression=0.5, # Moderate downshift responsiveness
    ),

    DrivingMode.MANUAL: DrivingModeConfig(
        mode=DrivingMode.MANUAL,
        hysteresis=float('inf'),  # Never auto-shift
        upshift_delay=float('inf'),
        downshift_aggression=0.0, # Never auto-downshift
    ),
}


def get_driving_mode_config(mode: DrivingMode) -> DrivingModeConfig:
    """Get the configuration for a driving mode."""
    return DRIVING_MODE_CONFIGS[mode]


def is_auto_shift_enabled(mode: DrivingMode) -> bool:
    """Check if auto-shifting is enabled for this mode."""
    return mode != DrivingMode.MANUAL


__all__ = [
    "DrivingMode",
    "DrivingModeConfig",
    "DRIVING_MODE_CONFIGS",
    "get_driving_mode_config",
    "is_auto_shift_enabled",
]
