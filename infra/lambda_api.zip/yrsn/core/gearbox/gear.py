"""
YRSN Gearbox - Gear Definitions

Defines the 5 fixed gears of the Dimensional Gearbox:
- 1st (Precision): Gradient engine, (α, ω) quality slice, τ < 1.0
- 2nd (Balanced): Gradient engine, (θ, φ, α) 3D view, 1.0 ≤ τ < 1.43
- 3rd (Explore): Eggroll engine, (θ, φ) polar slice, 1.43 ≤ τ < 2.5
- 4th (Discovery): Eggroll engine, full T⁴, τ ≥ 2.5
- R (Reverse): Eggroll engine, (α, ω) recovery slice, any τ

Each gear represents a complete operating mode: (Engine, View, τ-range).

Reference:
    docs/CIP_03_PLATFORM_ARCHITECTURE.md
    Temperature thresholds from core/optimization/adaptive_backend.py
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Tuple, Literal, Optional


@dataclass(frozen=True)
class DimensionalView:
    """
    Specification for a dimensional slice/projection of T⁴ space.

    Attributes:
        dimensions: Tuple of dimension names to include in view
        projection_type: How to handle the view
            - "slice": Fixed values for excluded dimensions
            - "projection": Project onto subspace (no fixed dims)
            - "full": All 4 dimensions (T⁴)
        fixed_dims: Values for dimensions not in view (for slices)

    Example:
        # 2D quality slice
        view = DimensionalView(
            dimensions=("alpha", "omega"),
            projection_type="slice",
            fixed_dims={"simplex_theta": 180.0, "phi_simplex": 180.0}
        )
    """
    dimensions: Tuple[str, ...]
    projection_type: Literal["slice", "projection", "full"]
    fixed_dims: Dict[str, float] = field(default_factory=dict)

    @property
    def ndim(self) -> int:
        """Number of dimensions in this view."""
        return len(self.dimensions)

    def __post_init__(self):
        """Validate dimension names."""
        valid_dims = {"simplex_theta", "phi_simplex", "alpha", "omega"}
        for dim in self.dimensions:
            if dim not in valid_dims:
                raise ValueError(f"Invalid dimension '{dim}'. Must be one of {valid_dims}")


class Gear(Enum):
    """
    Available gears in the Dimensional Gearbox.

    Gear progression represents exploration vs exploitation tradeoff:
    - Lower gears (1st, 2nd): Exploitation, gradient-based, quality focus
    - Higher gears (3rd, 4th): Exploration, evolutionary, broader search
    - Reverse (R): Recovery mode for topological collapse
    """
    FIRST = "1st"       # Precision: fine-tuning in known good regime
    SECOND = "2nd"      # Balanced: guided refinement with spatial awareness
    THIRD = "3rd"       # Explore: boundary exploration
    FOURTH = "4th"      # Discovery: full T⁴ exploration for novel territory
    REVERSE = "R"       # Recovery: collapse recovery mode

    @property
    def is_exploitation(self) -> bool:
        """Returns True if this gear favors exploitation."""
        return self in (Gear.FIRST, Gear.SECOND)

    @property
    def is_exploration(self) -> bool:
        """Returns True if this gear favors exploration."""
        return self in (Gear.THIRD, Gear.FOURTH)

    @property
    def ordinal(self) -> int:
        """Numeric order for comparison (R = -1)."""
        order = {
            Gear.REVERSE: -1,
            Gear.FIRST: 1,
            Gear.SECOND: 2,
            Gear.THIRD: 3,
            Gear.FOURTH: 4,
        }
        return order[self]


@dataclass(frozen=True)
class GearSpec:
    """
    Complete specification for a gear's operating mode.

    Attributes:
        name: Human-readable gear name
        engine: Optimization backend ("gradient" or "eggroll")
        view: Dimensional view/slice for this gear
        tau_range: (min, max) temperature range for this gear
        description: Brief description of use case

    Note:
        Engine selection aligns with AdaptiveBackend thresholds:
        - Gradient: τ ≤ 1.43 (exploitation, deterministic)
        - Eggroll: τ > 1.43 (exploration, stochastic)
    """
    name: str
    engine: Literal["gradient", "eggroll", "hybrid"]
    view: DimensionalView
    tau_range: Tuple[float, float]  # (min, max)
    description: str

    @property
    def tau_min(self) -> float:
        """Minimum temperature for this gear."""
        return self.tau_range[0]

    @property
    def tau_max(self) -> float:
        """Maximum temperature for this gear."""
        return self.tau_range[1]

    def contains_tau(self, tau: float) -> bool:
        """Check if temperature falls within this gear's range."""
        return self.tau_min <= tau < self.tau_max


# =============================================================================
# Standard Gear Configurations (Fixed)
# =============================================================================

GEAR_SPECS: Dict[Gear, GearSpec] = {
    Gear.FIRST: GearSpec(
        name="1st (Precision)",
        engine="gradient",
        view=DimensionalView(
            dimensions=("alpha", "omega"),
            projection_type="slice",
            fixed_dims={"simplex_theta": 180.0, "phi_simplex": 180.0},
        ),
        tau_range=(0.0, 1.0),
        description="Fine-tuning in high-quality regime (α > 0.7)",
    ),

    Gear.SECOND: GearSpec(
        name="2nd (Balanced)",
        engine="gradient",
        view=DimensionalView(
            dimensions=("simplex_theta", "phi_simplex", "alpha"),
            projection_type="projection",
        ),
        tau_range=(1.0, 1.43),
        description="Guided refinement with spatial awareness",
    ),

    Gear.THIRD: GearSpec(
        name="3rd (Explore)",
        engine="eggroll",
        view=DimensionalView(
            dimensions=("simplex_theta", "phi_simplex"),
            projection_type="slice",
            fixed_dims={"alpha": 90.0, "omega": 90.0},
        ),
        tau_range=(1.43, 2.5),
        description="Boundary exploration in RSN polar plane",
    ),

    Gear.FOURTH: GearSpec(
        name="4th (Discovery)",
        engine="eggroll",
        view=DimensionalView(
            dimensions=("simplex_theta", "phi_simplex", "alpha", "omega"),
            projection_type="full",
        ),
        tau_range=(2.5, float('inf')),
        description="Full T⁴ exploration for novel discovery",
    ),

    Gear.REVERSE: GearSpec(
        name="R (Recovery)",
        engine="eggroll",
        view=DimensionalView(
            dimensions=("alpha", "omega"),
            projection_type="slice",
            fixed_dims={"simplex_theta": 180.0, "phi_simplex": 180.0},
        ),
        tau_range=(0.0, float('inf')),  # Any tau - recovery overrides
        description="Collapse recovery mode (triggered by E101-E103)",
    ),
}


def get_gear_for_tau(tau: float, exclude_reverse: bool = True) -> Gear:
    """
    Get the appropriate gear for a given temperature.

    Args:
        tau: Current temperature (τ = 1/α typically)
        exclude_reverse: If True, don't return REVERSE (it's triggered by failures)

    Returns:
        Appropriate Gear for the temperature range
    """
    for gear, spec in GEAR_SPECS.items():
        if gear == Gear.REVERSE and exclude_reverse:
            continue
        if spec.contains_tau(tau):
            return gear

    # Fallback: if tau is very high, use FOURTH
    return Gear.FOURTH


def get_gear_spec(gear: Gear) -> GearSpec:
    """Get the specification for a gear."""
    return GEAR_SPECS[gear]


__all__ = [
    "DimensionalView",
    "Gear",
    "GearSpec",
    "GEAR_SPECS",
    "get_gear_for_tau",
    "get_gear_spec",
]
