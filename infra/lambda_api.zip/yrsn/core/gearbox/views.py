"""
YRSN Gearbox - Dimensional View Projections

Projects T⁴ coordinates (simplex_theta, phi_simplex, alpha, omega) to
lower-dimensional views based on the current gear's DimensionalView spec.

The ViewProjector handles:
- Project: T⁴ [N, 4] → View [N, k] where k ∈ {2, 3, 4}
- Embed: View [N, k] → T⁴ [N, 4] using fixed dimensions

Reference:
    T⁴ coordinates: src/yrsn/core/decomposition/geometric_utils.py
    Gear views: src/yrsn/core/gearbox/gear.py
"""

from typing import Optional, Dict, List
import numpy as np

from yrsn.core.gearbox.gear import DimensionalView


# Canonical dimension ordering for T⁴
T4_DIMENSIONS = ("simplex_theta", "phi_simplex", "alpha", "omega")
T4_DIM_INDEX = {dim: i for i, dim in enumerate(T4_DIMENSIONS)}


class ViewProjector:
    """
    Projects T⁴ coordinates to dimensional views and back.

    The projector extracts specified dimensions from full T⁴ coordinates
    and can embed lower-dimensional points back to T⁴ using fixed values.

    Example:
        >>> projector = ViewProjector()
        >>> t4 = np.array([[180, 90, 45, 30], [200, 100, 50, 40]])  # [N, 4]
        >>> view = DimensionalView(dimensions=("alpha", "omega"), projection_type="slice")
        >>> projected = projector.project(t4, view)  # [N, 2]
        >>> print(projected.shape)
        (2, 2)
    """

    @staticmethod
    def project(
        t4_coords: np.ndarray,
        view: DimensionalView,
    ) -> np.ndarray:
        """
        Project T⁴ coordinates to a dimensional view.

        Args:
            t4_coords: [N, 4] array of T⁴ coordinates
                       Order: (simplex_theta, phi_simplex, alpha, omega)
            view: DimensionalView specification

        Returns:
            [N, k] array where k = len(view.dimensions)

        Raises:
            ValueError: If t4_coords doesn't have shape [N, 4]
        """
        if t4_coords.ndim == 1:
            t4_coords = t4_coords.reshape(1, -1)

        if t4_coords.shape[1] != 4:
            raise ValueError(f"Expected T⁴ coordinates with shape [N, 4], got {t4_coords.shape}")

        if view.projection_type == "full":
            return t4_coords.copy()

        # Extract indices for requested dimensions
        indices = [T4_DIM_INDEX[dim] for dim in view.dimensions]
        return t4_coords[:, indices]

    @staticmethod
    def embed(
        projected: np.ndarray,
        view: DimensionalView,
        fixed_values: Optional[Dict[str, float]] = None,
    ) -> np.ndarray:
        """
        Embed projected coordinates back to T⁴.

        Args:
            projected: [N, k] array of projected coordinates
            view: DimensionalView that was used for projection
            fixed_values: Override values for fixed dimensions
                         If None, uses view.fixed_dims

        Returns:
            [N, 4] array of T⁴ coordinates

        Note:
            Missing dimensions are filled with:
            1. fixed_values if provided
            2. view.fixed_dims if available
            3. 0.0 as fallback
        """
        if projected.ndim == 1:
            projected = projected.reshape(1, -1)

        n_samples = projected.shape[0]

        if view.projection_type == "full":
            return projected.copy()

        # Merge fixed values
        final_fixed = dict(view.fixed_dims)
        if fixed_values:
            final_fixed.update(fixed_values)

        # Build output array
        t4_coords = np.zeros((n_samples, 4), dtype=projected.dtype)

        # Fill in projected dimensions
        for proj_idx, dim in enumerate(view.dimensions):
            t4_idx = T4_DIM_INDEX[dim]
            t4_coords[:, t4_idx] = projected[:, proj_idx]

        # Fill in fixed dimensions
        for dim in T4_DIMENSIONS:
            if dim not in view.dimensions:
                t4_idx = T4_DIM_INDEX[dim]
                t4_coords[:, t4_idx] = final_fixed.get(dim, 0.0)

        return t4_coords

    @staticmethod
    def get_projection_matrix(view: DimensionalView) -> np.ndarray:
        """
        Get the projection matrix for a view.

        Args:
            view: DimensionalView specification

        Returns:
            [k, 4] matrix P such that projected = t4_coords @ P.T

        Note:
            For slice views, this matrix extracts columns.
            For full views, returns identity.
        """
        if view.projection_type == "full":
            return np.eye(4)

        k = len(view.dimensions)
        P = np.zeros((k, 4))

        for proj_idx, dim in enumerate(view.dimensions):
            t4_idx = T4_DIM_INDEX[dim]
            P[proj_idx, t4_idx] = 1.0

        return P

    @staticmethod
    def get_dimension_names(view: DimensionalView) -> List[str]:
        """Get human-readable names for view dimensions."""
        return list(view.dimensions)

    @staticmethod
    def compute_view_bounds(view: DimensionalView) -> Dict[str, tuple]:
        """
        Get the expected bounds for each dimension in the view.

        Returns:
            Dict mapping dimension name to (min, max) tuple

        Note:
            Bounds are based on T⁴ coordinate definitions:
            - simplex_theta: [0, 360) degrees
            - phi_simplex: [0, 360) degrees (normalized radial)
            - alpha: [0, 180] degrees
            - omega: [0, 90] degrees (arccos range, NOT [0, 180])
                     v2.6 fix: Previous docs incorrectly showed [0, 180]
                     Mathematical reason: omega = arccos(φ) ∈ [0°, 90°]
        """
        bounds = {
            "simplex_theta": (0.0, 360.0),
            "phi_simplex": (0.0, 360.0),
            "alpha": (0.0, 180.0),
            "omega": (0.0, 90.0),  # CORRECTED: arccos range is [0, 90], not [0, 180]
        }
        return {dim: bounds[dim] for dim in view.dimensions}


def create_view_from_dims(
    dimensions: tuple,
    projection_type: str = "slice",
    fixed_values: Optional[Dict[str, float]] = None,
) -> DimensionalView:
    """
    Convenience function to create a DimensionalView.

    Args:
        dimensions: Tuple of dimension names to include
        projection_type: "slice", "projection", or "full"
        fixed_values: Values for dimensions not in view

    Returns:
        DimensionalView instance
    """
    fixed = fixed_values or {}

    # Auto-fill missing fixed dimensions with midpoint values
    if projection_type == "slice":
        defaults = {
            "simplex_theta": 180.0,
            "phi_simplex": 180.0,
            "alpha": 90.0,
            "omega": 90.0,
        }
        for dim in T4_DIMENSIONS:
            if dim not in dimensions and dim not in fixed:
                fixed[dim] = defaults[dim]

    return DimensionalView(
        dimensions=dimensions,
        projection_type=projection_type,
        fixed_dims=fixed,
    )


__all__ = [
    "ViewProjector",
    "T4_DIMENSIONS",
    "T4_DIM_INDEX",
    "create_view_from_dims",
]
