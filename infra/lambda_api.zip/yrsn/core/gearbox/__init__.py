"""
YRSN Dimensional Gearbox - Core Domain Layer

The Gearbox unifies engine selection + dimensional view selection into
discrete "gears" that shift based on quality signals.

Gears (Fixed):
    - 1st (Precision): Gradient, (α, ω) slice, τ < 1.0
    - 2nd (Balanced): Gradient, (θ, φ, α) 3D, 1.0 ≤ τ < 1.43
    - 3rd (Explore): Eggroll, (θ, φ) polar, 1.43 ≤ τ < 2.5
    - 4th (Discovery): Eggroll, full T⁴, τ ≥ 2.5
    - R (Reverse): Eggroll, (α, ω) slice, collapse recovery

Driving Modes:
    - SPORT: Aggressive shifting for low-latency (edge robotics)
    - ECO: Conservative shifting for high-reliability (medical AI)
    - MANUAL: No auto-shifting, explicit control

Usage:
    from yrsn.core.gearbox import (
        Gear, GearSpec, GEAR_SPECS,
        DrivingMode, DrivingModeConfig,
        GearShifter, QualitySignals,
        ViewProjector, DimensionalView,
    )

    # Get gear for temperature
    gear = get_gear_for_tau(tau=1.2)  # -> Gear.SECOND

    # Make shift decision
    shifter = GearShifter()
    quality = QualitySignals(alpha=0.6)
    decision = shifter.decide_shift(
        current_gear=Gear.SECOND,
        quality=quality,
        mode_config=DRIVING_MODE_CONFIGS[DrivingMode.SPORT],
    )

Reference:
    docs/CIP_03_PLATFORM_ARCHITECTURE.md
"""

# Gear definitions
from yrsn.core.gearbox.gear import (
    DimensionalView,
    Gear,
    GearSpec,
    GEAR_SPECS,
    get_gear_for_tau,
    get_gear_spec,
)

# Driving modes
from yrsn.core.gearbox.driving_mode import (
    DrivingMode,
    DrivingModeConfig,
    DRIVING_MODE_CONFIGS,
    get_driving_mode_config,
    is_auto_shift_enabled,
)

# View projections
from yrsn.core.gearbox.views import (
    ViewProjector,
    T4_DIMENSIONS,
    T4_DIM_INDEX,
    create_view_from_dims,
)

# Shifting logic
from yrsn.core.gearbox.shifter import (
    QualitySignals,
    ShiftDecision,
    GearShifter,
)

# Calibration
from yrsn.core.gearbox.gearbox_calibrator import (
    GearboxCalibrator,
    GearboxCalibrationConfig,
    GearboxCalibrationResult,
)


__all__ = [
    # Gear definitions
    "DimensionalView",
    "Gear",
    "GearSpec",
    "GEAR_SPECS",
    "get_gear_for_tau",
    "get_gear_spec",
    # Driving modes
    "DrivingMode",
    "DrivingModeConfig",
    "DRIVING_MODE_CONFIGS",
    "get_driving_mode_config",
    "is_auto_shift_enabled",
    # View projections
    "ViewProjector",
    "T4_DIMENSIONS",
    "T4_DIM_INDEX",
    "create_view_from_dims",
    # Shifting logic
    "QualitySignals",
    "ShiftDecision",
    "GearShifter",
    # Calibration
    "GearboxCalibrator",
    "GearboxCalibrationConfig",
    "GearboxCalibrationResult",
]
