"""
YRSN Gearbox - Gear Shifting Logic

Pure domain logic for gear shifting decisions. No side effects, no dependencies
on backends or external state. Designed for testability and clean separation.

Key rules:
1. Can always shift to REVERSE (emergency recovery)
2. Can always shift FROM REVERSE to any gear
3. Downshifts: allowed freely (4→3→2→1)
4. Upshifts: only one gear at a time (1→2→3→4)
5. Hysteresis prevents oscillation ("gear hunting")

Reference:
    driving_mode.py for hysteresis configurations
    gear.py for gear specifications
"""

from typing import Optional, Tuple, List
from dataclasses import dataclass
import time

from yrsn.core.gearbox.gear import Gear, GearSpec, GEAR_SPECS, get_gear_for_tau
from yrsn.core.gearbox.driving_mode import (
    DrivingMode,
    DrivingModeConfig,
    get_driving_mode_config,
    is_auto_shift_enabled,
)


@dataclass
class QualitySignals:
    """
    Quality signals used for gear shifting decisions.

    Attributes:
        alpha: Quality signal (R component), higher = better
        tau: Temperature (1/alpha typically)
        collapse_risk: Risk of topological collapse [0, 1]
        coherence: Phasor coherence (multi-source agreement) [0, 1]

    Note:
        These are the minimal signals needed for shifting.
        Full quality signals are in the validation layer.
    """
    alpha: float = 0.5
    tau: Optional[float] = None
    collapse_risk: float = 0.0
    coherence: float = 1.0

    def __post_init__(self):
        """Compute tau from alpha if not provided."""
        if self.tau is None:
            self.tau = 1.0 / max(self.alpha, 0.01)


@dataclass
class ShiftDecision:
    """Result of a gear shift decision."""
    should_shift: bool
    from_gear: Gear
    to_gear: Gear
    reason: str
    blocked: bool = False
    block_reason: Optional[str] = None


class GearShifter:
    """
    Pure domain logic for gear shifting decisions.

    This class contains no mutable state and makes deterministic decisions
    based on input parameters. Side effects (actually shifting) happen in
    the adapter layer.

    Example:
        >>> shifter = GearShifter()
        >>> quality = QualitySignals(alpha=0.8)
        >>> gear = shifter.recommend_gear(quality)
        >>> print(gear)  # Gear.FIRST (high quality = precision gear)
    """

    # Gear order for shift validation (REVERSE excluded - always accessible)
    GEAR_ORDER: List[Gear] = [Gear.FIRST, Gear.SECOND, Gear.THIRD, Gear.FOURTH]

    @staticmethod
    def recommend_gear(
        quality: QualitySignals,
        collapse_detected: bool = False,
    ) -> Gear:
        """
        Recommend the optimal gear based on quality signals.

        Args:
            quality: Current quality signals
            collapse_detected: If True, forces REVERSE gear

        Returns:
            Recommended Gear

        Note:
            This is a pure recommendation - it doesn't consider hysteresis
            or the current gear. Use decide_shift() for full logic.
        """
        # Recovery override - always shift to REVERSE on collapse
        if collapse_detected or quality.collapse_risk > 0.8:
            return Gear.REVERSE

        # Low coherence suggests exploration needed
        if quality.coherence < 0.3:
            return Gear.THIRD

        # Temperature-based gear selection
        tau = quality.tau
        return get_gear_for_tau(tau, exclude_reverse=True)

    @staticmethod
    def can_shift(from_gear: Gear, to_gear: Gear) -> Tuple[bool, str]:
        """
        Check if a gear shift is allowed.

        Args:
            from_gear: Current gear
            to_gear: Target gear

        Returns:
            (allowed, reason) tuple

        Rules:
            - REVERSE: always accessible from any gear
            - From REVERSE: can shift to any gear
            - Downshift: allowed freely (higher → lower ordinal)
            - Upshift: only one gear at a time
        """
        if from_gear == to_gear:
            return False, "Already in target gear"

        # REVERSE is always accessible
        if to_gear == Gear.REVERSE:
            return True, "REVERSE always accessible for recovery"

        # Can shift from REVERSE to any gear
        if from_gear == Gear.REVERSE:
            return True, "Recovery complete, resuming normal operation"

        # Get ordinals for comparison
        from_ord = from_gear.ordinal
        to_ord = to_gear.ordinal

        # Downshifts are always allowed
        if to_ord < from_ord:
            return True, f"Downshift from {from_gear.value} to {to_gear.value}"

        # Upshifts must be sequential (one gear at a time)
        if to_ord == from_ord + 1:
            return True, f"Sequential upshift to {to_gear.value}"
        else:
            return False, f"Cannot skip gears: {from_gear.value} → {to_gear.value}"

    @staticmethod
    def compute_shift_tau(
        from_gear: Gear,
        to_gear: Gear,
        current_tau: float,
    ) -> float:
        """
        Compute the appropriate tau after shifting.

        Args:
            from_gear: Current gear
            to_gear: Target gear
            current_tau: Current temperature

        Returns:
            Adjusted tau clamped to target gear's range

        Note:
            When upshifting, tau is clamped to the new gear's minimum.
            When downshifting, tau is clamped to the new gear's maximum.
        """
        target_spec = GEAR_SPECS[to_gear]
        tau_min, tau_max = target_spec.tau_range

        # Clamp to target range
        if current_tau < tau_min:
            return tau_min
        elif current_tau >= tau_max and tau_max != float('inf'):
            return tau_max - 0.01  # Just below max
        return current_tau

    @classmethod
    def decide_shift(
        cls,
        current_gear: Gear,
        quality: QualitySignals,
        mode_config: DrivingModeConfig,
        time_in_gear: float = 0.0,
        collapse_detected: bool = False,
    ) -> ShiftDecision:
        """
        Make a complete gear shift decision with hysteresis.

        Args:
            current_gear: Current gear
            quality: Current quality signals
            mode_config: Driving mode configuration
            time_in_gear: Seconds since last shift
            collapse_detected: If True, forces REVERSE

        Returns:
            ShiftDecision with full details

        Note:
            This is the primary decision method that considers:
            - Quality-based gear recommendation
            - Hysteresis (τ buffer)
            - Upshift delay
            - Downshift aggression
            - Shift validity rules
        """
        # Manual mode = no auto-shifting
        if mode_config.mode == DrivingMode.MANUAL:
            return ShiftDecision(
                should_shift=False,
                from_gear=current_gear,
                to_gear=current_gear,
                reason="Manual mode - no auto-shifting",
            )

        # Get recommended gear
        recommended = cls.recommend_gear(quality, collapse_detected)

        # Same gear - no shift needed
        if recommended == current_gear:
            return ShiftDecision(
                should_shift=False,
                from_gear=current_gear,
                to_gear=current_gear,
                reason="Current gear is optimal",
            )

        # Check shift validity
        can_do, validity_reason = cls.can_shift(current_gear, recommended)
        if not can_do:
            return ShiftDecision(
                should_shift=False,
                from_gear=current_gear,
                to_gear=recommended,
                reason=validity_reason,
                blocked=True,
                block_reason=validity_reason,
            )

        # REVERSE bypasses hysteresis
        if recommended == Gear.REVERSE:
            return ShiftDecision(
                should_shift=True,
                from_gear=current_gear,
                to_gear=Gear.REVERSE,
                reason="Emergency shift to REVERSE for recovery",
            )

        tau = quality.tau
        recommended_spec = GEAR_SPECS[recommended]

        # Determine if upshift or downshift
        is_upshift = recommended.ordinal > current_gear.ordinal

        if is_upshift:
            # Check upshift delay
            if time_in_gear < mode_config.upshift_delay:
                return ShiftDecision(
                    should_shift=False,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason=f"Upshift delay: {time_in_gear:.1f}s < {mode_config.upshift_delay:.1f}s",
                    blocked=True,
                    block_reason="Upshift delay not met",
                )

            # Check hysteresis for upshift
            threshold = mode_config.effective_threshold(
                recommended_spec.tau_min, "up"
            )
            if tau > threshold:
                return ShiftDecision(
                    should_shift=True,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason=f"Upshift: τ={tau:.2f} > threshold={threshold:.2f}",
                )
            else:
                return ShiftDecision(
                    should_shift=False,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason=f"Hysteresis: τ={tau:.2f} ≤ threshold={threshold:.2f}",
                )

        else:
            # Downshift: apply aggression factor
            if mode_config.downshift_aggression <= 0:
                return ShiftDecision(
                    should_shift=False,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason="Downshift disabled (aggression=0)",
                )

            # Check hysteresis for downshift
            current_spec = GEAR_SPECS[current_gear]
            threshold = mode_config.effective_threshold(
                current_spec.tau_min, "down"
            )

            if tau < threshold:
                return ShiftDecision(
                    should_shift=True,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason=f"Downshift: τ={tau:.2f} < threshold={threshold:.2f}",
                )
            else:
                return ShiftDecision(
                    should_shift=False,
                    from_gear=current_gear,
                    to_gear=recommended,
                    reason=f"Hysteresis: τ={tau:.2f} ≥ threshold={threshold:.2f}",
                )


__all__ = [
    "QualitySignals",
    "ShiftDecision",
    "GearShifter",
]
