"""
YRSN Drift Monitor - Operational Thresholds for T^4 Topology

Translates validated chordal distance metrics into actionable operational states.
Based on expS5_001d validation (1.69x improvement over Euclidean).

PATENT SPECIFICATION COMPLIANCE:
--------------------------------
This module implements:
- §7.8: Environmental Validation Context
  - §7.8.4: Drift Detection (phase classification, threshold-based detection)
- §7.6: Toroidal Geometric Mapping
  - §7.6.5: Distance Computation (T⁴ chordal distance thresholds)

Drift phases (§7.8.4):
  Phase 1 (NOMINAL):  d < 0.2  → GREEN  → No action
  Phase 2 (JITTER):   0.2 ≤ d < 0.5 → YELLOW → Hold
  Phase 3 (DRIFT):    0.5 ≤ d < 1.5 → ORANGE → Downshift
  Phase 4 (COLLAPSE): d ≥ 1.5 → RED    → Reverse/Neutral

Relevant patent files:
- docs/specs/patent_spec_section_7_8_environmental_context.md

See also: docs/PATENT_SPEC_TO_CODE_MAPPING.md

Operational Envelope:
- Phase 1 (GREEN):  d < 0.2  - Nominal stability
- Phase 2 (YELLOW): 0.2 ≤ d < 0.5 - Structural jitter
- Phase 3 (ORANGE): 0.5 ≤ d < 1.5 - Domain drift
- Phase 4 (RED):    d ≥ 1.5 - Topological collapse

Reference:
    docs/T4_CHORDAL_DISTANCE_IMPLEMENTATION.md
    SME operational framework (2026-01-23)
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
import numpy as np


class DriftPhase(Enum):
    """Operational drift phases based on T^4 chordal distance."""

    NOMINAL = "nominal"           # GREEN: d < 0.2
    JITTER = "jitter"            # YELLOW: 0.2 ≤ d < 0.5
    DRIFT = "drift"              # ORANGE: 0.5 ≤ d < 1.5
    COLLAPSE = "collapse"        # RED: d ≥ 1.5

    @property
    def color(self) -> str:
        """Console color code for this phase."""
        return {
            DriftPhase.NOMINAL: "\033[92m",   # Green
            DriftPhase.JITTER: "\033[93m",    # Yellow
            DriftPhase.DRIFT: "\033[38;5;208m",  # Orange
            DriftPhase.COLLAPSE: "\033[91m",  # Red
        }[self]

    @property
    def symbol(self) -> str:
        """Symbol for this phase."""
        return {
            DriftPhase.NOMINAL: "[OK]",
            DriftPhase.JITTER: "[WARN]",
            DriftPhase.DRIFT: "[ALERT]",
            DriftPhase.COLLAPSE: "[EMERGENCY]",
        }[self]


@dataclass
class DriftThresholds:
    """
    Operational thresholds for T^4 chordal distance drift detection.

    Based on maximum possible distance on T^4 manifold (d_max = 4.0):
    - Nominal: < 5% of max (< 0.2)
    - Jitter: 5-12.5% of max (0.2-0.5)
    - Drift: 12.5-37.5% of max (0.5-1.5)
    - Collapse: > 37.5% of max (≥ 1.5)
    """

    nominal_max: float = 0.2      # Phase 1: GREEN
    jitter_max: float = 0.5       # Phase 2: YELLOW
    drift_max: float = 1.5        # Phase 3: ORANGE
    # Phase 4 (RED): anything >= drift_max

    # Derived thresholds
    max_distance: float = 4.0     # Maximum possible on T^4

    def classify(self, distance: float) -> DriftPhase:
        """Classify drift distance into operational phase."""
        if distance < self.nominal_max:
            return DriftPhase.NOMINAL
        elif distance < self.jitter_max:
            return DriftPhase.JITTER
        elif distance < self.drift_max:
            return DriftPhase.DRIFT
        else:
            return DriftPhase.COLLAPSE

    def health_percentage(self, distance: float) -> float:
        """
        Compute operational health as percentage.

        Formula: (1 - distance/max_distance) * 100
        Returns: 0-100% where 100% = perfect alignment
        """
        return max(0.0, min(100.0, (1.0 - distance / self.max_distance) * 100))


@dataclass
class DriftAlert:
    """Single drift detection alert."""

    timestamp: datetime
    phase: DriftPhase
    distance: float
    baseline_state: str           # Brief description of baseline
    current_state: str            # Brief description of current
    health_pct: float            # Operational health percentage
    recommendation: str          # Suggested action

    def __str__(self) -> str:
        """Format alert for console output."""
        symbol = self.phase.symbol
        return (
            f"{symbol} Drift Alert: {self.phase.value.upper()}\n"
            f"  Distance: {self.distance:.4f}\n"
            f"  Health: {self.health_pct:.1f}%\n"
            f"  Action: {self.recommendation}"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary for logging."""
        return {
            'timestamp': self.timestamp.isoformat(),
            'phase': self.phase.value,
            'distance': float(self.distance),
            'baseline': self.baseline_state,
            'current': self.current_state,
            'health_pct': float(self.health_pct),
            'recommendation': self.recommendation,
        }


class DriftMonitor:
    """
    Monitors T^4 chordal distance drift and generates operational alerts.

    Usage:
        monitor = DriftMonitor(baseline_score)

        # During inference
        current_score = projection.compute_rsn(embedding, return_t4=True)
        alert = monitor.check_drift(current_score)

        if alert and alert.phase in [DriftPhase.DRIFT, DriftPhase.COLLAPSE]:
            print(alert)
            # Take corrective action

    Features:
        - Classifies drift into 4 operational phases
        - Generates actionable recommendations
        - Tracks drift history
        - Supports auto-reset and emergency halt
    """

    def __init__(
        self,
        baseline_score=None,
        thresholds: Optional[DriftThresholds] = None,
        alert_history_size: int = 100,
    ):
        """
        Initialize drift monitor.

        Args:
            baseline_score: DecompositionScore to use as reference (can be None initially)
            thresholds: Custom thresholds (default: validated operational envelope)
            alert_history_size: Max alerts to keep in history
        """
        self.baseline = baseline_score
        self.thresholds = thresholds or DriftThresholds()
        self.alert_history: List[DriftAlert] = []
        self.alert_history_size = alert_history_size

        # Drift tracking
        self.max_drift_seen = 0.0
        self.phase_3_duration = 0.0  # Time spent in drift phase (for auto-reboot)
        self.last_check_time = None

    def set_baseline(self, score) -> None:
        """Update baseline reference."""
        self.baseline = score
        print(f"[DriftMonitor] Baseline updated: R={score.R:.3f}, S={score.S:.3f}, N={score.N:.3f}")

    def check_drift(
        self,
        current_score,
        auto_log: bool = True,
    ) -> Optional[DriftAlert]:
        """
        Check current score against baseline and classify drift.

        Args:
            current_score: Current DecompositionScore with T^4 coordinates
            auto_log: Automatically add alert to history

        Returns:
            DriftAlert if baseline set and T^4 coords available, else None
        """
        # Validate inputs
        if self.baseline is None:
            return None

        # P9 Compliance: Use t4_coords (schema attribute from YRSNCertificate)
        if current_score.t4_coords is None or self.baseline.t4_coords is None:
            return None

        # Compute drift distance using Certificate's static method (P9: schema is source of truth)
        from yrsn.core.certificate import YRSNCertificate
        distance = YRSNCertificate._chordal_distance_t4(
            current_score.t4_coords,
            self.baseline.t4_coords
        )

        # Track maximum
        if distance > self.max_drift_seen:
            self.max_drift_seen = distance

        # Classify phase
        phase = self.thresholds.classify(distance)
        health_pct = self.thresholds.health_percentage(distance)

        # Generate recommendation
        recommendation = self._get_recommendation(phase, distance)

        # Create alert (P9: use schema attributes - alpha not t4_alpha)
        alert = DriftAlert(
            timestamp=datetime.now(),
            phase=phase,
            distance=distance,
            baseline_state=f"R={self.baseline.R:.3f}, alpha={self.baseline.alpha:.3f}",
            current_state=f"R={current_score.R:.3f}, alpha={current_score.alpha:.3f}",
            health_pct=health_pct,
            recommendation=recommendation,
        )

        # Track Phase 3 duration (for auto-reboot logic)
        if phase == DriftPhase.DRIFT:
            if self.last_check_time:
                elapsed = (datetime.now() - self.last_check_time).total_seconds()
                self.phase_3_duration += elapsed
            else:
                self.phase_3_duration = 0.0
        else:
            self.phase_3_duration = 0.0  # Reset if not in Phase 3

        self.last_check_time = datetime.now()

        # Log to history
        if auto_log:
            self.alert_history.append(alert)
            if len(self.alert_history) > self.alert_history_size:
                self.alert_history.pop(0)

        return alert

    def _get_recommendation(self, phase: DriftPhase, distance: float) -> str:
        """Generate actionable recommendation based on phase."""
        if phase == DriftPhase.NOMINAL:
            return "Continue normal operations; log baseline metrics"
        elif phase == DriftPhase.JITTER:
            return "Apply complex smoothing (window=3) to stabilize signals"
        elif phase == DriftPhase.DRIFT:
            if self.phase_3_duration > 600:  # 10 minutes
                return "CRITICAL: Trigger auto-reboot; Phase 3 exceeded 10 minutes"
            else:
                return "Alert operator for model review; consider re-sync to baseline"
        else:  # COLLAPSE
            return "EMERGENCY HALT: Revert to last stable checkpoint immediately"

    def get_drift_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive drift report.

        Returns:
            Dictionary with current state, trends, and recommendations
        """
        if not self.alert_history:
            return {
                'status': 'NO_DATA',
                'message': 'No drift alerts recorded yet',
            }

        latest = self.alert_history[-1]

        # Compute trend (last 10 alerts)
        recent_alerts = self.alert_history[-10:]
        distances = [a.distance for a in recent_alerts]

        if len(distances) > 1:
            trend_direction = "UP" if distances[-1] > distances[0] else "DOWN"
            trend_pct = ((distances[-1] - distances[0]) / distances[0]) * 100 if distances[0] > 0 else 0.0
        else:
            trend_direction = "STABLE"
            trend_pct = 0.0

        # Phase distribution
        phase_counts = {}
        for alert in self.alert_history:
            phase_counts[alert.phase.value] = phase_counts.get(alert.phase.value, 0) + 1

        return {
            'status': latest.phase.value.upper(),
            'current_drift': float(latest.distance),
            'max_drift_seen': float(self.max_drift_seen),
            'health_pct': float(latest.health_pct),
            'trend_direction': trend_direction,
            'trend_pct': float(trend_pct),
            'phase_3_duration_sec': float(self.phase_3_duration),
            'recommendation': latest.recommendation,
            'phase_distribution': phase_counts,
            'total_alerts': len(self.alert_history),
            'timestamp': latest.timestamp.isoformat(),
        }

    def print_report(self) -> None:
        """Print formatted drift report to console."""
        report = self.get_drift_report()

        if report['status'] == 'NO_DATA':
            print(report['message'])
            return

        print("=" * 70)
        print("YRSN DRIFT MONITORING REPORT")
        print("=" * 70)
        print()
        print(f"Status: {report['status']}")
        print(f"Current Drift: {report['current_drift']:.4f}")
        print(f"Max Drift Seen: {report['max_drift_seen']:.4f}")
        print(f"Health: {report['health_pct']:.1f}%")
        print(f"Trend: {report['trend_direction']} ({report['trend_pct']:+.1f}%)")
        print()
        print("Phase Distribution:")
        for phase, count in report['phase_distribution'].items():
            pct = (count / report['total_alerts']) * 100
            print(f"  {phase.upper():12}: {count:3d} alerts ({pct:.1f}%)")
        print()
        print(f"Recommendation: {report['recommendation']}")

        if report['phase_3_duration_sec'] > 0:
            mins = report['phase_3_duration_sec'] / 60
            print(f"\nWARNING: Phase 3 (DRIFT) duration: {mins:.1f} minutes")
            if mins > 10:
                print("  ** AUTO-REBOOT THRESHOLD EXCEEDED **")

        print()
        print("=" * 70)

    def should_auto_reboot(self, duration_threshold_minutes: float = 10.0) -> bool:
        """
        Check if auto-reboot should be triggered.

        Args:
            duration_threshold_minutes: Minutes in Phase 3 before auto-reboot

        Returns:
            True if Phase 3 duration exceeds threshold
        """
        return self.phase_3_duration > (duration_threshold_minutes * 60)

    def reset_history(self) -> None:
        """Clear alert history and reset tracking."""
        self.alert_history.clear()
        self.max_drift_seen = 0.0
        self.phase_3_duration = 0.0
        self.last_check_time = None
        print("[DriftMonitor] History reset")


# Convenience function for quick drift check
def check_model_drift(baseline_score, current_score) -> Optional[DriftAlert]:
    """
    Quick drift check without creating monitor instance.

    Args:
        baseline_score: Reference DecompositionScore with T^4 coords
        current_score: Current DecompositionScore with T^4 coords

    Returns:
        DriftAlert or None

    Example:
        >>> alert = check_model_drift(baseline, current)
        >>> if alert and alert.phase != DriftPhase.NOMINAL:
        ...     print(alert)
    """
    monitor = DriftMonitor(baseline_score)
    return monitor.check_drift(current_score, auto_log=False)
