"""
Grounding Validator - Resolve language references to scene objects.

Handles:
    - Object reference resolution ("the red cup" → object_id_123)
    - Spatial reference resolution ("on the left" → position)
    - Temporal reference resolution ("after that" → sequence)
    - Ambiguity detection and resolution

Integration:
    - Perception system: Query scene objects
    - VLA: Ground language to visual features
    - YRSN: Quality signal for grounding confidence
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
import math


@dataclass
class ObjectReference:
    """A reference to an object in natural language."""

    text: str                    # Original text ("the red cup")
    object_type: Optional[str] = None   # "cup"
    color: Optional[str] = None         # "red"
    location: Optional[str] = None      # "on the left"
    ordinal: Optional[int] = None       # "first", "second" → 1, 2
    is_definite: bool = True     # "the" vs "a"
    is_anaphoric: bool = False   # "it", "that" (refers to previous)


@dataclass
class GroundedObject:
    """An object reference resolved to a scene object."""

    reference: ObjectReference
    object_id: str
    confidence: float
    position: Optional[Tuple[float, float, float]] = None
    alternatives: List[str] = field(default_factory=list)  # Other possible matches


@dataclass
class GroundedCommand:
    """A fully grounded robot command."""

    action: str
    grounded_objects: Dict[str, GroundedObject] = field(default_factory=dict)
    grounded_positions: Dict[str, Tuple[float, float, float]] = field(default_factory=dict)
    grounding_confidence: float = 0.0
    ambiguities: List[str] = field(default_factory=list)

    @property
    def is_fully_grounded(self) -> bool:
        """Check if all references are grounded without ambiguity."""
        return (
            self.grounding_confidence > 0.8 and
            len(self.ambiguities) == 0
        )

    def to_action(self) -> Dict[str, Any]:
        """Convert to executable action dict."""
        return {
            "action": self.action,
            "objects": {k: v.object_id for k, v in self.grounded_objects.items()},
            "positions": self.grounded_positions,
        }


class GroundingValidator:
    """
    Validate and resolve language references to scene objects.

    Uses multiple strategies:
    1. Type + color matching
    2. Spatial filtering (location constraints)
    3. Saliency (most prominent object)
    4. Recency (last mentioned/manipulated)
    5. Disambiguation dialog (if needed)
    """

    def __init__(
        self,
        require_unique_match: bool = True,
        allow_saliency_fallback: bool = True,
    ):
        self.require_unique_match = require_unique_match
        self.allow_saliency_fallback = allow_saliency_fallback
        self._discourse_history: List[str] = []  # Track mentioned objects

    def ground(
        self,
        intent: Any,  # ParsedIntent
        scene_objects: List[Dict[str, Any]],
        robot_state: Optional[Dict[str, Any]] = None,
    ) -> GroundedCommand:
        """
        Ground all references in intent to scene objects.

        Args:
            intent: Parsed intent with object/location references
            scene_objects: Current scene objects from perception
            robot_state: Robot state (for "held object", etc.)

        Returns:
            GroundedCommand with resolved references
        """
        grounded = GroundedCommand(
            action=intent.action.normalized if intent.action else "unknown"
        )
        ambiguities = []

        # Ground object reference
        if intent.object:
            ref = ObjectReference(
                text=intent.object.value,
                object_type=intent.object.normalized,
                color=intent.color.normalized if intent.color else None,
                location=intent.location.normalized if intent.location else None,
            )

            result = self._ground_object_reference(ref, scene_objects, robot_state)

            if result:
                grounded.grounded_objects["target"] = result
                if result.alternatives:
                    ambiguities.append(
                        f"Multiple matches for '{ref.text}': {', '.join(result.alternatives[:3])}"
                    )
            else:
                ambiguities.append(f"Cannot find '{ref.text}' in scene")

        # Ground destination reference
        if intent.destination:
            dest = intent.destination.normalized
            pos = self._resolve_spatial_reference(dest, scene_objects)
            if pos:
                grounded.grounded_positions["destination"] = pos
            else:
                ambiguities.append(f"Cannot resolve destination '{dest}'")

        # Compute overall confidence
        confidences = [obj.confidence for obj in grounded.grounded_objects.values()]
        if confidences:
            grounded.grounding_confidence = sum(confidences) / len(confidences)
        else:
            grounded.grounding_confidence = 0.5  # No objects to ground

        grounded.ambiguities = ambiguities

        return grounded

    def _ground_object_reference(
        self,
        ref: ObjectReference,
        scene_objects: List[Dict[str, Any]],
        robot_state: Optional[Dict[str, Any]] = None,
    ) -> Optional[GroundedObject]:
        """Ground a single object reference."""

        # Handle anaphoric references ("it", "that")
        if ref.is_anaphoric or ref.text.lower() in ["it", "that", "this"]:
            return self._resolve_anaphoric(ref, robot_state)

        # Find candidates by type
        candidates = self._filter_by_type(scene_objects, ref.object_type)

        # Filter by color
        if ref.color and candidates:
            candidates = self._filter_by_color(candidates, ref.color)

        # Filter by location
        if ref.location and candidates:
            candidates = self._filter_by_location(candidates, ref.location)

        # Handle results
        if len(candidates) == 0:
            return None

        if len(candidates) == 1:
            # Unique match
            obj = candidates[0]
            return GroundedObject(
                reference=ref,
                object_id=obj["id"],
                confidence=1.0,
                position=tuple(obj.get("position", [0, 0, 0])),
            )

        # Multiple candidates - try disambiguation
        if self.allow_saliency_fallback:
            # Use saliency/recency
            best = self._select_by_saliency(candidates)
            return GroundedObject(
                reference=ref,
                object_id=best["id"],
                confidence=0.7,
                position=tuple(best.get("position", [0, 0, 0])),
                alternatives=[c["id"] for c in candidates if c["id"] != best["id"]],
            )

        # Can't disambiguate
        return GroundedObject(
            reference=ref,
            object_id=candidates[0]["id"],
            confidence=0.3,
            alternatives=[c["id"] for c in candidates[1:]],
        )

    def _filter_by_type(
        self,
        objects: List[Dict[str, Any]],
        obj_type: Optional[str],
    ) -> List[Dict[str, Any]]:
        """Filter objects by type."""
        if not obj_type:
            return objects

        obj_type = obj_type.lower()
        matches = []

        for obj in objects:
            obj_types = obj.get("type", "").lower()
            # Flexible matching
            if obj_type in obj_types or obj_types in obj_type:
                matches.append(obj)

        return matches

    def _filter_by_color(
        self,
        objects: List[Dict[str, Any]],
        color: str,
    ) -> List[Dict[str, Any]]:
        """Filter objects by color."""
        color = color.lower()
        return [obj for obj in objects if obj.get("color", "").lower() == color]

    def _filter_by_location(
        self,
        objects: List[Dict[str, Any]],
        location: str,
    ) -> List[Dict[str, Any]]:
        """Filter objects by spatial location."""
        location = location.lower()

        # Handle relative directions
        if location in ["left", "right", "front", "back"]:
            return self._filter_by_direction(objects, location)

        # Handle on/in relations
        if location in ["table", "desk", "shelf"]:
            return [obj for obj in objects if location in obj.get("support", "").lower()]

        return objects

    def _filter_by_direction(
        self,
        objects: List[Dict[str, Any]],
        direction: str,
    ) -> List[Dict[str, Any]]:
        """Filter by relative direction from robot viewpoint."""
        if not objects:
            return []

        # Sort by x-coordinate for left/right
        if direction in ["left", "right"]:
            sorted_objs = sorted(objects, key=lambda o: o.get("position", [0])[0])
            if direction == "left":
                return sorted_objs[:len(sorted_objs)//2 + 1]
            else:
                return sorted_objs[len(sorted_objs)//2:]

        # Sort by y-coordinate for front/back
        if direction in ["front", "back"]:
            sorted_objs = sorted(objects, key=lambda o: o.get("position", [0, 0])[1])
            if direction == "front":
                return sorted_objs[:len(sorted_objs)//2 + 1]
            else:
                return sorted_objs[len(sorted_objs)//2:]

        return objects

    def _resolve_anaphoric(
        self,
        ref: ObjectReference,
        robot_state: Optional[Dict[str, Any]],
    ) -> Optional[GroundedObject]:
        """Resolve anaphoric reference (it, that, this)."""

        # Check if robot is holding something
        if robot_state and robot_state.get("held_object"):
            held = robot_state["held_object"]
            return GroundedObject(
                reference=ref,
                object_id=held["id"],
                confidence=0.9,
                position=tuple(held.get("position", [0, 0, 0])),
            )

        # Check discourse history
        if self._discourse_history:
            last_mentioned = self._discourse_history[-1]
            return GroundedObject(
                reference=ref,
                object_id=last_mentioned,
                confidence=0.7,
            )

        return None

    def _resolve_spatial_reference(
        self,
        location: str,
        scene_objects: List[Dict[str, Any]],
    ) -> Optional[Tuple[float, float, float]]:
        """Resolve spatial reference to position."""
        location = location.lower()

        # Relative directions (from robot frame)
        relative_offsets = {
            "left": (-0.3, 0, 0),
            "right": (0.3, 0, 0),
            "forward": (0, 0.3, 0),
            "backward": (0, -0.3, 0),
            "up": (0, 0, 0.2),
            "down": (0, 0, -0.2),
        }

        if location in relative_offsets:
            return relative_offsets[location]

        # Look for named surface
        for obj in scene_objects:
            if location in obj.get("type", "").lower():
                pos = obj.get("position", [0, 0, 0])
                # Place above the surface
                return (pos[0], pos[1], pos[2] + 0.1)

        return None

    def _select_by_saliency(
        self,
        candidates: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Select most salient object from candidates."""
        if not candidates:
            return {}

        # Saliency heuristics:
        # 1. Recently manipulated
        # 2. Closest to robot
        # 3. Largest

        scored = []
        for obj in candidates:
            score = 0.0

            # Recency
            if obj["id"] in self._discourse_history:
                idx = self._discourse_history.index(obj["id"])
                score += 0.5 * (idx / len(self._discourse_history))

            # Distance (closer = higher score)
            pos = obj.get("position", [0, 0, 0])
            dist = math.sqrt(sum(p**2 for p in pos))
            score += 0.3 * (1.0 / (1.0 + dist))

            # Size
            size = obj.get("size", 1.0)
            score += 0.2 * min(1.0, size / 0.1)

            scored.append((score, obj))

        scored.sort(key=lambda x: -x[0])
        return scored[0][1]

    def update_discourse(self, object_id: str) -> None:
        """Update discourse history with mentioned object."""
        if object_id in self._discourse_history:
            self._discourse_history.remove(object_id)
        self._discourse_history.append(object_id)

        # Keep history bounded
        if len(self._discourse_history) > 10:
            self._discourse_history = self._discourse_history[-10:]


__all__ = [
    "GroundingValidator",
    "GroundedCommand",
    "GroundedObject",
    "ObjectReference",
]
