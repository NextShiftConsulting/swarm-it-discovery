"""
Intent Parser - Extract structured intent from natural language commands.

Converts free-form text/voice commands into structured intents that can be
matched to robot skills and grounded in the scene.

Integration Points:
    - Unitree UnifoLM: Can use as backend for intent extraction
    - External LLMs: OpenAI, local models via Jetson
    - Rule-based fallback: Works without LLM dependency

Example:
    "Pick up the red cup on the left carefully"
    →
    ParsedIntent(
        action="pick",
        object=ObjectRef(color="red", type="cup", location="left"),
        modifiers=["carefully"],
        confidence=0.92
    )
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Callable
from enum import Enum
import re


class SlotType(str, Enum):
    """Types of slots in a robot command."""

    ACTION = "action"           # pick, place, move, etc.
    OBJECT = "object"           # cup, block, ball, etc.
    COLOR = "color"             # red, blue, green, etc.
    LOCATION = "location"       # left, right, on table, etc.
    DESTINATION = "destination" # where to place/move to
    MODIFIER = "modifier"       # carefully, slowly, etc.
    QUANTITY = "quantity"       # one, two, all, etc.
    REFERENCE = "reference"     # "the other one", "that", etc.


@dataclass
class IntentSlot:
    """A filled slot in a parsed intent."""

    slot_type: SlotType
    value: str
    confidence: float = 1.0
    span: Tuple[int, int] = (0, 0)  # Character span in original text
    normalized: Optional[str] = None  # Canonical form

    def __post_init__(self):
        if self.normalized is None:
            self.normalized = self.value.lower().strip()


@dataclass
class ParsedIntent:
    """Structured representation of a robot command."""

    raw_text: str
    action: Optional[IntentSlot] = None
    object: Optional[IntentSlot] = None
    color: Optional[IntentSlot] = None
    location: Optional[IntentSlot] = None
    destination: Optional[IntentSlot] = None
    modifiers: List[IntentSlot] = field(default_factory=list)

    # Quality metrics
    confidence: float = 0.0
    completeness: float = 0.0  # Fraction of required slots filled
    ambiguity_score: float = 0.0  # Higher = more ambiguous

    # Issues detected
    missing_slots: List[SlotType] = field(default_factory=list)
    ambiguous_refs: List[str] = field(default_factory=list)

    @property
    def is_complete(self) -> bool:
        """Check if intent has minimum required slots (action + target)."""
        has_action = self.action is not None
        has_target = (
            self.object is not None or
            self.location is not None or
            self.destination is not None
        )
        return has_action and has_target

    @property
    def action_type(self) -> Optional[str]:
        """Get normalized action type."""
        return self.action.normalized if self.action else None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "raw_text": self.raw_text,
            "action": self.action.normalized if self.action else None,
            "object": self.object.normalized if self.object else None,
            "color": self.color.normalized if self.color else None,
            "location": self.location.normalized if self.location else None,
            "destination": self.destination.normalized if self.destination else None,
            "modifiers": [m.normalized for m in self.modifiers],
            "confidence": self.confidence,
            "completeness": self.completeness,
            "is_complete": self.is_complete,
        }


class IntentParser:
    """
    Parse natural language into structured robot commands.

    Supports multiple backends:
    - Rule-based (default): Fast, no dependencies
    - LLM-based: More accurate, requires LLM client
    - Hybrid: Rules + LLM refinement

    Example:
        parser = IntentParser()
        intent = parser.parse("pick up the red block")

        # With LLM backend
        parser = IntentParser(llm_client=openai_client)
        intent = parser.parse("grab that thing over there")  # LLM resolves "that thing"
    """

    # Action synonyms → canonical form
    ACTION_SYNONYMS = {
        # Pick/Grasp family
        "pick": "pick", "pick up": "pick", "grab": "pick", "grasp": "pick",
        "get": "pick", "take": "pick", "lift": "pick", "retrieve": "pick",
        # Place family
        "place": "place", "put": "place", "put down": "place", "set": "place",
        "drop": "place", "release": "place", "let go": "place",
        # Move family
        "move": "move", "push": "move", "pull": "move", "slide": "move",
        "drag": "move", "shift": "move",
        # Rotate family
        "rotate": "rotate", "turn": "rotate", "spin": "rotate", "twist": "rotate",
        # Open/Close family
        "open": "open", "close": "close", "shut": "close",
        # Press family
        "press": "press", "push": "press", "click": "press", "tap": "press",
        # Stack family
        "stack": "stack", "pile": "stack",
        # Pour family
        "pour": "pour", "empty": "pour", "fill": "pour",
    }

    # Object types (expandable)
    OBJECT_TYPES = {
        "block", "cube", "ball", "sphere", "cup", "mug", "bowl", "plate",
        "box", "container", "bottle", "can", "jar", "lid", "cap", "handle",
        "button", "switch", "lever", "knob", "door", "drawer", "cabinet",
        "object", "thing", "item",  # Generic (may need clarification)
    }

    # Colors
    COLORS = {
        "red", "blue", "green", "yellow", "orange", "purple", "pink",
        "white", "black", "gray", "grey", "brown", "cyan", "magenta",
    }

    # Locations/Directions
    LOCATIONS = {
        "left", "right", "up", "down", "top", "bottom", "front", "back",
        "forward", "backward", "center", "middle", "corner", "side",
        "near", "far", "close", "away", "here", "there",
        "above", "below", "over", "under", "beside", "next to",
        "on", "in", "inside", "outside", "onto", "into",
        "table", "desk", "shelf", "floor", "ground", "surface",
    }

    # Modifiers
    MODIFIERS = {
        "carefully", "gently", "slowly", "quickly", "fast",
        "precisely", "exactly", "approximately",
        "slightly", "a bit", "a little",
    }

    # Ambiguous references (need grounding)
    AMBIGUOUS_REFS = {
        "it", "that", "this", "those", "these", "them",
        "the other", "another", "same", "other",
        "here", "there", "over there",
    }

    def __init__(
        self,
        llm_client: Optional[Any] = None,
        skill_catalog: Optional[List[str]] = None,
        use_hybrid: bool = True,
    ):
        """
        Initialize intent parser.

        Args:
            llm_client: Optional LLM client for advanced parsing
            skill_catalog: List of available robot skills (for matching)
            use_hybrid: Use rules first, LLM for ambiguity resolution
        """
        self.llm_client = llm_client
        self.skill_catalog = skill_catalog or []
        self.use_hybrid = use_hybrid

    def parse(self, text: str) -> ParsedIntent:
        """
        Parse text into structured intent.

        Args:
            text: Natural language command

        Returns:
            ParsedIntent with extracted slots and quality metrics
        """
        text = text.strip()
        if not text:
            return ParsedIntent(
                raw_text="",
                confidence=0.0,
                completeness=0.0,
                ambiguity_score=1.0,
            )

        # Rule-based extraction
        intent = self._rule_based_parse(text)

        # LLM refinement for ambiguous cases
        if self.llm_client and intent.ambiguity_score > 0.3:
            intent = self._llm_refine(intent)

        # Compute final metrics
        self._compute_metrics(intent)

        return intent

    def _rule_based_parse(self, text: str) -> ParsedIntent:
        """Extract slots using rule-based patterns."""
        text_lower = text.lower()
        words = text_lower.split()

        intent = ParsedIntent(raw_text=text)

        # Extract action (first verb-like token)
        for i, word in enumerate(words):
            # Check two-word phrases first
            if i < len(words) - 1:
                phrase = f"{word} {words[i+1]}"
                if phrase in self.ACTION_SYNONYMS:
                    intent.action = IntentSlot(
                        slot_type=SlotType.ACTION,
                        value=phrase,
                        normalized=self.ACTION_SYNONYMS[phrase],
                        span=(text_lower.find(phrase), text_lower.find(phrase) + len(phrase)),
                    )
                    break

            if word in self.ACTION_SYNONYMS:
                intent.action = IntentSlot(
                    slot_type=SlotType.ACTION,
                    value=word,
                    normalized=self.ACTION_SYNONYMS[word],
                    span=(text_lower.find(word), text_lower.find(word) + len(word)),
                )
                break

        # Extract color
        for color in self.COLORS:
            if color in text_lower:
                intent.color = IntentSlot(
                    slot_type=SlotType.COLOR,
                    value=color,
                    span=(text_lower.find(color), text_lower.find(color) + len(color)),
                )
                break

        # Extract object
        for obj in self.OBJECT_TYPES:
            if obj in text_lower:
                intent.object = IntentSlot(
                    slot_type=SlotType.OBJECT,
                    value=obj,
                    span=(text_lower.find(obj), text_lower.find(obj) + len(obj)),
                )
                break

        # Extract location/direction
        for loc in self.LOCATIONS:
            if loc in text_lower:
                # Determine if it's source location or destination
                if intent.action and intent.action.normalized in ["place", "move"]:
                    intent.destination = IntentSlot(
                        slot_type=SlotType.DESTINATION,
                        value=loc,
                        span=(text_lower.find(loc), text_lower.find(loc) + len(loc)),
                    )
                else:
                    intent.location = IntentSlot(
                        slot_type=SlotType.LOCATION,
                        value=loc,
                        span=(text_lower.find(loc), text_lower.find(loc) + len(loc)),
                    )
                break

        # Extract modifiers
        for mod in self.MODIFIERS:
            if mod in text_lower:
                intent.modifiers.append(IntentSlot(
                    slot_type=SlotType.MODIFIER,
                    value=mod,
                    span=(text_lower.find(mod), text_lower.find(mod) + len(mod)),
                ))

        # Detect ambiguous references
        for ref in self.AMBIGUOUS_REFS:
            if ref in text_lower:
                intent.ambiguous_refs.append(ref)

        return intent

    def _llm_refine(self, intent: ParsedIntent) -> ParsedIntent:
        """Use LLM to resolve ambiguities."""
        if not self.llm_client:
            return intent

        # Build prompt for LLM
        prompt = f"""Parse this robot command into structured slots:
Command: "{intent.raw_text}"

Current parse:
- Action: {intent.action.normalized if intent.action else "MISSING"}
- Object: {intent.object.normalized if intent.object else "MISSING"}
- Color: {intent.color.normalized if intent.color else "MISSING"}
- Location: {intent.location.normalized if intent.location else "MISSING"}
- Destination: {intent.destination.normalized if intent.destination else "MISSING"}
- Modifiers: {[m.normalized for m in intent.modifiers]}

Ambiguous references detected: {intent.ambiguous_refs}

Please clarify any ambiguous references and fill missing required slots.
Respond in JSON format."""

        # Call LLM (implementation depends on client type)
        # For now, return original intent
        return intent

    def _compute_metrics(self, intent: ParsedIntent) -> None:
        """Compute quality metrics for the parsed intent."""
        # Required slots for different actions
        required_by_action = {
            "pick": [SlotType.OBJECT],
            "place": [SlotType.DESTINATION],
            "move": [SlotType.OBJECT, SlotType.DESTINATION],
            "rotate": [SlotType.OBJECT],
            "open": [SlotType.OBJECT],
            "close": [SlotType.OBJECT],
            "press": [SlotType.OBJECT],
            "stack": [SlotType.OBJECT],
            "pour": [SlotType.OBJECT, SlotType.DESTINATION],
        }

        # Compute completeness
        if intent.action:
            action = intent.action.normalized
            required = required_by_action.get(action, [SlotType.OBJECT])

            filled = 0
            for slot_type in required:
                if slot_type == SlotType.OBJECT and intent.object:
                    filled += 1
                elif slot_type == SlotType.DESTINATION and intent.destination:
                    filled += 1
                elif slot_type == SlotType.LOCATION and intent.location:
                    filled += 1
                else:
                    intent.missing_slots.append(slot_type)

            intent.completeness = filled / len(required) if required else 1.0
        else:
            intent.completeness = 0.0
            intent.missing_slots.append(SlotType.ACTION)

        # Compute ambiguity score
        ambiguity = 0.0
        if intent.ambiguous_refs:
            ambiguity += 0.3 * len(intent.ambiguous_refs)
        if intent.object and intent.object.normalized in ["thing", "object", "item"]:
            ambiguity += 0.4  # Generic object reference
        if not intent.action:
            ambiguity += 0.5

        intent.ambiguity_score = min(1.0, ambiguity)

        # Compute confidence
        slot_confidence = []
        if intent.action:
            slot_confidence.append(intent.action.confidence)
        if intent.object:
            slot_confidence.append(intent.object.confidence)
        if intent.color:
            slot_confidence.append(intent.color.confidence)
        if intent.location:
            slot_confidence.append(intent.location.confidence)
        if intent.destination:
            slot_confidence.append(intent.destination.confidence)

        if slot_confidence:
            base_conf = sum(slot_confidence) / len(slot_confidence)
        else:
            base_conf = 0.0

        # Penalize for incompleteness and ambiguity
        intent.confidence = base_conf * intent.completeness * (1 - 0.5 * intent.ambiguity_score)


__all__ = [
    "IntentParser",
    "ParsedIntent",
    "IntentSlot",
    "SlotType",
]
