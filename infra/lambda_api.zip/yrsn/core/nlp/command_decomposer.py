"""
Command Decomposer - R/S/N at the command level for robot control.

Unlike word-level decomposition, this assesses:
    R (Relevance): Can we execute this command? (intent clarity + skill match)
    S (Structure): Is the command well-formed? (grounding completeness)
    N (Noise): Is there ambiguity or safety risk? (uncertainty + danger)

This provides the quality gate between NLP and actuation.

Integration with Unitree:
    1. Voice → ASR (BenBen / external)
    2. Text → IntentParser (extract structured intent)
    3. Intent → CommandDecomposer (YRSN quality gate)
    4. If α > threshold → SkillMatcher → SDK actuation
    5. If α < threshold → Request clarification

Example:
    decomposer = CommandDecomposer(capabilities=robot.get_capabilities())

    intent = parser.parse("pick up the red cup")
    quality = decomposer.decompose(intent, scene=perception.objects)

    if quality.can_execute:
        action = quality.grounded_command.to_action()
        robot.execute(action)
    else:
        robot.say(quality.clarification_prompt)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set
import math

from .intent_parser import ParsedIntent, SlotType


@dataclass
class CommandQuality:
    """
    Quality metrics for a robot command at the command level.

    R/S/N Semantics (consistent with YRSN):
        R (Relevance): Task-relevant signal (action + grounded target)
        S (Superfluous): Neutral content (politeness, extra modifiers)
        N (Noise): Harmful content (ambiguity, safety risk, ungrounded refs)

    High α = R/(R+S+N) means command is clear, grounded, and safe.
    """

    # R/S/N decomposition (each 0-1, normalized to sum to ~1)
    relevance: float      # R: Action + grounded target + skill match
    superfluous: float    # S: Politeness, extra modifiers, verbose
    noise: float          # N: Ambiguity + ungrounded refs + safety risk

    # Derived metrics
    alpha: float = 0.0    # α = R / (R + S + N)
    confidence: float = 0.0

    # Execution decision
    can_execute: bool = False
    execution_risk: float = 0.0  # 0 = safe, 1 = dangerous

    # Issues for clarification
    issues: List[str] = field(default_factory=list)
    clarification_prompt: Optional[str] = None

    # Backwards compatibility alias
    @property
    def structure(self) -> float:
        return self.superfluous

    def __post_init__(self):
        total = self.relevance + self.superfluous + self.noise
        if total > 0:
            # Normalize to ensure proper alpha computation
            self.alpha = self.relevance / total
        self.confidence = self.alpha * (1 - self.execution_risk)


@dataclass
class CommandDecomposition:
    """Full decomposition result for a robot command."""

    intent: ParsedIntent
    quality: CommandQuality

    # Grounding results
    grounded_objects: Dict[str, str] = field(default_factory=dict)  # ref → object_id
    matched_skill: Optional[str] = None
    skill_confidence: float = 0.0

    # Scene context used
    scene_objects: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def can_execute(self) -> bool:
        return self.quality.can_execute

    @property
    def needs_clarification(self) -> bool:
        return not self.can_execute and len(self.quality.issues) > 0


class CommandDecomposer:
    """
    Decompose robot commands into R/S/N quality signals.

    This is the YRSN quality gate for robot command execution.
    Unlike word-level decomposition, it assesses the entire command
    in context of robot capabilities and scene state.

    Usage:
        decomposer = CommandDecomposer(
            capabilities=["pick", "place", "move", "rotate"],
            safety_rules=["no_pick_while_moving", "no_close_on_finger"],
        )

        quality = decomposer.decompose(intent, scene_objects)

        if quality.can_execute:
            execute(intent)
        else:
            ask_clarification(quality.issues)

    Configuration:
        Thresholds can be loaded from consumer/base_learner_config.yaml:

        from yrsn.consumer import get_command_decomposer_config
        config = get_command_decomposer_config()
        decomposer = CommandDecomposer(**config)
    """

    # Default thresholds (can be overridden by consumer config)
    DEFAULT_ALPHA_THRESHOLD = 0.6
    DEFAULT_SAFETY_THRESHOLD = 0.8

    # Safety-critical actions (require higher α threshold)
    SAFETY_CRITICAL_ACTIONS = {
        "press", "close", "rotate", "pour",
    }

    # Actions that need specific objects
    OBJECT_REQUIRED_ACTIONS = {
        "pick", "grasp", "grab", "lift", "rotate", "open", "close", "press",
    }

    # Actions that need destinations
    DESTINATION_REQUIRED_ACTIONS = {
        "place", "put", "move", "pour",
    }

    # Default capabilities
    DEFAULT_CAPABILITIES = [
        "pick", "place", "move", "rotate", "open", "close", "press", "stack",
    ]

    def __init__(
        self,
        capabilities: Optional[List[str]] = None,
        safety_rules: Optional[List[str]] = None,
        alpha_threshold: float = None,
        safety_threshold: float = None,
    ):
        """
        Initialize command decomposer.

        Args:
            capabilities: List of robot skill names
            safety_rules: List of safety constraint names
            alpha_threshold: Minimum α for execution
            safety_threshold: Minimum α for safety-critical actions
        """
        self.capabilities = set(capabilities or self.DEFAULT_CAPABILITIES)
        self.safety_rules = safety_rules or []
        self.alpha_threshold = alpha_threshold if alpha_threshold is not None else self.DEFAULT_ALPHA_THRESHOLD
        self.safety_threshold = safety_threshold if safety_threshold is not None else self.DEFAULT_SAFETY_THRESHOLD

    def decompose(
        self,
        intent: ParsedIntent,
        scene_objects: Optional[List[Dict[str, Any]]] = None,
    ) -> CommandDecomposition:
        """
        Decompose command into R/S/N quality signals.

        Args:
            intent: Parsed intent from IntentParser
            scene_objects: Current scene objects for grounding

        Returns:
            CommandDecomposition with quality metrics and grounding
        """
        scene_objects = scene_objects or []

        # Compute R: Relevance (intent clarity + grounding + skill match)
        r_score, r_issues, grounded = self._compute_relevance(intent, scene_objects)

        # Compute S: Superfluous (politeness, filler, verbose content)
        s_score = self._compute_superfluous(intent)

        # Compute N: Noise (ambiguity + ungrounded refs + safety risk)
        n_score, n_issues, risk = self._compute_noise(intent, scene_objects)

        # Build quality
        quality = CommandQuality(
            relevance=r_score,
            superfluous=s_score,
            noise=n_score,
            execution_risk=risk,
            issues=r_issues + n_issues,
        )

        # Determine if executable
        threshold = self.safety_threshold if self._is_safety_critical(intent) else self.alpha_threshold
        quality.can_execute = (
            quality.alpha >= threshold and
            quality.execution_risk < 0.5 and
            len(quality.issues) == 0
        )

        # Generate clarification prompt if needed
        if not quality.can_execute and quality.issues:
            quality.clarification_prompt = self._generate_clarification(quality.issues)

        # Find matched skill
        matched_skill = None
        skill_confidence = 0.0
        if intent.action and intent.action.normalized in self.capabilities:
            matched_skill = intent.action.normalized
            skill_confidence = intent.action.confidence

        return CommandDecomposition(
            intent=intent,
            quality=quality,
            grounded_objects=grounded,
            matched_skill=matched_skill,
            skill_confidence=skill_confidence,
            scene_objects=scene_objects,
        )

    def _compute_relevance(
        self,
        intent: ParsedIntent,
        scene_objects: List[Dict[str, Any]],
    ) -> tuple:
        """
        Compute R score: intent clarity + grounding success + capability match.

        High R means:
        - Clear action specified and matches capability
        - Object/target successfully grounded in scene
        - Complete command structure
        """
        issues = []
        grounded = {}
        score = 0.0

        # Action + Capability match (35% of R)
        if intent.action:
            if intent.action.normalized in self.capabilities:
                score += 0.35  # Full credit for matching capability
            else:
                score += 0.15  # Partial credit for having action
                issues.append(f"Unknown capability: {intent.action.value}")
        else:
            issues.append("No action specified")

        # Object grounding (40% of R)
        if intent.object:
            obj_name = intent.object.normalized
            color = intent.color.normalized if intent.color else None
            location = intent.location.normalized if intent.location else None

            matches = self._find_matching_objects(scene_objects, obj_name, color, location)

            if len(matches) == 1:
                # Perfect grounding
                grounded[obj_name] = matches[0]["id"]
                score += 0.40
            elif len(matches) > 1:
                # Ambiguous - partial credit
                grounded[obj_name] = matches[0]["id"]  # Best guess
                score += 0.20
            elif not scene_objects:
                # No scene context - assume grounding will work
                score += 0.30
            else:
                issues.append(f"Cannot find '{obj_name}' in scene")
        elif intent.action and intent.action.normalized in self.OBJECT_REQUIRED_ACTIONS:
            issues.append("Object required but not specified")
        else:
            score += 0.30  # No object needed

        # Spatial reference (25% of R)
        if intent.destination:
            score += 0.25  # Has destination
        elif intent.location:
            score += 0.20  # Has location context
        elif intent.action and intent.action.normalized in self.DESTINATION_REQUIRED_ACTIONS:
            issues.append("Destination required but not specified")
        else:
            score += 0.20  # Not required

        return score, issues, grounded

    def _compute_superfluous(self, intent: ParsedIntent) -> float:
        """
        Compute S score: superfluous/neutral content.

        Detects:
        - Politeness markers ("please", "kindly")
        - Verbose phrasing
        - Redundant modifiers
        """
        score = 0.0

        # Check raw text for politeness markers
        text_lower = intent.raw_text.lower()
        politeness = ["please", "kindly", "would you", "could you", "can you"]
        for marker in politeness:
            if marker in text_lower:
                score += 0.1

        # Extra modifiers beyond the essential
        if len(intent.modifiers) > 1:
            score += 0.1 * (len(intent.modifiers) - 1)

        # Verbose command (many words for simple action)
        word_count = len(intent.raw_text.split())
        if word_count > 8:
            score += 0.1 * min(1.0, (word_count - 8) / 10)

        return min(0.3, score)  # Cap S to keep R dominant for good commands

    def _compute_noise(
        self,
        intent: ParsedIntent,
        scene_objects: List[Dict[str, Any]],
    ) -> tuple:
        """
        Compute N score: ambiguity + safety risk.

        High N means:
        - Ambiguous references
        - Safety risks
        - Low parser confidence
        """
        issues = []
        risk = 0.0
        score = 0.0

        # Ambiguity from parser
        score += 0.4 * intent.ambiguity_score

        # Safety risk assessment
        if intent.action:
            action = intent.action.normalized

            # Safety-critical actions
            if action in self.SAFETY_CRITICAL_ACTIONS:
                if not intent.object:
                    risk += 0.3
                    issues.append(f"'{action}' requires clear target object")

            # Check for dangerous modifiers
            for mod in intent.modifiers:
                if mod.normalized in ["fast", "quickly", "hard"]:
                    risk += 0.2
                    issues.append(f"'{mod.value}' may be unsafe - consider 'carefully'")

            # Check for collision risk
            if action in ["move", "push", "slide"] and len(scene_objects) > 3:
                risk += 0.1  # More objects = more collision risk

        # Low confidence adds to noise
        if intent.confidence < 0.5:
            score += 0.3 * (1 - intent.confidence)

        # Missing required slots add to noise
        if intent.missing_slots:
            score += 0.2 * len(intent.missing_slots)

        return min(1.0, score), issues, min(1.0, risk)

    def _is_safety_critical(self, intent: ParsedIntent) -> bool:
        """Check if command is safety-critical."""
        if not intent.action:
            return True  # Unknown action = assume dangerous
        return intent.action.normalized in self.SAFETY_CRITICAL_ACTIONS

    def _find_matching_objects(
        self,
        scene_objects: List[Dict[str, Any]],
        obj_type: str,
        color: Optional[str],
        location: Optional[str],
    ) -> List[Dict[str, Any]]:
        """Find objects matching the description."""
        matches = []

        for obj in scene_objects:
            # Type match
            obj_types = obj.get("type", "").lower()
            if obj_type not in obj_types and obj_types not in obj_type:
                continue

            # Color match (if specified)
            if color:
                obj_color = obj.get("color", "").lower()
                if color != obj_color:
                    continue

            # Location match (if specified)
            if location:
                obj_location = obj.get("location", "").lower()
                if obj_location:
                    # Explicit location field
                    if location not in obj_location:
                        continue
                else:
                    # Infer from position coordinates
                    pos = obj.get("position", [0, 0, 0])
                    if not self._matches_spatial_location(pos, location):
                        continue

            matches.append(obj)

        return matches

    def _matches_spatial_location(self, position: List[float], location: str) -> bool:
        """Check if position matches spatial location description."""
        if len(position) < 2:
            return True  # Can't filter without coordinates

        x, y = position[0], position[1]

        # Left/Right based on x-coordinate (negative = left in robot frame)
        if location == "left":
            return x < 0
        if location == "right":
            return x > 0

        # Front/Back based on y-coordinate
        if location in ["front", "forward"]:
            return y > 0
        if location in ["back", "backward"]:
            return y < 0

        # Up/Down based on z-coordinate
        if len(position) >= 3:
            z = position[2]
            if location in ["up", "top", "above"]:
                return z > 0.3
            if location in ["down", "bottom", "below"]:
                return z < 0.1

        # Can't determine - allow match
        return True

    def _generate_clarification(self, issues: List[str]) -> str:
        """Generate a clarification prompt from issues."""
        if not issues:
            return "Please repeat your command."

        if len(issues) == 1:
            return f"I need clarification: {issues[0]}"

        return "I need clarification:\n" + "\n".join(f"- {issue}" for issue in issues)


__all__ = [
    "CommandDecomposer",
    "CommandDecomposition",
    "CommandQuality",
]
