"""
YRSN NLP Module - Command-Level Understanding for Robot Control.

Provides semantic decomposition at the COMMAND level, not word level.
Integrates with robot NLP stacks (Unitree UnifoLM, external LLMs).

Architecture:
    Voice/Text → Intent Parser → Grounding → Capability Check → Safety Gate → SDK

Key Components:
    CommandDecomposer: R/S/N at command level (intent clarity, grounding, ambiguity)
    IntentParser: Extract structured intent from natural language
    SkillMatcher: Match intent to robot capabilities
    GroundingValidator: Resolve object references to scene objects
    SafetyGate: Block unsafe commands before actuation

YRSN Quality Signals at Command Level:
    R (Relevance): Intent clarity + skill match confidence
    S (Structure): Grounding completeness (can we resolve all references?)
    N (Noise): Ambiguity + safety risk + capability mismatch

Usage:
    from yrsn.core.nlp import CommandDecomposer, IntentParser

    # Parse command
    parser = IntentParser(skill_catalog=robot.get_skills())
    intent = parser.parse("pick up the red cup carefully")

    # Decompose at command level
    decomposer = CommandDecomposer(robot_capabilities=robot.capabilities)
    quality = decomposer.decompose(intent, scene_context=perception.objects)

    # Quality gate
    if quality.alpha > 0.7:
        robot.execute(intent.to_action())
    else:
        robot.ask_clarification(quality.ambiguities)
"""

from .command_decomposer import (
    CommandDecomposer,
    CommandDecomposition,
    CommandQuality,
)
from .intent_parser import (
    IntentParser,
    ParsedIntent,
    IntentSlot,
    SlotType,
)
from .skill_matcher import (
    SkillMatcher,
    SkillMatch,
    SkillCatalog,
)
from .grounding import (
    GroundingValidator,
    GroundedCommand,
    ObjectReference,
)

__all__ = [
    # Command decomposition
    "CommandDecomposer",
    "CommandDecomposition",
    "CommandQuality",
    # Intent parsing
    "IntentParser",
    "ParsedIntent",
    "IntentSlot",
    "SlotType",
    # Skill matching
    "SkillMatcher",
    "SkillMatch",
    "SkillCatalog",
    # Grounding
    "GroundingValidator",
    "GroundedCommand",
    "ObjectReference",
]
