"""
Skill Matcher - Match parsed intents to robot capabilities.

Maps natural language actions to robot skill primitives,
handling synonyms, skill parameters, and capability constraints.

Integration:
    - Unitree SDK: Query available skills from robot
    - Custom skills: Register domain-specific skills
    - Parameterized skills: Match intent slots to skill arguments
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable
from enum import Enum


class SkillCategory(str, Enum):
    """Categories of robot skills."""

    MANIPULATION = "manipulation"  # pick, place, grasp
    LOCOMOTION = "locomotion"      # walk, turn, balance
    INTERACTION = "interaction"    # open, close, press
    PERCEPTION = "perception"      # look, scan, find
    COMMUNICATION = "communication"  # say, gesture


@dataclass
class SkillParameter:
    """A parameter for a robot skill."""

    name: str
    param_type: str  # "object", "position", "speed", etc.
    required: bool = True
    default: Any = None


@dataclass
class SkillDefinition:
    """Definition of a robot skill/primitive."""

    name: str
    category: SkillCategory
    description: str
    parameters: List[SkillParameter] = field(default_factory=list)
    synonyms: List[str] = field(default_factory=list)
    preconditions: List[str] = field(default_factory=list)  # e.g., "gripper_empty"
    effects: List[str] = field(default_factory=list)  # e.g., "holding_object"

    def matches_action(self, action: str) -> bool:
        """Check if action name matches this skill."""
        action = action.lower()
        return action == self.name or action in self.synonyms


@dataclass
class SkillMatch:
    """Result of matching an intent to a skill."""

    skill: SkillDefinition
    confidence: float
    bound_parameters: Dict[str, Any] = field(default_factory=dict)
    missing_parameters: List[str] = field(default_factory=list)
    precondition_issues: List[str] = field(default_factory=list)

    @property
    def can_execute(self) -> bool:
        return (
            len(self.missing_parameters) == 0 and
            len(self.precondition_issues) == 0
        )


class SkillCatalog:
    """
    Catalog of available robot skills.

    Provides:
    - Skill registration and lookup
    - Action → skill matching
    - Parameter binding from intent
    """

    def __init__(self):
        self.skills: Dict[str, SkillDefinition] = {}
        self._register_default_skills()

    def _register_default_skills(self):
        """Register common robot skills."""
        # Manipulation skills
        self.register(SkillDefinition(
            name="pick",
            category=SkillCategory.MANIPULATION,
            description="Pick up an object",
            parameters=[
                SkillParameter("object_id", "object", required=True),
                SkillParameter("grasp_type", "string", required=False, default="power"),
            ],
            synonyms=["grasp", "grab", "lift", "take", "get"],
            preconditions=["gripper_empty"],
            effects=["holding_object"],
        ))

        self.register(SkillDefinition(
            name="place",
            category=SkillCategory.MANIPULATION,
            description="Place held object at location",
            parameters=[
                SkillParameter("position", "position", required=True),
                SkillParameter("orientation", "orientation", required=False),
            ],
            synonyms=["put", "put down", "set", "release"],
            preconditions=["holding_object"],
            effects=["gripper_empty"],
        ))

        self.register(SkillDefinition(
            name="move",
            category=SkillCategory.MANIPULATION,
            description="Move object to new position",
            parameters=[
                SkillParameter("object_id", "object", required=True),
                SkillParameter("target_position", "position", required=True),
            ],
            synonyms=["push", "pull", "slide", "drag"],
        ))

        # Interaction skills
        self.register(SkillDefinition(
            name="open",
            category=SkillCategory.INTERACTION,
            description="Open a door, drawer, or container",
            parameters=[
                SkillParameter("object_id", "object", required=True),
            ],
            synonyms=[],
        ))

        self.register(SkillDefinition(
            name="close",
            category=SkillCategory.INTERACTION,
            description="Close a door, drawer, or container",
            parameters=[
                SkillParameter("object_id", "object", required=True),
            ],
            synonyms=["shut"],
        ))

        self.register(SkillDefinition(
            name="press",
            category=SkillCategory.INTERACTION,
            description="Press a button or switch",
            parameters=[
                SkillParameter("object_id", "object", required=True),
                SkillParameter("force", "float", required=False, default=5.0),
            ],
            synonyms=["push", "click", "tap"],
        ))

        self.register(SkillDefinition(
            name="rotate",
            category=SkillCategory.MANIPULATION,
            description="Rotate object or robot",
            parameters=[
                SkillParameter("angle", "float", required=True),
                SkillParameter("object_id", "object", required=False),
            ],
            synonyms=["turn", "spin", "twist"],
        ))

    def register(self, skill: SkillDefinition) -> None:
        """Register a skill in the catalog."""
        self.skills[skill.name] = skill

    def get(self, name: str) -> Optional[SkillDefinition]:
        """Get skill by name."""
        return self.skills.get(name)

    def find_by_action(self, action: str) -> Optional[SkillDefinition]:
        """Find skill matching an action name."""
        action = action.lower()

        # Direct match
        if action in self.skills:
            return self.skills[action]

        # Synonym match
        for skill in self.skills.values():
            if skill.matches_action(action):
                return skill

        return None

    def list_skills(self, category: Optional[SkillCategory] = None) -> List[str]:
        """List available skill names."""
        if category:
            return [s.name for s in self.skills.values() if s.category == category]
        return list(self.skills.keys())


class SkillMatcher:
    """
    Match parsed intents to robot skills.

    Takes a ParsedIntent and finds the best matching skill,
    binding intent slots to skill parameters.
    """

    def __init__(self, catalog: Optional[SkillCatalog] = None):
        self.catalog = catalog or SkillCatalog()

    def match(
        self,
        intent: Any,  # ParsedIntent
        robot_state: Optional[Dict[str, Any]] = None,
    ) -> Optional[SkillMatch]:
        """
        Match intent to a skill.

        Args:
            intent: Parsed intent from IntentParser
            robot_state: Current robot state for precondition checking

        Returns:
            SkillMatch if found, None otherwise
        """
        if not intent.action:
            return None

        action = intent.action.normalized
        skill = self.catalog.find_by_action(action)

        if not skill:
            return None

        # Bind parameters from intent
        bound = {}
        missing = []

        for param in skill.parameters:
            value = self._extract_parameter(intent, param)
            if value is not None:
                bound[param.name] = value
            elif param.required:
                missing.append(param.name)
            elif param.default is not None:
                bound[param.name] = param.default

        # Check preconditions
        precond_issues = []
        if robot_state:
            for precond in skill.preconditions:
                if not self._check_precondition(precond, robot_state):
                    precond_issues.append(f"Precondition not met: {precond}")

        # Compute confidence
        confidence = intent.action.confidence
        if missing:
            confidence *= 0.5
        if precond_issues:
            confidence *= 0.3

        return SkillMatch(
            skill=skill,
            confidence=confidence,
            bound_parameters=bound,
            missing_parameters=missing,
            precondition_issues=precond_issues,
        )

    def _extract_parameter(self, intent: Any, param: SkillParameter) -> Any:
        """Extract parameter value from intent."""
        if param.param_type == "object":
            if intent.object:
                return intent.object.normalized
        elif param.param_type == "position":
            if intent.destination:
                return intent.destination.normalized
            if intent.location:
                return intent.location.normalized
        elif param.param_type == "speed":
            for mod in intent.modifiers:
                if mod.normalized in ["slowly", "carefully"]:
                    return 0.3
                if mod.normalized in ["quickly", "fast"]:
                    return 1.0
        return None

    def _check_precondition(self, precond: str, state: Dict[str, Any]) -> bool:
        """Check if precondition is satisfied."""
        # Simple state lookup
        return state.get(precond, False)


__all__ = [
    "SkillMatcher",
    "SkillMatch",
    "SkillCatalog",
    "SkillDefinition",
    "SkillParameter",
    "SkillCategory",
]
