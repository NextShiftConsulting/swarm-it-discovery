"""
Capability Registry - Agent Discovery and Health Tracking.

Maintains a registry of available agents and their current state:
    - Dynamic agent registration/deregistration
    - Health tracking via YRSNCertificates
    - Capability-based lookup
    - Request metrics tracking

Example:
    registry = CapabilityRegistry()

    # Register agents
    registry.register(Offer(
        agent_id="encoder-1",
        capabilities=frozenset({Capability.RE_ENCODE}),
        current_quality=0.9,
        avg_latency_ms=50,
    ))

    # Find candidates for a need
    need = Need(required_capability=Capability.RE_ENCODE, min_quality=0.8)
    candidates = registry.find_candidates(need)

    # Update health from certificate
    registry.update_health("encoder-1", certificate)

    # Record request outcome
    registry.record_request("encoder-1", latency_ms=45, success=True)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Set, List, Optional, Any, TYPE_CHECKING
import logging

from .descriptors import Capability, Offer, Need

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


logger = logging.getLogger(__name__)


@dataclass
class AgentMetrics:
    """
    Tracking metrics for an agent.

    Attributes:
        total_requests: Total number of requests
        successful_requests: Number of successful requests
        failed_requests: Number of failed requests
        total_latency_ms: Sum of latencies for successful requests
        last_certificate: Most recent certificate from agent
    """

    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    total_latency_ms: float = 0.0
    last_certificate: Optional["YRSNCertificate"] = None

    @property
    def success_rate(self) -> float:
        """
        Calculate success rate.

        Returns:
            Success rate in [0, 1], or 0 if no requests
        """
        if self.total_requests == 0:
            return 0.0
        return self.successful_requests / self.total_requests

    @property
    def avg_latency_ms(self) -> float:
        """
        Calculate average latency.

        Returns:
            Average latency in ms, or 0 if no successful requests
        """
        if self.successful_requests == 0:
            return 0.0
        return self.total_latency_ms / self.successful_requests

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "success_rate": round(self.success_rate, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "has_certificate": self.last_certificate is not None,
        }


class CapabilityRegistry:
    """
    Registry of available agents and their capabilities.

    Tracks:
        - Agent offers (capabilities, quality, latency)
        - Health metrics from certificates
        - Request metrics (success rate, latency)

    Thread-safety note: This implementation is NOT thread-safe.
    For concurrent use, wrap with appropriate locking.
    """

    def __init__(self):
        """Initialize empty registry."""
        self._agents: Dict[str, Offer] = {}
        self._metrics: Dict[str, AgentMetrics] = {}
        self._capability_index: Dict[Capability, Set[str]] = {}
        logger.info("CapabilityRegistry initialized")

    def register(self, offer: Offer) -> None:
        """
        Register an agent.

        If agent already exists, updates the registration.

        Args:
            offer: Agent's offer (capabilities, quality, etc.)
        """
        agent_id = offer.agent_id

        # Remove from old capability index if updating
        if agent_id in self._agents:
            old_offer = self._agents[agent_id]
            for capability in old_offer.capabilities:
                if capability in self._capability_index:
                    self._capability_index[capability].discard(agent_id)

        # Add to registry
        self._agents[agent_id] = offer
        if agent_id not in self._metrics:
            self._metrics[agent_id] = AgentMetrics()

        # Update capability index
        for capability in offer.capabilities:
            if capability not in self._capability_index:
                self._capability_index[capability] = set()
            self._capability_index[capability].add(agent_id)

        logger.info(
            f"Registered agent '{agent_id}' with capabilities: "
            f"{[c.name for c in offer.capabilities]}, quality={offer.current_quality:.2f}"
        )

    def deregister(self, agent_id: str) -> None:
        """
        Remove agent from registry.

        Args:
            agent_id: Agent identifier
        """
        if agent_id not in self._agents:
            return

        offer = self._agents[agent_id]

        # Remove from capability index
        for capability in offer.capabilities:
            if capability in self._capability_index:
                self._capability_index[capability].discard(agent_id)

        # Remove from main registry
        del self._agents[agent_id]
        # Remove metrics
        if agent_id in self._metrics:
            del self._metrics[agent_id]
        logger.info(f"Deregistered agent '{agent_id}'")

    def get_offer(self, agent_id: str) -> Optional[Offer]:
        """
        Get offer for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            Offer if found, None otherwise
        """
        return self._agents.get(agent_id)

    def update_health(self, agent_id: str, certificate: "YRSNCertificate") -> None:
        """
        Update agent health from certificate.

        Updates:
            - current_quality from certificate.alpha
            - health_score from certificate.health_score (1 - N)

        Args:
            agent_id: Agent identifier
            certificate: Latest YRSNCertificate from agent
        """
        if agent_id not in self._agents:
            logger.warning(f"Cannot update health for unknown agent '{agent_id}'")
            return

        # Update metrics
        metrics = self._metrics[agent_id]
        metrics.last_certificate = certificate

        # Update offer with new quality
        old_offer = self._agents[agent_id]

        # Get health_score from certificate (defaults to 1 - N if not present)
        health_score = getattr(certificate, "health_score", 1.0 - certificate.N)

        new_offer = old_offer.with_updates(
            current_quality=certificate.alpha,
            health_score=health_score,
        )

        # Re-register with updated offer
        self._agents[agent_id] = new_offer

        logger.debug(
            f"Updated agent '{agent_id}' health: α={certificate.alpha:.3f}, "
            f"N={certificate.N:.3f}, health={health_score:.3f}"
        )

    def update_circuit_state(self, agent_id: str, state: str) -> None:
        """
        Update agent circuit breaker state.

        Args:
            agent_id: Agent identifier
            state: Circuit state (CLOSED, OPEN, HALF_OPEN)
        """
        if agent_id not in self._agents:
            return

        old_offer = self._agents[agent_id]
        new_offer = old_offer.with_updates(circuit_state=state)
        self._agents[agent_id] = new_offer
        logger.info(f"Agent '{agent_id}' circuit state: {state}")

    def update_latency(self, agent_id: str, avg_latency_ms: float) -> None:
        """
        Update agent average latency.

        Args:
            agent_id: Agent identifier
            avg_latency_ms: New average latency
        """
        if agent_id not in self._agents:
            return

        old_offer = self._agents[agent_id]
        new_offer = old_offer.with_updates(avg_latency_ms=avg_latency_ms)
        self._agents[agent_id] = new_offer

    def record_request(
        self,
        agent_id: str,
        latency_ms: float,
        success: bool,
    ) -> None:
        """
        Record request outcome for metrics.

        Args:
            agent_id: Agent that handled request
            latency_ms: Request latency in milliseconds
            success: Whether request succeeded
        """
        if agent_id not in self._metrics:
            return

        metrics = self._metrics[agent_id]
        metrics.total_requests += 1

        if success:
            metrics.successful_requests += 1
            metrics.total_latency_ms += latency_ms
            # Update offer with new average latency
            self.update_latency(agent_id, metrics.avg_latency_ms)
        else:
            metrics.failed_requests += 1

    def find_candidates(self, need: Need) -> List[Offer]:
        """
        Find agents that can satisfy the need.

        Filters by:
            - Has required capability
            - Meets quality threshold
            - Meets latency SLA
            - Circuit breaker not OPEN

        Args:
            need: Task requirements

        Returns:
            List of Offer objects that can satisfy the need
        """
        # Get agents with required capability
        agent_ids = self._capability_index.get(need.required_capability, set())

        # Filter by can_satisfy
        candidates = [
            self._agents[agent_id]
            for agent_id in agent_ids
            if agent_id in self._agents and self._agents[agent_id].can_satisfy(need)
        ]

        logger.debug(
            f"Found {len(candidates)} candidates for capability "
            f"{need.required_capability.name}"
        )
        return candidates

    def get_metrics(self, agent_id: str) -> Optional[AgentMetrics]:
        """
        Get metrics for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            AgentMetrics if found, None otherwise
        """
        return self._metrics.get(agent_id)

    def get_all_agents(self) -> List[Offer]:
        """
        Get all registered agents.

        Returns:
            List of all registered Offers
        """
        return list(self._agents.values())

    def get_agents_by_capability(self, capability: Capability) -> List[Offer]:
        """
        Get all agents with a specific capability.

        Args:
            capability: The capability to filter by

        Returns:
            List of Offers with the capability
        """
        agent_ids = self._capability_index.get(capability, set())
        return [self._agents[aid] for aid in agent_ids if aid in self._agents]

    def __len__(self) -> int:
        """Return number of registered agents."""
        return len(self._agents)

    def to_dict(self) -> Dict[str, Any]:
        """
        Export registry state.

        Returns:
            Dictionary with registry state
        """
        return {
            "total_agents": len(self._agents),
            "agents": [offer.to_dict() for offer in self._agents.values()],
            "capabilities": {
                cap.name: list(agents) for cap, agents in self._capability_index.items()
            },
            "metrics": {
                agent_id: metrics.to_dict()
                for agent_id, metrics in self._metrics.items()
            },
        }
