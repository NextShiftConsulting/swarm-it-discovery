"""
Need/Offer Descriptors for Agent Routing.

Defines:
    - Capability: What agents can do (RE_ENCODE, INFERENCE_LLM, etc.)
    - Need: What a task requires (capability, quality level, latency SLA)
    - Offer: What an agent provides (capabilities, current quality, health)

These descriptors bridge ControlDecision (from UnifiedQualityController)
to agent selection (via CapabilityRegistry and SemanticRouter).

Example:
    # Convert control decision to routing need
    decision = controller.decide(certificate)
    need = Need.from_control_decision(decision)

    # Check if an agent can satisfy the need
    offer = Offer(
        agent_id="encoder-1",
        capabilities=frozenset({Capability.RE_ENCODE}),
        current_quality=0.9,
        avg_latency_ms=50,
    )
    if offer.can_satisfy(need):
        # Route to this agent
        pass
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import FrozenSet, Dict, Any, Optional, TYPE_CHECKING
import math

if TYPE_CHECKING:
    from yrsn.core.enforcement import (
        ControlDecision,
        ControlAction,
        GearState,
    )


class Capability(Enum):
    """
    Agent capabilities.

    Maps to ControlAction for routing:
        ControlAction.RE_ENCODE → Capability.RE_ENCODE
        ControlAction.FILTER_CONTEXT → Capability.FILTER_CONTEXT
        etc.

    Additional capabilities for inference backends:
        INFERENCE_LLM: LLM-based inference (Claude, GPT-4, Gemini)
        INFERENCE_HRMV: HRMV solver
        INFERENCE_TRM: TRM solver
    """

    # From ControlAction
    RE_ENCODE = auto()
    FILTER_CONTEXT = auto()
    RECALIBRATE = auto()
    SUPPRESS = auto()
    DEFER_HUMAN = auto()
    GATE_ADAPTATION = auto()

    # Inference backends
    INFERENCE_LLM = auto()
    INFERENCE_HRMV = auto()
    INFERENCE_TRM = auto()

    # Utility
    PROCEED = auto()  # Default pass-through


# Mapping from ControlAction to Capability
_ACTION_TO_CAPABILITY: Dict[str, Capability] = {
    "RE_ENCODE": Capability.RE_ENCODE,
    "FILTER_CONTEXT": Capability.FILTER_CONTEXT,
    "RECALIBRATE": Capability.RECALIBRATE,
    "SUPPRESS": Capability.SUPPRESS,
    "DEFER_HUMAN": Capability.DEFER_HUMAN,
    "GATE_ADAPTATION": Capability.GATE_ADAPTATION,
    "PROCEED": Capability.PROCEED,
    "PROCEED_CAUTIOUS": Capability.PROCEED,
    "REJECT": Capability.SUPPRESS,
    "REVERSE_GATE": Capability.SUPPRESS,
}

# Mapping from GearState to minimum quality threshold
_GEAR_TO_MIN_QUALITY: Dict[int, float] = {
    1: 0.8,   # FIRST gear → high quality required
    2: 0.6,   # SECOND gear → moderate quality
    3: 0.3,   # THIRD gear → low quality acceptable
    4: 0.0,   # FOURTH gear → any quality
    -1: 0.0,  # REVERSE → any quality (emergency)
}


@dataclass(frozen=True)
class Need:
    """
    Describes what a task needs from routing.

    Derived from ControlDecision:
        - required_capability: From decision.action (RE_ENCODE, SUPPRESS, etc.)
        - min_quality: From decision.gear (1st=0.8, 2nd=0.6, etc.)
        - max_latency_ms: SLA requirement
        - prefer_local: Prefer local agents over remote

    Attributes:
        required_capability: The capability needed to handle this task
        min_quality: Minimum α (quality) required from the agent
        max_latency_ms: Maximum acceptable latency in milliseconds
        prefer_local: Whether to prefer local agents over remote
        metadata: Additional context for routing decisions
    """

    required_capability: Capability
    min_quality: float = 0.0
    max_latency_ms: float = math.inf
    prefer_local: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate constraints."""
        if not 0.0 <= self.min_quality <= 1.0:
            raise ValueError(f"min_quality must be in [0, 1], got {self.min_quality}")
        if self.max_latency_ms < 0:
            raise ValueError(f"max_latency_ms must be >= 0, got {self.max_latency_ms}")

    @classmethod
    def from_control_decision(cls, decision: "ControlDecision") -> "Need":
        """
        Convert ControlDecision to Need.

        Maps:
            decision.action → required_capability
            decision.gear → min_quality

        Args:
            decision: ControlDecision from UnifiedQualityController

        Returns:
            Need instance for routing
        """
        # Map action to capability
        action_name = decision.action.name
        capability = _ACTION_TO_CAPABILITY.get(action_name, Capability.PROCEED)

        # Map gear to min quality
        gear_value = decision.gear.value if hasattr(decision.gear, "value") else decision.gear
        min_quality = _GEAR_TO_MIN_QUALITY.get(gear_value, 0.0)

        return cls(
            required_capability=capability,
            min_quality=min_quality,
            metadata={
                "degradation": decision.degradation.name,
                "gear": decision.gear.name if hasattr(decision.gear, "name") else str(decision.gear),
                "rationale": decision.rationale,
            },
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "required_capability": self.required_capability.name,
            "min_quality": self.min_quality,
            "max_latency_ms": self.max_latency_ms if self.max_latency_ms != math.inf else None,
            "prefer_local": self.prefer_local,
            "metadata": self.metadata,
        }


@dataclass(frozen=True)
class Offer:
    """
    Describes what an agent offers.

    Attributes:
        agent_id: Unique agent identifier
        capabilities: Set of Capability enums this agent supports
        current_quality: Agent's current α value (quality signal)
        avg_latency_ms: Average response time in milliseconds
        health_score: Health score from certificate (1 - N), range [0, 1]
        circuit_state: Circuit breaker state (CLOSED, OPEN, HALF_OPEN)
        is_local: Whether agent is local or remote
        metadata: Additional context
    """

    agent_id: str
    capabilities: FrozenSet[Capability]
    current_quality: float
    avg_latency_ms: float
    health_score: float = 1.0
    circuit_state: str = "CLOSED"
    is_local: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate constraints."""
        if not self.agent_id:
            raise ValueError("agent_id cannot be empty")
        if not 0.0 <= self.current_quality <= 1.0:
            raise ValueError(f"current_quality must be in [0, 1], got {self.current_quality}")
        if not 0.0 <= self.health_score <= 1.0:
            raise ValueError(f"health_score must be in [0, 1], got {self.health_score}")
        if self.avg_latency_ms < 0:
            raise ValueError(f"avg_latency_ms must be >= 0, got {self.avg_latency_ms}")
        if self.circuit_state not in ("CLOSED", "OPEN", "HALF_OPEN"):
            raise ValueError(f"circuit_state must be CLOSED/OPEN/HALF_OPEN, got {self.circuit_state}")

    def can_satisfy(self, need: Need) -> bool:
        """
        Check if this offer can satisfy the need.

        Checks:
            1. Has required capability
            2. Meets quality threshold
            3. Meets latency SLA
            4. Circuit breaker is not OPEN

        Args:
            need: The task requirements

        Returns:
            True if this offer can satisfy the need
        """
        # Must have required capability
        if need.required_capability not in self.capabilities:
            return False

        # Must meet quality threshold
        if self.current_quality < need.min_quality:
            return False

        # Must meet latency SLA
        if self.avg_latency_ms > need.max_latency_ms:
            return False

        # Circuit breaker check (OPEN blocks, HALF_OPEN allows test traffic)
        if self.circuit_state == "OPEN":
            return False

        return True

    def with_updates(
        self,
        current_quality: Optional[float] = None,
        avg_latency_ms: Optional[float] = None,
        health_score: Optional[float] = None,
        circuit_state: Optional[str] = None,
    ) -> "Offer":
        """
        Create a new Offer with updated values.

        Since Offer is frozen, this creates a new instance.

        Args:
            current_quality: New quality value (optional)
            avg_latency_ms: New latency value (optional)
            health_score: New health score (optional)
            circuit_state: New circuit state (optional)

        Returns:
            New Offer with updated values
        """
        return Offer(
            agent_id=self.agent_id,
            capabilities=self.capabilities,
            current_quality=current_quality if current_quality is not None else self.current_quality,
            avg_latency_ms=avg_latency_ms if avg_latency_ms is not None else self.avg_latency_ms,
            health_score=health_score if health_score is not None else self.health_score,
            circuit_state=circuit_state if circuit_state is not None else self.circuit_state,
            is_local=self.is_local,
            metadata=self.metadata,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "agent_id": self.agent_id,
            "capabilities": [c.name for c in self.capabilities],
            "current_quality": round(self.current_quality, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "health_score": round(self.health_score, 4),
            "circuit_state": self.circuit_state,
            "is_local": self.is_local,
            "metadata": self.metadata,
        }
