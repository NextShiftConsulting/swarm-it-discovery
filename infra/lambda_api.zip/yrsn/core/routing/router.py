"""
Semantic Router - Best Route Selection.

Selects the optimal agent from candidates based on:
    - Quality signals (α)
    - Health metrics (1 - N)
    - Latency requirements
    - Local preference

Scoring formula:
    score = quality * W_q + health * W_h + (1 - norm_latency) * W_l + local * W_loc

Default weights:
    - Quality: 40%
    - Health: 30%
    - Latency: 20%
    - Local: 10%

Example:
    router = SemanticRouter()

    need = Need(required_capability=Capability.RE_ENCODE, min_quality=0.7)
    candidates = [offer1, offer2, offer3]

    decision = router.select_route(need, candidates)
    if decision.selected_agent:
        print(f"Route to: {decision.selected_agent}")
        print(f"Reason: {decision.reason.name}")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import List, Optional, Dict, Any, Tuple
import logging

from .descriptors import Need, Offer


logger = logging.getLogger(__name__)


class RouteSelectionReason(Enum):
    """Why was this route selected?"""

    HIGHEST_QUALITY = auto()  # Best α among candidates
    LOWEST_LATENCY = auto()  # Fastest response time
    HIGHEST_HEALTH = auto()  # Best health score
    LOCAL_PREFERENCE = auto()  # Preferred local agent
    BEST_SCORE = auto()  # Highest weighted score
    ONLY_CANDIDATE = auto()  # Only one option
    NO_CANDIDATES = auto()  # No candidates available


@dataclass(frozen=True)
class RouteDecision:
    """
    Immutable routing decision (P1 compliant - data only).

    Attributes:
        selected_agent: Chosen agent ID (None if no route found)
        selected_offer: Full offer of chosen agent
        reason: Why this route was selected
        score: Selection score (higher = better)
        alternatives: Other candidates considered
        rationale: Human-readable explanation
    """

    selected_agent: Optional[str]
    selected_offer: Optional[Offer]
    reason: RouteSelectionReason
    score: float
    alternatives: Tuple[Offer, ...] = ()
    rationale: str = ""

    @property
    def success(self) -> bool:
        """Whether routing succeeded."""
        return self.selected_agent is not None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "selected_agent": self.selected_agent,
            "reason": self.reason.name,
            "score": round(self.score, 4),
            "rationale": self.rationale,
            "alternatives_count": len(self.alternatives),
            "success": self.success,
            "offer": self.selected_offer.to_dict() if self.selected_offer else None,
        }


class SemanticRouter:
    """
    Route selector using quality-aware scoring.

    Scoring factors (configurable weights):
        - Quality (α): Agent's current quality signal
        - Health (1-N): Agent's health score
        - Latency: Inverse of normalized latency (lower is better)
        - Local preference: Bonus for local agents
    """

    # Default weights
    DEFAULT_QUALITY_WEIGHT = 0.4
    DEFAULT_HEALTH_WEIGHT = 0.3
    DEFAULT_LATENCY_WEIGHT = 0.2
    DEFAULT_LOCAL_WEIGHT = 0.1

    def __init__(
        self,
        quality_weight: float = DEFAULT_QUALITY_WEIGHT,
        health_weight: float = DEFAULT_HEALTH_WEIGHT,
        latency_weight: float = DEFAULT_LATENCY_WEIGHT,
        local_weight: float = DEFAULT_LOCAL_WEIGHT,
    ):
        """
        Initialize router with weights.

        Args:
            quality_weight: Weight for α (quality)
            health_weight: Weight for health_score (1-N)
            latency_weight: Weight for latency (lower is better)
            local_weight: Weight for local preference
        """
        self.quality_weight = quality_weight
        self.health_weight = health_weight
        self.latency_weight = latency_weight
        self.local_weight = local_weight

        logger.info(
            f"SemanticRouter initialized: Q={quality_weight}, H={health_weight}, "
            f"L={latency_weight}, Loc={local_weight}"
        )

    def select_route(self, need: Need, candidates: List[Offer]) -> RouteDecision:
        """
        Select best agent from candidates.

        Args:
            need: Task requirements
            candidates: Available agents (already filtered by can_satisfy)

        Returns:
            RouteDecision with selected agent (or None if no candidates)
        """
        if not candidates:
            return RouteDecision(
                selected_agent=None,
                selected_offer=None,
                reason=RouteSelectionReason.NO_CANDIDATES,
                score=0.0,
                rationale="No candidates available",
            )

        if len(candidates) == 1:
            offer = candidates[0]
            return RouteDecision(
                selected_agent=offer.agent_id,
                selected_offer=offer,
                reason=RouteSelectionReason.ONLY_CANDIDATE,
                score=self._score_offer(offer, need),
                rationale=f"Only candidate: {offer.agent_id}",
            )

        # Score all candidates
        scored: List[Tuple[Offer, float]] = [
            (offer, self._score_offer(offer, need)) for offer in candidates
        ]
        scored.sort(key=lambda x: x[1], reverse=True)

        best_offer, best_score = scored[0]

        # Determine selection reason
        reason = self._determine_reason(best_offer, candidates, need)

        return RouteDecision(
            selected_agent=best_offer.agent_id,
            selected_offer=best_offer,
            reason=reason,
            score=best_score,
            alternatives=tuple(offer for offer, _ in scored[1:]),
            rationale=self._explain_selection(best_offer, best_score, reason),
        )

    def _score_offer(self, offer: Offer, need: Need) -> float:
        """
        Compute weighted score for an offer.

        Score = quality * W_q + health * W_h + (1 - norm_latency) * W_l + local * W_loc

        Args:
            offer: Agent offer
            need: Task requirements

        Returns:
            Score in [0, 1]
        """
        # Quality score (α)
        quality_score = offer.current_quality

        # Health score (1-N)
        health_score = offer.health_score

        # Latency score (normalize to [0, 1], invert so lower is better)
        # Use max_latency_ms from need, or default to 1000ms
        max_latency = need.max_latency_ms if need.max_latency_ms < float("inf") else 1000.0
        norm_latency = min(1.0, offer.avg_latency_ms / max_latency)
        latency_score = 1.0 - norm_latency

        # Local preference
        local_score = 1.0 if offer.is_local else 0.0
        if not need.prefer_local:
            local_score *= 0.5  # Reduced weight if local not preferred

        # Weighted sum
        total_score = (
            quality_score * self.quality_weight
            + health_score * self.health_weight
            + latency_score * self.latency_weight
            + local_score * self.local_weight
        )

        return total_score

    def _determine_reason(
        self,
        selected: Offer,
        candidates: List[Offer],
        need: Need,
    ) -> RouteSelectionReason:
        """
        Determine why this agent was selected.

        Args:
            selected: The selected offer
            candidates: All candidates
            need: Task requirements

        Returns:
            RouteSelectionReason
        """
        # Highest quality?
        if all(selected.current_quality >= c.current_quality for c in candidates):
            return RouteSelectionReason.HIGHEST_QUALITY

        # Highest health?
        if all(selected.health_score >= c.health_score for c in candidates):
            return RouteSelectionReason.HIGHEST_HEALTH

        # Lowest latency?
        if all(selected.avg_latency_ms <= c.avg_latency_ms for c in candidates):
            return RouteSelectionReason.LOWEST_LATENCY

        # Local preference?
        if need.prefer_local and selected.is_local:
            remote_candidates = [c for c in candidates if not c.is_local]
            if remote_candidates:
                return RouteSelectionReason.LOCAL_PREFERENCE

        return RouteSelectionReason.BEST_SCORE

    def _explain_selection(
        self,
        offer: Offer,
        score: float,
        reason: RouteSelectionReason,
    ) -> str:
        """
        Generate human-readable explanation.

        Args:
            offer: Selected offer
            score: Selection score
            reason: Selection reason

        Returns:
            Explanation string
        """
        return (
            f"Selected '{offer.agent_id}' ({reason.name}): "
            f"score={score:.3f}, α={offer.current_quality:.3f}, "
            f"health={offer.health_score:.3f}, latency={offer.avg_latency_ms:.1f}ms"
        )
