"""
YRSN Routing Layer - DyTopo-inspired agent/backend routing.

This module fills the execution gap between quality control decisions
and actual agent/backend selection:

    UnifiedQualityController.decide(cert) → ControlDecision
                    ↓
    RoutingOrchestrator.route(need) → RoutingResult
                    ↓
    ExecutorRegistry.execute(request) → ExecutionResult
                    ↓
    EnforcementEngine.enforce_certificate(cert) → EnforcementResult

Components:
    Core Routing:
        - Capability: Enum of agent capabilities (RE_ENCODE, INFERENCE_LLM, etc.)
        - Need: What a task requires (capability, quality, latency)
        - Offer: What an agent provides (capabilities, quality, health)
        - CapabilityRegistry: Agent discovery and health tracking
        - SemanticRouter: Best-route selection based on quality/latency/health
        - CircuitBreaker: Health protection for failing agents
        - RoutingOrchestrator: Coordinates registry + router + circuit breakers
        - RoutingController: Integration adapter wrapping controller + routing + enforcement

    Execution:
        - ExecutorRegistry: Registry of backend executors
        - LLMExecutor: Execute via LLM backends (Claude, GPT-4, Gemini)
        - EncoderExecutor: Execute re-encoding via local encoders
        - SolverExecutor: Execute via HRMV/TRM/Symbolic solvers

    Validation:
        - ConsistencyChecker: Validate payload satisfies Need
        - check_consistency: Quick consistency check function

    Health Metrics:
        - HealthMetricsTracker: Per-agent health tracking
        - LatencyHistogram: Latency distribution tracking
        - TopologyChurnMetrics: Topology stability tracking

    Halting:
        - HaltingController: RSCT-based stop-early logic
        - should_halt: Quick halt check function

Usage:
    from yrsn.core.routing import (
        RoutingController,
        ExecutorRegistry,
        create_default_orchestrator,
        create_default_executors,
    )

    # Create controller with default backends
    orchestrator = create_default_orchestrator()
    executors = create_default_executors()
    controller = RoutingController(routing_orchestrator=orchestrator)

    # Process certificate and execute
    result = controller.process(certificate)
    if result.authorized and result.selected_agent:
        exec_result = await executors.execute(ExecutionRequest(
            agent_id=result.selected_agent,
            payload={"prompt": "..."},
            need=result.routing_result.decision.need,
        ))
"""

from .descriptors import Capability, Need, Offer
from .registry import CapabilityRegistry, AgentMetrics
from .router import SemanticRouter, RouteDecision, RouteSelectionReason
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig, CircuitState
from .orchestrator import RoutingOrchestrator, RoutingResult
from .controller import RoutingController, IntegratedResult
from .defaults import (
    DEFAULT_BACKENDS,
    EMERGENCY_BACKENDS,
    BACKEND_CLAUDE,
    BACKEND_GPT4,
    BACKEND_GEMINI,
    BACKEND_ROTOR,
    BACKEND_ADAPTER,
    BACKEND_HRMV,
    BACKEND_TRM,
    BACKEND_SYMBOLIC,
    EMERGENCY_LLM,
    EMERGENCY_ENCODER,
    EMERGENCY_SOLVER,
    create_default_orchestrator,
)

# Executors
from .executors import (
    ExecutionStatus,
    ExecutionRequest,
    ExecutionResult,
    BackendExecutor,
    LLMExecutor,
    EncoderExecutor,
    SolverExecutor,
    ExecutorRegistry,
    create_default_executors,
)

# Consistency checking
from .consistency import (
    ConsistencyLevel,
    ConsistencyResult,
    ConsistencyChecker,
    KeywordConsistencyChecker,
    StructuralConsistencyChecker,
    CompositeConsistencyChecker,
    check_consistency,
)

# Health metrics
from .health_metrics import (
    HealthTrend,
    LatencyHistogram,
    TimeWindowCounter,
    AgentHealthMetrics,
    TopologyChurnMetrics,
    HealthMetricsTracker,
)

# Halting controller
from .halting import (
    HaltingReason,
    HaltingDecision,
    HaltingConfig,
    HaltingController,
    should_halt,
)

# Filters
from .filters import (
    FilterResult,
    ContradictionFilter,
    IrrelevantContentFilter,
)

# Consensus
from .consensus import (
    ConsensusResult,
    ConsensusVerifier,
    QuorumChecker,
)

# Advanced Defenses
from .defenses import (
    GoalAnchor,
    GoalIntegrityResult,
    SemanticNormalizer,
    NormalizationResult,
    TokenBucketLimiter,
    RateLimitResult,
    MetricSmoother,
    SmoothedMetric,
    SybilDetector,
    SybilCheckResult,
    AmplificationDetector,
    AmplificationCheckResult,
    QualityDecayDetector,
    QualityDecayCheckResult,
    StarvationDetector,
    StarvationCheckResult,
    RedundantManager,
    ManagerState,
    ManagerHealthResult,
    DefenseStack,
    DefenseCheckResult,
)

__all__ = [
    # Descriptors
    "Capability",
    "Need",
    "Offer",
    # Registry
    "CapabilityRegistry",
    "AgentMetrics",
    # Router
    "SemanticRouter",
    "RouteDecision",
    "RouteSelectionReason",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitState",
    # Orchestrator
    "RoutingOrchestrator",
    "RoutingResult",
    # Controller
    "RoutingController",
    "IntegratedResult",
    # Defaults
    "DEFAULT_BACKENDS",
    "BACKEND_CLAUDE",
    "BACKEND_GPT4",
    "BACKEND_GEMINI",
    "BACKEND_ROTOR",
    "BACKEND_ADAPTER",
    "BACKEND_HRMV",
    "BACKEND_TRM",
    "BACKEND_SYMBOLIC",
    "create_default_orchestrator",
    # Executors
    "ExecutionStatus",
    "ExecutionRequest",
    "ExecutionResult",
    "BackendExecutor",
    "LLMExecutor",
    "EncoderExecutor",
    "SolverExecutor",
    "ExecutorRegistry",
    "create_default_executors",
    # Consistency
    "ConsistencyLevel",
    "ConsistencyResult",
    "ConsistencyChecker",
    "KeywordConsistencyChecker",
    "StructuralConsistencyChecker",
    "CompositeConsistencyChecker",
    "check_consistency",
    # Health Metrics
    "HealthTrend",
    "LatencyHistogram",
    "TimeWindowCounter",
    "AgentHealthMetrics",
    "TopologyChurnMetrics",
    "HealthMetricsTracker",
    # Halting
    "HaltingReason",
    "HaltingDecision",
    "HaltingConfig",
    "HaltingController",
    "should_halt",
    # Filters
    "FilterResult",
    "ContradictionFilter",
    "IrrelevantContentFilter",
    # Consensus
    "ConsensusResult",
    "ConsensusVerifier",
    "QuorumChecker",
    # Advanced Defenses
    "GoalAnchor",
    "GoalIntegrityResult",
    "SemanticNormalizer",
    "NormalizationResult",
    "TokenBucketLimiter",
    "RateLimitResult",
    "MetricSmoother",
    "SmoothedMetric",
    "SybilDetector",
    "SybilCheckResult",
    "AmplificationDetector",
    "AmplificationCheckResult",
    "QualityDecayDetector",
    "QualityDecayCheckResult",
    "StarvationDetector",
    "StarvationCheckResult",
    "RedundantManager",
    "ManagerState",
    "ManagerHealthResult",
    "DefenseStack",
    "DefenseCheckResult",
]
