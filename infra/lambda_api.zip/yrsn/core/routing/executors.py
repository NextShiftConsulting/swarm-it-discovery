"""
Backend Executors - Actual execution logic for routed requests.

Provides:
    - BackendExecutor: Protocol for all backend types
    - LLMExecutor: Execute via LLM backends (Claude, GPT-4, Gemini)
    - EncoderExecutor: Execute re-encoding via local encoders
    - SolverExecutor: Execute via HRMV/TRM/Symbolic solvers
    - ExecutorRegistry: Registry of available executors

Example:
    from yrsn.core.routing.executors import ExecutorRegistry, ExecutionRequest

    registry = ExecutorRegistry()

    # Execute via selected backend
    request = ExecutionRequest(
        agent_id="claude-sonnet",
        payload={"prompt": "Solve this puzzle..."},
        need=need,
    )
    result = await registry.execute(request)

    if result.success:
        print(f"Output: {result.output}")
    else:
        print(f"Error: {result.error}")
"""

from __future__ import annotations

import asyncio
import time
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, TYPE_CHECKING, Callable, Awaitable
from enum import Enum, auto

from .descriptors import Capability, Need

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


logger = logging.getLogger(__name__)


class ExecutionStatus(Enum):
    """Execution outcome status."""
    SUCCESS = auto()
    FAILURE = auto()
    TIMEOUT = auto()
    REJECTED = auto()  # Rejected before execution (e.g., circuit open)


@dataclass(frozen=True)
class ExecutionRequest:
    """
    Request to execute via a backend.

    Attributes:
        agent_id: Target backend ID
        payload: The actual data to process
        need: The routing Need that led to this request
        timeout_ms: Execution timeout in milliseconds
        metadata: Additional execution context
    """
    agent_id: str
    payload: Dict[str, Any]
    need: Need
    timeout_ms: float = 30000.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExecutionResult:
    """
    Result from backend execution.

    Attributes:
        status: Execution outcome
        output: The result data (if successful)
        error: Error message (if failed)
        latency_ms: Execution time in milliseconds
        certificate: Output certificate (if available)
        metadata: Additional result context
    """
    status: ExecutionStatus
    output: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    latency_ms: float = 0.0
    certificate: Optional["YRSNCertificate"] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        """Whether execution succeeded."""
        return self.status == ExecutionStatus.SUCCESS

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "status": self.status.name,
            "success": self.success,
            "error": self.error,
            "latency_ms": round(self.latency_ms, 2),
            "has_output": self.output is not None,
            "has_certificate": self.certificate is not None,
            "metadata": self.metadata,
        }


class BackendExecutor(ABC):
    """
    Protocol for backend execution.

    Subclasses implement specific backend types:
        - LLMExecutor: Claude, GPT-4, Gemini
        - EncoderExecutor: HybridRotor, KappaAdapter
        - SolverExecutor: HRMV, TRM, Symbolic
    """

    @property
    @abstractmethod
    def agent_id(self) -> str:
        """Backend identifier."""
        ...

    @property
    @abstractmethod
    def capabilities(self) -> List[Capability]:
        """Supported capabilities."""
        ...

    @abstractmethod
    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """
        Execute the request.

        Args:
            request: The execution request

        Returns:
            ExecutionResult with output or error
        """
        ...

    async def health_check(self) -> bool:
        """
        Check if backend is healthy.

        Returns:
            True if backend is responsive
        """
        return True  # Default: always healthy


class LLMExecutor(BackendExecutor):
    """
    Executor for LLM backends (Claude, GPT-4, Gemini).

    Supports:
        - INFERENCE_LLM: General LLM inference
        - RE_ENCODE: Use LLM for re-encoding context
        - FILTER_CONTEXT: Use LLM to filter/prune context

    Usage:
        executor = LLMExecutor(
            agent_id="claude-sonnet",
            api_key="sk-...",
            model="claude-3-5-sonnet-20241022",
            provider="anthropic",
        )
        result = await executor.execute(request)
    """

    def __init__(
        self,
        agent_id: str,
        model: str,
        provider: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        default_timeout_ms: float = 30000.0,
    ):
        self._agent_id = agent_id
        self.model = model
        self.provider = provider
        self.api_key = api_key
        self.base_url = base_url
        self.default_timeout_ms = default_timeout_ms
        self._client = None  # Lazy initialization

    @property
    def agent_id(self) -> str:
        return self._agent_id

    @property
    def capabilities(self) -> List[Capability]:
        return [Capability.INFERENCE_LLM, Capability.RE_ENCODE, Capability.FILTER_CONTEXT]

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Execute LLM inference."""
        start_time = time.time()

        try:
            # Extract prompt from payload
            prompt = request.payload.get("prompt", "")
            system = request.payload.get("system", "")
            messages = request.payload.get("messages", [])

            if not prompt and not messages:
                return ExecutionResult(
                    status=ExecutionStatus.FAILURE,
                    error="No prompt or messages in payload",
                    latency_ms=(time.time() - start_time) * 1000,
                )

            # Build messages if only prompt provided
            if prompt and not messages:
                messages = [{"role": "user", "content": prompt}]

            # Execute based on provider
            output = await self._call_provider(
                messages=messages,
                system=system,
                timeout_ms=request.timeout_ms or self.default_timeout_ms,
            )

            latency_ms = (time.time() - start_time) * 1000
            logger.info(f"LLM execution completed: {self.agent_id} in {latency_ms:.1f}ms")

            return ExecutionResult(
                status=ExecutionStatus.SUCCESS,
                output={"response": output, "model": self.model},
                latency_ms=latency_ms,
                metadata={"provider": self.provider},
            )

        except asyncio.TimeoutError:
            return ExecutionResult(
                status=ExecutionStatus.TIMEOUT,
                error=f"Timeout after {request.timeout_ms}ms",
                latency_ms=(time.time() - start_time) * 1000,
            )
        except Exception as e:
            logger.error(f"LLM execution failed: {e}")
            return ExecutionResult(
                status=ExecutionStatus.FAILURE,
                error=str(e),
                latency_ms=(time.time() - start_time) * 1000,
            )

    async def _call_provider(
        self,
        messages: List[Dict[str, str]],
        system: str,
        timeout_ms: float,
    ) -> str:
        """
        Call the LLM provider.

        Override this for actual API calls. Default is a stub.
        """
        # STUB: Replace with actual API calls
        # For now, return a placeholder response
        if self.provider == "anthropic":
            return await self._call_anthropic(messages, system, timeout_ms)
        elif self.provider == "openai":
            return await self._call_openai(messages, system, timeout_ms)
        elif self.provider == "google":
            return await self._call_google(messages, system, timeout_ms)
        else:
            return f"[STUB] Response from {self.model}"

    async def _call_anthropic(
        self,
        messages: List[Dict[str, str]],
        system: str,
        timeout_ms: float,
    ) -> str:
        """Call Anthropic API."""
        try:
            import anthropic

            if self._client is None:
                self._client = anthropic.AsyncAnthropic(api_key=self.api_key)

            response = await asyncio.wait_for(
                self._client.messages.create(
                    model=self.model,
                    max_tokens=4096,
                    system=system if system else None,
                    messages=messages,
                ),
                timeout=timeout_ms / 1000,
            )
            return response.content[0].text

        except ImportError:
            logger.warning("anthropic package not installed, using stub")
            return f"[STUB] Anthropic response from {self.model}"

    async def _call_openai(
        self,
        messages: List[Dict[str, str]],
        system: str,
        timeout_ms: float,
    ) -> str:
        """Call OpenAI API."""
        try:
            import openai

            if self._client is None:
                self._client = openai.AsyncOpenAI(api_key=self.api_key)

            full_messages = []
            if system:
                full_messages.append({"role": "system", "content": system})
            full_messages.extend(messages)

            response = await asyncio.wait_for(
                self._client.chat.completions.create(
                    model=self.model,
                    messages=full_messages,
                    max_tokens=4096,
                ),
                timeout=timeout_ms / 1000,
            )
            return response.choices[0].message.content

        except ImportError:
            logger.warning("openai package not installed, using stub")
            return f"[STUB] OpenAI response from {self.model}"

    async def _call_google(
        self,
        messages: List[Dict[str, str]],
        system: str,
        timeout_ms: float,
    ) -> str:
        """Call Google Gemini API."""
        try:
            import google.generativeai as genai

            if self._client is None:
                genai.configure(api_key=self.api_key)
                self._client = genai.GenerativeModel(self.model)

            # Convert messages to Gemini format
            prompt = "\n".join(
                f"{m['role']}: {m['content']}" for m in messages
            )
            if system:
                prompt = f"System: {system}\n{prompt}"

            response = await asyncio.wait_for(
                asyncio.to_thread(self._client.generate_content, prompt),
                timeout=timeout_ms / 1000,
            )
            return response.text

        except ImportError:
            logger.warning("google-generativeai package not installed, using stub")
            return f"[STUB] Google response from {self.model}"


class EncoderExecutor(BackendExecutor):
    """
    Executor for encoding backends (HybridRotor, KappaAdapter).

    Supports:
        - RE_ENCODE: Transform representations
        - RECALIBRATE: Recalibrate for domain shift
    """

    def __init__(
        self,
        agent_id: str,
        encoder_fn: Optional[Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]] = None,
    ):
        self._agent_id = agent_id
        self._encoder_fn = encoder_fn

    @property
    def agent_id(self) -> str:
        return self._agent_id

    @property
    def capabilities(self) -> List[Capability]:
        return [Capability.RE_ENCODE, Capability.RECALIBRATE]

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Execute encoding transformation."""
        start_time = time.time()

        try:
            if self._encoder_fn is None:
                # STUB: Return transformed payload
                output = {
                    "encoded": True,
                    "input_keys": list(request.payload.keys()),
                    "encoder": self.agent_id,
                }
            else:
                output = await self._encoder_fn(request.payload)

            latency_ms = (time.time() - start_time) * 1000
            logger.info(f"Encoding completed: {self.agent_id} in {latency_ms:.1f}ms")

            return ExecutionResult(
                status=ExecutionStatus.SUCCESS,
                output=output,
                latency_ms=latency_ms,
            )

        except Exception as e:
            logger.error(f"Encoding failed: {e}")
            return ExecutionResult(
                status=ExecutionStatus.FAILURE,
                error=str(e),
                latency_ms=(time.time() - start_time) * 1000,
            )


class SolverExecutor(BackendExecutor):
    """
    Executor for solver backends (HRMV, TRM, Symbolic).

    Supports:
        - INFERENCE_HRMV: HRMV solver
        - INFERENCE_TRM: TRM solver
        - GATE_ADAPTATION: Freeze/adapt learning
        - SUPPRESS: Block execution
    """

    def __init__(
        self,
        agent_id: str,
        solver_type: str,
        solver_fn: Optional[Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]] = None,
    ):
        self._agent_id = agent_id
        self.solver_type = solver_type
        self._solver_fn = solver_fn

    @property
    def agent_id(self) -> str:
        return self._agent_id

    @property
    def capabilities(self) -> List[Capability]:
        if self.solver_type == "HRMV":
            return [Capability.INFERENCE_HRMV, Capability.GATE_ADAPTATION]
        elif self.solver_type == "TRM":
            return [Capability.INFERENCE_TRM]
        elif self.solver_type == "Symbolic":
            return [Capability.SUPPRESS, Capability.GATE_ADAPTATION]
        return []

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Execute solver inference."""
        start_time = time.time()

        try:
            if self._solver_fn is None:
                # STUB: Return solver output
                output = {
                    "solved": True,
                    "solver": self.solver_type,
                    "agent": self.agent_id,
                }
            else:
                output = await self._solver_fn(request.payload)

            latency_ms = (time.time() - start_time) * 1000
            logger.info(f"Solver completed: {self.agent_id} ({self.solver_type}) in {latency_ms:.1f}ms")

            return ExecutionResult(
                status=ExecutionStatus.SUCCESS,
                output=output,
                latency_ms=latency_ms,
            )

        except Exception as e:
            logger.error(f"Solver failed: {e}")
            return ExecutionResult(
                status=ExecutionStatus.FAILURE,
                error=str(e),
                latency_ms=(time.time() - start_time) * 1000,
            )


class ExecutorRegistry:
    """
    Registry of backend executors.

    Manages executor lifecycle and routes execution requests.
    """

    def __init__(self):
        self._executors: Dict[str, BackendExecutor] = {}
        logger.info("ExecutorRegistry initialized")

    def register(self, executor: BackendExecutor) -> None:
        """Register an executor."""
        self._executors[executor.agent_id] = executor
        logger.info(f"Registered executor: {executor.agent_id}")

    def deregister(self, agent_id: str) -> None:
        """Remove an executor."""
        if agent_id in self._executors:
            del self._executors[agent_id]
            logger.info(f"Deregistered executor: {agent_id}")

    def get(self, agent_id: str) -> Optional[BackendExecutor]:
        """Get executor by ID."""
        return self._executors.get(agent_id)

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """
        Execute request via appropriate executor.

        Args:
            request: The execution request

        Returns:
            ExecutionResult
        """
        executor = self._executors.get(request.agent_id)

        if executor is None:
            return ExecutionResult(
                status=ExecutionStatus.REJECTED,
                error=f"No executor for agent: {request.agent_id}",
            )

        return await executor.execute(request)

    async def health_check_all(self) -> Dict[str, bool]:
        """Check health of all executors."""
        results = {}
        for agent_id, executor in self._executors.items():
            try:
                results[agent_id] = await executor.health_check()
            except Exception:
                results[agent_id] = False
        return results

    def __len__(self) -> int:
        return len(self._executors)


def create_default_executors() -> ExecutorRegistry:
    """
    Create registry with default executors.

    Note: These use stub implementations. For production, configure
    with actual API keys and endpoints.
    """
    registry = ExecutorRegistry()

    # LLM executors
    registry.register(LLMExecutor(
        agent_id="claude-sonnet",
        model="claude-3-5-sonnet-20241022",
        provider="anthropic",
    ))
    registry.register(LLMExecutor(
        agent_id="gpt-4o",
        model="gpt-4o",
        provider="openai",
    ))
    registry.register(LLMExecutor(
        agent_id="gemini-flash",
        model="gemini-2.0-flash",
        provider="google",
    ))

    # Encoder executors
    registry.register(EncoderExecutor(agent_id="hybrid-rotor"))
    registry.register(EncoderExecutor(agent_id="kappa-adapter"))

    # Solver executors
    registry.register(SolverExecutor(agent_id="hrmv-solver", solver_type="HRMV"))
    registry.register(SolverExecutor(agent_id="trm-solver", solver_type="TRM"))
    registry.register(SolverExecutor(agent_id="symbolic-solver", solver_type="Symbolic"))

    return registry
