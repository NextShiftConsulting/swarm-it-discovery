"""
Manager Halting Controller - RSCT-based stop-early logic.

DyTopo-inspired halting with RSCT signals:
    - Halt when RSCT says stable (goal achieved)
    - Halt when instability detected (prevent damage)
    - Continue when progress is being made

Provides:
    - HaltingController: Main halting decision logic
    - HaltingDecision: Immutable halt/continue decision
    - HaltingReason: Why we halted or continued

Example:
    controller = HaltingController()

    # Check if we should halt
    decision = controller.should_halt(
        certificate=cert,
        round_number=5,
        goal_achieved=False,
    )

    if decision.should_halt:
        print(f"Halting: {decision.reason.name}")
    else:
        print("Continue execution")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, TYPE_CHECKING
from enum import Enum, auto

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


logger = logging.getLogger(__name__)


class HaltingReason(Enum):
    """Why did we halt or continue?"""

    # Halt reasons
    GOAL_ACHIEVED = auto()         # Task successfully completed
    INSTABILITY_DETECTED = auto()  # σ too high, stop before damage
    COLLAPSE_IMMINENT = auto()     # α too low, representation failing
    POISONING_DETECTED = auto()    # N too high, adversarial input
    MAX_ROUNDS_EXCEEDED = auto()   # Safety limit reached
    CIRCUIT_OPEN = auto()          # All backends unavailable
    NO_PROGRESS = auto()           # Quality not improving

    # Continue reasons
    PROGRESS_DETECTED = auto()     # Quality improving
    STABLE_EXECUTION = auto()      # Normal operation
    RETRY_ALLOWED = auto()         # Within retry budget


@dataclass(frozen=True)
class HaltingDecision:
    """
    Immutable halting decision.

    Attributes:
        should_halt: Whether to halt execution
        reason: Why we halted or continued
        confidence: Confidence in decision [0, 1]
        details: Additional context
    """

    should_halt: bool
    reason: HaltingReason
    confidence: float = 1.0
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "should_halt": self.should_halt,
            "reason": self.reason.name,
            "confidence": round(self.confidence, 4),
            "details": self.details,
        }


@dataclass
class HaltingConfig:
    """
    Configuration for halting controller.

    Thresholds for RSCT signals and operational limits.
    """

    # RSCT thresholds
    instability_threshold: float = 0.7    # σ >= this triggers halt
    collapse_threshold: float = 0.2       # α <= this triggers halt
    poisoning_threshold: float = 0.5      # N >= this triggers halt

    # Quality thresholds
    min_quality: float = 0.3              # Minimum acceptable α
    quality_improvement_threshold: float = 0.05  # Required improvement per round
    goal_quality_threshold: float = 0.85  # α >= this = goal achieved

    # Operational limits
    max_rounds: int = 20                  # Maximum execution rounds
    max_retries: int = 3                  # Maximum retries per round
    stagnation_rounds: int = 3            # Rounds without improvement = halt

    # Health thresholds
    min_healthy_agents: int = 1           # Minimum agents available


class HaltingController:
    """
    Manager halting controller with RSCT integration.

    Decides whether to halt or continue based on:
        - Certificate quality signals (α, ω, τ)
        - RSCT stability signals (κ, σ)
        - Progress tracking
        - Operational constraints
    """

    def __init__(self, config: Optional[HaltingConfig] = None):
        self.config = config or HaltingConfig()
        self._round_history: List[Dict[str, float]] = []
        self._retry_count = 0
        logger.info("HaltingController initialized")

    def should_halt(
        self,
        certificate: "YRSNCertificate",
        round_number: int,
        goal_achieved: bool = False,
        healthy_agents: int = 1,
        verifier_passed: bool = True,
    ) -> HaltingDecision:
        """
        Decide whether to halt execution.

        Args:
            certificate: Current YRSNCertificate
            round_number: Current round number
            goal_achieved: Whether the goal has been achieved
            healthy_agents: Number of healthy agents available
            verifier_passed: Whether verifier approved last output

        Returns:
            HaltingDecision
        """
        # Priority 1: Goal achieved
        if goal_achieved and verifier_passed:
            logger.info("Halting: goal achieved")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.GOAL_ACHIEVED,
                confidence=1.0,
                details={"round": round_number},
            )

        # Priority 2: RSCT instability (σ check)
        sigma = getattr(certificate, "sigma", 0.0)
        if sigma >= self.config.instability_threshold:
            logger.warning(f"Halting: instability detected (σ={sigma:.3f})")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.INSTABILITY_DETECTED,
                confidence=0.9,
                details={"sigma": sigma, "threshold": self.config.instability_threshold},
            )

        # Priority 3: Collapse imminent (α check)
        alpha = certificate.alpha
        if alpha <= self.config.collapse_threshold:
            logger.warning(f"Halting: collapse imminent (α={alpha:.3f})")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.COLLAPSE_IMMINENT,
                confidence=0.95,
                details={"alpha": alpha, "threshold": self.config.collapse_threshold},
            )

        # Priority 4: Poisoning detected (N check)
        N = certificate.N
        if N >= self.config.poisoning_threshold:
            logger.warning(f"Halting: poisoning detected (N={N:.3f})")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.POISONING_DETECTED,
                confidence=0.85,
                details={"N": N, "threshold": self.config.poisoning_threshold},
            )

        # Priority 5: No healthy agents
        if healthy_agents < self.config.min_healthy_agents:
            logger.warning("Halting: no healthy agents available")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.CIRCUIT_OPEN,
                confidence=1.0,
                details={"healthy_agents": healthy_agents},
            )

        # Priority 6: Max rounds exceeded
        if round_number >= self.config.max_rounds:
            logger.warning(f"Halting: max rounds exceeded ({round_number})")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.MAX_ROUNDS_EXCEEDED,
                confidence=1.0,
                details={"round": round_number, "max": self.config.max_rounds},
            )

        # Priority 7: No progress (stagnation)
        # Note: Check stagnation BEFORE recording, so history doesn't include current
        if self._is_stagnating(certificate):
            logger.warning("Halting: no progress detected")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.NO_PROGRESS,
                confidence=0.7,
                details={"history_length": len(self._round_history)},
            )

        # Continue: Check if progress is being made BEFORE recording
        # so _round_history[-1] is the PREVIOUS round, not current
        is_progressing = self._is_progressing(certificate)

        # Record current round for history AFTER progress check
        self._record_round(certificate)

        if is_progressing:
            return HaltingDecision(
                should_halt=False,
                reason=HaltingReason.PROGRESS_DETECTED,
                confidence=0.8,
                details={"alpha": alpha, "round": round_number},
            )

        # Continue: Stable execution
        return HaltingDecision(
            should_halt=False,
            reason=HaltingReason.STABLE_EXECUTION,
            confidence=0.7,
            details={"alpha": alpha, "round": round_number},
        )

    def should_retry(
        self,
        last_success: bool,
        certificate: "YRSNCertificate",
    ) -> HaltingDecision:
        """
        Decide whether to retry a failed operation.

        Args:
            last_success: Whether last attempt succeeded
            certificate: Current certificate

        Returns:
            HaltingDecision
        """
        if last_success:
            self._retry_count = 0
            return HaltingDecision(
                should_halt=False,
                reason=HaltingReason.STABLE_EXECUTION,
                confidence=1.0,
            )

        self._retry_count += 1

        if self._retry_count > self.config.max_retries:
            logger.warning(f"Halting: max retries exceeded ({self._retry_count})")
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.NO_PROGRESS,
                confidence=0.9,
                details={"retries": self._retry_count, "max": self.config.max_retries},
            )

        # Check if certificate allows retry
        if certificate.alpha < self.config.min_quality:
            return HaltingDecision(
                should_halt=True,
                reason=HaltingReason.COLLAPSE_IMMINENT,
                confidence=0.8,
                details={"alpha": certificate.alpha},
            )

        return HaltingDecision(
            should_halt=False,
            reason=HaltingReason.RETRY_ALLOWED,
            confidence=0.6,
            details={"retries": self._retry_count},
        )

    def reset(self) -> None:
        """Reset controller state."""
        self._round_history.clear()
        self._retry_count = 0
        logger.info("HaltingController reset")

    def _record_round(self, certificate: "YRSNCertificate") -> None:
        """Record round data for history."""
        self._round_history.append({
            "alpha": certificate.alpha,
            "omega": certificate.omega,
            "N": certificate.N,
            "sigma": getattr(certificate, "sigma", 0.0),
            "kappa": getattr(certificate, "kappa", 1.0),
        })

        # Keep only recent history
        if len(self._round_history) > self.config.max_rounds:
            self._round_history = self._round_history[-self.config.max_rounds:]

    def _is_stagnating(self, certificate: "YRSNCertificate") -> bool:
        """Check if quality is stagnating."""
        if len(self._round_history) < self.config.stagnation_rounds:
            return False

        recent = self._round_history[-self.config.stagnation_rounds:]
        alphas = [r["alpha"] for r in recent]

        # Include current alpha in the comparison
        all_alphas = alphas + [certificate.alpha]

        # Check if all alphas (including current) are similar (no improvement)
        if max(all_alphas) - min(all_alphas) < self.config.quality_improvement_threshold:
            # And current alpha isn't high enough to be considered "done"
            if certificate.alpha < 0.8:
                return True

        return False

    def _is_progressing(self, certificate: "YRSNCertificate") -> bool:
        """Check if quality is improving.

        Note: Called BEFORE _record_round(), so history[-1] is the previous round.
        """
        if len(self._round_history) < 1:
            return True  # No history yet, assume progress

        prev_alpha = self._round_history[-1]["alpha"]
        curr_alpha = certificate.alpha

        # Check for improvement
        if curr_alpha > prev_alpha + self.config.quality_improvement_threshold:
            return True

        # Check kappa improvement if available
        prev_kappa = self._round_history[-1].get("kappa", 1.0)
        curr_kappa = getattr(certificate, "kappa", 1.0)

        if curr_kappa > prev_kappa + 0.05:
            return True

        return False

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "config": {
                "instability_threshold": self.config.instability_threshold,
                "collapse_threshold": self.config.collapse_threshold,
                "poisoning_threshold": self.config.poisoning_threshold,
                "goal_quality_threshold": self.config.goal_quality_threshold,
                "max_rounds": self.config.max_rounds,
                "max_retries": self.config.max_retries,
            },
            "history_length": len(self._round_history),
            "retry_count": self._retry_count,
        }


# Convenience function
def should_halt(
    certificate: "YRSNCertificate",
    round_number: int,
    goal_achieved: bool = False,
    config: Optional[HaltingConfig] = None,
) -> HaltingDecision:
    """
    Quick check if we should halt.

    Creates a temporary controller for single-use checks.
    For repeated checks, create a HaltingController instance.
    """
    controller = HaltingController(config)
    return controller.should_halt(
        certificate=certificate,
        round_number=round_number,
        goal_achieved=goal_achieved,
    )
