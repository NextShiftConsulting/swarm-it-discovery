"""
Multi-Agent Consensus Verification.

Provides consensus mechanisms to protect against identity attacks:
    - Require N-of-M agreement before accepting
    - Detect dissenting agents
    - Combine responses safely

Example:
    verifier = ConsensusVerifier(min_agreement=0.66, min_voters=3)

    responses = {
        "agent-1": "The answer is 42",
        "agent-2": "The answer is 42",
        "agent-3": "The answer is 17",  # Dissenter
    }

    result = verifier.verify(responses)
    if result.agreed:
        use_response = result.combined_response
    else:
        handle_disagreement(result.dissenting_agents)
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple, Optional, FrozenSet


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ConsensusResult:
    """
    Result of consensus verification.

    Attributes:
        agreed: Whether consensus was reached
        agreement_ratio: Ratio of agreeing agents (0-1)
        majority_response: The response that received the most votes
        dissenting_agents: Tuple of agent IDs that disagreed
        combined_response: The agreed-upon response (or majority if no consensus)
        vote_counts: Mapping of response hash to vote count
    """

    agreed: bool
    agreement_ratio: float
    majority_response: str
    dissenting_agents: Tuple[str, ...]
    combined_response: str
    vote_counts: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "agreed": self.agreed,
            "agreement_ratio": round(self.agreement_ratio, 4),
            "dissenting_count": len(self.dissenting_agents),
            "dissenting_agents": list(self.dissenting_agents),
            "vote_counts": self.vote_counts,
        }


class ConsensusVerifier:
    """
    Multi-agent consensus verifier.

    Requires a minimum agreement ratio among voting agents before
    accepting a response. Helps defend against:
        - Overconfident adversarial agents
        - Identity spoofing attacks
        - Single point of failure

    Attributes:
        min_agreement: Minimum ratio of agreeing agents (default 0.66)
        min_voters: Minimum number of voters required (default 3)
    """

    def __init__(
        self,
        min_agreement: float = 0.66,
        min_voters: int = 3,
        normalize_whitespace: bool = True,
    ):
        """
        Initialize consensus verifier.

        Args:
            min_agreement: Minimum ratio of agreeing agents (0-1)
            min_voters: Minimum number of voters required
            normalize_whitespace: Whether to normalize whitespace when comparing
        """
        if not 0 < min_agreement <= 1:
            raise ValueError(f"min_agreement must be in (0, 1], got {min_agreement}")
        if min_voters < 1:
            raise ValueError(f"min_voters must be >= 1, got {min_voters}")

        self.min_agreement = min_agreement
        self.min_voters = min_voters
        self.normalize_whitespace = normalize_whitespace
        logger.debug(
            f"ConsensusVerifier initialized: min_agreement={min_agreement}, "
            f"min_voters={min_voters}"
        )

    def verify(self, responses: Dict[str, str]) -> ConsensusResult:
        """
        Verify consensus among agent responses.

        Args:
            responses: Mapping of agent_id to response string

        Returns:
            ConsensusResult with agreement status and details
        """
        if len(responses) < self.min_voters:
            logger.warning(
                f"Insufficient voters: {len(responses)} < {self.min_voters}"
            )
            # Return degraded result - can't verify consensus
            majority = next(iter(responses.values()), "")
            return ConsensusResult(
                agreed=False,
                agreement_ratio=0.0,
                majority_response=majority,
                dissenting_agents=(),
                combined_response=majority,
                vote_counts={},
            )

        # Normalize and count responses
        normalized = {
            agent_id: self._normalize(response)
            for agent_id, response in responses.items()
        }

        # Group agents by their normalized response
        response_to_agents: Dict[str, List[str]] = {}
        for agent_id, norm_response in normalized.items():
            if norm_response not in response_to_agents:
                response_to_agents[norm_response] = []
            response_to_agents[norm_response].append(agent_id)

        # Find majority response
        total_voters = len(responses)
        vote_counts = {
            resp: len(agents) for resp, agents in response_to_agents.items()
        }
        majority_response = max(response_to_agents.keys(), key=lambda r: len(response_to_agents[r]))
        majority_count = len(response_to_agents[majority_response])

        # Calculate agreement ratio
        agreement_ratio = majority_count / total_voters

        # Find dissenting agents
        dissenting_agents = []
        for resp, agents in response_to_agents.items():
            if resp != majority_response:
                dissenting_agents.extend(agents)

        agreed = agreement_ratio >= self.min_agreement

        if agreed:
            logger.info(
                f"Consensus reached: {agreement_ratio:.1%} agreement "
                f"({majority_count}/{total_voters})"
            )
        else:
            logger.warning(
                f"No consensus: {agreement_ratio:.1%} < {self.min_agreement:.1%} required"
            )

        # Get original (non-normalized) majority response
        majority_agents = response_to_agents[majority_response]
        original_majority = responses[majority_agents[0]]

        return ConsensusResult(
            agreed=agreed,
            agreement_ratio=agreement_ratio,
            majority_response=original_majority,
            dissenting_agents=tuple(dissenting_agents),
            combined_response=original_majority if agreed else "",
            vote_counts=vote_counts,
        )

    def verify_with_weights(
        self,
        responses: Dict[str, str],
        weights: Dict[str, float],
    ) -> ConsensusResult:
        """
        Verify consensus with weighted voting.

        Args:
            responses: Mapping of agent_id to response string
            weights: Mapping of agent_id to vote weight

        Returns:
            ConsensusResult with weighted agreement status
        """
        if len(responses) < self.min_voters:
            majority = next(iter(responses.values()), "")
            return ConsensusResult(
                agreed=False,
                agreement_ratio=0.0,
                majority_response=majority,
                dissenting_agents=(),
                combined_response=majority,
                vote_counts={},
            )

        # Normalize responses
        normalized = {
            agent_id: self._normalize(response)
            for agent_id, response in responses.items()
        }

        # Group agents by normalized response
        response_to_agents: Dict[str, List[str]] = {}
        for agent_id, norm_response in normalized.items():
            if norm_response not in response_to_agents:
                response_to_agents[norm_response] = []
            response_to_agents[norm_response].append(agent_id)

        # Calculate weighted votes
        total_weight = sum(weights.get(agent_id, 1.0) for agent_id in responses)
        vote_weights: Dict[str, float] = {}
        for resp, agents in response_to_agents.items():
            vote_weights[resp] = sum(weights.get(a, 1.0) for a in agents)

        majority_response = max(vote_weights.keys(), key=lambda r: vote_weights[r])
        majority_weight = vote_weights[majority_response]

        agreement_ratio = majority_weight / total_weight

        # Find dissenting agents
        dissenting_agents = []
        for resp, agents in response_to_agents.items():
            if resp != majority_response:
                dissenting_agents.extend(agents)

        agreed = agreement_ratio >= self.min_agreement

        majority_agents = response_to_agents[majority_response]
        original_majority = responses[majority_agents[0]]

        return ConsensusResult(
            agreed=agreed,
            agreement_ratio=agreement_ratio,
            majority_response=original_majority,
            dissenting_agents=tuple(dissenting_agents),
            combined_response=original_majority if agreed else "",
            vote_counts={r: int(w) for r, w in vote_weights.items()},
        )

    def _normalize(self, response: str) -> str:
        """Normalize response for comparison."""
        if self.normalize_whitespace:
            # Collapse whitespace
            import re
            normalized = re.sub(r"\s+", " ", response.strip())
            return normalized.lower()
        return response.strip().lower()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize configuration for telemetry."""
        return {
            "min_agreement": self.min_agreement,
            "min_voters": self.min_voters,
            "normalize_whitespace": self.normalize_whitespace,
        }


class QuorumChecker:
    """
    Simple quorum checker for agent availability.

    Ensures minimum number of healthy agents before proceeding.
    """

    def __init__(self, min_quorum: int = 2):
        """
        Initialize quorum checker.

        Args:
            min_quorum: Minimum number of agents required
        """
        if min_quorum < 1:
            raise ValueError(f"min_quorum must be >= 1, got {min_quorum}")
        self.min_quorum = min_quorum

    def check(self, available_agents: List[str]) -> bool:
        """
        Check if quorum is met.

        Args:
            available_agents: List of available agent IDs

        Returns:
            True if quorum is met
        """
        return len(available_agents) >= self.min_quorum

    def check_with_health(
        self,
        agents: Dict[str, float],
        min_health: float = 0.5,
    ) -> Tuple[bool, List[str]]:
        """
        Check quorum with health threshold.

        Args:
            agents: Mapping of agent_id to health score (0-1)
            min_health: Minimum health to be considered available

        Returns:
            Tuple of (quorum_met, list of healthy agent IDs)
        """
        healthy = [
            agent_id
            for agent_id, health in agents.items()
            if health >= min_health
        ]
        return len(healthy) >= self.min_quorum, healthy
