"""
Routing Orchestrator - Complete Routing Pipeline.

Coordinates:
    1. CapabilityRegistry - agent discovery
    2. SemanticRouter - best route selection
    3. CircuitBreaker - health protection per agent

This is the main entry point for routing operations.

Example:
    orchestrator = RoutingOrchestrator()

    # Register agents
    orchestrator.register_agent(Offer(
        agent_id="encoder-1",
        capabilities=frozenset({Capability.RE_ENCODE}),
        current_quality=0.9,
        avg_latency_ms=50,
    ))

    # Route request
    need = Need(required_capability=Capability.RE_ENCODE, min_quality=0.8)
    result = orchestrator.route(need)

    if result.success:
        print(f"Route to: {result.selected_agent}")

    # Update health
    orchestrator.update_agent_health("encoder-1", certificate)

    # Record outcome
    orchestrator.record_outcome("encoder-1", success=True, latency_ms=45)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, TYPE_CHECKING
import logging

from .descriptors import Need, Offer, Capability
from .registry import CapabilityRegistry, AgentMetrics
from .router import SemanticRouter, RouteDecision, RouteSelectionReason
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig, CircuitState
from .defenses import (
    SybilDetector,
    StarvationDetector,
    SybilCheckResult,
    StarvationCheckResult,
    AmplificationDetector,
    AmplificationCheckResult,
    QualityDecayDetector,
    QualityDecayCheckResult,
)

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RoutingResult:
    """
    Complete routing result (P1 compliant - data only).

    Combines RouteDecision with circuit breaker state and telemetry.

    Attributes:
        decision: The route decision from SemanticRouter
        circuit_state: Circuit breaker state of selected agent
        registry_candidates: Total candidates in registry for capability
        satisfied_candidates: Candidates that passed filtering
        rationale: Human-readable explanation
    """

    decision: RouteDecision
    circuit_state: str
    registry_candidates: int
    satisfied_candidates: int
    rationale: str

    @property
    def selected_agent(self) -> Optional[str]:
        """Shortcut to selected agent ID."""
        return self.decision.selected_agent

    @property
    def selected_offer(self) -> Optional[Offer]:
        """Shortcut to selected offer."""
        return self.decision.selected_offer

    @property
    def success(self) -> bool:
        """Whether routing succeeded."""
        return self.selected_agent is not None

    @property
    def reason(self) -> RouteSelectionReason:
        """Shortcut to selection reason."""
        return self.decision.reason

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "success": self.success,
            "selected_agent": self.selected_agent,
            "decision": self.decision.to_dict(),
            "circuit_state": self.circuit_state,
            "registry_candidates": self.registry_candidates,
            "satisfied_candidates": self.satisfied_candidates,
            "rationale": self.rationale,
        }


class RoutingOrchestrator:
    """
    Complete routing orchestration.

    Coordinates:
        - CapabilityRegistry: Agent discovery and health tracking
        - SemanticRouter: Best route selection
        - CircuitBreaker: Per-agent health protection

    Thread-safety note: This implementation is NOT thread-safe.
    For concurrent use, wrap with appropriate locking.
    """

    def __init__(
        self,
        router: Optional[SemanticRouter] = None,
        circuit_config: Optional[CircuitBreakerConfig] = None,
        sybil_threshold: float = 0.85,
        starvation_threshold: float = 0.4,
    ):
        """
        Initialize orchestrator.

        Args:
            router: Custom SemanticRouter (optional, uses defaults)
            circuit_config: Circuit breaker config (optional, uses defaults)
            sybil_threshold: Similarity threshold for Sybil detection
            starvation_threshold: Failure rate threshold for starvation detection
        """
        self.registry = CapabilityRegistry()
        self.router = router or SemanticRouter()
        self.circuit_config = circuit_config or CircuitBreakerConfig()
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}
        self._protected_agents: set = set()  # Agents that can't be deregistered

        # Defense integrations
        self.sybil_detector = SybilDetector(similarity_threshold=sybil_threshold)
        self.starvation_detector = StarvationDetector(starvation_threshold=starvation_threshold)
        self.amplification_detector = AmplificationDetector()
        self.quality_decay_detector = QualityDecayDetector()

        logger.info("RoutingOrchestrator initialized with full defense suite")

    def register_agent(self, offer: Offer, protected: bool = False) -> None:
        """
        Register an agent.

        Creates circuit breaker if not exists.

        Args:
            offer: Agent offer (capabilities, quality, etc.)
            protected: If True, agent cannot be deregistered (for emergency backends)
        """
        self.registry.register(offer)

        # Initialize circuit breaker
        if offer.agent_id not in self._circuit_breakers:
            self._circuit_breakers[offer.agent_id] = CircuitBreaker(self.circuit_config)

        # Mark as protected if specified
        if protected:
            self._protected_agents.add(offer.agent_id)
            logger.info(f"Registered protected agent: {offer.agent_id}")

    def deregister_agent(self, agent_id: str, force: bool = False) -> bool:
        """
        Remove agent from registry.

        Protected agents cannot be deregistered unless force=True.

        Args:
            agent_id: Agent identifier
            force: If True, deregister even if protected

        Returns:
            True if agent was deregistered, False if protected
        """
        if agent_id in self._protected_agents and not force:
            logger.warning(f"Cannot deregister protected agent: {agent_id}")
            return False

        self.registry.deregister(agent_id)
        if agent_id in self._circuit_breakers:
            del self._circuit_breakers[agent_id]
        if agent_id in self._protected_agents:
            self._protected_agents.discard(agent_id)

        return True

    def update_agent_health(self, agent_id: str, certificate: "YRSNCertificate") -> None:
        """
        Update agent health from certificate.

        Args:
            agent_id: Agent identifier
            certificate: Latest certificate from agent
        """
        self.registry.update_health(agent_id, certificate)

    def route(self, need: Need) -> RoutingResult:
        """
        Route request to best agent.

        Pipeline:
            1. Find candidates from registry by capability
            2. Filter by circuit breaker state
            3. Filter by Sybil detection
            4. Select best route via SemanticRouter
            5. Record for starvation detection
            6. Return RoutingResult

        Args:
            need: Task requirements

        Returns:
            RoutingResult with selected agent
        """
        # Count all agents with the required capability (before any filtering)
        all_with_capability = self.registry.get_agents_by_capability(need.required_capability)
        total_with_capability = len(all_with_capability)

        # Find candidates from registry (filters by quality, latency, circuit_state in Offer)
        all_candidates = self.registry.find_candidates(need)

        # Filter by circuit breaker (authoritative check - breaker may have updated)
        healthy_candidates = [
            offer
            for offer in all_candidates
            if self._allow_agent(offer.agent_id)
        ]

        # Filter by Sybil detection - exclude agents detected as Sybils
        non_sybil_candidates = [
            offer
            for offer in healthy_candidates
            if not self._is_sybil(offer.agent_id)
        ]

        sybil_blocked = len(healthy_candidates) - len(non_sybil_candidates)
        if sybil_blocked > 0:
            logger.warning(f"Blocked {sybil_blocked} Sybil agents from routing")

        # Select best route
        decision = self.router.select_route(need, non_sybil_candidates)

        # Get circuit state
        circuit_state = "UNKNOWN"
        if decision.selected_agent:
            breaker = self._circuit_breakers.get(decision.selected_agent)
            circuit_state = breaker.state.value if breaker else "UNKNOWN"

        # Build rationale
        rationale = decision.rationale
        if not non_sybil_candidates:
            if healthy_candidates:
                rationale = f"No candidates ({sybil_blocked} blocked as Sybil)"
            elif all_candidates:
                blocked_count = len(all_candidates) - len(healthy_candidates)
                rationale = f"No healthy candidates ({blocked_count} blocked by circuit breaker)"
            else:
                rationale = f"No candidates found for {need.required_capability.name}"

        result = RoutingResult(
            decision=decision,
            circuit_state=circuit_state,
            registry_candidates=total_with_capability,
            satisfied_candidates=len(non_sybil_candidates),
            rationale=rationale,
        )

        # Record for starvation detection
        self.starvation_detector.record_route(
            capability=need.required_capability.name,
            success=result.success,
            candidate_count=len(non_sybil_candidates),
        )

        # Check for starvation condition
        starvation = self.starvation_detector.check(need.required_capability.name)
        if starvation.is_starving:
            logger.warning(
                f"Starvation detected for {need.required_capability.name}: "
                f"score={starvation.starvation_score:.2f}, "
                f"consecutive={starvation.consecutive_failures}"
            )

        logger.info(
            f"Routed {need.required_capability.name} -> "
            f"{result.selected_agent or 'NONE'} ({result.rationale})"
        )

        return result

    def _is_sybil(self, agent_id: str) -> bool:
        """
        Check if agent is flagged as Sybil.

        Args:
            agent_id: Agent identifier

        Returns:
            True if agent is a suspected Sybil
        """
        result = self.sybil_detector.check(agent_id)
        return result.is_sybil

    def record_response(self, agent_id: str, response: str) -> SybilCheckResult:
        """
        Record agent response for Sybil detection.

        Should be called after receiving response from an agent.

        Args:
            agent_id: Agent identifier
            response: Response text from agent

        Returns:
            SybilCheckResult with detection status
        """
        self.sybil_detector.record(agent_id, response)
        return self.sybil_detector.check(agent_id)

    def check_starvation(self, capability: Optional[str] = None) -> StarvationCheckResult:
        """
        Check for starvation condition.

        Args:
            capability: Specific capability to check, or None for overall

        Returns:
            StarvationCheckResult with starvation status
        """
        return self.starvation_detector.check(capability)

    def record_metric(self, metric_name: str, value: float) -> None:
        """
        Record a metric for amplification detection.

        Args:
            metric_name: Name of the metric (e.g., "quality", "latency")
            value: Metric value
        """
        self.amplification_detector.record(metric_name, value)

    def check_amplification(self, metric_name: str) -> AmplificationCheckResult:
        """
        Check for amplification on a metric.

        Args:
            metric_name: Name of the metric to check

        Returns:
            AmplificationCheckResult with detection status
        """
        return self.amplification_detector.check(metric_name)

    def record_agent_quality(self, agent_id: str, quality: float) -> None:
        """
        Record agent quality for decay detection.

        Args:
            agent_id: Agent identifier
            quality: Current quality value
        """
        self.quality_decay_detector.record(agent_id, quality)

    def check_quality_decay(self, agent_id: str) -> QualityDecayCheckResult:
        """
        Check for quality decay in an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            QualityDecayCheckResult with detection status
        """
        return self.quality_decay_detector.check(agent_id)

    def get_decaying_agents(self) -> List[str]:
        """Get list of agents experiencing quality decay."""
        return self.quality_decay_detector.get_decaying_agents()

    def record_outcome(
        self,
        agent_id: str,
        success: bool,
        latency_ms: float,
    ) -> None:
        """
        Record request outcome.

        Updates:
            - Registry metrics (success rate, latency)
            - Circuit breaker state

        Args:
            agent_id: Agent that handled request
            success: Whether request succeeded
            latency_ms: Request latency in milliseconds
        """
        # Update registry metrics
        self.registry.record_request(agent_id, latency_ms, success)

        # Update circuit breaker
        breaker = self._circuit_breakers.get(agent_id)
        if breaker:
            if success:
                breaker.record_success()
            else:
                breaker.record_failure()

            # Sync circuit state back to registry
            self.registry.update_circuit_state(agent_id, breaker.state.value)

    def get_agent_metrics(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get metrics for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            Metrics dictionary or None if agent not found
        """
        metrics = self.registry.get_metrics(agent_id)
        breaker = self._circuit_breakers.get(agent_id)

        if not metrics:
            return None

        return {
            "agent_id": agent_id,
            "total_requests": metrics.total_requests,
            "success_rate": metrics.success_rate,
            "avg_latency_ms": metrics.avg_latency_ms,
            "circuit_breaker": breaker.to_dict() if breaker else None,
        }

    def get_circuit_breaker(self, agent_id: str) -> Optional[CircuitBreaker]:
        """
        Get circuit breaker for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            CircuitBreaker or None if agent not found
        """
        return self._circuit_breakers.get(agent_id)

    def reset_circuit_breaker(self, agent_id: str) -> None:
        """
        Reset circuit breaker for an agent.

        Args:
            agent_id: Agent identifier
        """
        breaker = self._circuit_breakers.get(agent_id)
        if breaker:
            breaker.reset()
            self.registry.update_circuit_state(agent_id, breaker.state.value)

    def _allow_agent(self, agent_id: str) -> bool:
        """
        Check if agent is healthy (circuit breaker).

        Args:
            agent_id: Agent identifier

        Returns:
            True if agent is allowed, False if blocked
        """
        breaker = self._circuit_breakers.get(agent_id)
        if not breaker:
            return True
        return breaker.allow_request()

    def route_with_fallback(
        self,
        need: Need,
        chain_depth: int = 3,
    ) -> RoutingResult:
        """
        Route request with fallback chain.

        Tries multiple candidates in order of health score until one succeeds
        or all options are exhausted. Helps defend against topology attacks
        that reduce agent availability.

        Args:
            need: Task requirements
            chain_depth: Maximum number of fallbacks to try

        Returns:
            RoutingResult with best available agent
        """
        # Get all candidates from registry
        all_with_capability = self.registry.get_agents_by_capability(need.required_capability)
        total_with_capability = len(all_with_capability)

        all_candidates = self.registry.find_candidates(need)

        # Filter by circuit breaker
        healthy_candidates = [
            offer
            for offer in all_candidates
            if self._allow_agent(offer.agent_id)
        ]

        if not healthy_candidates:
            # No healthy candidates - try to find ANY agent with the capability
            # even if circuit breaker is open (degraded mode)
            logger.warning(
                f"No healthy candidates for {need.required_capability.name}, "
                f"attempting degraded routing"
            )
            degraded_candidates = all_with_capability
            if degraded_candidates:
                # Sort by quality (highest first) for degraded mode
                degraded_candidates = sorted(
                    degraded_candidates,
                    key=lambda o: o.current_quality,
                    reverse=True,
                )
                # Take the best degraded candidate
                selected = degraded_candidates[0]
                decision = RouteDecision(
                    selected_agent=selected.agent_id,
                    selected_offer=selected,
                    reason=RouteSelectionReason.ONLY_CANDIDATE,
                    score=selected.current_quality * 0.5,  # Penalized score
                    alternatives=tuple(degraded_candidates[1:chain_depth]),
                    rationale=f"Degraded routing: all circuit breakers open",
                )
                return RoutingResult(
                    decision=decision,
                    circuit_state="OPEN",
                    registry_candidates=total_with_capability,
                    satisfied_candidates=0,
                    rationale="Degraded routing - no healthy candidates",
                )

            # Truly no candidates
            decision = RouteDecision(
                selected_agent=None,
                selected_offer=None,
                reason=RouteSelectionReason.NO_CANDIDATES,
                score=0.0,
                alternatives=(),
                rationale=f"No candidates for {need.required_capability.name}",
            )
            return RoutingResult(
                decision=decision,
                circuit_state="UNKNOWN",
                registry_candidates=0,
                satisfied_candidates=0,
                rationale="No candidates available",
            )

        # Sort by health score (highest first) for fallback ordering
        ranked_candidates = sorted(
            healthy_candidates,
            key=lambda o: o.health_score,
            reverse=True,
        )

        # Take top candidates up to chain_depth
        fallback_chain = ranked_candidates[:chain_depth]

        # Select primary (best) candidate
        primary = fallback_chain[0]
        alternatives = tuple(fallback_chain[1:])

        # Get circuit state
        breaker = self._circuit_breakers.get(primary.agent_id)
        circuit_state = breaker.state.value if breaker else "UNKNOWN"

        decision = RouteDecision(
            selected_agent=primary.agent_id,
            selected_offer=primary,
            reason=RouteSelectionReason.HIGHEST_QUALITY if primary.health_score >= 0.8 else RouteSelectionReason.ONLY_CANDIDATE,
            score=primary.health_score * primary.current_quality,
            alternatives=alternatives,
            rationale=f"Selected with {len(alternatives)} fallbacks available",
        )

        result = RoutingResult(
            decision=decision,
            circuit_state=circuit_state,
            registry_candidates=total_with_capability,
            satisfied_candidates=len(healthy_candidates),
            rationale=f"Primary: {primary.agent_id}, fallbacks: {[o.agent_id for o in alternatives]}",
        )

        logger.info(
            f"Fallback route {need.required_capability.name} -> {primary.agent_id} "
            f"(+{len(alternatives)} fallbacks)"
        )

        return result

    def get_all_agents(self) -> List[Offer]:
        """
        Get all registered agents.

        Returns:
            List of all registered Offers
        """
        return self.registry.get_all_agents()

    def __len__(self) -> int:
        """Return number of registered agents."""
        return len(self.registry)

    def to_dict(self) -> Dict[str, Any]:
        """
        Export orchestrator state.

        Returns:
            Dictionary with orchestrator state
        """
        return {
            "registry": self.registry.to_dict(),
            "circuit_breakers": {
                agent_id: breaker.to_dict()
                for agent_id, breaker in self._circuit_breakers.items()
            },
        }
