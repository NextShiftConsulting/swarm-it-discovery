"""
Communication Health Metrics.

DyTopo-inspired link quality tracking:
    - Latency histograms per route
    - Success/failure rates over time
    - Topology churn metrics
    - Agent health scoring

Example:
    tracker = HealthMetricsTracker()

    # Record request outcomes
    tracker.record_request("claude-sonnet", latency_ms=150, success=True)
    tracker.record_request("claude-sonnet", latency_ms=200, success=True)
    tracker.record_request("claude-sonnet", latency_ms=5000, success=False)

    # Get health metrics
    health = tracker.get_health("claude-sonnet")
    print(f"Success rate: {health.success_rate}")
    print(f"P50 latency: {health.latency_p50}")
    print(f"Health score: {health.health_score}")
"""

from __future__ import annotations

import time
import math
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Deque
from collections import deque
from enum import Enum, auto

from .descriptors import Capability


logger = logging.getLogger(__name__)


class HealthTrend(Enum):
    """Health trend direction."""
    IMPROVING = auto()
    STABLE = auto()
    DEGRADING = auto()
    UNKNOWN = auto()


@dataclass
class LatencyHistogram:
    """
    Histogram for latency tracking.

    Tracks:
        - Min/max/mean latency
        - Percentiles (p50, p90, p99)
        - Standard deviation
    """

    values: Deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    _sorted_cache: Optional[List[float]] = field(default=None, repr=False)
    _cache_valid: bool = field(default=False, repr=False)

    def record(self, latency_ms: float) -> None:
        """Record a latency value."""
        self.values.append(latency_ms)
        self._cache_valid = False

    def _ensure_sorted(self) -> List[float]:
        """Get sorted values (cached)."""
        if not self._cache_valid or self._sorted_cache is None:
            self._sorted_cache = sorted(self.values)
            self._cache_valid = True
        return self._sorted_cache

    @property
    def count(self) -> int:
        """Number of samples."""
        return len(self.values)

    @property
    def min(self) -> float:
        """Minimum latency."""
        if not self.values:
            return 0.0
        return min(self.values)

    @property
    def max(self) -> float:
        """Maximum latency."""
        if not self.values:
            return 0.0
        return max(self.values)

    @property
    def mean(self) -> float:
        """Mean latency."""
        if not self.values:
            return 0.0
        return sum(self.values) / len(self.values)

    @property
    def std(self) -> float:
        """Standard deviation."""
        if len(self.values) < 2:
            return 0.0
        mean = self.mean
        variance = sum((x - mean) ** 2 for x in self.values) / len(self.values)
        return math.sqrt(variance)

    def percentile(self, p: float) -> float:
        """Get percentile value."""
        if not self.values:
            return 0.0
        sorted_values = self._ensure_sorted()
        idx = int(len(sorted_values) * p / 100)
        idx = max(0, min(idx, len(sorted_values) - 1))
        return sorted_values[idx]

    @property
    def p50(self) -> float:
        """50th percentile (median)."""
        return self.percentile(50)

    @property
    def p90(self) -> float:
        """90th percentile."""
        return self.percentile(90)

    @property
    def p99(self) -> float:
        """99th percentile."""
        return self.percentile(99)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "count": self.count,
            "min": round(self.min, 2),
            "max": round(self.max, 2),
            "mean": round(self.mean, 2),
            "std": round(self.std, 2),
            "p50": round(self.p50, 2),
            "p90": round(self.p90, 2),
            "p99": round(self.p99, 2),
        }


@dataclass
class TimeWindowCounter:
    """
    Counter with sliding time window.

    Tracks counts over a configurable time window for rate calculations.
    """

    window_seconds: float = 300.0  # 5 minutes default
    _timestamps: Deque[float] = field(default_factory=deque)

    def record(self) -> None:
        """Record an event at current time."""
        now = time.time()
        self._timestamps.append(now)
        self._cleanup()

    def _cleanup(self) -> None:
        """Remove old timestamps outside window."""
        cutoff = time.time() - self.window_seconds
        while self._timestamps and self._timestamps[0] < cutoff:
            self._timestamps.popleft()

    @property
    def count(self) -> int:
        """Count in current window."""
        self._cleanup()
        return len(self._timestamps)

    @property
    def rate_per_second(self) -> float:
        """Rate per second in current window."""
        self._cleanup()
        if not self._timestamps:
            return 0.0
        return len(self._timestamps) / self.window_seconds


@dataclass
class AgentHealthMetrics:
    """
    Comprehensive health metrics for an agent.

    Tracks:
        - Success/failure counts and rates
        - Latency distribution
        - Consistency scores
        - Health trend
    """

    agent_id: str
    latency: LatencyHistogram = field(default_factory=LatencyHistogram)
    success_counter: TimeWindowCounter = field(default_factory=TimeWindowCounter)
    failure_counter: TimeWindowCounter = field(default_factory=TimeWindowCounter)
    total_requests: int = 0
    total_successes: int = 0
    total_failures: int = 0
    consistency_scores: Deque[float] = field(default_factory=lambda: deque(maxlen=100))
    last_update: float = field(default_factory=time.time)
    _health_history: Deque[float] = field(default_factory=lambda: deque(maxlen=10))

    def record_request(
        self,
        latency_ms: float,
        success: bool,
        consistency_score: Optional[float] = None,
    ) -> None:
        """
        Record a request outcome.

        Args:
            latency_ms: Request latency
            success: Whether request succeeded
            consistency_score: Optional consistency check score
        """
        self.total_requests += 1
        self.last_update = time.time()

        if success:
            self.total_successes += 1
            self.success_counter.record()
            self.latency.record(latency_ms)
        else:
            self.total_failures += 1
            self.failure_counter.record()

        if consistency_score is not None:
            self.consistency_scores.append(consistency_score)

        # Update health history
        self._health_history.append(self.health_score)

    @property
    def success_rate(self) -> float:
        """Overall success rate."""
        if self.total_requests == 0:
            return 0.0
        return self.total_successes / self.total_requests

    @property
    def recent_success_rate(self) -> float:
        """Success rate in recent window."""
        successes = self.success_counter.count
        failures = self.failure_counter.count
        total = successes + failures
        if total == 0:
            return 0.0
        return successes / total

    @property
    def avg_consistency(self) -> float:
        """Average consistency score."""
        if not self.consistency_scores:
            return 1.0  # Default to consistent
        return sum(self.consistency_scores) / len(self.consistency_scores)

    @property
    def health_score(self) -> float:
        """
        Composite health score in [0, 1].

        Combines:
            - Success rate (40%)
            - Latency score (30%)
            - Consistency score (30%)
        """
        # Success component
        success_score = self.recent_success_rate if self.total_requests > 0 else 1.0

        # Latency component (lower is better, normalize to 1000ms baseline)
        latency_p90 = self.latency.p90 if self.latency.count > 0 else 100.0
        latency_score = max(0.0, 1.0 - (latency_p90 / 5000.0))  # 5s = 0 score

        # Consistency component
        consistency_score = self.avg_consistency

        # Weighted combination
        return (
            0.4 * success_score +
            0.3 * latency_score +
            0.3 * consistency_score
        )

    @property
    def trend(self) -> HealthTrend:
        """Health trend over recent history."""
        if len(self._health_history) < 3:
            return HealthTrend.UNKNOWN

        recent = list(self._health_history)[-5:]
        if len(recent) < 2:
            return HealthTrend.UNKNOWN

        # Calculate trend
        first_half = sum(recent[:len(recent)//2]) / (len(recent)//2)
        second_half = sum(recent[len(recent)//2:]) / (len(recent) - len(recent)//2)

        diff = second_half - first_half

        if diff > 0.05:
            return HealthTrend.IMPROVING
        elif diff < -0.05:
            return HealthTrend.DEGRADING
        return HealthTrend.STABLE

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "agent_id": self.agent_id,
            "total_requests": self.total_requests,
            "total_successes": self.total_successes,
            "total_failures": self.total_failures,
            "success_rate": round(self.success_rate, 4),
            "recent_success_rate": round(self.recent_success_rate, 4),
            "health_score": round(self.health_score, 4),
            "trend": self.trend.name,
            "latency": self.latency.to_dict(),
            "avg_consistency": round(self.avg_consistency, 4),
            "last_update": self.last_update,
        }


@dataclass
class TopologyChurnMetrics:
    """
    Tracks topology changes over time.

    Monitors:
        - Agent registration/deregistration
        - Circuit breaker state changes
        - Routing pattern changes
    """

    window_seconds: float = 300.0
    _registrations: Deque[tuple[float, str]] = field(default_factory=deque)
    _deregistrations: Deque[tuple[float, str]] = field(default_factory=deque)
    _circuit_changes: Deque[tuple[float, str, str]] = field(default_factory=deque)
    _route_changes: Deque[tuple[float, str, str]] = field(default_factory=deque)

    def _cleanup(self) -> None:
        """Remove old events outside window."""
        cutoff = time.time() - self.window_seconds

        while self._registrations and self._registrations[0][0] < cutoff:
            self._registrations.popleft()
        while self._deregistrations and self._deregistrations[0][0] < cutoff:
            self._deregistrations.popleft()
        while self._circuit_changes and self._circuit_changes[0][0] < cutoff:
            self._circuit_changes.popleft()
        while self._route_changes and self._route_changes[0][0] < cutoff:
            self._route_changes.popleft()

    def record_registration(self, agent_id: str) -> None:
        """Record agent registration."""
        self._registrations.append((time.time(), agent_id))

    def record_deregistration(self, agent_id: str) -> None:
        """Record agent deregistration."""
        self._deregistrations.append((time.time(), agent_id))

    def record_circuit_change(self, agent_id: str, new_state: str) -> None:
        """Record circuit breaker state change."""
        self._circuit_changes.append((time.time(), agent_id, new_state))

    def record_route_change(self, capability: str, old_agent: str, new_agent: str) -> None:
        """Record routing pattern change."""
        if old_agent != new_agent:
            self._route_changes.append((time.time(), old_agent, new_agent))

    @property
    def churn_score(self) -> float:
        """
        Topology churn score.

        Higher = more instability.
        """
        self._cleanup()

        # Weight different types of changes
        reg_weight = 0.5
        dereg_weight = 1.0  # Deregistrations are more impactful
        circuit_weight = 2.0  # Circuit changes indicate problems
        route_weight = 0.3  # Route changes are normal

        total = (
            len(self._registrations) * reg_weight +
            len(self._deregistrations) * dereg_weight +
            len(self._circuit_changes) * circuit_weight +
            len(self._route_changes) * route_weight
        )

        # Normalize to [0, 1] (10 events in window = score of 1)
        return min(1.0, total / 10.0)

    @property
    def is_stable(self) -> bool:
        """Whether topology is stable."""
        return self.churn_score < 0.3

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        self._cleanup()
        return {
            "registrations": len(self._registrations),
            "deregistrations": len(self._deregistrations),
            "circuit_changes": len(self._circuit_changes),
            "route_changes": len(self._route_changes),
            "churn_score": round(self.churn_score, 4),
            "is_stable": self.is_stable,
            "window_seconds": self.window_seconds,
        }


class HealthMetricsTracker:
    """
    Central tracker for all health metrics.

    Provides:
        - Per-agent health metrics
        - Topology churn tracking
        - Aggregate health scores
    """

    def __init__(self, window_seconds: float = 300.0):
        self._agents: Dict[str, AgentHealthMetrics] = {}
        self._topology = TopologyChurnMetrics(window_seconds=window_seconds)
        self._last_routes: Dict[str, str] = {}  # capability -> agent_id
        logger.info(f"HealthMetricsTracker initialized (window={window_seconds}s)")

    def get_or_create(self, agent_id: str) -> AgentHealthMetrics:
        """Get or create metrics for an agent."""
        if agent_id not in self._agents:
            self._agents[agent_id] = AgentHealthMetrics(agent_id=agent_id)
        return self._agents[agent_id]

    def record_request(
        self,
        agent_id: str,
        latency_ms: float,
        success: bool,
        consistency_score: Optional[float] = None,
    ) -> None:
        """
        Record a request outcome.

        Args:
            agent_id: Agent that handled request
            latency_ms: Request latency
            success: Whether request succeeded
            consistency_score: Optional consistency check score
        """
        metrics = self.get_or_create(agent_id)
        metrics.record_request(latency_ms, success, consistency_score)

    def record_registration(self, agent_id: str) -> None:
        """Record agent registration."""
        self._topology.record_registration(agent_id)
        self.get_or_create(agent_id)  # Ensure metrics exist

    def record_deregistration(self, agent_id: str) -> None:
        """Record agent deregistration."""
        self._topology.record_deregistration(agent_id)
        # Remove agent metrics to prevent memory leak and stale data in aggregations
        if agent_id in self._agents:
            del self._agents[agent_id]
        # Clean up route tracking for this agent
        self._last_routes = {k: v for k, v in self._last_routes.items() if v != agent_id}

    def record_circuit_change(self, agent_id: str, new_state: str) -> None:
        """Record circuit breaker state change."""
        self._topology.record_circuit_change(agent_id, new_state)

    def record_route(self, capability: str, agent_id: str) -> None:
        """Record routing decision (tracks changes)."""
        old_agent = self._last_routes.get(capability, "")
        if old_agent and old_agent != agent_id:
            self._topology.record_route_change(capability, old_agent, agent_id)
        self._last_routes[capability] = agent_id

    def get_health(self, agent_id: str) -> Optional[AgentHealthMetrics]:
        """Get health metrics for an agent."""
        return self._agents.get(agent_id)

    def get_all_health(self) -> Dict[str, AgentHealthMetrics]:
        """Get health metrics for all agents."""
        return dict(self._agents)

    @property
    def topology_churn(self) -> TopologyChurnMetrics:
        """Get topology churn metrics."""
        return self._topology

    @property
    def aggregate_health(self) -> float:
        """Aggregate health score across all agents."""
        if not self._agents:
            return 1.0
        scores = [m.health_score for m in self._agents.values()]
        return sum(scores) / len(scores)

    @property
    def unhealthy_agents(self) -> List[str]:
        """List of agents with health < 0.5."""
        return [
            agent_id
            for agent_id, metrics in self._agents.items()
            if metrics.health_score < 0.5
        ]

    @property
    def degrading_agents(self) -> List[str]:
        """List of agents with degrading trend."""
        return [
            agent_id
            for agent_id, metrics in self._agents.items()
            if metrics.trend == HealthTrend.DEGRADING
        ]

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "agents": {
                agent_id: metrics.to_dict()
                for agent_id, metrics in self._agents.items()
            },
            "topology": self._topology.to_dict(),
            "aggregate_health": round(self.aggregate_health, 4),
            "unhealthy_agents": self.unhealthy_agents,
            "degrading_agents": self.degrading_agents,
        }
