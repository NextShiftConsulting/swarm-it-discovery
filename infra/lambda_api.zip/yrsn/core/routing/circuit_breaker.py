"""
Circuit Breaker - Agent Health Protection.

Implements the circuit breaker pattern to protect against failing agents:
    - CLOSED: Normal operation, requests allowed
    - OPEN: Too many failures, requests blocked
    - HALF_OPEN: Testing recovery, limited requests allowed

State transitions:
    CLOSED → OPEN: After failure_threshold failures in window
    OPEN → HALF_OPEN: After timeout_seconds
    HALF_OPEN → CLOSED: After success_threshold successes
    HALF_OPEN → OPEN: On any failure

Example:
    config = CircuitBreakerConfig(failure_threshold=5, timeout_seconds=60)
    breaker = CircuitBreaker(config)

    if breaker.allow_request():
        try:
            result = call_agent()
            breaker.record_success()
        except Exception:
            breaker.record_failure()
    else:
        # Circuit is open, use fallback
        pass
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional, List
import threading
import time
import logging


logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""

    CLOSED = "CLOSED"  # Normal operation
    OPEN = "OPEN"  # Blocking requests
    HALF_OPEN = "HALF_OPEN"  # Testing recovery


@dataclass(frozen=True)
class CircuitBreakerConfig:
    """
    Configuration for circuit breaker.

    Attributes:
        failure_threshold: Number of failures to trigger OPEN state
        success_threshold: Number of successes in HALF_OPEN to close
        timeout_seconds: Base time to wait before transitioning to HALF_OPEN
        window_seconds: Sliding window for counting failures
        backoff_multiplier: Multiplier for exponential backoff on consecutive opens
        max_backoff_seconds: Maximum backoff timeout
    """

    failure_threshold: int = 5
    success_threshold: int = 2
    timeout_seconds: float = 60.0
    window_seconds: float = 60.0
    backoff_multiplier: float = 2.0
    max_backoff_seconds: float = 300.0

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.failure_threshold < 1:
            raise ValueError(f"failure_threshold must be >= 1, got {self.failure_threshold}")
        if self.success_threshold < 1:
            raise ValueError(f"success_threshold must be >= 1, got {self.success_threshold}")
        if self.timeout_seconds < 0:
            raise ValueError(f"timeout_seconds must be >= 0, got {self.timeout_seconds}")
        if self.window_seconds < 0:
            raise ValueError(f"window_seconds must be >= 0, got {self.window_seconds}")
        if self.backoff_multiplier < 1.0:
            raise ValueError(f"backoff_multiplier must be >= 1.0, got {self.backoff_multiplier}")
        if self.max_backoff_seconds < self.timeout_seconds:
            raise ValueError(f"max_backoff_seconds must be >= timeout_seconds")


class CircuitBreaker:
    """
    Circuit breaker for agent health protection.

    Tracks:
        - Failure count in sliding window
        - Success count in half-open state
        - Last failure timestamp
        - Current state
        - Consecutive opens for exponential backoff

    Thread-safe: Uses RLock for all state modifications.
    """

    def __init__(self, config: Optional[CircuitBreakerConfig] = None):
        """
        Initialize circuit breaker.

        Args:
            config: Configuration (uses defaults if not provided)
        """
        self.config = config or CircuitBreakerConfig()
        self._lock = threading.RLock()
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: Optional[float] = None
        self._failure_timestamps: List[float] = []
        self._consecutive_opens = 0
        logger.debug(f"CircuitBreaker initialized: {self.config}")

    @property
    def state(self) -> CircuitState:
        """
        Get current state (may trigger state transitions).

        Returns:
            Current CircuitState
        """
        with self._lock:
            self._update_state()
            return self._state

    @property
    def failure_count(self) -> int:
        """Get current failure count in window."""
        with self._lock:
            self._cleanup_old_failures()
            return len(self._failure_timestamps)

    @property
    def consecutive_opens(self) -> int:
        """Get number of consecutive times circuit has opened."""
        with self._lock:
            return self._consecutive_opens

    def _get_current_timeout(self) -> float:
        """Calculate timeout with exponential backoff."""
        base_timeout = self.config.timeout_seconds
        backoff = base_timeout * (self.config.backoff_multiplier ** self._consecutive_opens)
        return min(backoff, self.config.max_backoff_seconds)

    def record_success(self) -> None:
        """Record a successful request."""
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                logger.debug(
                    f"CircuitBreaker success in HALF_OPEN: "
                    f"{self._success_count}/{self.config.success_threshold}"
                )

                if self._success_count >= self.config.success_threshold:
                    self._transition_to_closed()

            elif self._state == CircuitState.CLOSED:
                # Reset failure count on success
                self._failure_count = 0
                self._failure_timestamps.clear()

    def record_failure(self) -> None:
        """Record a failed request."""
        with self._lock:
            current_time = time.time()
            self._last_failure_time = current_time
            self._failure_timestamps.append(current_time)

            # Remove old failures outside window
            self._cleanup_old_failures()

            self._failure_count = len(self._failure_timestamps)

            logger.debug(
                f"CircuitBreaker failure recorded: "
                f"{self._failure_count}/{self.config.failure_threshold}"
            )

            if self._state == CircuitState.HALF_OPEN:
                # Any failure in half-open → back to open
                self._transition_to_open()

            elif (
                self._state == CircuitState.CLOSED
                and self._failure_count >= self.config.failure_threshold
            ):
                self._transition_to_open()

    def allow_request(self) -> bool:
        """
        Check if a request should be allowed.

        Returns:
            True if request should proceed, False if blocked
        """
        with self._lock:
            self._update_state()

            if self._state == CircuitState.OPEN:
                return False

            return True

    def reset(self) -> None:
        """Reset circuit breaker to closed state."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._success_count = 0
            self._last_failure_time = None
            self._failure_timestamps.clear()
            self._consecutive_opens = 0
            logger.info("CircuitBreaker reset to CLOSED")

    # --- Internal state management ---

    def _cleanup_old_failures(self) -> None:
        """Remove failures outside the sliding window."""
        cutoff = time.time() - self.config.window_seconds
        self._failure_timestamps = [t for t in self._failure_timestamps if t > cutoff]

    def _update_state(self) -> None:
        """Update state based on timeout with exponential backoff."""
        if self._state == CircuitState.OPEN and self._last_failure_time:
            elapsed = time.time() - self._last_failure_time
            timeout = self._get_current_timeout()
            if elapsed >= timeout:
                self._transition_to_half_open()

    def _transition_to_open(self) -> None:
        """Transition to OPEN state."""
        # Only increment consecutive_opens on recovery failure (HALF_OPEN → OPEN)
        # First open from CLOSED should use base timeout
        if self._state == CircuitState.HALF_OPEN:
            self._consecutive_opens += 1

        self._state = CircuitState.OPEN
        self._success_count = 0
        timeout = self._get_current_timeout()
        logger.warning(
            f"CircuitBreaker OPEN: too many failures "
            f"(consecutive={self._consecutive_opens}, timeout={timeout:.1f}s)"
        )

    def _transition_to_half_open(self) -> None:
        """Transition to HALF_OPEN state."""
        self._state = CircuitState.HALF_OPEN
        self._success_count = 0
        logger.info("CircuitBreaker HALF_OPEN: testing recovery")

    def _transition_to_closed(self) -> None:
        """Transition to CLOSED state."""
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._failure_timestamps.clear()
        self._consecutive_opens = 0  # Reset backoff on successful recovery
        logger.info("CircuitBreaker CLOSED: recovery confirmed")

    def to_dict(self) -> Dict[str, Any]:
        """
        Export state for diagnostics.

        Returns:
            Dictionary with circuit breaker state
        """
        with self._lock:
            return {
                "state": self._state.value,
                "failure_count": len(self._failure_timestamps),
                "success_count": self._success_count,
                "last_failure_time": self._last_failure_time,
                "consecutive_opens": self._consecutive_opens,
                "current_timeout": self._get_current_timeout(),
                "config": {
                    "failure_threshold": self.config.failure_threshold,
                    "success_threshold": self.config.success_threshold,
                    "timeout_seconds": self.config.timeout_seconds,
                    "window_seconds": self.config.window_seconds,
                    "backoff_multiplier": self.config.backoff_multiplier,
                    "max_backoff_seconds": self.config.max_backoff_seconds,
                },
            }
