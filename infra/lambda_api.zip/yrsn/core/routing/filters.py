"""
Content Filters for Routing Layer.

Provides filtering capabilities to detect and handle:
    - Contradictions in input/context
    - Irrelevant content injection
    - Semantic noise

Example:
    filter = ContradictionFilter(max_contradictions=3)
    result = filter.filter(content)

    if not result.passed:
        # Handle filtered content
        use_filtered = result.filtered_content
"""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from typing import Dict, Any, List, Tuple, Optional


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FilterResult:
    """
    Result of content filtering.

    Attributes:
        passed: Whether content passed the filter
        contradiction_count: Number of contradictions detected
        filtered_content: Cleaned content (if filtering applied)
        rationale: Explanation of filtering decision
        detected_patterns: List of (pattern_name, match) tuples
    """

    passed: bool
    contradiction_count: int
    filtered_content: str
    rationale: str
    detected_patterns: Tuple[Tuple[str, str], ...] = ()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "passed": self.passed,
            "contradiction_count": self.contradiction_count,
            "filtered_content_length": len(self.filtered_content),
            "rationale": self.rationale,
            "detected_patterns": list(self.detected_patterns),
        }


class ContradictionFilter:
    """
    Filter for detecting and handling contradictory content.

    Detects patterns like:
        - "Do X" followed by "Do NOT do X"
        - "Include" followed by "exclude"
        - Factual contradictions ("X is true" / "X is false")

    Attributes:
        max_contradictions: Maximum allowed contradictions before filtering
    """

    # Default contradiction patterns (regex, name)
    DEFAULT_PATTERNS: List[Tuple[str, str]] = [
        # Explicit do/don't contradictions
        (r"(?i)do\s+(\w+).*do\s+NOT\s+\1", "explicit_negation"),
        (r"(?i)do\s+NOT\s+(\w+).*do\s+\1", "explicit_negation_reverse"),

        # Include/exclude contradictions
        (r"(?i)include\s+(?:the\s+)?(\w+).*exclude\s+(?:the\s+)?\1", "boundary_contradiction"),
        (r"(?i)exclude\s+(?:the\s+)?(\w+).*include\s+(?:the\s+)?\1", "boundary_contradiction_reverse"),

        # True/false factual contradictions
        (r"(?i)(\w+)\s+is\s+true.*\1\s+is\s+false", "factual_contradiction"),
        (r"(?i)(\w+)\s+is\s+false.*\1\s+is\s+true", "factual_contradiction_reverse"),

        # Claim blocks (common in kill suite attacks)
        (r"(?i)Claim:\s*(\w+)\s+is\s+true.*Claim:\s*\1\s+is\s+false", "claim_contradiction"),

        # Constraint contradictions
        (r"(?i)Constraint\s+\w+:\s*Do\s+(\w+).*Constraint\s+\w+:\s*Do\s+NOT\s+\1", "constraint_contradiction"),

        # Endpoints include/exclude trap
        (r"(?i)include\s+(?:the\s+)?endpoints.*exclude\s+(?:them)?", "endpoint_trap"),
    ]

    def __init__(
        self,
        max_contradictions: int = 3,
        custom_patterns: Optional[List[Tuple[str, str]]] = None,
    ):
        """
        Initialize contradiction filter.

        Args:
            max_contradictions: Maximum contradictions before content is filtered
            custom_patterns: Additional (regex, name) patterns to detect
        """
        self.max_contradictions = max_contradictions
        self._patterns = list(self.DEFAULT_PATTERNS)
        if custom_patterns:
            self._patterns.extend(custom_patterns)

        # Compile patterns for efficiency
        self._compiled_patterns = [
            (re.compile(pattern, re.MULTILINE | re.DOTALL), name)
            for pattern, name in self._patterns
        ]
        logger.debug(f"ContradictionFilter initialized with {len(self._patterns)} patterns")

    def filter(self, content: str) -> FilterResult:
        """
        Filter content for contradictions.

        Args:
            content: Text content to filter

        Returns:
            FilterResult with detection results and optionally filtered content
        """
        detected: List[Tuple[str, str]] = []

        for compiled_pattern, pattern_name in self._compiled_patterns:
            matches = compiled_pattern.findall(content)
            for match in matches:
                match_str = match if isinstance(match, str) else str(match)
                detected.append((pattern_name, match_str))

        contradiction_count = len(detected)

        if contradiction_count <= self.max_contradictions:
            return FilterResult(
                passed=True,
                contradiction_count=contradiction_count,
                filtered_content=content,
                rationale=f"Content passed with {contradiction_count} contradictions (max={self.max_contradictions})",
                detected_patterns=tuple(detected),
            )

        # Filter out contradictory sections
        filtered_content = self._remove_contradictions(content)

        logger.warning(
            f"ContradictionFilter blocked: {contradiction_count} contradictions detected "
            f"(max={self.max_contradictions})"
        )

        return FilterResult(
            passed=False,
            contradiction_count=contradiction_count,
            filtered_content=filtered_content,
            rationale=f"Content filtered: {contradiction_count} contradictions detected",
            detected_patterns=tuple(detected),
        )

    def _remove_contradictions(self, content: str) -> str:
        """
        Remove contradictory sections from content.

        Simple approach: Remove lines containing contradiction patterns.
        """
        lines = content.split("\n")
        filtered_lines = []

        for line in lines:
            is_contradictory = False
            for compiled_pattern, _ in self._compiled_patterns:
                if compiled_pattern.search(line):
                    is_contradictory = True
                    break

            if not is_contradictory:
                filtered_lines.append(line)

        return "\n".join(filtered_lines)

    def detect_count(self, content: str) -> int:
        """
        Quick count of contradictions without full filtering.

        Args:
            content: Text to scan

        Returns:
            Number of contradictions detected
        """
        count = 0
        for compiled_pattern, _ in self._compiled_patterns:
            count += len(compiled_pattern.findall(content))
        return count

    def to_dict(self) -> Dict[str, Any]:
        """Serialize configuration for telemetry."""
        return {
            "max_contradictions": self.max_contradictions,
            "pattern_count": len(self._patterns),
        }


class IrrelevantContentFilter:
    """
    Filter for detecting and removing irrelevant content injection.

    Detects patterns like:
        - Repeated "IRRELEVANT" markers
        - Hash noise (deadbeef patterns)
        - Excessive repetition
    """

    DEFAULT_NOISE_PATTERNS: List[Tuple[str, str]] = [
        (r"IRRELEVANT\s+", "irrelevant_marker"),
        (r"[a-f0-9]{16,}", "hash_noise"),
        (r"Related but irrelevant fact", "distractor_fact"),
        (r"\[Background \d+\]", "background_injection"),
    ]

    def __init__(
        self,
        max_noise_ratio: float = 0.3,
        custom_patterns: Optional[List[Tuple[str, str]]] = None,
    ):
        """
        Initialize irrelevant content filter.

        Args:
            max_noise_ratio: Maximum ratio of noise to content (0-1)
            custom_patterns: Additional (regex, name) patterns to detect
        """
        self.max_noise_ratio = max_noise_ratio
        self._patterns = list(self.DEFAULT_NOISE_PATTERNS)
        if custom_patterns:
            self._patterns.extend(custom_patterns)

        self._compiled_patterns = [
            (re.compile(pattern), name)
            for pattern, name in self._patterns
        ]

    def filter(self, content: str) -> FilterResult:
        """
        Filter content for irrelevant noise.

        Args:
            content: Text content to filter

        Returns:
            FilterResult with detection results
        """
        detected: List[Tuple[str, str]] = []
        noise_chars = 0

        for compiled_pattern, pattern_name in self._compiled_patterns:
            matches = compiled_pattern.findall(content)
            for match in matches:
                match_str = match if isinstance(match, str) else str(match)
                detected.append((pattern_name, match_str))
                noise_chars += len(match_str)

        total_chars = max(len(content), 1)
        noise_ratio = noise_chars / total_chars

        if noise_ratio <= self.max_noise_ratio:
            return FilterResult(
                passed=True,
                contradiction_count=len(detected),
                filtered_content=content,
                rationale=f"Content passed with {noise_ratio:.1%} noise ratio",
                detected_patterns=tuple(detected),
            )

        # Remove noise patterns
        filtered_content = content
        for compiled_pattern, _ in self._compiled_patterns:
            filtered_content = compiled_pattern.sub("", filtered_content)

        # Clean up excessive whitespace
        filtered_content = re.sub(r"\n{3,}", "\n\n", filtered_content)
        filtered_content = re.sub(r" {2,}", " ", filtered_content)

        logger.warning(
            f"IrrelevantContentFilter blocked: {noise_ratio:.1%} noise ratio "
            f"(max={self.max_noise_ratio:.1%})"
        )

        return FilterResult(
            passed=False,
            contradiction_count=len(detected),
            filtered_content=filtered_content.strip(),
            rationale=f"Content filtered: {noise_ratio:.1%} noise ratio",
            detected_patterns=tuple(detected),
        )
