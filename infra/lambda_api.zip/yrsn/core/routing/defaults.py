"""
Default Backend Configurations.

Pre-configured backends for common use cases:
    - LLM backends: Claude, GPT-4, Gemini
    - Encoding backends: HybridRotor, KappaAdapter
    - Solver backends: HRMV, TRM, Symbolic

Example:
    from yrsn.core.routing import create_default_orchestrator

    # Create orchestrator with all default backends
    orchestrator = create_default_orchestrator()

    # Or use specific backends
    from yrsn.core.routing import BACKEND_CLAUDE, BACKEND_ROTOR

    orchestrator = RoutingOrchestrator()
    orchestrator.register_agent(BACKEND_CLAUDE)
    orchestrator.register_agent(BACKEND_ROTOR)
"""

from __future__ import annotations

from typing import List

from .descriptors import Capability, Offer
from .orchestrator import RoutingOrchestrator


# =============================================================================
# LLM Backends (Remote)
# =============================================================================

BACKEND_CLAUDE = Offer(
    agent_id="claude-sonnet",
    capabilities=frozenset({Capability.INFERENCE_LLM, Capability.RE_ENCODE}),
    current_quality=0.9,
    avg_latency_ms=800,
    health_score=0.95,
    is_local=False,
    metadata={"provider": "anthropic", "model": "claude-3-5-sonnet"},
)

BACKEND_GPT4 = Offer(
    agent_id="gpt-4o",
    capabilities=frozenset({Capability.INFERENCE_LLM}),
    current_quality=0.85,
    avg_latency_ms=1200,
    health_score=0.90,
    is_local=False,
    metadata={"provider": "openai", "model": "gpt-4o"},
)

BACKEND_GEMINI = Offer(
    agent_id="gemini-flash",
    capabilities=frozenset({Capability.INFERENCE_LLM, Capability.FILTER_CONTEXT}),
    current_quality=0.8,
    avg_latency_ms=400,
    health_score=0.88,
    is_local=False,
    metadata={"provider": "google", "model": "gemini-2.0-flash"},
)


# =============================================================================
# Encoding Backends (Local)
# =============================================================================

BACKEND_ROTOR = Offer(
    agent_id="hybrid-rotor",
    capabilities=frozenset({Capability.RE_ENCODE, Capability.RECALIBRATE}),
    current_quality=0.95,
    avg_latency_ms=50,
    health_score=0.98,
    is_local=True,
    metadata={"type": "HybridSimplexRotor", "checkpoint": "trained_rotor_universal64.pt"},
)

BACKEND_ADAPTER = Offer(
    agent_id="kappa-adapter",
    capabilities=frozenset({Capability.RE_ENCODE}),
    current_quality=0.88,
    avg_latency_ms=30,
    health_score=0.92,
    is_local=True,
    metadata={"type": "KappaAdapter", "version": "1.0"},
)


# =============================================================================
# Solver Backends (Local)
# =============================================================================

BACKEND_HRMV = Offer(
    agent_id="hrmv-solver",
    capabilities=frozenset({Capability.INFERENCE_HRMV, Capability.GATE_ADAPTATION}),
    current_quality=0.92,
    avg_latency_ms=100,
    health_score=0.94,
    is_local=True,
    metadata={"type": "HRMV", "version": "2.0"},
)

BACKEND_TRM = Offer(
    agent_id="trm-solver",
    capabilities=frozenset({Capability.INFERENCE_TRM}),
    current_quality=0.90,
    avg_latency_ms=150,
    health_score=0.91,
    is_local=True,
    metadata={"type": "TRM", "version": "1.5"},
)

BACKEND_SYMBOLIC = Offer(
    agent_id="symbolic-solver",
    capabilities=frozenset({Capability.SUPPRESS, Capability.GATE_ADAPTATION}),
    current_quality=0.99,
    avg_latency_ms=20,
    health_score=0.99,
    is_local=True,
    metadata={"type": "SymbolicReasoner", "version": "3.0"},
)


# =============================================================================
# Emergency Backends (Protected - Cannot be deregistered by attacks)
# =============================================================================

EMERGENCY_LLM = Offer(
    agent_id="emergency-llm",
    capabilities=frozenset({Capability.INFERENCE_LLM, Capability.RE_ENCODE, Capability.FILTER_CONTEXT}),
    current_quality=0.75,  # Lower quality but always available
    avg_latency_ms=1000,
    health_score=1.0,  # Always healthy
    is_local=False,
    metadata={"type": "emergency", "protected": True},
)

EMERGENCY_ENCODER = Offer(
    agent_id="emergency-encoder",
    capabilities=frozenset({Capability.RE_ENCODE, Capability.RECALIBRATE}),
    current_quality=0.70,
    avg_latency_ms=100,
    health_score=1.0,
    is_local=True,
    metadata={"type": "emergency", "protected": True},
)

EMERGENCY_SOLVER = Offer(
    agent_id="emergency-solver",
    capabilities=frozenset({Capability.INFERENCE_HRMV, Capability.INFERENCE_TRM, Capability.SUPPRESS}),
    current_quality=0.70,
    avg_latency_ms=200,
    health_score=1.0,
    is_local=True,
    metadata={"type": "emergency", "protected": True},
)

EMERGENCY_BACKENDS: List[Offer] = [
    EMERGENCY_LLM,
    EMERGENCY_ENCODER,
    EMERGENCY_SOLVER,
]


# =============================================================================
# Default Collection
# =============================================================================

DEFAULT_BACKENDS: List[Offer] = [
    # LLM
    BACKEND_CLAUDE,
    BACKEND_GPT4,
    BACKEND_GEMINI,
    # Encoding
    BACKEND_ROTOR,
    BACKEND_ADAPTER,
    # Solvers
    BACKEND_HRMV,
    BACKEND_TRM,
    BACKEND_SYMBOLIC,
]


def create_default_orchestrator(include_emergency: bool = True) -> RoutingOrchestrator:
    """
    Create orchestrator with all default backends pre-registered.

    Args:
        include_emergency: Whether to include protected emergency backends

    Returns:
        RoutingOrchestrator with default backends
    """
    orchestrator = RoutingOrchestrator()

    # Register emergency backends first (protected)
    if include_emergency:
        for backend in EMERGENCY_BACKENDS:
            orchestrator.register_agent(backend, protected=True)

    # Register normal backends
    for backend in DEFAULT_BACKENDS:
        orchestrator.register_agent(backend)

    return orchestrator


def create_llm_only_orchestrator() -> RoutingOrchestrator:
    """
    Create orchestrator with only LLM backends.

    Returns:
        RoutingOrchestrator with LLM backends only
    """
    orchestrator = RoutingOrchestrator()
    orchestrator.register_agent(BACKEND_CLAUDE)
    orchestrator.register_agent(BACKEND_GPT4)
    orchestrator.register_agent(BACKEND_GEMINI)
    return orchestrator


def create_local_only_orchestrator() -> RoutingOrchestrator:
    """
    Create orchestrator with only local backends.

    Returns:
        RoutingOrchestrator with local backends only
    """
    orchestrator = RoutingOrchestrator()
    for backend in DEFAULT_BACKENDS:
        if backend.is_local:
            orchestrator.register_agent(backend)
    return orchestrator
