"""
Descriptor-Payload Consistency Checks.

DyTopo-inspired validation: does the routed payload actually satisfy the Need?

Provides:
    - ConsistencyChecker: Protocol for consistency validation
    - KeywordConsistencyChecker: Simple keyword overlap check
    - SemanticConsistencyChecker: Embedding-based semantic similarity
    - EntailmentConsistencyChecker: NLI-based entailment check
    - ConsistencyResult: Validation outcome with explanation

Example:
    checker = KeywordConsistencyChecker()

    result = checker.check(
        need=Need(required_capability=Capability.RE_ENCODE),
        payload={"encoded": True, "features": [...]},
    )

    if result.consistent:
        print("Payload satisfies need")
    else:
        print(f"Inconsistency: {result.reason}")
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Set
from enum import Enum, auto

from .descriptors import Need, Capability


logger = logging.getLogger(__name__)


class ConsistencyLevel(Enum):
    """Level of consistency between Need and payload."""
    FULL = auto()      # Payload fully satisfies Need
    PARTIAL = auto()   # Payload partially satisfies Need
    NONE = auto()      # Payload does not satisfy Need
    UNKNOWN = auto()   # Cannot determine consistency


@dataclass(frozen=True)
class ConsistencyResult:
    """
    Result of consistency check.

    Attributes:
        level: Consistency level
        score: Consistency score in [0, 1]
        reason: Human-readable explanation
        details: Additional check details
    """
    level: ConsistencyLevel
    score: float
    reason: str
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def consistent(self) -> bool:
        """Whether payload is consistent (FULL or PARTIAL)."""
        return self.level in (ConsistencyLevel.FULL, ConsistencyLevel.PARTIAL)

    @property
    def fully_consistent(self) -> bool:
        """Whether payload is fully consistent."""
        return self.level == ConsistencyLevel.FULL

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "level": self.level.name,
            "score": round(self.score, 4),
            "reason": self.reason,
            "consistent": self.consistent,
            "details": self.details,
        }


class ConsistencyChecker(ABC):
    """Protocol for consistency validation."""

    @abstractmethod
    def check(
        self,
        need: Need,
        payload: Dict[str, Any],
    ) -> ConsistencyResult:
        """
        Check if payload satisfies need.

        Args:
            need: The routing Need
            payload: The response payload

        Returns:
            ConsistencyResult
        """
        ...


class KeywordConsistencyChecker(ConsistencyChecker):
    """
    Simple keyword-based consistency checker.

    Checks:
        - Required keywords present in payload
        - Capability-specific field validation
        - Structural completeness
    """

    # Expected fields per capability
    # Note: For inference capabilities, ANY of the fields is sufficient
    CAPABILITY_FIELDS: Dict[Capability, Set[str]] = {
        Capability.RE_ENCODE: {"encoded", "features", "embedding"},
        Capability.FILTER_CONTEXT: {"filtered", "kept", "removed"},
        Capability.RECALIBRATE: {"recalibrated", "domain", "shift"},
        Capability.INFERENCE_LLM: {"response", "content", "text"},
        Capability.INFERENCE_HRMV: {"solved", "solution", "proof"},
        Capability.INFERENCE_TRM: {"solved", "trace", "steps"},
        Capability.SUPPRESS: {"blocked", "reason"},
        Capability.DEFER_HUMAN: {"deferred", "queue_id"},
        Capability.GATE_ADAPTATION: {"frozen", "learning_rate"},
        Capability.PROCEED: set(),  # No specific requirements
    }

    # Capabilities where ANY field is sufficient (vs ALL fields)
    ANY_FIELD_SUFFICIENT: Set[Capability] = {
        Capability.INFERENCE_LLM,
        Capability.INFERENCE_HRMV,
        Capability.INFERENCE_TRM,
    }

    def check(
        self,
        need: Need,
        payload: Dict[str, Any],
    ) -> ConsistencyResult:
        """Check keyword-based consistency."""
        if not payload:
            return ConsistencyResult(
                level=ConsistencyLevel.NONE,
                score=0.0,
                reason="Empty payload",
            )

        # Get expected fields for capability
        expected = self.CAPABILITY_FIELDS.get(need.required_capability, set())

        if not expected:
            # No specific requirements, any non-empty payload is acceptable
            return ConsistencyResult(
                level=ConsistencyLevel.FULL,
                score=1.0,
                reason=f"No specific requirements for {need.required_capability.name}",
            )

        # Check field overlap
        payload_keys = set(self._flatten_keys(payload))
        matched = expected & payload_keys
        missing = expected - payload_keys

        # For inference capabilities, ANY matching field is FULL
        if need.required_capability in self.ANY_FIELD_SUFFICIENT:
            if matched:
                return ConsistencyResult(
                    level=ConsistencyLevel.FULL,
                    score=1.0,
                    reason=f"Inference field present: {matched}",
                    details={"matched": list(matched), "missing": list(missing)},
                )
            else:
                return ConsistencyResult(
                    level=ConsistencyLevel.NONE,
                    score=0.0,
                    reason=f"No inference output field found, expected one of: {expected}",
                    details={"matched": [], "missing": list(expected)},
                )

        # For other capabilities, require all fields
        if not missing:
            return ConsistencyResult(
                level=ConsistencyLevel.FULL,
                score=1.0,
                reason=f"All expected fields present: {matched}",
                details={"matched": list(matched), "missing": []},
            )

        overlap_ratio = len(matched) / len(expected)

        if overlap_ratio >= 0.5:
            return ConsistencyResult(
                level=ConsistencyLevel.PARTIAL,
                score=overlap_ratio,
                reason=f"Partial match: {len(matched)}/{len(expected)} fields",
                details={"matched": list(matched), "missing": list(missing)},
            )

        return ConsistencyResult(
            level=ConsistencyLevel.NONE,
            score=overlap_ratio,
            reason=f"Missing required fields: {missing}",
            details={"matched": list(matched), "missing": list(missing)},
        )

    def _flatten_keys(self, d: Dict[str, Any], prefix: str = "") -> List[str]:
        """Flatten nested dict keys."""
        keys = []
        for k, v in d.items():
            full_key = f"{prefix}.{k}" if prefix else k
            keys.append(k)  # Add just the key
            keys.append(full_key)  # Add full path
            if isinstance(v, dict):
                keys.extend(self._flatten_keys(v, full_key))
        return keys


class StructuralConsistencyChecker(ConsistencyChecker):
    """
    Structural consistency checker.

    Validates payload structure against capability requirements:
        - Required fields present
        - Field types correct
        - Values within expected ranges
    """

    # Type expectations per field
    FIELD_TYPES: Dict[str, type] = {
        "encoded": bool,
        "features": (list, dict),
        "response": str,
        "solved": bool,
        "score": (int, float),
        "latency_ms": (int, float),
    }

    def check(
        self,
        need: Need,
        payload: Dict[str, Any],
    ) -> ConsistencyResult:
        """Check structural consistency."""
        if not payload:
            return ConsistencyResult(
                level=ConsistencyLevel.NONE,
                score=0.0,
                reason="Empty payload",
            )

        # Check for error indicators
        if "error" in payload and payload["error"]:
            return ConsistencyResult(
                level=ConsistencyLevel.NONE,
                score=0.0,
                reason=f"Payload contains error: {payload['error']}",
                details={"error": payload["error"]},
            )

        # Validate field types
        type_errors = []
        for field, expected_type in self.FIELD_TYPES.items():
            if field in payload:
                if not isinstance(payload[field], expected_type):
                    type_errors.append(
                        f"{field}: expected {expected_type}, got {type(payload[field])}"
                    )

        if type_errors:
            return ConsistencyResult(
                level=ConsistencyLevel.PARTIAL,
                score=0.5,
                reason=f"Type mismatches: {len(type_errors)}",
                details={"type_errors": type_errors},
            )

        # Check capability-specific validation
        return self._validate_capability(need.required_capability, payload)

    def _validate_capability(
        self,
        capability: Capability,
        payload: Dict[str, Any],
    ) -> ConsistencyResult:
        """Validate capability-specific requirements."""
        if capability == Capability.RE_ENCODE:
            if "encoded" in payload and payload["encoded"]:
                return ConsistencyResult(
                    level=ConsistencyLevel.FULL,
                    score=1.0,
                    reason="Re-encoding successful",
                )

        elif capability in (Capability.INFERENCE_LLM, Capability.INFERENCE_HRMV, Capability.INFERENCE_TRM):
            if any(k in payload for k in ("response", "output", "result", "solved")):
                return ConsistencyResult(
                    level=ConsistencyLevel.FULL,
                    score=1.0,
                    reason="Inference output present",
                )

        elif capability == Capability.SUPPRESS:
            if "blocked" in payload:
                return ConsistencyResult(
                    level=ConsistencyLevel.FULL,
                    score=1.0,
                    reason="Suppression acknowledged",
                )

        elif capability == Capability.PROCEED:
            # PROCEED has no specific requirements - any non-empty payload is fine
            return ConsistencyResult(
                level=ConsistencyLevel.FULL,
                score=1.0,
                reason="PROCEED capability - no validation required",
            )

        # Default: partial match if non-empty
        return ConsistencyResult(
            level=ConsistencyLevel.PARTIAL,
            score=0.7,
            reason="Payload present but capability-specific validation incomplete",
        )


class CompositeConsistencyChecker(ConsistencyChecker):
    """
    Composite checker combining multiple strategies.

    Aggregates results from multiple checkers with configurable weights.
    """

    def __init__(
        self,
        checkers: Optional[List[tuple[ConsistencyChecker, float]]] = None,
    ):
        """
        Initialize with checkers and weights.

        Args:
            checkers: List of (checker, weight) tuples
        """
        if checkers is None:
            checkers = [
                (KeywordConsistencyChecker(), 0.5),
                (StructuralConsistencyChecker(), 0.5),
            ]
        self.checkers = checkers

    def check(
        self,
        need: Need,
        payload: Dict[str, Any],
    ) -> ConsistencyResult:
        """Run all checkers and aggregate results."""
        if not self.checkers:
            return ConsistencyResult(
                level=ConsistencyLevel.UNKNOWN,
                score=0.5,
                reason="No checkers configured",
            )

        results: List[ConsistencyResult] = []
        total_weight = 0.0
        weighted_score = 0.0

        for checker, weight in self.checkers:
            try:
                result = checker.check(need, payload)
                results.append(result)
                weighted_score += result.score * weight
                total_weight += weight
            except Exception as e:
                logger.warning(f"Checker {checker.__class__.__name__} failed: {e}")

        if not results:
            return ConsistencyResult(
                level=ConsistencyLevel.UNKNOWN,
                score=0.5,
                reason="All checkers failed",
            )

        # Calculate aggregate score
        final_score = weighted_score / total_weight if total_weight > 0 else 0.5

        # Determine level from score
        if final_score >= 0.9:
            level = ConsistencyLevel.FULL
        elif final_score >= 0.5:
            level = ConsistencyLevel.PARTIAL
        else:
            level = ConsistencyLevel.NONE

        # Collect reasons
        reasons = [r.reason for r in results if r.reason]

        return ConsistencyResult(
            level=level,
            score=final_score,
            reason=" | ".join(reasons),
            details={
                "checker_results": [r.to_dict() for r in results],
            },
        )


# Default checker instance
default_consistency_checker = CompositeConsistencyChecker()


def check_consistency(need: Need, payload: Dict[str, Any]) -> ConsistencyResult:
    """
    Convenience function using default checker.

    Args:
        need: The routing Need
        payload: The response payload

    Returns:
        ConsistencyResult
    """
    return default_consistency_checker.check(need, payload)
