"""
Routing Controller - Integration Adapter.

Non-invasive integration with UnifiedEnforcementEngine.

Pipeline:
    1. UnifiedEnforcementEngine.decide(cert) → ControlDecision (for routing)
    2. RoutingOrchestrator.route(need) → RoutingResult
    3. UnifiedEnforcementEngine.enforce_certificate(cert) → EnforcementResult (optional full enforcement)

This controller wraps all three components into a single interface,
without modifying any of the underlying implementations (P1 compliant).

Example:
    from yrsn.core.routing import RoutingController, create_default_orchestrator

    # Create controller with default backends
    orchestrator = create_default_orchestrator()
    controller = RoutingController(routing_orchestrator=orchestrator)

    # Process certificate through full pipeline
    result = controller.process(certificate)

    if result.authorized and result.selected_agent:
        print(f"Execute via: {result.selected_agent}")
        print(f"Action: {result.control_decision.action.name}")

    # Update agent health after execution
    controller.update_agent_health(result.selected_agent, new_certificate)

    # Record outcome
    controller.record_outcome(result.selected_agent, success=True, latency_ms=50)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Any, TYPE_CHECKING
import logging

from .descriptors import Need, Offer
from .orchestrator import RoutingOrchestrator, RoutingResult

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate
    from yrsn.core.enforcement import (
        UnifiedEnforcementEngine,
        ControlDecision,
    )
    from yrsn.ports.gearbox import EnforcementResult


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class IntegratedResult:
    """
    Combined result from controller + routing + enforcement.

    Attributes:
        control_decision: From UnifiedEnforcementEngine.decide()
        routing_result: From RoutingOrchestrator
        enforcement_result: From UnifiedEnforcementEngine (optional, None if not available)
    """

    control_decision: "ControlDecision"
    routing_result: RoutingResult
    enforcement_result: Optional["EnforcementResult"] = None

    @property
    def selected_agent(self) -> Optional[str]:
        """Shortcut to selected agent ID."""
        return self.routing_result.selected_agent

    @property
    def authorized(self) -> bool:
        """Whether enforcement authorized the request."""
        if self.enforcement_result is None:
            return True  # No enforcement means authorized
        return self.enforcement_result.authorized

    @property
    def success(self) -> bool:
        """Whether routing succeeded (found a valid agent)."""
        return self.routing_result.success

    @property
    def action(self) -> str:
        """Shortcut to control action name."""
        return self.control_decision.action.name

    @property
    def gear(self) -> str:
        """Shortcut to gear name."""
        return self.control_decision.gear.name

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for telemetry."""
        return {
            "control": self.control_decision.to_dict(),
            "routing": self.routing_result.to_dict(),
            "enforcement": self.enforcement_result.to_dict() if self.enforcement_result else None,
            "selected_agent": self.selected_agent,
            "authorized": self.authorized,
            "action": self.action,
            "gear": self.gear,
        }


class RoutingController:
    """
    Integrated controller with routing.

    Pipeline:
        1. UnifiedEnforcementEngine.decide(cert) → ControlDecision
        2. RoutingOrchestrator.route(need) → RoutingResult
        3. UnifiedEnforcementEngine.enforce_certificate(cert) → EnforcementResult (optional)

    This is a non-invasive wrapper that doesn't modify the underlying components.
    Components can be injected or created with defaults.

    Thread-safety note: This implementation is NOT thread-safe.
    For concurrent use, wrap with appropriate locking.
    """

    def __init__(
        self,
        enforcement_engine: Optional["UnifiedEnforcementEngine"] = None,
        routing_orchestrator: Optional[RoutingOrchestrator] = None,
    ):
        """
        Initialize integrated controller.

        Args:
            enforcement_engine: Custom UnifiedEnforcementEngine (optional)
            routing_orchestrator: Custom RoutingOrchestrator (optional)
        """
        self._enforcement_engine = enforcement_engine
        self.routing_orchestrator = routing_orchestrator or RoutingOrchestrator()
        logger.info("RoutingController initialized")

    @property
    def enforcement_engine(self) -> "UnifiedEnforcementEngine":
        """Get or lazily create enforcement engine."""
        if self._enforcement_engine is None:
            from yrsn.core.enforcement.unified_enforcement_engine import (
                UnifiedEnforcementEngine,
            )

            self._enforcement_engine = UnifiedEnforcementEngine()
        return self._enforcement_engine

    def process(self, certificate: "YRSNCertificate") -> IntegratedResult:
        """
        Process certificate through full pipeline.

        Args:
            certificate: YRSNCertificate with R, S, N, alpha, omega, tau

        Returns:
            IntegratedResult with control + routing + enforcement decisions
        """
        # Step 1: Quality control decision
        control_decision = self.enforcement_engine.decide(certificate)

        # Step 2: Route to best agent
        need = Need.from_control_decision(control_decision)
        routing_result = self.routing_orchestrator.route(need)

        # Step 3: Enforcement (optional)
        enforcement_result = None
        if self._enforcement_engine is not None:
            enforcement_result = self._enforcement_engine.enforce_certificate(certificate)

        # Combine results
        result = IntegratedResult(
            control_decision=control_decision,
            routing_result=routing_result,
            enforcement_result=enforcement_result,
        )

        logger.info(
            f"Processed certificate: decision={control_decision.action.name}, "
            f"route={routing_result.selected_agent or 'NONE'}, "
            f"authorized={result.authorized}"
        )

        return result

    def process_with_need(
        self,
        certificate: "YRSNCertificate",
        need: Need,
    ) -> IntegratedResult:
        """
        Process certificate with explicit need (bypasses ControlDecision mapping).

        Useful when you want to specify routing requirements directly.

        Args:
            certificate: YRSNCertificate
            need: Explicit routing requirements

        Returns:
            IntegratedResult
        """
        # Step 1: Quality control decision
        control_decision = self.enforcement_engine.decide(certificate)

        # Step 2: Route with explicit need
        routing_result = self.routing_orchestrator.route(need)

        # Step 3: Enforcement (optional)
        enforcement_result = None
        if self._enforcement_engine is not None:
            enforcement_result = self._enforcement_engine.enforce_certificate(certificate)

        return IntegratedResult(
            control_decision=control_decision,
            routing_result=routing_result,
            enforcement_result=enforcement_result,
        )

    def register_agent(self, offer: Offer) -> None:
        """
        Register agent with routing orchestrator.

        Args:
            offer: Agent offer
        """
        self.routing_orchestrator.register_agent(offer)

    def deregister_agent(self, agent_id: str) -> None:
        """
        Remove agent from routing orchestrator.

        Args:
            agent_id: Agent identifier
        """
        self.routing_orchestrator.deregister_agent(agent_id)

    def update_agent_health(self, agent_id: str, certificate: "YRSNCertificate") -> None:
        """
        Update agent health from certificate.

        Args:
            agent_id: Agent identifier
            certificate: Latest certificate from agent
        """
        self.routing_orchestrator.update_agent_health(agent_id, certificate)

    def record_outcome(
        self,
        agent_id: str,
        success: bool,
        latency_ms: float,
    ) -> None:
        """
        Record agent request outcome.

        Args:
            agent_id: Agent that handled request
            success: Whether request succeeded
            latency_ms: Request latency in milliseconds
        """
        self.routing_orchestrator.record_outcome(agent_id, success, latency_ms)

    def get_agent_metrics(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get metrics for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            Metrics dictionary or None
        """
        return self.routing_orchestrator.get_agent_metrics(agent_id)

    def to_dict(self) -> Dict[str, Any]:
        """
        Export controller state.

        Returns:
            Dictionary with controller state
        """
        return {
            "has_enforcement_engine": self._enforcement_engine is not None,
            "orchestrator": self.routing_orchestrator.to_dict(),
        }
