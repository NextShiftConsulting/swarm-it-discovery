"""
Advanced Defense Layers for Routing.

Provides additional defense mechanisms beyond Oobleck:
    - Goal Anchor: Integrity checking for goal drift
    - Semantic Normalizer: Canonicalization and schema validation
    - Rate Limiter: Token bucket with backpressure
    - Metric Smoothing: EMA, TTL, outlier rejection
    - Sybil Detector: Agent fingerprinting and clustering
    - Manager Redundancy: Failover and watchdog

Example:
    defenses = DefenseStack()
    defenses.check_goal_integrity(current_goal, original_goal)
    defenses.normalize_semantic(payload)
    defenses.allow_request(agent_id)
"""

from __future__ import annotations

import hashlib
import logging
import time
import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple, Set, TYPE_CHECKING
from enum import Enum, auto

if TYPE_CHECKING:
    from yrsn.core.certificate import YRSNCertificate


logger = logging.getLogger(__name__)


# =============================================================================
# Layer 1: Goal Anchor
# =============================================================================

@dataclass(frozen=True)
class GoalIntegrityResult:
    """Result of goal integrity check."""
    valid: bool
    drift_score: float  # 0 = identical, 1 = completely different
    original_hash: str
    current_hash: str
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "drift_score": self.drift_score,
            "original_hash": self.original_hash[:16],
            "current_hash": self.current_hash[:16],
            "rationale": self.rationale,
        }


class GoalAnchor:
    """
    Detects goal drift mid-execution.

    Snapshots the goal at task start and validates each round
    that the goal hasn't been modified.
    """

    def __init__(self, max_drift: float = 0.1):
        """
        Args:
            max_drift: Maximum allowed drift score (0-1)
        """
        self.max_drift = max_drift
        self._original_goal: Optional[str] = None
        self._original_hash: Optional[str] = None
        self._original_tokens: Optional[Set[str]] = None

    def anchor(self, goal: str) -> str:
        """Anchor the original goal. Returns hash."""
        self._original_goal = goal
        self._original_hash = hashlib.sha256(goal.encode()).hexdigest()
        self._original_tokens = set(goal.lower().split())
        logger.debug(f"Goal anchored: {self._original_hash[:16]}")
        return self._original_hash

    def check(self, current_goal: str) -> GoalIntegrityResult:
        """Check if current goal matches anchored goal."""
        if self._original_goal is None:
            return GoalIntegrityResult(
                valid=True,
                drift_score=0.0,
                original_hash="",
                current_hash="",
                rationale="No anchor set",
            )

        current_hash = hashlib.sha256(current_goal.encode()).hexdigest()

        # Exact match
        if current_hash == self._original_hash:
            return GoalIntegrityResult(
                valid=True,
                drift_score=0.0,
                original_hash=self._original_hash,
                current_hash=current_hash,
                rationale="Exact match",
            )

        # Calculate drift via token overlap (Jaccard similarity)
        current_tokens = set(current_goal.lower().split())
        intersection = self._original_tokens & current_tokens
        union = self._original_tokens | current_tokens
        similarity = len(intersection) / max(len(union), 1)
        drift_score = 1.0 - similarity

        valid = drift_score <= self.max_drift

        return GoalIntegrityResult(
            valid=valid,
            drift_score=drift_score,
            original_hash=self._original_hash,
            current_hash=current_hash,
            rationale=f"Drift={drift_score:.2f}, max={self.max_drift}",
        )

    def reset(self) -> None:
        """Reset anchor for new task."""
        self._original_goal = None
        self._original_hash = None
        self._original_tokens = None


# =============================================================================
# Layer 2: Semantic Normalizer
# =============================================================================

@dataclass(frozen=True)
class NormalizationResult:
    """Result of semantic normalization."""
    normalized: str
    valid_schema: bool
    aliases_detected: int
    transformations: Tuple[str, ...]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "normalized_length": len(self.normalized),
            "valid_schema": self.valid_schema,
            "aliases_detected": self.aliases_detected,
            "transformations": list(self.transformations),
        }


class SemanticNormalizer:
    """
    Normalizes representations to canonical form.

    Detects semantic aliasing and validates schemas.
    """

    # Common aliases to normalize
    ALIASES = {
        # Whitespace variants
        "\t": " ",
        "\r\n": "\n",
        "\r": "\n",
        # Unicode normalization
        "\u00a0": " ",  # Non-breaking space
        "\u2018": "'",  # Left single quote
        "\u2019": "'",  # Right single quote
        "\u201c": '"',  # Left double quote
        "\u201d": '"',  # Right double quote
        # Common semantic aliases
        "cannot": "can not",
        "don't": "do not",
        "doesn't": "does not",
        "won't": "will not",
    }

    REQUIRED_FIELDS = {"prompt", "task_id"}  # Minimal schema

    def __init__(self, strict_schema: bool = False):
        self.strict_schema = strict_schema

    def normalize(self, content: str) -> NormalizationResult:
        """Normalize content to canonical form."""
        normalized = content
        transformations = []
        aliases_detected = 0

        # Apply alias normalization
        for alias, canonical in self.ALIASES.items():
            if alias in normalized:
                count = normalized.count(alias)
                normalized = normalized.replace(alias, canonical)
                aliases_detected += count
                transformations.append(f"{alias!r}->{canonical!r}")

        # Collapse multiple spaces
        while "  " in normalized:
            normalized = normalized.replace("  ", " ")
            transformations.append("collapse_spaces")

        # Strip
        normalized = normalized.strip()

        return NormalizationResult(
            normalized=normalized,
            valid_schema=True,  # Text always valid
            aliases_detected=aliases_detected,
            transformations=tuple(transformations),
        )

    def validate_payload(self, payload: Dict[str, Any]) -> NormalizationResult:
        """Validate payload against schema."""
        transformations = []
        valid = True

        if self.strict_schema:
            missing = self.REQUIRED_FIELDS - set(payload.keys())
            if missing:
                valid = False
                transformations.append(f"missing_fields:{missing}")

        # Check for suspicious keys
        for key in payload.keys():
            if "__" in key or key.startswith("_"):
                transformations.append(f"suspicious_key:{key}")

        return NormalizationResult(
            normalized=str(payload),
            valid_schema=valid,
            aliases_detected=0,
            transformations=tuple(transformations),
        )


# =============================================================================
# Layer 3: Rate Limiter
# =============================================================================

@dataclass
class RateLimitResult:
    """Result of rate limit check."""
    allowed: bool
    tokens_remaining: float
    wait_time_ms: float
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "allowed": self.allowed,
            "tokens_remaining": self.tokens_remaining,
            "wait_time_ms": self.wait_time_ms,
            "rationale": self.rationale,
        }


class TokenBucketLimiter:
    """
    Token bucket rate limiter with backpressure.

    Each agent has a bucket that refills over time.
    Requests consume tokens; denied if bucket empty.
    """

    def __init__(
        self,
        tokens_per_second: float = 10.0,
        bucket_size: float = 50.0,
        backpressure_threshold: float = 0.2,
    ):
        self.tokens_per_second = tokens_per_second
        self.bucket_size = bucket_size
        self.backpressure_threshold = backpressure_threshold

        self._buckets: Dict[str, float] = defaultdict(lambda: bucket_size)
        self._last_refill: Dict[str, float] = {}
        self._total_requests = 0
        self._denied_requests = 0

    def allow(self, agent_id: str, tokens: float = 1.0) -> RateLimitResult:
        """Check if request is allowed."""
        now = time.time()
        self._total_requests += 1

        # Refill bucket
        if agent_id in self._last_refill:
            elapsed = now - self._last_refill[agent_id]
            refill = elapsed * self.tokens_per_second
            self._buckets[agent_id] = min(
                self.bucket_size,
                self._buckets[agent_id] + refill
            )
        self._last_refill[agent_id] = now

        current = self._buckets[agent_id]

        # Check backpressure
        if current / self.bucket_size < self.backpressure_threshold:
            wait_time = (tokens - current) / self.tokens_per_second * 1000
            self._denied_requests += 1
            return RateLimitResult(
                allowed=False,
                tokens_remaining=current,
                wait_time_ms=wait_time,
                rationale=f"Backpressure: {current:.1f}/{self.bucket_size} tokens",
            )

        # Consume tokens
        if current >= tokens:
            self._buckets[agent_id] -= tokens
            return RateLimitResult(
                allowed=True,
                tokens_remaining=self._buckets[agent_id],
                wait_time_ms=0,
                rationale="OK",
            )

        # Insufficient tokens
        wait_time = (tokens - current) / self.tokens_per_second * 1000
        self._denied_requests += 1
        return RateLimitResult(
            allowed=False,
            tokens_remaining=current,
            wait_time_ms=wait_time,
            rationale=f"Insufficient: need {tokens}, have {current:.1f}",
        )

    def get_stats(self) -> Dict[str, Any]:
        """Get rate limiter statistics."""
        return {
            "total_requests": self._total_requests,
            "denied_requests": self._denied_requests,
            "denial_rate": self._denied_requests / max(1, self._total_requests),
            "active_buckets": len(self._buckets),
        }

    def reset(self, agent_id: Optional[str] = None) -> None:
        """Reset bucket(s)."""
        if agent_id:
            self._buckets[agent_id] = self.bucket_size
        else:
            self._buckets.clear()
            self._last_refill.clear()


# =============================================================================
# Layer 4: Metric Smoothing
# =============================================================================

@dataclass
class SmoothedMetric:
    """Smoothed metric value with confidence."""
    value: float
    raw_value: float
    confidence: float  # 0-1, lower if stale/noisy
    is_outlier: bool
    age_seconds: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "raw_value": self.raw_value,
            "confidence": self.confidence,
            "is_outlier": self.is_outlier,
            "age_seconds": self.age_seconds,
        }


class MetricSmoother:
    """
    Smooths metrics using EMA with outlier rejection.

    Provides:
        - Exponential moving average
        - TTL-based staleness detection
        - Median-based outlier rejection
        - Decay rate limiting
    """

    def __init__(
        self,
        alpha: float = 0.3,  # EMA weight for new values
        ttl_seconds: float = 60.0,
        outlier_threshold: float = 3.0,  # Standard deviations
        max_decay_per_second: float = 0.1,
        history_size: int = 10,
    ):
        self.alpha = alpha
        self.ttl_seconds = ttl_seconds
        self.outlier_threshold = outlier_threshold
        self.max_decay_per_second = max_decay_per_second
        self.history_size = history_size

        self._values: Dict[str, float] = {}
        self._history: Dict[str, List[float]] = defaultdict(list)
        self._timestamps: Dict[str, float] = {}

    def update(self, key: str, raw_value: float) -> SmoothedMetric:
        """Update metric with new value."""
        now = time.time()

        # Check staleness
        age = 0.0
        if key in self._timestamps:
            age = now - self._timestamps[key]

        # Detect outlier
        is_outlier = False
        if key in self._history and len(self._history[key]) >= 3:
            hist = self._history[key]
            median = statistics.median(hist)
            try:
                stdev = statistics.stdev(hist)
                if stdev > 0 and abs(raw_value - median) > self.outlier_threshold * stdev:
                    is_outlier = True
            except statistics.StatisticsError:
                pass

        # Apply EMA (ignore outliers)
        if key not in self._values:
            smoothed = raw_value
        elif is_outlier:
            smoothed = self._values[key]  # Keep old value
        else:
            # Limit decay rate
            old_value = self._values[key]
            change = raw_value - old_value
            max_change = self.max_decay_per_second * max(age, 0.1)
            if abs(change) > max_change:
                change = max_change if change > 0 else -max_change
            smoothed = old_value + self.alpha * change

        # Update state
        self._values[key] = smoothed
        self._timestamps[key] = now
        if not is_outlier:
            self._history[key].append(raw_value)
            if len(self._history[key]) > self.history_size:
                self._history[key].pop(0)

        # Calculate confidence
        confidence = 1.0
        if age > self.ttl_seconds:
            confidence *= 0.5  # Stale
        if is_outlier:
            confidence *= 0.3  # Outlier

        return SmoothedMetric(
            value=smoothed,
            raw_value=raw_value,
            confidence=confidence,
            is_outlier=is_outlier,
            age_seconds=age,
        )

    def get(self, key: str) -> Optional[SmoothedMetric]:
        """Get current smoothed value."""
        if key not in self._values:
            return None

        now = time.time()
        age = now - self._timestamps.get(key, now)
        confidence = 1.0 if age <= self.ttl_seconds else 0.5

        return SmoothedMetric(
            value=self._values[key],
            raw_value=self._values[key],
            confidence=confidence,
            is_outlier=False,
            age_seconds=age,
        )

    def reset(self, key: Optional[str] = None) -> None:
        """Reset smoother."""
        if key:
            self._values.pop(key, None)
            self._history.pop(key, None)
            self._timestamps.pop(key, None)
        else:
            self._values.clear()
            self._history.clear()
            self._timestamps.clear()


# =============================================================================
# Layer 5: Sybil Detector
# =============================================================================

@dataclass(frozen=True)
class SybilCheckResult:
    """Result of Sybil detection."""
    is_sybil: bool
    cluster_id: Optional[int]
    similarity_score: float
    similar_agents: Tuple[str, ...]
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_sybil": self.is_sybil,
            "cluster_id": self.cluster_id,
            "similarity_score": self.similarity_score,
            "similar_agents": list(self.similar_agents),
            "rationale": self.rationale,
        }


class SybilDetector:
    """
    Detects Sybil attacks via behavioral fingerprinting.

    Tracks agent response patterns and clusters similar agents.
    Flags agents that appear to be clones.
    """

    def __init__(
        self,
        similarity_threshold: float = 0.9,
        min_samples: int = 3,
        max_cluster_size: int = 3,
    ):
        self.similarity_threshold = similarity_threshold
        self.min_samples = min_samples
        self.max_cluster_size = max_cluster_size

        self._fingerprints: Dict[str, List[str]] = defaultdict(list)
        self._clusters: Dict[str, int] = {}
        self._next_cluster_id = 0

    def record(self, agent_id: str, response: str) -> None:
        """Record agent response for fingerprinting."""
        # Simple fingerprint: normalized response tokens
        tokens = response.lower().split()[:20]  # First 20 tokens
        fingerprint = " ".join(sorted(set(tokens)))
        self._fingerprints[agent_id].append(fingerprint)

        # Keep limited history
        if len(self._fingerprints[agent_id]) > 10:
            self._fingerprints[agent_id].pop(0)

    def check(self, agent_id: str) -> SybilCheckResult:
        """Check if agent appears to be a Sybil."""
        if agent_id not in self._fingerprints:
            return SybilCheckResult(
                is_sybil=False,
                cluster_id=None,
                similarity_score=0.0,
                similar_agents=(),
                rationale="No fingerprint data",
            )

        if len(self._fingerprints[agent_id]) < self.min_samples:
            return SybilCheckResult(
                is_sybil=False,
                cluster_id=None,
                similarity_score=0.0,
                similar_agents=(),
                rationale=f"Insufficient samples: {len(self._fingerprints[agent_id])}/{self.min_samples}",
            )

        # Compare with other agents
        my_prints = set(self._fingerprints[agent_id])
        similar_agents = []
        max_similarity = 0.0

        for other_id, other_prints in self._fingerprints.items():
            if other_id == agent_id:
                continue

            other_set = set(other_prints)
            intersection = my_prints & other_set
            union = my_prints | other_set
            similarity = len(intersection) / max(len(union), 1)

            if similarity >= self.similarity_threshold:
                similar_agents.append(other_id)
                max_similarity = max(max_similarity, similarity)

        is_sybil = len(similar_agents) >= self.max_cluster_size - 1

        # Assign cluster
        cluster_id = None
        if is_sybil:
            if agent_id in self._clusters:
                cluster_id = self._clusters[agent_id]
            else:
                cluster_id = self._next_cluster_id
                self._next_cluster_id += 1
                self._clusters[agent_id] = cluster_id
                for other in similar_agents:
                    self._clusters[other] = cluster_id

        return SybilCheckResult(
            is_sybil=is_sybil,
            cluster_id=cluster_id,
            similarity_score=max_similarity,
            similar_agents=tuple(similar_agents[:5]),
            rationale=f"Similar to {len(similar_agents)} agents" if similar_agents else "Unique",
        )

    def reset(self) -> None:
        """Reset detector."""
        self._fingerprints.clear()
        self._clusters.clear()
        self._next_cluster_id = 0


# =============================================================================
# Layer 6: Amplification Detector
# =============================================================================

@dataclass(frozen=True)
class AmplificationCheckResult:
    """Result of amplification detection."""
    is_runaway: bool
    is_feedback_loop: bool
    is_damping_failure: bool
    amplification_score: float  # 0 = stable, 1 = runaway
    trend: str  # "stable", "growing", "runaway"
    max_value: float
    growth_rate: float
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_runaway": self.is_runaway,
            "is_feedback_loop": self.is_feedback_loop,
            "is_damping_failure": self.is_damping_failure,
            "amplification_score": self.amplification_score,
            "trend": self.trend,
            "max_value": self.max_value,
            "growth_rate": self.growth_rate,
            "rationale": self.rationale,
        }


class AmplificationDetector:
    """
    Detects runaway amplification and feedback loops.

    Tracks metric values over time and detects:
        - Runaway growth (values exceeding bounds)
        - Feedback loops (oscillating or growing patterns)
        - Damping failures (unable to stabilize)
    """

    def __init__(
        self,
        runaway_threshold: float = 1.2,
        growth_rate_threshold: float = 0.1,
        oscillation_threshold: int = 3,
        window_size: int = 10,
    ):
        """
        Args:
            runaway_threshold: Value above which runaway is detected
            growth_rate_threshold: Growth rate above which amplification detected
            oscillation_threshold: Number of direction changes for feedback loop
            window_size: Number of values to track
        """
        self.runaway_threshold = runaway_threshold
        self.growth_rate_threshold = growth_rate_threshold
        self.oscillation_threshold = oscillation_threshold
        self.window_size = window_size

        self._history: Dict[str, List[float]] = defaultdict(list)
        self._timestamps: Dict[str, List[float]] = defaultdict(list)

    def record(self, metric_name: str, value: float) -> None:
        """Record a metric value."""
        self._history[metric_name].append(value)
        self._timestamps[metric_name].append(time.time())

        # Keep window bounded
        if len(self._history[metric_name]) > self.window_size:
            self._history[metric_name].pop(0)
            self._timestamps[metric_name].pop(0)

    def check(self, metric_name: str) -> AmplificationCheckResult:
        """Check for amplification on a specific metric."""
        history = self._history.get(metric_name, [])

        if len(history) < 3:
            return AmplificationCheckResult(
                is_runaway=False,
                is_feedback_loop=False,
                is_damping_failure=False,
                amplification_score=0.0,
                trend="stable",
                max_value=max(history) if history else 0.0,
                growth_rate=0.0,
                rationale="Insufficient history",
            )

        # Calculate metrics
        max_value = max(history)
        min_value = min(history)
        avg_value = sum(history) / len(history)

        # Growth rate: compare recent to earlier values
        mid = len(history) // 2
        early_avg = sum(history[:mid]) / mid if mid > 0 else history[0]
        late_avg = sum(history[mid:]) / (len(history) - mid)
        growth_rate = (late_avg - early_avg) / max(abs(early_avg), 0.001)

        # Detect runaway
        is_runaway = max_value > self.runaway_threshold

        # Detect feedback loop (oscillations)
        direction_changes = 0
        for i in range(2, len(history)):
            prev_dir = history[i-1] - history[i-2]
            curr_dir = history[i] - history[i-1]
            if prev_dir * curr_dir < 0:  # Direction changed
                direction_changes += 1
        is_feedback_loop = direction_changes >= self.oscillation_threshold

        # Detect damping failure (consistent growth without stabilization)
        is_damping_failure = (
            growth_rate > self.growth_rate_threshold and
            len(history) >= self.window_size // 2
        )

        # Calculate amplification score
        amplification_score = min(1.0, max(
            max_value / self.runaway_threshold if self.runaway_threshold > 0 else 0,
            abs(growth_rate),
            direction_changes / max(self.oscillation_threshold, 1),
        ))

        # Determine trend
        if is_runaway:
            trend = "runaway"
        elif growth_rate > self.growth_rate_threshold:
            trend = "growing"
        elif is_feedback_loop:
            trend = "oscillating"
        else:
            trend = "stable"

        return AmplificationCheckResult(
            is_runaway=is_runaway,
            is_feedback_loop=is_feedback_loop,
            is_damping_failure=is_damping_failure,
            amplification_score=amplification_score,
            trend=trend,
            max_value=max_value,
            growth_rate=growth_rate,
            rationale=f"max={max_value:.3f}, growth={growth_rate:.3f}, oscillations={direction_changes}",
        )

    def check_all(self) -> Dict[str, AmplificationCheckResult]:
        """Check all tracked metrics."""
        return {name: self.check(name) for name in self._history}

    def reset(self, metric_name: Optional[str] = None) -> None:
        """Reset detector state."""
        if metric_name:
            self._history.pop(metric_name, None)
            self._timestamps.pop(metric_name, None)
        else:
            self._history.clear()
            self._timestamps.clear()


# =============================================================================
# Layer 7: Quality Decay Detector
# =============================================================================

@dataclass(frozen=True)
class QualityDecayCheckResult:
    """Result of quality decay detection."""
    is_decaying: bool
    decay_rate: float  # Negative = decay, positive = improvement
    current_quality: float
    initial_quality: float
    decay_score: float  # 0 = stable, 1 = severe decay
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_decaying": self.is_decaying,
            "decay_rate": self.decay_rate,
            "current_quality": self.current_quality,
            "initial_quality": self.initial_quality,
            "decay_score": self.decay_score,
            "rationale": self.rationale,
        }


class QualityDecayDetector:
    """
    Detects quality decay in agents over time.

    Tracks agent quality and detects:
        - Gradual quality decay
        - Sudden quality drops
        - Capability degradation
    """

    def __init__(
        self,
        decay_threshold: float = -0.05,
        sudden_drop_threshold: float = -0.2,
        window_size: int = 10,
    ):
        """
        Args:
            decay_threshold: Rate below which decay is detected
            sudden_drop_threshold: Single-step drop threshold
            window_size: Number of readings to track
        """
        self.decay_threshold = decay_threshold
        self.sudden_drop_threshold = sudden_drop_threshold
        self.window_size = window_size

        self._quality_history: Dict[str, List[float]] = defaultdict(list)
        self._initial_quality: Dict[str, float] = {}

    def record(self, agent_id: str, quality: float) -> None:
        """Record an agent's quality."""
        if agent_id not in self._initial_quality:
            self._initial_quality[agent_id] = quality

        self._quality_history[agent_id].append(quality)

        if len(self._quality_history[agent_id]) > self.window_size:
            self._quality_history[agent_id].pop(0)

    def check(self, agent_id: str) -> QualityDecayCheckResult:
        """Check for quality decay in an agent."""
        history = self._quality_history.get(agent_id, [])
        initial = self._initial_quality.get(agent_id, 1.0)

        if len(history) < 2:
            return QualityDecayCheckResult(
                is_decaying=False,
                decay_rate=0.0,
                current_quality=history[-1] if history else initial,
                initial_quality=initial,
                decay_score=0.0,
                rationale="Insufficient history",
            )

        current = history[-1]
        previous = history[-2]

        # Calculate decay rate
        total_change = current - initial
        decay_rate = total_change / max(len(history), 1)

        # Check for sudden drop
        sudden_drop = (current - previous) < self.sudden_drop_threshold

        # Check for gradual decay
        is_decaying = decay_rate < self.decay_threshold or sudden_drop

        # Calculate decay score
        if initial > 0:
            relative_decay = (initial - current) / initial
            decay_score = min(1.0, max(0.0, relative_decay))
        else:
            decay_score = 0.0

        return QualityDecayCheckResult(
            is_decaying=is_decaying,
            decay_rate=decay_rate,
            current_quality=current,
            initial_quality=initial,
            decay_score=decay_score,
            rationale=f"init={initial:.3f}, curr={current:.3f}, rate={decay_rate:.4f}",
        )

    def get_decaying_agents(self) -> List[str]:
        """Get list of agents currently experiencing decay."""
        return [
            agent_id for agent_id in self._quality_history
            if self.check(agent_id).is_decaying
        ]

    def reset(self, agent_id: Optional[str] = None) -> None:
        """Reset detector state."""
        if agent_id:
            self._quality_history.pop(agent_id, None)
            self._initial_quality.pop(agent_id, None)
        else:
            self._quality_history.clear()
            self._initial_quality.clear()


# =============================================================================
# Layer 8: Starvation Detector
# =============================================================================

@dataclass(frozen=True)
class StarvationCheckResult:
    """Result of starvation detection."""
    is_starving: bool
    starvation_score: float  # 0 = healthy, 1 = completely starved
    consecutive_failures: int
    failure_rate: float
    affected_capabilities: Tuple[str, ...]
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_starving": self.is_starving,
            "starvation_score": self.starvation_score,
            "consecutive_failures": self.consecutive_failures,
            "failure_rate": self.failure_rate,
            "affected_capabilities": list(self.affected_capabilities),
            "rationale": self.rationale,
        }


class StarvationDetector:
    """
    Detects relevance starvation in routing.

    Tracks routing failures and detects when agents consistently
    cannot find suitable matches - a key attack pattern in the
    starvation domain.

    Starvation indicators:
        - High consecutive routing failures
        - Low candidate counts
        - Specific capabilities consistently failing
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        starvation_threshold: float = 0.4,
        window_size: int = 20,
    ):
        """
        Args:
            failure_threshold: Consecutive failures before starvation alert
            starvation_threshold: Failure rate threshold (0-1)
            window_size: Number of recent routes to track
        """
        self.failure_threshold = failure_threshold
        self.starvation_threshold = starvation_threshold
        self.window_size = window_size

        self._route_history: List[Tuple[str, bool, int]] = []  # (capability, success, candidates)
        self._consecutive_failures: Dict[str, int] = defaultdict(int)
        self._capability_failures: Dict[str, int] = defaultdict(int)
        self._capability_total: Dict[str, int] = defaultdict(int)

    def record_route(
        self,
        capability: str,
        success: bool,
        candidate_count: int,
    ) -> None:
        """
        Record a routing attempt.

        Args:
            capability: The capability that was requested
            success: Whether routing found a suitable agent
            candidate_count: Number of candidates found
        """
        self._route_history.append((capability, success, candidate_count))

        # Keep window bounded
        if len(self._route_history) > self.window_size:
            self._route_history.pop(0)

        # Track per-capability stats
        self._capability_total[capability] += 1
        if not success:
            self._capability_failures[capability] += 1
            self._consecutive_failures[capability] += 1
        else:
            self._consecutive_failures[capability] = 0

    def check(self, capability: Optional[str] = None) -> StarvationCheckResult:
        """
        Check for starvation condition.

        Args:
            capability: Specific capability to check, or None for overall

        Returns:
            StarvationCheckResult with starvation status
        """
        if not self._route_history:
            return StarvationCheckResult(
                is_starving=False,
                starvation_score=0.0,
                consecutive_failures=0,
                failure_rate=0.0,
                affected_capabilities=(),
                rationale="No routing history",
            )

        # Calculate overall failure rate
        total_routes = len(self._route_history)
        failed_routes = sum(1 for _, success, _ in self._route_history if not success)
        failure_rate = failed_routes / total_routes

        # Find affected capabilities
        affected = []
        max_consecutive = 0
        for cap, consec in self._consecutive_failures.items():
            if consec >= self.failure_threshold:
                affected.append(cap)
            max_consecutive = max(max_consecutive, consec)

        # Check specific capability if provided
        if capability:
            cap_total = self._capability_total.get(capability, 0)
            cap_failures = self._capability_failures.get(capability, 0)
            cap_rate = cap_failures / max(cap_total, 1)
            consec = self._consecutive_failures.get(capability, 0)

            is_starving = (
                consec >= self.failure_threshold or
                cap_rate >= self.starvation_threshold
            )
            starvation_score = min(1.0, cap_rate + (consec / 10))

            return StarvationCheckResult(
                is_starving=is_starving,
                starvation_score=starvation_score,
                consecutive_failures=consec,
                failure_rate=cap_rate,
                affected_capabilities=(capability,) if is_starving else (),
                rationale=f"{capability}: {cap_failures}/{cap_total} failed, {consec} consecutive",
            )

        # Overall check
        is_starving = (
            max_consecutive >= self.failure_threshold or
            failure_rate >= self.starvation_threshold
        )
        starvation_score = min(1.0, failure_rate + (max_consecutive / 10))

        return StarvationCheckResult(
            is_starving=is_starving,
            starvation_score=starvation_score,
            consecutive_failures=max_consecutive,
            failure_rate=failure_rate,
            affected_capabilities=tuple(affected),
            rationale=f"Overall: {failed_routes}/{total_routes} failed, {len(affected)} capabilities affected",
        )

    def get_starving_capabilities(self) -> List[str]:
        """Get list of capabilities currently experiencing starvation."""
        return [
            cap for cap, consec in self._consecutive_failures.items()
            if consec >= self.failure_threshold
        ]

    def reset(self, capability: Optional[str] = None) -> None:
        """Reset detector state."""
        if capability:
            self._consecutive_failures[capability] = 0
            self._capability_failures[capability] = 0
            self._capability_total[capability] = 0
        else:
            self._route_history.clear()
            self._consecutive_failures.clear()
            self._capability_failures.clear()
            self._capability_total.clear()


# =============================================================================
# Layer 7: Manager Redundancy
# =============================================================================

class ManagerState(Enum):
    """Manager health state."""
    HEALTHY = auto()
    DEGRADED = auto()
    FAILED = auto()


@dataclass
class ManagerHealthResult:
    """Result of manager health check."""
    primary_state: ManagerState
    active_manager: str
    failover_occurred: bool
    watchdog_violations: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "primary_state": self.primary_state.name,
            "active_manager": self.active_manager,
            "failover_occurred": self.failover_occurred,
            "watchdog_violations": self.watchdog_violations,
        }


class RedundantManager:
    """
    Provides manager redundancy with failover.

    Maintains primary and backup managers.
    Watchdog timer detects failures.
    """

    def __init__(
        self,
        watchdog_timeout_seconds: float = 5.0,
        max_violations: int = 3,
    ):
        self.watchdog_timeout = watchdog_timeout_seconds
        self.max_violations = max_violations

        self._primary_id = "primary"
        self._backup_id = "backup"
        self._active_id = self._primary_id
        self._last_heartbeat: Dict[str, float] = {}
        self._violations: Dict[str, int] = defaultdict(int)
        self._failover_count = 0

    def heartbeat(self, manager_id: str) -> None:
        """Record manager heartbeat."""
        self._last_heartbeat[manager_id] = time.time()
        self._violations[manager_id] = 0  # Reset violations on heartbeat

    def check(self) -> ManagerHealthResult:
        """Check manager health and failover if needed."""
        now = time.time()
        failover_occurred = False

        # Check primary
        primary_age = now - self._last_heartbeat.get(self._primary_id, 0)
        if primary_age > self.watchdog_timeout:
            self._violations[self._primary_id] += 1

        primary_state = ManagerState.HEALTHY
        if self._violations[self._primary_id] > 0:
            primary_state = ManagerState.DEGRADED
        if self._violations[self._primary_id] >= self.max_violations:
            primary_state = ManagerState.FAILED

        # Failover if primary failed
        if primary_state == ManagerState.FAILED and self._active_id == self._primary_id:
            self._active_id = self._backup_id
            self._failover_count += 1
            failover_occurred = True
            logger.warning(f"Manager failover: {self._primary_id} -> {self._backup_id}")

        # Recover to primary if it's healthy again
        if primary_state == ManagerState.HEALTHY and self._active_id == self._backup_id:
            self._active_id = self._primary_id
            failover_occurred = True
            logger.info(f"Manager recovery: {self._backup_id} -> {self._primary_id}")

        return ManagerHealthResult(
            primary_state=primary_state,
            active_manager=self._active_id,
            failover_occurred=failover_occurred,
            watchdog_violations=self._violations[self._primary_id],
        )

    def is_active(self, manager_id: str) -> bool:
        """Check if manager is currently active."""
        return self._active_id == manager_id

    def reset(self) -> None:
        """Reset to primary."""
        self._active_id = self._primary_id
        self._last_heartbeat.clear()
        self._violations.clear()


# =============================================================================
# Defense Stack: Combines All Layers
# =============================================================================

@dataclass
class DefenseCheckResult:
    """Combined result from all defense layers."""
    allowed: bool
    goal_valid: bool
    schema_valid: bool
    rate_limited: bool
    is_sybil: bool
    is_starving: bool
    manager_healthy: bool
    pressure_contribution: float  # For Oobleck integration
    details: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "allowed": self.allowed,
            "goal_valid": self.goal_valid,
            "schema_valid": self.schema_valid,
            "rate_limited": self.rate_limited,
            "is_sybil": self.is_sybil,
            "is_starving": self.is_starving,
            "manager_healthy": self.manager_healthy,
            "pressure_contribution": self.pressure_contribution,
            "details": self.details,
        }


class DefenseStack:
    """
    Combines all defense layers into unified interface.

    Integrates with Oobleck via pressure_contribution.
    """

    def __init__(
        self,
        goal_max_drift: float = 0.1,
        rate_limit_tps: float = 10.0,
        sybil_threshold: float = 0.9,
        watchdog_timeout: float = 5.0,
        starvation_threshold: float = 0.4,
        runaway_threshold: float = 1.2,
        decay_threshold: float = -0.05,
    ):
        self.goal_anchor = GoalAnchor(max_drift=goal_max_drift)
        self.normalizer = SemanticNormalizer()
        self.rate_limiter = TokenBucketLimiter(tokens_per_second=rate_limit_tps)
        self.metric_smoother = MetricSmoother()
        self.sybil_detector = SybilDetector(similarity_threshold=sybil_threshold)
        self.starvation_detector = StarvationDetector(starvation_threshold=starvation_threshold)
        self.amplification_detector = AmplificationDetector(runaway_threshold=runaway_threshold)
        self.quality_decay_detector = QualityDecayDetector(decay_threshold=decay_threshold)
        self.manager = RedundantManager(watchdog_timeout_seconds=watchdog_timeout)

    def anchor_goal(self, goal: str) -> str:
        """Anchor goal at task start."""
        return self.goal_anchor.anchor(goal)

    def check_all(
        self,
        agent_id: str,
        current_goal: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        response: Optional[str] = None,
        certificate: Optional['YRSNCertificate'] = None,
    ) -> DefenseCheckResult:
        """Run all defense checks.

        Input Bridge: When certificate is provided, extracts health signals
        to adjust pressure thresholds (degraded certs = stricter defense).

        Args:
            agent_id: Identifier for the requesting agent
            current_goal: Current goal text (checked against anchor)
            payload: Request payload (validated against schema)
            response: Agent response (used for Sybil fingerprinting)
            certificate: Optional YRSNCertificate for health-aware pressure

        Returns:
            DefenseCheckResult with all defense signals and pressure_contribution
        """
        details = {}
        pressure = 0.0

        # INPUT BRIDGE: Certificate-aware pressure adjustment
        cert_health = 1.0
        cert_severity = 0.0
        if certificate is not None:
            # Extract health signals from certificate
            cert_health = getattr(certificate, 'health_score', None)
            if cert_health is None:
                # Fallback: compute from N if health_score not present
                cert_health = 1.0 - getattr(certificate, 'N', 0.0)
            cert_severity = getattr(certificate, 'severity_value', 0.0) or 0.0

            details["cert_health"] = cert_health
            details["cert_severity"] = cert_severity

            # Lower health = higher base pressure (0.0 to 0.1 range)
            pressure += (1.0 - cert_health) * 0.1

            logger.debug(
                f"Certificate-aware defense: health={cert_health:.3f}, "
                f"severity={cert_severity:.3f}, base_pressure={pressure:.3f}"
            )

        # Goal integrity (pressure adjusted by cert severity if available)
        goal_valid = True
        if current_goal:
            goal_result = self.goal_anchor.check(current_goal)
            goal_valid = goal_result.valid
            details["goal"] = goal_result.to_dict()
            if not goal_valid:
                # Higher pressure if cert already shows degradation
                goal_pressure = 0.3 + (cert_severity * 0.1)
                pressure += goal_pressure

        # Schema validation
        schema_valid = True
        if payload:
            norm_result = self.normalizer.validate_payload(payload)
            schema_valid = norm_result.valid_schema
            details["schema"] = norm_result.to_dict()
            if not schema_valid:
                pressure += 0.2

        # Rate limiting
        rate_result = self.rate_limiter.allow(agent_id)
        rate_limited = not rate_result.allowed
        details["rate_limit"] = rate_result.to_dict()
        if rate_limited:
            pressure += 0.15

        # Sybil detection
        is_sybil = False
        if response:
            self.sybil_detector.record(agent_id, response)
            sybil_result = self.sybil_detector.check(agent_id)
            is_sybil = sybil_result.is_sybil
            details["sybil"] = sybil_result.to_dict()
            if is_sybil:
                pressure += 0.25

        # Starvation detection (check overall)
        starvation_result = self.starvation_detector.check()
        is_starving = starvation_result.is_starving
        details["starvation"] = starvation_result.to_dict()
        if is_starving:
            pressure += 0.2

        # Manager health
        self.manager.heartbeat("primary")  # Simulate heartbeat
        manager_result = self.manager.check()
        manager_healthy = manager_result.primary_state != ManagerState.FAILED
        details["manager"] = manager_result.to_dict()
        if not manager_healthy:
            pressure += 0.2

        # Determine if request allowed
        allowed = goal_valid and schema_valid and not rate_limited and not is_sybil

        return DefenseCheckResult(
            allowed=allowed,
            goal_valid=goal_valid,
            schema_valid=schema_valid,
            rate_limited=rate_limited,
            is_sybil=is_sybil,
            is_starving=is_starving,
            manager_healthy=manager_healthy,
            pressure_contribution=min(1.0, pressure),
            details=details,
        )

    def smooth_metric(self, key: str, value: float) -> SmoothedMetric:
        """Smooth a metric value."""
        return self.metric_smoother.update(key, value)

    def record_route(
        self,
        capability: str,
        success: bool,
        candidate_count: int,
    ) -> None:
        """
        Record a routing attempt for starvation detection.

        Args:
            capability: The capability that was requested
            success: Whether routing found a suitable agent
            candidate_count: Number of candidates found
        """
        self.starvation_detector.record_route(capability, success, candidate_count)

    def check_starvation(self, capability: Optional[str] = None) -> StarvationCheckResult:
        """
        Check for starvation condition.

        Args:
            capability: Specific capability to check, or None for overall

        Returns:
            StarvationCheckResult with starvation status
        """
        return self.starvation_detector.check(capability)

    def record_metric(self, metric_name: str, value: float) -> None:
        """Record a metric for amplification detection."""
        self.amplification_detector.record(metric_name, value)

    def check_amplification(self, metric_name: str) -> AmplificationCheckResult:
        """Check for amplification on a metric."""
        return self.amplification_detector.check(metric_name)

    def record_quality(self, agent_id: str, quality: float) -> None:
        """Record agent quality for decay detection."""
        self.quality_decay_detector.record(agent_id, quality)

    def check_quality_decay(self, agent_id: str) -> QualityDecayCheckResult:
        """Check for quality decay in an agent."""
        return self.quality_decay_detector.check(agent_id)

    def reset(self) -> None:
        """Reset all defense layers."""
        self.goal_anchor.reset()
        self.rate_limiter.reset()
        self.metric_smoother.reset()
        self.sybil_detector.reset()
        self.starvation_detector.reset()
        self.amplification_detector.reset()
        self.quality_decay_detector.reset()
        self.manager.reset()

    def to_dict(self) -> Dict[str, Any]:
        """Export defense stack state."""
        return {
            "rate_limiter": self.rate_limiter.get_stats(),
        }
