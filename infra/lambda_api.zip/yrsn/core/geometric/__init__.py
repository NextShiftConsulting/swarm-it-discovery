"""
Geometric Algebra Toolkit for YRSN/RSCT

IMPORTANT: This module has four distinct parts with different scope:

1. primitives/ - SUBSTRATE-INDEPENDENT (works on ANY AI system)
   - bivector, trivector, cayley, rotor, subspace
   - Use for: LLMs, Vision, Quantum, Robotics, Neuromorphic, etc.

2. detectors/ - MODALITY-AGNOSTIC (generic implementations) ✨ NEW
   - Sequential coherence (Generic Type V)
   - Domain mismatch (Generic Type VI)
   - Turbulence metric (Generic σ)
   - Works on: Text, Vision, Audio, Sensor, Multi-modal

3. llm_validation/ - LLM-SPECIFIC (text outputs only)
   - Type I-VI detectors (LLM-centric wrappers)
   - Use for: Post-execution validation of LLM outputs ONLY
   - Wraps generic detectors with text-specific APIs

4. financial/ - DOMAIN EXAMPLES (financial applications)
   - yield_curve.py: Term structure analysis
   - Demonstrates GA primitives on real-world financial data

Source Attribution:
- https://substack.com/@agussudjianto
- Papers: SSRN 6101568 (RoRA), SSRN 5995254 (GIFT)

Usage:
======

Universal (any AI system):
    from yrsn.core.geometric.primitives import (
        bivector_norm,      # σ (turbulence)
        CayleySteering,     # α (purity)
        LowRankRotorLayer,  # RoRA
        subspace_support,   # ω (OOD)
    )

Generic detectors (modality-agnostic):
    from yrsn.core.geometric.detectors import (
        SequentialCoherenceDetector,  # Works on any embeddings
        DomainMismatchDetector,        # Works on any domains
        compute_turbulence,            # Works on any trajectories
        analyze_llm_reasoning,         # Text wrapper
        analyze_visual_reasoning,      # Vision wrapper
    )

LLM-specific (backward compatible):
    from yrsn.core.geometric.llm_validation import (
        TypeIGroundednessDetector,   # Unsupported claims
        TypeIIContradictionDetector, # Contradictions
        TypeVReasoningDetector,      # Reasoning coherence (wraps SequentialCoherence)
        TypeVIDetector,              # Domain mismatch (wraps DomainMismatch)
    )

Financial domain examples:
    from yrsn.core.geometric.financial import (
        YieldCurveAnalyzer,  # Term structure
        decompose_curve,     # L/S/C decomposition
    )
"""

# Re-export primitives (universal)
from .primitives import (
    # Bivector
    bivector_norm,
    bivector_angle,
    wedge_product_matrix,
    bivector_inner_product,
    # Trivector
    trivector_volume,
    trajectory_coplanarity,
    detect_topic_jumps,
    # Cayley
    CayleySteering,
    # Rotor
    RotorLayer,
    LowRankRotorLayer,
    check_rotor_capacity,
    # Subspace
    orthonormal_basis,
    subspace_support,
    DomainBases,
)

# Re-export generic detectors (modality-agnostic)
from .detectors import (
    # Sequential Coherence (Generic Type V)
    SequentialCoherenceDetector,
    SequentialAnalysis,
    analyze_llm_reasoning,
    analyze_visual_reasoning,
    analyze_sensor_trajectory,
    # Domain Mismatch (Generic Type VI)
    DomainMismatchDetector,
    DomainAnalysis,
    create_text_domain_detector,
    create_visual_domain_detector,
    # Turbulence (Generic σ)
    compute_turbulence,
    compute_turbulence_profile,
)

# Re-export financial domain examples
from .financial import (
    YieldCurveAnalyzer,
    decompose_curve,
    get_basis_vectors,
)

# Re-export LLM validation (LLM-specific)
from .llm_validation import (
    TypeIGroundednessDetector,
    compute_groundedness_score,
    TypeIIContradictionDetector,
    TypeIIIInversionDetector,
    TypeIVDetector,
    compute_drift,
    TypeVReasoningDetector,
    TypeVIDetector,
    create_mrm_detector,
)

__all__ = [
    # =========================================================================
    # PRIMITIVES (Substrate-Independent - works on ANY AI system)
    # =========================================================================
    # Bivector
    'bivector_norm',
    'bivector_angle',
    'wedge_product_matrix',
    'bivector_inner_product',
    # Trivector
    'trivector_volume',
    'trajectory_coplanarity',
    'detect_topic_jumps',
    # Cayley
    'CayleySteering',
    # Rotor
    'RotorLayer',
    'LowRankRotorLayer',
    'check_rotor_capacity',
    # Subspace
    'orthonormal_basis',
    'subspace_support',
    'DomainBases',

    # =========================================================================
    # GENERIC DETECTORS (Modality-Agnostic)
    # =========================================================================
    # Sequential Coherence (Generic Type V)
    'SequentialCoherenceDetector',
    'SequentialAnalysis',
    'analyze_llm_reasoning',
    'analyze_visual_reasoning',
    'analyze_sensor_trajectory',
    # Domain Mismatch (Generic Type VI)
    'DomainMismatchDetector',
    'DomainAnalysis',
    'create_text_domain_detector',
    'create_visual_domain_detector',
    # Turbulence (Generic σ)
    'compute_turbulence',
    'compute_turbulence_profile',

    # =========================================================================
    # FINANCIAL (Domain Examples)
    # =========================================================================
    'YieldCurveAnalyzer',
    'decompose_curve',
    'get_basis_vectors',

    # =========================================================================
    # LLM VALIDATION (LLM-Specific - text outputs only)
    # =========================================================================
    'TypeIGroundednessDetector',
    'compute_groundedness_score',
    'TypeIIContradictionDetector',
    'TypeIIIInversionDetector',
    'TypeIVDetector',
    'compute_drift',
    'TypeVReasoningDetector',
    'TypeVIDetector',
    'create_mrm_detector',
]
