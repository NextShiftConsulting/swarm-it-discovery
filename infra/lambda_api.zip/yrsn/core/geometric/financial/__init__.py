"""
Financial Domain Examples for Geometric Algebra

Domain-specific applications of GA primitives to financial use cases.
These demonstrate how the substrate-independent primitives apply to
real-world financial modeling.

Contents:
- yield_curve.py: Term structure analysis (Level/Slope/Curvature)
    Uses axiomatic basis (stable, not learned like PCA)
    Rotor dynamics predict curve momentum

RSCT Parallels:
- Level/Slope/Curvature ↔ R/S/N (fixed axiomatic basis)
- Rotor angular velocity ↔ σ (turbulence/instability)
- VIX-forced curvature ↔ Environmental shocks

Source: Sudjianto, "Yield Curve Analysis with Geometric Algebra"
"""

from .yield_curve import (
    YieldCurveAnalyzer,
    decompose_curve,
    reconstruct_curve,
    get_basis_vectors,
    compute_rotor_dynamics,
    CurveState,
)

__all__ = [
    'YieldCurveAnalyzer',
    'decompose_curve',
    'reconstruct_curve',
    'get_basis_vectors',
    'compute_rotor_dynamics',
    'CurveState',
]
