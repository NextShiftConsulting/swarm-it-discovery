"""
Yield Curve Analysis with Geometric Algebra

Treats the yield curve as a vector in R³ (3M, 5Y, 10Y) and decomposes
it into geometric grades:
- Grade 0: Level (center of mass)
- Grade 1: Slope (first derivative)
- Grade 2: Curvature (second derivative / butterfly)

The rotor dynamics (angular velocity ω) predict curve momentum.

RSCT APPLICATION:
-----------------
This demonstrates GA on financial time series, NOT LLM outputs.
However, the geometric principles apply:

1. Axiomatic basis (Level/Slope/Curvature) is STABLE - doesn't drift
   like PCA factors. This parallels RSCT's stable RSN simplex.

2. Rotor velocity ω predicts momentum. This parallels RSCT's σ
   (turbulence) as a predictor of instability.

3. VIX-forced curvature models external shocks. This parallels
   how RSCT gates respond to environmental changes.

Source: Sudjianto, "Yield Curve Analysis with Geometric Algebra"
"""

import torch
import numpy as np
from typing import Tuple, Optional, Dict
from dataclasses import dataclass


# Axiomatic basis vectors (constants, never learned)
# These are the "physics" of the curve, not statistical artifacts

def get_basis_vectors() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Get the orthonormal geometric basis for yield curve analysis.

    Returns:
        (u0, u1, u2): Level, Slope, Curvature unit vectors

    The basis is:
    - u0 = [1, 1, 1] / sqrt(3)     # Level (parallel shift)
    - u1 = [-1, 0, 1] / sqrt(2)    # Slope (tilt)
    - u2 = [1, -2, 1] / sqrt(6)    # Curvature (butterfly)

    RSCT Parallel:
        Like RSN simplex, these are AXIOMATIC - they don't change
        with market regimes. PCA factors drift; these don't.
    """
    basis_raw = np.array([
        [1, 1, 1],      # Level: Parallel Shift
        [-1, 0, 1],     # Slope: Linear Tilt (Short vs Long)
        [1, -2, 1]      # Curvature: Butterfly (Wings vs Belly)
    ])

    # Normalize to unit vectors
    basis = basis_raw / np.linalg.norm(basis_raw, axis=1, keepdims=True)

    return basis[0], basis[1], basis[2]


@dataclass
class CurveState:
    """Decomposed yield curve state."""
    level: float      # Grade 0: Center of mass
    slope: float      # Grade 1: Tilt
    curvature: float  # Grade 2: Butterfly
    theta: float      # Phase angle in Level-Slope plane
    omega: float      # Angular velocity (rotor speed)


def decompose_curve(yields: np.ndarray) -> Tuple[float, float, float]:
    """
    Project yield curve onto geometric basis.

    Args:
        yields: Array of [3M, 5Y, 10Y] yields

    Returns:
        (L, S, C): Level, Slope, Curvature coefficients

    RSCT Parallel:
        This is like RSN decomposition - projecting features onto
        a fixed orthonormal basis to get interpretable components.
    """
    u0, u1, u2 = get_basis_vectors()

    L = np.dot(yields, u0)
    S = np.dot(yields, u1)
    C = np.dot(yields, u2)

    return L, S, C


def reconstruct_curve(L: float, S: float, C: float) -> np.ndarray:
    """
    Reconstruct yield curve from geometric components.

    Args:
        L, S, C: Level, Slope, Curvature

    Returns:
        Yields array [3M, 5Y, 10Y]

    Because the basis is orthonormal, this is lossless:
        Y = L*u0 + S*u1 + C*u2
    """
    u0, u1, u2 = get_basis_vectors()
    return L * u0 + S * u1 + C * u2


def compute_rotor_dynamics(L: np.ndarray, S: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute rotor phase angle and angular velocity.

    The curve rotates in the Level-Slope plane. The angular velocity
    ω predicts momentum of the pivot.

    Args:
        L: Level time series [T]
        S: Slope time series [T]

    Returns:
        (theta, omega): Phase angles and angular velocities

    RSCT Parallel:
        ω (angular velocity) is like σ (turbulence) - it measures
        how fast the system is changing direction.

        High |ω| = high instability = high σ
    """
    # Phase angle in Level-Slope plane
    theta = np.arctan2(S, L)

    # Angular velocity (first difference)
    omega = np.diff(theta)

    return theta, omega


class YieldCurveAnalyzer:
    """
    Full geometric analyzer for yield curve dynamics.

    RSCT Integration Notes:
        This demonstrates GA on financial time series. The principles
        transfer to RSCT:

        1. Fixed basis (like RSN simplex) - doesn't drift with data
        2. Rotor dynamics (like σ) - measures instability
        3. External forcing (like environmental changes) - VIX shocks

    Example Usage:
        analyzer = YieldCurveAnalyzer()

        # Add daily observations
        for date, yields in yield_data:
            analyzer.add_observation(yields)

        # Get current state
        state = analyzer.current_state()
        print(f"Rotor velocity: {state.omega:.6f} rad/day")

        # Forecast
        forecast = analyzer.forecast_curve()
    """

    def __init__(self):
        self.history: list = []
        self.L_history: list = []
        self.S_history: list = []
        self.C_history: list = []

    def add_observation(self, yields: np.ndarray) -> CurveState:
        """
        Add a yield curve observation.

        Args:
            yields: [3M, 5Y, 10Y] yields

        Returns:
            Decomposed state
        """
        self.history.append(yields)

        L, S, C = decompose_curve(yields)
        self.L_history.append(L)
        self.S_history.append(S)
        self.C_history.append(C)

        # Compute rotor dynamics if we have history
        theta = np.arctan2(S, L)
        omega = 0.0
        if len(self.L_history) > 1:
            prev_theta = np.arctan2(self.S_history[-2], self.L_history[-2])
            omega = theta - prev_theta

        return CurveState(
            level=L,
            slope=S,
            curvature=C,
            theta=theta,
            omega=omega
        )

    def current_state(self) -> Optional[CurveState]:
        """Get the current decomposed state."""
        if not self.history:
            return None

        L = self.L_history[-1]
        S = self.S_history[-1]
        C = self.C_history[-1]

        theta = np.arctan2(S, L)
        omega = 0.0
        if len(self.L_history) > 1:
            prev_theta = np.arctan2(self.S_history[-2], self.L_history[-2])
            omega = theta - prev_theta

        return CurveState(L, S, C, theta, omega)

    def forecast_curve(self,
                       omega_forecast: Optional[float] = None,
                       c_forecast: Optional[float] = None) -> np.ndarray:
        """
        Forecast the yield curve using rotor dynamics.

        Args:
            omega_forecast: Predicted angular velocity (default: AR(1))
            c_forecast: Predicted curvature (default: current)

        Returns:
            Forecasted yields [3M, 5Y, 10Y]
        """
        if len(self.history) < 2:
            return self.history[-1] if self.history else np.zeros(3)

        state = self.current_state()

        # Default forecasts
        if omega_forecast is None:
            # Simple AR(1) on omega
            L = np.array(self.L_history)
            S = np.array(self.S_history)
            _, omega_series = compute_rotor_dynamics(L, S)
            if len(omega_series) > 1:
                # Regress omega_t on omega_{t-1}
                omega_forecast = 0.8 * omega_series[-1]  # Simple decay
            else:
                omega_forecast = 0.0

        if c_forecast is None:
            c_forecast = state.curvature

        # Apply rotor to get new angle
        theta_new = state.theta + omega_forecast

        # New slope from rotated angle
        S_new = state.level * np.tan(theta_new)

        # Reconstruct curve
        return reconstruct_curve(state.level, S_new, c_forecast)

    def stress_test(self,
                    theta_shock: float = 0.0,
                    curvature_shock: float = 1.0) -> np.ndarray:
        """
        Geometric stress test.

        Args:
            theta_shock: Rotation shock in radians (e.g., -0.05 for flattening)
            curvature_shock: Curvature multiplier (e.g., 2.0 for doubling)

        Returns:
            Stressed yield curve

        RSCT Parallel:
            Like "what if σ spikes?" - geometric stress tests show
            how the system responds to shocks.
        """
        state = self.current_state()
        if state is None:
            return np.zeros(3)

        # Apply shocks
        theta_stressed = state.theta + theta_shock
        C_stressed = state.curvature * curvature_shock

        # Recompute slope from shocked angle
        S_stressed = state.level * np.tan(theta_stressed)

        return reconstruct_curve(state.level, S_stressed, C_stressed)
