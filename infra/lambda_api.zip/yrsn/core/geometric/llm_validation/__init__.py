"""
LLM-Specific Post-Execution Validation (Type I-VI Detectors)

WARNING: These detectors work on LLM TEXT OUTPUTS ONLY.
They require sentence embeddings, NLI models, and cross-encoders.
They do NOT apply to Vision, Quantum, Robotics, or other AI systems.

For substrate-independent operations, use ../primitives/ instead.

Type Taxonomy:
- Type I: Groundedness (unsupported claims)
- Type II: Contradiction (conflicts with evidence)
- Type III: Inversion (role/entity swaps)
- Type IV: Drift (same topic, wrong relationship)
- Type V: Reasoning (trajectory coherence)
- Type VI: Domain (wrong knowledge domain)

RSCT Integration:
These detectors provide POST-EXECUTION validation that feeds back
to calibrate PRE-EXECUTION thresholds. They are the "ground truth"
for tuning RSCT gates when the solver is an LLM.

Feedback Loop:
    Type I high  → Tighten Gate 1 (N threshold)
    Type II high → Tighten Gate 4 (κ_L threshold)
    Type V high  → Tighten σ_thr
    Type VI high → Tighten ω threshold, add domain bases

Source: Sudjianto substack (Type I-VI Hallucination Detection series)
"""

from .type_i_detector import (
    TypeIGroundednessDetector,
    compute_groundedness_score,
)

from .type_ii_detector import TypeIIContradictionDetector

from .type_iii_detector import (
    TypeIIIInversionDetector,
    DEFAULT_INVERSION_EXAMPLES,
    DEFAULT_NEGATION_EXAMPLES,
)

from .type_iv_detector import (
    TypeIVDetector,
    compute_drift,
)

from .type_v_detector import (
    TypeVReasoningDetector,
    TYPE_V_TEST_SCENARIOS,
)

from .type_vi_detector import (
    TypeVIDetector,
    create_mrm_detector,
    SR117_MRM_EXEMPLARS,
    GENERAL_ML_EXEMPLARS,
)

__all__ = [
    # Type I
    'TypeIGroundednessDetector',
    'compute_groundedness_score',
    # Type II
    'TypeIIContradictionDetector',
    # Type III
    'TypeIIIInversionDetector',
    'DEFAULT_INVERSION_EXAMPLES',
    'DEFAULT_NEGATION_EXAMPLES',
    # Type IV
    'TypeIVDetector',
    'compute_drift',
    # Type V
    'TypeVReasoningDetector',
    'TYPE_V_TEST_SCENARIOS',
    # Type VI
    'TypeVIDetector',
    'create_mrm_detector',
    'SR117_MRM_EXEMPLARS',
    'GENERAL_ML_EXEMPLARS',
]
