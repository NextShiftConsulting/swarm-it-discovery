"""
Type V Detector: Reasoning Dynamics

Type V catches process failures in multi-step reasoning:
1. Context Ignoring ("Vibing") - model ignores provided evidence
2. Erratic Trajectories - topic jumps between steps
3. Gradual Drift - cumulative deviation over multiple steps

Uses Cayley steering (τ) for context influence and trivector volume
for coplanarity/topic jump detection.

RSCT APPLICATION:
-----------------
Type V maps directly to RSCT's σ (turbulence):
- High Cayley steering = Low σ (grounded, stable)
- Low Cayley steering = High σ (vibing, unstable)
- High trivector volume = Mode 2.1 (Trajectory Divergence)

This is the most comprehensive post-execution check for reasoning quality.

Source: Sudjianto, "Type V Hallucination: When LLMs Go Off the Rails"
"""

import torch
import numpy as np
from typing import Dict, List, Union, Callable, Optional, Tuple
from dataclasses import dataclass


@dataclass
class StepAnalysis:
    """Analysis of a single reasoning step."""
    step_idx: int
    text: str
    bivector_norm: float      # Rotation from previous step
    trivector_volume: float   # Out-of-plane deviation (if applicable)
    context_projection: float # How much step projects onto context
    rejection: float          # How much is orthogonal to context
    flags: List[str]


@dataclass
class TrajectoryAnalysis:
    """Full trajectory analysis."""
    score: float              # Overall Type V score [0, 1]
    is_vibing: bool           # Context ignored?
    drift_onset: int          # First problematic step (-1 if none)
    cayley_steering: float    # τ: context influence magnitude
    max_trivector: float      # Maximum topic jump
    per_step: List[StepAnalysis]
    flags: List[str]


class TypeVReasoningDetector:
    """
    Detect reasoning dynamics failures using geometric algebra.

    Three detection modes:
    1. Cayley Steering (τ): Is the model using context?
    2. Bivector Norm: How much does each step rotate from the previous?
    3. Trivector Volume: Did the trajectory leave its plane?

    RSCT Integration:
        detector = TypeVReasoningDetector(embed_fn)
        analysis = detector.analyze(context, reasoning_steps)

        # Map to RSCT metrics
        certificate.sigma = 1.0 - analysis.cayley_steering
        if analysis.max_trivector > 0.9:
            flag_mode_21_trajectory_divergence()
    """

    def __init__(self,
                 embed_fn: Callable[[str], torch.Tensor],
                 vibe_threshold: float = 0.05,
                 jump_threshold: float = 0.9,
                 drift_threshold: float = 0.7):
        """
        Initialize detector.

        Args:
            embed_fn: Function to embed text to normalized tensor
            vibe_threshold: Below this τ = vibing
            jump_threshold: Above this trivector = topic jump
            drift_threshold: Above this rejection = drift onset
        """
        self.embed_fn = embed_fn
        self.vibe_threshold = vibe_threshold
        self.jump_threshold = jump_threshold
        self.drift_threshold = drift_threshold

    def _bivector_norm(self, u: torch.Tensor, v: torch.Tensor) -> float:
        """Compute ||u ∧ v|| for normalized vectors."""
        dot = torch.dot(u, v)
        dot = torch.clamp(dot, -1.0, 1.0)
        return torch.sqrt(1.0 - dot ** 2).item()

    def _trivector_volume(self, u: torch.Tensor, v: torch.Tensor,
                          w: torch.Tensor) -> float:
        """Compute trivector volume via Gram determinant."""
        vecs = [u, v, w]
        G = torch.zeros(3, 3)
        for i in range(3):
            for j in range(3):
                G[i, j] = torch.dot(vecs[i], vecs[j])

        det = torch.det(G)
        det = torch.clamp(det, min=0.0)
        return torch.sqrt(det).item()

    def _cayley_steering(self, prior: torch.Tensor,
                         posterior: torch.Tensor) -> float:
        """Compute Cayley steering magnitude τ."""
        dot = torch.dot(prior, posterior)
        wedge = torch.outer(posterior, prior) - torch.outer(prior, posterior)
        tau = torch.norm(wedge, p='fro') / (1 + dot + 1e-10)
        return tau.item()

    def _context_projection(self, step: torch.Tensor,
                            context_basis: torch.Tensor) -> Tuple[float, float]:
        """
        Compute projection onto context subspace.

        Returns:
            (projection, rejection): How much is in/out of context space
        """
        proj = context_basis @ (context_basis.T @ step)
        proj_norm = torch.norm(proj)
        step_norm = torch.norm(step)

        if step_norm < 1e-10:
            return 0.0, 0.0

        projection = (proj_norm / step_norm).item()
        rejection = np.sqrt(max(0, 1 - projection ** 2))

        return projection, rejection

    def analyze(self,
                context: Union[str, List[str]],
                reasoning_steps: List[str],
                prior_query: Optional[str] = None) -> TrajectoryAnalysis:
        """
        Analyze a reasoning trajectory.

        Args:
            context: Evidence/context (string or list of sentences)
            reasoning_steps: List of reasoning step texts
            prior_query: Optional query-only representation for Cayley

        Returns:
            TrajectoryAnalysis with full geometric breakdown

        RSCT Usage:
            analysis = detector.analyze(context, output_steps)

            certificate.sigma = 1.0 - analysis.cayley_steering
            certificate.type_v_score = analysis.score

            if analysis.is_vibing:
                flag_mode_31_fluent_hallucination()
            if analysis.max_trivector > 0.9:
                flag_mode_21_trajectory_divergence()
        """
        # Embed context
        if isinstance(context, str):
            context = [context]

        context_embs = torch.stack([self.embed_fn(c) for c in context])
        context_basis, _ = torch.linalg.qr(context_embs.T)

        # Embed reasoning steps
        step_embs = [self.embed_fn(s) for s in reasoning_steps]

        # Compute Cayley steering if prior available
        cayley_tau = 0.0
        if prior_query is not None:
            prior_emb = self.embed_fn(prior_query)
            # Use mean of steps as posterior
            posterior = torch.stack(step_embs).mean(dim=0)
            posterior = posterior / (torch.norm(posterior) + 1e-10)
            cayley_tau = self._cayley_steering(prior_emb, posterior)
        else:
            # Estimate from context influence on first step
            if step_embs:
                proj, _ = self._context_projection(step_embs[0], context_basis)
                cayley_tau = proj  # Rough proxy

        is_vibing = cayley_tau < self.vibe_threshold

        # Analyze each step
        per_step = []
        drift_onset = -1
        max_trivector = 0.0
        flags = []

        for i, (step_text, step_emb) in enumerate(zip(reasoning_steps, step_embs)):
            step_flags = []

            # Bivector norm (rotation from previous)
            bv_norm = 0.0
            if i > 0:
                bv_norm = self._bivector_norm(step_embs[i-1], step_emb)
                if bv_norm > 0.9:
                    step_flags.append("ERRATIC_JUMP")

            # Trivector volume (out-of-plane)
            tv_vol = 0.0
            if i >= 2:
                tv_vol = self._trivector_volume(
                    step_embs[i-2], step_embs[i-1], step_emb
                )
                if tv_vol > self.jump_threshold:
                    step_flags.append("TOPIC_JUMP")
                    if tv_vol > max_trivector:
                        max_trivector = tv_vol

            # Context projection
            proj, rej = self._context_projection(step_emb, context_basis)
            if rej > self.drift_threshold and drift_onset < 0:
                drift_onset = i
                step_flags.append("DRIFT_ONSET")

            per_step.append(StepAnalysis(
                step_idx=i,
                text=step_text[:100] + "..." if len(step_text) > 100 else step_text,
                bivector_norm=bv_norm,
                trivector_volume=tv_vol,
                context_projection=proj,
                rejection=rej,
                flags=step_flags
            ))

        # Aggregate flags
        if is_vibing:
            flags.append("VIBING")
        if drift_onset >= 0:
            flags.append(f"DRIFT_AT_STEP_{drift_onset}")
        if max_trivector > self.jump_threshold:
            flags.append("TOPIC_JUMPS_DETECTED")

        # Compute overall score
        # Higher = worse reasoning
        score = 0.0
        if is_vibing:
            score += 0.4
        if drift_onset >= 0:
            score += 0.3 * (1 - drift_onset / len(reasoning_steps))
        if max_trivector > self.jump_threshold:
            score += 0.3 * max_trivector

        score = min(1.0, score)

        return TrajectoryAnalysis(
            score=score,
            is_vibing=is_vibing,
            drift_onset=drift_onset,
            cayley_steering=cayley_tau,
            max_trivector=max_trivector,
            per_step=per_step,
            flags=flags
        )


# Example test scenarios
TYPE_V_TEST_SCENARIOS = {
    "Grounded": [
        "Q3 revenue was $2.5 billion, a 15% increase from Q2.",
        "This growth was driven by strong demand in the enterprise segment.",
        "Operating margins improved to 22% due to cost discipline.",
    ],
    "Vibing (Generic)": [
        "Q3 showed strong performance across the board.",
        "Revenue growth exceeded expectations.",
        "Management remains optimistic about future prospects.",
    ],
    "Erratic Jumps": [
        "Q3 revenue was $2.5 billion.",
        "Paris is beautiful in spring.",
        "Operating margins were discussed.",
        "Bitcoin reached new highs.",
    ],
    "Gradual Drift": [
        "Q3 revenue was $2.5 billion, up 15%.",
        "This was a strong quarter for the company.",
        "The industry is evolving rapidly.",
        "Technology continues to transform society.",
    ],
}
