"""
Type III Detector: Relational Inversion

Type III catches when subject and object are swapped while keeping
the same entities and relationship type.

Example: "The hunter shot the bear" → "The bear shot the hunter"

This is distinct from:
- Type II (contradiction): "The hunter did not shoot the bear"
- Passive voice: "The bear was shot by the hunter" (SAME meaning!)

RSCT APPLICATION:
-----------------
Type III is critical for regulated domains where entity relationships
matter (financial reporting, legal documents, clinical records).

Getting the relationship BACKWARDS is a qualitatively different failure
from unsupported or contradictory claims. In SR 11-7 model risk contexts,
role inversions can reverse attribution of risk.

Source: Sudjianto, "Type III: Why Role Inversions Break Every Detector"
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional


class TypeIIIInversionDetector:
    """
    Detect role inversions using cross-encoder subspace projection.

    The challenge: inversions and negations BOTH show high contradiction
    scores. We need to separate them geometrically.

    Solution: Build separate subspaces for inversions vs negations from
    calibration examples, then classify which subspace a contradiction
    falls into.

    RSCT Integration:
        detector = TypeIIIInversionDetector(model, tokenizer)
        detector.calibrate(inversion_examples, negation_examples)

        result = detector.detect(evidence, claim)
        if result['is_inversion']:
            # Role inversion detected - critical audit flag
            certificate.type_iii_inversion = True
    """

    def __init__(self,
                 model,
                 tokenizer,
                 contradiction_threshold: float = 0.5,
                 device: str = 'cpu'):
        """
        Initialize detector.

        Args:
            model: NLI cross-encoder model
            tokenizer: Corresponding tokenizer
            contradiction_threshold: NLI P(contradiction) threshold
            device: 'cpu' or 'cuda'
        """
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.contradiction_threshold = contradiction_threshold
        self.device = device
        self.model.eval()

        self.inversion_subspace = None
        self.negation_subspace = None

    def _encode_pair(self, premise: str, hypothesis: str) -> torch.Tensor:
        """Get hidden state for premise-hypothesis pair."""
        inputs = self.tokenizer(
            premise, hypothesis,
            return_tensors="pt",
            padding=True,
            truncation=True
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model.deberta(**inputs)
            last_hidden_state = outputs.last_hidden_state

            if hasattr(self.model, 'pooler') and self.model.pooler is not None:
                h = self.model.pooler(last_hidden_state)
            else:
                h = last_hidden_state[:, 0, :]

        return h[0]

    def _get_nli_probs(self, premise: str, hypothesis: str) -> torch.Tensor:
        """Get NLI probabilities [contradiction, entailment, neutral]."""
        inputs = self.tokenizer(
            premise, hypothesis,
            return_tensors="pt",
            padding=True,
            truncation=True
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            probs = F.softmax(outputs.logits, dim=-1)

        return probs[0]

    def calibrate(self,
                  inversion_examples: List[Tuple[str, str]],
                  negation_examples: List[Tuple[str, str]]) -> None:
        """
        Build subspaces from calibration examples.

        Args:
            inversion_examples: List of (premise, inverted_hypothesis) pairs
            negation_examples: List of (premise, negated_hypothesis) pairs

        Example:
            inversions = [
                ("The hunter shot the bear", "The bear shot the hunter"),
                ("John chases the dog", "The dog chases John"),
            ]
            negations = [
                ("The hunter shot the bear", "The hunter did not shoot the bear"),
                ("John chases the dog", "John does not chase the dog"),
            ]
            detector.calibrate(inversions, negations)
        """
        # Collect hidden states for inversions
        inv_states = []
        for premise, hypothesis in inversion_examples:
            h = self._encode_pair(premise, hypothesis)
            inv_states.append(h)

        inv_matrix = torch.stack(inv_states)  # [N, d]

        # Collect hidden states for negations
        neg_states = []
        for premise, hypothesis in negation_examples:
            h = self._encode_pair(premise, hypothesis)
            neg_states.append(h)

        neg_matrix = torch.stack(neg_states)  # [M, d]

        # Build orthonormal subspaces via QR
        self.inversion_subspace, _ = torch.linalg.qr(inv_matrix.T)  # [d, r1]
        self.negation_subspace, _ = torch.linalg.qr(neg_matrix.T)   # [d, r2]

    def _subspace_support(self, h: torch.Tensor, Q: torch.Tensor) -> float:
        """Compute ||proj_Q(h)|| / ||h||."""
        proj = Q @ (Q.T @ h)
        h_norm = torch.norm(h)
        if h_norm < 1e-10:
            return 0.0
        return (torch.norm(proj) / h_norm).item()

    def detect(self, premise: str, hypothesis: str) -> Dict:
        """
        Detect if hypothesis is a role inversion of premise.

        Returns:
            Dict with:
                - is_contradiction: Whether it contradicts at all
                - is_inversion: Whether it's specifically a role inversion
                - is_negation: Whether it's a negation (not inversion)
                - score: Type III score (higher = more inversion)
                - inversion_support: Support on inversion subspace
                - negation_support: Support on negation subspace
                - nli_probs: Raw NLI probabilities

        RSCT Usage:
            result = detector.detect(evidence, claim)
            if result['is_inversion']:
                certificate.type_iii_score = result['score']
                flag_role_inversion()
        """
        # First check if it's a contradiction at all
        probs = self._get_nli_probs(premise, hypothesis)
        is_contradiction = probs[0].item() > self.contradiction_threshold

        result = {
            'is_contradiction': is_contradiction,
            'is_inversion': False,
            'is_negation': False,
            'score': 0.0,
            'inversion_support': 0.0,
            'negation_support': 0.0,
            'nli_probs': {
                'contradiction': probs[0].item(),
                'entailment': probs[1].item(),
                'neutral': probs[2].item()
            }
        }

        if not is_contradiction:
            return result

        # Check subspace supports if calibrated
        if self.inversion_subspace is None or self.negation_subspace is None:
            # Not calibrated - can't distinguish inversion from negation
            return result

        h = self._encode_pair(premise, hypothesis)

        inv_support = self._subspace_support(h, self.inversion_subspace)
        neg_support = self._subspace_support(h, self.negation_subspace)

        result['inversion_support'] = inv_support
        result['negation_support'] = neg_support

        # Classification based on relative support
        if inv_support > neg_support:
            result['is_inversion'] = True
            # Score based on support ratio
            result['score'] = probs[0].item() * (inv_support / (inv_support + neg_support + 1e-10))
        else:
            result['is_negation'] = True
            result['score'] = 0.0  # Not an inversion

        return result


# Default calibration examples
DEFAULT_INVERSION_EXAMPLES = [
    ("The hunter shot the bear.", "The bear shot the hunter."),
    ("John chases the dog.", "The dog chases John."),
    ("Alice teaches Bob.", "Bob teaches Alice."),
    ("The company acquired the startup.", "The startup acquired the company."),
    ("The plaintiff sued the defendant.", "The defendant sued the plaintiff."),
    ("Manager A reports to Manager B.", "Manager B reports to Manager A."),
]

DEFAULT_NEGATION_EXAMPLES = [
    ("The hunter shot the bear.", "The hunter did not shoot the bear."),
    ("John chases the dog.", "John does not chase the dog."),
    ("Alice teaches Bob.", "Alice does not teach Bob."),
    ("The company acquired the startup.", "The company did not acquire the startup."),
    ("The plaintiff sued the defendant.", "The plaintiff did not sue the defendant."),
    ("Manager A reports to Manager B.", "Manager A does not report to Manager B."),
]

# Passive voice examples (should NOT be detected as inversions!)
PASSIVE_VOICE_EXAMPLES = [
    ("The hunter shot the bear.", "The bear was shot by the hunter."),
    ("John chases the dog.", "The dog is chased by John."),
    ("Alice teaches Bob.", "Bob is taught by Alice."),
]
