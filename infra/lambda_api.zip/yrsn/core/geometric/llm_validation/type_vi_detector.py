"""
Type VI Detector: Domain Mismatch

Type VI catches when a claim is correct in SOME domain but wrong for
the EXPECTED domain. "Right answer to the wrong question's domain."

Example: Asking about SR 11-7 validation, getting ML test-set validation.
Both are "validation" but in completely different semantic neighborhoods.

RSCT APPLICATION:
-----------------
This is the hardest hallucination to detect because the content IS correct.
Type VI is effectively a domain-specific ω (OOD) detector for text.

Maps to Mode 3.4 (OOD Fabrication): Low ω (outside target domain) with
High κ (model is confident in its wrong-domain answer).

Source: Sudjianto, "Type VI: Domain Mismatch Hallucination"
"""

import torch
import numpy as np
from typing import Dict, List, Union, Callable, Optional


class TypeVIDetector:
    """
    Detect domain mismatch using QR subspace projection.

    The key insight: different domains (sr117_mrm vs general_ml) occupy
    different regions of embedding space despite shared vocabulary.

    Score = support(best_wrong_domain) - support(expected_domain)
    Positive score = domain mismatch

    RSCT Integration:
        detector = TypeVIDetector(embed_fn)
        detector.add_domain("sr117_mrm", sr117_exemplars)
        detector.add_domain("general_ml", ml_exemplars)

        score = detector.detect(claim, expected_domain="sr117_mrm")
        if score['score'] > 0.2:
            # Claim is in wrong domain
            omega = 1.0 - score['score']  # Reduce ω
            flag_mode_34_ood_fabrication()
    """

    def __init__(self, embed_fn: Callable[[str], torch.Tensor]):
        """
        Initialize detector.

        Args:
            embed_fn: Function to embed text to tensor
        """
        self.embed_fn = embed_fn
        self.domain_bases: Dict[str, torch.Tensor] = {}
        self.domain_exemplars: Dict[str, List[str]] = {}

    def add_domain(self, name: str, exemplars: List[str]) -> None:
        """
        Add a domain with its exemplar sentences.

        Exemplars should reflect how experts in that domain actually write,
        not just topically related sentences.

        Args:
            name: Domain identifier (e.g., "sr117_mrm")
            exemplars: List of representative sentences
        """
        self.domain_exemplars[name] = exemplars

        # Embed all exemplars
        embeddings = torch.stack([self.embed_fn(e) for e in exemplars])

        # QR decomposition to get orthonormal basis
        Q, _ = torch.linalg.qr(embeddings.T)
        self.domain_bases[name] = Q

    def _support(self, x: torch.Tensor, Q: torch.Tensor) -> float:
        """Compute ||proj_Q(x)|| / ||x||"""
        proj = Q @ (Q.T @ x)
        x_norm = torch.norm(x)
        if x_norm < 1e-10:
            return 0.0
        return (torch.norm(proj) / x_norm).item()

    def compute_supports(self, claim: str) -> Dict[str, float]:
        """
        Compute support on all domains for a claim.

        Args:
            claim: Text to classify

        Returns:
            Dict of {domain_name: support_value}
        """
        x = self.embed_fn(claim)
        return {name: self._support(x, Q)
                for name, Q in self.domain_bases.items()}

    def classify_domain(self, claim: str) -> str:
        """Return the best-matching domain for a claim."""
        supports = self.compute_supports(claim)
        return max(supports, key=supports.get)

    def detect(self,
               claim: str,
               expected_domain: str) -> Dict[str, Union[float, str, Dict]]:
        """
        Detect if a claim is in the wrong domain.

        Args:
            claim: Text to check
            expected_domain: The domain the claim SHOULD be in

        Returns:
            Dict with:
                - score: Type VI score (positive = mismatch)
                - raw_gap: Unscaled difference
                - expected_support: Support on expected domain
                - best_wrong_domain: Which wrong domain matched best
                - best_wrong_support: Support on that domain
                - all_supports: Full support profile

        RSCT Usage:
            result = detector.detect(output, "sr117_mrm")
            if result['score'] > 0.0:
                # Output is in wrong domain
                certificate.omega = result['expected_support']
                certificate.type_vi_score = result['score']
        """
        supports = self.compute_supports(claim)
        expected_support = supports.get(expected_domain, 0.0)

        # Find best wrong domain
        wrong_supports = {d: s for d, s in supports.items()
                         if d != expected_domain}

        if not wrong_supports:
            return {
                'score': 0.0,
                'raw_gap': 0.0,
                'expected_support': expected_support,
                'best_wrong_domain': None,
                'best_wrong_support': 0.0,
                'all_supports': supports,
            }

        best_wrong_domain = max(wrong_supports, key=wrong_supports.get)
        best_wrong_support = wrong_supports[best_wrong_domain]

        raw_gap = best_wrong_support - expected_support
        # Scale to [0, 1] - gap of 0.5+ maps to 1.0
        score = min(1.0, max(0.0, 2 * raw_gap))

        return {
            'score': score,
            'raw_gap': raw_gap,
            'expected_support': expected_support,
            'best_wrong_domain': best_wrong_domain,
            'best_wrong_support': best_wrong_support,
            'all_supports': supports,
        }

    def detect_batch(self,
                     claims: List[str],
                     expected_domain: str) -> List[Dict]:
        """Check multiple claims against expected domain."""
        return [self.detect(c, expected_domain) for c in claims]


# Pre-defined exemplars for financial MRM domain
SR117_MRM_EXEMPLARS = [
    "The independent validation unit assessed the model's conceptual soundness.",
    "Outcomes analysis compared model predictions against realized loss experience.",
    "The validation report documented limitations and conditions for use.",
    "Model risk appetite was reviewed by the risk committee and board.",
    "Governance attestation confirmed the model is fit for its intended purpose.",
    "The challenger model was developed independently to benchmark the champion.",
    "SR 11-7 requires ongoing monitoring of model performance in production.",
    "The model inventory was updated to reflect changes in scope and materiality.",
    "Tier 1 models require full independent validation prior to deployment.",
    "The model owner submitted a use case justification to the validation team.",
    "Findings from the validation were tracked and remediated through the issue log.",
    "Pre-implementation review confirmed alignment with the model risk policy.",
    "The validation covered data quality, methodology, and implementation testing.",
    "Back-testing results were reviewed against the model's stated assumptions.",
    "Model limitations identified during validation were disclosed to stakeholders.",
]

GENERAL_ML_EXEMPLARS = [
    "The model achieved 94% accuracy on the held-out test set.",
    "Hyperparameter tuning was performed using cross-validation.",
    "The architecture outperformed baseline benchmarks on standard datasets.",
    "Regularization techniques were applied to reduce overfitting.",
    "Feature importance was computed using permutation-based methods.",
    "The model was fine-tuned on domain-specific data to improve generalization.",
    "Evaluation metrics included precision, recall, and F1 score.",
    "The training loop used Adam optimizer with a learning rate scheduler.",
    "We applied dropout and batch normalization to stabilize training.",
    "The confusion matrix revealed class imbalance in the minority label.",
    "SHAP values were used to explain individual predictions.",
    "The model was exported to ONNX format for production deployment.",
    "Early stopping prevented overfitting on the validation split.",
    "We benchmarked inference latency across GPU and CPU environments.",
    "The ensemble combined gradient boosting and neural network predictions.",
]


def create_mrm_detector(embed_fn: Callable[[str], torch.Tensor]) -> TypeVIDetector:
    """
    Create a pre-configured detector for MRM domain checking.

    RSCT Usage:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer('all-MiniLM-L6-v2')
        embed = lambda x: torch.tensor(model.encode([x], normalize_embeddings=True)[0])

        detector = create_mrm_detector(embed)
        result = detector.detect(llm_output, "sr117_mrm")
    """
    detector = TypeVIDetector(embed_fn)
    detector.add_domain("sr117_mrm", SR117_MRM_EXEMPLARS)
    detector.add_domain("general_ml", GENERAL_ML_EXEMPLARS)
    return detector
