"""
Type IV Detector: Drift (Instruction Drift)

Type IV catches when the answer stays on-topic but loses the relationship.
"Same words, different meaning" - the answer is fluent and relevant but
doesn't actually answer the question using the provided context.

Detection uses plane alignment: the (query ∧ context) plane should align
with the (query ∧ answer) plane if the answer preserves the relationship.

RSCT APPLICATION:
-----------------
Type IV detects semantic drift that passes topical similarity checks.
This is post-execution validation for Mode 3.1 (Fluent Hallucination)
and Mode 3.4 (OOD Fabrication) where the output sounds right but
doesn't actually use the provided evidence.

Drift = 1 - cos(Q∧C, Q∧A)

Source: Sudjianto, "Type IV: Drift - when the answer keeps the words but loses the relationship"
"""

import torch
import numpy as np
from typing import Union, Dict, Tuple, Callable


def bivector_inner(u: torch.Tensor, v: torch.Tensor,
                   x: torch.Tensor, y: torch.Tensor) -> float:
    """
    Inner product between bivectors (u∧v) and (x∧y).

    <u∧v, x∧y> = (u·x)(v·y) - (u·y)(v·x)

    Args:
        u, v: Vectors spanning first plane
        x, y: Vectors spanning second plane

    Returns:
        Inner product scalar
    """
    return (torch.dot(u, x) * torch.dot(v, y) -
            torch.dot(u, y) * torch.dot(v, x)).item()


def wedge_norm(u: torch.Tensor, v: torch.Tensor, eps: float = 1e-12) -> float:
    """
    Compute ||u ∧ v||.

    ||u ∧ v||² = ||u||²||v||² - (u·v)²
    """
    uu = torch.dot(u, u).item()
    vv = torch.dot(v, v).item()
    uv = torch.dot(u, v).item()

    val = uu * vv - uv * uv
    return np.sqrt(max(val, eps))


def plane_cosine(u: torch.Tensor, v: torch.Tensor,
                 x: torch.Tensor, y: torch.Tensor,
                 eps: float = 1e-12) -> float:
    """
    Cosine similarity between two planes (bivectors).

    cos(u∧v, x∧y) = <u∧v, x∧y> / (||u∧v|| ||x∧y||)

    Args:
        u, v: Vectors spanning first plane (e.g., query, context)
        x, y: Vectors spanning second plane (e.g., query, answer)

    Returns:
        Cosine in [-1, 1]. +1 = aligned planes. -1 = opposite.
    """
    inner = bivector_inner(u, v, x, y)
    norm1 = wedge_norm(u, v, eps)
    norm2 = wedge_norm(x, y, eps)

    return inner / max(norm1 * norm2, eps)


def compute_drift(query: torch.Tensor,
                  context: torch.Tensor,
                  answer: torch.Tensor) -> Tuple[float, float]:
    """
    Compute Type IV drift score.

    Drift = 1 - cos(Q∧C, Q∧A)

    Low drift = answer preserves query-context relationship
    High drift = answer slides to different relationship

    Args:
        query: Query embedding [d]
        context: Context embedding [d]
        answer: Answer embedding [d]

    Returns:
        (drift, plane_cosine): Drift score and raw plane alignment

    RSCT Usage:
        drift, _ = compute_drift(q_emb, c_emb, a_emb)
        if drift > 0.5:
            # Answer doesn't preserve relationship
            flag_type_iv_drift()
    """
    pc = plane_cosine(query, context, query, answer)
    drift = 1.0 - pc
    return drift, pc


class TypeIVDetector:
    """
    Detect instruction drift using plane alignment geometry.

    RSCT Integration:
        detector = TypeIVDetector(embed_fn)
        result = detector.detect(query, context, answer)
        if result['drift'] > 0.5:
            # Mode 3.1 or 3.4 likely
            certificate.type_iv_score = result['drift']
    """

    def __init__(self, embed_fn: Callable[[str], torch.Tensor]):
        """
        Initialize detector.

        Args:
            embed_fn: Function to embed text to tensor (normalized)
        """
        self.embed_fn = embed_fn

    def detect(self,
               query: str,
               context: str,
               answer: str) -> Dict[str, float]:
        """
        Detect drift in an answer.

        Args:
            query: The question asked
            context: The evidence/context provided
            answer: The model's answer

        Returns:
            Dict with:
                - drift: Type IV score (higher = more drift)
                - plane_cosine: Raw plane alignment
                - cosine_answer_context: Standard cosine similarity
                - cosine_answer_query: Standard cosine similarity
        """
        q = self.embed_fn(query)
        c = self.embed_fn(context)
        a = self.embed_fn(answer)

        drift, pc = compute_drift(q, c, a)

        return {
            'drift': drift,
            'plane_cosine': pc,
            'cosine_answer_context': torch.dot(a, c).item(),
            'cosine_answer_query': torch.dot(a, q).item(),
        }

    def detect_batch(self,
                     query: str,
                     context: str,
                     answers: Dict[str, str]) -> Dict[str, Dict[str, float]]:
        """
        Compare multiple answer candidates.

        Useful for evaluating whether a model's answer drifts compared
        to a "grounded" baseline.

        Args:
            query: The question
            context: The evidence
            answers: Dict of {name: answer_text}

        Returns:
            Dict of results per answer
        """
        results = {}
        for name, answer in answers.items():
            results[name] = self.detect(query, context, answer)

        return results


# Example usage patterns for RSCT integration
"""
from sentence_transformers import SentenceTransformer
import torch

# Setup
model = SentenceTransformer('all-MiniLM-L6-v2')

def embed(text: str) -> torch.Tensor:
    return torch.tensor(model.encode([text], normalize_embeddings=True)[0])

detector = TypeIVDetector(embed)

# Check a single answer
result = detector.detect(
    query="Why did Alpha-X revenue decline last quarter?",
    context="Alpha-X revenue declined due to supplier disruption...",
    answer="Revenue declined amid challenging operating environment..."
)

if result['drift'] > 0.5:
    # Answer drifted from the causal explanation in context
    print(f"Type IV Drift detected: {result['drift']:.3f}")
    print(f"Cosine says 'on topic': {result['cosine_answer_context']:.3f}")
    print(f"But plane alignment shows drift: {result['plane_cosine']:.3f}")
"""
