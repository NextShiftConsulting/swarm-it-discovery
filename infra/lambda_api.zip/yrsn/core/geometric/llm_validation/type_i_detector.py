"""
Type I Detector: Unsupported Claims (Groundedness)

Type I catches claims that are not grounded in the provided evidence.
Uses bivector projection onto evidence planes to measure "leakage" -
how much of the claim is orthogonal to the evidence space.

NOTE: The original source mentions Type I but doesn't provide full
implementation code. This implementation is inferred from:
- "bivector projection onto evidence planes"
- "leakage is the fraction of the claim's energy that doesn't lie in the domain subspace"
- "FActScore-style decomposition"

RSCT APPLICATION:
-----------------
Type I is the foundational groundedness check. In RSCT terms:
- High support on evidence = High R (Relevant)
- High leakage = High N (Noise) or S (Superfluous)

This maps to pre-execution encoding quality assessment.

Source: Sudjianto, "Type I - Unsupported Claims" (description only)
"""

import torch
import numpy as np
from typing import Dict, List, Union, Callable, Tuple


class TypeIGroundednessDetector:
    """
    Detect unsupported claims using evidence subspace projection.

    The key insight: claims should project well onto the evidence space.
    Claims that are orthogonal to evidence ("leakage") are unsupported.

    Unlike Type VI (wrong domain), Type I checks if the claim has ANY
    grounding in the provided evidence, regardless of domain.

    RSCT Integration:
        detector = TypeIGroundednessDetector(embed_fn)
        result = detector.detect(evidence, claim)

        # Map to RSN
        certificate.R = result['support']  # Grounded in evidence
        certificate.N = result['leakage']  # Not in evidence
    """

    def __init__(self,
                 embed_fn: Callable[[str], torch.Tensor],
                 support_threshold: float = 0.5):
        """
        Initialize detector.

        Args:
            embed_fn: Function to embed text to normalized tensor
            support_threshold: Below this support = unsupported claim
        """
        self.embed_fn = embed_fn
        self.support_threshold = support_threshold

    def _build_evidence_basis(self, evidence: List[str]) -> torch.Tensor:
        """Build orthonormal basis from evidence sentences."""
        embeddings = torch.stack([self.embed_fn(e) for e in evidence])
        Q, _ = torch.linalg.qr(embeddings.T)
        return Q

    def _compute_support_leakage(self,
                                 claim_emb: torch.Tensor,
                                 evidence_basis: torch.Tensor) -> Tuple[float, float]:
        """
        Compute support (projection) and leakage (rejection).

        The Pythagorean decomposition:
            ||x||² = ||proj_Q(x)||² + ||rej_Q(x)||²
            1 = support² + leakage²

        Args:
            claim_emb: Claim embedding [d]
            evidence_basis: Orthonormal basis [d, r]

        Returns:
            (support, leakage): Both in [0, 1]
        """
        # Project onto evidence space
        proj = evidence_basis @ (evidence_basis.T @ claim_emb)

        claim_norm = torch.norm(claim_emb)
        if claim_norm < 1e-10:
            return 0.0, 1.0

        proj_norm = torch.norm(proj)
        support = (proj_norm / claim_norm).item()

        # Leakage from Pythagorean theorem
        leakage = np.sqrt(max(0, 1 - support ** 2))

        return support, leakage

    def detect(self,
               evidence: List[str],
               claim: str) -> Dict[str, Union[float, bool]]:
        """
        Check if a claim is supported by evidence.

        Args:
            evidence: List of evidence/context sentences
            claim: Claim to check

        Returns:
            Dict with:
                - support: How much of claim is in evidence space [0, 1]
                - leakage: How much is orthogonal to evidence [0, 1]
                - is_unsupported: Boolean flag
                - score: Type I score (higher = more unsupported)

        RSCT Usage:
            result = detector.detect(evidence, claim)
            certificate.R = result['support']
            if result['is_unsupported']:
                flag_type_i_unsupported()
        """
        # Build evidence basis
        evidence_basis = self._build_evidence_basis(evidence)

        # Embed claim
        claim_emb = self.embed_fn(claim)

        # Compute support and leakage
        support, leakage = self._compute_support_leakage(claim_emb, evidence_basis)

        is_unsupported = support < self.support_threshold

        return {
            'support': support,
            'leakage': leakage,
            'is_unsupported': is_unsupported,
            'score': leakage,  # Higher leakage = more unsupported
        }

    def detect_batch(self,
                     evidence: List[str],
                     claims: List[str]) -> List[Dict]:
        """Check multiple claims against the same evidence."""
        evidence_basis = self._build_evidence_basis(evidence)

        results = []
        for claim in claims:
            claim_emb = self.embed_fn(claim)
            support, leakage = self._compute_support_leakage(claim_emb, evidence_basis)

            results.append({
                'claim': claim,
                'support': support,
                'leakage': leakage,
                'is_unsupported': support < self.support_threshold,
                'score': leakage,
            })

        return results

    def attribute_to_evidence(self,
                              evidence: List[str],
                              claim: str) -> Dict[str, float]:
        """
        Attribute claim to specific evidence sentences.

        Returns per-sentence contribution scores.

        Args:
            evidence: List of evidence sentences
            claim: Claim to attribute

        Returns:
            Dict of {evidence_sentence: contribution_score}
        """
        claim_emb = self.embed_fn(claim)
        attributions = {}

        for e in evidence:
            e_emb = self.embed_fn(e)
            # Cosine similarity as attribution
            sim = torch.dot(claim_emb, e_emb).item()
            attributions[e[:50] + "..." if len(e) > 50 else e] = max(0, sim)

        # Normalize
        total = sum(attributions.values())
        if total > 0:
            attributions = {k: v / total for k, v in attributions.items()}

        return attributions


def compute_groundedness_score(evidence_embeddings: torch.Tensor,
                               claim_embedding: torch.Tensor) -> float:
    """
    Standalone function to compute groundedness.

    Simple interface for integration with existing pipelines.

    Args:
        evidence_embeddings: Stacked evidence embeddings [N, d]
        claim_embedding: Single claim embedding [d]

    Returns:
        Groundedness score in [0, 1]. Higher = more grounded.

    RSCT Usage:
        # Quick groundedness check
        score = compute_groundedness_score(evidence_embs, claim_emb)
        certificate.R = score
    """
    # Build basis
    Q, _ = torch.linalg.qr(evidence_embeddings.T)

    # Project
    proj = Q @ (Q.T @ claim_embedding)

    # Support
    claim_norm = torch.norm(claim_embedding)
    if claim_norm < 1e-10:
        return 0.0

    return (torch.norm(proj) / claim_norm).item()


# Example test cases
TYPE_I_TEST_CASES = {
    'evidence': [
        "Q3 revenue was $2.5 billion, up 15% from Q2.",
        "Operating margins improved to 22%.",
        "The company expanded into three new markets.",
    ],
    'supported': [
        "Revenue increased 15% to reach $2.5 billion.",
        "Margins reached 22% in the quarter.",
    ],
    'unsupported': [
        "The CEO announced a stock buyback program.",
        "Competition from overseas intensified.",
        "Supply chain issues affected production.",
    ],
}
