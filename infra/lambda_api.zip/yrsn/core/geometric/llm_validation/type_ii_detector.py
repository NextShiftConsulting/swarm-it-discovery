"""
Type II Detector: Contradiction

Type II catches when an LLM generates claims that directly conflict with
the provided context. Unlike Type I (unsupported), Type II outputs have
high topical relevance but opposite semantic meaning.

Detection uses NLI cross-encoder discriminant directions with Gram-Schmidt
orthogonalization to isolate "pure contradiction" from entailment.

RSCT APPLICATION:
-----------------
Type II is a post-execution validation check. In RSCT terms, it catches
cases where:
- κ_gate was high (content passed gates)
- But output contradicts input context

This maps to Mode 3.1 (Fluent Hallucination) where the model is
"confidently wrong" - generating plausible content that conflicts
with provided evidence.

Source: Sudjianto, "Type II: When AI Contradicts Its Sources"
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Union, Optional


class TypeIIContradictionDetector:
    """
    Detect contradictions using NLI cross-encoder geometry.

    The key insight: NLI models have learned discriminant directions
    for contradiction vs entailment. We extract and orthogonalize
    these to get "pure contradiction" detection.

    RSCT Integration:
        detector = TypeIIContradictionDetector(model, tokenizer)
        results = detector.detect(context_claims, output_claims)

        for r in results['scores']:
            if r['contradicts']:
                # Mode 3.1: Fluent Hallucination detected
                flag_contradiction(r['claim'], r['context_claim'])
    """

    def __init__(self,
                 model,
                 tokenizer,
                 threshold: float = 0.3,
                 device: str = 'cpu'):
        """
        Initialize detector.

        Args:
            model: HuggingFace NLI model (e.g., cross-encoder/nli-deberta-v3-base)
            tokenizer: Corresponding tokenizer
            threshold: Score above this = contradiction
            device: 'cpu' or 'cuda'
        """
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.threshold = threshold
        self.device = device
        self.model.eval()

        self._extract_discriminants()

    def _extract_discriminants(self):
        """Extract and orthogonalize discriminant directions from classifier."""
        # Get classification head weights
        # Shape: (3, hidden_dim) for [contradiction, entailment, neutral]
        W = self.model.classifier.weight.data

        w_contra = W[0]  # Contradiction direction
        w_entail = W[1]  # Entailment direction

        # Gram-Schmidt: Remove entailment component from contradiction
        # This gives us "pure contradiction" orthogonal to entailment
        dot_ce = torch.dot(w_contra, w_entail)
        dot_ee = torch.dot(w_entail, w_entail)
        proj = (dot_ce / dot_ee) * w_entail

        w_pure = w_contra - proj

        # Normalize
        self.w_pure_contra = F.normalize(w_pure, p=2, dim=0)

    def _encode_pair(self, premise: str, hypothesis: str) -> torch.Tensor:
        """Get pooled hidden state for premise-hypothesis pair."""
        inputs = self.tokenizer(
            premise, hypothesis,
            return_tensors="pt",
            padding=True,
            truncation=True
        ).to(self.device)

        with torch.no_grad():
            # Get model outputs
            outputs = self.model.deberta(**inputs)
            last_hidden_state = outputs.last_hidden_state

            # Apply pooler if available (critical for correct space)
            if hasattr(self.model, 'pooler') and self.model.pooler is not None:
                h = self.model.pooler(last_hidden_state)
            else:
                h = last_hidden_state[:, 0, :]

        return h[0]

    def detect(self,
               context: List[str],
               claims: List[str]) -> Dict:
        """
        Detect contradictions between claims and context.

        Args:
            context: List of context/evidence sentences
            claims: List of claims to check

        Returns:
            Dict with 'scores' list containing per-claim results:
                - claim: The claim text
                - score: Contradiction score (higher = more contradiction)
                - contradicts: Boolean flag
                - context_claim: Which context sentence it contradicts

        RSCT Usage:
            result = detector.detect(evidence, output_claims)
            type_ii_score = max(r['score'] for r in result['scores'])
            if type_ii_score > 0.3:
                certificate.type_ii_contradiction = True
        """
        results = []

        for claim in claims:
            max_cos = -1.0
            contra_idx = -1

            for i, ctx in enumerate(context):
                h = self._encode_pair(ctx, claim)
                h_norm = F.normalize(h, p=2, dim=0)

                # Project onto pure contradiction direction
                score = torch.dot(h_norm, self.w_pure_contra).item()

                if score > max_cos:
                    max_cos = score
                    contra_idx = i

            results.append({
                'claim': claim,
                'score': max_cos,
                'contradicts': max_cos > self.threshold,
                'context_claim': context[contra_idx] if contra_idx >= 0 else None
            })

        return {'scores': results}

    def detect_single(self, premise: str, hypothesis: str) -> Dict:
        """
        Check if hypothesis contradicts premise.

        Simpler interface for single pair checking.
        """
        h = self._encode_pair(premise, hypothesis)
        h_norm = F.normalize(h, p=2, dim=0)
        score = torch.dot(h_norm, self.w_pure_contra).item()

        return {
            'score': score,
            'contradicts': score > self.threshold,
            'premise': premise,
            'hypothesis': hypothesis
        }


def create_contradiction_detector(device: str = 'cpu') -> TypeIIContradictionDetector:
    """
    Create a pre-configured contradiction detector.

    Requires: pip install transformers

    Example:
        detector = create_contradiction_detector()
        result = detector.detect(
            context=["Revenue declined 12% in Q3"],
            claims=["Revenue grew 12% in Q3"]
        )
    """
    from transformers import AutoTokenizer, AutoModelForSequenceClassification

    model_name = 'cross-encoder/nli-deberta-v3-base'
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name)

    return TypeIIContradictionDetector(model, tokenizer, device=device)


# Example test cases
TYPE_II_TEST_CASES = [
    {
        'context': "The product launch was delayed to Q4 due to supply chain issues.",
        'contradiction': "The product launched successfully in Q3.",
        'entailment': "The product launch was postponed."
    },
    {
        'context': "Q3 revenue declined 12% year-over-year to $1.8B",
        'contradiction': "The company reported revenue growth of 12% in Q3",
        'entailment': "Revenue was lower than the same quarter last year."
    },
    {
        'context': "Patient tested negative for infection, symptoms resolved.",
        'contradiction': "Patient tested positive for infection requiring treatment.",
        'entailment': "The patient no longer has infection symptoms."
    },
]
