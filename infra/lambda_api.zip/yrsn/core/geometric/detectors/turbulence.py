"""
Turbulence Metric (Generic σ)

Measures instability in sequential processes via bivector rotation.

MODALITY-AGNOSTIC: Works on any embedding sequence.

Use Cases:
----------
- LLM: Reasoning chain stability
- Vision: Feature trajectory stability
- Audio: Spectrogram embedding stability
- Sensor: IoT sensor trajectory stability
- Multi-agent: Agent state trajectory stability

Key Insight:
------------
Turbulence σ measures the "rotation magnitude" between consecutive
steps in an embedding sequence. High σ indicates erratic/unstable
processes.

Unlike variance (which measures magnitude changes), bivector rotation
captures DIRECTIONAL changes - more sensitive to mode switches.

RSCT Integration:
-----------------
Maps directly to σ (turbulence) in RSCT paper:
- High σ → Unstable process
- σ spike (max >> mean) → Mode 2.3 (Oobleck Jamming)
- High σ variance → Erratic trajectory

Replaces variance-based σ proxies with geometric ground truth.

Source: Sudjianto bivector operations, applied to σ computation
"""

import torch
import numpy as np
from typing import List, Dict, Optional

from ..primitives.bivector import bivector_norm


def compute_turbulence(
    embeddings: List[torch.Tensor],
    method: str = 'mean',
) -> float:
    """
    Compute turbulence (σ) from embedding trajectory.

    **MODALITY-AGNOSTIC**

    Turbulence is the bivector rotation magnitude between consecutive
    steps. This measures directional instability, not just magnitude
    changes.

    Args:
        embeddings: Sequential embeddings [N x d]
                    Interpretation depends on modality:
                    - LLM: Text embeddings of reasoning steps
                    - Vision: CNN features over time/frames
                    - Audio: Spectrogram embeddings in sequence
                    - Sensor: IoT sensor embeddings over time

        method: Aggregation method
                - 'mean': Average rotation (stable processes)
                - 'max': Maximum rotation (spike detection)
                - 'std': Rotation variance (erratic processes)

    Returns:
        Turbulence σ in [0, 1]
        - σ ≈ 0: Very stable (little directional change)
        - σ ≈ 0.5: Moderate turbulence
        - σ ≈ 1: Highly turbulent (erratic jumps)

    RSCT Usage:
        >>> sigma = compute_turbulence(embeddings, method='mean')
        >>> if sigma > 0.7:
        ...     flag_mode_21_trajectory_divergence()
        >>>
        >>> # Spike detection for Mode 2.3
        >>> sigma_max = compute_turbulence(embeddings, method='max')
        >>> sigma_mean = compute_turbulence(embeddings, method='mean')
        >>> if sigma_max > 2 * sigma_mean and sigma_max > 0.8:
        ...     flag_mode_23_oobleck_jamming()

    Example (LLM):
        >>> # Reasoning chain stability
        >>> text_embs = [embed(step) for step in reasoning_steps]
        >>> sigma = compute_turbulence(text_embs, method='mean')
        >>> print(f"Reasoning turbulence: {sigma:.3f}")

    Example (Vision):
        >>> # Video frame feature stability
        >>> visual_embs = [cnn(frame) for frame in video_frames]
        >>> sigma = compute_turbulence(visual_embs, method='max')
        >>> if sigma > 0.8:
        ...     print("High visual turbulence - scene change?")

    Example (Sensor):
        >>> # IoT sensor trajectory stability
        >>> sensor_embs = [embed(reading) for reading in sensor_stream]
        >>> sigma_std = compute_turbulence(sensor_embs, method='std')
        >>> if sigma_std > 0.3:
        ...     print("Erratic sensor behavior detected")
    """
    if len(embeddings) < 2:
        return 0.0

    # Compute step-to-step rotations via bivector norm
    rotations = []
    for i in range(len(embeddings) - 1):
        rotation = bivector_norm(embeddings[i], embeddings[i+1])
        rotations.append(rotation)

    if not rotations:
        return 0.0

    # Aggregate rotations based on method
    if method == 'mean':
        return float(np.mean(rotations))
    elif method == 'max':
        return float(np.max(rotations))
    elif method == 'std':
        return float(np.std(rotations))
    else:
        raise ValueError(f"Unknown method: {method}. Use 'mean', 'max', or 'std'")


def compute_turbulence_profile(
    embeddings: List[torch.Tensor],
) -> Dict[str, float]:
    """
    Compute full turbulence profile with multiple metrics.

    Returns all turbulence statistics in one call for comprehensive
    analysis.

    Args:
        embeddings: Sequential embeddings [N x d]

    Returns:
        Dict with:
        - mean: Average rotation (overall stability)
        - max: Maximum rotation (worst spike)
        - std: Rotation variance (erratic behavior)
        - spike_detected: Boolean (max > 2×mean AND max > 0.8)
        - per_step: List of rotations at each step

    RSCT Usage:
        >>> profile = compute_turbulence_profile(embeddings)
        >>>
        >>> # Overall turbulence
        >>> certificate['sigma'] = profile['mean']
        >>>
        >>> # Mode 2.3: Oobleck Jamming (spike detection)
        >>> if profile['spike_detected']:
        ...     flag_mode_23(sigma_max=profile['max'])
        >>>
        >>> # Trajectory erratic-ness
        >>> if profile['std'] > 0.3:
        ...     flag_high_variance_trajectory()

    Example:
        >>> profile = compute_turbulence_profile(text_embeddings)
        >>> print(f"Mean σ: {profile['mean']:.3f}")
        >>> print(f"Max σ: {profile['max']:.3f}")
        >>> print(f"Std σ: {profile['std']:.3f}")
        >>> if profile['spike_detected']:
        ...     print("⚠️ Turbulence spike detected!")
        >>> print(f"Per-step: {profile['per_step']}")
    """
    if len(embeddings) < 2:
        return {
            'mean': 0.0,
            'max': 0.0,
            'std': 0.0,
            'spike_detected': False,
            'per_step': [],
        }

    # Compute all rotations
    rotations = []
    for i in range(len(embeddings) - 1):
        rotation = bivector_norm(embeddings[i], embeddings[i+1])
        rotations.append(rotation)

    if not rotations:
        return {
            'mean': 0.0,
            'max': 0.0,
            'std': 0.0,
            'spike_detected': False,
            'per_step': [],
        }

    mean_rot = float(np.mean(rotations))
    max_rot = float(np.max(rotations))
    std_rot = float(np.std(rotations))

    # Spike detection for Mode 2.3 (Oobleck Jamming)
    # Criteria: max > 2× mean AND max > 0.8 (absolute threshold)
    spike_detected = (max_rot > 2 * mean_rot) and (max_rot > 0.8)

    return {
        'mean': mean_rot,
        'max': max_rot,
        'std': std_rot,
        'spike_detected': spike_detected,
        'per_step': rotations,
    }


def detect_turbulence_spike(
    embeddings: List[torch.Tensor],
    spike_threshold: float = 2.0,
    absolute_threshold: float = 0.8,
) -> Optional[int]:
    """
    Detect turbulence spike (Mode 2.3: Oobleck Jamming).

    Args:
        embeddings: Sequential embeddings
        spike_threshold: Ratio max/mean to trigger (default 2.0)
        absolute_threshold: Absolute max rotation threshold (default 0.8)

    Returns:
        Index of spike step, or None if no spike

    RSCT Usage:
        >>> spike_idx = detect_turbulence_spike(embeddings)
        >>> if spike_idx is not None:
        ...     flag_mode_23_at_step(spike_idx)
        ...     certificate['rsct'] = {
        ...         'mode': '2.3',
        ...         'trigger': f'Oobleck spike at step {spike_idx}',
        ...     }

    Example:
        >>> spike_idx = detect_turbulence_spike(reasoning_embeddings)
        >>> if spike_idx is not None:
        ...     print(f"⚠️ Reasoning spike at step {spike_idx}")
        ...     print(f"LLM became suddenly unstable")
    """
    if len(embeddings) < 2:
        return None

    rotations = []
    for i in range(len(embeddings) - 1):
        rotation = bivector_norm(embeddings[i], embeddings[i+1])
        rotations.append(rotation)

    if not rotations:
        return None

    mean_rot = np.mean(rotations)
    max_rot = np.max(rotations)
    max_idx = int(np.argmax(rotations))

    # Check both relative and absolute thresholds
    is_spike = (max_rot > spike_threshold * mean_rot) and (max_rot > absolute_threshold)

    if is_spike:
        return max_idx + 1  # +1 because rotation[i] is between steps i and i+1
    return None


def compute_windowed_turbulence(
    embeddings: List[torch.Tensor],
    window_size: int = 5,
) -> List[float]:
    """
    Compute turbulence in sliding windows for trend analysis.

    Useful for detecting gradual drift vs sudden spikes.

    Args:
        embeddings: Sequential embeddings
        window_size: Size of sliding window

    Returns:
        List of turbulence values, one per window

    Example:
        >>> windowed = compute_windowed_turbulence(embeddings, window_size=5)
        >>> # Detect drift
        >>> for i, sigma in enumerate(windowed):
        ...     if sigma > 0.7:
        ...         print(f"High turbulence in window {i}")
        >>>
        >>> # Detect trend
        >>> if windowed[-1] > windowed[0] * 1.5:
        ...     print("Turbulence increasing over time")
    """
    if len(embeddings) < window_size:
        # Not enough data for windowing
        return [compute_turbulence(embeddings, method='mean')]

    window_sigmas = []
    for i in range(len(embeddings) - window_size + 1):
        window = embeddings[i:i + window_size]
        sigma = compute_turbulence(window, method='mean')
        window_sigmas.append(sigma)

    return window_sigmas


__all__ = [
    'compute_turbulence',
    'compute_turbulence_profile',
    'detect_turbulence_spike',
    'compute_windowed_turbulence',
]
