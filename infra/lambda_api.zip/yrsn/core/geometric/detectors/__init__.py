"""
Generic Geometric Detectors (Modality-Agnostic)

This module provides modality-agnostic implementations of geometric
validation techniques. These detectors work on ANY embedding space,
not just LLM text embeddings.

Architecture:
-------------
- Generic detectors operate on vectors (embeddings)
- Modality-specific wrappers provide convenience APIs
- Same underlying math works for text, vision, audio, sensors, etc.

Components:
-----------
1. Sequential Coherence (Generic Type V)
   - Detects failures in multi-step processes
   - Uses: Cayley steering, bivector rotation, trivector volume
   - Works on: LLM chains, vision sequences, sensor trajectories

2. Domain Mismatch (Generic Type VI)
   - Detects semantic domain mismatches via QR subspace
   - Works on: Text domains, visual domains, audio domains

3. Turbulence Metric (Generic σ)
   - Measures instability in sequential embeddings
   - Works on: Any embedding trajectory

Design Principle:
-----------------
"Operate on embeddings, not modalities."

The only modality-specific part is how you obtain the embeddings.
All geometric operations work identically across modalities.
"""

from .sequential_coherence import (
    SequentialCoherenceDetector,
    SequentialAnalysis,
    analyze_llm_reasoning,
    analyze_visual_reasoning,
    analyze_sensor_trajectory,
)

from .domain_mismatch import (
    DomainMismatchDetector,
    DomainAnalysis,
    create_text_domain_detector,
    create_visual_domain_detector,
)

from .turbulence import (
    compute_turbulence,
    compute_turbulence_profile,
)

__all__ = [
    # Sequential Coherence (Generic Type V)
    'SequentialCoherenceDetector',
    'SequentialAnalysis',
    'analyze_llm_reasoning',
    'analyze_visual_reasoning',
    'analyze_sensor_trajectory',

    # Domain Mismatch (Generic Type VI)
    'DomainMismatchDetector',
    'DomainAnalysis',
    'create_text_domain_detector',
    'create_visual_domain_detector',

    # Turbulence (Generic σ)
    'compute_turbulence',
    'compute_turbulence_profile',
]
