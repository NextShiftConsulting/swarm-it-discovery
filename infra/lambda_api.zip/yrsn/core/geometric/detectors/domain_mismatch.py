"""
Domain Mismatch Detector (Generic Type VI)

Detects when an output is correct in SOME domain but wrong for the
EXPECTED domain using QR subspace projection.

MODALITY-AGNOSTIC: Works with any embedding space.

Use Cases:
----------
- LLM: SR 11-7 MRM vs general ML content
- Vision: Medical imaging domains (MRI vs CT vs X-ray)
- Audio: Speaker domains, language domains
- Manufacturing: Production line domains
- Finance: Market regime domains

The detector learns a subspace for each domain from exemplars,
then measures how much a sample "belongs" to each subspace.

Key Insight:
------------
Different semantic domains occupy different regions of embedding
space despite shared vocabulary/visual features. A claim can be
factually correct but in the WRONG domain.

Example: "The model achieved 94% test accuracy" is correct ML content
but WRONG if you asked about SR 11-7 model risk management validation.

RSCT Integration:
-----------------
Maps to Mode 3.4 (OOD Fabrication):
- High mismatch score → Low ω (out of distribution)
- Wrong domain detected → Mode 3.4 triggered

Source: Sudjianto Type VI (LLM), generalized to all modalities
"""

import torch
import numpy as np
from typing import Dict, List, Callable, Optional, Union, Any
from dataclasses import dataclass

from ..primitives.subspace import orthonormal_basis, subspace_support


@dataclass
class DomainAnalysis:
    """
    Generic domain mismatch analysis.

    Attributes:
        mismatch_score: [0,1] where 1 = severe mismatch
        expected_support: Support on expected domain [0,1]
        best_wrong_domain: Which wrong domain matched best
        best_wrong_support: Support on wrong domain
        all_supports: Support on all registered domains
    """
    mismatch_score: float
    expected_support: float
    best_wrong_domain: Optional[str]
    best_wrong_support: float
    all_supports: Dict[str, float]


class DomainMismatchDetector:
    """
    Generic domain mismatch detector using QR subspace projection.

    **MODALITY-AGNOSTIC**

    The detector builds an orthonormal basis for each domain via QR
    decomposition of domain exemplars, then measures how much a test
    sample projects onto each domain's subspace.

    High support on wrong domain = domain mismatch.

    Works identically for:
    - Text: Semantic domains (legal vs medical vs financial)
    - Vision: Visual domains (MRI vs CT vs X-ray)
    - Audio: Acoustic domains (speaker A vs speaker B)
    - Sensor: Operational domains (normal vs fault modes)

    Example (LLM - SR 11-7 vs general ML):
        >>> detector = DomainMismatchDetector(embed_fn=sentence_transformer.encode)
        >>> detector.add_domain("sr117_mrm", [
        ...     "The validation unit assessed model soundness.",
        ...     "SR 11-7 requires ongoing monitoring.",
        ... ])
        >>> detector.add_domain("general_ml", [
        ...     "The model achieved 94% accuracy.",
        ...     "We used cross-validation for tuning.",
        ... ])
        >>> result = detector.detect(
        ...     "The model achieved high accuracy on test data.",
        ...     expected_domain="sr117_mrm"
        ... )
        >>> if result.mismatch_score > 0.2:
        ...     print(f"Wrong domain! Actually: {result.best_wrong_domain}")

    Example (Vision - Medical imaging):
        >>> detector = DomainMismatchDetector(embed_fn=resnet.extract_features)
        >>> detector.add_domain("mri", [mri_img_1, mri_img_2, ...])
        >>> detector.add_domain("ct", [ct_img_1, ct_img_2, ...])
        >>> detector.add_domain("xray", [xray_img_1, xray_img_2, ...])
        >>> result = detector.detect(mystery_image, expected_domain="mri")
        >>> if result.mismatch_score > 0.2:
        ...     print(f"Wrong modality! Got {result.best_wrong_domain} not MRI")

    Example (Audio - Speaker verification):
        >>> detector = DomainMismatchDetector(embed_fn=audio_encoder.encode)
        >>> detector.add_domain("speaker_A", [clip_a1, clip_a2, ...])
        >>> detector.add_domain("speaker_B", [clip_b1, clip_b2, ...])
        >>> result = detector.detect(mystery_audio, expected_domain="speaker_A")
        >>> if result.mismatch_score > 0.2:
        ...     print("Speaker mismatch detected!")
    """

    def __init__(self, embed_fn: Callable[[Any], torch.Tensor]):
        """
        Initialize detector.

        Args:
            embed_fn: Function that converts raw input to embedding
                      The signature depends on modality:
                      - LLM: str → torch.Tensor
                      - Vision: np.ndarray → torch.Tensor
                      - Audio: np.ndarray → torch.Tensor
                      - Sensor: Dict → torch.Tensor

        Example:
            >>> # LLM
            >>> from sentence_transformers import SentenceTransformer
            >>> model = SentenceTransformer('all-MiniLM-L6-v2')
            >>> embed_fn = lambda x: torch.tensor(model.encode(x))
            >>> detector = DomainMismatchDetector(embed_fn)

            >>> # Vision
            >>> embed_fn = lambda img: resnet.extract_features(img)
            >>> detector = DomainMismatchDetector(embed_fn)
        """
        self.embed_fn = embed_fn
        self.domain_bases: Dict[str, torch.Tensor] = {}
        self.domain_exemplars: Dict[str, List[Any]] = {}

    def add_domain(self, name: str, exemplars: List[Any]) -> None:
        """
        Add a domain with its exemplars.

        Args:
            name: Domain identifier (e.g., "sr117_mrm", "mri", "speaker_A")
            exemplars: List of domain-representative samples
                       Type depends on modality:
                       - LLM: List[str] sentences
                       - Vision: List[np.ndarray] images
                       - Audio: List[np.ndarray] audio clips
                       - Sensor: List[Dict] sensor readings

        The method:
        1. Embeds all exemplars using embed_fn
        2. Stacks them into a matrix [N x d]
        3. Performs QR decomposition to get orthonormal basis
        4. Stores basis for future support computation

        Example (LLM):
            >>> detector.add_domain("sr117_mrm", [
            ...     "Independent validation assessed conceptual soundness.",
            ...     "SR 11-7 requires ongoing performance monitoring.",
            ...     "Model risk appetite reviewed by committee.",
            ... ])

        Example (Vision):
            >>> mri_images = load_mri_examples()  # List[np.ndarray]
            >>> detector.add_domain("mri", mri_images)

        Example (Audio):
            >>> speaker_clips = load_speaker_samples()  # List[np.ndarray]
            >>> detector.add_domain("speaker_A", speaker_clips)
        """
        if len(exemplars) == 0:
            raise ValueError(f"Domain '{name}' requires at least one exemplar")

        self.domain_exemplars[name] = exemplars

        # Embed all exemplars
        embeddings = torch.stack([self.embed_fn(e) for e in exemplars])

        # Build orthonormal basis via QR decomposition
        Q, _ = torch.linalg.qr(embeddings.T)
        self.domain_bases[name] = Q

    def detect(
        self,
        sample: Any,
        expected_domain: str,
    ) -> DomainAnalysis:
        """
        Detect if sample is in wrong domain.

        Args:
            sample: Raw input (modality-specific type)
                    - LLM: str
                    - Vision: np.ndarray (image)
                    - Audio: np.ndarray (audio)
                    - Sensor: Dict (reading)

            expected_domain: The domain the sample SHOULD be in

        Returns:
            DomainAnalysis with mismatch score and domain supports

        Algorithm:
        1. Embed the sample
        2. Compute support on all domain subspaces
        3. Compare expected vs best wrong domain
        4. Return mismatch score (positive = mismatch)

        RSCT Mapping:
            - mismatch_score > 0.2 → Mode 3.4 (OOD Fabrication)
            - expected_support → ω (reliability/in-distribution)

        Example (LLM):
            >>> result = detector.detect(
            ...     "The model achieved 94% accuracy on the test set.",
            ...     expected_domain="sr117_mrm",
            ... )
            >>> if result.mismatch_score > 0.2:
            ...     print(f"Mode 3.4: Output is {result.best_wrong_domain}")
            ...     print(f"ω = {result.expected_support:.2f}")

        Example (Vision):
            >>> result = detector.detect(xray_image, expected_domain="mri")
            >>> if result.mismatch_score > 0.2:
            ...     print(f"Wrong modality: {result.best_wrong_domain}")
        """
        if expected_domain not in self.domain_bases:
            raise ValueError(f"Unknown domain: {expected_domain}")

        # Embed sample
        x = self.embed_fn(sample)

        # Compute support on all domains
        supports = {}
        for name, Q in self.domain_bases.items():
            supports[name] = subspace_support(x, Q)

        expected_support = supports[expected_domain]

        # Find best wrong domain
        wrong_supports = {d: s for d, s in supports.items()
                         if d != expected_domain}

        if not wrong_supports:
            # Only one domain registered
            return DomainAnalysis(
                mismatch_score=0.0,
                expected_support=expected_support,
                best_wrong_domain=None,
                best_wrong_support=0.0,
                all_supports=supports,
            )

        best_wrong_domain = max(wrong_supports, key=wrong_supports.get)
        best_wrong_support = wrong_supports[best_wrong_domain]

        # Mismatch score: positive if wrong domain has higher support
        # Scale: gap of 0.5+ maps to score of 1.0
        raw_gap = best_wrong_support - expected_support
        mismatch_score = min(1.0, max(0.0, 2 * raw_gap))

        return DomainAnalysis(
            mismatch_score=mismatch_score,
            expected_support=expected_support,
            best_wrong_domain=best_wrong_domain,
            best_wrong_support=best_wrong_support,
            all_supports=supports,
        )

    def classify_domain(self, sample: Any) -> str:
        """
        Classify sample into best-matching domain.

        Args:
            sample: Raw input (any modality)

        Returns:
            Name of best-matching domain

        Example:
            >>> domain = detector.classify_domain(mystery_text)
            >>> print(f"Sample belongs to: {domain}")
        """
        if not self.domain_bases:
            raise ValueError("No domains registered")

        x = self.embed_fn(sample)
        supports = {name: subspace_support(x, Q)
                   for name, Q in self.domain_bases.items()}

        return max(supports, key=supports.get)

    def compute_all_supports(self, sample: Any) -> Dict[str, float]:
        """
        Compute support on all registered domains.

        Args:
            sample: Raw input (any modality)

        Returns:
            Dict mapping domain name to support [0,1]

        Example:
            >>> supports = detector.compute_all_supports(sample)
            >>> for domain, support in supports.items():
            ...     print(f"{domain}: {support:.3f}")
        """
        x = self.embed_fn(sample)
        return {name: subspace_support(x, Q)
                for name, Q in self.domain_bases.items()}


# =============================================================================
# Pre-configured Detectors for Common Use Cases
# =============================================================================

def create_text_domain_detector(
    embed_fn: Callable[[str], torch.Tensor],
    domains: Dict[str, List[str]],
) -> DomainMismatchDetector:
    """
    Create detector for text domains.

    Args:
        embed_fn: Text embedding function
        domains: Dict mapping domain name to exemplar sentences

    Returns:
        Configured DomainMismatchDetector

    Example:
        >>> from sentence_transformers import SentenceTransformer
        >>> model = SentenceTransformer('all-MiniLM-L6-v2')
        >>> embed = lambda x: torch.tensor(model.encode(x))
        >>>
        >>> detector = create_text_domain_detector(
        ...     embed_fn=embed,
        ...     domains={
        ...         "sr117_mrm": [
        ...             "SR 11-7 requires independent validation.",
        ...             "Model risk governance reviewed by board.",
        ...         ],
        ...         "general_ml": [
        ...             "The model achieved 94% test accuracy.",
        ...             "We used cross-validation for tuning.",
        ...         ],
        ...     }
        ... )
        >>>
        >>> result = detector.detect(llm_output, expected_domain="sr117_mrm")
    """
    detector = DomainMismatchDetector(embed_fn)
    for name, exemplars in domains.items():
        detector.add_domain(name, exemplars)
    return detector


def create_visual_domain_detector(
    feature_extractor: Callable[[np.ndarray], torch.Tensor],
    domains: Dict[str, List[np.ndarray]],
) -> DomainMismatchDetector:
    """
    Create detector for visual domains.

    Args:
        feature_extractor: Image → embedding function
        domains: Dict mapping domain name to exemplar images

    Returns:
        Configured DomainMismatchDetector

    Example:
        >>> import numpy as np
        >>> # Assume resnet is a pre-trained feature extractor
        >>>
        >>> detector = create_visual_domain_detector(
        ...     feature_extractor=resnet.extract_features,
        ...     domains={
        ...         "mri": [mri_img_1, mri_img_2, ...],
        ...         "ct": [ct_img_1, ct_img_2, ...],
        ...         "xray": [xray_img_1, xray_img_2, ...],
        ...     }
        ... )
        >>>
        >>> result = detector.detect(mystery_image, expected_domain="mri")
        >>> if result.mismatch_score > 0.2:
        ...     print(f"Wrong modality: {result.best_wrong_domain}")
    """
    detector = DomainMismatchDetector(feature_extractor)
    for name, exemplars in domains.items():
        detector.add_domain(name, exemplars)
    return detector


__all__ = [
    'DomainMismatchDetector',
    'DomainAnalysis',
    'create_text_domain_detector',
    'create_visual_domain_detector',
]
