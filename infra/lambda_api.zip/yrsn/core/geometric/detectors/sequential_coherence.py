"""
Sequential Coherence Detector (Generic Type V)

Detects failures in multi-step processes via geometric analysis:
- Cayley steering: Is process guided by context/prior?
- Bivector rotation: Magnitude of step-to-step changes
- Trivector volume: Out-of-plane jumps (topic/mode switches)

MODALITY-AGNOSTIC: Works on any embedding sequence.

Use Cases:
----------
- LLM reasoning chains (text embeddings)
- Visual reasoning (CNN feature sequences)
- Audio processing (spectrogram embedding sequences)
- Sensor fusion (IoT sensor embedding trajectories)
- Multi-agent coordination (agent state sequences)

The detector doesn't care WHAT the embeddings represent,
only their geometric properties.

RSCT Integration:
-----------------
Maps to Mode 2.1 (Trajectory Divergence) and σ (turbulence):
- High trivector volume → Mode 2.1
- Low Cayley steering → Mode 3.1 (unguided/"vibing")
- High rotation variance → High σ (turbulent)

Source: Sudjianto Type V (LLM), generalized to all modalities
"""

import torch
import numpy as np
from typing import List, Optional, Callable, Union
from dataclasses import dataclass

from ..primitives.bivector import bivector_norm
from ..primitives.cayley import CayleySteering
from ..primitives.trivector import trivector_volume


@dataclass
class SequentialAnalysis:
    """
    Generic analysis of sequential process coherence.

    Attributes:
        coherence_score: Overall coherence [0,1], higher = better
        is_guided: Is process using context/prior guidance?
        drift_onset: First problematic step (-1 if none)
        steering_magnitude: τ (Cayley steering) - context influence
        max_deviation: Maximum out-of-plane jump (trivector)
        per_step_rotations: Bivector rotation at each step
        flags: List of detected issues
    """
    coherence_score: float
    is_guided: bool
    drift_onset: int
    steering_magnitude: float
    max_deviation: float
    per_step_rotations: List[float]
    flags: List[str]


class SequentialCoherenceDetector:
    """
    Generic detector for sequential process coherence.

    **MODALITY-AGNOSTIC**

    The detector analyzes sequences of embeddings to detect:
    1. Unguided processes (low Cayley steering)
    2. Erratic jumps (high bivector rotation)
    3. Mode switches (high trivector volume)

    Works identically for:
    - Text: LLM reasoning step embeddings
    - Vision: CNN feature sequences over time
    - Audio: Spectrogram embeddings
    - Sensors: IoT sensor state embeddings
    - Multi-agent: Agent state trajectories

    Example (LLM):
        >>> detector = SequentialCoherenceDetector()
        >>> steps = [embed(s) for s in reasoning_steps]
        >>> analysis = detector.analyze(steps, prior=query_emb, context=rag_emb)
        >>> if not analysis.is_guided:
        ...     flag_vibing()  # LLM ignored context

    Example (Vision):
        >>> detector = SequentialCoherenceDetector()
        >>> features = [cnn(frame) for frame in video_frames]
        >>> analysis = detector.analyze(features, prior=input_features)
        >>> if analysis.max_deviation > 0.9:
        ...     flag_mode_jump()  # Vision switched objects/domains

    Example (Sensor):
        >>> detector = SequentialCoherenceDetector()
        >>> embeddings = [embed(reading) for reading in sensor_stream]
        >>> analysis = detector.analyze(embeddings, prior=baseline)
        >>> if analysis.drift_onset >= 0:
        ...     alert_anomaly(analysis.drift_onset)
    """

    def __init__(
        self,
        guidance_threshold: float = 0.05,   # Below this = unguided
        jump_threshold: float = 0.9,        # Above this = mode jump
        drift_threshold: float = 0.7,       # Above this = drift onset
    ):
        """
        Initialize detector.

        Args:
            guidance_threshold: Below this Cayley τ = unguided process
            jump_threshold: Above this trivector volume = mode jump
            drift_threshold: Above this rotation = drift onset
        """
        self.guidance_threshold = guidance_threshold
        self.jump_threshold = jump_threshold
        self.drift_threshold = drift_threshold
        self.steering = CayleySteering(vibe_threshold=guidance_threshold)

    def analyze(
        self,
        steps: List[torch.Tensor],
        prior: Optional[torch.Tensor] = None,
        context: Optional[torch.Tensor] = None,
    ) -> SequentialAnalysis:
        """
        Analyze sequential coherence.

        Args:
            steps: List of embedding vectors [N x d]
                   Interpretation depends on modality:
                   - LLM: Text embeddings of reasoning steps
                   - Vision: CNN features at each inference step
                   - Audio: Spectrogram embeddings over time
                   - Sensor: IoT sensor embeddings in sequence

            prior: Initial state before process starts (optional)
                   - LLM: Query-only embedding (before RAG)
                   - Vision: Input image features
                   - Audio: Input audio embedding
                   - Sensor: Baseline/normal state

            context: Guidance context (optional)
                     - LLM: RAG context embedding
                     - Vision: Reference/target image features
                     - Audio: Target speaker/content embedding
                     - Sensor: Expected state embedding

        Returns:
            SequentialAnalysis with coherence metrics

        RSCT Mapping:
            - analysis.is_guided == False → Mode 3.1 (Fluent Hallucination)
            - analysis.max_deviation > 0.9 → Mode 2.1 (Trajectory Divergence)
            - analysis.coherence_score → σ (turbulence) inverse
        """
        if len(steps) < 2:
            return self._default_analysis()

        # Normalize all steps
        steps = [s / (torch.norm(s) + 1e-10) for s in steps]

        # Compute steering (guidance) if prior and context available
        steering_magnitude = 0.0
        is_guided = True

        if prior is not None and len(steps) > 0:
            # Posterior = mean of process steps
            posterior = torch.stack(steps).mean(dim=0)
            posterior = posterior / (torch.norm(posterior) + 1e-10)

            if context is not None:
                # Use Cayley steering between prior and posterior
                steering_magnitude = self.steering.compute_steering_magnitude(
                    prior, posterior
                )
            else:
                # Use bivector as proxy for steering
                steering_magnitude = bivector_norm(prior, posterior)

            is_guided = steering_magnitude >= self.guidance_threshold

        # Analyze step-to-step rotations
        rotations = []
        for i in range(len(steps) - 1):
            rotation = bivector_norm(steps[i], steps[i+1])
            rotations.append(rotation)

        # Detect out-of-plane jumps (mode switches)
        max_deviation = 0.0
        drift_onset = -1
        flags = []

        if len(steps) >= 3:
            for i in range(len(steps) - 2):
                vol = trivector_volume(steps[i], steps[i+1], steps[i+2])

                if vol > max_deviation:
                    max_deviation = vol

                if vol > self.jump_threshold and drift_onset < 0:
                    drift_onset = i + 2
                    flags.append(f"MODE_JUMP_AT_STEP_{i+2}")

        # Check for high rotation (drift)
        if rotations:
            for i, rot in enumerate(rotations):
                if rot > self.drift_threshold and drift_onset < 0:
                    drift_onset = i + 1
                    flags.append(f"DRIFT_AT_STEP_{i+1}")

        # Compute overall coherence score
        # High coherence = guided + low rotation variance + no jumps
        coherence = 1.0

        if not is_guided:
            coherence -= 0.4
            flags.append("UNGUIDED")

        if rotations:
            rotation_variance = np.var(rotations)
            coherence -= min(0.3, rotation_variance * 3)

        if max_deviation > self.jump_threshold:
            coherence -= 0.3 * max_deviation
            flags.append("DEVIATION_DETECTED")

        coherence = max(0.0, coherence)

        return SequentialAnalysis(
            coherence_score=coherence,
            is_guided=is_guided,
            drift_onset=drift_onset,
            steering_magnitude=steering_magnitude,
            max_deviation=max_deviation,
            per_step_rotations=rotations,
            flags=flags,
        )

    def _default_analysis(self) -> SequentialAnalysis:
        """Default for insufficient data."""
        return SequentialAnalysis(
            coherence_score=0.5,
            is_guided=True,
            drift_onset=-1,
            steering_magnitude=0.0,
            max_deviation=0.0,
            per_step_rotations=[],
            flags=["INSUFFICIENT_DATA"],
        )


# =============================================================================
# Convenience Functions for Common Modalities
# =============================================================================

def analyze_llm_reasoning(
    reasoning_steps: List[str],
    context: Union[str, List[str]],
    embed_fn: Callable[[str], torch.Tensor],
    query: Optional[str] = None,
) -> SequentialAnalysis:
    """
    LLM-specific wrapper for sequential coherence.

    Args:
        reasoning_steps: List of text reasoning steps
        context: RAG context (string or list of strings)
        embed_fn: Function to embed text to tensor
        query: Original user query (optional)

    Returns:
        SequentialAnalysis

    Example:
        >>> from sentence_transformers import SentenceTransformer
        >>> model = SentenceTransformer('all-MiniLM-L6-v2')
        >>> embed = lambda x: torch.tensor(model.encode(x))
        >>>
        >>> analysis = analyze_llm_reasoning(
        ...     reasoning_steps=["First, analyze...", "Next, consider...", "Finally..."],
        ...     context="Retrieved documents from RAG",
        ...     embed_fn=embed,
        ...     query="What is the answer?",
        ... )
        >>>
        >>> if not analysis.is_guided:
        ...     print("LLM is vibing (ignoring context)")
        >>> if analysis.max_deviation > 0.9:
        ...     print("LLM jumped topics (Mode 2.1)")
    """
    detector = SequentialCoherenceDetector()

    # Embed steps
    steps_emb = [embed_fn(step) for step in reasoning_steps]

    # Embed prior (query)
    prior_emb = embed_fn(query) if query else None

    # Embed context
    if isinstance(context, str):
        context_emb = embed_fn(context)
    else:
        # Multiple context pieces - take mean
        context_embs = [embed_fn(c) for c in context]
        context_emb = torch.stack(context_embs).mean(dim=0)

    return detector.analyze(steps_emb, prior_emb, context_emb)


def analyze_visual_reasoning(
    visual_features: List[torch.Tensor],
    reference_image: Optional[torch.Tensor] = None,
) -> SequentialAnalysis:
    """
    Vision-specific wrapper for sequential coherence.

    Args:
        visual_features: CNN features at each step [N x d]
        reference_image: Reference/target image features (optional)

    Returns:
        SequentialAnalysis

    Example:
        >>> # Multi-step visual reasoning (e.g., visual question answering)
        >>> features = [resnet(img) for img in image_sequence]
        >>> reference = resnet(target_image)
        >>>
        >>> analysis = analyze_visual_reasoning(features, reference_image=reference)
        >>>
        >>> if analysis.max_deviation > 0.9:
        ...     print("Vision jumped domains/objects (Mode 2.1)")
    """
    detector = SequentialCoherenceDetector()
    return detector.analyze(visual_features, prior=reference_image)


def analyze_sensor_trajectory(
    sensor_embeddings: List[torch.Tensor],
    baseline: Optional[torch.Tensor] = None,
) -> SequentialAnalysis:
    """
    Sensor-specific wrapper for sequential coherence.

    Args:
        sensor_embeddings: IoT sensor embeddings over time
        baseline: Baseline/normal state embedding (optional)

    Returns:
        SequentialAnalysis

    Example:
        >>> # IoT sensor monitoring
        >>> embeddings = [embed_sensor_reading(r) for r in readings]
        >>> baseline_state = embed_sensor_reading(normal_reading)
        >>>
        >>> analysis = analyze_sensor_trajectory(embeddings, baseline=baseline_state)
        >>>
        >>> if analysis.drift_onset >= 0:
        ...     alert_anomaly(f"Drift detected at step {analysis.drift_onset}")
    """
    detector = SequentialCoherenceDetector()
    return detector.analyze(sensor_embeddings, prior=baseline)


__all__ = [
    'SequentialCoherenceDetector',
    'SequentialAnalysis',
    'analyze_llm_reasoning',
    'analyze_visual_reasoning',
    'analyze_sensor_trajectory',
]
