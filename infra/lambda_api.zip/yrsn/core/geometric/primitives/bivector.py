"""
Bivector Operations for Geometric Algebra

A bivector u ∧ v represents the oriented parallelogram spanned by two vectors.
Its norm measures the "rotation magnitude" between them.

RSCT APPLICATION:
-----------------
σ (turbulence) could be computed as the mean bivector norm between consecutive
reasoning steps, rather than simple variance:

    σ_geometric = mean([bivector_norm(step_i, step_{i+1}) for steps])

This captures directional change (rotation) rather than just magnitude change.

For Mode 2.1 (Trajectory Divergence), high bivector norms indicate the solver
is making erratic jumps in representation space.

Source: Sudjianto, "Type V Hallucination: When LLMs Go Off the Rails"
"""

import torch
import numpy as np
from typing import Union, Tuple


def bivector_norm(u: Union[torch.Tensor, np.ndarray],
                  v: Union[torch.Tensor, np.ndarray]) -> float:
    """
    Compute the bivector norm ||u ∧ v||.

    For normalized vectors, this equals sin(θ) where θ is the angle between them.

    Formula: ||u ∧ v||² = ||u||²||v||² - (u·v)²

    Args:
        u: First vector (any dimension)
        v: Second vector (same dimension as u)

    Returns:
        Bivector norm in [0, 1] for normalized inputs

    RSCT Usage:
        # Measure step-to-step rotation in reasoning
        for i in range(len(steps) - 1):
            rotation = bivector_norm(steps[i], steps[i+1])
            if rotation > 0.9:
                # Mode 2.1: Trajectory Divergence
                flag_erratic_jump(i)
    """
    if isinstance(u, np.ndarray):
        u = torch.tensor(u, dtype=torch.float32)
    if isinstance(v, np.ndarray):
        v = torch.tensor(v, dtype=torch.float32)

    # Normalize for directional comparison
    u_norm = torch.norm(u)
    v_norm = torch.norm(v)

    if u_norm < 1e-10 or v_norm < 1e-10:
        return 0.0

    u_hat = u / u_norm
    v_hat = v / v_norm

    # ||u ∧ v||² = ||u||²||v||² - (u·v)²
    # For unit vectors: ||u ∧ v||² = 1 - cos²(θ) = sin²(θ)
    dot_product = torch.dot(u_hat, v_hat)

    # Clamp to avoid numerical issues
    dot_product = torch.clamp(dot_product, -1.0, 1.0)

    bivector_norm_sq = 1.0 - dot_product ** 2
    bivector_norm_sq = torch.clamp(bivector_norm_sq, min=0.0)

    return torch.sqrt(bivector_norm_sq).item()


def bivector_angle(u: Union[torch.Tensor, np.ndarray],
                   v: Union[torch.Tensor, np.ndarray],
                   degrees: bool = True) -> float:
    """
    Compute the angle between two vectors using bivector geometry.

    Args:
        u: First vector
        v: Second vector
        degrees: If True, return angle in degrees; otherwise radians

    Returns:
        Angle between vectors

    RSCT Usage:
        # Measure θ between consecutive certificate states
        angle = bivector_angle(cert_t, cert_t1)
        if angle > 45:  # Large rotation
            sigma += angle / 90  # Contribute to turbulence
    """
    bv_norm = bivector_norm(u, v)

    # sin(θ) = ||u ∧ v|| for unit vectors
    angle_rad = np.arcsin(np.clip(bv_norm, 0, 1))

    if degrees:
        return np.degrees(angle_rad)
    return angle_rad


def wedge_product_matrix(u: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """
    Compute the wedge product as a skew-symmetric matrix.

    u ∧ v = u ⊗ v - v ⊗ u

    This is the bivector representation used in Cayley transforms.

    Args:
        u: First vector [d]
        v: Second vector [d]

    Returns:
        Skew-symmetric matrix [d, d]

    RSCT Usage:
        # Used internally by CayleySteering for context influence
        B = wedge_product_matrix(prior, posterior)
        tau = torch.norm(B, 'fro') / (1 + prior @ posterior)
    """
    return torch.outer(u, v) - torch.outer(v, u)


def bivector_inner_product(B1: torch.Tensor, B2: torch.Tensor) -> float:
    """
    Inner product between two bivectors (skew-symmetric matrices).

    <B1, B2> = (1/2) * tr(B1^T @ B2)

    Args:
        B1: First bivector [d, d]
        B2: Second bivector [d, d]

    Returns:
        Inner product scalar

    RSCT Usage:
        # Compare rotation planes between different failure modes
        similarity = bivector_inner_product(B_mode_21, B_mode_32)
    """
    return 0.5 * torch.trace(B1.T @ B2).item()
