"""
Cayley Transform for Context Steering Detection

The Cayley transform maps a rotation to its generator bivector:
    A = (v ∧ u) / (1 + v · u)

The magnitude τ = ||A|| measures the "steering force" that context
applied to the model's representation.

RSCT APPLICATION:
-----------------
α (purity) could be computed as Cayley steering magnitude:
- Prior: representation given query alone
- Posterior: representation given query + context

High τ = context is steering the output = high α (grounded)
Low τ = context ignored = low α (hallucinating from priors)

This directly detects "vibing" - when RAG systems ignore retrieved context.

Source: Sudjianto, "The Geometry of Attention" (Cayley Steering)
Paper: "Geometric Anti-Vibe Control" achieves 67% → 80% accuracy
"""

import torch
import numpy as np
from typing import Union, Tuple, Optional


class CayleySteering:
    """
    Detect context influence using Cayley transform geometry.

    The Cayley bivector A = (v ⊗ u - u ⊗ v) / (1 + v · u) represents
    the rotation from prior to posterior. Its norm τ measures steering.

    RSCT Integration:
        # Use as α estimator
        steering = CayleySteering()
        tau = steering.compute_steering_magnitude(prior, posterior)
        alpha = min(1.0, tau / 0.1)  # Normalize to [0, 1]
    """

    def __init__(self, vibe_threshold: float = 0.05):
        """
        Initialize the steering detector.

        Args:
            vibe_threshold: Below this τ, model is "vibing" (ignoring context)
                           Default 0.05 from Algorithm 1 in source paper.
        """
        self.vibe_threshold = vibe_threshold

    def _normalize(self, vec: torch.Tensor) -> torch.Tensor:
        """L2 normalization for directional comparison."""
        norm = torch.norm(vec)
        return vec / (norm + 1e-10)

    def compute_steering_magnitude(self,
                                   u_prior: Union[torch.Tensor, np.ndarray],
                                   v_posterior: Union[torch.Tensor, np.ndarray]) -> float:
        """
        Compute the Cayley Bivector magnitude (τ).

        Formula: A = (v ∧ u) / (1 + v · u)
                 τ = ||A||_F

        Args:
            u_prior: Representation given query only [d]
            v_posterior: Representation given query + context [d]

        Returns:
            τ (tau): Steering magnitude. Higher = more context influence.

        RSCT Usage:
            # Estimate purity from context steering
            tau = steering.compute_steering_magnitude(prior, posterior)
            if tau < 0.05:
                # Mode 3.1: Fluent Hallucination (ignoring context)
                flag_low_purity()
        """
        if isinstance(u_prior, np.ndarray):
            u_prior = torch.tensor(u_prior, dtype=torch.float32)
        if isinstance(v_posterior, np.ndarray):
            v_posterior = torch.tensor(v_posterior, dtype=torch.float32)

        # Normalize
        u = self._normalize(u_prior)
        v = self._normalize(v_posterior)

        # Inner product
        dot_prod = torch.dot(v, u)

        # Wedge product as skew-symmetric matrix
        # v ∧ u = v ⊗ u - u ⊗ v
        wedge_prod = torch.outer(v, u) - torch.outer(u, v)

        # Cayley bivector
        A = wedge_prod / (1 + dot_prod + 1e-10)

        # Magnitude (Frobenius norm)
        tau = torch.norm(A, p='fro')

        return tau.item()

    def detect_vibing(self,
                      u_prior: Union[torch.Tensor, np.ndarray],
                      v_posterior: Union[torch.Tensor, np.ndarray]) -> Tuple[bool, float]:
        """
        Detect if the model is "vibing" (ignoring context).

        Args:
            u_prior: Prior representation (query only)
            v_posterior: Posterior representation (query + context)

        Returns:
            (is_vibing, tau): Boolean flag and steering magnitude

        RSCT Usage:
            is_vibing, tau = steering.detect_vibing(prior, posterior)
            if is_vibing:
                # Low α detected - Mode 3.1 or 3.4
                certificate.alpha = tau / self.vibe_threshold
        """
        tau = self.compute_steering_magnitude(u_prior, v_posterior)
        is_vibing = tau < self.vibe_threshold
        return is_vibing, tau

    def compute_rotation_plane(self,
                               u_prior: Union[torch.Tensor, np.ndarray],
                               v_posterior: Union[torch.Tensor, np.ndarray]) -> torch.Tensor:
        """
        Extract the rotation plane (unit bivector) from Cayley transform.

        The plane direction is semantically meaningful - different topics
        rotate in different planes.

        Args:
            u_prior: Prior representation
            v_posterior: Posterior representation

        Returns:
            Unit bivector (skew-symmetric matrix) representing rotation plane

        RSCT Usage:
            # Compare rotation planes across different inputs
            plane_1 = steering.compute_rotation_plane(prior_1, post_1)
            plane_2 = steering.compute_rotation_plane(prior_2, post_2)
            similarity = (plane_1 * plane_2).sum()  # Bivector inner product
        """
        if isinstance(u_prior, np.ndarray):
            u_prior = torch.tensor(u_prior, dtype=torch.float32)
        if isinstance(v_posterior, np.ndarray):
            v_posterior = torch.tensor(v_posterior, dtype=torch.float32)

        u = self._normalize(u_prior)
        v = self._normalize(v_posterior)

        dot_prod = torch.dot(v, u)
        wedge_prod = torch.outer(v, u) - torch.outer(u, v)
        A = wedge_prod / (1 + dot_prod + 1e-10)

        # Normalize to unit bivector
        norm = torch.norm(A, p='fro')
        if norm < 1e-10:
            return A  # Zero rotation
        return A / norm

    def apply_control(self,
                      u_prior: Union[torch.Tensor, np.ndarray],
                      rotation_matrix: torch.Tensor,
                      alpha: float = 0.25) -> torch.Tensor:
        """
        Apply a learned rotation to intervene on stubborn models.

        This is "Geometric Anti-Vibe Control" - force the rotation
        when the model refuses to use context.

        Args:
            u_prior: Prior representation to modify
            rotation_matrix: Learned rotation from successful examples
            alpha: Interpolation strength (default 0.25)

        Returns:
            Modified representation

        Note: This is for model intervention, not RSCT gating.
        """
        if isinstance(u_prior, np.ndarray):
            u_prior = torch.tensor(u_prior, dtype=torch.float32)

        dim = u_prior.shape[0]
        I = torch.eye(dim)

        # Interpolated rotation
        R_alpha = I + alpha * (rotation_matrix - I)

        # Apply rotation
        v_new = R_alpha @ u_prior
        return v_new
