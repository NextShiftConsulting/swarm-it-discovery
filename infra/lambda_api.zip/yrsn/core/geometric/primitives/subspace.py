"""
Subspace Operations for Domain Detection (Type VI)

QR decomposition builds orthonormal bases from domain exemplars.
Support = ||proj_Q(x)|| / ||x|| measures how much a claim "belongs" to a domain.

RSCT APPLICATION:
-----------------
ω (OOD detection) could use domain subspace support:
- Build bases for expected domains (e.g., sr117_mrm, general_ml)
- Compute support on target domain
- Low support = OOD = low ω → Mode 3.4 (OOD Fabrication)

Type VI catches "correct in wrong domain" - the hardest hallucination to detect
because the content IS correct, just not for THIS context.

Source: Sudjianto, "Type VI: Domain Mismatch Hallucination"
"""

import torch
import numpy as np
from typing import Dict, List, Union, Optional, Callable


def orthonormal_basis(exemplars: List[str],
                      embed_fn: Callable[[str], torch.Tensor]) -> torch.Tensor:
    """
    Build QR orthonormal basis from domain exemplar sentences.

    Args:
        exemplars: List of representative sentences for the domain
        embed_fn: Function that embeds text to tensor

    Returns:
        Q: Orthonormal basis [embed_dim, rank] where rank <= len(exemplars)

    RSCT Usage:
        # Build domain bases offline
        sr117_basis = orthonormal_basis(sr117_exemplars, embed)
        ml_basis = orthonormal_basis(ml_exemplars, embed)
    """
    # Embed all exemplars
    embeddings = torch.stack([embed_fn(e) for e in exemplars])  # [N, d]

    # QR decomposition: A = QR where Q is orthonormal
    Q, R = torch.linalg.qr(embeddings.T)  # Q: [d, r]

    return Q


def subspace_support(x: torch.Tensor, Q: torch.Tensor) -> float:
    """
    Compute how much of x lies in the subspace spanned by Q.

    Support = ||proj_Q(x)|| / ||x||

    This is the fraction of x's "energy" in the domain subspace.

    Args:
        x: Query vector [d]
        Q: Orthonormal basis [d, r]

    Returns:
        Support in [0, 1]. Higher = more of x is in the subspace.

    RSCT Usage:
        support = subspace_support(claim_embedding, sr117_basis)
        if support < 0.5:
            # Claim doesn't fit expected domain
            omega = support  # Low ω
    """
    # Project x onto Q's column space
    # proj_Q(x) = Q @ Q^T @ x
    proj = Q @ (Q.T @ x)

    # Support = ||proj|| / ||x||
    x_norm = torch.norm(x)
    if x_norm < 1e-10:
        return 0.0

    proj_norm = torch.norm(proj)
    return (proj_norm / x_norm).item()


class DomainBases:
    """
    Manage multiple domain subspaces for Type VI detection.

    RSCT Integration:
        # Build bases for each target domain
        bases = DomainBases()
        bases.add_domain("sr117_mrm", sr117_exemplars, embed_fn)
        bases.add_domain("general_ml", ml_exemplars, embed_fn)

        # Check if output is in expected domain
        supports = bases.compute_supports(output_embedding)
        if supports["sr117_mrm"] < supports["general_ml"]:
            # Domain mismatch! Mode 3.4 triggered
            flag_ood_fabrication()
    """

    def __init__(self):
        self.bases: Dict[str, torch.Tensor] = {}

    def add_domain(self,
                   name: str,
                   exemplars: List[str],
                   embed_fn: Callable[[str], torch.Tensor]) -> None:
        """Add a domain with its exemplars."""
        self.bases[name] = orthonormal_basis(exemplars, embed_fn)

    def compute_supports(self, x: torch.Tensor) -> Dict[str, float]:
        """Compute support on all domains."""
        return {name: subspace_support(x, Q) for name, Q in self.bases.items()}

    def classify_domain(self, x: torch.Tensor) -> str:
        """Return the best-matching domain."""
        supports = self.compute_supports(x)
        return max(supports, key=supports.get)

    def type_vi_score(self,
                      x: torch.Tensor,
                      expected_domain: str) -> float:
        """
        Compute Type VI score for domain mismatch.

        Score = support(best_wrong) - support(expected)
        Negative = correct domain
        Positive = domain mismatch

        Args:
            x: Claim embedding
            expected_domain: The domain the claim SHOULD be in

        Returns:
            Score in [-1, 1]. Positive = mismatch.

        RSCT Usage:
            score = bases.type_vi_score(output_emb, "sr117_mrm")
            if score > 0.2:
                # Output is in wrong domain
                omega = 1.0 - score  # Reduce ω
        """
        supports = self.compute_supports(x)
        expected_support = supports.get(expected_domain, 0.0)

        # Find best wrong domain
        wrong_supports = {d: s for d, s in supports.items() if d != expected_domain}
        if not wrong_supports:
            return 0.0

        best_wrong_support = max(wrong_supports.values())

        return best_wrong_support - expected_support


# Example domain exemplars for financial MRM
SR117_MRM_EXEMPLARS = [
    "The independent validation unit assessed the model's conceptual soundness.",
    "Outcomes analysis compared model predictions against realized loss experience.",
    "The validation report documented limitations and conditions for use.",
    "Model risk appetite was reviewed by the risk committee and board.",
    "Governance attestation confirmed the model is fit for its intended purpose.",
    "The challenger model was developed independently to benchmark the champion.",
    "SR 11-7 requires ongoing monitoring of model performance in production.",
    "The model inventory was updated to reflect changes in scope and materiality.",
    "Tier 1 models require full independent validation prior to deployment.",
    "The model owner submitted a use case justification to the validation team.",
    "Findings from the validation were tracked and remediated through the issue log.",
    "Pre-implementation review confirmed alignment with the model risk policy.",
    "The validation covered data quality, methodology, and implementation testing.",
    "Back-testing results were reviewed against the model's stated assumptions.",
    "Model limitations identified during validation were disclosed to stakeholders.",
]

GENERAL_ML_EXEMPLARS = [
    "The model achieved 94% accuracy on the held-out test set.",
    "Hyperparameter tuning was performed using cross-validation.",
    "The architecture outperformed baseline benchmarks on standard datasets.",
    "Regularization techniques were applied to reduce overfitting.",
    "Feature importance was computed using permutation-based methods.",
    "The model was fine-tuned on domain-specific data to improve generalization.",
    "Evaluation metrics included precision, recall, and F1 score.",
    "The training loop used Adam optimizer with a learning rate scheduler.",
    "We applied dropout and batch normalization to stabilize training.",
    "The confusion matrix revealed class imbalance in the minority label.",
    "SHAP values were used to explain individual predictions.",
    "The model was exported to ONNX format for production deployment.",
    "Early stopping prevented overfitting on the validation split.",
    "We benchmarked inference latency across GPU and CPU environments.",
    "The ensemble combined gradient boosting and neural network predictions.",
]
