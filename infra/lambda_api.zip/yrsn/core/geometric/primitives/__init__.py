"""
Geometric Algebra Primitives (Substrate-Independent)

These primitives work on ANY AI system - LLMs, Vision, Quantum, Robotics, etc.
They operate on feature embeddings and trajectories, not text.

RSCT Integration:
- bivector.py → σ (turbulence) via rotation angle
- trivector.py → Mode 2.1 (Trajectory Divergence) detection
- cayley.py → α (purity) via context steering
- rotor.py → HybridSimplexRotor, RoRA low-rank adaptation
- subspace.py → ω (OOD) via domain subspace support

For domain-specific examples, see:
- ../financial/ → Yield curve analysis

Source: Sudjianto substack, SSRN 6101568 (RoRA), SSRN 5995254 (GIFT)
"""

from .bivector import (
    bivector_norm,
    bivector_angle,
    wedge_product_matrix,
    bivector_inner_product,
)

from .trivector import (
    trivector_volume,
    trajectory_coplanarity,
    detect_topic_jumps,
)

from .cayley import CayleySteering

from .rotor import (
    RotorLayer,
    LowRankRotorLayer,
    check_rotor_capacity,
)

from .subspace import (
    orthonormal_basis,
    subspace_support,
    DomainBases,
    SR117_MRM_EXEMPLARS,
    GENERAL_ML_EXEMPLARS,
)

__all__ = [
    # Bivector
    'bivector_norm',
    'bivector_angle',
    'wedge_product_matrix',
    'bivector_inner_product',
    # Trivector
    'trivector_volume',
    'trajectory_coplanarity',
    'detect_topic_jumps',
    # Cayley
    'CayleySteering',
    # Rotor
    'RotorLayer',
    'LowRankRotorLayer',
    'check_rotor_capacity',
    # Subspace
    'orthonormal_basis',
    'subspace_support',
    'DomainBases',
    'SR117_MRM_EXEMPLARS',
    'GENERAL_ML_EXEMPLARS',
]
