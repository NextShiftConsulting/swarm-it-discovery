"""
Trivector Operations for Geometric Algebra

A trivector u ∧ v ∧ w represents the oriented parallelepiped (3D volume)
spanned by three vectors. Its volume measures coplanarity.

RSCT APPLICATION:
-----------------
Mode 2.1 (Trajectory Divergence) detection: When three consecutive reasoning
steps have high trivector volume, the trajectory has "jumped out of plane"
indicating a topic shift or erratic reasoning.

If vol(step_i, step_{i+1}, step_{i+2}) > 0.9, flag potential Mode 2.1.

Coherent reasoning typically stays in a 2D manifold even in high-dimensional
space. Breaking coplanarity indicates structural failure.

Source: Sudjianto, "Type V Hallucination: When LLMs Go Off the Rails"
"""

import torch
import numpy as np
from typing import Union, List


def trivector_volume(u: Union[torch.Tensor, np.ndarray],
                     v: Union[torch.Tensor, np.ndarray],
                     w: Union[torch.Tensor, np.ndarray]) -> float:
    """
    Compute the trivector volume ||u ∧ v ∧ w||.

    This is computed via the Gram determinant:
    vol² = det([[u·u, u·v, u·w],
                [v·u, v·v, v·w],
                [w·u, w·v, w·w]])

    Args:
        u: First vector [d]
        v: Second vector [d]
        w: Third vector [d]

    Returns:
        Volume in [0, 1] for normalized inputs.
        Small volume = coplanar (coherent)
        Large volume = out-of-plane jump (erratic)

    RSCT Usage:
        # Detect topic jumps in reasoning trajectory
        for i in range(len(steps) - 2):
            vol = trivector_volume(steps[i], steps[i+1], steps[i+2])
            if vol > 0.9:
                # Mode 2.1: Trajectory left its plane
                flag_topic_jump(i+2)
    """
    if isinstance(u, np.ndarray):
        u = torch.tensor(u, dtype=torch.float32)
    if isinstance(v, np.ndarray):
        v = torch.tensor(v, dtype=torch.float32)
    if isinstance(w, np.ndarray):
        w = torch.tensor(w, dtype=torch.float32)

    # Normalize
    u = u / (torch.norm(u) + 1e-10)
    v = v / (torch.norm(v) + 1e-10)
    w = w / (torch.norm(w) + 1e-10)

    # Build Gram matrix
    G = torch.zeros(3, 3)
    vecs = [u, v, w]
    for i in range(3):
        for j in range(3):
            G[i, j] = torch.dot(vecs[i], vecs[j])

    # Volume² = det(G)
    det_G = torch.det(G)
    det_G = torch.clamp(det_G, min=0.0)  # Numerical safety

    return torch.sqrt(det_G).item()


def trajectory_coplanarity(steps: List[Union[torch.Tensor, np.ndarray]]) -> List[float]:
    """
    Compute trivector volumes for sliding window of 3 consecutive steps.

    Args:
        steps: List of embedding vectors representing reasoning steps

    Returns:
        List of volumes (one fewer than len(steps) - 1)

    RSCT Usage:
        vols = trajectory_coplanarity(reasoning_steps)
        max_vol = max(vols)
        if max_vol > 0.9:
            sigma_contribution = max_vol  # Add to turbulence
    """
    if len(steps) < 3:
        return []

    volumes = []
    for i in range(len(steps) - 2):
        vol = trivector_volume(steps[i], steps[i+1], steps[i+2])
        volumes.append(vol)

    return volumes


def detect_topic_jumps(steps: List[Union[torch.Tensor, np.ndarray]],
                       threshold: float = 0.9) -> List[int]:
    """
    Find indices where the trajectory jumps out of its plane.

    Args:
        steps: List of embedding vectors
        threshold: Volume threshold for jump detection

    Returns:
        List of step indices where jumps occurred

    RSCT Usage:
        jumps = detect_topic_jumps(reasoning_steps)
        if jumps:
            # Mode 2.1 triggered
            flag_trajectory_divergence(jumps[0])
    """
    volumes = trajectory_coplanarity(steps)
    jumps = []

    for i, vol in enumerate(volumes):
        if vol > threshold:
            # Jump occurred at step i+2 (third vector in the triplet)
            jumps.append(i + 2)

    return jumps
