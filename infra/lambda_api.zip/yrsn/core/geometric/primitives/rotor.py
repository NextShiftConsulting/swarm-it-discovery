"""
Rotor Operations for Geometric Algebra

A rotor is the GA object that performs rotations via the sandwich product:
    v' = R v R†

Rotors are parameterized by bivectors (skew-symmetric matrices) and
generated via the exponential map: R = exp(B).

RSCT APPLICATION:
-----------------
HybridSimplexRotor could use the Lie algebra parameterization:
1. Learn B (skew-symmetric generator) instead of R directly
2. Compute R = exp(B) to guarantee orthogonality
3. Low-rank constraint (RoRA) prevents catastrophic forgetting

RoRA's rank-1 constraint forces "minimal geometric action" - the network
finds the ONE rotation plane that solves the task, leaving everything else
unchanged. This is ideal for modular, mergeable representations.

Source:
- Sudjianto, "The Pivot: Recycling Neural Networks with Rotors"
- Sudjianto, "The Geometric Miracle: Fixing Model Merging with RoRA"
- Paper: SSRN 6101568 (RoRA), SSRN 5995254 (GIFT)
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Optional


class RotorLayer(nn.Module):
    """
    A learnable rotation layer using Lie algebra parameterization.

    Instead of learning R directly (which breaks orthogonality under gradient
    descent), we learn the generator B and compute R = exp(B).

    B is constrained to be skew-symmetric: B = M - M^T
    This guarantees R is orthogonal with det(R) = +1.

    RSCT Usage:
        # Replace HybridSimplexRotor's rotation with this
        rotor = RotorLayer(embed_dim)
        features_rotated = rotor(features)  # Guaranteed orthogonal
    """

    def __init__(self, dim: int, init_scale: float = 0.01):
        """
        Initialize the rotor layer.

        Args:
            dim: Dimension of vectors to rotate
            init_scale: Scale for random initialization
        """
        super().__init__()
        # Learn a general matrix M; we'll enforce skew-symmetry
        self.B_param = nn.Parameter(torch.randn(dim, dim) * init_scale)

    def get_bivector(self) -> torch.Tensor:
        """Get the skew-symmetric bivector B = M - M^T."""
        return self.B_param - self.B_param.T

    def get_rotation_matrix(self) -> torch.Tensor:
        """Compute R = exp(B). Guaranteed orthogonal."""
        B = self.get_bivector()
        return torch.matrix_exp(B)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Rotate input vectors.

        Args:
            x: Input tensor [..., dim]

        Returns:
            Rotated tensor [..., dim] with preserved norms
        """
        R = self.get_rotation_matrix()
        return x @ R.T


class LowRankRotorLayer(nn.Module):
    """
    Low-Rank Rotational Adaptation (RoRA).

    Constrains the rotor to rotate in only `rank` planes.
    This forces "minimal geometric action" - the network must find
    the essential rotation that solves the task.

    Key benefits:
    1. Prevents catastrophic forgetting (geometric drift)
    2. Models are mergeable (SLERP on bivectors)
    3. Only 2 * dim * rank parameters (very efficient)

    RSCT Usage:
        # For simplex projection, rank=1 may suffice
        rotor = LowRankRotorLayer(64, rank=1)  # Only 128 params!

        # The rotor finds ONE rotation plane for RSN decomposition
        rsn = rotor(features)
    """

    def __init__(self, dim: int, rank: int = 1, init_scale: float = 0.01):
        """
        Initialize low-rank rotor.

        Args:
            dim: Vector dimension
            rank: Number of rotation planes (1 = most constrained)
            init_scale: Initialization scale
        """
        super().__init__()
        self.dim = dim
        self.rank = rank

        # B = UV^T - VU^T guarantees skew-symmetry with rank <= 2*rank
        self.U = nn.Parameter(torch.randn(dim, rank) * init_scale)
        self.V = nn.Parameter(torch.randn(dim, rank) * init_scale)

    def get_bivector(self) -> torch.Tensor:
        """Get the low-rank skew-symmetric bivector."""
        return self.U @ self.V.T - self.V @ self.U.T

    def get_rotation_matrix(self) -> torch.Tensor:
        """Compute R = exp(B). Guaranteed orthogonal."""
        B = self.get_bivector()
        return torch.matrix_exp(B)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Rotate input through the low-rank rotation."""
        R = self.get_rotation_matrix()
        return x @ R.T

    @staticmethod
    def merge(rotor1: 'LowRankRotorLayer',
              rotor2: 'LowRankRotorLayer',
              alpha: float = 0.5) -> torch.Tensor:
        """
        Merge two rotors via SLERP on their bivectors.

        This is the geometric way to combine skills from two models.
        Unlike weight averaging, this stays on the rotation manifold.

        Args:
            rotor1: First rotor
            rotor2: Second rotor
            alpha: Interpolation weight (0 = rotor1, 1 = rotor2)

        Returns:
            Merged rotation matrix

        RSCT Usage:
            # Merge rotors from different modalities
            R_merged = LowRankRotorLayer.merge(rotor_text, rotor_vision)
        """
        B1 = rotor1.get_bivector()
        B2 = rotor2.get_bivector()

        # SLERP on Lie algebra = linear interpolation on bivectors
        B_merged = (1 - alpha) * B1 + alpha * B2

        return torch.matrix_exp(B_merged)


def check_rotor_capacity(features: torch.Tensor,
                         min_ratio: float = 50.0) -> bool:
    """
    Check if embedding dimension has enough "room to rotate".

    The over-parameterization ratio κ = dim / stable_rank(Cov) should
    be at least 50-60 for RoRA to work well.

    Args:
        features: Feature tensor [batch, dim]
        min_ratio: Minimum acceptable κ

    Returns:
        True if sufficient capacity

    RSCT Usage:
        if not check_rotor_capacity(embeddings):
            # Need higher embedding dimension
            warn("Rotor may not have room to rotate")
    """
    if features.dim() == 1:
        return True  # Can't compute for single vector

    # Compute covariance
    centered = features - features.mean(dim=0)
    cov = centered.T @ centered / (features.shape[0] - 1)

    # Eigenvalues
    eigenvalues = torch.linalg.eigvalsh(cov)
    eigenvalues = torch.clamp(eigenvalues, min=1e-10)

    # Stable rank = trace / max eigenvalue
    stable_rank = eigenvalues.sum() / eigenvalues.max()

    # Over-parameterization ratio
    kappa = features.shape[1] / stable_rank.item()

    return kappa >= min_ratio
