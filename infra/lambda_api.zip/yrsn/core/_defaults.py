"""
YRSN Defaults - Sensible Out-of-Box Configuration
==================================================

All default values with rationale. These work well for most use cases.
Customize only when you have specific domain requirements.

Usage Levels:
    Level 1 (90% of users): Just use defaults - they work
    Level 2 (9% of users): Set domain= to get domain-appropriate defaults
    Level 3 (1% of users): Customize individual parameters

Quick Reference:
    ALPHA_HIGH = 0.70    # Above this = HIGH quality
    ALPHA_LOW = 0.40     # Below this = LOW quality
    TAU_MIN = 0.1        # Never go tighter than this
    TAU_MAX = 5.0        # Never go looser than this
    OMEGA_THRESHOLD = 0.3  # Below this = don't trust α
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional


# =============================================================================
# QUALITY THRESHOLDS
# =============================================================================

# Quality phase boundaries (configurable, NOT formula-derived)
ALPHA_HIGH_THRESHOLD = 0.70  # α > 0.70 = HIGH quality phase
                              # Rationale: 70% relevant signal is "good enough"
                              # for most applications

ALPHA_LOW_THRESHOLD = 0.40   # α < 0.40 = LOW quality phase
                              # Rationale: Below 40% relevant, noise/superfluous
                              # dominates - proceed with caution

# Collapse detection thresholds
POISONING_N_THRESHOLD = 0.30   # N > 0.30 triggers POISONING
                                # Rationale: 30% noise is concerning

DISTRACTION_S_THRESHOLD = 0.40  # S > 0.40 triggers DISTRACTION
                                 # Rationale: 40% superfluous = information overload

CONFLICT_N_THRESHOLD = 0.20    # N > 0.20 AND S > 0.25 = CONFLICT
CONFLICT_S_THRESHOLD = 0.25    # Compound condition

CLASH_VARIANCE_THRESHOLD = 0.15  # Source R variance > 0.15 = CLASH
                                  # Rationale: Sources disagree significantly


# =============================================================================
# TEMPERATURE PARAMETERS
# =============================================================================

TAU_MIN = 0.1   # Minimum temperature (tightest/most deterministic)
                 # Rationale: Never go below 0.1 to avoid numerical issues
                 # and over-confident responses

TAU_MAX = 5.0   # Maximum temperature (loosest/most exploratory)
                 # Rationale: Above 5.0, responses become incoherent
                 # (research shows >2.0 already problematic for most tasks)

TAU_NEUTRAL = 1.0  # Neutral temperature (standard softmax)
                    # Rationale: τ=1.0 means no modification to logits

TAU_FALLBACK = 1.0  # Fallback when OOD (ω < threshold)
                     # Rationale: When uncertain, use neutral temperature

POWER_K = 2.0   # Exponent for POWER activation mode: τ = 1/α^k
                 # Rationale: k=2 provides good sensitivity to quality changes
                 # without being too aggressive

LOG_C = 10.0    # Coefficient for LOG activation mode: τ = 1/log(1+c*α)
                 # Rationale: c=10 compresses the range appropriately


# =============================================================================
# RELIABILITY (OMEGA) PARAMETERS
# =============================================================================

OMEGA_THRESHOLD = 0.3   # Below this, don't trust α measurement
                         # Rationale: ω < 0.3 means significant OOD -
                         # quality measurement is unreliable

OMEGA_PRIOR = 0.5   # Prior for α_ω blending: α_ω = ω*α + (1-ω)*prior
                     # Rationale: 0.5 is uninformative/neutral prior

OMEGA_CRITICAL = 0.1  # Below this, definitely OOD
                       # Rationale: ω < 0.1 means severe distribution shift


# =============================================================================
# TAU MODE - How temperature is determined
# =============================================================================

class TauMode(str, Enum):
    """
    Temperature derivation mode.

    QUICK GUIDE:
        DERIVED  - Default. τ = f(α). Quality-responsive. Use this.
        GATED    - Production. Auto-fallback when OOD. Safer.
        HYBRID   - Migration. Blend derived with fixed anchor.
        OVERRIDE - Testing. Bypass quality, use fixed τ.

    Examples:
        >>> from yrsn.core import TauMode, analyze
        >>>
        >>> # Default - just works
        >>> signal = analyze(context, query)
        >>>
        >>> # Explicit mode
        >>> signal = analyze(context, query, tau_mode=TauMode.GATED)
        >>>
        >>> # Override for testing
        >>> signal = analyze(context, query, tau_mode=TauMode.OVERRIDE, tau_fixed=0.7)
    """

    DERIVED = "derived"
    """τ = f_domain(α) - DEFAULT

    Temperature derived from quality using domain-specific activation.
    Works for 90% of use cases. Start here.

    When to use:
        - Default choice
        - You trust the quality measurement
        - Domain detection works for your use case
    """

    GATED = "gated"
    """τ = f(α) IF ω > threshold ELSE τ_fallback

    Reliability-gated derivation. Falls back to safe temperature
    when input is out-of-distribution (low ω).

    When to use:
        - Production systems
        - Adversarial environments
        - When OOD inputs are common
    """

    HYBRID = "hybrid"
    """τ = w × f(α) + (1-w) × τ_anchor

    Blend derived temperature with a fixed anchor.
    Useful for gradual migration or conservative systems.

    When to use:
        - Migrating from fixed temperature
        - Want some quality-responsiveness but not full
        - Risk-averse applications
    """

    OVERRIDE = "override"
    """τ = τ_fixed (bypass quality derivation)

    Ignore quality, use fixed temperature.

    When to use:
        - Testing and debugging
        - Comparing against baseline
        - Legacy system compatibility
    """


# =============================================================================
# ACTIVATION MODE - Shape of τ = f(α) curve
# =============================================================================

class ActivationMode(str, Enum):
    """
    Domain-specific activation function for τ = f(α).

    QUICK GUIDE:
        LINEAR  - Real-time systems (robotics, AV). Direct response.
        POWER   - Default. Adversarial/symbolic. Amplified response.
        LOG     - Slow physical (industrial). Compressed response.
        SIGMOID - Probabilistic (quantum). Bounded, smooth.

    The activation mode is typically auto-selected based on domain,
    but you can override for specific requirements.
    """

    LINEAR = "linear"
    """τ = 1/α - Direct, predictable response

    Best for: Real-time physical systems (robotics, autonomous vehicles)
    Rationale: Need predictable, immediate response to quality changes
    """

    POWER = "power"
    """τ = 1/α^k - Amplified response (default k=2)

    Best for: Adversarial, symbolic/LLM domains
    Rationale: Magnify small quality changes, be sensitive to degradation
    DEFAULT for most applications.
    """

    LOG = "log"
    """τ = 1/log(1+c*α) - Compressed response

    Best for: Slow physical systems (industrial, HVAC, energy)
    Rationale: Smooth, gradual response; systems need time to stabilize
    """

    SIGMOID = "sigmoid"
    """τ = bounded S-curve

    Best for: Probabilistic/quantum domains, ensemble methods
    Rationale: Bounded, smooth response; irreducible uncertainty expected
    """


# =============================================================================
# DOMAIN PRESETS
# =============================================================================

@dataclass
class DomainPreset:
    """Pre-configured settings for common domains."""

    name: str
    activation: ActivationMode
    tau_mode: TauMode
    omega_threshold: float
    hysteresis: float
    description: str


# Domain presets - use these for quick configuration
DOMAIN_PRESETS = {
    "realtime": DomainPreset(
        name="Real-Time Physical",
        activation=ActivationMode.LINEAR,
        tau_mode=TauMode.GATED,  # Safety: fallback when OOD
        omega_threshold=0.4,     # Higher threshold - safety critical
        hysteresis=0.005,        # React immediately
        description="Robotics, AV, drones. Fast response, safety-critical."
    ),

    "industrial": DomainPreset(
        name="Slow Physical",
        activation=ActivationMode.LOG,
        tau_mode=TauMode.DERIVED,
        omega_threshold=0.3,
        hysteresis=0.10,         # Gradual transitions
        description="Industrial, HVAC, energy. Smooth, gradual response."
    ),

    "adversarial": DomainPreset(
        name="Adversarial",
        activation=ActivationMode.POWER,
        tau_mode=TauMode.GATED,  # Don't trust OOD in adversarial
        omega_threshold=0.4,     # Conservative
        hysteresis=0.01,
        description="Security, fraud, abuse. Assume worst case."
    ),

    "symbolic": DomainPreset(
        name="Symbolic/LLM",
        activation=ActivationMode.POWER,
        tau_mode=TauMode.DERIVED,
        omega_threshold=0.3,
        hysteresis=0.02,
        description="LLM agents, RAG, code assistants. Default choice."
    ),

    "quantum": DomainPreset(
        name="Quantum/Probabilistic",
        activation=ActivationMode.SIGMOID,
        tau_mode=TauMode.DERIVED,
        omega_threshold=0.2,     # Expect uncertainty
        hysteresis=0.05,
        description="Quantum, ensemble methods. Uncertainty expected."
    ),
}

# Alias for common use
DEFAULT_DOMAIN = "symbolic"


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_domain_preset(domain: str) -> DomainPreset:
    """
    Get preset configuration for a domain.

    Args:
        domain: One of 'realtime', 'industrial', 'adversarial',
                'symbolic' (default), 'quantum'

    Returns:
        DomainPreset with recommended settings

    Example:
        >>> preset = get_domain_preset("adversarial")
        >>> print(preset.activation)  # POWER
        >>> print(preset.tau_mode)    # GATED
    """
    if domain not in DOMAIN_PRESETS:
        available = ", ".join(DOMAIN_PRESETS.keys())
        raise ValueError(
            f"Unknown domain '{domain}'. Available: {available}"
        )
    return DOMAIN_PRESETS[domain]


def get_defaults_summary() -> str:
    """
    Print summary of all defaults for quick reference.

    Example:
        >>> print(get_defaults_summary())
    """
    return f"""
YRSN Defaults Summary
=====================

Quality Thresholds:
    ALPHA_HIGH = {ALPHA_HIGH_THRESHOLD}    (above = HIGH quality)
    ALPHA_LOW = {ALPHA_LOW_THRESHOLD}     (below = LOW quality)

Temperature Bounds:
    TAU_MIN = {TAU_MIN}       (minimum, most deterministic)
    TAU_MAX = {TAU_MAX}       (maximum, most exploratory)
    TAU_FALLBACK = {TAU_FALLBACK}   (used when OOD)

Reliability:
    OMEGA_THRESHOLD = {OMEGA_THRESHOLD}   (below = don't trust α)
    OMEGA_PRIOR = {OMEGA_PRIOR}       (neutral prior)

Default Mode:
    TauMode = {TauMode.DERIVED.value}
    ActivationMode = {ActivationMode.POWER.value}
    Domain = {DEFAULT_DOMAIN}

Available Domains:
    {', '.join(DOMAIN_PRESETS.keys())}
"""


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Thresholds
    "ALPHA_HIGH_THRESHOLD",
    "ALPHA_LOW_THRESHOLD",
    "POISONING_N_THRESHOLD",
    "DISTRACTION_S_THRESHOLD",
    "CONFLICT_N_THRESHOLD",
    "CONFLICT_S_THRESHOLD",
    "CLASH_VARIANCE_THRESHOLD",

    # Temperature
    "TAU_MIN",
    "TAU_MAX",
    "TAU_NEUTRAL",
    "TAU_FALLBACK",
    "POWER_K",
    "LOG_C",

    # Reliability
    "OMEGA_THRESHOLD",
    "OMEGA_PRIOR",
    "OMEGA_CRITICAL",

    # Enums
    "TauMode",
    "ActivationMode",

    # Presets
    "DomainPreset",
    "DOMAIN_PRESETS",
    "DEFAULT_DOMAIN",

    # Functions
    "get_domain_preset",
    "get_defaults_summary",
]
