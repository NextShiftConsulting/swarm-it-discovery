"""
YRSN Signal Validator
=====================

Validates YRSN outputs against the Signal Specification v2.0 JSON schemas.

This module provides validation utilities for ensuring that YRSN outputs
conform to the documented signal specification. It can be used in:
- Test suites (pytest fixtures)
- Runtime validation (optional)
- CI/CD pipelines

Usage:
    from yrsn.core.signal_validator import SignalValidator

    validator = SignalValidator()

    # Validate a response dict
    result = validator.validate_response(output_dict)
    if not result.valid:
        print(f"Validation errors: {result.errors}")

    # Validate YRSNSignalLog (from common_logger.py)
    result = validator.validate_signal_log(log_entry)

Part of YRSN Signal Specification v2.0.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import json


@dataclass
class ValidationResult:
    """Result of schema validation."""
    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    schema_version: str = "2.0"


class SignalValidator:
    """
    Validates YRSN signals against the Signal Specification JSON schemas.

    The validator loads schemas from docs/ directory and provides methods
    to validate both raw dicts and typed objects.

    Attributes:
        request_schema: Loaded YRSNRequest schema
        response_schema: Loaded YRSNResponse schema
        strict_mode: If True, treat warnings as errors
    """

    def __init__(
        self,
        schema_dir: Optional[Union[str, Path]] = None,
        strict_mode: bool = False
    ):
        """
        Initialize validator with schema files.

        Args:
            schema_dir: Directory containing schema files. Defaults to docs/
            strict_mode: If True, warnings become errors
        """
        self.strict_mode = strict_mode

        # Find schema directory
        if schema_dir is None:
            # Try to find schema files relative to this file
            this_file = Path(__file__)
            possible_paths = [
                # Schema files are in docs/api/
                this_file.parent.parent.parent.parent / "docs" / "api",  # src/yrsn/core -> docs/api
                this_file.parent.parent.parent.parent / "docs",  # src/yrsn/core -> docs
                Path.cwd() / "docs" / "api",
                Path.cwd() / "docs",
                Path.cwd().parent / "docs" / "api",
                Path.cwd().parent / "docs",
            ]
            for p in possible_paths:
                if (p / "yrsn_response.schema.json").exists():
                    schema_dir = p
                    break

        self.schema_dir = Path(schema_dir) if schema_dir else None

        # Load schemas
        self.request_schema = None
        self.response_schema = None
        self._load_schemas()

    def _load_schemas(self) -> None:
        """Load JSON schemas from disk."""
        if self.schema_dir is None:
            return

        request_path = self.schema_dir / "yrsn_request.schema.json"
        response_path = self.schema_dir / "yrsn_response.schema.json"

        if request_path.exists():
            with open(request_path, encoding="utf-8") as f:
                self.request_schema = json.load(f)

        if response_path.exists():
            with open(response_path, encoding="utf-8") as f:
                self.response_schema = json.load(f)

    def validate_request(self, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate a YRSNRequest dict against the schema.

        Args:
            data: Request dict to validate

        Returns:
            ValidationResult with valid flag and any errors
        """
        return self._validate_against_schema(data, self.request_schema, "request")

    def validate_response(self, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate a YRSNResponse dict against the schema.

        Args:
            data: Response dict to validate

        Returns:
            ValidationResult with valid flag and any errors
        """
        return self._validate_against_schema(data, self.response_schema, "response")

    def validate_signal_log(self, log_entry: Any) -> ValidationResult:
        """
        Validate a YRSNSignalLog object (from common_logger.py).

        Converts the dataclass to response format and validates.

        Args:
            log_entry: YRSNSignalLog instance

        Returns:
            ValidationResult
        """
        # Convert YRSNSignalLog to response-like dict
        response_dict = self._signal_log_to_response(log_entry)
        return self.validate_response(response_dict)

    def validate_example_signals(
        self,
        R: float,
        S: float,
        N: float,
        alpha: Optional[float] = None,
        omega: Optional[float] = None,
        tau: Optional[float] = None,
        **kwargs
    ) -> ValidationResult:
        """
        Validate per-example signals directly.

        Lightweight validation without full schema:
        - R + S + N ≈ 1.0 (within tolerance)
        - Values in [0, 1]
        - Temperature positive if provided

        Args:
            R, S, N: Decomposition values
            alpha: Quality score (optional)
            omega: Reliability score (optional)
            tau: Temperature (optional)
            **kwargs: Additional signals

        Returns:
            ValidationResult
        """
        errors = []
        warnings = []

        # Check R/S/N constraint
        total = R + S + N
        if abs(total - 1.0) > 1e-3:
            if abs(total - 1.0) > 0.1:
                errors.append(f"R+S+N={total:.4f}, expected ~1.0 (deviation > 0.1)")
            else:
                warnings.append(f"R+S+N={total:.6f}, minor deviation from 1.0")

        # Check ranges
        for name, val in [("R", R), ("S", S), ("N", N)]:
            if not (0.0 <= val <= 1.0):
                errors.append(f"{name}={val:.4f} out of range [0, 1]")

        # Check alpha if provided
        if alpha is not None:
            if not (0.0 <= alpha <= 1.0):
                errors.append(f"alpha={alpha:.4f} out of range [0, 1]")

        # Check omega if provided
        if omega is not None:
            if not (0.0 <= omega <= 1.0):
                errors.append(f"omega={omega:.4f} out of range [0, 1]")

        # Check tau if provided
        if tau is not None:
            if tau <= 0:
                errors.append(f"tau={tau:.4f} must be positive")
            elif tau > 100:
                warnings.append(f"tau={tau:.4f} unusually high")

        # Check confidence if provided
        if "confidence" in kwargs:
            conf = kwargs["confidence"]
            if not (0.0 <= conf <= 1.0):
                errors.append(f"confidence={conf:.4f} out of range [0, 1]")

        # Check uncertainty signals if provided
        if "epistemic" in kwargs and kwargs["epistemic"] is not None:
            if not (0.0 <= kwargs["epistemic"] <= 1.0):
                warnings.append(f"epistemic={kwargs['epistemic']:.4f} typically in [0, 1]")

        # In strict mode, warnings become errors
        if self.strict_mode:
            errors.extend(warnings)
            warnings = []

        return ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings
        )

    def _validate_against_schema(
        self,
        data: Dict[str, Any],
        schema: Optional[Dict[str, Any]],
        schema_name: str
    ) -> ValidationResult:
        """Internal schema validation using jsonschema if available."""
        if schema is None:
            return ValidationResult(
                valid=True,
                warnings=[f"No {schema_name} schema loaded, skipping validation"]
            )

        try:
            import jsonschema
        except ImportError:
            return ValidationResult(
                valid=True,
                warnings=["jsonschema not installed, skipping schema validation"]
            )

        errors = []

        try:
            jsonschema.validate(data, schema)
        except jsonschema.ValidationError as e:
            errors.append(f"Schema validation error: {e.message}")
            if e.context:
                for ctx in e.context[:3]:  # Limit to first 3 context errors
                    errors.append(f"  - {ctx.message}")
        except jsonschema.SchemaError as e:
            errors.append(f"Schema error (invalid schema): {e.message}")

        return ValidationResult(valid=len(errors) == 0, errors=errors)

    def _signal_log_to_response(self, log_entry: Any) -> Dict[str, Any]:
        """
        Convert YRSNSignalLog to YRSNResponse format.

        This adapter bridges the internal logging format to the spec format.
        """
        import time

        # Handle both dataclass and dict input
        if hasattr(log_entry, "__dict__"):
            data = vars(log_entry) if not hasattr(log_entry, "asdict") else log_entry.asdict()
        elif hasattr(log_entry, "_asdict"):
            data = log_entry._asdict()
        else:
            data = dict(log_entry)

        # Build response structure
        response = {
            "version": "2.0",
            "request_id": data.get("example_id", "unknown"),
            "timestamp_ms": int(time.time() * 1000),
            "status": {"ok": True},
            "example": {
                "decomposition": {
                    "R": data.get("R", 0.33),
                    "S": data.get("S", 0.33),
                    "N": data.get("N", 0.34),
                },
                "quality": {
                    "alpha": data.get("alpha"),
                    "omega": data.get("omega"),
                    "alpha_omega": data.get("alpha_omega"),
                },
                "temperature": {
                    "tau": data.get("tau"),
                    "beta": data.get("beta"),
                    "phase": data.get("phase"),
                },
                "prediction": {
                    "label": data.get("route"),
                    "confidence": data.get("confidence"),
                    "margin": data.get("margin"),
                },
                "learning": {
                    "reward": data.get("reward"),
                    "was_correct": data.get("was_correct"),
                    "batch_learned": data.get("batch_learned"),
                },
                "memory": {
                    "sdm_locations": data.get("sdm_locations"),
                    "hopfield_patterns": data.get("hopfield_patterns"),
                    "replay_size": data.get("replay_size"),
                },
                "layer_weights": {
                    "sdm_weight": data.get("sdm_weight"),
                    "hopfield_weight": data.get("hopfield_weight"),
                    "ewc_weight": data.get("ewc_weight"),
                    "replay_weight": data.get("replay_weight"),
                },
            }
        }

        # Add uncertainty if present
        if data.get("epistemic") is not None:
            response["example"]["uncertainty"] = {
                "enabled": True,
                "epistemic": data.get("epistemic"),
                "aleatoric": data.get("aleatoric"),
                "entropy": data.get("entropy"),
                "uncertainty_ratio": data.get("uncertainty_ratio"),
            }

        # Add calibration if present
        if data.get("drift_detected") is not None:
            response["aggregate"] = {
                "calibration": {
                    "enabled": True,
                    "drift_detected": data.get("drift_detected"),
                    "drift_confirmed": data.get("drift_confirmed"),
                    "ks_p_values": {
                        "R": data.get("ks_p_value_R"),
                        "S": data.get("ks_p_value_S"),
                        "N": data.get("ks_p_value_N"),
                    },
                    "calibration_state": data.get("calibration_state"),
                    "samples_since_calibration": data.get("samples_since_calibration"),
                }
            }

        return response


# =============================================================================
# Convenience functions
# =============================================================================

def validate_rsn(R: float, S: float, N: float) -> ValidationResult:
    """
    Quick validation of R/S/N values.

    Usage:
        result = validate_rsn(0.5, 0.3, 0.2)
        assert result.valid
    """
    validator = SignalValidator()
    return validator.validate_example_signals(R=R, S=S, N=N)


def validate_output(output: Dict[str, Any]) -> ValidationResult:
    """
    Quick validation of YRSN output dict.

    Usage:
        metrics = calibration_manager.compute_metrics(hidden)
        result = validate_output(metrics)
    """
    validator = SignalValidator()

    # If it looks like raw metrics (has R/S/N at top level), validate signals
    if "R" in output and "S" in output and "N" in output:
        return validator.validate_example_signals(**output)

    # Otherwise try full response validation
    return validator.validate_response(output)


# =============================================================================
# Pytest fixtures (for test integration)
# =============================================================================

def pytest_signal_validator():
    """
    Pytest fixture for signal validation.

    Usage in tests:
        def test_decomposition(signal_validator):
            result = some_function()
            validation = signal_validator.validate_example_signals(**result)
            assert validation.valid, validation.errors

    Add to conftest.py:
        from yrsn.core.signal_validator import pytest_signal_validator

        @pytest.fixture
        def signal_validator():
            return pytest_signal_validator()
    """
    return SignalValidator(strict_mode=True)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "ValidationResult",
    "SignalValidator",
    "validate_rsn",
    "validate_output",
    "pytest_signal_validator",
]
