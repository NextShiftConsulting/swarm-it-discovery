"""
YRSN Signal Specification v2.0 - Pydantic Models
=================================================

Pydantic models that exactly match the JSON schemas in docs/:
- docs/yrsn_request.schema.json
- docs/yrsn_response.schema.json

These provide runtime validation and JSON serialization that is
guaranteed to comply with the spec.

Usage:
    from yrsn.core.signal_spec_pydantic import (
        YRSNRequestModel, YRSNResponseModel, validate_request, validate_response
    )

    # Parse and validate request JSON
    request = YRSNRequestModel.model_validate(json_data)

    # Serialize to JSON
    json_str = response.model_dump_json()

    # Validate against JSON schema
    is_valid = validate_response(response_dict)

Part of YRSN Signal Specification v2.0.
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

try:
    from pydantic import BaseModel, Field, ConfigDict, field_validator
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False
    BaseModel = object  # Fallback for type hints


# Version constant
SPEC_VERSION: Literal["2.0"] = "2.0"


if PYDANTIC_AVAILABLE:

    # =========================================================================
    # Request Models (matching docs/yrsn_request.schema.json)
    # =========================================================================

    class ScopeModel(BaseModel):
        """Scope specification matching schema."""
        model_config = ConfigDict(extra='forbid')

        level: Literal["example", "window", "session", "batch"]
        window_size: Optional[int] = None
        window_id: Optional[str] = None

    class EmbeddingModel(BaseModel):
        """Embedding input specification."""
        model_config = ConfigDict(extra='forbid')

        vector: Optional[List[float]] = None
        model_id: Optional[str] = None
        dims: Optional[int] = Field(None, ge=1)

    class RetrievedItemModel(BaseModel):
        """Single retrieved context item."""
        model_config = ConfigDict(extra='allow')

        id: str = Field(..., min_length=1)
        text: Optional[str] = None
        embedding: Optional[List[float]] = None
        meta: Optional[Dict[str, Any]] = None

    class RetrievedContextModel(BaseModel):
        """Retrieved context specification."""
        model_config = ConfigDict(extra='forbid')

        items: Optional[List[RetrievedItemModel]] = None

    class LabelsModel(BaseModel):
        """Label information."""
        model_config = ConfigDict(extra='forbid')

        true_label: Optional[str] = None
        candidate_labels: Optional[List[str]] = None

    class InputMetaModel(BaseModel):
        """Input metadata."""
        model_config = ConfigDict(extra='allow')

        user_id: Optional[str] = None
        route_id: Optional[str] = None
        domain: Optional[str] = None
        tags: Optional[List[str]] = None

    class InputModel(BaseModel):
        """Input specification matching schema."""
        model_config = ConfigDict(extra='allow')

        kind: Literal["text", "messages", "embedding", "documents", "sensor", "other"]
        content: Optional[Any] = None
        embedding: Optional[EmbeddingModel] = None
        retrieved_context: Optional[RetrievedContextModel] = None
        labels: Optional[LabelsModel] = None
        meta: Optional[InputMetaModel] = None

    class OptionsModel(BaseModel):
        """Options specification matching schema."""
        model_config = ConfigDict(extra='forbid')

        return_prediction: bool = True
        return_uncertainty: bool = False
        return_memory_signals: bool = True
        return_layer_weights: bool = True
        return_calibration: bool = False
        include_distributions: bool = False

    class YRSNRequestModel(BaseModel):
        """
        Complete YRSNRequest matching docs/yrsn_request.schema.json.

        All field names and types exactly match the JSON schema.
        """
        model_config = ConfigDict(extra='forbid')

        version: Literal["2.0"] = SPEC_VERSION
        request_id: str = Field(default_factory=lambda: str(uuid.uuid4()), min_length=1)
        timestamp_ms: int = Field(default_factory=lambda: int(time.time() * 1000), ge=0)
        scope: ScopeModel
        input: InputModel
        options: Optional[OptionsModel] = None
        args: Optional[Dict[str, Any]] = Field(
            default=None,
            description="Dynamic / rare / future args; producers must ignore unknown keys."
        )

    # =========================================================================
    # Response Models (matching docs/yrsn_response.schema.json)
    # =========================================================================

    class StatusModel(BaseModel):
        """Status specification matching schema."""
        model_config = ConfigDict(extra='forbid')

        ok: bool
        warnings: Optional[List[str]] = None
        errors: Optional[List[str]] = None

    class ModulesEnabledModel(BaseModel):
        """Modules enabled tracking."""
        model_config = ConfigDict(extra='forbid')

        decomposition: Optional[bool] = None
        uncertainty: Optional[bool] = None
        calibration: Optional[bool] = None
        memory: Optional[bool] = None

    class ProvenanceModelModel(BaseModel):
        """Model provenance."""
        model_config = ConfigDict(extra='forbid')

        signal_engine: Optional[str] = None
        signal_engine_version: Optional[str] = None
        prediction_model_id: Optional[str] = None
        embedding_model_id: Optional[str] = None

    class ProvenanceComputeModel(BaseModel):
        """Compute provenance."""
        model_config = ConfigDict(extra='forbid')

        latency_ms: Optional[int] = Field(None, ge=0)
        args_applied: Optional[Dict[str, Any]] = None
        modules_enabled: Optional[ModulesEnabledModel] = None

    class ProvenanceModel(BaseModel):
        """Complete provenance."""
        model_config = ConfigDict(extra='forbid')

        model: Optional[ProvenanceModelModel] = None
        compute: Optional[ProvenanceComputeModel] = None

    class DecompositionModel(BaseModel):
        """
        R/S/N decomposition matching schema.
        
        ⚠️ NOTE: R, S, N are PROBABILITIES (normalized scores), not logits.
        They represent normalized decomposition scores that satisfy R + S + N = 1.
        These values come from score_predictor (after softmax) or normalized projections,
        NOT from quality_classifier (which outputs logits).
        """
        model_config = ConfigDict(extra='forbid')

        R: float = Field(..., ge=0, le=1, description="Relevant signal component (probability, normalized)")
        S: float = Field(..., ge=0, le=1, description="Superfluous signal component (probability, normalized)")
        N: float = Field(..., ge=0, le=1, description="Noise signal component (probability, normalized)")
        epsilon: Optional[float] = Field(None, ge=0, description="Reconstruction error (unexplained signal)")
        constraint: Optional[Literal["normalized", "approx_normalized"]] = "normalized"

    class CollapseModel(BaseModel):
        """Collapse detection signals."""
        model_config = ConfigDict(extra='forbid')

        detected: Optional[bool] = Field(None, description="Whether collapse was detected")
        type: Optional[Literal[
            "NONE",
            "POISONING", "DISTRACTION", "CONFLICT", "CLASH",
            "HALLUCINATION", "O_POISONING", "DRIFT",
            "SATURATION", "SPARSITY", "DEAD_NEURON",
            "ENTROPY_COLLAPSE", "CONFIDENCE_COLLAPSE",
            "FORGETTING", "INTERFERENCE", "REPLAY_FAILURE",
            "MODE_COLLAPSE"
        ]] = Field(None, description="Type of collapse detected")
        domain: Optional[Literal["quality", "reliability", "representation", "uncertainty", "distributional"]] = None
        severity: Optional[Literal["none", "low", "medium", "high", "critical"]] = None
        risk: Optional[float] = Field(None, ge=0, le=1, description="Probability of imminent collapse")
        action: Optional[Literal["PROCEED", "CAUTION", "RETRY", "FALLBACK", "HALT"]] = None

    class QualityModel(BaseModel):
        """Quality metrics."""
        model_config = ConfigDict(extra='forbid')

        alpha: Optional[float] = None
        omega: Optional[float] = None
        alpha_omega: Optional[float] = None
        quality_mode: Optional[str] = None

    class TemperatureModel(BaseModel):
        """Temperature signals."""
        model_config = ConfigDict(extra='forbid')

        tau: Optional[float] = None
        beta: Optional[float] = None
        phase: Optional[Literal["EXPLOIT", "EXPLORE", "TRANSITION"]] = None

    class PredictionModel(BaseModel):
        """Prediction signals."""
        model_config = ConfigDict(extra='forbid')

        label: Optional[str] = None
        confidence: Optional[float] = Field(None, ge=0, le=1)
        margin: Optional[float] = None
        label_probabilities: Optional[Dict[str, float]] = None

    class LearningModel(BaseModel):
        """Learning signals."""
        model_config = ConfigDict(extra='forbid')

        reward: Optional[float] = None
        was_correct: Optional[bool] = None
        batch_learned: Optional[bool] = None

    class MemoryModel(BaseModel):
        """Memory layer signals."""
        model_config = ConfigDict(extra='forbid')

        sdm_locations: Optional[int] = Field(None, ge=0)
        hopfield_patterns: Optional[int] = Field(None, ge=0)
        replay_size: Optional[int] = Field(None, ge=0)

    class LayerWeightsModel(BaseModel):
        """Layer weight signals."""
        model_config = ConfigDict(extra='forbid')

        sdm_weight: Optional[float] = None
        hopfield_weight: Optional[float] = None
        ewc_weight: Optional[float] = None
        replay_weight: Optional[float] = None

    class UncertaintyModel(BaseModel):
        """Uncertainty signals (Category 8)."""
        model_config = ConfigDict(extra='forbid')

        enabled: Optional[bool] = None
        epistemic: Optional[float] = None
        aleatoric: Optional[float] = None
        entropy: Optional[float] = None
        uncertainty_ratio: Optional[float] = None
        method: Optional[str] = None
        mc_passes: Optional[int] = Field(None, ge=1)

    class ExampleSignalsModel(BaseModel):
        """Per-example signals matching schema."""
        model_config = ConfigDict(extra='forbid')

        decomposition: Optional[DecompositionModel] = None
        collapse: Optional[CollapseModel] = None
        quality: Optional[QualityModel] = None
        temperature: Optional[TemperatureModel] = None
        prediction: Optional[PredictionModel] = None
        learning: Optional[LearningModel] = None
        memory: Optional[MemoryModel] = None
        layer_weights: Optional[LayerWeightsModel] = None
        uncertainty: Optional[UncertaintyModel] = None
        extras: Optional[Dict[str, Any]] = Field(
            default=None,
            description="Rare/undocumented per-example fields; consumers must ignore unknown keys."
        )

    class KSPValuesModel(BaseModel):
        """KS test p-values."""
        model_config = ConfigDict(extra='forbid')

        R: Optional[float] = Field(None, ge=0, le=1)
        S: Optional[float] = Field(None, ge=0, le=1)
        N: Optional[float] = Field(None, ge=0, le=1)

    class CalibrationModel(BaseModel):
        """Calibration signals (Category 9)."""
        model_config = ConfigDict(extra='forbid')

        enabled: Optional[bool] = None
        drift_detected: Optional[bool] = None
        drift_confirmed: Optional[bool] = None
        ks_p_values: Optional[KSPValuesModel] = None
        calibration_state: Optional[Literal["WEIGHT_DERIVED", "DATA_CALIBRATED", "RECALIBRATING"]] = None
        samples_since_calibration: Optional[int] = Field(None, ge=0)
        window_size: Optional[int] = Field(None, ge=1)
        window_id: Optional[str] = None

    class AggregateSignalsModel(BaseModel):
        """Aggregate/window/session signals."""
        model_config = ConfigDict(extra='forbid')

        calibration: Optional[CalibrationModel] = None
        extras: Optional[Dict[str, Any]] = None

    class MiningModel(BaseModel):
        """Training mining signals."""
        model_config = ConfigDict(extra='forbid')

        mining_strategy: Optional[str] = None
        valid_triplets: Optional[int] = Field(None, ge=0)
        triplet_loss: Optional[float] = None
        curriculum_stage: Optional[int] = Field(None, ge=0)

    class TrainingSignalsModel(BaseModel):
        """Training-only signals."""
        model_config = ConfigDict(extra='forbid')

        mining: Optional[MiningModel] = None
        extras: Optional[Dict[str, Any]] = None

    class YRSNResponseModel(BaseModel):
        """
        Complete YRSNResponse matching docs/yrsn_response.schema.json.

        All field names and types exactly match the JSON schema.
        """
        model_config = ConfigDict(extra='forbid')

        version: Literal["2.0"] = SPEC_VERSION
        request_id: str = Field(..., min_length=1)
        timestamp_ms: int = Field(..., ge=0)
        status: StatusModel
        provenance: Optional[ProvenanceModel] = None
        example: Optional[ExampleSignalsModel] = None
        aggregate: Optional[AggregateSignalsModel] = None
        training: Optional[TrainingSignalsModel] = None


    # =========================================================================
    # Validation Functions
    # =========================================================================

    def validate_request(data: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate request dict against Pydantic model.

        Args:
            data: Request dict to validate

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        try:
            YRSNRequestModel.model_validate(data)
            return True, []
        except Exception as e:
            return False, [str(e)]

    def validate_response(data: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate response dict against Pydantic model.

        Args:
            data: Response dict to validate

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        try:
            YRSNResponseModel.model_validate(data)
            return True, []
        except Exception as e:
            return False, [str(e)]

    def validate_against_json_schema(
        data: Dict[str, Any],
        schema_name: Literal["request", "response"]
    ) -> tuple[bool, List[str]]:
        """
        Validate data against JSON schema files in docs/.

        Args:
            data: Data dict to validate
            schema_name: "request" or "response"

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        try:
            import jsonschema
        except ImportError:
            return True, ["jsonschema not installed, skipping validation"]

        # Find schema file
        this_file = Path(__file__)
        docs_dir = this_file.parent.parent.parent.parent / "docs"

        schema_file = docs_dir / f"yrsn_{schema_name}.schema.json"
        if not schema_file.exists():
            return True, [f"Schema file not found: {schema_file}"]

        with open(schema_file, encoding="utf-8") as f:
            schema = json.load(f)

        errors = []
        try:
            jsonschema.validate(data, schema)
        except jsonschema.ValidationError as e:
            errors.append(f"Schema validation error: {e.message}")
            if e.context:
                for ctx in e.context[:3]:
                    errors.append(f"  - {ctx.message}")

        return len(errors) == 0, errors


    # =========================================================================
    # Factory Functions
    # =========================================================================

    def create_request_model(
        content: Optional[str] = None,
        query: Optional[str] = None,
        kind: str = "text",
        options: Optional[Dict[str, bool]] = None,
        args: Optional[Dict[str, Any]] = None,
        scope_level: str = "example",
    ) -> YRSNRequestModel:
        """Create a validated YRSNRequestModel."""
        input_content = content
        if content and query:
            input_content = {"text": content, "query": query}

        input_model = InputModel(kind=kind, content=input_content)
        scope_model = ScopeModel(level=scope_level)
        options_model = OptionsModel(**(options or {}))

        return YRSNRequestModel(
            scope=scope_model,
            input=input_model,
            options=options_model,
            args=args,
        )

    def create_response_model(
        request_id: str,
        R: float,
        S: float,
        N: float,
        alpha: Optional[float] = None,
        omega: Optional[float] = None,
        tau: Optional[float] = None,
        phase: Optional[str] = None,
        ok: bool = True,
        warnings: Optional[List[str]] = None,
        errors: Optional[List[str]] = None,
    ) -> YRSNResponseModel:
        """Create a validated YRSNResponseModel."""
        # Compute derived values
        total = R + S + N
        if alpha is None and total > 0:
            alpha = R / total
        if omega is None:
            omega = 1.0
        alpha_omega = omega * alpha + (1 - omega) * 0.5 if alpha else None

        if tau is None and alpha_omega and alpha_omega > 0:
            tau = min(10.0, max(0.1, 1.0 / alpha_omega))

        if phase is None and tau:
            if tau < 1.43:
                phase = "EXPLOIT"
            elif tau < 2.50:
                phase = "TRANSITION"
            else:
                phase = "EXPLORE"

        return YRSNResponseModel(
            request_id=request_id,
            timestamp_ms=int(time.time() * 1000),
            status=StatusModel(ok=ok, warnings=warnings, errors=errors),
            example=ExampleSignalsModel(
                decomposition=DecompositionModel(R=R, S=S, N=N),
                quality=QualityModel(alpha=alpha, omega=omega, alpha_omega=alpha_omega),
                temperature=TemperatureModel(tau=tau, phase=phase),
            ),
        )


    # =========================================================================
    # Exports
    # =========================================================================

    __all__ = [
        # Version
        "SPEC_VERSION",
        # Request Models
        "ScopeModel",
        "EmbeddingModel",
        "RetrievedItemModel",
        "RetrievedContextModel",
        "LabelsModel",
        "InputMetaModel",
        "InputModel",
        "OptionsModel",
        "YRSNRequestModel",
        # Response Models
        "StatusModel",
        "ModulesEnabledModel",
        "ProvenanceModelModel",
        "ProvenanceComputeModel",
        "ProvenanceModel",
        "DecompositionModel",
        "CollapseModel",
        "QualityModel",
        "TemperatureModel",
        "PredictionModel",
        "LearningModel",
        "MemoryModel",
        "LayerWeightsModel",
        "UncertaintyModel",
        "ExampleSignalsModel",
        "KSPValuesModel",
        "CalibrationModel",
        "AggregateSignalsModel",
        "MiningModel",
        "TrainingSignalsModel",
        "YRSNResponseModel",
        # Validation
        "validate_request",
        "validate_response",
        "validate_against_json_schema",
        # Factory
        "create_request_model",
        "create_response_model",
        # Flag
        "PYDANTIC_AVAILABLE",
    ]

else:
    # Pydantic not available - provide stubs
    def validate_request(data: Dict[str, Any]) -> tuple[bool, List[str]]:
        return True, ["Pydantic not available"]

    def validate_response(data: Dict[str, Any]) -> tuple[bool, List[str]]:
        return True, ["Pydantic not available"]

    def validate_against_json_schema(
        data: Dict[str, Any],
        schema_name: str
    ) -> tuple[bool, List[str]]:
        return True, ["Pydantic not available"]

    __all__ = [
        "SPEC_VERSION",
        "PYDANTIC_AVAILABLE",
        "validate_request",
        "validate_response",
        "validate_against_json_schema",
    ]
