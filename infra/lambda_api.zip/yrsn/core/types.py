"""
Core data types used throughout the library.

This module contains:
1. ContextBlock, RefinementState - Core internal types
2. TypedDict definitions - JSON-serializable types matching the spec
3. Conversion utilities - Between TypedDict, Dataclass, and Pydantic

Part of YRSN Signal Specification v2.0.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, TypedDict, TYPE_CHECKING

import numpy as np
import numpy.typing as npt

if TYPE_CHECKING:
    from yrsn.core.signal_spec import YRSNRequest, YRSNResponse


# =============================================================================
# Literal Type Aliases
# =============================================================================

ScopeLevelLiteral = Literal["example", "window", "session", "batch"]
InputKindLiteral = Literal["text", "messages", "embedding", "documents", "sensor", "other"]
PhaseLiteral = Literal["EXPLOIT", "EXPLORE", "TRANSITION"]
CalibrationStateLiteral = Literal["WEIGHT_DERIVED", "DATA_CALIBRATED", "RECALIBRATING"]
ConstraintModeLiteral = Literal["normalized", "approx_normalized"]


@dataclass
class ContextBlock:
    """
    Represents a retrieved context segment with YRSN decomposition.

    This is the fundamental unit of context in the library.

    YRSN Decomposition:
        R (Relevant): Information that directly contributes to task performance
        S (Superfluous): Information that neither helps nor hurts—neutral context
        N (Noise): Information that actively degrades performance

    Decomposition Model:
        Y_observed = R + S + N + ε
        where ε is reconstruction error (minimized during decomposition)

    Derived Metrics:
        alpha (α): Quality score = R / (R + S + N)
        alpha_omega (α_ω): Distribution-adjusted quality
        tau (τ): Temperature = 1 / α_ω

    Attributes:
        content: The text content of this context block
        source: Source identifier for this content
        R: Relevant component score (0-1)
        S: Superfluous component score (0-1)
        N: Noise component score (0-1)
        epsilon: Reconstruction error - unexplained signal (≥0)
        omega: OOD reliability score (1.0 = in-distribution), inversely correlated with epsilon
        precision_level: The precision level (0=coarse, 1=medium, 2=fine)
        embedding: Optional vector embedding of the content
    """

    content: str
    source: str = "unknown"

    # YRSN decomposition: Y = R + S + N + ε
    R: float = 0.5  # Relevant
    S: float = 0.3  # Superfluous
    N: float = 0.2  # Noise
    epsilon: float = 0.0  # Reconstruction error (unexplained signal)
    omega: float = 1.0  # OOD reliability (1.0 = fully in-distribution, inversely correlated with ε)

    # Metadata
    precision_level: int = 0
    embedding: Optional[npt.NDArray[np.float32]] = None

    @property
    def alpha(self) -> float:
        """Quality score α = R / (R + S + N)."""
        total = self.R + self.S + self.N
        return self.R / total if total > 0 else 0.0

    @property
    def alpha_omega(self) -> float:
        """Distribution-adjusted quality α_ω = ω·α + (1-ω)·α_prior."""
        alpha_prior = 0.5  # Conservative prior for OOD content
        return self.omega * self.alpha + (1 - self.omega) * alpha_prior

    @property
    def tau(self) -> float:
        """Temperature τ = 1 / α_ω (clamped to avoid division by zero)."""
        return 1.0 / max(self.alpha_omega, 0.01)

    # Backward compatibility aliases
    @property
    def relevance_score(self) -> float:
        """Backward compatible alias for α (quality score)."""
        return self.alpha

    @property
    def quality_score(self) -> float:
        """Backward compatible alias for α_ω (distribution-adjusted quality)."""
        return self.alpha_omega

    def __post_init__(self) -> None:
        """Validate fields after initialization."""
        for name, val in [("R", self.R), ("S", self.S), ("N", self.N), ("omega", self.omega)]:
            if not 0 <= val <= 1:
                raise ValueError(f"{name} must be in [0, 1], got {val}")
        if self.epsilon < 0:
            raise ValueError(f"epsilon must be >= 0, got {self.epsilon}")
        if self.precision_level < 0:
            raise ValueError(f"precision_level must be >= 0, got {self.precision_level}")

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "content": self.content,
            "source": self.source,
            "R": self.R,
            "S": self.S,
            "N": self.N,
            "epsilon": self.epsilon,
            "omega": self.omega,
            "alpha": self.alpha,
            "alpha_omega": self.alpha_omega,
            "tau": self.tau,
            "precision_level": self.precision_level,
        }

    @classmethod
    def from_legacy(cls, content: str, relevance_score: float, **kwargs) -> "ContextBlock":
        """
        Create from legacy format (relevance_score only).

        Maps relevance_score to R/S/N:
        - High relevance → high R, low S, low N
        - Low relevance → low R, high S or N
        """
        R = relevance_score
        S = (1 - relevance_score) * 0.6  # Most non-relevant is superfluous
        N = (1 - relevance_score) * 0.4  # Some is noise
        return cls(content=content, R=R, S=S, N=N, **kwargs)


@dataclass
class RefinementState:
    """
    Tracks the state of iterative refinement process.

    Used by IterativeContextEngine to track convergence.

    Attributes:
        current_context: List of context blocks accumulated so far
        residual_queries: Queries for information still missing
        iteration: Current iteration number (0-indexed)
        precision_achieved: Current precision level (0-1)
        convergence_rate: Rate of precision improvement per iteration
        avg_alpha: Average α across current context
        avg_omega: Average ω across current context
        avg_tau: Average τ across current context
    """

    current_context: List[ContextBlock] = field(default_factory=list)
    residual_queries: List[str] = field(default_factory=list)
    iteration: int = 0
    precision_achieved: float = 0.0
    convergence_rate: float = 0.0

    @property
    def avg_alpha(self) -> float:
        """Average quality score across context."""
        if not self.current_context:
            return 0.0
        return sum(b.alpha for b in self.current_context) / len(self.current_context)

    @property
    def avg_omega(self) -> float:
        """Average OOD reliability across context."""
        if not self.current_context:
            return 1.0
        return sum(b.omega for b in self.current_context) / len(self.current_context)

    @property
    def avg_tau(self) -> float:
        """Average temperature across context."""
        if not self.current_context:
            return 1.0
        return sum(b.tau for b in self.current_context) / len(self.current_context)

    def __post_init__(self) -> None:
        """Validate fields after initialization."""
        if self.iteration < 0:
            raise ValueError(f"iteration must be >= 0, got {self.iteration}")
        if not 0 <= self.precision_achieved <= 1:
            raise ValueError(
                f"precision_achieved must be in [0, 1], got {self.precision_achieved}"
            )


# =============================================================================
# Request TypedDicts (matching docs/yrsn_request.schema.json)
# =============================================================================

class YRSNScopeDict(TypedDict, total=False):
    """Scope specification for signal computation."""
    level: ScopeLevelLiteral
    window_size: int
    window_id: str


class YRSNEmbeddingDict(TypedDict, total=False):
    """Embedding input specification."""
    vector: List[float]
    model_id: str
    dims: int


class RetrievedItemDict(TypedDict, total=False):
    """Single retrieved context item."""
    id: str
    text: str
    embedding: List[float]
    meta: Dict[str, Any]


class RetrievedContextDict(TypedDict, total=False):
    """Retrieved context for RAG-style inputs."""
    items: List[RetrievedItemDict]


class YRSNLabelsDict(TypedDict, total=False):
    """Label information for supervised signals."""
    true_label: str
    candidate_labels: List[str]


class YRSNInputMetaDict(TypedDict, total=False):
    """Metadata for input."""
    user_id: str
    route_id: str
    domain: str
    tags: List[str]


class YRSNInputDict(TypedDict, total=False):
    """Input specification for signal computation."""
    kind: InputKindLiteral
    content: Any
    embedding: YRSNEmbeddingDict
    retrieved_context: RetrievedContextDict
    labels: YRSNLabelsDict
    meta: YRSNInputMetaDict


class YRSNOptionsDict(TypedDict, total=False):
    """Options controlling signal computation."""
    return_prediction: bool
    return_uncertainty: bool
    return_memory_signals: bool
    return_layer_weights: bool
    return_calibration: bool
    include_distributions: bool


class YRSNSessionRefDict(TypedDict, total=False):
    """Session reference for streaming requests (v2.1 extension)."""
    session_id: str
    sequence_number: int
    is_final: bool


class YRSNRequestDict(TypedDict):
    """Complete YRSN request envelope."""
    version: Literal["2.0"]
    request_id: str
    timestamp_ms: int
    scope: YRSNScopeDict
    input: YRSNInputDict
    options: Optional[YRSNOptionsDict]
    args: Optional[Dict[str, Any]]
    session: Optional[YRSNSessionRefDict]  # v2.1 extension


# =============================================================================
# Response TypedDicts (matching docs/yrsn_response.schema.json)
# =============================================================================

class StatusDict(TypedDict, total=False):
    """Response status with optional warnings/errors."""
    ok: bool
    warnings: List[str]
    errors: List[str]


class ModulesEnabledDict(TypedDict, total=False):
    """Tracking which modules were enabled for computation."""
    decomposition: bool
    uncertainty: bool
    calibration: bool
    memory: bool


class ProvenanceModelDict(TypedDict, total=False):
    """Model provenance information."""
    signal_engine: str
    signal_engine_version: str
    prediction_model_id: str
    embedding_model_id: str


class ProvenanceComputeDict(TypedDict, total=False):
    """Computation provenance information."""
    latency_ms: int
    args_applied: Dict[str, Any]
    modules_enabled: ModulesEnabledDict


class ProvenanceDict(TypedDict, total=False):
    """Complete provenance for response."""
    model: ProvenanceModelDict
    compute: ProvenanceComputeDict


class DecompositionDict(TypedDict, total=False):
    """R/S/N decomposition values."""
    R: float
    S: float
    N: float
    epsilon: float  # Reconstruction error (unexplained signal)
    constraint: ConstraintModeLiteral


# Collapse type literals
CollapseTypeLiteral = Literal[
    "NONE",
    "POISONING", "DISTRACTION", "CONFLICT", "CLASH",
    "HALLUCINATION", "O_POISONING", "DRIFT",
    "SATURATION", "SPARSITY", "DEAD_NEURON",
    "ENTROPY_COLLAPSE", "CONFIDENCE_COLLAPSE",
    "FORGETTING", "INTERFERENCE", "REPLAY_FAILURE",
    "MODE_COLLAPSE"
]

CollapseDomainLiteral = Literal["quality", "reliability", "representation", "uncertainty", "distributional"]
CollapseSeverityLiteral = Literal["none", "low", "medium", "high", "critical"]
CollapseActionLiteral = Literal["PROCEED", "CAUTION", "RETRY", "FALLBACK", "HALT"]


class CollapseDict(TypedDict, total=False):
    """Collapse detection signals."""
    detected: bool
    type: CollapseTypeLiteral
    domain: CollapseDomainLiteral
    severity: CollapseSeverityLiteral
    risk: float  # 0-1 probability
    action: CollapseActionLiteral


class QualityDict(TypedDict, total=False):
    """Quality metrics."""
    alpha: float
    omega: float
    alpha_omega: float
    quality_mode: str


class TemperatureDict(TypedDict, total=False):
    """Temperature signals."""
    tau: float
    beta: float
    phase: PhaseLiteral


class PredictionDict(TypedDict, total=False):
    """Prediction signals."""
    label: str
    confidence: float
    margin: float
    label_probabilities: Dict[str, float]


class LearningDict(TypedDict, total=False):
    """Learning signals."""
    reward: float
    was_correct: bool
    batch_learned: bool


class MemoryDict(TypedDict, total=False):
    """Memory layer signals."""
    sdm_locations: int
    hopfield_patterns: int
    replay_size: int


class LayerWeightsDict(TypedDict, total=False):
    """Memory layer weight signals."""
    sdm_weight: float
    hopfield_weight: float
    ewc_weight: float
    replay_weight: float


class UncertaintyDict(TypedDict, total=False):
    """Uncertainty signals (Category 8)."""
    enabled: bool
    epistemic: float
    aleatoric: float
    entropy: float
    uncertainty_ratio: float
    method: str
    mc_passes: int


class ExampleSignalsDict(TypedDict, total=False):
    """Per-example signals (Categories 1-8)."""
    decomposition: DecompositionDict
    collapse: CollapseDict
    quality: QualityDict
    temperature: TemperatureDict
    prediction: PredictionDict
    learning: LearningDict
    memory: MemoryDict
    layer_weights: LayerWeightsDict
    uncertainty: UncertaintyDict
    extras: Dict[str, Any]


class KSPValuesDict(TypedDict, total=False):
    """KS test p-values for drift detection."""
    R: float
    S: float
    N: float


class CalibrationDict(TypedDict, total=False):
    """Calibration signals (Category 9)."""
    enabled: bool
    drift_detected: bool
    drift_confirmed: bool
    ks_p_values: KSPValuesDict
    calibration_state: CalibrationStateLiteral
    samples_since_calibration: int
    window_size: int
    window_id: str


class AggregateSignalsDict(TypedDict, total=False):
    """Aggregate/window/session signals."""
    calibration: CalibrationDict
    extras: Dict[str, Any]


class MiningDict(TypedDict, total=False):
    """Training mining signals."""
    mining_strategy: str
    valid_triplets: int
    triplet_loss: float
    curriculum_stage: int


class TrainingSignalsDict(TypedDict, total=False):
    """Training-only signals."""
    mining: MiningDict
    extras: Dict[str, Any]


# =============================================================================
# Continuity Signals (v2.1 Extension for Streaming)
# =============================================================================

class DriftMetricsDict(TypedDict, total=False):
    """Drift metrics relative to session baseline."""
    R_drift: float
    S_drift: float
    N_drift: float
    alpha_drift: float
    drift_magnitude: float
    drift_direction: str  # "improving", "degrading", "stable"


class ContinuitySignalsDict(TypedDict, total=False):
    """Signals for stream continuity (v2.1 extension)."""
    session_id: str
    sequence_number: int
    window_position: int
    window_complete: bool
    samples_in_window: int
    drift_from_baseline: DriftMetricsDict
    running_R_mean: float
    running_S_mean: float
    running_N_mean: float
    running_alpha_mean: float
    running_alpha_std: float
    alpha_trend: str  # "stable", "improving", "degrading"
    collapse_risk: float  # 0-1 probability
    samples_since_baseline: int


class YRSNResponseDict(TypedDict):
    """Complete YRSN response envelope."""
    version: Literal["2.0"]
    request_id: str
    timestamp_ms: int
    status: StatusDict
    provenance: Optional[ProvenanceDict]
    example: Optional[ExampleSignalsDict]
    aggregate: Optional[AggregateSignalsDict]
    training: Optional[TrainingSignalsDict]
    continuity: Optional[ContinuitySignalsDict]  # v2.1 extension


# =============================================================================
# Session TypedDicts (v2.1 Extension)
# =============================================================================

class SessionConfigDict(TypedDict, total=False):
    """Session configuration options."""
    window_size: int
    calibration_mode: str  # "adaptive", "fixed", "none"
    drift_threshold: float
    collapse_risk_threshold: float
    checkpoint_interval: int
    max_buffer_size: int


class YRSNSessionDict(TypedDict, total=False):
    """Persistent session state for streaming continuity."""
    session_id: str
    created_at: int
    updated_at: int
    config: SessionConfigDict
    calibration_state: CalibrationStateLiteral
    samples_processed: int
    current_sequence: int
    running_R_mean: float
    running_S_mean: float
    running_N_mean: float
    running_R_var: float
    running_S_var: float
    running_N_var: float
    baseline_R_mean: float
    baseline_S_mean: float
    baseline_N_mean: float
    baseline_R_std: float
    baseline_S_std: float
    baseline_N_std: float
    baseline_alpha: float
    baseline_samples: int
    window_R_buffer: List[float]
    window_S_buffer: List[float]
    window_N_buffer: List[float]
    last_checkpoint_at: int
    checkpoint_data: Optional[bytes]


# =============================================================================
# Conversion Utilities
# =============================================================================

def dataclass_to_typed_dict(obj: Any) -> Dict[str, Any]:
    """
    Convert a dataclass (from signal_spec.py) to TypedDict-compatible dict.

    Produces clean JSON-serializable output matching the TypedDict schemas.
    """
    from enum import Enum

    if obj is None:
        return None

    if isinstance(obj, Enum):
        return obj.value

    if isinstance(obj, (list, tuple)):
        return [dataclass_to_typed_dict(item) for item in obj]

    if isinstance(obj, dict):
        return {k: dataclass_to_typed_dict(v) for k, v in obj.items()}

    if hasattr(obj, "__dataclass_fields__"):
        result = {}
        for field_name in obj.__dataclass_fields__:
            value = getattr(obj, field_name)
            if value is not None:
                result[field_name] = dataclass_to_typed_dict(value)
        return result

    return obj


def typed_dict_to_dataclass(
    data: Dict[str, Any],
    target_class: str = "YRSNRequest"
) -> "YRSNRequest | YRSNResponse":
    """
    Convert TypedDict-compatible dict to dataclass.

    Args:
        data: Dict matching TypedDict schema
        target_class: "YRSNRequest" or "YRSNResponse"

    Returns:
        Dataclass instance from signal_spec.py
    """
    from yrsn.core.signal_spec import dict_to_request, create_response

    if target_class == "YRSNRequest":
        return dict_to_request(data)
    elif target_class == "YRSNResponse":
        example = data.get("example", {})
        decomp = example.get("decomposition", {})
        quality = example.get("quality", {})
        temp = example.get("temperature", {})

        return create_response(
            request_id=data.get("request_id", ""),
            R=decomp.get("R", 0.33),
            S=decomp.get("S", 0.33),
            N=decomp.get("N", 0.34),
            alpha=quality.get("alpha"),
            omega=quality.get("omega"),
            tau=temp.get("tau"),
            phase=temp.get("phase"),
            prediction=example.get("prediction"),
            learning=example.get("learning"),
            memory=example.get("memory"),
            layer_weights=example.get("layer_weights"),
            uncertainty=example.get("uncertainty"),
            calibration=data.get("aggregate", {}).get("calibration"),
            warnings=data.get("status", {}).get("warnings"),
            errors=data.get("status", {}).get("errors"),
        )
    else:
        raise ValueError(f"Unknown target class: {target_class}")


def pydantic_to_dataclass(model: Any) -> "YRSNRequest | YRSNResponse":
    """
    Convert Pydantic model to dataclass.

    Args:
        model: YRSNRequestModel or YRSNResponseModel

    Returns:
        YRSNRequest or YRSNResponse dataclass
    """
    if hasattr(model, "model_dump"):
        data = model.model_dump(exclude_none=True)
    else:
        data = model.dict(exclude_none=True)

    model_name = type(model).__name__
    if "Request" in model_name:
        return typed_dict_to_dataclass(data, "YRSNRequest")
    else:
        return typed_dict_to_dataclass(data, "YRSNResponse")


def dataclass_to_pydantic(obj: Any) -> Any:
    """
    Convert dataclass to Pydantic model.

    Args:
        obj: YRSNRequest or YRSNResponse dataclass

    Returns:
        YRSNRequestModel or YRSNResponseModel
    """
    from yrsn.core.signal_spec_pydantic import (
        YRSNRequestModel, YRSNResponseModel, PYDANTIC_AVAILABLE
    )

    if not PYDANTIC_AVAILABLE:
        raise ImportError("Pydantic not available")

    data = dataclass_to_typed_dict(obj)
    class_name = type(obj).__name__

    if "Request" in class_name:
        return YRSNRequestModel.model_validate(data)
    else:
        return YRSNResponseModel.model_validate(data)


def validate_typed_dict(
    data: Dict[str, Any],
    schema: str = "request"
) -> tuple[bool, List[str]]:
    """
    Validate dict against TypedDict schema using Pydantic.

    Args:
        data: Dict to validate
        schema: "request" or "response"

    Returns:
        Tuple of (is_valid, error_messages)
    """
    try:
        from yrsn.core.signal_spec_pydantic import validate_request, validate_response

        if schema == "request":
            return validate_request(data)
        else:
            return validate_response(data)
    except ImportError:
        return True, ["Pydantic not available for validation"]


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Core types
    "ContextBlock",
    "RefinementState",

    # Literal types
    "ScopeLevelLiteral",
    "InputKindLiteral",
    "PhaseLiteral",
    "CalibrationStateLiteral",
    "ConstraintModeLiteral",
    "CollapseTypeLiteral",
    "CollapseDomainLiteral",
    "CollapseSeverityLiteral",
    "CollapseActionLiteral",

    # Request TypedDicts
    "YRSNScopeDict",
    "YRSNEmbeddingDict",
    "RetrievedItemDict",
    "RetrievedContextDict",
    "YRSNLabelsDict",
    "YRSNInputMetaDict",
    "YRSNInputDict",
    "YRSNOptionsDict",
    "YRSNSessionRefDict",
    "YRSNRequestDict",

    # Response TypedDicts
    "StatusDict",
    "ModulesEnabledDict",
    "ProvenanceModelDict",
    "ProvenanceComputeDict",
    "ProvenanceDict",
    "DecompositionDict",
    "CollapseDict",
    "QualityDict",
    "TemperatureDict",
    "PredictionDict",
    "LearningDict",
    "MemoryDict",
    "LayerWeightsDict",
    "UncertaintyDict",
    "ExampleSignalsDict",
    "KSPValuesDict",
    "CalibrationDict",
    "AggregateSignalsDict",
    "MiningDict",
    "TrainingSignalsDict",
    "YRSNResponseDict",

    # Continuity/Streaming TypedDicts
    "DriftMetricsDict",
    "ContinuitySignalsDict",
    "SessionConfigDict",
    "YRSNSessionDict",

    # Conversion utilities
    "dataclass_to_typed_dict",
    "typed_dict_to_dataclass",
    "pydantic_to_dataclass",
    "dataclass_to_pydantic",
    "validate_typed_dict",
]
