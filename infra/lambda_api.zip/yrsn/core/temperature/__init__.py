"""
YRSN Temperature-Quality Duality (τ_α)
======================================

CRITICAL DISTINCTION:
    τ_α (tau_alpha) EMERGES from quality measurement - it is NOT a hyperparameter!

    Unlike LLM API "temperature" which you CHOOSE, YRSN's τ_α is DERIVED:
        Y → Decompose → (R,S,N) → α = R/(R+S+N) → α_ω → τ_α = 1/α_ω

    This is the core YRSN innovation: adaptive behavior emerges from measurement.

TERMINOLOGY CLARIFICATION:
    This module uses "Quality Phases" to mean temperature regimes based on
    quality thresholds (HIGH/MEDIUM/LOW).
    
    This is DIFFERENT from "BBP Phase Transitions" in phase_transitions.py:
    - Quality Phases → Temperature mapping (what temperature regime)
    - BBP Phase Transitions → Rank selection (how many components)
    
    Both are valid uses of "phase" but in different contexts.

Core implementation of the temperature-quality relationship: τ_α = f(α)

The fundamental insight: quality (α) and temperature (τ) are inversely related.
High quality data allows tight (low temperature) reasoning; low quality requires
loose (high temperature) exploration.

Activation Modes:
- linear:  τ = 1/α           (basic inverse)
- power:   τ = 1/α^k         (sharper response, default k=2)
- log:     τ = 1/log(1+cα)   (compressed range)
- sigmoid: τ = bounded smooth mapping (prevents extremes)

Mathematical Foundation:
    Free Energy: F(R,S,N; τ) = E(R,S,N) - τ·H(R,S,N)
    Boltzmann:   P(R,S,N|Y,τ) ∝ exp(-E/τ)

Quality Phases (Temperature Regimes):
    HIGH    (High Quality):   α > 0.70, τ < 1.43
    MEDIUM  (Medium Quality): 0.40 ≤ α ≤ 0.70, 1.43 ≤ τ ≤ 2.50
    LOW     (Low Quality):    α < 0.40, τ > 2.50
"""

import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any

import numpy as np


class ActivationMode(Enum):
    """Temperature activation function modes."""

    LINEAR = "linear"  # τ = 1/α
    POWER = "power"  # τ = 1/α^k (default k=2)
    LOG = "log"  # τ = 1/log(1+cα)
    SIGMOID = "sigmoid"  # Bounded smooth mapping


class QualityPhase(Enum):
    """Content quality phases with critical temperatures."""

    HIGH = "high"  # α > 0.70, τ < 1.43
    MEDIUM = "medium"  # 0.40 ≤ α ≤ 0.70
    LOW = "low"  # α < 0.40, τ > 2.50


@dataclass
class TemperatureParams:
    """
    Parameters for temperature-quality mapping.

    Attributes:
        mode: Activation function mode
        tau_min: Minimum temperature bound (tightest rules)
        tau_max: Maximum temperature bound (loosest rules)
        power_k: Exponent for power mode (default 2.0)
        log_c: Scaling constant for log mode (default 10.0)
        sigmoid_k: Steepness for sigmoid mode (default 12.0)
        sigmoid_alpha_c: Center point for sigmoid (default 0.5)
    """

    mode: ActivationMode = ActivationMode.POWER
    tau_min: float = 0.1
    tau_max: float = 5.0
    power_k: float = 2.0
    log_c: float = 10.0
    sigmoid_k: float = 12.0
    sigmoid_alpha_c: float = 0.5


def map_quality_to_temperature(
    alpha: float,
    mode: str = "power",
    params: Optional[TemperatureParams] = None,
) -> float:
    """
    Map quality score (α) to temperature (τ).

    This is the core activation function for the YRSN temperature-quality
    duality. Different modes provide different response curves.

    Args:
        alpha: Quality score in [0, 1]. Typically α = R/(R+S+N).
        mode: Activation mode: "linear", "power", "log", or "sigmoid"
        params: Custom parameters. Uses defaults if not provided.

    Returns:
        Temperature τ, bounded by [tau_min, tau_max]

    Examples:
        >>> map_quality_to_temperature(0.8, mode="linear")
        1.25
        >>> map_quality_to_temperature(0.8, mode="power")
        1.5625
    """
    if params is None:
        params = TemperatureParams(mode=ActivationMode(mode))

    # Clamp alpha to valid range
    alpha = max(0.001, min(1.0, alpha))  # Avoid division by zero

    if mode == "linear":
        tau = 1.0 / alpha

    elif mode == "power":
        tau = 1.0 / (alpha**params.power_k)

    elif mode == "log":
        tau = 1.0 / math.log(1 + params.log_c * alpha)

    elif mode == "sigmoid":
        # Sigmoid maps α to bounded τ range
        sig = 1.0 / (1.0 + math.exp(-params.sigmoid_k * (params.sigmoid_alpha_c - alpha)))
        tau = params.tau_min + (params.tau_max - params.tau_min) * sig
        return tau  # Already bounded

    else:
        raise ValueError(f"Unknown mode: {mode}. Use 'linear', 'power', 'log', or 'sigmoid'")

    # Clamp to bounds
    return max(params.tau_min, min(params.tau_max, tau))


def get_quality_phase(alpha: float) -> QualityPhase:
    """
    Determine quality phase from α value.

    Phase boundaries correspond to critical temperatures:
    - τ_c1 = 1.43 ≈ 1/0.70 (High → Medium transition)
    - τ_c2 = 2.50 = 1/0.40 (Medium → Low transition)
    """
    if alpha > 0.70:
        return QualityPhase.HIGH
    elif alpha >= 0.40:
        return QualityPhase.MEDIUM
    else:
        return QualityPhase.LOW


def get_phase_characteristics(phase: QualityPhase) -> Dict[str, Any]:
    """Get characteristics and recommendations for a quality phase."""
    characteristics = {
        QualityPhase.HIGH: {
            "alpha_range": (0.70, 1.0),
            "tau_range": (0.1, 1.43),
            "description": "High quality - deterministic reasoning appropriate",
            "recommended_mode": "power",
            "automation_level": "high",
        },
        QualityPhase.MEDIUM: {
            "alpha_range": (0.40, 0.70),
            "tau_range": (1.43, 2.50),
            "description": "Medium quality - mixed deterministic/stochastic",
            "recommended_mode": "sigmoid",
            "automation_level": "moderate",
        },
        QualityPhase.LOW: {
            "alpha_range": (0.0, 0.40),
            "tau_range": (2.50, 5.0),
            "description": "Low quality - stochastic exploration needed",
            "recommended_mode": "linear",
            "automation_level": "low",
        },
    }
    return characteristics[phase]


def compute_y_score(R: float, S: float, N: float) -> float:
    """
    Compute Y-score (quality metric) from YRSN components.

    Y = R + 0.5·S

    The Y-score weights Relevant content fully and Superfluous
    content at half weight. Noise is excluded entirely.
    """
    return R + 0.5 * S


def compute_risk_score(R: float, S: float, N: float) -> float:
    """
    Compute collapse risk score from YRSN components.

    Risk = S + 1.5·N

    Noise is weighted 1.5x more than Superfluous content
    because noise is more likely to cause reasoning failures.
    """
    return S + 1.5 * N


def softmax_with_temperature(scores: np.ndarray, tau: float) -> np.ndarray:
    """
    Apply temperature-scaled softmax.

    Low τ → sharp distribution (confident decisions)
    High τ → soft distribution (uncertain, exploratory)
    """
    if tau <= 0:
        raise ValueError(f"Temperature must be positive, got {tau}")

    scaled = scores / tau
    scaled = scaled - np.max(scaled)  # Numerical stability
    exp_scores = np.exp(scaled)
    return exp_scores / np.sum(exp_scores)


# =============================================================================
# Temperature from Reliability-Adjusted Quality (Claim 2/4)
# =============================================================================


def compute_tau_from_alpha_omega(alpha_omega: float) -> float:
    """
    Compute temperature τ from reliability-adjusted quality α_ω.

    Patent Reference: Claim 2/4 - "Temperature Derivation"

    Formula:
        τ = 1 / α_ω

    This is the core temperature-quality duality: temperature is the
    inverse of reliability-adjusted quality. The formula ensures:
    - High α_ω (good quality, in-distribution) → low τ (confident)
    - Low α_ω (poor quality or OOD) → high τ (exploratory)

    Note: This is MEASUREMENT math, not policy:
    - The α_ω <= 0 check gates validity, not actions
    - Returns inf when quality is undefined

    Args:
        alpha_omega: Reliability-adjusted quality (output of compute_alpha_omega)

    Returns:
        Temperature τ >= 1.0 (since α_ω <= 1.0)
    """
    if alpha_omega <= 0:
        # Validity gate: quality undefined → temperature infinite
        return float("inf")
    return 1.0 / alpha_omega


def compute_tau(alpha: float, omega: float = 1.0, prior: float = 0.5) -> float:
    """
    Compute temperature τ from raw quality and reliability.

    Convenience function combining α_ω computation and τ derivation.

    Formula:
        α_ω = ω × α + (1 - ω) × prior
        τ = 1 / α_ω

    Args:
        alpha: Raw quality score (R/(R+S+N))
        omega: Reliability coefficient (default 1.0 = in-distribution)
        prior: Prior quality estimate (default 0.5)

    Returns:
        Temperature τ
    """
    alpha_omega = omega * alpha + (1 - omega) * prior
    return compute_tau_from_alpha_omega(alpha_omega)


# =============================================================================
# Critical Temperature Constants
# =============================================================================

TAU_CRITICAL_1 = 1.43  # High → Medium quality transition (α = 0.70)
TAU_CRITICAL_2 = 2.50  # Medium → Low quality transition (α = 0.40)

ALPHA_HIGH_THRESHOLD = 0.70
ALPHA_LOW_THRESHOLD = 0.40

# =============================================================================
# Convenience aliases
# =============================================================================

quality_to_temperature = map_quality_to_temperature
tau_from_alpha = map_quality_to_temperature

__all__ = [
    # Enums
    "ActivationMode",
    "QualityPhase",
    # Classes
    "TemperatureParams",
    # Functions
    "map_quality_to_temperature",
    "get_quality_phase",
    "get_phase_characteristics",
    "compute_y_score",
    "compute_risk_score",
    "softmax_with_temperature",
    # Temperature from α_ω (Claim 2/4)
    "compute_tau_from_alpha_omega",
    "compute_tau",
    # Constants
    "TAU_CRITICAL_1",
    "TAU_CRITICAL_2",
    "ALPHA_HIGH_THRESHOLD",
    "ALPHA_LOW_THRESHOLD",
    # Aliases
    "quality_to_temperature",
    "tau_from_alpha",
]
