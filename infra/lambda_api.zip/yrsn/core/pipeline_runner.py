"""
StandardYRSNPipeline - The Orchestrator / Nervous System.

This module implements the IYRSNPipeline protocol and provides the concrete
orchestration that ties all components together:

    Scrub → Extract → Compute τ → Recall Memory → Route → Learn

The pipeline is the "nervous system" that connects:
- Pre-processors (gatekeeping)
- Signal extractors (domain translation)
- Temperature config (quality-temperature duality)
- Experience memory (learning from outcomes)

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    StandardYRSNPipeline                         │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  raw_data ──→ [PreProcessor] ──→ signals ──→ [SignalExtractor] │
    │                     │                              │            │
    │                 (reject?)                     Y=R+S+N           │
    │                     ↓                              ↓            │
    │              REJECT/WARN              ┌────────────────────┐    │
    │                                       │ AdaptiveConfig     │    │
    │                                       │ τ = f(α), phase    │    │
    │                                       └─────────┬──────────┘    │
    │                                                 ↓               │
    │                                       ┌────────────────────┐    │
    │                                       │ ExperienceLayer    │    │
    │                                       │ recall → predict   │    │
    │                                       └─────────┬──────────┘    │
    │                                                 ↓               │
    │                                        PipelineResult           │
    │                                    (stream, τ, confidence)      │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘

Author: YRSN Framework (Rudy Martin)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Tuple, Union
try:
    from typing import Protocol
except ImportError:
    from typing_extensions import Protocol
from enum import Enum
import numpy as np

from .protocols import (
    QualitySignals,
    YRSNDecomposition,
    IPreProcessor,
    ISignalExtractor,
    IContextEncoder,
    PreProcessorChain,
)

from .adaptive_config import (
    AdaptiveTemperatureConfig,
    Stream,
    QualityPhase,
    CollapseType,
    TemperatureResult,
    production_config,
)

from .memristive_experience import (
    MemristiveExperienceLayer,
    MemoryPrediction,
    Experience,
    create_experience_layer,
)


# =============================================================================
# PIPELINE CONTEXT & RESULT
# =============================================================================

@dataclass
class PipelineContext:
    """
    Context passed through the pipeline.

    This is the "state" that flows through each stage.
    """
    raw_data: Any
    cleaned_data: Any = None
    signals: Optional[QualitySignals] = None
    yrsn: Optional[YRSNDecomposition] = None
    temperature: float = 1.0
    temperature_result: Optional[TemperatureResult] = None
    phase: QualityPhase = QualityPhase.MEDIUM
    memory_hint: Optional[MemoryPrediction] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineResult:
    """
    Final result of pipeline processing.

    This is what the caller receives after process().
    """
    stream: Stream
    confidence: float
    temperature: float
    yrsn: YRSNDecomposition
    phase: QualityPhase
    collapse_type: CollapseType
    collapse_risk: float

    # Rejection info
    rejected: bool = False
    rejection_reason: Optional[str] = None

    # Explainability
    signals: Optional[QualitySignals] = None
    memory_contribution: float = 0.0
    similar_cases: int = 0

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_green(self) -> bool:
        return self.stream == Stream.GREEN

    @property
    def is_yellow(self) -> bool:
        return self.stream == Stream.YELLOW

    @property
    def is_red(self) -> bool:
        return self.stream == Stream.RED

    @property
    def needs_human_review(self) -> bool:
        return self.stream in (Stream.YELLOW, Stream.RED)


@dataclass
class LearningResult:
    """Result of learning from an outcome."""
    learned: bool
    learning_rate: float
    reward: float
    temperature: float
    was_override: bool
    accuracy: float
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# VECTORIZATION ADAPTER
# =============================================================================

class VectorizationAdapter:
    """
    Bridges between data formats and vector representations for memory.

    This adapter handles the translation between:
    - Pandas DataFrames → feature vectors
    - Dicts → feature vectors
    - Raw data → context vectors for MemristiveExperienceLayer

    The key insight: the memory layer needs vectors, but the preprocessors
    work with structured data. This adapter is the bridge.
    """

    def __init__(
        self,
        context_dim: int = 256,
        feature_columns: Optional[List[str]] = None,
        category_column: str = "category",
        amount_column: str = "amount",
    ):
        """
        Initialize vectorization adapter.

        Parameters
        ----------
        context_dim : int
            Output vector dimension
        feature_columns : list[str], optional
            Columns to include in vectorization (for DataFrames)
        category_column : str
            Name of category column
        amount_column : str
            Name of amount column
        """
        self.context_dim = context_dim
        self.feature_columns = feature_columns or []
        self.category_column = category_column
        self.amount_column = amount_column

        # Category codebook
        self._category_vectors: Dict[str, np.ndarray] = {}
        self._rng = np.random.RandomState(42)

    def vectorize(
        self,
        data: Any,
        yrsn: YRSNDecomposition,
    ) -> np.ndarray:
        """
        Vectorize data for memory storage/retrieval.

        Parameters
        ----------
        data : Any
            Raw or cleaned data (DataFrame, dict, etc.)
        yrsn : YRSNDecomposition
            The R, S, N decomposition

        Returns
        -------
        np.ndarray
            Context vector for memory
        """
        # Extract category and amount
        category = self._extract_category(data)
        amount = self._extract_amount(data)

        # Build vector using same encoding as MemristiveExperienceLayer
        return self._encode_context(
            R=yrsn.R,
            S=yrsn.S,
            N=yrsn.N,
            category=category,
            amount=amount
        )

    def _extract_category(self, data: Any) -> str:
        """Extract category from various data formats."""
        if hasattr(data, 'iloc'):  # DataFrame
            if self.category_column in data.columns:
                return str(data[self.category_column].iloc[0])
        elif isinstance(data, dict):
            return str(data.get(self.category_column, "default"))
        return "default"

    def _extract_amount(self, data: Any) -> float:
        """Extract amount from various data formats."""
        if hasattr(data, 'iloc'):  # DataFrame
            if self.amount_column in data.columns:
                try:
                    return float(data[self.amount_column].iloc[0])
                except (ValueError, TypeError):
                    return 0.0
        elif isinstance(data, dict):
            try:
                return float(data.get(self.amount_column, 0))
            except (ValueError, TypeError):
                return 0.0
        return 0.0

    def _encode_context(
        self,
        R: float,
        S: float,
        N: float,
        category: str,
        amount: float
    ) -> np.ndarray:
        """Encode to vector (mirrors MemristiveExperienceLayer._encode_context)."""
        dim = self.context_dim

        # Allocate dimensions
        r_dims = dim // 2          # 50% for R
        cat_dims = dim // 4        # 25% for category
        other_dims = dim - r_dims - cat_dims  # 25% for S, N, amount

        # Thermometer encode R
        r_vec = self._thermometer_encode(R, r_dims)

        # Random vector for category (stable per category)
        if category not in self._category_vectors:
            self._category_vectors[category] = self._rng.randn(cat_dims)
        cat_vec = self._category_vectors[category]

        # Thermometer encode S, N, amount
        s_dims = other_dims // 3
        n_dims = other_dims // 3
        amt_dims = other_dims - s_dims - n_dims

        s_vec = self._thermometer_encode(S, s_dims)
        n_vec = self._thermometer_encode(N, n_dims)
        amt_vec = self._thermometer_encode(
            np.clip(np.log10(max(amount, 1)) / 6, 0, 1),
            amt_dims
        )

        # Concatenate
        vec = np.concatenate([r_vec, cat_vec, s_vec, n_vec, amt_vec])

        # Pad/truncate to exact dim
        if len(vec) < dim:
            vec = np.concatenate([vec, np.zeros(dim - len(vec))])
        elif len(vec) > dim:
            vec = vec[:dim]

        return vec.astype(np.float32)

    def _thermometer_encode(self, value: float, dim: int) -> np.ndarray:
        """Thermometer encoding."""
        value = np.clip(value, 0, 1)
        k = int(value * dim)
        vec = np.zeros(dim, dtype=np.float32)
        vec[:k] = 1.0
        return vec


# =============================================================================
# STANDARD YRSN PIPELINE
# =============================================================================

class StandardYRSNPipeline:
    """
    The Orchestrator - implements IYRSNPipeline protocol.

    This class ties together all components into a unified processing flow:
        Scrub → Extract → Compute τ → Recall Memory → Route → Learn

    Usage:
        # Create components
        preprocessor = CleanlabPreProcessor(label_column="label")
        extractor = ApprovalSignalExtractor()

        # Create pipeline
        pipeline = StandardYRSNPipeline(
            preprocessor=preprocessor,
            extractor=extractor,
        )

        # Process data
        result = pipeline.process(raw_df)

        if result.rejected:
            handle_rejection(result.rejection_reason)
        elif result.is_green:
            auto_approve()
        elif result.is_yellow:
            queue_for_review()
        else:
            escalate_to_expert()

        # Learn from outcome
        pipeline.learn(
            raw_data=raw_df,
            predicted_stream=result.stream,
            actual_stream=Stream.GREEN,  # Human decision
            was_override=True
        )
    """

    def __init__(
        self,
        preprocessor: Optional[Union[IPreProcessor, PreProcessorChain]] = None,
        extractor: Optional[ISignalExtractor] = None,
        config: Optional[AdaptiveTemperatureConfig] = None,
        experience_layer: Optional[MemristiveExperienceLayer] = None,
        vectorizer: Optional[VectorizationAdapter] = None,
        enable_memory: bool = True,
    ):
        """
        Initialize the pipeline.

        Parameters
        ----------
        preprocessor : IPreProcessor or PreProcessorChain, optional
            Data scrubbing/quality check. If None, uses passthrough.
        extractor : ISignalExtractor, optional
            Domain-specific Y=R+S+N extraction. If None, uses default.
        config : AdaptiveTemperatureConfig, optional
            Temperature/routing configuration. Defaults to production.
        experience_layer : MemristiveExperienceLayer, optional
            Memory layer for learning. If None, creates new one.
        vectorizer : VectorizationAdapter, optional
            Data vectorization for memory. If None, creates default.
        enable_memory : bool
            Whether to use experience memory for predictions.
        """
        self.preprocessor = preprocessor
        self.extractor = extractor
        self.config = config or production_config()
        self.experience_layer = experience_layer or create_experience_layer()
        self.vectorizer = vectorizer or VectorizationAdapter()
        self.enable_memory = enable_memory

        # Statistics
        self.total_processed = 0
        self.total_rejected = 0
        self.total_green = 0
        self.total_yellow = 0
        self.total_red = 0

    def process(
        self,
        raw_data: Any,
        is_special: bool = False,
        metadata: Optional[Dict[str, Any]] = None
    ) -> PipelineResult:
        """
        Process raw data through the full YRSN pipeline.

        Parameters
        ----------
        raw_data : Any
            Input data (DataFrame, dict, etc.)
        is_special : bool
            If True, apply extra scrubbing for special requests
        metadata : dict, optional
            Additional context

        Returns
        -------
        PipelineResult
            Routing decision with full explainability
        """
        self.total_processed += 1
        ctx = PipelineContext(raw_data=raw_data, metadata=metadata or {})

        # === STAGE 1: SCRUB ===
        if self.preprocessor:
            try:
                ctx.cleaned_data, ctx.signals = self.preprocessor.scrub(raw_data)
            except Exception as e:
                # Scrub failure → reject
                self.total_rejected += 1
                return self._create_rejection_result(
                    f"Preprocessing failed: {str(e)}",
                    ctx
                )

            # Check for hard rejection
            reject, reason = self.preprocessor.should_reject(ctx.signals)
            if reject:
                self.total_rejected += 1
                return self._create_rejection_result(reason, ctx)
        else:
            ctx.cleaned_data = raw_data
            ctx.signals = QualitySignals()  # Default neutral signals

        # === STAGE 2: EXTRACT Y=R+S+N ===
        if self.extractor:
            try:
                ctx.yrsn = self.extractor.extract(ctx.signals)
            except Exception as e:
                # Use default decomposition on error
                ctx.yrsn = YRSNDecomposition(R=0.5, S=0.25, N=0.25)
                ctx.metadata["extraction_error"] = str(e)
        else:
            # Default decomposition from signals
            ctx.yrsn = self._default_extract(ctx.signals)

        # === STAGE 3: COMPUTE TEMPERATURE ===
        alpha = ctx.yrsn.R  # α = R
        ctx.temperature = self.config.compute_tau(alpha=alpha)
        ctx.phase = self.config.get_phase(alpha)
        ctx.temperature_result = TemperatureResult(
            tau=ctx.temperature,
            alpha=alpha,
            mode=self.config.mode,
            step=self.experience_layer._step if self.experience_layer else 0
        )

        # Detect collapse
        collapse_type, collapse_risk = self.config.detect_collapse(
            ctx.yrsn.R, ctx.yrsn.S, ctx.yrsn.N
        )

        # === STAGE 4: QUERY MEMORY ===
        memory_hint = None
        if self.enable_memory and self.experience_layer:
            category = self.vectorizer._extract_category(ctx.cleaned_data)
            amount = self.vectorizer._extract_amount(ctx.cleaned_data)

            memory_hint = self.experience_layer.predict(
                R=ctx.yrsn.R,
                S=ctx.yrsn.S,
                N=ctx.yrsn.N,
                category=category,
                amount=amount,
                metadata=ctx.metadata
            )
            ctx.memory_hint = memory_hint

        # === STAGE 5: ROUTE ===
        result = self._make_routing_decision(ctx, collapse_type, collapse_risk)

        # Update statistics
        if result.is_green:
            self.total_green += 1
        elif result.is_yellow:
            self.total_yellow += 1
        else:
            self.total_red += 1

        return result

    def _make_routing_decision(
        self,
        ctx: PipelineContext,
        collapse_type: CollapseType,
        collapse_risk: float
    ) -> PipelineResult:
        """Make final routing decision combining config and memory."""

        # Memory hint provides confidence and stream suggestion
        if ctx.memory_hint:
            memory_stream = ctx.memory_hint.stream
            memory_confidence = ctx.memory_hint.confidence
            similar_cases = ctx.memory_hint.metadata.get("similar_found", 0)
        else:
            memory_stream = None
            memory_confidence = 0.5
            similar_cases = 0

        # Compute combined confidence
        base_confidence = self.config.compute_confidence(
            R=ctx.yrsn.R,
            S=ctx.yrsn.S,
            N=ctx.yrsn.N,
            classifier_conf=ctx.signals.confidence if ctx.signals else 0.8
        )

        # Blend memory confidence with base
        if similar_cases > 0:
            memory_weight = min(0.5, similar_cases / 20)  # Up to 50% memory influence
            confidence = (1 - memory_weight) * base_confidence + memory_weight * memory_confidence
        else:
            confidence = base_confidence

        # Apply confidence boost from memory
        if self.experience_layer:
            boost = self.experience_layer.get_confidence_boost(
                R=ctx.yrsn.R, S=ctx.yrsn.S, N=ctx.yrsn.N,
                category=self.vectorizer._extract_category(ctx.cleaned_data)
            )
            confidence = min(1.0, confidence * boost)

        # Get stream from config (applies knockouts and threshold logic)
        config_stream = self.config.get_stream(
            confidence=confidence,
            R=ctx.yrsn.R,
            N=ctx.yrsn.N,
            tau=ctx.temperature
        )

        # Final stream: config wins for knockouts, blend otherwise
        if config_stream == Stream.RED and ctx.yrsn.R < self.config.routing.min_R:
            final_stream = Stream.RED  # Knockout
        elif config_stream == Stream.RED and ctx.yrsn.N > self.config.routing.max_N:
            final_stream = Stream.RED  # Knockout
        elif memory_stream and similar_cases >= 5:
            # Trust memory if we have enough similar cases
            final_stream = memory_stream
        else:
            final_stream = config_stream

        return PipelineResult(
            stream=final_stream,
            confidence=confidence,
            temperature=ctx.temperature,
            yrsn=ctx.yrsn,
            phase=ctx.phase,
            collapse_type=collapse_type,
            collapse_risk=collapse_risk,
            rejected=False,
            signals=ctx.signals,
            memory_contribution=similar_cases / max(1, similar_cases + 5),
            similar_cases=similar_cases,
            metadata=ctx.metadata
        )

    def _create_rejection_result(
        self,
        reason: str,
        ctx: PipelineContext
    ) -> PipelineResult:
        """Create a rejection result."""
        return PipelineResult(
            stream=Stream.RED,
            confidence=0.0,
            temperature=self.config.tau_max,
            yrsn=ctx.yrsn or YRSNDecomposition(R=0.0, S=0.0, N=1.0),
            phase=QualityPhase.LOW,
            collapse_type=CollapseType.POISONING,
            collapse_risk=1.0,
            rejected=True,
            rejection_reason=reason,
            signals=ctx.signals,
            metadata=ctx.metadata
        )

    def _default_extract(self, signals: QualitySignals) -> YRSNDecomposition:
        """Default extraction when no extractor is provided."""
        # R = quality * confidence
        r = signals.label_quality * signals.confidence

        # S = ood + verbosity + duplicate
        s = signals.ood_score * 0.3 + signals.verbosity * 0.3
        if signals.is_duplicate:
            s += 0.2

        # N = critical failures + toxicity
        n = signals.toxicity * 0.5
        if signals.is_label_issue:
            n += 0.3
        if signals.critical_failure:
            n = 0.8

        return YRSNDecomposition(R=r, S=s, N=n)

    def learn(
        self,
        raw_data: Any,
        predicted_stream: Stream,
        actual_stream: Stream,
        was_override: bool,
        metadata: Optional[Dict[str, Any]] = None
    ) -> LearningResult:
        """
        Learn from outcome (especially human overrides).

        Parameters
        ----------
        raw_data : Any
            Original input data
        predicted_stream : Stream
            What the system predicted
        actual_stream : Stream
            What actually happened (may differ if overridden)
        was_override : bool
            True if human changed the routing
        metadata : dict, optional
            Additional context

        Returns
        -------
        LearningResult
            Learning statistics
        """
        if not self.experience_layer:
            return LearningResult(
                learned=False,
                learning_rate=0.0,
                reward=0.0,
                temperature=1.0,
                was_override=was_override,
                accuracy=0.0
            )

        # Re-process to get current signals (or use cached)
        if self.preprocessor:
            cleaned_data, signals = self.preprocessor.scrub(raw_data)
        else:
            cleaned_data = raw_data
            signals = QualitySignals()

        if self.extractor:
            yrsn = self.extractor.extract(signals)
        else:
            yrsn = self._default_extract(signals)

        # Extract category/amount
        category = self.vectorizer._extract_category(cleaned_data)
        amount = self.vectorizer._extract_amount(cleaned_data)

        # Record outcome
        result = self.experience_layer.record_outcome(
            R=yrsn.R,
            S=yrsn.S,
            N=yrsn.N,
            category=category,
            amount=amount,
            predicted=predicted_stream,
            actual=actual_stream,
            was_override=was_override,
            metadata=metadata
        )

        return LearningResult(
            learned=True,
            learning_rate=result["learning_rate"],
            reward=result["reward"],
            temperature=result["temperature"],
            was_override=was_override,
            accuracy=result["accuracy"],
            metadata=result
        )

    def batch_learn(self, batch_size: int = 32) -> Dict[str, Any]:
        """Perform batch learning from experience replay."""
        if not self.experience_layer:
            return {"learned": False}
        return self.experience_layer.batch_learn(batch_size)

    def consolidate(self, task_id: str = "current") -> None:
        """Consolidate learning into protected memory."""
        if self.experience_layer:
            self.experience_layer.consolidate(task_id)

    def get_statistics(self) -> Dict[str, Any]:
        """Get pipeline statistics."""
        experience_stats = (
            self.experience_layer.get_statistics()
            if self.experience_layer else {}
        )

        return {
            "total_processed": self.total_processed,
            "total_rejected": self.total_rejected,
            "total_green": self.total_green,
            "total_yellow": self.total_yellow,
            "total_red": self.total_red,
            "rejection_rate": self.total_rejected / max(1, self.total_processed),
            "auto_approve_rate": self.total_green / max(1, self.total_processed),
            **experience_stats
        }


# =============================================================================
# CONVENIENCE FACTORIES
# =============================================================================

def create_pipeline(
    domain: str = "approval",
    preprocessor: Optional[IPreProcessor] = None,
    config_mode: str = "production",
    memory_capacity: int = 10000,
    context_dim: int = 256,
) -> StandardYRSNPipeline:
    """
    Factory function to create a configured pipeline.

    Parameters
    ----------
    domain : str
        Domain for signal extraction: approval, text, multi_annotator, rag, ner
    preprocessor : IPreProcessor, optional
        Custom preprocessor. If None, uses passthrough.
    config_mode : str
        Configuration mode: production, learning, shadow, conservative
    memory_capacity : int
        Experience memory capacity
    context_dim : int
        Context vector dimension

    Returns
    -------
    StandardYRSNPipeline
        Configured pipeline ready to use
    """
    # Import extractors (avoid circular imports)
    try:
        from .protocols import YRSNDecomposition, QualitySignals
    except ImportError:
        pass

    # Create extractor based on domain
    # NOTE: In production, import from yrsn_iars.adapters
    extractor = _create_default_extractor(domain)

    # Create experience layer
    experience_layer = create_experience_layer(
        mode=config_mode,
        context_dim=context_dim,
        memory_capacity=memory_capacity
    )

    return StandardYRSNPipeline(
        preprocessor=preprocessor,
        extractor=extractor,
        config=experience_layer.config,
        experience_layer=experience_layer,
        vectorizer=VectorizationAdapter(context_dim=context_dim),
        enable_memory=True
    )


def _create_default_extractor(domain: str):
    """Create a simple default extractor (for standalone use)."""

    class DefaultExtractor:
        """Simple extractor that maps signals to R, S, N."""

        def __init__(self, domain: str):
            self.domain = domain

        def extract(self, signals: QualitySignals) -> YRSNDecomposition:
            r = signals.label_quality * signals.confidence
            s = signals.verbosity * 0.3 + signals.ood_score * 0.2
            n = signals.toxicity * 0.5 + (0.3 if signals.is_label_issue else 0.0)
            return YRSNDecomposition(R=r, S=s, N=n)

        def get_critical_rules(self) -> Dict[str, Any]:
            return {"domain": self.domain}

    return DefaultExtractor(domain)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "PipelineContext",
    "PipelineResult",
    "LearningResult",
    "VectorizationAdapter",
    "StandardYRSNPipeline",
    "create_pipeline",
]
