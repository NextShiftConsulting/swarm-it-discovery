"""
YRSN Session Manager for Streaming Continuity
==============================================

Implements the session-based architecture for handling streaming data
with state continuity across requests.

Key Components:
- YRSNSession: Persistent session state dataclass
- YRSNSessionManager: Manages session lifecycle and state
- SessionStorage: Abstract storage interface with implementations
- ContinuitySignals: Computed signals for stream continuity

Usage:
    from yrsn.core.session import YRSNSessionManager

    # Create manager
    manager = YRSNSessionManager()

    # Create session
    session = manager.create_session(window_size=256)

    # Process streaming requests
    for chunk in data_stream:
        request = create_request(content=chunk)
        response = manager.process_request(request, session)

        if response.continuity.collapse_risk > 0.8:
            handle_collapse_warning()

    # Close session
    final_stats = manager.close_session(session.session_id)

Part of YRSN Signal Specification v2.0/2.1.
"""

from __future__ import annotations

import math
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from yrsn.core.types import (
    CalibrationStateLiteral,
    ContinuitySignalsDict,
    DriftMetricsDict,
    SessionConfigDict,
    YRSNSessionDict,
)


# =============================================================================
# Enums
# =============================================================================

class CalibrationMode(str, Enum):
    """Session calibration mode."""
    ADAPTIVE = "adaptive"  # Recalibrate on drift detection
    FIXED = "fixed"  # Use initial baseline only
    NONE = "none"  # No calibration tracking


class DriftDirection(str, Enum):
    """Direction of signal drift."""
    IMPROVING = "improving"  # Alpha increasing
    DEGRADING = "degrading"  # Alpha decreasing
    STABLE = "stable"  # Within threshold


class TrendState(str, Enum):
    """Alpha trend state."""
    STABLE = "stable"
    IMPROVING = "improving"
    DEGRADING = "degrading"


# =============================================================================
# Session Configuration
# =============================================================================

@dataclass
class SessionConfig:
    """Configuration for YRSN session."""
    window_size: int = 256
    calibration_mode: CalibrationMode = CalibrationMode.ADAPTIVE
    drift_threshold: float = 0.05  # KS p-value threshold
    collapse_risk_threshold: float = 0.7
    checkpoint_interval: int = 100  # Samples between checkpoints
    max_buffer_size: int = 1000  # Maximum samples to buffer
    warmup_samples: int = 50  # Samples before baseline is established
    trend_window: int = 20  # Samples for trend detection

    def to_dict(self) -> SessionConfigDict:
        """Convert to TypedDict."""
        return {
            "window_size": self.window_size,
            "calibration_mode": self.calibration_mode.value,
            "drift_threshold": self.drift_threshold,
            "collapse_risk_threshold": self.collapse_risk_threshold,
            "checkpoint_interval": self.checkpoint_interval,
            "max_buffer_size": self.max_buffer_size,
        }


# =============================================================================
# Running Statistics (Welford's algorithm)
# =============================================================================

@dataclass
class RunningStats:
    """Running mean and variance using Welford's algorithm."""
    count: int = 0
    mean: float = 0.0
    M2: float = 0.0  # Sum of squared differences

    def update(self, value: float) -> None:
        """Add a new value to the running statistics."""
        self.count += 1
        delta = value - self.mean
        self.mean += delta / self.count
        delta2 = value - self.mean
        self.M2 += delta * delta2

    @property
    def variance(self) -> float:
        """Population variance."""
        if self.count < 2:
            return 0.0
        return self.M2 / self.count

    @property
    def std(self) -> float:
        """Population standard deviation."""
        return math.sqrt(self.variance)


# =============================================================================
# Session State
# =============================================================================

@dataclass
class YRSNSession:
    """
    Persistent session state for streaming continuity.

    Tracks running statistics, baseline, and window buffers for
    drift detection and continuity signal computation.
    """
    # Identity
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: int = field(default_factory=lambda: int(time.time() * 1000))
    updated_at: int = field(default_factory=lambda: int(time.time() * 1000))

    # Configuration
    config: SessionConfig = field(default_factory=SessionConfig)

    # State
    calibration_state: CalibrationStateLiteral = "WEIGHT_DERIVED"
    samples_processed: int = 0
    current_sequence: int = 0

    # Running statistics (Welford's algorithm)
    R_stats: RunningStats = field(default_factory=RunningStats)
    S_stats: RunningStats = field(default_factory=RunningStats)
    N_stats: RunningStats = field(default_factory=RunningStats)
    alpha_stats: RunningStats = field(default_factory=RunningStats)

    # Baseline (established after warmup)
    baseline_established: bool = False
    baseline_R_mean: float = 0.0
    baseline_S_mean: float = 0.0
    baseline_N_mean: float = 0.0
    baseline_R_std: float = 0.0
    baseline_S_std: float = 0.0
    baseline_N_std: float = 0.0
    baseline_alpha: float = 0.0
    baseline_samples: int = 0

    # Window buffers for drift detection
    window_R_buffer: List[float] = field(default_factory=list)
    window_S_buffer: List[float] = field(default_factory=list)
    window_N_buffer: List[float] = field(default_factory=list)
    window_alpha_buffer: List[float] = field(default_factory=list)

    # Trend detection buffer
    recent_alphas: List[float] = field(default_factory=list)

    # Checkpointing
    last_checkpoint_at: int = 0

    def update(self, R: float, S: float, N: float) -> None:
        """Update session with new R/S/N values."""
        self.samples_processed += 1
        self.current_sequence += 1
        self.updated_at = int(time.time() * 1000)

        # Compute alpha
        total = R + S + N
        alpha = R / total if total > 0 else 0.5

        # Update running statistics
        self.R_stats.update(R)
        self.S_stats.update(S)
        self.N_stats.update(N)
        self.alpha_stats.update(alpha)

        # Update window buffers
        self._update_buffer(self.window_R_buffer, R)
        self._update_buffer(self.window_S_buffer, S)
        self._update_buffer(self.window_N_buffer, N)
        self._update_buffer(self.window_alpha_buffer, alpha)

        # Update trend buffer
        self._update_buffer(self.recent_alphas, alpha, self.config.trend_window)

        # Establish baseline after warmup
        if not self.baseline_established and self.samples_processed >= self.config.warmup_samples:
            self._establish_baseline()

    def _update_buffer(self, buffer: List[float], value: float, max_size: int = None) -> None:
        """Update a sliding window buffer."""
        if max_size is None:
            max_size = self.config.window_size
        buffer.append(value)
        if len(buffer) > max_size:
            buffer.pop(0)

    def _establish_baseline(self) -> None:
        """Establish baseline from current running statistics."""
        self.baseline_R_mean = self.R_stats.mean
        self.baseline_S_mean = self.S_stats.mean
        self.baseline_N_mean = self.N_stats.mean
        self.baseline_R_std = self.R_stats.std
        self.baseline_S_std = self.S_stats.std
        self.baseline_N_std = self.N_stats.std
        self.baseline_alpha = self.alpha_stats.mean
        self.baseline_samples = self.samples_processed
        self.baseline_established = True
        self.calibration_state = "DATA_CALIBRATED"

    def compute_drift(self) -> DriftMetricsDict:
        """Compute drift metrics relative to baseline."""
        if not self.baseline_established:
            return {
                "R_drift": 0.0,
                "S_drift": 0.0,
                "N_drift": 0.0,
                "alpha_drift": 0.0,
                "drift_magnitude": 0.0,
                "drift_direction": "stable",
            }

        R_drift = self.R_stats.mean - self.baseline_R_mean
        S_drift = self.S_stats.mean - self.baseline_S_mean
        N_drift = self.N_stats.mean - self.baseline_N_mean
        alpha_drift = self.alpha_stats.mean - self.baseline_alpha

        # L2 distance
        drift_magnitude = math.sqrt(R_drift**2 + S_drift**2 + N_drift**2)

        # Direction based on alpha
        if alpha_drift > self.config.drift_threshold:
            direction = "improving"
        elif alpha_drift < -self.config.drift_threshold:
            direction = "degrading"
        else:
            direction = "stable"

        return {
            "R_drift": R_drift,
            "S_drift": S_drift,
            "N_drift": N_drift,
            "alpha_drift": alpha_drift,
            "drift_magnitude": drift_magnitude,
            "drift_direction": direction,
        }

    def compute_trend(self) -> str:
        """Compute alpha trend from recent samples."""
        if len(self.recent_alphas) < 5:
            return "stable"

        # Simple linear regression slope
        n = len(self.recent_alphas)
        x_mean = (n - 1) / 2
        y_mean = sum(self.recent_alphas) / n

        numerator = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(self.recent_alphas))
        denominator = sum((i - x_mean) ** 2 for i in range(n))

        if denominator == 0:
            return "stable"

        slope = numerator / denominator

        # Threshold for significance
        if slope > 0.001:
            return "improving"
        elif slope < -0.001:
            return "degrading"
        else:
            return "stable"

    def compute_collapse_risk(self) -> float:
        """
        Compute collapse risk (0-1) based on multiple signals.

        Factors:
        - Low alpha (< 0.3)
        - High N (> 0.4)
        - Degrading trend
        - Drift from baseline
        """
        risk = 0.0

        # Current alpha risk
        current_alpha = self.alpha_stats.mean if self.alpha_stats.count > 0 else 0.5
        if current_alpha < 0.3:
            risk += 0.4 * (0.3 - current_alpha) / 0.3
        elif current_alpha < 0.5:
            risk += 0.2 * (0.5 - current_alpha) / 0.2

        # High noise risk
        current_N = self.N_stats.mean if self.N_stats.count > 0 else 0.33
        if current_N > 0.4:
            risk += 0.3 * min(1.0, (current_N - 0.4) / 0.3)

        # Trend risk
        trend = self.compute_trend()
        if trend == "degrading":
            risk += 0.2

        # Drift risk
        if self.baseline_established:
            drift = self.compute_drift()
            if drift["drift_direction"] == "degrading":
                risk += 0.1 * min(1.0, drift["drift_magnitude"] / 0.2)

        return min(1.0, max(0.0, risk))

    def to_dict(self) -> YRSNSessionDict:
        """Convert to TypedDict for serialization."""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "config": self.config.to_dict(),
            "calibration_state": self.calibration_state,
            "samples_processed": self.samples_processed,
            "current_sequence": self.current_sequence,
            "running_R_mean": self.R_stats.mean,
            "running_S_mean": self.S_stats.mean,
            "running_N_mean": self.N_stats.mean,
            "running_R_var": self.R_stats.variance,
            "running_S_var": self.S_stats.variance,
            "running_N_var": self.N_stats.variance,
            "baseline_R_mean": self.baseline_R_mean,
            "baseline_S_mean": self.baseline_S_mean,
            "baseline_N_mean": self.baseline_N_mean,
            "baseline_R_std": self.baseline_R_std,
            "baseline_S_std": self.baseline_S_std,
            "baseline_N_std": self.baseline_N_std,
            "baseline_alpha": self.baseline_alpha,
            "baseline_samples": self.baseline_samples,
            "window_R_buffer": self.window_R_buffer.copy(),
            "window_S_buffer": self.window_S_buffer.copy(),
            "window_N_buffer": self.window_N_buffer.copy(),
            "last_checkpoint_at": self.last_checkpoint_at,
        }

    @classmethod
    def from_dict(cls, data: YRSNSessionDict) -> "YRSNSession":
        """Create session from TypedDict."""
        session = cls(
            session_id=data.get("session_id", str(uuid.uuid4())),
            created_at=data.get("created_at", int(time.time() * 1000)),
            updated_at=data.get("updated_at", int(time.time() * 1000)),
        )

        # Restore config
        if "config" in data:
            cfg = data["config"]
            session.config = SessionConfig(
                window_size=cfg.get("window_size", 256),
                calibration_mode=CalibrationMode(cfg.get("calibration_mode", "adaptive")),
                drift_threshold=cfg.get("drift_threshold", 0.05),
                collapse_risk_threshold=cfg.get("collapse_risk_threshold", 0.7),
                checkpoint_interval=cfg.get("checkpoint_interval", 100),
                max_buffer_size=cfg.get("max_buffer_size", 1000),
            )

        # Restore state
        session.calibration_state = data.get("calibration_state", "WEIGHT_DERIVED")
        session.samples_processed = data.get("samples_processed", 0)
        session.current_sequence = data.get("current_sequence", 0)

        # Restore running stats (approximate from means)
        if "running_R_mean" in data:
            n = session.samples_processed
            session.R_stats = RunningStats(count=n, mean=data["running_R_mean"], M2=data.get("running_R_var", 0) * n)
            session.S_stats = RunningStats(count=n, mean=data["running_S_mean"], M2=data.get("running_S_var", 0) * n)
            session.N_stats = RunningStats(count=n, mean=data["running_N_mean"], M2=data.get("running_N_var", 0) * n)

        # Restore baseline
        if data.get("baseline_samples", 0) > 0:
            session.baseline_established = True
            session.baseline_R_mean = data.get("baseline_R_mean", 0.0)
            session.baseline_S_mean = data.get("baseline_S_mean", 0.0)
            session.baseline_N_mean = data.get("baseline_N_mean", 0.0)
            session.baseline_R_std = data.get("baseline_R_std", 0.0)
            session.baseline_S_std = data.get("baseline_S_std", 0.0)
            session.baseline_N_std = data.get("baseline_N_std", 0.0)
            session.baseline_alpha = data.get("baseline_alpha", 0.0)
            session.baseline_samples = data.get("baseline_samples", 0)

        # Restore buffers
        session.window_R_buffer = list(data.get("window_R_buffer", []))
        session.window_S_buffer = list(data.get("window_S_buffer", []))
        session.window_N_buffer = list(data.get("window_N_buffer", []))

        session.last_checkpoint_at = data.get("last_checkpoint_at", 0)

        return session


# =============================================================================
# Continuity Signals
# =============================================================================

@dataclass
class ContinuitySignals:
    """Computed signals for stream continuity."""
    session_id: str = ""
    sequence_number: int = 0

    # Window state
    window_position: int = 0
    window_complete: bool = False
    samples_in_window: int = 0

    # Drift
    drift_from_baseline: Optional[DriftMetricsDict] = None

    # Running aggregates
    running_R_mean: float = 0.0
    running_S_mean: float = 0.0
    running_N_mean: float = 0.0
    running_alpha_mean: float = 0.0
    running_alpha_std: float = 0.0

    # Trend and risk
    alpha_trend: str = "stable"
    collapse_risk: float = 0.0
    samples_since_baseline: int = 0

    def to_dict(self) -> ContinuitySignalsDict:
        """Convert to TypedDict."""
        return {
            "session_id": self.session_id,
            "sequence_number": self.sequence_number,
            "window_position": self.window_position,
            "window_complete": self.window_complete,
            "samples_in_window": self.samples_in_window,
            "drift_from_baseline": self.drift_from_baseline,
            "running_R_mean": self.running_R_mean,
            "running_S_mean": self.running_S_mean,
            "running_N_mean": self.running_N_mean,
            "running_alpha_mean": self.running_alpha_mean,
            "running_alpha_std": self.running_alpha_std,
            "alpha_trend": self.alpha_trend,
            "collapse_risk": self.collapse_risk,
            "samples_since_baseline": self.samples_since_baseline,
        }


# =============================================================================
# Storage Backends
# =============================================================================

class SessionStorage(ABC):
    """Abstract session storage interface."""

    @abstractmethod
    def save(self, session: YRSNSession) -> None:
        """Save session to storage."""
        pass

    @abstractmethod
    def load(self, session_id: str) -> Optional[YRSNSession]:
        """Load session from storage."""
        pass

    @abstractmethod
    def delete(self, session_id: str) -> bool:
        """Delete session from storage."""
        pass

    @abstractmethod
    def list_sessions(self) -> List[str]:
        """List all session IDs."""
        pass


class InMemorySessionStorage(SessionStorage):
    """In-memory session storage (for development/testing)."""

    def __init__(self) -> None:
        self._sessions: Dict[str, YRSNSessionDict] = {}

    def save(self, session: YRSNSession) -> None:
        """Save session to memory."""
        self._sessions[session.session_id] = session.to_dict()

    def load(self, session_id: str) -> Optional[YRSNSession]:
        """Load session from memory."""
        data = self._sessions.get(session_id)
        if data is None:
            return None
        return YRSNSession.from_dict(data)

    def delete(self, session_id: str) -> bool:
        """Delete session from memory."""
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False

    def list_sessions(self) -> List[str]:
        """List all session IDs."""
        return list(self._sessions.keys())


# =============================================================================
# Session Manager
# =============================================================================

class YRSNSessionManager:
    """
    Manages session lifecycle for streaming APIs.

    Provides:
    - Session creation with configuration
    - Request processing with continuity signals
    - Session persistence via storage backends
    - Baseline export/import for cross-session continuity
    """

    def __init__(self, storage: Optional[SessionStorage] = None) -> None:
        """
        Initialize session manager.

        Args:
            storage: Session storage backend (defaults to in-memory)
        """
        self.storage = storage or InMemorySessionStorage()
        self._active_sessions: Dict[str, YRSNSession] = {}

    def create_session(
        self,
        window_size: int = 256,
        calibration_mode: str = "adaptive",
        **kwargs
    ) -> YRSNSession:
        """
        Create a new session.

        Args:
            window_size: Size of sliding window for drift detection
            calibration_mode: "adaptive", "fixed", or "none"
            **kwargs: Additional SessionConfig parameters

        Returns:
            New YRSNSession instance
        """
        config = SessionConfig(
            window_size=window_size,
            calibration_mode=CalibrationMode(calibration_mode),
            **kwargs
        )

        session = YRSNSession(config=config)
        self._active_sessions[session.session_id] = session
        self.storage.save(session)

        return session

    def get_session(self, session_id: str) -> Optional[YRSNSession]:
        """
        Get session by ID.

        Checks active sessions first, then storage.
        """
        # Check active sessions
        if session_id in self._active_sessions:
            return self._active_sessions[session_id]

        # Load from storage
        session = self.storage.load(session_id)
        if session:
            self._active_sessions[session_id] = session

        return session

    def process_sample(
        self,
        session_id: str,
        R: float,
        S: float,
        N: float,
    ) -> ContinuitySignals:
        """
        Process a single sample and compute continuity signals.

        Args:
            session_id: Session identifier
            R, S, N: Decomposition values

        Returns:
            ContinuitySignals with drift/trend/risk information
        """
        session = self.get_session(session_id)
        if session is None:
            raise ValueError(f"Session not found: {session_id}")

        # Update session state
        session.update(R, S, N)

        # Compute continuity signals
        continuity = ContinuitySignals(
            session_id=session_id,
            sequence_number=session.current_sequence,
            window_position=session.samples_processed % session.config.window_size,
            window_complete=(session.samples_processed % session.config.window_size == 0),
            samples_in_window=len(session.window_R_buffer),
            drift_from_baseline=session.compute_drift() if session.baseline_established else None,
            running_R_mean=session.R_stats.mean,
            running_S_mean=session.S_stats.mean,
            running_N_mean=session.N_stats.mean,
            running_alpha_mean=session.alpha_stats.mean,
            running_alpha_std=session.alpha_stats.std,
            alpha_trend=session.compute_trend(),
            collapse_risk=session.compute_collapse_risk(),
            samples_since_baseline=session.samples_processed - session.baseline_samples if session.baseline_established else 0,
        )

        # Persist if checkpoint interval reached
        if session.samples_processed % session.config.checkpoint_interval == 0:
            session.last_checkpoint_at = int(time.time() * 1000)
            self.storage.save(session)

        return continuity

    def close_session(self, session_id: str) -> Dict[str, Any]:
        """
        Close session and return final statistics.

        Args:
            session_id: Session identifier

        Returns:
            Final session statistics
        """
        session = self.get_session(session_id)
        if session is None:
            return {"error": f"Session not found: {session_id}"}

        # Final save
        self.storage.save(session)

        # Remove from active sessions
        if session_id in self._active_sessions:
            del self._active_sessions[session_id]

        return {
            "session_id": session_id,
            "samples_processed": session.samples_processed,
            "final_R_mean": session.R_stats.mean,
            "final_S_mean": session.S_stats.mean,
            "final_N_mean": session.N_stats.mean,
            "final_alpha_mean": session.alpha_stats.mean,
            "final_alpha_std": session.alpha_stats.std,
            "baseline_alpha": session.baseline_alpha,
            "baseline_established": session.baseline_established,
            "final_collapse_risk": session.compute_collapse_risk(),
        }

    def export_baseline(self, session_id: str) -> Dict[str, float]:
        """
        Export baseline from session for use in new sessions.

        Args:
            session_id: Session identifier

        Returns:
            Baseline statistics dict
        """
        session = self.get_session(session_id)
        if session is None or not session.baseline_established:
            return {}

        return {
            "R_mean": session.baseline_R_mean,
            "S_mean": session.baseline_S_mean,
            "N_mean": session.baseline_N_mean,
            "R_std": session.baseline_R_std,
            "S_std": session.baseline_S_std,
            "N_std": session.baseline_N_std,
            "alpha": session.baseline_alpha,
            "samples": session.baseline_samples,
        }

    def import_baseline(self, session_id: str, baseline: Dict[str, float]) -> bool:
        """
        Import baseline into session.

        Args:
            session_id: Session identifier
            baseline: Baseline statistics from export_baseline()

        Returns:
            True if successful
        """
        session = self.get_session(session_id)
        if session is None:
            return False

        session.baseline_R_mean = baseline.get("R_mean", 0.0)
        session.baseline_S_mean = baseline.get("S_mean", 0.0)
        session.baseline_N_mean = baseline.get("N_mean", 0.0)
        session.baseline_R_std = baseline.get("R_std", 0.0)
        session.baseline_S_std = baseline.get("S_std", 0.0)
        session.baseline_N_std = baseline.get("N_std", 0.0)
        session.baseline_alpha = baseline.get("alpha", 0.0)
        session.baseline_samples = int(baseline.get("samples", 0))
        session.baseline_established = True
        session.calibration_state = "DATA_CALIBRATED"

        self.storage.save(session)
        return True


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "CalibrationMode",
    "DriftDirection",
    "TrendState",

    # Configuration
    "SessionConfig",

    # Session state
    "RunningStats",
    "YRSNSession",
    "ContinuitySignals",

    # Storage
    "SessionStorage",
    "InMemorySessionStorage",

    # Manager
    "YRSNSessionManager",
]
