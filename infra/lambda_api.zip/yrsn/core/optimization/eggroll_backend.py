"""
EGGROLL Optimization Backend
============================

Evolution-Guided Low-Rank Optimization for YRSN components.

Inspired by "Hyperscale Evolution Strategies with Low-Rank Perturbations"
(arXiv:2511.16652). Enables gradient-free optimization using population-based
evolution with memory-efficient low-rank perturbation matrices.

Key innovations:
- O(r(m+n)) storage instead of O(mn) for perturbations
- Gradient-free: no backpropagation required
- Integer-compatible: supports quantized/discrete parameters
- Hyperscale: proven on billion+ parameter models
- Phase transition-aware rank selection (BBP theory)
"""

from typing import Dict, List, Optional, Tuple, Callable, Any
from dataclasses import dataclass
import numpy as np


# =============================================================================
# Phase Transition Theory (BBP)
# =============================================================================

class PhaseTransition:
    """
    BBP phase transition thresholds for adaptive rank selection.

    Based on Baik-Ben Arous-Péché theory extended to semantic decomposition.
    Signal emergence at α_ℓ = (ℓ-1)/(2ℓ) determines when order-ℓ
    structure becomes detectable above noise.

    Critical Thresholds:
    - α < 0.25: Noise regime (no structure)
    - α ≥ 0.25: Quadratic structure visible
    - α ≥ 0.33: Cubic structure recoverable
    - α ≥ 0.50: Full higher-order structure

    Usage:
        >>> phase = PhaseTransition.get_phase_name(0.35)
        'HIGHER_ORDER'
        >>> rank = PhaseTransition.recommended_rank(0.35, max_rank=32)
        8
    """

    # Critical thresholds from theory
    ALPHA_QUADRATIC = 0.25   # ℓ=2: α = (2-1)/(2*2) = 1/4
    ALPHA_CUBIC = 1/3        # ℓ=3: α = (3-1)/(2*3) = 1/3
    ALPHA_QUARTIC = 3/8      # ℓ=4: α = (4-1)/(2*4) = 3/8
    ALPHA_FULL = 0.50        # ℓ→∞: α = 1/2

    @staticmethod
    def critical_alpha(order: int) -> float:
        """
        Compute critical quality threshold for order-ℓ structure.

        α_ℓ = (ℓ-1) / (2ℓ)

        Parameters
        ----------
        order : int
            Polynomial order (ℓ ≥ 1)

        Returns
        -------
        float
            Critical quality threshold α_ℓ
        """
        if order < 1:
            raise ValueError("Order must be ≥ 1")
        return (order - 1) / (2 * order)

    @staticmethod
    def detectable_order(quality: float) -> int:
        """
        Determine maximum polynomial order detectable at given quality.

        Inverts α_ℓ = (ℓ-1)/(2ℓ) to find ℓ given α:
        ℓ = 1 / (2(1-α))  for α < 0.5
        ℓ = ∞             for α ≥ 0.5

        Parameters
        ----------
        quality : float
            Current quality α ∈ [0, 1]

        Returns
        -------
        int
            Maximum detectable polynomial order (∞ returned as 999)
        """
        if quality >= 0.5:
            return 999  # Effectively infinite
        if quality <= 0:
            return 0  # No structure detectable
        return int(1 / (2 * (1 - quality)))

    @staticmethod
    def recommended_rank(quality: float, max_rank: int = 64) -> int:
        """
        Select EGGROLL perturbation rank based on quality phase.

        Strategy based on phase transitions:
        - Noise regime (α < 0.25): Max rank for broad exploration
        - Quadratic regime (0.25 ≤ α < 0.33): High rank
        - Higher-order regime (0.33 ≤ α < 0.50): Medium rank
        - Full signal regime (α ≥ 0.50): Low rank for refinement

        Parameters
        ----------
        quality : float
            Current quality α (from Y-Score or R component)
        max_rank : int
            Maximum allowed perturbation rank

        Returns
        -------
        int
            Recommended perturbation rank
        """
        if quality < PhaseTransition.ALPHA_QUADRATIC:
            # Below quadratic threshold: maximum exploration
            return max_rank
        elif quality < PhaseTransition.ALPHA_CUBIC:
            # Quadratic regime: high exploration
            return max(4, int(max_rank * 0.75))
        elif quality < PhaseTransition.ALPHA_FULL:
            # Higher-order regime: moderate exploration
            return max(4, int(max_rank * 0.5))
        else:
            # Full signal regime: minimal exploration, focus on refinement
            return max(2, int(max_rank * 0.25))

    @staticmethod
    def get_phase_name(quality: float) -> str:
        """Get human-readable phase name from quality."""
        if quality < PhaseTransition.ALPHA_QUADRATIC:
            return "NOISE"
        elif quality < PhaseTransition.ALPHA_CUBIC:
            return "QUADRATIC"
        elif quality < PhaseTransition.ALPHA_FULL:
            return "HIGHER_ORDER"
        else:
            return "FULL_SIGNAL"

    @staticmethod
    def get_phase_description(quality: float) -> str:
        """Get detailed phase description."""
        phase = PhaseTransition.get_phase_name(quality)
        order = PhaseTransition.detectable_order(quality)
        descriptions = {
            "NOISE": f"α={quality:.2f} < 0.25: No detectable structure. Use max rank.",
            "QUADRATIC": f"α={quality:.2f}: Quadratic (ℓ=2) structure visible. High rank.",
            "HIGHER_ORDER": f"α={quality:.2f}: Up to order-{order} structure. Medium rank.",
            "FULL_SIGNAL": f"α={quality:.2f} ≥ 0.50: Full structure recoverable. Low rank.",
        }
        return descriptions.get(phase, f"Unknown phase at α={quality:.2f}")


@dataclass
class LowRankPerturbation:
    """
    Low-rank perturbation matrix E = (1/√r) * A @ B.T

    Instead of storing full m×n perturbation (O(mn)),
    stores factors A (m×r) and B (n×r) for O(r(m+n)) storage.
    """
    A: np.ndarray  # Shape: (m, r)
    B: np.ndarray  # Shape: (n, r)
    scale: float   # 1/√r normalization

    @property
    def rank(self) -> int:
        return self.A.shape[1]

    def apply(self, W: np.ndarray, sigma: float = 1.0) -> np.ndarray:
        """Apply perturbation: W + σ * (1/√r) * A @ B.T"""
        return W + sigma * self.scale * (self.A @ self.B.T)

    def memory_savings(self) -> float:
        """Ratio of full storage to low-rank storage."""
        m, r = self.A.shape
        n = self.B.shape[0]
        full_storage = m * n
        low_rank_storage = r * (m + n)
        return full_storage / low_rank_storage


@dataclass
class EvolutionState:
    """Tracks evolution optimization state."""
    generation: int
    best_fitness: float
    mean_fitness: float
    fitness_history: List[float]


class EggrollBackend:
    """
    Evolution-Guided Low-Rank Optimization backend.

    Uses evolution strategies with low-rank perturbations for
    gradient-free optimization of YRSN components.

    Parameters
    ----------
    perturbation_rank : int
        Rank of low-rank perturbations (r). Lower = more memory efficient.
        Typical values: 4-64.
    population_size : int
        Number of perturbation samples per generation.
        Must be even (antithetic sampling).
    learning_rate : float
        Step size for parameter updates
    sigma : float
        Standard deviation for perturbation sampling
    fitness_shaping : bool
        Use rank-based fitness shaping for robustness
    antithetic : bool
        Use antithetic sampling (±ε pairs) for variance reduction
    weight_decay : float
        L2 regularization applied during updates

    Example
    -------
    >>> optimizer = EggrollBackend(perturbation_rank=8, population_size=64)
    >>> for generation in range(1000):
    ...     # Sample low-rank perturbations
    ...     perturbations = optimizer.sample_perturbations(parameters)
    ...     # Evaluate fitness (forward only, no gradients)
    ...     fitness = [evaluate(apply_perturbation(params, p)) for p in perturbations]
    ...     # Update via evolution
    ...     parameters = optimizer.step(parameters, fitness)
    """

    def __init__(
        self,
        perturbation_rank: int = 8,
        population_size: int = 64,
        learning_rate: float = 0.01,
        sigma: float = 0.02,
        fitness_shaping: bool = True,
        antithetic: bool = True,
        weight_decay: float = 0.0,
        adaptive_rank: bool = True,
        max_rank: int = 64
    ):
        if population_size % 2 != 0 and antithetic:
            raise ValueError("Population size must be even for antithetic sampling")

        self.perturbation_rank = perturbation_rank
        self.population_size = population_size
        self.learning_rate = learning_rate
        self.sigma = sigma
        self.fitness_shaping = fitness_shaping
        self.antithetic = antithetic
        self.weight_decay = weight_decay

        # Phase transition-aware rank adaptation
        self.adaptive_rank = adaptive_rank
        self.max_rank = max_rank
        self._base_rank = perturbation_rank
        self._current_quality: Optional[float] = None
        self._current_phase: str = "UNKNOWN"

        # State
        self.generation = 0
        self.best_fitness = float('-inf')
        self.fitness_history: List[float] = []

        # Current perturbations (stored for step())
        self._current_perturbations: Dict[str, List[LowRankPerturbation]] = {}

    def update_quality(self, quality: float) -> int:
        """
        Update quality and adapt perturbation rank based on phase transitions.

        Uses BBP phase transition theory to select optimal rank:
        - Low quality (α < 0.25): High rank for exploration
        - High quality (α ≥ 0.50): Low rank for refinement

        Parameters
        ----------
        quality : float
            Current quality α (e.g., from Y-Score or R component)

        Returns
        -------
        int
            New perturbation rank
        """
        self._current_quality = quality
        self._current_phase = PhaseTransition.get_phase_name(quality)

        if self.adaptive_rank:
            self.perturbation_rank = PhaseTransition.recommended_rank(
                quality,
                max_rank=self.max_rank
            )

        return self.perturbation_rank

    def get_phase_info(self) -> Dict[str, Any]:
        """Get current phase transition information."""
        return {
            'quality': self._current_quality,
            'phase': self._current_phase,
            'current_rank': self.perturbation_rank,
            'max_rank': self.max_rank,
            'adaptive': self.adaptive_rank,
            'description': PhaseTransition.get_phase_description(
                self._current_quality or 0.0
            ) if self._current_quality else "No quality set",
        }

    def sample_perturbations(
        self,
        parameters: Dict[str, np.ndarray]
    ) -> List[Dict[str, np.ndarray]]:
        """
        Sample low-rank perturbations for all parameters.

        Returns list of perturbed parameter dictionaries.
        Uses antithetic sampling: for each ε, also samples -ε.

        Parameters
        ----------
        parameters : dict
            Named parameter arrays

        Returns
        -------
        list of dict
            Population of perturbed parameters
        """
        self._current_perturbations = {}
        population = []

        n_pairs = self.population_size // 2 if self.antithetic else self.population_size

        for i in range(n_pairs):
            perturbed_pos = {}
            perturbed_neg = {}

            for name, W in parameters.items():
                if W.ndim == 1:
                    # Vector: simple Gaussian perturbation
                    eps = np.random.randn(*W.shape)
                    perturbed_pos[name] = W + self.sigma * eps
                    if self.antithetic:
                        perturbed_neg[name] = W - self.sigma * eps

                    if name not in self._current_perturbations:
                        self._current_perturbations[name] = []
                    # Store as "degenerate" low-rank (rank=1 vector)
                    self._current_perturbations[name].append(eps)
                    if self.antithetic:
                        self._current_perturbations[name].append(-eps)

                else:
                    # Matrix: low-rank perturbation E = (1/√r) A @ B.T
                    m, n = W.shape
                    r = min(self.perturbation_rank, min(m, n))

                    A = np.random.randn(m, r)
                    B = np.random.randn(n, r)
                    scale = 1.0 / np.sqrt(r)

                    perturbation = LowRankPerturbation(A=A, B=B, scale=scale)

                    perturbed_pos[name] = perturbation.apply(W, self.sigma)
                    if self.antithetic:
                        perturbed_neg[name] = perturbation.apply(W, -self.sigma)

                    if name not in self._current_perturbations:
                        self._current_perturbations[name] = []
                    self._current_perturbations[name].append(perturbation)
                    if self.antithetic:
                        # Store negated version
                        neg_perturbation = LowRankPerturbation(A=A, B=-B, scale=scale)
                        self._current_perturbations[name].append(neg_perturbation)

            population.append(perturbed_pos)
            if self.antithetic:
                population.append(perturbed_neg)

        return population

    def step(
        self,
        parameters: Dict[str, np.ndarray],
        fitness_scores: List[float]
    ) -> Dict[str, np.ndarray]:
        """
        Update parameters based on fitness scores.

        Parameters
        ----------
        parameters : dict
            Current parameter values
        fitness_scores : list of float
            Fitness for each member of population

        Returns
        -------
        dict
            Updated parameters
        """
        self.generation += 1

        # Apply fitness shaping
        if self.fitness_shaping:
            weights = self._fitness_shaping(fitness_scores)
        else:
            weights = np.array(fitness_scores)
            weights = (weights - weights.mean()) / (weights.std() + 1e-8)

        # Track best fitness
        max_fitness = max(fitness_scores)
        mean_fitness = np.mean(fitness_scores)
        if max_fitness > self.best_fitness:
            self.best_fitness = max_fitness
        self.fitness_history.append(mean_fitness)

        # Update each parameter
        updated = {}
        for name, W in parameters.items():
            perturbations = self._current_perturbations.get(name, [])
            if not perturbations:
                updated[name] = W
                continue

            # Compute weighted sum of perturbations
            if W.ndim == 1:
                # Vector case
                gradient_estimate = np.zeros_like(W)
                for i, eps in enumerate(perturbations):
                    gradient_estimate += weights[i] * eps
                gradient_estimate /= (self.population_size * self.sigma)

            else:
                # Matrix case: reconstruct from low-rank factors
                gradient_estimate = np.zeros_like(W)
                for i, perturbation in enumerate(perturbations):
                    if isinstance(perturbation, LowRankPerturbation):
                        E = perturbation.scale * (perturbation.A @ perturbation.B.T)
                        gradient_estimate += weights[i] * E
                gradient_estimate /= (self.population_size * self.sigma)

            # Apply weight decay
            if self.weight_decay > 0:
                gradient_estimate -= self.weight_decay * W

            # Update
            updated[name] = W + self.learning_rate * gradient_estimate

        return updated

    def _fitness_shaping(self, fitness_scores: List[float]) -> np.ndarray:
        """
        Rank-based fitness shaping for robustness.

        Transforms raw fitness to rank-based weights, making
        optimization robust to fitness scale and outliers.
        """
        n = len(fitness_scores)
        ranks = np.argsort(np.argsort(fitness_scores))  # 0 = worst, n-1 = best

        # Compute shaping weights (log-linear)
        weights = np.maximum(0, np.log(n / 2 + 1) - np.log(n - ranks))
        weights /= weights.sum()
        weights -= 1.0 / n  # Center

        return weights

    def get_memory_savings(self, parameters: Dict[str, np.ndarray]) -> Dict[str, float]:
        """
        Calculate memory savings for each parameter.

        Returns ratio of full perturbation storage to low-rank storage.
        """
        savings = {}
        for name, W in parameters.items():
            if W.ndim < 2:
                savings[name] = 1.0  # No savings for vectors
            else:
                m, n = W.shape
                r = min(self.perturbation_rank, min(m, n))
                full = m * n
                low_rank = r * (m + n)
                savings[name] = full / low_rank
        return savings

    def state_dict(self) -> EvolutionState:
        """Get optimizer state for checkpointing."""
        return EvolutionState(
            generation=self.generation,
            best_fitness=self.best_fitness,
            mean_fitness=self.fitness_history[-1] if self.fitness_history else 0.0,
            fitness_history=self.fitness_history.copy()
        )

    def load_state_dict(self, state: EvolutionState):
        """Load optimizer state from checkpoint."""
        self.generation = state.generation
        self.best_fitness = state.best_fitness
        self.fitness_history = state.fitness_history.copy()


def demonstrate_savings():
    """Show memory savings for typical YRSN tensor sizes."""
    sizes = [
        ("Small embedding", (128, 64)),
        ("Medium layer", (512, 512)),
        ("Large layer", (2048, 2048)),
        ("LLM attention", (4096, 4096)),
        ("Hyperscale", (65536, 65536)),
    ]

    print("EGGROLL Memory Savings (rank=8)")
    print("=" * 50)

    for name, (m, n) in sizes:
        r = 8
        full = m * n
        low_rank = r * (m + n)
        savings = full / low_rank
        print(f"{name:20s} ({m:>5d}×{n:<5d}): {savings:>8.1f}x savings")


if __name__ == "__main__":
    demonstrate_savings()
