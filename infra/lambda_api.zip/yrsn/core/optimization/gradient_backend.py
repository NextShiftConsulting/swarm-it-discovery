"""
Gradient-Based Optimization Backend
===================================

Standard gradient-based optimization for YRSN components.
Wraps common optimizers (Adam, SGD, etc.) with YRSN-specific features.

This is the default backend for differentiable objectives.
"""

from typing import Dict, Any, Optional, Iterator, Callable
from dataclasses import dataclass
import numpy as np


@dataclass
class OptimizationState:
    """Tracks optimization state for checkpointing."""
    step: int
    learning_rate: float
    momentum_buffers: Dict[str, np.ndarray]
    adaptive_buffers: Dict[str, np.ndarray]


class GradientBackend:
    """
    Standard gradient-based optimizer for YRSN components.

    Supports Adam, SGD, and temperature-aware scheduling (τ=1/α).

    Parameters
    ----------
    learning_rate : float
        Initial learning rate
    optimizer_type : str
        One of 'adam', 'sgd', 'adamw'
    beta1 : float
        Momentum coefficient (Adam)
    beta2 : float
        Second moment coefficient (Adam)
    weight_decay : float
        L2 regularization strength
    use_temperature_schedule : bool
        If True, adapt LR based on τ=1/α duality

    Example
    -------
    >>> optimizer = GradientBackend(learning_rate=0.001, optimizer_type='adam')
    >>> for epoch in range(100):
    ...     gradients = compute_gradients(model, loss)
    ...     optimizer.step(model.parameters(), gradients)
    """

    def __init__(
        self,
        learning_rate: float = 0.001,
        optimizer_type: str = 'adam',
        beta1: float = 0.9,
        beta2: float = 0.999,
        epsilon: float = 1e-8,
        weight_decay: float = 0.0,
        use_temperature_schedule: bool = False,
        initial_temperature: float = 1.0
    ):
        self.learning_rate = learning_rate
        self.optimizer_type = optimizer_type.lower()
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.weight_decay = weight_decay
        self.use_temperature_schedule = use_temperature_schedule
        self.temperature = initial_temperature

        # State tracking
        self.step_count = 0
        self.momentum_buffers: Dict[str, np.ndarray] = {}
        self.variance_buffers: Dict[str, np.ndarray] = {}

    def step(
        self,
        parameters: Dict[str, np.ndarray],
        gradients: Dict[str, np.ndarray]
    ) -> Dict[str, np.ndarray]:
        """
        Perform one optimization step.

        Parameters
        ----------
        parameters : dict
            Named parameter arrays to update
        gradients : dict
            Gradients for each parameter

        Returns
        -------
        dict
            Updated parameters
        """
        self.step_count += 1

        # Temperature-aware learning rate
        lr = self._get_learning_rate()

        updated = {}
        for name, param in parameters.items():
            if name not in gradients:
                updated[name] = param
                continue

            grad = gradients[name]

            # Apply weight decay
            if self.weight_decay > 0:
                grad = grad + self.weight_decay * param

            if self.optimizer_type == 'sgd':
                updated[name] = self._sgd_step(name, param, grad, lr)
            elif self.optimizer_type in ('adam', 'adamw'):
                updated[name] = self._adam_step(name, param, grad, lr)
            else:
                raise ValueError(f"Unknown optimizer: {self.optimizer_type}")

        return updated

    def _sgd_step(
        self,
        name: str,
        param: np.ndarray,
        grad: np.ndarray,
        lr: float
    ) -> np.ndarray:
        """SGD with momentum."""
        if name not in self.momentum_buffers:
            self.momentum_buffers[name] = np.zeros_like(param)

        self.momentum_buffers[name] = (
            self.beta1 * self.momentum_buffers[name] + grad
        )
        return param - lr * self.momentum_buffers[name]

    def _adam_step(
        self,
        name: str,
        param: np.ndarray,
        grad: np.ndarray,
        lr: float
    ) -> np.ndarray:
        """Adam optimizer step."""
        if name not in self.momentum_buffers:
            self.momentum_buffers[name] = np.zeros_like(param)
            self.variance_buffers[name] = np.zeros_like(param)

        # Update biased moments
        self.momentum_buffers[name] = (
            self.beta1 * self.momentum_buffers[name] + (1 - self.beta1) * grad
        )
        self.variance_buffers[name] = (
            self.beta2 * self.variance_buffers[name] + (1 - self.beta2) * grad**2
        )

        # Bias correction
        m_hat = self.momentum_buffers[name] / (1 - self.beta1**self.step_count)
        v_hat = self.variance_buffers[name] / (1 - self.beta2**self.step_count)

        return param - lr * m_hat / (np.sqrt(v_hat) + self.epsilon)

    def _get_learning_rate(self) -> float:
        """Get current learning rate, possibly temperature-adjusted."""
        if not self.use_temperature_schedule:
            return self.learning_rate

        # τ = 1/α duality: high temperature → more exploration (higher LR)
        # As quality (α) improves, temperature drops, LR decreases
        return self.learning_rate * self.temperature

    def set_temperature(self, temperature: float):
        """
        Set optimization temperature (τ = 1/α).

        Higher temperature = more exploration
        Lower temperature = more exploitation
        """
        self.temperature = max(0.01, temperature)

    def anneal_temperature(self, decay: float = 0.99):
        """Reduce temperature by decay factor."""
        self.temperature *= decay

    def state_dict(self) -> OptimizationState:
        """Get optimizer state for checkpointing."""
        return OptimizationState(
            step=self.step_count,
            learning_rate=self.learning_rate,
            momentum_buffers=self.momentum_buffers.copy(),
            adaptive_buffers=self.variance_buffers.copy()
        )

    def load_state_dict(self, state: OptimizationState):
        """Load optimizer state from checkpoint."""
        self.step_count = state.step
        self.learning_rate = state.learning_rate
        self.momentum_buffers = state.momentum_buffers.copy()
        self.variance_buffers = state.adaptive_buffers.copy()
