"""
Adaptive Backend Selector
=========================

Automatically selects the optimal optimization backend based on
task characteristics, paradigm, and constraints.

Integrates temperature-quality duality (τ = 1/α) for dynamic backend switching:
- High temperature (τ > τ_switch): EGGROLL for exploration
- Low temperature (τ ≤ τ_switch): Gradient for exploitation/refinement

Default selection logic:
- Discrete/combinatorial decisions → EGGROLL
- Non-differentiable objectives → EGGROLL
- Memory-constrained training → EGGROLL
- Smooth differentiable loss → Gradient
- Need fast convergence on small models → Gradient
"""

from typing import Dict, Any, Optional, Union, List, Callable
from enum import Enum, auto
from dataclasses import dataclass, field
import numpy as np

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal  # Python < 3.8

from .gradient_backend import GradientBackend
from .eggroll_backend import EggrollBackend

# Import collapse detection (lazy to avoid circular imports)
_collapse_detection = None

def _get_collapse_detector():
    """Lazy import of collapse detection module."""
    global _collapse_detection
    if _collapse_detection is None:
        from yrsn.core.decomposition.collapse import (
            detect_collapse, CollapseType, CollapseAnalysis, Severity
        )
        _collapse_detection = {
            'detect_collapse': detect_collapse,
            'CollapseType': CollapseType,
            'CollapseAnalysis': CollapseAnalysis,
            'Severity': Severity,
        }
    return _collapse_detection


class Paradigm(Enum):
    """The 5 core YRSN paradigms."""
    ITERATIVE_REFINEMENT = auto()      # 1. HP-INV inspired
    BIT_SLICING = auto()               # 2. Multi-granularity
    HIERARCHICAL_DECOMPOSITION = auto() # 3. BlockAMC inspired
    LAYERED_ARCHITECTURE = auto()      # 4. 3D circuit stacking
    NEURAL_CONTEXT = auto()            # 5. CTM inspired


class ObjectiveType(Enum):
    """Type of optimization objective."""
    DIFFERENTIABLE = auto()      # Smooth, gradient-friendly
    NON_DIFFERENTIABLE = auto()  # Discrete metrics, rankings
    MIXED = auto()               # Combination
    UNKNOWN = auto()             # Let adaptive backend decide


# =============================================================================
# Quality Metrics (Y-Score, Collapse Risk)
# =============================================================================

@dataclass
class QualityMetrics:
    """
    YRSN quality metrics for optimization guidance.

    Tracks R (relevant), S (superfluous), N (noise) components
    and computes derived metrics for adaptive optimization.

    Y = R + S + N (constraint: sums to 1.0)

    Derived Metrics:
    - Y-Score = R + 0.5*S (overall quality)
    - Collapse Risk = S + 1.5*N (context collapse probability)
    - Temperature τ = 1/R (from quality duality)
    """
    R: float  # Relevant content ratio [0, 1]
    S: float  # Superfluous content ratio [0, 1]
    N: float  # Noise ratio [0, 1]

    def __post_init__(self):
        """Validate and normalize constraint R + S + N = 1.0"""
        total = self.R + self.S + self.N
        if total > 0 and not (0.99 <= total <= 1.01):
            # Normalize if needed
            self.R /= total
            self.S /= total
            self.N /= total

    @property
    def y_score(self) -> float:
        """
        Y-Score: Overall quality metric.

        Y = R + 0.5 × S

        Range: [0, 1] where higher is better.
        """
        return self.R + 0.5 * self.S

    @property
    def collapse_risk(self) -> float:
        """
        Context collapse risk.

        Risk = S + 1.5 × N

        Range: [0, 1.5] where lower is better.
        """
        return self.S + 1.5 * self.N

    @property
    def quality_alpha(self) -> float:
        """
        Quality parameter α for temperature duality.

        α = R (relevant content ratio)
        """
        return self.R

    @property
    def temperature(self) -> float:
        """
        Temperature τ from quality duality.

        τ = 1/α = 1/R
        """
        if self.R <= 0:
            return float('inf')
        return 1.0 / self.R

    @property
    def risk_level(self) -> str:
        """Categorical risk assessment."""
        risk = self.collapse_risk
        if risk < 0.3:
            return "LOW"
        elif risk < 0.6:
            return "MEDIUM"
        else:
            return "HIGH"

    @property
    def quality_level(self) -> str:
        """Categorical quality assessment."""
        y = self.y_score
        if y >= 0.9:
            return "EXCELLENT"
        elif y >= 0.8:
            return "VERY_GOOD"
        elif y >= 0.7:
            return "GOOD"
        elif y >= 0.6:
            return "FAIR"
        elif y >= 0.5:
            return "POOR"
        else:
            return "VERY_POOR"

    def should_use_eggroll(self) -> bool:
        """
        Determine if EGGROLL is recommended based on metrics.

        Use EGGROLL when:
        - High collapse risk (need exploration to escape)
        - Low quality (need broad search)
        - High noise ratio (gradients unreliable)
        """
        return (
            self.collapse_risk > 0.5 or
            self.y_score < 0.6 or
            self.N > 0.25
        )

    def to_dict(self) -> Dict[str, Any]:
        """Export metrics as dictionary."""
        return {
            'R': self.R,
            'S': self.S,
            'N': self.N,
            'y_score': self.y_score,
            'collapse_risk': self.collapse_risk,
            'temperature': self.temperature,
            'quality_alpha': self.quality_alpha,
            'risk_level': self.risk_level,
            'quality_level': self.quality_level,
        }


# =============================================================================
# Annealing Configuration
# =============================================================================

@dataclass
class AnnealingConfig:
    """
    Temperature annealing configuration for dynamic backend switching.

    Based on temperature-quality duality: τ = 1/α

    Phase transitions:
    - τ > 2.5 (α < 0.4): Low quality → EGGROLL exploration
    - 1.43 ≤ τ ≤ 2.5 (0.4 ≤ α ≤ 0.7): Medium → either backend
    - τ < 1.43 (α > 0.7): High quality → Gradient refinement
    """
    initial_temperature: float = 5.0      # τ₀: Start hot (exploration)
    final_temperature: float = 0.5        # τ_min: End cold (exploitation)
    cooling_rate: float = 0.95            # λ: Geometric cooling
    switch_temperature: float = 1.5       # τ_switch: EGGROLL→Gradient threshold
    adaptive_reheating: bool = True       # Reheat if quality degrades

    # Critical temperatures from theory
    tau_high_quality: float = 1.43        # τ < this → high quality phase
    tau_low_quality: float = 2.50         # τ > this → low quality phase


@dataclass
class TaskProfile:
    """Describes task characteristics for backend selection."""
    paradigm: Optional[Paradigm] = None
    objective_type: ObjectiveType = ObjectiveType.UNKNOWN
    parameter_count: int = 0
    memory_constrained: bool = False
    requires_discrete_decisions: bool = False
    quantized_training: bool = False
    max_evaluations: Optional[int] = None  # Budget for fitness evals

    # Temperature annealing settings
    enable_annealing: bool = False        # Enable dynamic backend switching
    annealing_config: Optional[AnnealingConfig] = None


class AdaptiveBackend:
    """
    Automatically selects and configures the optimal optimization backend.

    Selection priorities:
    1. Explicit user override (force_backend)
    2. Task-specific requirements (discrete, non-diff, memory)
    3. Paradigm-based defaults
    4. Fallback to EGGROLL for classical, Gradient for neural

    Parameters
    ----------
    task_profile : TaskProfile, optional
        Describes the optimization task characteristics
    force_backend : str, optional
        Override automatic selection ('gradient' or 'eggroll')
    gradient_config : dict, optional
        Configuration for GradientBackend if selected
    eggroll_config : dict, optional
        Configuration for EggrollBackend if selected

    Example
    -------
    >>> # Automatic selection based on paradigm
    >>> backend = AdaptiveBackend(TaskProfile(paradigm=Paradigm.BIT_SLICING))
    >>> print(backend.backend_name)  # 'eggroll'

    >>> # Automatic selection for neural with quantization
    >>> backend = AdaptiveBackend(TaskProfile(
    ...     paradigm=Paradigm.NEURAL_CONTEXT,
    ...     quantized_training=True
    ... ))
    >>> print(backend.backend_name)  # 'eggroll'

    >>> # Force specific backend
    >>> backend = AdaptiveBackend(force_backend='gradient')
    """

    # Paradigm → default backend mapping
    PARADIGM_DEFAULTS = {
        Paradigm.ITERATIVE_REFINEMENT: 'eggroll',      # Non-diff precision metrics
        Paradigm.BIT_SLICING: 'eggroll',               # Discrete boundaries
        Paradigm.HIERARCHICAL_DECOMPOSITION: 'eggroll', # Combinatorial blocks
        Paradigm.LAYERED_ARCHITECTURE: 'eggroll',      # End-to-end stack quality
        Paradigm.NEURAL_CONTEXT: 'gradient',           # Standard backprop works
    }

    def __init__(
        self,
        task_profile: Optional[TaskProfile] = None,
        force_backend: Optional[Literal['gradient', 'eggroll']] = None,
        gradient_config: Optional[Dict[str, Any]] = None,
        eggroll_config: Optional[Dict[str, Any]] = None
    ):
        self.task_profile = task_profile or TaskProfile()
        self.force_backend = force_backend
        self.gradient_config = gradient_config or {}
        self.eggroll_config = eggroll_config or {}

        # Temperature annealing state
        self._annealing_enabled = self.task_profile.enable_annealing
        self._annealing_config = (
            self.task_profile.annealing_config or AnnealingConfig()
        )
        self._temperature = self._annealing_config.initial_temperature
        self._iteration = 0
        self._quality_history: List[float] = []
        self._switch_count = 0

        # Both backends for dynamic switching
        self._eggroll_backend: Optional[EggrollBackend] = None
        self._gradient_backend: Optional[GradientBackend] = None

        # Select and instantiate backend(s)
        self._backend_name = self._select_backend()
        self._backend = self._create_backend()
        self._selection_reason = self._get_selection_reason()

        # Pre-create both backends if annealing enabled
        if self._annealing_enabled:
            self._ensure_both_backends()

    @property
    def backend_name(self) -> str:
        """Name of the currently active backend."""
        return self._backend_name

    @property
    def backend(self) -> Union[GradientBackend, EggrollBackend]:
        """The currently active backend optimizer."""
        return self._backend

    @property
    def selection_reason(self) -> str:
        """Explanation for why this backend was selected."""
        return self._selection_reason

    @property
    def temperature(self) -> float:
        """Current temperature τ (τ = 1/α)."""
        return self._temperature

    @property
    def quality(self) -> float:
        """Current quality α = 1/τ."""
        return 1.0 / self._temperature if self._temperature > 0 else 1.0

    @property
    def annealing_enabled(self) -> bool:
        """Whether dynamic backend switching is enabled."""
        return self._annealing_enabled

    def _ensure_both_backends(self):
        """Pre-create both backends for fast switching."""
        if self._eggroll_backend is None:
            config = self._auto_tune_eggroll()
            config.update(self.eggroll_config)
            self._eggroll_backend = EggrollBackend(**config)

        if self._gradient_backend is None:
            self._gradient_backend = GradientBackend(**self.gradient_config)

    def _select_backend(self) -> str:
        """Determine optimal backend based on task profile."""
        profile = self.task_profile

        # 1. Explicit override
        if self.force_backend:
            return self.force_backend

        # 2. Hard requirements → EGGROLL
        if profile.requires_discrete_decisions:
            return 'eggroll'
        if profile.objective_type == ObjectiveType.NON_DIFFERENTIABLE:
            return 'eggroll'
        if profile.quantized_training:
            return 'eggroll'
        if profile.memory_constrained and profile.parameter_count > 1_000_000:
            return 'eggroll'

        # 3. Paradigm-based default
        if profile.paradigm:
            return self.PARADIGM_DEFAULTS.get(profile.paradigm, 'eggroll')

        # 4. Objective type hints
        if profile.objective_type == ObjectiveType.DIFFERENTIABLE:
            return 'gradient'
        if profile.objective_type == ObjectiveType.MIXED:
            # Mixed objectives: EGGROLL handles both
            return 'eggroll'

        # 5. Size-based heuristic
        if profile.parameter_count > 0:
            if profile.parameter_count < 100_000:
                return 'gradient'  # Small models: gradient is faster
            else:
                return 'eggroll'   # Large models: EGGROLL scales better

        # 6. Default: EGGROLL (more general-purpose)
        return 'eggroll'

    def _create_backend(self) -> Union[GradientBackend, EggrollBackend]:
        """Instantiate the selected backend with config."""
        if self._backend_name == 'gradient':
            return GradientBackend(**self.gradient_config)
        else:
            # Auto-tune EGGROLL config based on profile
            config = self._auto_tune_eggroll()
            config.update(self.eggroll_config)
            return EggrollBackend(**config)

    def _auto_tune_eggroll(self) -> Dict[str, Any]:
        """Auto-tune EGGROLL hyperparameters based on task."""
        profile = self.task_profile
        config = {}

        # Rank selection based on parameter count
        if profile.parameter_count > 10_000_000:
            config['perturbation_rank'] = 16  # Higher rank for huge models
        elif profile.parameter_count > 1_000_000:
            config['perturbation_rank'] = 8
        else:
            config['perturbation_rank'] = 4

        # Population size based on budget
        if profile.max_evaluations:
            # Use ~10% of budget per generation
            config['population_size'] = min(128, max(8, profile.max_evaluations // 100))
            # Ensure even for antithetic
            config['population_size'] = (config['population_size'] // 2) * 2

        # Memory-constrained: lower rank
        if profile.memory_constrained:
            config['perturbation_rank'] = min(config.get('perturbation_rank', 8), 4)

        return config

    def _get_selection_reason(self) -> str:
        """Generate human-readable selection explanation."""
        profile = self.task_profile

        if self.force_backend:
            return f"Forced by user: {self.force_backend}"

        if profile.requires_discrete_decisions:
            return "EGGROLL: Task requires discrete/combinatorial decisions"
        if profile.objective_type == ObjectiveType.NON_DIFFERENTIABLE:
            return "EGGROLL: Non-differentiable objective (no gradients available)"
        if profile.quantized_training:
            return "EGGROLL: Quantized/integer training requires gradient-free optimization"
        if profile.memory_constrained and profile.parameter_count > 1_000_000:
            return f"EGGROLL: Memory-constrained with {profile.parameter_count:,} params"

        if profile.paradigm:
            paradigm_name = profile.paradigm.name.replace('_', ' ').title()
            return f"Paradigm default: {paradigm_name} → {self._backend_name}"

        if profile.objective_type == ObjectiveType.DIFFERENTIABLE:
            return "Gradient: Smooth differentiable objective"

        if profile.parameter_count < 100_000:
            return f"Gradient: Small model ({profile.parameter_count:,} params) - faster convergence"

        return "EGGROLL: Default for general-purpose optimization"

    # =================================================================
    # Temperature Annealing Methods
    # =================================================================

    def anneal(self, current_quality: Optional[float] = None) -> bool:
        """
        Perform one annealing step: cool temperature and maybe switch backend.

        Temperature-quality duality: τ = 1/α
        - High τ → exploration (EGGROLL)
        - Low τ → exploitation (Gradient)

        Parameters
        ----------
        current_quality : float, optional
            Current optimization quality (α). If provided, enables
            adaptive reheating when quality degrades.

        Returns
        -------
        bool
            True if backend was switched
        """
        if not self._annealing_enabled:
            return False

        self._iteration += 1
        config = self._annealing_config

        # Track quality history for adaptive reheating
        if current_quality is not None:
            self._quality_history.append(current_quality)

        # Compute new temperature
        new_temp = self._compute_temperature()

        # Check for adaptive reheating
        if config.adaptive_reheating and len(self._quality_history) >= 3:
            new_temp = self._maybe_reheat(new_temp)

        self._temperature = max(new_temp, config.final_temperature)

        # Check if we should switch backends
        return self._maybe_switch_backend()

    def _compute_temperature(self) -> float:
        """Compute temperature using geometric cooling."""
        config = self._annealing_config
        return config.initial_temperature * (config.cooling_rate ** self._iteration)

    def _maybe_reheat(self, base_temp: float) -> float:
        """
        Adaptive reheating based on quality trajectory.

        Strategy:
        - Quality improving → continue cooling
        - Quality plateaued → accelerate cooling
        - Quality degrading → REHEAT to escape local minimum
        """
        recent = self._quality_history[-3:]
        delta = recent[-1] - recent[0]
        config = self._annealing_config

        if delta < -0.02:  # Quality degrading
            # Reheat! Increase temperature by 20%
            return min(base_temp * 1.2, config.initial_temperature * 0.8)
        elif abs(delta) < 0.005:  # Plateaued
            # Cool faster
            return base_temp * 0.9
        else:
            return base_temp

    def _maybe_switch_backend(self) -> bool:
        """
        Switch backend based on temperature crossing threshold.

        τ > τ_switch → EGGROLL (exploration)
        τ ≤ τ_switch → Gradient (refinement)
        """
        config = self._annealing_config
        target_backend = 'eggroll' if self._temperature > config.switch_temperature else 'gradient'

        if target_backend != self._backend_name:
            self._switch_backend(target_backend)
            return True
        return False

    def _switch_backend(self, new_backend: str):
        """Switch to a different backend."""
        self._ensure_both_backends()

        old_backend = self._backend_name
        self._backend_name = new_backend

        if new_backend == 'eggroll':
            self._backend = self._eggroll_backend
        else:
            self._backend = self._gradient_backend

        self._switch_count += 1
        self._selection_reason = (
            f"Annealing switch #{self._switch_count}: {old_backend}→{new_backend} "
            f"at τ={self._temperature:.2f} (α={self.quality:.2f})"
        )

    def get_annealing_state(self) -> Dict[str, Any]:
        """Get current annealing state for logging/debugging."""
        return {
            'temperature': self._temperature,
            'quality': self.quality,
            'iteration': self._iteration,
            'backend': self._backend_name,
            'switch_count': self._switch_count,
            'phase': self._get_quality_phase(),
        }

    def _get_quality_phase(self) -> str:
        """Determine quality phase from temperature."""
        config = self._annealing_config
        if self._temperature < config.tau_high_quality:
            return 'HIGH (τ < 1.43)'
        elif self._temperature > config.tau_low_quality:
            return 'LOW (τ > 2.5)'
        else:
            return 'MEDIUM (1.43 ≤ τ ≤ 2.5)'

    def reset_annealing(self):
        """Reset annealing state to initial conditions."""
        self._temperature = self._annealing_config.initial_temperature
        self._iteration = 0
        self._quality_history = []
        self._switch_count = 0

        # Reset to initial backend
        initial_backend = self._select_backend()
        if initial_backend != self._backend_name:
            self._switch_backend(initial_backend)

    # =================================================================
    # YRSN Quality Metrics
    # =================================================================

    def update_yrsn_quality(
        self,
        R: float,
        S: float,
        N: float,
        source_S_values: Optional[List[float]] = None
    ) -> bool:
        """
        Update YRSN quality metrics and adapt optimization strategy.

        This is the primary interface for quality-aware optimization.
        Updates temperature, detects collapse, may switch backends,
        and adjusts EGGROLL rank based on phase transitions.

        Parameters
        ----------
        R : float
            Relevant content ratio
        S : float
            Superfluous content ratio
        N : float
            Noise ratio
        source_S_values : list of float, optional
            S values from individual sources (for clash detection)

        Returns
        -------
        bool
            True if backend was switched based on new metrics
        """
        # Create metrics object
        self._quality_metrics = QualityMetrics(R=R, S=S, N=N)

        # Detect collapse
        cd = _get_collapse_detector()
        self._collapse_analysis = cd['detect_collapse'](R, S, N, source_S_values)

        # Update temperature from quality
        self._temperature = self._quality_metrics.temperature

        # Update EGGROLL rank if using that backend
        if self._eggroll_backend is not None:
            self._eggroll_backend.update_quality(self._quality_metrics.quality_alpha)

        # Check if we should switch backends based on quality or collapse
        switched = False
        if self._annealing_enabled:
            # Use EGGROLL if quality suggests it OR if collapse detected
            use_eggroll = (
                self._quality_metrics.should_use_eggroll() or
                self._collapse_analysis.needs_immediate_action
            )
            recommended = 'eggroll' if use_eggroll else 'gradient'

            if recommended != self._backend_name:
                self._switch_backend(recommended)
                if self._collapse_analysis.is_collapsed:
                    self._selection_reason = (
                        f"Collapse switch: {self._backend_name} "
                        f"({self._collapse_analysis.collapse_type.name}, "
                        f"{self._collapse_analysis.severity.value})"
                    )
                else:
                    self._selection_reason = (
                        f"Quality switch: {self._backend_name} "
                        f"(Y={self._quality_metrics.y_score:.2f}, "
                        f"Risk={self._quality_metrics.collapse_risk:.2f})"
                    )
                switched = True

        return switched

    @property
    def collapse_analysis(self) -> Optional[Any]:
        """Current collapse analysis (None if not detected yet)."""
        return getattr(self, '_collapse_analysis', None)

    @property
    def quality_metrics(self) -> Optional[QualityMetrics]:
        """Current YRSN quality metrics (None if not set)."""
        return getattr(self, '_quality_metrics', None)

    def get_optimization_guidance(self) -> Dict[str, Any]:
        """
        Get optimization guidance based on current quality metrics.

        Returns dict with:
        - recommended_backend
        - risk_level
        - quality_level
        - y_score
        - collapse_risk
        - suggested_actions
        - phase_info (if EGGROLL)
        """
        metrics = self.quality_metrics

        if metrics is None:
            return {
                'status': 'no_metrics',
                'recommendation': 'Call update_yrsn_quality(R, S, N) first',
            }

        guidance = {
            'recommended_backend': 'eggroll' if metrics.should_use_eggroll() else 'gradient',
            'current_backend': self._backend_name,
            'risk_level': metrics.risk_level,
            'quality_level': metrics.quality_level,
            'y_score': metrics.y_score,
            'collapse_risk': metrics.collapse_risk,
            'temperature': metrics.temperature,
            'suggested_actions': [],
        }

        # Generate actionable suggestions
        if metrics.collapse_risk > 0.6:
            guidance['suggested_actions'].append(
                "HIGH RISK: Switch to EGGROLL, increase exploration"
            )
        if metrics.N > 0.25:
            guidance['suggested_actions'].append(
                "HIGH NOISE: Use gradient-free optimization, validate data"
            )
        if metrics.S > 0.4:
            guidance['suggested_actions'].append(
                "HIGH SUPERFLUOUS: Apply bit-slicing, focus on Level 0"
            )
        if metrics.R < 0.4:
            guidance['suggested_actions'].append(
                "LOW RELEVANCE: Broaden exploration, check data sources"
            )

        # Add phase info if using EGGROLL
        if self._eggroll_backend is not None:
            guidance['phase_info'] = self._eggroll_backend.get_phase_info()

        return guidance

    # =================================================================
    # Optimization Methods
    # =================================================================

    def step(self, *args, **kwargs):
        """Perform optimization step (delegates to active backend)."""
        return self._backend.step(*args, **kwargs)

    def step_with_annealing(
        self,
        parameters: Dict[str, np.ndarray],
        gradients_or_fitness: Union[Dict[str, np.ndarray], List[float]],
        current_quality: Optional[float] = None
    ) -> Dict[str, np.ndarray]:
        """
        Perform optimization step with automatic annealing.

        Combines step() + anneal() in one call. Handles both
        gradient-based and evolution-based backends transparently.

        Parameters
        ----------
        parameters : dict
            Current parameter values
        gradients_or_fitness : dict or list
            For gradient backend: gradient dict
            For EGGROLL backend: fitness scores list
        current_quality : float, optional
            Current quality metric for adaptive reheating

        Returns
        -------
        dict
            Updated parameters
        """
        # Perform optimization step
        if self._backend_name == 'gradient':
            updated = self._backend.step(parameters, gradients_or_fitness)
        else:
            # EGGROLL: gradients_or_fitness is fitness scores
            updated = self._backend.step(parameters, gradients_or_fitness)

        # Anneal temperature (may switch backend)
        self.anneal(current_quality)

        return updated

    def sample_perturbations(self, *args, **kwargs):
        """Sample perturbations (EGGROLL only)."""
        if hasattr(self._backend, 'sample_perturbations'):
            return self._backend.sample_perturbations(*args, **kwargs)
        raise AttributeError("GradientBackend doesn't use perturbation sampling")

    def state_dict(self) -> Dict[str, Any]:
        """Get full optimizer state including annealing."""
        return {
            'backend_state': self._backend.state_dict(),
            'backend_name': self._backend_name,
            'temperature': self._temperature,
            'iteration': self._iteration,
            'quality_history': self._quality_history,
            'switch_count': self._switch_count,
        }

    def load_state_dict(self, state: Dict[str, Any]):
        """Load optimizer state including annealing."""
        self._temperature = state.get('temperature', self._temperature)
        self._iteration = state.get('iteration', 0)
        self._quality_history = state.get('quality_history', [])
        self._switch_count = state.get('switch_count', 0)

        # Switch to saved backend if different
        saved_backend = state.get('backend_name', self._backend_name)
        if saved_backend != self._backend_name:
            self._switch_backend(saved_backend)

        # Load backend-specific state
        if 'backend_state' in state:
            self._backend.load_state_dict(state['backend_state'])


def get_backend_for_paradigm(
    paradigm: Union[Paradigm, str, int],
    **kwargs
) -> AdaptiveBackend:
    """
    Convenience function to get optimal backend for a paradigm.

    Parameters
    ----------
    paradigm : Paradigm, str, or int
        The YRSN paradigm (1-5 or name)
    **kwargs
        Additional arguments passed to AdaptiveBackend

    Returns
    -------
    AdaptiveBackend
        Configured backend for the paradigm
    """
    # Convert string/int to Paradigm enum
    if isinstance(paradigm, str):
        paradigm = Paradigm[paradigm.upper().replace(' ', '_')]
    elif isinstance(paradigm, int):
        paradigm = list(Paradigm)[paradigm - 1]  # 1-indexed

    profile = TaskProfile(paradigm=paradigm)
    return AdaptiveBackend(task_profile=profile, **kwargs)


# Convenience aliases
def iterative_refinement_backend(**kwargs) -> AdaptiveBackend:
    """Get backend optimized for Iterative Refinement paradigm."""
    return get_backend_for_paradigm(Paradigm.ITERATIVE_REFINEMENT, **kwargs)

def bit_slicing_backend(**kwargs) -> AdaptiveBackend:
    """Get backend optimized for Bit-Slicing paradigm."""
    return get_backend_for_paradigm(Paradigm.BIT_SLICING, **kwargs)

def hierarchical_backend(**kwargs) -> AdaptiveBackend:
    """Get backend optimized for Hierarchical Decomposition paradigm."""
    return get_backend_for_paradigm(Paradigm.HIERARCHICAL_DECOMPOSITION, **kwargs)

def layered_backend(**kwargs) -> AdaptiveBackend:
    """Get backend optimized for Layered Architecture paradigm."""
    return get_backend_for_paradigm(Paradigm.LAYERED_ARCHITECTURE, **kwargs)

def neural_backend(**kwargs) -> AdaptiveBackend:
    """Get backend optimized for Neural Context Retrieval paradigm."""
    return get_backend_for_paradigm(Paradigm.NEURAL_CONTEXT, **kwargs)


def annealing_backend(
    paradigm: Optional[Paradigm] = None,
    initial_temperature: float = 5.0,
    switch_temperature: float = 1.5,
    cooling_rate: float = 0.95,
    **kwargs
) -> AdaptiveBackend:
    """
    Get backend with temperature annealing enabled for dynamic switching.

    Starts with EGGROLL (exploration) at high temperature, automatically
    switches to Gradient (refinement) as temperature cools below threshold.

    Parameters
    ----------
    paradigm : Paradigm, optional
        YRSN paradigm (affects initial backend selection)
    initial_temperature : float
        Starting temperature τ₀ (default 5.0)
    switch_temperature : float
        Temperature at which to switch EGGROLL→Gradient (default 1.5)
    cooling_rate : float
        Geometric cooling factor λ (default 0.95)
    **kwargs
        Additional arguments passed to AdaptiveBackend

    Returns
    -------
    AdaptiveBackend
        Backend with annealing enabled

    Example
    -------
    >>> backend = annealing_backend(paradigm=Paradigm.BIT_SLICING)
    >>> for step in range(100):
    ...     # Optimization step
    ...     params = backend.step(params, gradients_or_fitness)
    ...     # Anneal temperature (may switch backend)
    ...     switched = backend.anneal(current_quality=0.6)
    ...     if switched:
    ...         print(f"Switched to {backend.backend_name} at τ={backend.temperature:.2f}")
    """
    config = AnnealingConfig(
        initial_temperature=initial_temperature,
        switch_temperature=switch_temperature,
        cooling_rate=cooling_rate,
    )

    profile = TaskProfile(
        paradigm=paradigm,
        enable_annealing=True,
        annealing_config=config,
    )

    return AdaptiveBackend(task_profile=profile, **kwargs)
