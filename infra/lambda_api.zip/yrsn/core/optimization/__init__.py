"""
YRSN Optimization Backends
==========================

Pluggable optimization strategies for the YRSN framework.

Backends available:
- AdaptiveBackend: Auto-selects optimal backend based on task (DEFAULT)
- GradientBackend: Standard gradient-based optimization (Adam, SGD, etc.)
- EggrollBackend: Evolution-guided low-rank optimization (gradient-free)

The 5 YRSN paradigms describe WHAT context engineering operations to perform.
These optimization backends describe HOW to train and optimize parameters.

Selection Logic (AdaptiveBackend):
- Paradigms 1-4 (classical) → EGGROLL (handles discrete/non-diff objectives)
- Paradigm 5 (neural) → Gradient (unless quantized training)
- Discrete decisions → EGGROLL
- Non-differentiable objectives → EGGROLL
- Memory-constrained → EGGROLL
- Smooth differentiable → Gradient

Usage:
    # Let the system choose
    from yrsn.core.optimization import AdaptiveBackend, Paradigm, TaskProfile
    backend = AdaptiveBackend(TaskProfile(paradigm=Paradigm.BIT_SLICING))

    # Or use convenience functions
    from yrsn.core.optimization import bit_slicing_backend
    backend = bit_slicing_backend()
"""

from .gradient_backend import GradientBackend
from .eggroll_backend import EggrollBackend, LowRankPerturbation, PhaseTransition
from .adaptive_backend import (
    AdaptiveBackend,
    TaskProfile,
    Paradigm,
    ObjectiveType,
    AnnealingConfig,
    QualityMetrics,
    get_backend_for_paradigm,
    # Convenience functions
    iterative_refinement_backend,
    bit_slicing_backend,
    hierarchical_backend,
    layered_backend,
    neural_backend,
    annealing_backend,
)

__all__ = [
    # Adaptive (recommended)
    "AdaptiveBackend",
    "TaskProfile",
    "Paradigm",
    "ObjectiveType",
    "AnnealingConfig",
    "QualityMetrics",
    "get_backend_for_paradigm",
    # Convenience functions
    "iterative_refinement_backend",
    "bit_slicing_backend",
    "hierarchical_backend",
    "layered_backend",
    "neural_backend",
    "annealing_backend",
    # Direct backends
    "GradientBackend",
    "EggrollBackend",
    "LowRankPerturbation",
    # Phase transitions
    "PhaseTransition",
]
