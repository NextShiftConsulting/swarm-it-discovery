"""
YRSN Core Protocols - Abstract interfaces for the pipeline.

These protocols define the contracts between components:
- IPreProcessor: Data scrubbing before YRSN pipeline
- ISignalExtractor: Domain signals → R, S, N decomposition
- IContextEncoder: Raw data → high-dimensional vectors

Using Protocol (structural subtyping) instead of ABC allows
implementations without explicit inheritance - duck typing with type hints.

Author: YRSN Framework (Rudy Martin)
"""

from __future__ import annotations

from typing import Any, Tuple, Dict, List, Optional, Union
try:
    from typing import Protocol
except ImportError:
    from typing_extensions import Protocol
from dataclasses import dataclass
import numpy as np


# =============================================================================
# DATA TYPES
# =============================================================================

@dataclass
class QualitySignals:
    """
    Quality signals from pre-processing, fed to SignalExtractor.

    This is the bridge between scrubbers and YRSN decomposition.
    """
    # Core quality metrics (0-1, higher = better)
    label_quality: float = 1.0          # Cleanlab label quality
    ood_score: float = 0.0              # Out-of-distribution (0=in, 1=out)
    confidence: float = 1.0             # Classifier confidence

    # Text quality (if applicable)
    toxicity: float = 0.0               # Toxic content score
    pii_detected: bool = False          # PII found
    verbosity: float = 0.0              # Excessive length
    informality: float = 0.0            # Informal language

    # Multi-annotator (if applicable)
    annotator_agreement: float = 1.0    # Agreement among annotators
    consensus_quality: float = 1.0      # Quality of consensus

    # Retrieval/RAG (if applicable)
    retrieval_similarity: float = 1.0   # Top-k retrieval score
    category_agreement: bool = True     # Retrieved docs agree on category

    # Token/NER (if applicable)
    token_quality: float = 1.0          # Per-token quality
    is_critical_entity: bool = False    # AMOUNT, DATE, etc.
    boundary_quality: float = 1.0       # Entity boundary confidence

    # Flags
    is_duplicate: bool = False          # Near-duplicate detected
    is_label_issue: bool = False        # Potential mislabel
    critical_failure: bool = False      # Hard reject flag
    failure_reason: Optional[str] = None

    # Raw signals dict for extensibility
    extra: Dict[str, Any] = None

    def __post_init__(self):
        if self.extra is None:
            self.extra = {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label_quality": self.label_quality,
            "ood_score": self.ood_score,
            "confidence": self.confidence,
            "toxicity": self.toxicity,
            "pii_detected": self.pii_detected,
            "verbosity": self.verbosity,
            "annotator_agreement": self.annotator_agreement,
            "retrieval_similarity": self.retrieval_similarity,
            "is_duplicate": self.is_duplicate,
            "is_label_issue": self.is_label_issue,
            "critical_failure": self.critical_failure,
            **self.extra
        }


@dataclass
class YRSNDecomposition:
    """
    The fundamental Y=R+S+N decomposition result.

    Invariant: R + S + N = 1.0
    """
    R: float  # Relevant (signal)
    S: float  # Superfluous (noise that doesn't hurt)
    N: float  # Noise (harmful, corrupting)

    # Derived
    collapse_type: str = "none"
    collapse_risk: float = 0.0

    def __post_init__(self):
        # Normalize to sum to 1
        total = self.R + self.S + self.N
        if total > 0:
            self.R /= total
            self.S /= total
            self.N /= total

    @property
    def quality_score(self) -> float:
        """Y-score: R + 0.5*S"""
        return self.R + 0.5 * self.S

    @property
    def risk_score(self) -> float:
        """Risk: S + 1.5*N"""
        return self.S + 1.5 * self.N

    @property
    def alpha(self) -> float:
        """Quality alpha = R (for temperature computation)."""
        return self.R


# =============================================================================
# PROTOCOLS (Interfaces)
# =============================================================================

class IPreProcessor(Protocol):
    """
    Gatekeeper that scrubs data before it enters the YRSN pipeline.

    Implementations:
    - CleanlabPreProcessor: Label quality, OOD, duplicates
    - TextQualityPreProcessor: Toxicity, PII, verbosity
    - PIIPreProcessor: Sensitive data detection
    - BusinessRuleValidator: Domain-specific rules

    Usage:
        scrubber = CleanlabPreProcessor()
        cleaned_data, signals = scrubber.scrub(raw_data)

        if signals.critical_failure:
            reject(signals.failure_reason)
        else:
            yrsn = extractor.extract(signals)
    """

    def scrub(self, raw_data: Any) -> Tuple[Any, QualitySignals]:
        """
        Scrub raw data and extract quality signals.

        Parameters
        ----------
        raw_data : Any
            Input data (DataFrame, dict, text, etc.)

        Returns
        -------
        Tuple[Any, QualitySignals]
            - cleaned_data: Potentially modified/sanitized data
            - signals: Quality metrics for YRSN decomposition
        """
        ...

    def should_reject(self, signals: QualitySignals) -> Tuple[bool, Optional[str]]:
        """
        Check if data should be hard-rejected before routing.

        Some data is SO bad it should never enter the pipeline.

        Returns
        -------
        Tuple[bool, Optional[str]]
            - reject: True if data should be rejected
            - reason: Why it was rejected
        """
        ...


class ISignalExtractor(Protocol):
    """
    Converts domain-specific quality signals to Y=R+S+N decomposition.

    This is where domain knowledge lives:
    - ApprovalExtractor: label_quality → N, margin → S
    - TextExtractor: toxicity → N, verbosity → S
    - RAGExtractor: OOD → N, low_similarity → S
    - NERExtractor: token_quality → N, boundary_error → S

    Usage:
        extractor = ApprovalSignalExtractor()
        yrsn = extractor.extract(signals)
        tau = config.compute_tau(yrsn.alpha)
    """

    def extract(self, signals: QualitySignals) -> YRSNDecomposition:
        """
        Extract R, S, N from quality signals.

        Parameters
        ----------
        signals : QualitySignals
            Quality metrics from pre-processing

        Returns
        -------
        YRSNDecomposition
            The R, S, N decomposition with collapse detection
        """
        ...

    def get_critical_rules(self) -> Dict[str, Any]:
        """
        Return domain-specific rules for POISONING detection.

        E.g., NER might return {"critical_entities": ["AMOUNT", "DATE"]}
        """
        ...


class IContextEncoder(Protocol):
    """
    Encodes raw data into high-dimensional vectors for memory or RSN extraction.

    Used by:
    - MemristiveExperienceLayer for similarity search (vector output)
    - SERG certify_handler for RSN extraction (RSN output)

    Implementations:
    - TextEncoder: Sentence transformers
    - StructuredEncoder: Numeric features → thermometer coding
    - HybridEncoder: Text + structured combined
    - MIMORSNAdapter: LLM reasoning → RSN extraction (semantic)
    - TextRSNAdapter: Text embeddings → RSN via projection (P15)
    """

    def encode(self, data: Any) -> Union[np.ndarray, Dict[str, float]]:
        """
        Encode data to vector or RSN decomposition.

        Parameters
        ----------
        data : Any
            Raw data (text, dict, etc.)

        Returns
        -------
        Union[np.ndarray, Dict[str, float]]
            - np.ndarray: High-dimensional vector for memory
            - Dict[str, float]: RSN decomposition with metadata
                Required keys: R, S, N, alpha, kappa, sigma
                Metadata keys: _source, _p15_compliant, _version
                Optional: _reasoning, _latency_ms
        """
        ...

    @property
    def dim(self) -> int:
        """Dimension of output vectors (for vector-based encoders)."""
        ...


class IRSNEncoder(Protocol):
    """
    Specialized protocol for RSN extraction from context.

    This extends IContextEncoder specifically for RSN decomposition,
    requiring semantic validation and P15 compliance checking.

    Implementations:
    - MIMORSNAdapter: Uses MIMO reasoning_content (semantic, P15 compliant)
    - TextRSNAdapter: Uses text embeddings + projection (requires trained checkpoint)
    """

    def encode_rsn(self, context: str) -> Dict[str, float]:
        """
        Extract RSN decomposition from context.

        Parameters
        ----------
        context : str
            Input context (prompt, text, etc.)

        Returns
        -------
        Dict[str, float]
            RSN decomposition with metadata:
            - R, S, N: Barycentric coordinates (sum to 1.0)
            - alpha: Quality signal (R - 0.5*S - N)
            - kappa: Compatibility/efficiency metric
            - sigma: Instability metric
            - _source: str - Encoder identifier
            - _p15_compliant: bool - Uses HybridSimplexRotor or semantic extraction
            - _version: str - Encoder version
            - _reasoning: Optional[str] - LLM reasoning trace (for MIMO)
            - _latency_ms: Optional[float] - Extraction time
        """
        ...

    def validate_semantic(self, context: str, rsn: Dict[str, float]) -> bool:
        """
        Validate that RSN extraction is semantically grounded.

        Proves I(encoding, problem) > 0 where:
        - encoding: RSN values extracted
        - problem: Original context

        Parameters
        ----------
        context : str
            Original input context
        rsn : Dict[str, float]
            Extracted RSN decomposition

        Returns
        -------
        bool
            True if encoding is information-theoretically valid
            (not just random hash)
        """
        ...


# =============================================================================
# PIPELINE PROTOCOL
# =============================================================================

class IYRSNPipeline(Protocol):
    """
    Full YRSN pipeline from raw data to routing decision.

    Combines: PreProcessor → SignalExtractor → Router → Memory
    """

    def process(
        self,
        raw_data: Any,
        is_special: bool = False
    ) -> Dict[str, Any]:
        """
        Process raw data through the full YRSN pipeline.

        Parameters
        ----------
        raw_data : Any
            Input data
        is_special : bool
            If True, apply extra scrubbing for special requests

        Returns
        -------
        Dict with keys:
            - stream: GREEN/YELLOW/RED
            - confidence: Routing confidence
            - yrsn: R, S, N decomposition
            - temperature: τ value
            - signals: Quality signals used
        """
        ...

    def learn(
        self,
        raw_data: Any,
        predicted_stream: str,
        actual_stream: str,
        was_override: bool
    ) -> Dict[str, Any]:
        """
        Learn from outcome (especially human overrides).

        Returns
        -------
        Dict with learning statistics
        """
        ...


# =============================================================================
# CHAIN HELPER
# =============================================================================

class PreProcessorChain:
    """
    Chains multiple pre-processors for special requests.

    Usage:
        chain = PreProcessorChain([
            CleanlabPreProcessor(),
            PIIPreProcessor(),
            BusinessRuleValidator()
        ])

        cleaned, signals = chain.scrub(raw_data)
    """

    def __init__(self, processors: List[IPreProcessor]):
        self.processors = processors

    def scrub(self, raw_data: Any) -> Tuple[Any, QualitySignals]:
        """Run all processors, merging signals."""
        data = raw_data
        merged_signals = QualitySignals()

        for processor in self.processors:
            data, signals = processor.scrub(data)

            # Merge signals (take worst quality for quality metrics, max for risk metrics)

            # Quality metrics (min = worst quality)
            merged_signals.label_quality = min(
                merged_signals.label_quality, signals.label_quality
            )
            merged_signals.confidence = min(
                merged_signals.confidence, signals.confidence
            )
            merged_signals.annotator_agreement = min(
                merged_signals.annotator_agreement, signals.annotator_agreement
            )
            merged_signals.consensus_quality = min(
                merged_signals.consensus_quality, signals.consensus_quality
            )
            merged_signals.retrieval_similarity = min(
                merged_signals.retrieval_similarity, signals.retrieval_similarity
            )
            merged_signals.token_quality = min(
                merged_signals.token_quality, signals.token_quality
            )
            merged_signals.boundary_quality = min(
                merged_signals.boundary_quality, signals.boundary_quality
            )

            # Risk metrics (max = worst risk)
            merged_signals.ood_score = max(
                merged_signals.ood_score, signals.ood_score
            )
            merged_signals.toxicity = max(
                merged_signals.toxicity, signals.toxicity
            )
            merged_signals.verbosity = max(
                merged_signals.verbosity, signals.verbosity
            )
            merged_signals.informality = max(
                merged_signals.informality, signals.informality
            )

            # Boolean flags (any True triggers)
            merged_signals.pii_detected = (
                merged_signals.pii_detected or signals.pii_detected
            )
            merged_signals.is_duplicate = (
                merged_signals.is_duplicate or signals.is_duplicate
            )
            merged_signals.is_label_issue = (
                merged_signals.is_label_issue or signals.is_label_issue
            )
            merged_signals.is_critical_entity = (
                merged_signals.is_critical_entity or signals.is_critical_entity
            )
            merged_signals.category_agreement = (
                merged_signals.category_agreement and signals.category_agreement
            )

            # Critical failure stops the chain
            if signals.critical_failure:
                merged_signals.critical_failure = True
                merged_signals.failure_reason = signals.failure_reason
                break

            # Merge extra signals
            merged_signals.extra.update(signals.extra or {})

        return data, merged_signals

    def should_reject(self, signals: QualitySignals) -> Tuple[bool, Optional[str]]:
        """Check if any processor would reject."""
        if signals.critical_failure:
            return True, signals.failure_reason
        return False, None


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Data types
    "QualitySignals",
    "YRSNDecomposition",
    # Protocols
    "IPreProcessor",
    "ISignalExtractor",
    "IContextEncoder",
    "IRSNEncoder",
    "IYRSNPipeline",
    # Helpers
    "PreProcessorChain",
]
