"""
YRSN Adaptive Temperature Configuration (UNIFIED)
==================================================

Consolidates ALL temperature, threshold, and activation settings from:
- yrsn-context (activation modes, phase thresholds)
- yrsn-iars (temperature modes, routing thresholds)
- yrsn-memristor (learning rates tied to τ)

Import this instead of scattered configs:
    from yrsn.core.adaptive_config import AdaptiveTemperatureConfig

Author: YRSN Framework (Rudy Martin)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, Any, Tuple, Union
import numpy as np

# Optional barrier control import
try:
    from yrsn.core.control import ControlBarrier, BarrierConfig
    CONTROL_AVAILABLE = True
except ImportError:
    CONTROL_AVAILABLE = False
    ControlBarrier = None
    BarrierConfig = None


# =============================================================================
# ENUMS
# =============================================================================

class ActivationMode(Enum):
    """Activation function for τ = f(α). Determines HOW τ responds to α."""
    LINEAR = "linear"      # τ = 1/α
    POWER = "power"        # τ = 1/α^k (production default)
    LOG = "log"            # τ = 1/log(1+cα)
    SIGMOID = "sigmoid"    # Bounded S-curve


class TemperatureMode(Enum):
    """Temperature control mode. Determines WHEN to compute τ."""
    ADAPTIVE = "adaptive"        # τ = f(α), dynamic
    FIXED_TIGHT = "tight"        # τ = 0.1
    FIXED_MID = "mid"            # τ = 1.0
    FIXED_LOOSE = "loose"        # τ = 2.0 (shadow mode)
    ANNEALING = "annealing"      # τ decreases over time


class QualityPhase(Enum):
    """Content quality phase based on α."""
    HIGH = "high"          # α > 0.70
    MEDIUM = "medium"      # 0.40 ≤ α ≤ 0.70
    LOW = "low"            # α < 0.40


class Stream(Enum):
    """Routing stream for decisions."""
    GREEN = "green"        # Auto-approve
    YELLOW = "yellow"      # AI-assisted human review
    RED = "red"            # Expert manual review


class CollapseType(Enum):
    """Types of context collapse."""
    NONE = "none"
    POISONING = "poisoning"        # High N
    DISTRACTION = "distraction"    # High S
    CONFLICT = "conflict"          # High N + S
    CLASH = "clash"                # Source conflicts


# =============================================================================
# CONSTANTS: All thresholds in ONE place
# =============================================================================

# Quality phase boundaries
ALPHA_HIGH_THRESHOLD = 0.70
ALPHA_LOW_THRESHOLD = 0.40

# Critical temperatures
TAU_CRITICAL_1 = 1.43            # HIGH → MEDIUM
TAU_CRITICAL_2 = 2.50            # MEDIUM → LOW

# Routing thresholds
CS_GREEN_THRESHOLD = 0.95
CS_YELLOW_THRESHOLD = 0.70

# Quality knockouts (production-tuned from IARS)
MIN_R_THRESHOLD = 0.50   # Minimum R for green stream (stricter)
MAX_N_THRESHOLD = 0.30   # Maximum N allowed (stricter)

# Temperature bounds
TAU_MIN_DEFAULT = 0.1
TAU_MAX_DEFAULT = 5.0


# =============================================================================
# SUPPORTING DATACLASSES
# =============================================================================

@dataclass
class RoutingThresholds:
    """Routing decision thresholds."""
    green: float = CS_GREEN_THRESHOLD
    yellow: float = CS_YELLOW_THRESHOLD
    min_R: float = MIN_R_THRESHOLD
    max_N: float = MAX_N_THRESHOLD

    def to_dict(self) -> Dict[str, float]:
        return {"green": self.green, "yellow": self.yellow,
                "min_R": self.min_R, "max_N": self.max_N}


@dataclass
class AnnealingSchedule:
    """Temperature annealing for learning."""
    tau_initial: float = 2.0
    tau_final: float = 0.3
    total_steps: int = 1000
    schedule: str = "linear"  # "linear", "cosine", "exponential"

    def compute_tau(self, step: int) -> float:
        progress = min(1.0, step / max(1, self.total_steps))
        if self.schedule == "cosine":
            cos_progress = 0.5 * (1 + math.cos(math.pi * progress))
            return self.tau_final + cos_progress * (self.tau_initial - self.tau_final)
        elif self.schedule == "exponential":
            decay = -math.log(self.tau_final / self.tau_initial) / self.total_steps
            return self.tau_initial * math.exp(-decay * step)
        return self.tau_initial + progress * (self.tau_final - self.tau_initial)


@dataclass(frozen=True)
class TemperatureResult:
    """
    Immutable result of temperature computation.

    Used by IARS for audit trail and decision tracking.
    """
    tau: float                      # Computed temperature
    alpha: float                    # Quality score used (R)
    mode: TemperatureMode           # Mode that was applied
    step: int = 0                   # Current step (for annealing)

    @property
    def is_tight(self) -> bool:
        """Temperature indicates tight/strict routing."""
        return self.tau < 1.0

    @property
    def is_loose(self) -> bool:
        """Temperature indicates loose/flexible routing."""
        return self.tau > 1.5


# =============================================================================
# UNIFIED CONFIGURATION
# =============================================================================

@dataclass
class AdaptiveTemperatureConfig:
    """
    UNIFIED configuration for temperature-quality duality.

    Usage:
        config = AdaptiveTemperatureConfig()
        tau = config.compute_tau(alpha=0.8)
        phase = config.get_phase(alpha=0.8)
        stream = config.get_stream(confidence=0.92)
    """

    # Mode control
    mode: TemperatureMode = TemperatureMode.ADAPTIVE
    activation: ActivationMode = ActivationMode.POWER

    # Temperature bounds
    tau_min: float = TAU_MIN_DEFAULT
    tau_max: float = TAU_MAX_DEFAULT

    # Activation parameters
    power_k: float = 2.0
    log_c: float = 10.0
    sigmoid_k: float = 12.0
    sigmoid_center: float = 0.5

    # Fixed values
    tau_tight: float = 0.1
    tau_mid: float = 1.0
    tau_loose: float = 2.0

    # Phase thresholds
    alpha_high: float = ALPHA_HIGH_THRESHOLD
    alpha_low: float = ALPHA_LOW_THRESHOLD

    # Routing & annealing
    routing: RoutingThresholds = field(default_factory=RoutingThresholds)
    annealing: AnnealingSchedule = field(default_factory=AnnealingSchedule)

    # Collapse detection (production-tuned from IARS - more sensitive)
    collapse_n_threshold: float = 0.30   # N > this triggers poisoning/confusion
    collapse_s_threshold: float = 0.40   # S > this triggers distraction
    collapse_s_confusion: float = 0.25   # S > this + high N = confusion

    # Memristor integration
    memristor_base_rate: float = 0.01
    memristor_tau_coupling: float = 1.0

    # Control barrier function (optional)
    use_barrier_control: bool = False
    barrier_config: Optional[Any] = None  # BarrierConfig from control module

    # State
    _step: int = field(default=0, repr=False)
    _barrier: Optional[Any] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        """Initialize barrier control if enabled."""
        if self.use_barrier_control and CONTROL_AVAILABLE:
            if self.barrier_config is None:
                # Use defaults
                self._barrier = ControlBarrier()
            else:
                self._barrier = ControlBarrier(self.barrier_config)
        elif self.use_barrier_control and not CONTROL_AVAILABLE:
            import warnings
            warnings.warn(
                "Barrier control requested but control module not available. "
                "Install control dependencies or set use_barrier_control=False."
            )

    # =========================================================================
    # CORE COMPUTATION
    # =========================================================================

    def compute_tau(
        self,
        alpha: float = None,
        R: float = None,
        omega: float = 1.0,
        prior: float = 0.5,
        use_barrier: bool = True,
        mode: str = "prediction",
        **_
    ) -> float:
        """
        Compute temperature from quality with optional barrier constraints.

        Uses P14 conjunction formula:
            α_ω = α × ω + prior × (1 - ω)
            τ = f(α_ω)  where f is the activation function

        Args:
            alpha: Quality signal
            R: Relevant signal (used if alpha not provided)
            omega: Reliability coefficient [0, 1]. Default 1.0 = in-distribution.
            prior: Collapse prevention baseline. Default 0.5.
            use_barrier: Whether to apply control barrier function constraints
            mode: "prediction" or "write" (affects barrier limits)
        """
        if alpha is None:
            alpha = R if R is not None else 0.5

        # P14 conjunction: α_ω = α × ω + prior × (1 - ω)
        alpha_omega = alpha * omega + (1 - omega) * prior

        # Compute base tau
        if self.mode == TemperatureMode.FIXED_TIGHT:
            base_tau = self.tau_tight
        elif self.mode == TemperatureMode.FIXED_MID:
            base_tau = self.tau_mid
        elif self.mode == TemperatureMode.FIXED_LOOSE:
            base_tau = self.tau_loose
        elif self.mode == TemperatureMode.ANNEALING:
            tau = self.annealing.compute_tau(self._step)
            self._step += 1
            base_tau = max(self.tau_min, min(self.tau_max, tau))
        else:
            base_tau = self._adaptive_tau(alpha_omega)
        
        # Apply barrier constraints if enabled
        if use_barrier and hasattr(self, '_barrier'):
            safe_tau, _ = self._barrier.compute_safe_tau(alpha, base_tau, mode)
            return safe_tau
        
        return base_tau

    def _adaptive_tau(self, alpha_omega: float) -> float:
        """
        Apply activation function to reliability-adjusted quality.

        Args:
            alpha_omega: P14 blended quality (α × ω + prior × (1 - ω))

        Returns:
            Temperature τ bounded by [tau_min, tau_max]
        """
        alpha_omega = max(0.001, min(1.0, alpha_omega))

        if self.activation == ActivationMode.LINEAR:
            tau = 1.0 / alpha_omega
        elif self.activation == ActivationMode.POWER:
            tau = 1.0 / (alpha_omega ** self.power_k)
        elif self.activation == ActivationMode.LOG:
            tau = 1.0 / math.log(1 + self.log_c * alpha_omega)
        elif self.activation == ActivationMode.SIGMOID:
            sig = 1.0 / (1.0 + math.exp(-self.sigmoid_k * (self.sigmoid_center - alpha_omega)))
            return self.tau_min + (self.tau_max - self.tau_min) * sig
        else:
            tau = 1.0 / alpha_omega

        return max(self.tau_min, min(self.tau_max, tau))

    # =========================================================================
    # PHASE & STREAM
    # =========================================================================

    def get_phase(self, alpha: float) -> QualityPhase:
        if alpha > self.alpha_high:
            return QualityPhase.HIGH
        elif alpha >= self.alpha_low:
            return QualityPhase.MEDIUM
        return QualityPhase.LOW

    def get_stream(self, confidence: float, R: float = None, N: float = None,
                   tau: float = None) -> Stream:
        # Knockouts
        if R is not None and R < self.routing.min_R:
            return Stream.RED
        if N is not None and N > self.routing.max_N:
            return Stream.RED

        thresholds = self.adjust_thresholds(tau) if tau else self.routing

        if confidence >= thresholds.green:
            return Stream.GREEN
        elif confidence >= thresholds.yellow:
            return Stream.YELLOW
        return Stream.RED

    def adjust_thresholds(self, tau: float) -> RoutingThresholds:
        """Adjust thresholds by τ. High τ → looser."""
        adj = 0.05 * (1 - tau)
        return RoutingThresholds(
            green=max(0.85, min(0.99, self.routing.green + adj)),
            yellow=max(0.50, min(0.85, self.routing.yellow + adj)),
            min_R=self.routing.min_R,
            max_N=self.routing.max_N
        )

    # =========================================================================
    # COLLAPSE DETECTION
    # =========================================================================

    def detect_collapse(self, R: float, S: float, N: float) -> Tuple[CollapseType, float]:
        """
        Detect context collapse type from R/S/N ratios.

        Thresholds tuned from IARS production (more sensitive detection).
        """
        risk = self.compute_risk_score(R, S, N)

        # Confusion: high noise AND moderate superfluous
        if N > self.collapse_n_threshold and S > self.collapse_s_confusion:
            return CollapseType.CONFLICT, min(1.0, risk)
        # Poisoning: high noise alone
        elif N > self.collapse_n_threshold:
            return CollapseType.POISONING, min(1.0, N / 0.5)
        # Distraction: high superfluous
        elif S > self.collapse_s_threshold:
            return CollapseType.DISTRACTION, min(1.0, S / 0.7)
        # Clash: elevated risk score (from IARS: risk > 0.6)
        elif risk > 0.6:
            return CollapseType.CLASH, min(1.0, risk)
        return CollapseType.NONE, 0.0

    # =========================================================================
    # DERIVED SCORES
    # =========================================================================

    def compute_y_score(self, R: float, S: float, N: float) -> float:
        return R + 0.5 * S

    def compute_risk_score(self, R: float, S: float, N: float) -> float:
        return S + 1.5 * N

    def compute_confidence(self, R: float, S: float, N: float,
                           classifier_conf: float = 1.0,
                           urgency: float = 0.0) -> float:
        cs = 0.4 * classifier_conf + 0.3 * R + 0.2 * (1 - N) - 0.1 * urgency
        return max(0.0, min(1.0, cs))

    # =========================================================================
    # MEMRISTOR
    # =========================================================================

    def get_memristor_learning_rate(self, tau: float) -> float:
        """High τ → more plastic (learn more)."""
        return self.memristor_base_rate * tau * self.memristor_tau_coupling

    # =========================================================================
    # SOFTMAX
    # =========================================================================

    def softmax(self, scores: Union[np.ndarray, Dict[str, float]],
                tau: float = None) -> Union[np.ndarray, Dict[str, float]]:
        tau = tau or self.tau_mid
        if isinstance(scores, dict):
            keys = list(scores.keys())
            vals = np.array([scores[k] for k in keys])
            probs = self._softmax_arr(vals, tau)
            return {k: float(p) for k, p in zip(keys, probs)}
        return self._softmax_arr(scores, tau)

    def _softmax_arr(self, scores: np.ndarray, tau: float) -> np.ndarray:
        scaled = scores / tau - np.max(scores / tau)
        exp_s = np.exp(scaled)
        return exp_s / np.sum(exp_s)

    # =========================================================================
    # UTILITY
    # =========================================================================

    def reset(self):
        self._step = 0

    @property
    def step(self) -> int:
        return self._step

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode.value,
            "activation": self.activation.value,
            "tau_min": self.tau_min,
            "tau_max": self.tau_max,
            "power_k": self.power_k,
            "alpha_high": self.alpha_high,
            "alpha_low": self.alpha_low,
            "routing": self.routing.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AdaptiveTemperatureConfig":
        return cls(
            mode=TemperatureMode(d.get("mode", "adaptive")),
            activation=ActivationMode(d.get("activation", "power")),
            tau_min=d.get("tau_min", TAU_MIN_DEFAULT),
            tau_max=d.get("tau_max", TAU_MAX_DEFAULT),
            power_k=d.get("power_k", 2.0),
            alpha_high=d.get("alpha_high", ALPHA_HIGH_THRESHOLD),
            alpha_low=d.get("alpha_low", ALPHA_LOW_THRESHOLD),
            routing=RoutingThresholds(**d.get("routing", {})),
            annealing=AnnealingSchedule(**d.get("annealing", {})),
        )


# =============================================================================
# PRESET CONFIGURATIONS
# =============================================================================

def production_config() -> AdaptiveTemperatureConfig:
    """Production: sharp response, strict thresholds."""
    return AdaptiveTemperatureConfig(activation=ActivationMode.POWER, power_k=2.0)


def learning_config(steps: int = 1000) -> AdaptiveTemperatureConfig:
    """Learning: annealing from explore to exploit."""
    return AdaptiveTemperatureConfig(
        mode=TemperatureMode.ANNEALING,
        annealing=AnnealingSchedule(
            tau_initial=2.0, tau_final=0.3,
            total_steps=steps, schedule="cosine"
        )
    )


def shadow_config() -> AdaptiveTemperatureConfig:
    """Shadow mode: always loose for testing."""
    return AdaptiveTemperatureConfig(
        mode=TemperatureMode.FIXED_LOOSE,
        routing=RoutingThresholds(green=0.99, yellow=0.50)
    )


def conservative_config() -> AdaptiveTemperatureConfig:
    """Conservative: bounded sigmoid, no extremes."""
    return AdaptiveTemperatureConfig(
        activation=ActivationMode.SIGMOID,
        tau_min=0.3, tau_max=3.0
    )


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def compute_tau(alpha: float, config: AdaptiveTemperatureConfig = None) -> float:
    return (config or AdaptiveTemperatureConfig()).compute_tau(alpha=alpha)


def get_phase(alpha: float) -> QualityPhase:
    if alpha > ALPHA_HIGH_THRESHOLD:
        return QualityPhase.HIGH
    if alpha >= ALPHA_LOW_THRESHOLD:
        return QualityPhase.MEDIUM
    return QualityPhase.LOW


def get_stream(confidence: float) -> Stream:
    if confidence >= CS_GREEN_THRESHOLD:
        return Stream.GREEN
    if confidence >= CS_YELLOW_THRESHOLD:
        return Stream.YELLOW
    return Stream.RED


# =============================================================================
# TEST
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("AdaptiveTemperatureConfig - Unified Test")
    print("=" * 60)

    config = AdaptiveTemperatureConfig()

    print("\n--- Activation Modes ---")
    for alpha in [0.9, 0.5, 0.2]:
        for mode in ActivationMode:
            cfg = AdaptiveTemperatureConfig(activation=mode)
            tau = cfg.compute_tau(alpha=alpha)
            print(f"  α={alpha}, {mode.value:8s} → τ={tau:.2f}")

    print("\n--- Phases ---")
    for alpha in [0.85, 0.55, 0.25]:
        print(f"  α={alpha} → {config.get_phase(alpha).value}")

    print("\n--- Streams ---")
    for cs in [0.98, 0.80, 0.50]:
        print(f"  Cs={cs} → {config.get_stream(confidence=cs).value}")

    print("\n--- Annealing ---")
    cfg = learning_config(100)
    for step in [0, 50, 100]:
        tau = cfg.annealing.compute_tau(step)
        print(f"  step={step} → τ={tau:.2f}")

    print("\n--- Memristor LR ---")
    for tau in [0.5, 1.0, 2.0]:
        lr = config.get_memristor_learning_rate(tau)
        print(f"  τ={tau} → lr={lr:.4f}")

    print("\n" + "=" * 60)
    print("All thresholds UNIFIED!")
    print("=" * 60)
