"""
Environmental Validation Context (EVC) for Multi-Consumer Deployments

The EVC defines domain-specific quality rules and enforcement policies
for certificate validation across different deployment contexts.

Reference:
    - docs/business/DEPLOYMENT_MODES_UNIVERSAL_ROTOR_V2.md (Mode 2, 3)
    - Patent Spec §7.11: Certificate Structure Requirements

Usage:
    >>> from yrsn.core.evc import EnvironmentalValidationContext, EVCRegistry
    >>>
    >>> # Define domain-specific context
    >>> medical_evc = EnvironmentalValidationContext(
    ...     domain_id="hipaa_medical_v1",
    ...     description="Medical text quality validation",
    ...     modality="text",
    ...     thresholds=ModalityThresholds(tau_R=0.65, tau_S=0.20, tau_N=0.12),
    ...     corruption_types=["truncation", "contradiction"],
    ...     enforcement_mode="strict"
    ... )
    >>>
    >>> # Register for multi-consumer use
    >>> registry = EVCRegistry()
    >>> registry.register(medical_evc)
    >>>
    >>> # Consumers query at runtime
    >>> evc = registry.get("hipaa_medical_v1")
    >>> gateway = CQC_MAS_Gateway(config=evc.to_gateway_config())
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any
from enum import Enum
import hashlib
import json


class EnforcementMode(Enum):
    """Enforcement strictness levels."""
    PERMISSIVE = "permissive"  # Warn only, allow all
    NORMAL = "normal"         # Standard thresholds
    STRICT = "strict"         # Tighter thresholds (+0.05 tau_R)
    CRITICAL = "critical"     # Very tight, block on any uncertainty


@dataclass
class ModalityThresholds:
    """Per-modality R/S/N thresholds."""
    tau_R: float = 0.55
    tau_S: float = 0.25
    tau_N: float = 0.20

    def adjust_for_mode(self, mode: EnforcementMode) -> 'ModalityThresholds':
        """Return thresholds adjusted for enforcement mode."""
        if mode == EnforcementMode.PERMISSIVE:
            return ModalityThresholds(
                tau_R=self.tau_R - 0.10,
                tau_S=self.tau_S + 0.10,
                tau_N=self.tau_N + 0.10
            )
        elif mode == EnforcementMode.STRICT:
            return ModalityThresholds(
                tau_R=self.tau_R + 0.05,
                tau_S=self.tau_S - 0.05,
                tau_N=self.tau_N - 0.05
            )
        elif mode == EnforcementMode.CRITICAL:
            return ModalityThresholds(
                tau_R=self.tau_R + 0.10,
                tau_S=self.tau_S - 0.08,
                tau_N=self.tau_N - 0.08
            )
        return self  # NORMAL mode


@dataclass
class EnvironmentalValidationContext:
    """
    Domain-specific quality validation context.

    The EVC encapsulates all configuration needed to validate
    certificates in a specific domain/deployment context.

    Attributes:
        domain_id: Unique identifier (e.g., "hipaa_medical_v1")
        description: Human-readable description
        modality: Primary modality ('text', 'vision', 'audio', 'multimodal')
        thresholds: Base R/S/N thresholds for this domain
        corruption_types: Allowed/expected corruption types
        enforcement_mode: Strictness level
        feature_extractor_uri: Optional path to custom feature extractor
        rotor_uri: Optional path to custom rotor checkpoint
        created_by: Creator identifier
        approved_by: Approver identifier (for governance)
        created_at: Creation timestamp
        is_active: Whether this EVC is currently active
        metadata: Additional domain-specific metadata
    """
    domain_id: str
    description: str = ""
    modality: str = "text"
    thresholds: ModalityThresholds = field(default_factory=ModalityThresholds)
    corruption_types: List[str] = field(default_factory=list)
    enforcement_mode: EnforcementMode = EnforcementMode.NORMAL
    feature_extractor_uri: Optional[str] = None
    rotor_uri: Optional[str] = None
    created_by: Optional[str] = None
    approved_by: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    is_active: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_effective_thresholds(self) -> ModalityThresholds:
        """Get thresholds adjusted for enforcement mode."""
        return self.thresholds.adjust_for_mode(self.enforcement_mode)

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of EVC for integrity verification."""
        content = json.dumps({
            'domain_id': self.domain_id,
            'modality': self.modality,
            'thresholds': {
                'tau_R': self.thresholds.tau_R,
                'tau_S': self.thresholds.tau_S,
                'tau_N': self.thresholds.tau_N,
            },
            'enforcement_mode': self.enforcement_mode.value,
            'corruption_types': sorted(self.corruption_types),
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()

    def to_gateway_config(self) -> Dict[str, Any]:
        """
        Convert to GatewayConfig-compatible dict.

        Usage:
            >>> from yrsn.adapters.cqc_mas.gateway import GatewayConfig
            >>> config_dict = evc.to_gateway_config()
            >>> gateway = CQC_MAS_Gateway(GatewayConfig(**config_dict))
        """
        effective = self.get_effective_thresholds()
        return {
            'tau_R': effective.tau_R,
            'tau_S': effective.tau_S,
            'tau_N': effective.tau_N,
            'stage1_enabled': True,
            'stage2_enabled': True,
            'stage3_enabled': True,
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'domain_id': self.domain_id,
            'description': self.description,
            'modality': self.modality,
            'thresholds': {
                'tau_R': self.thresholds.tau_R,
                'tau_S': self.thresholds.tau_S,
                'tau_N': self.thresholds.tau_N,
            },
            'corruption_types': self.corruption_types,
            'enforcement_mode': self.enforcement_mode.value,
            'feature_extractor_uri': self.feature_extractor_uri,
            'rotor_uri': self.rotor_uri,
            'created_by': self.created_by,
            'approved_by': self.approved_by,
            'created_at': self.created_at,
            'is_active': self.is_active,
            'metadata': self.metadata,
            'hash': self.compute_hash(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EnvironmentalValidationContext':
        """Create from dictionary."""
        thresholds = ModalityThresholds(**data.get('thresholds', {}))
        mode = EnforcementMode(data.get('enforcement_mode', 'normal'))
        return cls(
            domain_id=data['domain_id'],
            description=data.get('description', ''),
            modality=data.get('modality', 'text'),
            thresholds=thresholds,
            corruption_types=data.get('corruption_types', []),
            enforcement_mode=mode,
            feature_extractor_uri=data.get('feature_extractor_uri'),
            rotor_uri=data.get('rotor_uri'),
            created_by=data.get('created_by'),
            approved_by=data.get('approved_by'),
            created_at=data.get('created_at', datetime.utcnow().isoformat()),
            is_active=data.get('is_active', True),
            metadata=data.get('metadata', {}),
        )


class EVCRegistry:
    """
    In-memory registry for Environmental Validation Contexts.

    For production use, extend this with database/S3 storage adapters.

    Usage:
        >>> registry = EVCRegistry()
        >>> registry.register(medical_evc)
        >>> registry.register(legal_evc)
        >>>
        >>> evc = registry.get("hipaa_medical_v1")
        >>> all_text_evcs = registry.list_by_modality("text")
    """

    def __init__(self):
        self._contexts: Dict[str, EnvironmentalValidationContext] = {}

    def register(self, evc: EnvironmentalValidationContext) -> None:
        """Register an EVC."""
        self._contexts[evc.domain_id] = evc

    def get(self, domain_id: str) -> Optional[EnvironmentalValidationContext]:
        """Get EVC by domain_id."""
        return self._contexts.get(domain_id)

    def get_or_default(
        self,
        domain_id: str,
        modality: str = "text"
    ) -> EnvironmentalValidationContext:
        """Get EVC or return a default for the modality."""
        evc = self.get(domain_id)
        if evc:
            return evc
        # Return default EVC for modality
        return EnvironmentalValidationContext(
            domain_id=f"default_{modality}",
            description=f"Default EVC for {modality}",
            modality=modality,
        )

    def list_by_modality(self, modality: str) -> List[EnvironmentalValidationContext]:
        """List all EVCs for a specific modality."""
        return [
            evc for evc in self._contexts.values()
            if evc.modality == modality and evc.is_active
        ]

    def list_all(self, include_inactive: bool = False) -> List[EnvironmentalValidationContext]:
        """List all registered EVCs."""
        if include_inactive:
            return list(self._contexts.values())
        return [evc for evc in self._contexts.values() if evc.is_active]

    def deactivate(self, domain_id: str) -> bool:
        """Deactivate an EVC (soft delete)."""
        if domain_id in self._contexts:
            self._contexts[domain_id].is_active = False
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        """Export registry to dictionary."""
        return {
            domain_id: evc.to_dict()
            for domain_id, evc in self._contexts.items()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EVCRegistry':
        """Load registry from dictionary."""
        registry = cls()
        for domain_id, evc_data in data.items():
            evc = EnvironmentalValidationContext.from_dict(evc_data)
            registry.register(evc)
        return registry


# =============================================================================
# PREDEFINED EVCs (Common Deployment Contexts)
# =============================================================================

# Medical domain (HIPAA compliance)
MEDICAL_TEXT_EVC = EnvironmentalValidationContext(
    domain_id="medical_text_v1",
    description="Medical text quality validation (HIPAA-aware)",
    modality="text",
    thresholds=ModalityThresholds(tau_R=0.65, tau_S=0.20, tau_N=0.12),
    corruption_types=["truncation", "contradiction", "dosage_ambiguity"],
    enforcement_mode=EnforcementMode.STRICT,
)

# Legal domain
LEGAL_TEXT_EVC = EnvironmentalValidationContext(
    domain_id="legal_text_v1",
    description="Legal document quality validation",
    modality="text",
    thresholds=ModalityThresholds(tau_R=0.60, tau_S=0.25, tau_N=0.15),
    corruption_types=["clause_removal", "contradictory_terms"],
    enforcement_mode=EnforcementMode.STRICT,
)

# Financial domain
FINANCIAL_TEXT_EVC = EnvironmentalValidationContext(
    domain_id="financial_text_v1",
    description="Financial document quality validation",
    modality="text",
    thresholds=ModalityThresholds(tau_R=0.60, tau_S=0.22, tau_N=0.15),
    corruption_types=["calculation_error", "missing_disclosure"],
    enforcement_mode=EnforcementMode.STRICT,
)

# Vision domain (factory/robotics)
INDUSTRIAL_VISION_EVC = EnvironmentalValidationContext(
    domain_id="industrial_vision_v1",
    description="Industrial vision quality validation",
    modality="vision",
    thresholds=ModalityThresholds(tau_R=0.70, tau_S=0.15, tau_N=0.10),
    corruption_types=["blur", "occlusion", "lighting"],
    enforcement_mode=EnforcementMode.CRITICAL,
)

# General purpose (default)
GENERAL_PURPOSE_EVC = EnvironmentalValidationContext(
    domain_id="general_v1",
    description="General purpose quality validation",
    modality="multimodal",
    thresholds=ModalityThresholds(tau_R=0.55, tau_S=0.25, tau_N=0.20),
    corruption_types=[],
    enforcement_mode=EnforcementMode.NORMAL,
)


def get_default_registry() -> EVCRegistry:
    """Get a registry pre-populated with common EVCs."""
    registry = EVCRegistry()
    registry.register(MEDICAL_TEXT_EVC)
    registry.register(LEGAL_TEXT_EVC)
    registry.register(FINANCIAL_TEXT_EVC)
    registry.register(INDUSTRIAL_VISION_EVC)
    registry.register(GENERAL_PURPOSE_EVC)
    return registry
