"""
YRSN Signal Specification v1.0 Implementation
==============================================

Complete implementation of the YRSNRequest/YRSNResponse envelopes as defined
in docs/Signal_Specification.md.

This module provides:
1. YRSNRequest - Input envelope with version, scope, options, args
2. YRSNResponse - Output envelope with status, provenance, signals
3. compute_signal() - Unified signal computation function
4. Adapters to/from internal formats (YRSNSignalLog, PredictionResult, etc.)

Usage:
    from yrsn.core.signal_spec import (
        YRSNRequest, YRSNResponse, compute_signal,
        create_request, response_to_dict
    )

    # Create request
    request = create_request(
        content="Your context text",
        query="Your query",
        options={"return_uncertainty": True}
    )

    # Compute signals
    response = compute_signal(request)

    # Access results
    print(f"R={response.example.decomposition.R}")
    print(f"Status: {response.status.ok}")

Part of YRSN Signal Specification v1.0.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

# Version constant
SPEC_VERSION = "1.0"
ENGINE_NAME = "yrsn-core"
ENGINE_VERSION = "2.0.0"


# =============================================================================
# Enums
# =============================================================================

class ScopeLevel(str, Enum):
    """Granularity of signal computation."""
    EXAMPLE = "example"
    WINDOW = "window"
    SESSION = "session"
    BATCH = "batch"


class InputKind(str, Enum):
    """Type of input being analyzed."""
    TEXT = "text"
    MESSAGES = "messages"
    EMBEDDING = "embedding"
    DOCUMENTS = "documents"
    SENSOR = "sensor"
    OTHER = "other"


class Phase(str, Enum):
    """Quality phase for temperature."""
    # Spec values (formal)
    EXPLOIT = "EXPLOIT"
    EXPLORE = "EXPLORE"
    TRANSITION = "TRANSITION"
    # Legacy values (for compatibility with base_learner.py)
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

    @classmethod
    def from_string(cls, value: str) -> "Phase":
        """Convert string to Phase, handling both spec and legacy values."""
        if value is None:
            return None
        value_upper = value.upper()
        value_lower = value.lower()
        # Try exact match first
        try:
            return cls(value)
        except ValueError:
            pass
        # Try uppercase version
        try:
            return cls(value_upper)
        except ValueError:
            pass
        # Map legacy to spec
        mapping = {
            "high": cls.EXPLOIT,
            "medium": cls.TRANSITION,
            "low": cls.EXPLORE,
        }
        if value_lower in mapping:
            return mapping[value_lower]
        raise ValueError(f"Unknown phase: {value}")


class CalibrationState(str, Enum):
    """State of the calibration system."""
    WEIGHT_DERIVED = "WEIGHT_DERIVED"
    DATA_CALIBRATED = "DATA_CALIBRATED"
    RECALIBRATING = "RECALIBRATING"


class ConstraintMode(str, Enum):
    """R/S/N normalization mode."""
    NORMALIZED = "normalized"
    APPROX_NORMALIZED = "approx_normalized"


# =============================================================================
# Request Components
# =============================================================================

@dataclass
class YRSNScope:
    """Scope specification for signal computation."""
    level: ScopeLevel = ScopeLevel.EXAMPLE
    window_size: Optional[int] = None
    window_id: Optional[str] = None


@dataclass
class YRSNEmbedding:
    """Embedding input specification."""
    vector: Optional[List[float]] = None
    model_id: Optional[str] = None
    dims: Optional[int] = None


@dataclass
class RetrievedItem:
    """Single retrieved context item."""
    id: str
    text: Optional[str] = None
    embedding: Optional[List[float]] = None
    meta: Optional[Dict[str, Any]] = None


@dataclass
class RetrievedContext:
    """Retrieved context for RAG-style inputs."""
    items: List[RetrievedItem] = field(default_factory=list)


@dataclass
class YRSNLabels:
    """Label information for supervised signals."""
    true_label: Optional[str] = None
    candidate_labels: Optional[List[str]] = None


@dataclass
class YRSNInputMeta:
    """Metadata for input."""
    user_id: Optional[str] = None
    route_id: Optional[str] = None
    domain: Optional[str] = None
    tags: Optional[List[str]] = None


@dataclass
class YRSNInput:
    """Input specification for signal computation."""
    kind: InputKind = InputKind.TEXT
    content: Optional[Any] = None
    embedding: Optional[YRSNEmbedding] = None
    retrieved_context: Optional[RetrievedContext] = None
    labels: Optional[YRSNLabels] = None
    meta: Optional[YRSNInputMeta] = None


@dataclass
class YRSNOptions:
    """Options controlling signal computation."""
    return_prediction: bool = True
    return_uncertainty: bool = False
    return_memory_signals: bool = True
    return_layer_weights: bool = True
    return_calibration: bool = False
    include_distributions: bool = False


@dataclass
class YRSNRequest:
    """
    Complete YRSN request envelope (Signal Spec v1.0).

    Attributes:
        version: Schema version (always "1.0")
        request_id: Unique request identifier
        timestamp_ms: Request timestamp in milliseconds
        scope: Granularity specification
        input: Input data specification
        options: Computation options
        args: Dynamic/rare arguments (namespaced)
    """
    version: str = SPEC_VERSION
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    scope: YRSNScope = field(default_factory=YRSNScope)
    input: YRSNInput = field(default_factory=YRSNInput)
    options: YRSNOptions = field(default_factory=YRSNOptions)
    args: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Response Components
# =============================================================================

@dataclass
class Status:
    """Response status with optional warnings/errors."""
    ok: bool = True
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


@dataclass
class ModulesEnabled:
    """Tracking which modules were enabled for computation."""
    decomposition: bool = True
    uncertainty: bool = False
    calibration: bool = False
    memory: bool = False


@dataclass
class ProvenanceModel:
    """Model provenance information."""
    signal_engine: str = ENGINE_NAME
    signal_engine_version: str = ENGINE_VERSION
    prediction_model_id: Optional[str] = None
    embedding_model_id: Optional[str] = None


@dataclass
class ProvenanceCompute:
    """Computation provenance information."""
    latency_ms: Optional[int] = None
    args_applied: Dict[str, Any] = field(default_factory=dict)
    modules_enabled: ModulesEnabled = field(default_factory=ModulesEnabled)


@dataclass
class Provenance:
    """Complete provenance for response."""
    model: ProvenanceModel = field(default_factory=ProvenanceModel)
    compute: ProvenanceCompute = field(default_factory=ProvenanceCompute)


@dataclass
class Decomposition:
    """R/S/N decomposition values."""
    R: float = 0.33
    S: float = 0.33
    N: float = 0.34
    constraint: ConstraintMode = ConstraintMode.NORMALIZED


@dataclass
class Quality:
    """Quality metrics."""
    alpha: Optional[float] = None
    omega: Optional[float] = None
    alpha_omega: Optional[float] = None
    quality_mode: Optional[str] = None


@dataclass
class Temperature:
    """Temperature signals."""
    tau: Optional[float] = None
    beta: Optional[float] = None
    phase: Optional[Phase] = None


@dataclass
class Prediction:
    """Prediction signals."""
    label: Optional[str] = None
    confidence: Optional[float] = None
    margin: Optional[float] = None
    label_probabilities: Optional[Dict[str, float]] = None


@dataclass
class Learning:
    """Learning signals."""
    reward: Optional[float] = None
    was_correct: Optional[bool] = None
    batch_learned: Optional[bool] = None


@dataclass
class Memory:
    """Memory layer signals."""
    sdm_locations: Optional[int] = None
    hopfield_patterns: Optional[int] = None
    replay_size: Optional[int] = None


@dataclass
class LayerWeights:
    """Memory layer weight signals."""
    sdm_weight: Optional[float] = None
    hopfield_weight: Optional[float] = None
    ewc_weight: Optional[float] = None
    replay_weight: Optional[float] = None


@dataclass
class Uncertainty:
    """Uncertainty signals (Category 8)."""
    enabled: bool = False
    epistemic: Optional[float] = None
    aleatoric: Optional[float] = None
    entropy: Optional[float] = None
    uncertainty_ratio: Optional[float] = None
    method: Optional[str] = None
    mc_passes: Optional[int] = None


@dataclass
class ExampleSignals:
    """Per-example signals (Categories 1-8)."""
    decomposition: Decomposition = field(default_factory=Decomposition)
    quality: Quality = field(default_factory=Quality)
    temperature: Temperature = field(default_factory=Temperature)
    prediction: Optional[Prediction] = None
    learning: Optional[Learning] = None
    memory: Optional[Memory] = None
    layer_weights: Optional[LayerWeights] = None
    uncertainty: Optional[Uncertainty] = None
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass
class KSPValues:
    """KS test p-values for drift detection."""
    R: Optional[float] = None
    S: Optional[float] = None
    N: Optional[float] = None


@dataclass
class Calibration:
    """Calibration signals (Category 9)."""
    enabled: bool = False
    drift_detected: Optional[bool] = None
    drift_confirmed: Optional[bool] = None
    ks_p_values: Optional[KSPValues] = None
    calibration_state: Optional[CalibrationState] = None
    samples_since_calibration: Optional[int] = None
    window_size: Optional[int] = None
    window_id: Optional[str] = None


@dataclass
class AggregateSignals:
    """Aggregate/window/session signals."""
    calibration: Optional[Calibration] = None
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Mining:
    """Training mining signals."""
    mining_strategy: Optional[str] = None
    valid_triplets: Optional[int] = None
    triplet_loss: Optional[float] = None
    curriculum_stage: Optional[int] = None


@dataclass
class TrainingSignals:
    """Training-only signals."""
    mining: Optional[Mining] = None
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass
class YRSNResponse:
    """
    Complete YRSN response envelope (Signal Spec v1.0).

    Attributes:
        version: Schema version (always "1.0")
        request_id: Matching request identifier
        timestamp_ms: Response timestamp in milliseconds
        status: Success/failure with warnings/errors
        provenance: Model and computation metadata
        example: Per-example signals (always present)
        aggregate: Aggregate signals (optional)
        training: Training-only signals (optional)
    """
    version: str = SPEC_VERSION
    request_id: str = ""
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    status: Status = field(default_factory=Status)
    provenance: Provenance = field(default_factory=Provenance)
    example: ExampleSignals = field(default_factory=ExampleSignals)
    aggregate: Optional[AggregateSignals] = None
    training: Optional[TrainingSignals] = None


# =============================================================================
# Factory Functions
# =============================================================================

def create_request(
    content: Optional[str] = None,
    query: Optional[str] = None,
    embedding: Optional[List[float]] = None,
    kind: Union[InputKind, str] = InputKind.TEXT,
    options: Optional[Dict[str, bool]] = None,
    args: Optional[Dict[str, Any]] = None,
    scope_level: Union[ScopeLevel, str] = ScopeLevel.EXAMPLE,
    request_id: Optional[str] = None,
    **meta_kwargs
) -> YRSNRequest:
    """
    Create a YRSNRequest with convenient defaults.

    Args:
        content: Text content to analyze
        query: Optional query for relevance computation
        embedding: Pre-computed embedding vector
        kind: Input type (text, embedding, etc.)
        options: Dict of option overrides
        args: Dynamic arguments (namespaced)
        scope_level: Computation scope
        request_id: Custom request ID (auto-generated if None)
        **meta_kwargs: Metadata fields (user_id, route_id, domain, tags)

    Returns:
        Configured YRSNRequest
    """
    # Handle kind as string
    if isinstance(kind, str):
        kind = InputKind(kind)
    if isinstance(scope_level, str):
        scope_level = ScopeLevel(scope_level)

    # Build input
    yrsn_input = YRSNInput(kind=kind)

    if content is not None:
        yrsn_input.content = content
        if query is not None:
            # Store query in content as dict for text inputs
            yrsn_input.content = {"text": content, "query": query}

    if embedding is not None:
        yrsn_input.embedding = YRSNEmbedding(
            vector=embedding,
            dims=len(embedding)
        )

    if meta_kwargs:
        yrsn_input.meta = YRSNInputMeta(
            user_id=meta_kwargs.get("user_id"),
            route_id=meta_kwargs.get("route_id"),
            domain=meta_kwargs.get("domain"),
            tags=meta_kwargs.get("tags"),
        )

    # Build options
    yrsn_options = YRSNOptions()
    if options:
        for key, value in options.items():
            if hasattr(yrsn_options, key):
                setattr(yrsn_options, key, value)

    return YRSNRequest(
        request_id=request_id or str(uuid.uuid4()),
        scope=YRSNScope(level=scope_level),
        input=yrsn_input,
        options=yrsn_options,
        args=args or {},
    )


def create_response(
    request_id: str,
    R: float,
    S: float,
    N: float,
    alpha: Optional[float] = None,
    omega: Optional[float] = None,
    tau: Optional[float] = None,
    phase: Optional[str] = None,
    prediction: Optional[Dict[str, Any]] = None,
    learning: Optional[Dict[str, Any]] = None,
    memory: Optional[Dict[str, Any]] = None,
    layer_weights: Optional[Dict[str, Any]] = None,
    uncertainty: Optional[Dict[str, Any]] = None,
    calibration: Optional[Dict[str, Any]] = None,
    training: Optional[Dict[str, Any]] = None,
    latency_ms: Optional[int] = None,
    warnings: Optional[List[str]] = None,
    errors: Optional[List[str]] = None,
    extras: Optional[Dict[str, Any]] = None,
) -> YRSNResponse:
    """
    Create a YRSNResponse from computed values.

    Args:
        request_id: Matching request ID
        R, S, N: Decomposition values
        alpha, omega: Quality metrics
        tau, phase: Temperature signals
        prediction: Prediction dict
        learning: Learning dict
        memory: Memory signals dict
        layer_weights: Layer weights dict
        uncertainty: Uncertainty signals dict
        calibration: Calibration signals dict
        training: Training signals dict
        latency_ms: Computation time
        warnings: Warning messages
        errors: Error messages
        extras: Extra per-example signals

    Returns:
        Complete YRSNResponse
    """
    # Compute derived values if not provided
    total = R + S + N
    if alpha is None and total > 0:
        alpha = R / total

    if omega is None:
        omega = 1.0

    alpha_omega = None
    if alpha is not None and omega is not None:
        alpha_omega = omega * alpha + (1 - omega) * 0.5

    if tau is None and alpha_omega is not None and alpha_omega > 0:
        tau = min(10.0, max(0.1, 1.0 / alpha_omega))

    beta = 1.0 / tau if tau and tau > 0 else None

    if phase is None and tau is not None:
        if tau < 1.43:
            phase = "high"
        elif tau < 2.50:
            phase = "medium"
        else:
            phase = "low"

    # Build example signals
    example = ExampleSignals(
        decomposition=Decomposition(R=R, S=S, N=N),
        quality=Quality(
            alpha=alpha,
            omega=omega,
            alpha_omega=alpha_omega,
        ),
        temperature=Temperature(
            tau=tau,
            beta=beta,
            phase=Phase.from_string(phase) if phase else None,
        ),
        extras=extras or {},
    )

    # Add optional signals
    if prediction:
        example.prediction = Prediction(**prediction)

    if learning:
        example.learning = Learning(**learning)

    if memory:
        example.memory = Memory(**memory)

    if layer_weights:
        example.layer_weights = LayerWeights(**layer_weights)

    if uncertainty:
        example.uncertainty = Uncertainty(enabled=True, **uncertainty)

    # Build aggregate if calibration provided
    aggregate = None
    if calibration:
        ks_p = None
        if "ks_p_values" in calibration:
            ks_p = KSPValues(**calibration.pop("ks_p_values"))
        elif any(k.startswith("ks_p_value_") for k in calibration):
            ks_p = KSPValues(
                R=calibration.pop("ks_p_value_R", None),
                S=calibration.pop("ks_p_value_S", None),
                N=calibration.pop("ks_p_value_N", None),
            )

        cal_state = calibration.pop("calibration_state", None)
        if cal_state and isinstance(cal_state, str):
            cal_state = CalibrationState(cal_state)

        aggregate = AggregateSignals(
            calibration=Calibration(
                enabled=True,
                ks_p_values=ks_p,
                calibration_state=cal_state,
                **calibration,
            )
        )

    # Build training signals
    training_signals = None
    if training:
        mining_data = training.pop("mining", training)
        training_signals = TrainingSignals(
            mining=Mining(**mining_data) if mining_data else None,
            extras=training.get("extras", {}),
        )

    # Build provenance
    provenance = Provenance(
        compute=ProvenanceCompute(
            latency_ms=latency_ms,
            modules_enabled=ModulesEnabled(
                uncertainty=uncertainty is not None,
                calibration=calibration is not None,
                memory=memory is not None,
            ),
        )
    )

    # Build status
    status = Status(
        ok=not errors,
        warnings=warnings or [],
        errors=errors or [],
    )

    return YRSNResponse(
        request_id=request_id,
        status=status,
        provenance=provenance,
        example=example,
        aggregate=aggregate,
        training=training_signals,
    )


# =============================================================================
# Main Computation Function
# =============================================================================

def compute_signal(
    request: YRSNRequest,
    learner: Optional[Any] = None,
    calibration_manager: Optional[Any] = None,
) -> YRSNResponse:
    """
    Compute YRSN signals from a request.

    This is the main entry point for signal computation. It:
    1. Extracts content/query from request
    2. Runs decomposition
    3. Optionally runs uncertainty estimation
    4. Optionally runs calibration
    5. Returns spec-compliant response

    Args:
        request: YRSNRequest with input specification
        learner: Optional BaseLearner for prediction/learning signals
        calibration_manager: Optional CalibrationManager for drift detection

    Returns:
        YRSNResponse with computed signals
    """
    start_time = time.time()
    warnings: List[str] = []
    errors: List[str] = []

    try:
        # Extract content and query
        content = ""
        query = ""

        if request.input.content is not None:
            if isinstance(request.input.content, dict):
                content = request.input.content.get("text", "")
                query = request.input.content.get("query", "")
            else:
                content = str(request.input.content)

        # Import decomposition
        from yrsn.core import decompose
        import numpy as np

        # Run decomposition
        if request.input.kind == InputKind.EMBEDDING and request.input.embedding:
            # Embedding decomposition (v2.7+)
            if request.input.embedding.vector is None:
                raise ValueError("Embedding input requires vector field")

            # Convert to numpy array
            embedding_array = np.array(request.input.embedding.vector, dtype=np.float32)

            # Get checkpoint path from args
            checkpoint_path = request.args.get("checkpoint_path") if request.args else None

            if checkpoint_path is None:
                # Fallback to heuristic with warning
                warnings.append(
                    "Embedding input without checkpoint_path: falling back to heuristic method. "
                    "For neural projection, provide checkpoint_path in request.args. "
                    "Example: args={'checkpoint_path': 'checkpoints/trained.pt'}"
                )
                # Use heuristic as fallback (will process content as text if available)
                if content:
                    score = decompose(content, query=query, method="heuristic")
                else:
                    # No text content, return neutral decomposition
                    R, S, N = 0.33, 0.33, 0.34
            else:
                # Use neural projection
                try:
                    score = decompose(
                        embedding_array,
                        method="neural",
                        checkpoint_path=checkpoint_path
                    )
                except FileNotFoundError as e:
                    warnings.append(f"Checkpoint not found: {e}. Falling back to heuristic.")
                    if content:
                        score = decompose(content, query=query, method="heuristic")
                    else:
                        R, S, N = 0.33, 0.33, 0.34
                        score = None

            if 'score' in locals() and score is not None:
                R = score.relevant
                S = score.superfluous
                N = score.noise
        else:
            # Text decomposition (existing code)
            score = decompose(content, query=query, method="auto")
            R = score.relevant
            S = score.superfluous
            N = score.noise

        # Compute quality metrics
        total = R + S + N
        alpha = R / total if total > 0 else 0.5
        omega = 1.0  # Default reliability

        # Get omega from args if provided
        if "omega" in request.args:
            omega = float(request.args["omega"])

        alpha_omega = omega * alpha + (1 - omega) * 0.5
        tau = min(10.0, max(0.1, 1.0 / alpha_omega)) if alpha_omega > 0 else 2.0
        beta = 1.0 / tau

        # Determine phase
        if tau < 1.43:
            phase = Phase.EXPLOIT
        elif tau < 2.50:
            phase = Phase.TRANSITION
        else:
            phase = Phase.EXPLORE

        # Build response components
        prediction_data = None
        learning_data = None
        memory_data = None
        layer_weights_data = None
        uncertainty_data = None
        calibration_data = None

        # Run learner if provided and prediction requested
        if learner is not None and request.options.return_prediction:
            try:
                pred_result = learner.predict(content=content, query=query)
                prediction_data = {
                    "label": pred_result.label,
                    "confidence": pred_result.confidence,
                    "margin": pred_result.margin,
                }
                if request.options.include_distributions:
                    prediction_data["label_probabilities"] = pred_result.label_probabilities

                # Memory signals
                if request.options.return_memory_signals:
                    memory_data = {
                        "sdm_locations": len(getattr(learner.sdm, 'locations', [])),
                        "hopfield_patterns": len(getattr(learner.hopfield, 'patterns', [])),
                        "replay_size": len(getattr(learner.replay, 'buffer', [])),
                    }

                # Layer weights
                if request.options.return_layer_weights:
                    cfg = learner.config
                    layer_weights_data = {
                        "sdm_weight": cfg.sdm_weight,
                        "hopfield_weight": cfg.hopfield_weight,
                        "ewc_weight": cfg.ewc_weight,
                        "replay_weight": cfg.replay_weight,
                    }

            except Exception as e:
                warnings.append(f"Learner prediction failed: {str(e)}")

        # Run uncertainty estimation if requested
        if request.options.return_uncertainty:
            try:
                # Check for MC dropout parameters in args
                mc_passes = request.args.get("uncertainty.mc_passes", 10)
                method = request.args.get("uncertainty.method", "mc_dropout")

                # Compute uncertainty from R/S/N decomposition variance
                # This uses the variance of decomposition as a proxy for epistemic uncertainty
                # and the N component as a proxy for aleatoric uncertainty (inherent data noise)

                # Epistemic uncertainty: how confident is the model in its decomposition?
                # High variance between R,S,N suggests model uncertainty
                rsn_values = [R, S, N]
                rsn_variance = float(np.var(rsn_values))

                # Map variance to epistemic uncertainty [0, 1]
                # Low variance (one dominant component) = low epistemic uncertainty
                # High variance (similar components) = high epistemic uncertainty
                # Max variance for 3 components summing to 1 is ~0.22 (when one is 1, others 0)
                epistemic = min(1.0, rsn_variance / 0.22)

                # Aleatoric uncertainty: inherent noise in the data
                # Use N (noise component) as direct proxy - this IS data noise
                aleatoric = float(N)

                # Entropy of the R/S/N distribution
                # High entropy = more uncertainty about which component dominates
                rsn_probs = np.array([max(1e-10, R), max(1e-10, S), max(1e-10, N)])
                rsn_probs = rsn_probs / rsn_probs.sum()  # Ensure normalization
                entropy = float(-np.sum(rsn_probs * np.log(rsn_probs)))
                max_entropy = np.log(3)  # Maximum entropy for 3 categories
                normalized_entropy = entropy / max_entropy

                # Uncertainty ratio: epistemic / (epistemic + aleatoric)
                # High ratio = model uncertainty dominates (need more data)
                # Low ratio = data noise dominates (inherently ambiguous)
                total_uncertainty = epistemic + aleatoric + 1e-10
                uncertainty_ratio = epistemic / total_uncertainty

                uncertainty_data = {
                    "epistemic": round(epistemic, 6),
                    "aleatoric": round(aleatoric, 6),
                    "entropy": round(normalized_entropy, 6),
                    "uncertainty_ratio": round(uncertainty_ratio, 6),
                    "method": method,
                    "mc_passes": mc_passes,
                }

            except Exception as e:
                warnings.append(f"Uncertainty estimation failed: {str(e)}")
                uncertainty_data = {
                    "epistemic": None,
                    "aleatoric": None,
                    "entropy": None,
                    "uncertainty_ratio": None,
                    "method": method,
                    "mc_passes": mc_passes,
                    "error": str(e),
                }

        # Run calibration if manager provided and requested
        if calibration_manager is not None and request.options.return_calibration:
            try:
                cal_signals = calibration_manager.get_calibration_signals()
                calibration_data = {
                    "drift_detected": cal_signals.get("drift_detected"),
                    "drift_confirmed": cal_signals.get("drift_confirmed"),
                    "ks_p_value_R": cal_signals.get("ks_p_value_R"),
                    "ks_p_value_S": cal_signals.get("ks_p_value_S"),
                    "ks_p_value_N": cal_signals.get("ks_p_value_N"),
                    "calibration_state": cal_signals.get("calibration_state"),
                    "samples_since_calibration": cal_signals.get("samples_since_calibration"),
                }
            except Exception as e:
                warnings.append(f"Calibration failed: {str(e)}")

        # Compute latency
        latency_ms = int((time.time() - start_time) * 1000)

        # Create response
        return create_response(
            request_id=request.request_id,
            R=R,
            S=S,
            N=N,
            alpha=alpha,
            omega=omega,
            tau=tau,
            phase=phase.value.lower() if isinstance(phase, Phase) else phase,
            prediction=prediction_data,
            learning=learning_data,
            memory=memory_data,
            layer_weights=layer_weights_data,
            uncertainty=uncertainty_data,
            calibration=calibration_data,
            latency_ms=latency_ms,
            warnings=warnings,
            errors=errors,
        )

    except Exception as e:
        # Return error response
        errors.append(f"Signal computation failed: {str(e)}")
        latency_ms = int((time.time() - start_time) * 1000)

        return YRSNResponse(
            request_id=request.request_id,
            status=Status(ok=False, warnings=warnings, errors=errors),
            provenance=Provenance(
                compute=ProvenanceCompute(latency_ms=latency_ms)
            ),
        )


# =============================================================================
# Serialization
# =============================================================================

def request_to_dict(request: YRSNRequest) -> Dict[str, Any]:
    """Convert YRSNRequest to JSON-serializable dict."""
    return _dataclass_to_dict(request)


def response_to_dict(response: YRSNResponse) -> Dict[str, Any]:
    """Convert YRSNResponse to JSON-serializable dict."""
    return _dataclass_to_dict(response)


def _dataclass_to_dict(obj: Any) -> Any:
    """Recursively convert dataclass to dict."""
    if obj is None:
        return None

    if isinstance(obj, Phase):
        # Map legacy phase values to spec values for JSON schema compliance
        phase_mapping = {
            Phase.HIGH: "EXPLOIT",
            Phase.MEDIUM: "TRANSITION",
            Phase.LOW: "EXPLORE",
            Phase.EXPLOIT: "EXPLOIT",
            Phase.EXPLORE: "EXPLORE",
            Phase.TRANSITION: "TRANSITION",
        }
        return phase_mapping.get(obj, obj.value)

    if isinstance(obj, Enum):
        return obj.value

    if isinstance(obj, (list, tuple)):
        return [_dataclass_to_dict(item) for item in obj]

    if isinstance(obj, dict):
        return {k: _dataclass_to_dict(v) for k, v in obj.items()}

    if hasattr(obj, "__dataclass_fields__"):
        result = {}
        for field_name in obj.__dataclass_fields__:
            value = getattr(obj, field_name)
            if value is not None:  # Skip None values for cleaner output
                result[field_name] = _dataclass_to_dict(value)
        return result

    return obj


def dict_to_request(data: Dict[str, Any]) -> YRSNRequest:
    """Parse dict to YRSNRequest."""
    # Handle nested structures
    scope = YRSNScope(**data.get("scope", {})) if "scope" in data else YRSNScope()

    input_data = data.get("input", {})
    yrsn_input = YRSNInput(
        kind=InputKind(input_data.get("kind", "text")),
        content=input_data.get("content"),
    )

    if "embedding" in input_data and input_data["embedding"]:
        yrsn_input.embedding = YRSNEmbedding(**input_data["embedding"])

    if "meta" in input_data and input_data["meta"]:
        yrsn_input.meta = YRSNInputMeta(**input_data["meta"])

    options = YRSNOptions(**data.get("options", {})) if "options" in data else YRSNOptions()

    return YRSNRequest(
        version=data.get("version", SPEC_VERSION),
        request_id=data.get("request_id", str(uuid.uuid4())),
        timestamp_ms=data.get("timestamp_ms", int(time.time() * 1000)),
        scope=scope,
        input=yrsn_input,
        options=options,
        args=data.get("args", {}),
    )


# =============================================================================
# Adapters
# =============================================================================

def from_signal_log(log_entry: Any) -> YRSNResponse:
    """
    Convert YRSNSignalLog (from common_logger.py) to YRSNResponse.

    Args:
        log_entry: YRSNSignalLog instance or dict

    Returns:
        YRSNResponse
    """
    # Handle both dataclass and dict
    if hasattr(log_entry, "__dict__"):
        data = {k: v for k, v in vars(log_entry).items() if not k.startswith("_")}
    else:
        data = dict(log_entry)

    # Build prediction if present
    prediction_data = None
    if data.get("route"):
        prediction_data = {
            "label": data.get("route"),
            "confidence": data.get("confidence"),
            "margin": data.get("margin"),
        }
        if data.get("label_probabilities"):
            prediction_data["label_probabilities"] = data["label_probabilities"]

    # Build learning if present
    learning_data = None
    if data.get("reward") is not None:
        learning_data = {
            "reward": data.get("reward"),
            "was_correct": data.get("was_correct"),
            "batch_learned": data.get("batch_learned"),
        }

    # Build memory signals
    memory_data = None
    if data.get("sdm_locations") is not None:
        memory_data = {
            "sdm_locations": data.get("sdm_locations"),
            "hopfield_patterns": data.get("hopfield_patterns"),
            "replay_size": data.get("replay_size"),
        }

    # Build layer weights
    layer_weights_data = None
    if data.get("sdm_weight") is not None:
        layer_weights_data = {
            "sdm_weight": data.get("sdm_weight"),
            "hopfield_weight": data.get("hopfield_weight"),
            "ewc_weight": data.get("ewc_weight"),
            "replay_weight": data.get("replay_weight"),
        }

    # Build uncertainty if present
    uncertainty_data = None
    if data.get("epistemic") is not None:
        uncertainty_data = {
            "epistemic": data.get("epistemic"),
            "aleatoric": data.get("aleatoric"),
            "entropy": data.get("entropy"),
            "uncertainty_ratio": data.get("uncertainty_ratio"),
        }

    # Build calibration if present
    calibration_data = None
    if data.get("drift_detected") is not None:
        calibration_data = {
            "drift_detected": data.get("drift_detected"),
            "drift_confirmed": data.get("drift_confirmed"),
            "ks_p_value_R": data.get("ks_p_value_R"),
            "ks_p_value_S": data.get("ks_p_value_S"),
            "ks_p_value_N": data.get("ks_p_value_N"),
            "calibration_state": data.get("calibration_state"),
            "samples_since_calibration": data.get("samples_since_calibration"),
        }

    return create_response(
        request_id=data.get("example_id", "unknown"),
        R=data.get("R", 0.33),
        S=data.get("S", 0.33),
        N=data.get("N", 0.34),
        alpha=data.get("alpha"),
        omega=data.get("omega"),
        tau=data.get("tau"),
        phase=data.get("phase"),
        prediction=prediction_data,
        learning=learning_data,
        memory=memory_data,
        layer_weights=layer_weights_data,
        uncertainty=uncertainty_data,
        calibration=calibration_data,
    )


def from_prediction_result(
    pred: Any,
    R: float,
    S: float,
    N: float,
    request_id: str = "unknown",
    omega: float = 1.0,
) -> YRSNResponse:
    """
    Convert PredictionResult (from base_learner.py) to YRSNResponse.

    Args:
        pred: PredictionResult instance
        R, S, N: Decomposition values
        request_id: Request identifier
        omega: Reliability coefficient

    Returns:
        YRSNResponse
    """
    return create_response(
        request_id=request_id,
        R=R,
        S=S,
        N=N,
        omega=omega,
        tau=pred.temperature,
        phase=pred.phase,
        prediction={
            "label": pred.label,
            "confidence": pred.confidence,
            "margin": pred.margin,
            "label_probabilities": pred.label_probabilities,
        },
    )


def to_signal_log_dict(response: YRSNResponse, dataset: str = "unknown") -> Dict[str, Any]:
    """
    Convert YRSNResponse to YRSNSignalLog-compatible dict.

    This allows using spec responses with the existing logging infrastructure.

    Args:
        response: YRSNResponse
        dataset: Dataset name for logging

    Returns:
        Dict compatible with YRSNSignalLog
    """
    ex = response.example
    result = {
        "dataset": dataset,
        "example_id": response.request_id,
        "R": ex.decomposition.R,
        "S": ex.decomposition.S,
        "N": ex.decomposition.N,
        "alpha": ex.quality.alpha,
        "omega": ex.quality.omega,
        "alpha_omega": ex.quality.alpha_omega,
        "tau": ex.temperature.tau,
        "beta": ex.temperature.beta,
        "phase": ex.temperature.phase.value if ex.temperature.phase else None,
    }

    if ex.prediction:
        result.update({
            "route": ex.prediction.label,
            "confidence": ex.prediction.confidence,
            "margin": ex.prediction.margin,
            "label_probabilities": ex.prediction.label_probabilities or {},
        })

    if ex.learning:
        result.update({
            "reward": ex.learning.reward,
            "was_correct": ex.learning.was_correct,
            "batch_learned": ex.learning.batch_learned,
        })

    if ex.memory:
        result.update({
            "sdm_locations": ex.memory.sdm_locations,
            "hopfield_patterns": ex.memory.hopfield_patterns,
            "replay_size": ex.memory.replay_size,
        })

    if ex.layer_weights:
        result.update({
            "sdm_weight": ex.layer_weights.sdm_weight,
            "hopfield_weight": ex.layer_weights.hopfield_weight,
            "ewc_weight": ex.layer_weights.ewc_weight,
            "replay_weight": ex.layer_weights.replay_weight,
        })

    if ex.uncertainty and ex.uncertainty.enabled:
        result.update({
            "epistemic": ex.uncertainty.epistemic,
            "aleatoric": ex.uncertainty.aleatoric,
            "entropy": ex.uncertainty.entropy,
            "uncertainty_ratio": ex.uncertainty.uncertainty_ratio,
        })

    if response.aggregate and response.aggregate.calibration:
        cal = response.aggregate.calibration
        result.update({
            "drift_detected": cal.drift_detected,
            "drift_confirmed": cal.drift_confirmed,
            "calibration_state": cal.calibration_state.value if cal.calibration_state else None,
            "samples_since_calibration": cal.samples_since_calibration,
        })
        if cal.ks_p_values:
            result.update({
                "ks_p_value_R": cal.ks_p_values.R,
                "ks_p_value_S": cal.ks_p_values.S,
                "ks_p_value_N": cal.ks_p_values.N,
            })

    return result


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Version
    "SPEC_VERSION",
    "ENGINE_NAME",
    "ENGINE_VERSION",
    # Enums
    "ScopeLevel",
    "InputKind",
    "Phase",
    "CalibrationState",
    "ConstraintMode",
    # Request Components
    "YRSNScope",
    "YRSNEmbedding",
    "RetrievedItem",
    "RetrievedContext",
    "YRSNLabels",
    "YRSNInputMeta",
    "YRSNInput",
    "YRSNOptions",
    "YRSNRequest",
    # Response Components
    "Status",
    "ModulesEnabled",
    "ProvenanceModel",
    "ProvenanceCompute",
    "Provenance",
    "Decomposition",
    "Quality",
    "Temperature",
    "Prediction",
    "Learning",
    "Memory",
    "LayerWeights",
    "Uncertainty",
    "ExampleSignals",
    "KSPValues",
    "Calibration",
    "AggregateSignals",
    "Mining",
    "TrainingSignals",
    "YRSNResponse",
    # Factory Functions
    "create_request",
    "create_response",
    # Main Computation
    "compute_signal",
    # Serialization
    "request_to_dict",
    "response_to_dict",
    "dict_to_request",
    # Adapters
    "from_signal_log",
    "from_prediction_result",
    "to_signal_log_dict",
]
