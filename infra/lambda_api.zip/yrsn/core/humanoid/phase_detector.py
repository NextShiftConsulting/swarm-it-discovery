"""
Phase Detector - Detects manipulation phases for VLA control.

Based on OmniVIC's phase-aware approach:
- FREE_MOTION: Moving through free space
- APPROACHING: Near target
- CONTACT: Making/maintaining contact
- RETREAT: Withdrawing after task or error

The phase determines:
- Expected quality (α) range
- Impedance parameters (K, D)
- Velocity scaling
"""

from dataclasses import dataclass, field
from typing import Optional, List
from collections import deque
import time

from yrsn.ports.phase import (
    VLAPhase,
    PhaseConfig,
    PhaseInfo,
    IPhaseDetector,
    PHASE_PARAMETERS,
)


@dataclass
class PhaseTransition:
    """Record of a phase transition."""
    from_phase: VLAPhase
    to_phase: VLAPhase
    timestamp: float
    force_magnitude: float
    distance_to_target: float


class PhaseHistory:
    """Tracks phase history for analysis."""

    def __init__(self, max_history: int = 100):
        self.transitions: deque = deque(maxlen=max_history)
        self.phase_durations: dict[VLAPhase, float] = {p: 0.0 for p in VLAPhase}
        self._last_phase: Optional[VLAPhase] = None
        self._last_time: Optional[float] = None

    def record_transition(
        self,
        from_phase: VLAPhase,
        to_phase: VLAPhase,
        force_magnitude: float,
        distance_to_target: float,
    ):
        """Record a phase transition."""
        now = time.time()

        # Update duration of previous phase
        if self._last_phase is not None and self._last_time is not None:
            duration = now - self._last_time
            self.phase_durations[self._last_phase] += duration

        # Record transition
        self.transitions.append(PhaseTransition(
            from_phase=from_phase,
            to_phase=to_phase,
            timestamp=now,
            force_magnitude=force_magnitude,
            distance_to_target=distance_to_target,
        ))

        self._last_phase = to_phase
        self._last_time = now

    def get_phase_fraction(self, phase: VLAPhase) -> float:
        """Get fraction of time spent in a phase."""
        total = sum(self.phase_durations.values())
        if total == 0:
            return 0.0
        return self.phase_durations[phase] / total

    def get_recent_transitions(self, n: int = 5) -> List[PhaseTransition]:
        """Get recent transitions."""
        return list(self.transitions)[-n:]


class SimplePhaseDetector(IPhaseDetector):
    """
    Simple phase detector based on force and distance thresholds.

    Implements hysteresis to prevent oscillation between phases.
    """

    def __init__(self, config: Optional[PhaseConfig] = None):
        self.config = config or PhaseConfig()
        self.current_phase = VLAPhase.FREE_MOTION
        self.phase_start_time = time.time()
        self.history = PhaseHistory()
        self._retreat_requested = False
        self._retreat_start_time: Optional[float] = None

    def detect_phase(
        self,
        force_magnitude: float,
        distance_to_target: float,
    ) -> VLAPhase:
        """
        Detect manipulation phase.

        State machine:
        - FREE_MOTION → APPROACHING when distance < threshold
        - APPROACHING → CONTACT when force > threshold
        - CONTACT → RETREAT when task done or force too high
        - RETREAT → FREE_MOTION after timeout
        - Any → RETREAT when retreat_requested
        """
        previous_phase = self.current_phase
        new_phase = self._compute_phase(force_magnitude, distance_to_target)

        # Record transition if phase changed
        if new_phase != previous_phase:
            self.history.record_transition(
                from_phase=previous_phase,
                to_phase=new_phase,
                force_magnitude=force_magnitude,
                distance_to_target=distance_to_target,
            )
            self.phase_start_time = time.time()

        self.current_phase = new_phase
        return new_phase

    def _compute_phase(
        self,
        force_magnitude: float,
        distance_to_target: float,
    ) -> VLAPhase:
        """Compute phase with hysteresis."""

        # Check for retreat request
        if self._retreat_requested:
            if self._retreat_start_time is None:
                self._retreat_start_time = time.time()

            # Retreat timeout
            if time.time() - self._retreat_start_time > self.config.retreat_timeout:
                self._retreat_requested = False
                self._retreat_start_time = None
            else:
                return VLAPhase.RETREAT

        # Current phase affects thresholds (hysteresis)
        force_threshold = self.config.contact_force_threshold
        distance_threshold = self.config.approach_distance

        if self.current_phase == VLAPhase.CONTACT:
            # Need to drop below threshold - hysteresis to exit contact
            force_threshold = self.config.contact_force_threshold - self.config.force_hysteresis
        elif self.current_phase == VLAPhase.APPROACHING:
            # Need to exceed threshold + hysteresis to enter contact
            force_threshold = self.config.contact_force_threshold + self.config.force_hysteresis

        # Phase detection logic
        if force_magnitude > force_threshold:
            return VLAPhase.CONTACT
        elif distance_to_target < distance_threshold:
            return VLAPhase.APPROACHING
        else:
            return VLAPhase.FREE_MOTION

    def get_phase_info(
        self,
        force_magnitude: float,
        distance_to_target: float,
    ) -> PhaseInfo:
        """Get detailed phase information with recommendations."""
        phase = self.detect_phase(force_magnitude, distance_to_target)
        params = PHASE_PARAMETERS[phase]

        time_in_phase = time.time() - self.phase_start_time

        # Compute confidence based on how clearly we're in this phase
        confidence = self._compute_confidence(phase, force_magnitude, distance_to_target)

        # Get recommended impedance from parameters
        K_min, K_max = params["K_range"]
        D_min, D_max = params["D_range"]
        recommended_K = (K_min + K_max) / 2
        recommended_D = (D_min + D_max) / 2

        return PhaseInfo(
            phase=phase,
            confidence=confidence,
            time_in_phase=time_in_phase,
            force_magnitude=force_magnitude,
            distance_to_target=distance_to_target,
            expected_alpha_min=params["expected_alpha_min"],
            recommended_K=recommended_K,
            recommended_D=recommended_D,
        )

    def _compute_confidence(
        self,
        phase: VLAPhase,
        force_magnitude: float,
        distance_to_target: float,
    ) -> float:
        """Compute confidence in phase detection."""
        if phase == VLAPhase.CONTACT:
            # Higher force = more confident we're in contact
            excess = force_magnitude - self.config.contact_force_threshold
            return min(1.0, 0.5 + excess / self.config.contact_force_threshold)

        elif phase == VLAPhase.APPROACHING:
            # Closer = more confident we're approaching
            return min(1.0, 1.0 - distance_to_target / self.config.approach_distance)

        elif phase == VLAPhase.FREE_MOTION:
            # Further from target = more confident we're in free motion
            return min(1.0, distance_to_target / (2 * self.config.approach_distance))

        else:  # RETREAT
            return 1.0 if self._retreat_requested else 0.5

    def request_retreat(self):
        """Request transition to retreat phase."""
        self._retreat_requested = True
        self._retreat_start_time = None

    def reset(self) -> None:
        """Reset phase detector state."""
        self.current_phase = VLAPhase.FREE_MOTION
        self.phase_start_time = time.time()
        self._retreat_requested = False
        self._retreat_start_time = None


__all__ = [
    "SimplePhaseDetector",
    "PhaseHistory",
    "PhaseTransition",
]
