"""
YRSN Humanoid Control Core Module
=================================

Provides humanoid-specific control logic for YRSN:
- Phase detection (FREE_MOTION, APPROACHING, CONTACT, RETREAT)
- Impedance selection based on phase and quality
- Subsystem routing (legs, arms, torso)
- Gait scaling based on quality

This module implements the OmniVIC-style phase-aware control
combined with YRSN quality signals (α, ω, τ).

Usage:
    from yrsn.core.humanoid import (
        SimplePhaseDetector,
        ImpedanceSelector,
        SubsystemRouter,
        GaitScaler,
    )

    # Create phase detector
    detector = SimplePhaseDetector()
    phase = detector.detect_phase(force_magnitude=5.0, distance_to_target=0.05)

    # Get impedance for phase
    selector = ImpedanceSelector()
    K, D = selector.get_impedance(phase, alpha=0.6)

    # Route by subsystem
    router = SubsystemRouter(robot_type="h1")
    legs_joints = router.get_joints(BodyPart.LEGS)
"""

from yrsn.core.humanoid.phase_detector import (
    SimplePhaseDetector,
    PhaseHistory,
)
from yrsn.core.humanoid.impedance_selector import (
    ImpedanceSelector,
    ImpedanceConfig,
)
from yrsn.core.humanoid.subsystem_router import (
    SubsystemRouter,
    GaitScaler,
    GaitParams,
)
from yrsn.core.humanoid.interaction_mesh import (
    Keypoint,
    InteractionMesh,
    DeformationResult,
    LaplacianDeformationTracker,
    InteractionPreservingController,
    build_manipulation_mesh,
)
from yrsn.core.humanoid.kinematic_retargeting import (
    DemoKeypoint,
    RobotKeypoint,
    RetargetingConfig,
    RetargetingResult,
    KeypointMapping,
    KinematicRetargeter,
    ScaleAugmenter,
    TrajectoryOptimizationConfig,
    TrajectoryOptimizer,
)

__all__ = [
    # Phase detection
    "SimplePhaseDetector",
    "PhaseHistory",
    # Impedance
    "ImpedanceSelector",
    "ImpedanceConfig",
    # Routing
    "SubsystemRouter",
    "GaitScaler",
    "GaitParams",
    # Laplacian Interaction Mesh (Yang thesis)
    "Keypoint",
    "InteractionMesh",
    "DeformationResult",
    "LaplacianDeformationTracker",
    "InteractionPreservingController",
    "build_manipulation_mesh",
    # Kinematic Retargeting (Yang thesis - PhysicsGen)
    "DemoKeypoint",
    "RobotKeypoint",
    "RetargetingConfig",
    "RetargetingResult",
    "KeypointMapping",
    "KinematicRetargeter",
    "ScaleAugmenter",
    "TrajectoryOptimizationConfig",
    "TrajectoryOptimizer",
]
