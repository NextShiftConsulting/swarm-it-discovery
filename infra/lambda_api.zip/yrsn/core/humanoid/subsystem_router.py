"""
DEPRECATED: Subsystem router moved to yrsn.adapters.humanoid.routing

⚠️  This module is DEPRECATED and will be removed in a future version.
⚠️  Import from yrsn.adapters.humanoid.routing instead.

WHY IT MOVED:
------------
Routing commands to subsystems is CONTROL, not MEASUREMENT.
Per hexagonal architecture, control belongs in adapters.

MIGRATION:
---------
OLD: from yrsn.core.humanoid.subsystem_router import SubsystemRouter
NEW: from yrsn.adapters.humanoid.routing import SubsystemRouter

See: docs/HEX_ARCHITECTURE_DEEP_AUDIT.md

---

Subsystem Router - Routes control by body part with quality awareness.

Handles:
- Legs: Quality-scaled gait parameters
- Arms: Phase-aware impedance routing
- Torso: Balance barrier checks

Integrates with YRSN FeasibilityFilter and ControlBarrier.
"""

import warnings

warnings.warn(
    "yrsn.core.humanoid.subsystem_router is deprecated. "
    "Routing logic moved to yrsn.adapters.humanoid.routing. "
    "Per hexagonal architecture, routing (control) belongs in adapters, not core. "
    "Update your imports: 'from yrsn.adapters.humanoid.routing import ...'",
    DeprecationWarning,
    stacklevel=2
)

# Re-export from new location for backward compatibility
try:
    from yrsn.adapters.humanoid.routing import *
except ImportError as e:
    warnings.warn(
        f"Could not import from yrsn.adapters.humanoid.routing: {e}. "
        "The humanoid routing module may not be fully migrated yet.",
        ImportWarning
    )
