"""
Laplacian Interaction Mesh for Object-Safe Manipulation.

Based on Lujie Yang's thesis: "Bridging Model-Based and Learning-Based
Methods for Robotic Loco-Manipulation and Control"

Key concepts:
- Interaction Mesh: Volumetric structure (Delaunay tetrahedralization) connecting
  robot keypoints, object surface samples, and terrain samples.
- Laplacian Coordinate: L(v) = v - mean(neighbors) - encodes local spatial config
- Deformation Energy: ||L_target - L_source||^2 - minimizing preserves relationships

The mesh preserves crucial spatial relationships during manipulation to avoid:
- Object penetration/crushing
- Contact slip (losing grip)
- Foot skating during loco-manipulation
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Any
import math


@dataclass
class Keypoint:
    """A point in the interaction mesh."""

    name: str
    position: Tuple[float, float, float]  # (x, y, z)
    source: str  # "robot", "object", "terrain"
    is_contact: bool = False


@dataclass
class InteractionMesh:
    """
    Volumetric mesh connecting robot, object, and terrain keypoints.

    Uses Delaunay tetrahedralization which favors connecting nearby points
    while avoiding occlusions.
    """

    keypoints: List[Keypoint] = field(default_factory=list)
    edges: List[Tuple[int, int]] = field(default_factory=list)
    tetrahedra: List[Tuple[int, int, int, int]] = field(default_factory=list)

    # Laplacian coordinates for each vertex
    laplacian_coords: Dict[int, Tuple[float, float, float]] = field(default_factory=dict)

    def add_keypoint(self, kp: Keypoint) -> int:
        """Add keypoint, return its index."""
        idx = len(self.keypoints)
        self.keypoints.append(kp)
        return idx

    def compute_laplacian(self, vertex_idx: int) -> Tuple[float, float, float]:
        """
        Compute Laplacian coordinate for a vertex.

        L(v) = v - (1/|N|) * sum(neighbors)

        This encodes the vertex's displacement relative to its neighbors,
        capturing local spatial configuration.
        """
        if vertex_idx >= len(self.keypoints):
            return (0.0, 0.0, 0.0)

        vertex = self.keypoints[vertex_idx]
        vx, vy, vz = vertex.position

        # Find neighbors from edges
        neighbors = []
        for e0, e1 in self.edges:
            if e0 == vertex_idx:
                neighbors.append(e1)
            elif e1 == vertex_idx:
                neighbors.append(e0)

        if not neighbors:
            return (vx, vy, vz)

        # Compute mean of neighbors
        mean_x = sum(self.keypoints[n].position[0] for n in neighbors) / len(neighbors)
        mean_y = sum(self.keypoints[n].position[1] for n in neighbors) / len(neighbors)
        mean_z = sum(self.keypoints[n].position[2] for n in neighbors) / len(neighbors)

        # Laplacian = vertex - mean(neighbors)
        lx = vx - mean_x
        ly = vy - mean_y
        lz = vz - mean_z

        self.laplacian_coords[vertex_idx] = (lx, ly, lz)
        return (lx, ly, lz)

    def compute_all_laplacians(self) -> None:
        """Compute Laplacian coordinates for all vertices."""
        for i in range(len(self.keypoints)):
            self.compute_laplacian(i)


@dataclass
class DeformationResult:
    """Result of comparing source and target mesh deformation."""

    total_energy: float  # ||L_target - L_source||^2
    max_deformation: float  # Maximum single-vertex deformation
    contact_preservation_ratio: float  # Fraction of contacts maintained
    penetration_depth: float  # Maximum penetration (negative = penetrating)
    contact_slip: float  # Maximum contact point movement

    @property
    def is_safe(self) -> bool:
        """Check if deformation is within safe limits."""
        return (
            self.max_deformation < 0.1
            and self.penetration_depth >= -0.001
            and self.contact_slip < 0.02
        )


class LaplacianDeformationTracker:
    """
    Tracks Laplacian deformation during manipulation.

    Monitors mesh deformation to ensure object safety:
    - High deformation = potential damage
    - Contact slip = losing grip
    - Penetration = crushing object
    """

    def __init__(
        self,
        laplacian_weight: float = 1.0,
        temporal_smoothness: float = 0.5,
        penetration_margin: float = 0.001,
    ):
        self.laplacian_weight = laplacian_weight
        self.temporal_smoothness = temporal_smoothness
        self.penetration_margin = penetration_margin

        self._source_mesh: Optional[InteractionMesh] = None
        self._current_mesh: Optional[InteractionMesh] = None
        self._previous_mesh: Optional[InteractionMesh] = None

    def set_source_mesh(self, mesh: InteractionMesh) -> None:
        """Set the source (reference) mesh configuration."""
        mesh.compute_all_laplacians()
        self._source_mesh = mesh

    def update_current_mesh(self, mesh: InteractionMesh) -> DeformationResult:
        """Update current mesh and compute deformation from source."""
        self._previous_mesh = self._current_mesh
        mesh.compute_all_laplacians()
        self._current_mesh = mesh

        return self._compute_deformation()

    def _compute_deformation(self) -> DeformationResult:
        """Compute Laplacian deformation between source and current mesh."""
        if self._source_mesh is None or self._current_mesh is None:
            return DeformationResult(
                total_energy=0.0,
                max_deformation=0.0,
                contact_preservation_ratio=1.0,
                penetration_depth=0.0,
                contact_slip=0.0,
            )

        source = self._source_mesh
        current = self._current_mesh

        # Compute deformation energy: ||L_target - L_source||^2
        total_energy = 0.0
        max_deform = 0.0

        for i in source.laplacian_coords:
            if i not in current.laplacian_coords:
                continue

            src_l = source.laplacian_coords[i]
            cur_l = current.laplacian_coords[i]

            # Euclidean distance between Laplacian coordinates
            dx = cur_l[0] - src_l[0]
            dy = cur_l[1] - src_l[1]
            dz = cur_l[2] - src_l[2]
            dist_sq = dx * dx + dy * dy + dz * dz

            total_energy += dist_sq
            max_deform = max(max_deform, math.sqrt(dist_sq))

        # Contact preservation
        src_contacts = sum(1 for kp in source.keypoints if kp.is_contact)
        cur_contacts = sum(1 for kp in current.keypoints if kp.is_contact)
        contact_ratio = cur_contacts / max(src_contacts, 1)

        # Contact slip (simplified - actual implementation would track matching contacts)
        contact_slip = 0.0
        for i, kp in enumerate(source.keypoints):
            if kp.is_contact and i < len(current.keypoints):
                src_pos = kp.position
                cur_pos = current.keypoints[i].position
                slip = math.sqrt(
                    (cur_pos[0] - src_pos[0]) ** 2
                    + (cur_pos[1] - src_pos[1]) ** 2
                    + (cur_pos[2] - src_pos[2]) ** 2
                )
                contact_slip = max(contact_slip, slip)

        return DeformationResult(
            total_energy=total_energy * self.laplacian_weight,
            max_deformation=max_deform,
            contact_preservation_ratio=contact_ratio,
            penetration_depth=0.0,  # Would need collision detection
            contact_slip=contact_slip,
        )


class InteractionPreservingController:
    """
    Controller that adjusts impedance based on Laplacian deformation.

    When deformation exceeds thresholds for object fragility:
    - Reduce stiffness to become more compliant
    - Slow down motion to prevent impact
    - Adjust contact forces to prevent crushing
    """

    # Fragility-based thresholds
    THRESHOLDS = {
        "fragile": {
            "max_deformation": 0.005,
            "max_slip": 0.002,
            "min_contact_ratio": 0.95,
        },
        "delicate": {
            "max_deformation": 0.01,
            "max_slip": 0.005,
            "min_contact_ratio": 0.90,
        },
        "standard": {
            "max_deformation": 0.05,
            "max_slip": 0.02,
            "min_contact_ratio": 0.80,
        },
        "robust": {
            "max_deformation": 0.1,
            "max_slip": 0.05,
            "min_contact_ratio": 0.70,
        },
    }

    def __init__(self, object_fragility: str = "standard"):
        self.object_fragility = object_fragility
        self.tracker = LaplacianDeformationTracker()
        self._thresholds = self.THRESHOLDS.get(object_fragility, self.THRESHOLDS["standard"])

    def check_safety(self, deformation: DeformationResult) -> Dict[str, Any]:
        """
        Check if deformation is safe for current object fragility.

        Returns adjustment recommendations if unsafe.
        """
        violations = []
        adjustments = {}

        if deformation.max_deformation > self._thresholds["max_deformation"]:
            violations.append("deformation_exceeded")
            # Reduce stiffness to become more compliant
            scale = self._thresholds["max_deformation"] / max(deformation.max_deformation, 0.001)
            adjustments["stiffness_scale"] = min(scale, 1.0)

        if deformation.contact_slip > self._thresholds["max_slip"]:
            violations.append("contact_slip_exceeded")
            # Slow down motion
            adjustments["velocity_scale"] = 0.5

        if deformation.contact_preservation_ratio < self._thresholds["min_contact_ratio"]:
            violations.append("contact_lost")
            # Increase grip force slightly
            adjustments["grip_force_scale"] = 1.2

        return {
            "is_safe": len(violations) == 0,
            "violations": violations,
            "adjustments": adjustments,
            "fragility": self.object_fragility,
        }


def build_manipulation_mesh(
    robot_keypoints: List[Tuple[str, Tuple[float, float, float]]],
    object_keypoints: List[Tuple[float, float, float]],
    terrain_keypoints: Optional[List[Tuple[float, float, float]]] = None,
) -> InteractionMesh:
    """
    Build an interaction mesh for manipulation task.

    Args:
        robot_keypoints: List of (name, position) for robot joints/end-effectors
        object_keypoints: List of positions sampled from object surface
        terrain_keypoints: Optional terrain contact points

    Returns:
        InteractionMesh with Delaunay-inspired edge connectivity
    """
    mesh = InteractionMesh()

    # Add robot keypoints
    robot_indices = []
    for name, pos in robot_keypoints:
        idx = mesh.add_keypoint(Keypoint(name=name, position=pos, source="robot"))
        robot_indices.append(idx)

    # Add object keypoints
    object_indices = []
    for i, pos in enumerate(object_keypoints):
        idx = mesh.add_keypoint(
            Keypoint(name=f"object_{i}", position=pos, source="object", is_contact=True)
        )
        object_indices.append(idx)

    # Add terrain keypoints
    terrain_indices = []
    if terrain_keypoints:
        for i, pos in enumerate(terrain_keypoints):
            idx = mesh.add_keypoint(
                Keypoint(name=f"terrain_{i}", position=pos, source="terrain")
            )
            terrain_indices.append(idx)

    # Build edges using nearest-neighbor heuristic
    # (In practice, use scipy.spatial.Delaunay for proper tetrahedralization)
    all_indices = robot_indices + object_indices + terrain_indices

    for i in range(len(all_indices)):
        for j in range(i + 1, len(all_indices)):
            idx_i = all_indices[i]
            idx_j = all_indices[j]
            pos_i = mesh.keypoints[idx_i].position
            pos_j = mesh.keypoints[idx_j].position

            # Connect if within threshold distance
            dist = math.sqrt(
                (pos_i[0] - pos_j[0]) ** 2
                + (pos_i[1] - pos_j[1]) ** 2
                + (pos_i[2] - pos_j[2]) ** 2
            )
            if dist < 0.5:  # 50cm threshold
                mesh.edges.append((idx_i, idx_j))

    mesh.compute_all_laplacians()
    return mesh


__all__ = [
    "Keypoint",
    "InteractionMesh",
    "DeformationResult",
    "LaplacianDeformationTracker",
    "InteractionPreservingController",
    "build_manipulation_mesh",
]
