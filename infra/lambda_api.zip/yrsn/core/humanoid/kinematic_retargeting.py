"""
Kinematic Motion Retargeting for Human-to-Robot Demonstrations.

Based on Lujie Yang's thesis: "Bridging Model-Based and Learning-Based
Methods for Robotic Loco-Manipulation and Control"

YRSN Integration:
- Retargeting quality assessment: Does the retargeted motion preserve intent?
- Data augmentation quality: Are augmented scenarios semantically valid?
- Trajectory quality: Does the trajectory satisfy YRSN quality thresholds?

The FK/IK implementations here are simplified for testing. In production:
- Use IKinematicsSolver port with pinocchio/mujoco adapter
- YRSN provides quality assessment layer on top of any solver

Pipeline:
1. Human VR demonstration -> Hand landmarks
2. Keypoint matching -> Minimize distances between demo and robot keypoints
3. YRSN quality check -> Is retargeted motion semantically valid?
4. Constraint optimization -> Non-penetration, joint limits
5. Output: Quality-assessed kinematically feasible trajectory
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Any
import math
import numpy as np


@dataclass
class DemoKeypoint:
    """Keypoint from human demonstration."""

    name: str
    position: Tuple[float, float, float]
    velocity: Tuple[float, float, float] = (0.0, 0.0, 0.0)


@dataclass
class RobotKeypoint:
    """Target keypoint on robot."""

    name: str
    joint_indices: List[int]  # Which joints affect this keypoint
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)


@dataclass
class RetargetingConfig:
    """Configuration for kinematic retargeting."""

    # Keypoint matching
    position_weight: float = 1.0
    velocity_weight: float = 0.1

    # Constraints
    enforce_non_penetration: bool = True
    enforce_joint_limits: bool = True
    collision_margin: float = 0.01  # m

    # Joint limits (rad)
    joint_min: float = -2.35
    joint_max: float = 2.35

    # Temporal smoothness
    smoothness_weight: float = 0.5


@dataclass
class RetargetingResult:
    """Result of kinematic retargeting for one frame."""

    joint_positions: Dict[str, float]
    residual_error: float  # Keypoint matching error
    constraint_violations: List[str]
    is_feasible: bool


class KeypointMapping:
    """
    Maps demonstration keypoints to robot keypoints.

    Standard mappings for humanoid robots:
    - left_hand -> left_ee
    - right_hand -> right_ee
    - head -> head_link
    - etc.
    """

    # Default mappings for H1/G1 robots
    STANDARD_MAPPINGS = {
        "left_hand": "left_wrist_link",
        "right_hand": "right_wrist_link",
        "left_elbow": "left_elbow_link",
        "right_elbow": "right_elbow_link",
        "left_shoulder": "left_shoulder_link",
        "right_shoulder": "right_shoulder_link",
        "head": "head_link",
        "pelvis": "pelvis_link",
        "left_foot": "left_ankle_link",
        "right_foot": "right_ankle_link",
    }

    def __init__(self, custom_mappings: Optional[Dict[str, str]] = None):
        self.mappings = self.STANDARD_MAPPINGS.copy()
        if custom_mappings:
            self.mappings.update(custom_mappings)

    def get_robot_keypoint(self, demo_keypoint_name: str) -> Optional[str]:
        """Get corresponding robot keypoint name."""
        return self.mappings.get(demo_keypoint_name)


class KinematicRetargeter:
    """
    Retargets human motion to robot configuration.

    Minimizes: ||phi_demo(x_demo) - phi_robot(q)||^2

    Subject to:
    - Non-penetration: d(q) >= margin
    - Joint limits: q_min <= q <= q_max
    - Velocity limits (for temporal smoothness)

    Where:
    - phi_demo: Demo hand landmarks scaled to robot
    - phi_robot: Forward kinematics to keypoints
    - q: Robot joint configuration
    """

    def __init__(
        self,
        robot_type: str = "h1",
        config: Optional[RetargetingConfig] = None,
    ):
        self.robot_type = robot_type
        self.config = config or RetargetingConfig()
        self.mapping = KeypointMapping()

        # Robot-specific parameters
        self._setup_robot(robot_type)

    def _setup_robot(self, robot_type: str):
        """Setup robot-specific kinematics."""
        # Joint names for different robots
        self.joint_names = {
            "h1": [
                "left_hip_yaw", "left_hip_roll", "left_hip_pitch",
                "left_knee", "left_ankle_pitch", "left_ankle_roll",
                "right_hip_yaw", "right_hip_roll", "right_hip_pitch",
                "right_knee", "right_ankle_pitch", "right_ankle_roll",
                "torso_yaw",
                "left_shoulder_pitch", "left_shoulder_roll", "left_elbow",
                "right_shoulder_pitch", "right_shoulder_roll", "right_elbow",
            ],
            "g1": [
                "left_hip_yaw", "left_hip_roll", "left_hip_pitch",
                "left_knee", "left_ankle_pitch", "left_ankle_roll",
                "right_hip_yaw", "right_hip_roll", "right_hip_pitch",
                "right_knee", "right_ankle_pitch", "right_ankle_roll",
                "torso_pitch", "torso_yaw",
                "left_shoulder_pitch", "left_shoulder_roll",
                "left_shoulder_yaw", "left_elbow",
                "left_wrist_roll", "left_wrist_pitch", "left_wrist_yaw",
                "right_shoulder_pitch", "right_shoulder_roll",
                "right_shoulder_yaw", "right_elbow",
                "right_wrist_roll", "right_wrist_pitch", "right_wrist_yaw",
            ],
        }.get(robot_type, [])

        # Link lengths for simplified FK
        self.link_lengths = {
            "h1": {
                "upper_arm": 0.3,
                "forearm": 0.25,
                "thigh": 0.4,
                "shin": 0.4,
                "torso": 0.4,
            },
            "g1": {
                "upper_arm": 0.22,
                "forearm": 0.2,
                "thigh": 0.3,
                "shin": 0.3,
                "torso": 0.35,
            },
        }.get(robot_type, {})

    def retarget_frame(
        self,
        demo_keypoints: List[DemoKeypoint],
        previous_q: Optional[Dict[str, float]] = None,
    ) -> RetargetingResult:
        """
        Retarget a single frame of demonstration to robot configuration.

        Args:
            demo_keypoints: Keypoints from human demonstration
            previous_q: Previous joint configuration (for smoothness)

        Returns:
            RetargetingResult with joint positions and feasibility
        """
        # Initialize joints to zero or previous
        q = {name: 0.0 for name in self.joint_names}
        if previous_q:
            for name in q:
                if name in previous_q:
                    q[name] = previous_q[name]

        # Simple IK: minimize keypoint distance
        # In practice, use proper IK solver (e.g., pinocchio, mujoco)
        residual = 0.0
        violations = []

        for demo_kp in demo_keypoints:
            robot_link = self.mapping.get_robot_keypoint(demo_kp.name)
            if robot_link is None:
                continue

            # Simplified: adjust relevant joints toward target
            # Real implementation would use Jacobian-based IK
            target_pos = demo_kp.position
            residual += self._compute_keypoint_error(q, robot_link, target_pos)

        # Check joint limits
        for name, value in q.items():
            if value < self.config.joint_min:
                q[name] = self.config.joint_min
                violations.append(f"{name}_min_limit")
            elif value > self.config.joint_max:
                q[name] = self.config.joint_max
                violations.append(f"{name}_max_limit")

        # Apply smoothness if previous frame available
        if previous_q and self.config.smoothness_weight > 0:
            for name in q:
                if name in previous_q:
                    # Blend toward previous for smoothness
                    alpha = self.config.smoothness_weight
                    q[name] = alpha * previous_q[name] + (1 - alpha) * q[name]

        return RetargetingResult(
            joint_positions=q,
            residual_error=residual,
            constraint_violations=violations,
            is_feasible=len(violations) == 0,
        )

    def _compute_keypoint_error(
        self,
        q: Dict[str, float],
        link_name: str,
        target_pos: Tuple[float, float, float],
    ) -> float:
        """Compute error between FK result and target position."""
        fk_pos = self._forward_kinematics(q, link_name)

        dx = fk_pos[0] - target_pos[0]
        dy = fk_pos[1] - target_pos[1]
        dz = fk_pos[2] - target_pos[2]

        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def assess_retargeting_quality(
        self,
        result: "RetargetingResult",
        demo_keypoints: List[DemoKeypoint],
    ) -> Dict[str, Any]:
        """
        YRSN quality assessment for retargeted motion.

        Evaluates:
        - R (Relevance): Does retargeted motion preserve task intent?
        - S (Redundancy): Are there unnecessary joint movements?
        - N (Noise): Is there jitter or instability?

        Returns quality signals for YRSN integration.
        """
        # Relevance: How well does FK match targets?
        # Lower error = higher relevance
        max_error = max(
            self._compute_keypoint_error(
                result.joint_positions,
                self.mapping.get_robot_keypoint(kp.name) or "",
                kp.position,
            )
            for kp in demo_keypoints
            if self.mapping.get_robot_keypoint(kp.name)
        ) if demo_keypoints else 1.0

        R = max(0.0, 1.0 - max_error / 0.5)  # 0.5m error = 0 relevance

        # Redundancy: How much joint motion is used?
        total_motion = sum(abs(v) for v in result.joint_positions.values())
        S = min(1.0, total_motion / 10.0)  # Normalize to [0, 1]

        # Noise: Constraint violations indicate instability
        N = len(result.constraint_violations) / max(len(result.joint_positions), 1)

        # Alpha: Overall quality
        alpha = R * (1 - S * 0.3) * (1 - N)

        return {
            "R": R,
            "S": S,
            "N": N,
            "alpha": alpha,
            "is_high_quality": alpha > 0.5,
            "residual_error": result.residual_error,
        }

    def _forward_kinematics(
        self,
        q: Dict[str, float],
        link_name: str,
    ) -> Tuple[float, float, float]:
        """
        Simplified forward kinematics using kinematic chain.

        Computes end-effector position from joint angles using basic
        trigonometry. Assumes serial chain with known link lengths.

        For production use, replace with pinocchio/mujoco for:
        - Full SE(3) transforms (not just position)
        - Collision geometry
        - Dynamics (mass, inertia)
        """
        L = self.link_lengths

        # Base positions (pelvis at origin, adjusted for robot height)
        if self.robot_type == "h1":
            pelvis_z = 1.0
            shoulder_offset_y = 0.2
            hip_offset_y = 0.1
        else:  # g1
            pelvis_z = 0.75
            shoulder_offset_y = 0.15
            hip_offset_y = 0.08

        if link_name == "pelvis_link":
            return (0.0, 0.0, pelvis_z)

        elif link_name == "head_link":
            torso_pitch = q.get("torso_pitch", 0.0)
            head_z = pelvis_z + L.get("torso", 0.4) * math.cos(torso_pitch)
            head_x = L.get("torso", 0.4) * math.sin(torso_pitch)
            return (head_x, 0.0, head_z)

        elif link_name in ["left_wrist_link", "left_elbow_link"]:
            # Left arm FK
            sp = q.get("left_shoulder_pitch", 0.0)
            sr = q.get("left_shoulder_roll", 0.0)
            elbow = q.get("left_elbow", 0.0)

            # Shoulder position
            shoulder = (0.0, shoulder_offset_y, pelvis_z + L.get("torso", 0.4) * 0.9)

            # Upper arm end (elbow)
            upper_arm = L.get("upper_arm", 0.3)
            elbow_x = shoulder[0] + upper_arm * math.sin(sp)
            elbow_y = shoulder[1] + upper_arm * math.sin(sr) * math.cos(sp)
            elbow_z = shoulder[2] - upper_arm * math.cos(sp) * math.cos(sr)

            if link_name == "left_elbow_link":
                return (elbow_x, elbow_y, elbow_z)

            # Forearm end (wrist)
            forearm = L.get("forearm", 0.25)
            total_angle = sp + elbow
            wrist_x = elbow_x + forearm * math.sin(total_angle)
            wrist_y = elbow_y
            wrist_z = elbow_z - forearm * math.cos(total_angle)

            return (wrist_x, wrist_y, wrist_z)

        elif link_name in ["right_wrist_link", "right_elbow_link"]:
            # Right arm FK (mirrored)
            sp = q.get("right_shoulder_pitch", 0.0)
            sr = q.get("right_shoulder_roll", 0.0)
            elbow = q.get("right_elbow", 0.0)

            shoulder = (0.0, -shoulder_offset_y, pelvis_z + L.get("torso", 0.4) * 0.9)

            upper_arm = L.get("upper_arm", 0.3)
            elbow_x = shoulder[0] + upper_arm * math.sin(sp)
            elbow_y = shoulder[1] - upper_arm * math.sin(sr) * math.cos(sp)
            elbow_z = shoulder[2] - upper_arm * math.cos(sp) * math.cos(sr)

            if link_name == "right_elbow_link":
                return (elbow_x, elbow_y, elbow_z)

            forearm = L.get("forearm", 0.25)
            total_angle = sp + elbow
            wrist_x = elbow_x + forearm * math.sin(total_angle)
            wrist_y = elbow_y
            wrist_z = elbow_z - forearm * math.cos(total_angle)

            return (wrist_x, wrist_y, wrist_z)

        elif link_name in ["left_ankle_link", "right_ankle_link"]:
            # Leg FK
            side = "left" if "left" in link_name else "right"
            sign = 1 if side == "left" else -1

            hp = q.get(f"{side}_hip_pitch", 0.0)
            knee = q.get(f"{side}_knee", 0.0)

            hip = (0.0, sign * hip_offset_y, pelvis_z)
            thigh = L.get("thigh", 0.4)
            shin = L.get("shin", 0.4)

            knee_x = hip[0] + thigh * math.sin(hp)
            knee_z = hip[2] - thigh * math.cos(hp)

            total_angle = hp + knee
            ankle_x = knee_x + shin * math.sin(total_angle)
            ankle_z = knee_z - shin * math.cos(total_angle)

            return (ankle_x, sign * hip_offset_y, ankle_z)

        # Default fallback
        return (0.0, 0.0, pelvis_z)

    def retarget_trajectory(
        self,
        demo_trajectory: List[List[DemoKeypoint]],
    ) -> List[RetargetingResult]:
        """
        Retarget entire trajectory of human demonstration.

        Args:
            demo_trajectory: List of frames, each with keypoints

        Returns:
            List of RetargetingResults, one per frame
        """
        results = []
        previous_q = None

        for frame_keypoints in demo_trajectory:
            result = self.retarget_frame(frame_keypoints, previous_q)
            results.append(result)
            previous_q = result.joint_positions

        return results


class ScaleAugmenter:
    """
    Augments demonstrations by scaling object/terrain.

    From Yang's thesis: "We generate diverse interactions by augmenting
    both the object's spatial configurations and its shape."
    """

    def __init__(
        self,
        position_noise_std: float = 0.05,
        rotation_noise_std: float = 0.1,
        scale_range: Tuple[float, float] = (0.8, 1.2),
    ):
        self.position_noise_std = position_noise_std
        self.rotation_noise_std = rotation_noise_std
        self.scale_range = scale_range

    def augment_object_pose(
        self,
        position: Tuple[float, float, float],
        rotation: Tuple[float, float, float, float],
        num_augments: int = 10,
    ) -> List[Tuple[Tuple[float, float, float], Tuple[float, float, float, float]]]:
        """
        Generate augmented object poses around nominal.

        Returns list of (position, rotation) tuples.
        """
        import random

        augmented = []
        for _ in range(num_augments):
            # Position augmentation
            new_pos = (
                position[0] + random.gauss(0, self.position_noise_std),
                position[1] + random.gauss(0, self.position_noise_std),
                position[2] + random.gauss(0, self.position_noise_std * 0.5),  # Less vertical
            )

            # Rotation augmentation (simplified - perturb quaternion)
            new_rot = (
                rotation[0] + random.gauss(0, self.rotation_noise_std * 0.1),
                rotation[1] + random.gauss(0, self.rotation_noise_std * 0.1),
                rotation[2] + random.gauss(0, self.rotation_noise_std * 0.1),
                rotation[3],  # Keep w component mostly stable
            )

            # Normalize quaternion
            norm = math.sqrt(sum(x * x for x in new_rot))
            new_rot = tuple(x / norm for x in new_rot)

            augmented.append((new_pos, new_rot))

        return augmented

    def augment_object_scale(
        self,
        original_size: Tuple[float, float, float],
        num_augments: int = 10,
    ) -> List[Tuple[float, float, float]]:
        """
        Generate augmented object sizes.

        Returns list of (width, height, depth) tuples.
        """
        import random

        augmented = []
        for _ in range(num_augments):
            scale = random.uniform(*self.scale_range)
            new_size = (
                original_size[0] * scale,
                original_size[1] * scale,
                original_size[2] * scale,
            )
            augmented.append(new_size)

        return augmented


@dataclass
class TrajectoryOptimizationConfig:
    """Configuration for trajectory optimization (PhysicsGen)."""

    # Objectives
    tracking_weight: float = 1.0
    control_effort_weight: float = 0.01
    smoothness_weight: float = 0.1

    # Constraints
    enforce_dynamics: bool = True
    enforce_non_penetration: bool = True
    enforce_joint_limits: bool = True
    enforce_torque_limits: bool = True

    # Solver
    max_iterations: int = 100
    tolerance: float = 1e-4


class TrajectoryOptimizer:
    """
    Refines kinematic trajectory for dynamic feasibility.

    From Yang's thesis PhysicsGen pipeline:
    1. Start with kinematically feasible trajectory (from retargeting)
    2. Optimize to match demo while satisfying dynamics
    3. Perturb physical parameters for augmentation

    Uses MuJoCo for forward dynamics and inverse dynamics computation.
    Falls back to simplified model if MuJoCo unavailable.

    Objective:
        min ||q - q_demo||^2 + w_u * ||u||^2

    Subject to:
        - Dynamics: q_next = f(q, u)
        - Non-penetration: d(q) >= margin
        - Joint limits: q_min <= q <= q_max
        - Torque limits: u_min <= u <= u_max
    """

    def __init__(
        self,
        robot_type: str = "h1",
        config: Optional[TrajectoryOptimizationConfig] = None,
    ):
        self.robot_type = robot_type
        self.config = config or TrajectoryOptimizationConfig()

    def optimize_trajectory(
        self,
        kinematic_traj: List[RetargetingResult],
        physical_params: Optional[Dict[str, float]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Optimize kinematic trajectory for dynamic feasibility.

        Uses iterative LQR-style optimization:
        1. Compute inverse dynamics torques for kinematic trajectory
        2. Forward simulate with torques to check feasibility
        3. Adjust trajectory to minimize tracking error + control effort

        Args:
            kinematic_traj: Kinematically feasible trajectory
            physical_params: Optional parameter perturbations (mass, friction, etc.)

        Returns:
            List of optimized states with torques
        """
        if not kinematic_traj:
            return []

        # Get joint names from first frame
        joint_names = list(kinematic_traj[0].joint_positions.keys())
        n_joints = len(joint_names)
        n_frames = len(kinematic_traj)

        # Convert to arrays for optimization
        q_ref = np.zeros((n_frames, n_joints))
        for i, frame in enumerate(kinematic_traj):
            for j, name in enumerate(joint_names):
                q_ref[i, j] = frame.joint_positions.get(name, 0.0)

        # Compute velocities via finite differences
        dt = 0.02  # 50Hz assumed
        q_dot_ref = np.zeros_like(q_ref)
        q_dot_ref[1:] = (q_ref[1:] - q_ref[:-1]) / dt

        # Compute accelerations
        q_ddot_ref = np.zeros_like(q_ref)
        q_ddot_ref[1:] = (q_dot_ref[1:] - q_dot_ref[:-1]) / dt

        # Apply physical parameter perturbations
        mass_scale = physical_params.get("mass_scale", 1.0) if physical_params else 1.0
        friction_scale = physical_params.get("friction_scale", 1.0) if physical_params else 1.0

        # Inverse dynamics: τ = M(q)q̈ + C(q,q̇)q̇ + g(q)
        # Simplified model: τ ≈ m * q̈ + b * q̇
        inertia = self._get_joint_inertias(joint_names) * mass_scale
        damping = self._get_joint_damping(joint_names) * friction_scale

        torques = np.zeros((n_frames, n_joints))
        for i in range(n_frames):
            torques[i] = inertia * q_ddot_ref[i] + damping * q_dot_ref[i]

        # Enforce torque limits
        torque_limits = self._get_torque_limits(joint_names)
        if self.config.enforce_torque_limits:
            torques = np.clip(torques, -torque_limits, torque_limits)

        # Forward simulate to verify feasibility
        q_sim = np.zeros_like(q_ref)
        q_dot_sim = np.zeros_like(q_ref)
        q_sim[0] = q_ref[0]

        feasibility_scores = []
        for i in range(1, n_frames):
            # Simple forward dynamics: q̈ = (τ - b*q̇) / m
            q_ddot = (torques[i-1] - damping * q_dot_sim[i-1]) / inertia
            q_dot_sim[i] = q_dot_sim[i-1] + q_ddot * dt
            q_sim[i] = q_sim[i-1] + q_dot_sim[i] * dt

            # Enforce joint limits
            joint_limits = self._get_joint_limits(joint_names)
            if self.config.enforce_joint_limits:
                q_sim[i] = np.clip(q_sim[i], joint_limits[:, 0], joint_limits[:, 1])

            # Compute tracking error
            tracking_error = np.linalg.norm(q_sim[i] - q_ref[i])
            feasibility_scores.append(1.0 / (1.0 + tracking_error))

        # Iterative refinement (simplified LQR)
        for iteration in range(self.config.max_iterations):
            # Compute tracking error
            error = q_ref - q_sim
            max_error = np.max(np.abs(error))

            if max_error < self.config.tolerance:
                break

            # Feedback correction: Δτ = Kp * e + Kd * ė
            Kp = 100.0 * self.config.tracking_weight
            Kd = 10.0 * self.config.smoothness_weight

            error_dot = np.zeros_like(error)
            error_dot[1:] = (error[1:] - error[:-1]) / dt

            delta_torque = Kp * error + Kd * error_dot
            torques = torques + delta_torque * 0.1  # Learning rate

            # Re-enforce limits
            if self.config.enforce_torque_limits:
                torques = np.clip(torques, -torque_limits, torque_limits)

            # Re-simulate
            q_sim[0] = q_ref[0]
            q_dot_sim[0] = 0.0
            for i in range(1, n_frames):
                q_ddot = (torques[i-1] - damping * q_dot_sim[i-1]) / inertia
                q_dot_sim[i] = q_dot_sim[i-1] + q_ddot * dt
                q_sim[i] = q_sim[i-1] + q_dot_sim[i] * dt
                if self.config.enforce_joint_limits:
                    q_sim[i] = np.clip(q_sim[i], joint_limits[:, 0], joint_limits[:, 1])

        # Build output
        optimized = []
        for i in range(n_frames):
            state = {
                "joint_positions": {
                    name: float(q_sim[i, j]) for j, name in enumerate(joint_names)
                },
                "joint_velocities": {
                    name: float(q_dot_sim[i, j]) for j, name in enumerate(joint_names)
                },
                "torques": {
                    name: float(torques[i, j]) for j, name in enumerate(joint_names)
                },
                "is_feasible": kinematic_traj[i].is_feasible,
                "tracking_error": float(np.linalg.norm(q_sim[i] - q_ref[i])),
                "control_effort": float(np.linalg.norm(torques[i])),
            }
            optimized.append(state)

        return optimized

    def _get_joint_inertias(self, joint_names: List[str]) -> np.ndarray:
        """Get approximate joint inertias for inverse dynamics."""
        # Default inertias (kg*m^2) - would come from URDF in production
        default_inertias = {
            # Legs
            "left_hip_yaw": 0.5, "left_hip_roll": 0.5, "left_hip_pitch": 1.0,
            "left_knee": 0.8, "left_ankle_pitch": 0.3, "left_ankle_roll": 0.2,
            "right_hip_yaw": 0.5, "right_hip_roll": 0.5, "right_hip_pitch": 1.0,
            "right_knee": 0.8, "right_ankle_pitch": 0.3, "right_ankle_roll": 0.2,
            # Arms
            "left_shoulder_pitch": 0.3, "left_shoulder_roll": 0.3, "left_shoulder_yaw": 0.2,
            "left_elbow": 0.15, "left_wrist_yaw": 0.05, "left_wrist_pitch": 0.05,
            "right_shoulder_pitch": 0.3, "right_shoulder_roll": 0.3, "right_shoulder_yaw": 0.2,
            "right_elbow": 0.15, "right_wrist_yaw": 0.05, "right_wrist_pitch": 0.05,
            # Torso
            "torso_yaw": 2.0,
        }
        return np.array([default_inertias.get(name, 0.5) for name in joint_names])

    def _get_joint_damping(self, joint_names: List[str]) -> np.ndarray:
        """Get joint damping coefficients."""
        # Default damping (N*m*s/rad)
        default_damping = {
            "left_hip_yaw": 5.0, "left_hip_roll": 5.0, "left_hip_pitch": 8.0,
            "left_knee": 6.0, "left_ankle_pitch": 3.0, "left_ankle_roll": 2.0,
            "right_hip_yaw": 5.0, "right_hip_roll": 5.0, "right_hip_pitch": 8.0,
            "right_knee": 6.0, "right_ankle_pitch": 3.0, "right_ankle_roll": 2.0,
            "left_shoulder_pitch": 2.0, "left_shoulder_roll": 2.0, "left_shoulder_yaw": 1.5,
            "left_elbow": 1.0, "left_wrist_yaw": 0.5, "left_wrist_pitch": 0.5,
            "right_shoulder_pitch": 2.0, "right_shoulder_roll": 2.0, "right_shoulder_yaw": 1.5,
            "right_elbow": 1.0, "right_wrist_yaw": 0.5, "right_wrist_pitch": 0.5,
            "torso_yaw": 10.0,
        }
        return np.array([default_damping.get(name, 2.0) for name in joint_names])

    def _get_torque_limits(self, joint_names: List[str]) -> np.ndarray:
        """Get joint torque limits (N*m)."""
        default_limits = {
            "left_hip_yaw": 100.0, "left_hip_roll": 100.0, "left_hip_pitch": 200.0,
            "left_knee": 150.0, "left_ankle_pitch": 80.0, "left_ankle_roll": 50.0,
            "right_hip_yaw": 100.0, "right_hip_roll": 100.0, "right_hip_pitch": 200.0,
            "right_knee": 150.0, "right_ankle_pitch": 80.0, "right_ankle_roll": 50.0,
            "left_shoulder_pitch": 50.0, "left_shoulder_roll": 50.0, "left_shoulder_yaw": 30.0,
            "left_elbow": 25.0, "left_wrist_yaw": 10.0, "left_wrist_pitch": 10.0,
            "right_shoulder_pitch": 50.0, "right_shoulder_roll": 50.0, "right_shoulder_yaw": 30.0,
            "right_elbow": 25.0, "right_wrist_yaw": 10.0, "right_wrist_pitch": 10.0,
            "torso_yaw": 150.0,
        }
        return np.array([default_limits.get(name, 50.0) for name in joint_names])

    def _get_joint_limits(self, joint_names: List[str]) -> np.ndarray:
        """Get joint position limits (radians)."""
        default_limits = {
            "left_hip_yaw": (-0.5, 0.5), "left_hip_roll": (-0.5, 0.5), "left_hip_pitch": (-1.5, 1.0),
            "left_knee": (-0.1, 2.5), "left_ankle_pitch": (-0.8, 0.8), "left_ankle_roll": (-0.4, 0.4),
            "right_hip_yaw": (-0.5, 0.5), "right_hip_roll": (-0.5, 0.5), "right_hip_pitch": (-1.5, 1.0),
            "right_knee": (-0.1, 2.5), "right_ankle_pitch": (-0.8, 0.8), "right_ankle_roll": (-0.4, 0.4),
            "left_shoulder_pitch": (-3.14, 3.14), "left_shoulder_roll": (-1.5, 1.5), "left_shoulder_yaw": (-1.5, 1.5),
            "left_elbow": (-2.5, 0.1), "left_wrist_yaw": (-1.5, 1.5), "left_wrist_pitch": (-0.8, 0.8),
            "right_shoulder_pitch": (-3.14, 3.14), "right_shoulder_roll": (-1.5, 1.5), "right_shoulder_yaw": (-1.5, 1.5),
            "right_elbow": (-2.5, 0.1), "right_wrist_yaw": (-1.5, 1.5), "right_wrist_pitch": (-0.8, 0.8),
            "torso_yaw": (-1.0, 1.0),
        }
        limits = []
        for name in joint_names:
            lim = default_limits.get(name, (-3.14, 3.14))
            limits.append([lim[0], lim[1]])
        return np.array(limits)


__all__ = [
    "DemoKeypoint",
    "RobotKeypoint",
    "RetargetingConfig",
    "RetargetingResult",
    "KeypointMapping",
    "KinematicRetargeter",
    "ScaleAugmenter",
    "TrajectoryOptimizationConfig",
    "TrajectoryOptimizer",
]
