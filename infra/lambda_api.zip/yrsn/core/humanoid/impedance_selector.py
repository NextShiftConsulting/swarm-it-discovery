"""
Impedance Selector - Phase and quality aware impedance selection.

Selects stiffness (K) and damping (D) based on:
- Current manipulation phase (FREE_MOTION, CONTACT, etc.)
- YRSN quality signal (α)
- Task requirements

Based on OmniVIC's phase-aware impedance control.
"""

from dataclasses import dataclass
from typing import Dict, Tuple, Optional

from yrsn.ports.phase import VLAPhase, PHASE_PARAMETERS


@dataclass
class ImpedanceConfig:
    """Configuration for impedance selection."""

    # Global scaling factors
    K_scale: float = 1.0  # Scale all stiffness
    D_scale: float = 1.0  # Scale all damping

    # Quality thresholds
    alpha_low: float = 0.3   # Below this, use minimum stiffness
    alpha_high: float = 0.7  # Above this, use maximum stiffness

    # Safety limits
    K_max: float = 1500.0  # Maximum stiffness (N/m)
    K_min: float = 10.0    # Minimum stiffness (N/m)
    D_max: float = 150.0   # Maximum damping (Ns/m)
    D_min: float = 1.0     # Minimum damping (Ns/m)

    # Critical damping ratio (D = 2 * sqrt(K * m))
    # Typically want 0.7-1.0 for stable contact
    damping_ratio: float = 0.8


class ImpedanceSelector:
    """
    Selects impedance parameters based on phase and quality.

    Higher quality (α) → can use higher stiffness (faster, stiffer)
    Lower quality (α) → use lower stiffness (safer, compliant)

    In CONTACT phase, always more compliant regardless of α.
    """

    def __init__(self, config: Optional[ImpedanceConfig] = None):
        self.config = config or ImpedanceConfig()

    def get_impedance(
        self,
        phase: VLAPhase,
        alpha: float,
        task_K: Optional[float] = None,
        task_D: Optional[float] = None,
    ) -> Tuple[float, float]:
        """
        Get impedance (K, D) for current phase and quality.

        Args:
            phase: Current manipulation phase
            alpha: YRSN quality signal (0-1)
            task_K: Optional task-specific stiffness override
            task_D: Optional task-specific damping override

        Returns:
            (K, D) tuple - stiffness (N/m) and damping (Ns/m)
        """
        # Get phase base parameters
        params = PHASE_PARAMETERS[phase]
        K_min, K_max = params["K_range"]
        D_min, D_max = params["D_range"]

        # Scale by quality (interpolate between min and max)
        alpha_normalized = self._normalize_alpha(alpha)

        # Base impedance from phase
        K_base = K_min + (K_max - K_min) * alpha_normalized
        D_base = D_min + (D_max - D_min) * alpha_normalized

        # Apply task overrides if provided
        if task_K is not None:
            K_base = task_K * alpha_normalized
        if task_D is not None:
            D_base = task_D * alpha_normalized

        # Apply global scaling
        K = K_base * self.config.K_scale
        D = D_base * self.config.D_scale

        # Clamp to safety limits
        K = max(self.config.K_min, min(self.config.K_max, K))
        D = max(self.config.D_min, min(self.config.D_max, D))

        return K, D

    def _normalize_alpha(self, alpha: float) -> float:
        """Normalize alpha to [0, 1] based on thresholds."""
        if alpha <= self.config.alpha_low:
            return 0.0
        elif alpha >= self.config.alpha_high:
            return 1.0
        else:
            # Linear interpolation between low and high
            return (alpha - self.config.alpha_low) / (self.config.alpha_high - self.config.alpha_low)

    def get_impedance_for_body_parts(
        self,
        phase: VLAPhase,
        alpha: float,
        body_parts: Dict[str, float],  # {part_name: quality_weight}
    ) -> Dict[str, Tuple[float, float]]:
        """
        Get impedance for multiple body parts.

        Args:
            phase: Current phase
            alpha: Base quality
            body_parts: Dict mapping part name to quality weight

        Returns:
            Dict mapping part name to (K, D) tuple
        """
        result = {}
        for part_name, weight in body_parts.items():
            # Weight affects quality scaling
            effective_alpha = alpha * weight
            K, D = self.get_impedance(phase, effective_alpha)
            result[part_name] = (K, D)

        return result

    def compute_critically_damped_D(self, K: float, mass: float = 1.0) -> float:
        """
        Compute damping for critical damping ratio.

        D_critical = 2 * sqrt(K * m)
        D = ratio * D_critical

        Args:
            K: Stiffness (N/m)
            mass: Effective mass (kg)

        Returns:
            Damping coefficient (Ns/m)
        """
        import math
        D_critical = 2 * math.sqrt(K * mass)
        return self.config.damping_ratio * D_critical

    def get_velocity_scale(self, phase: VLAPhase, alpha: float) -> float:
        """
        Get velocity scaling factor for phase.

        Lower quality or contact phase → slower motion.

        Returns:
            Velocity scale (0-1)
        """
        params = PHASE_PARAMETERS[phase]
        base_scale = params["velocity_scale"]

        # Scale by quality
        alpha_normalized = self._normalize_alpha(alpha)

        return base_scale * (0.5 + 0.5 * alpha_normalized)


__all__ = [
    "ImpedanceSelector",
    "ImpedanceConfig",
]
