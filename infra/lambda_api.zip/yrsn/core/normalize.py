"""
YRSN Normalization Utilities
============================

Centralized normalization functions to avoid repeated patterns.

Usage:
    from yrsn.core.normalize import safe_normalize, safe_normalize_rows

    # Single vector
    normalized = safe_normalize(vector)

    # Matrix rows
    normalized_rows = safe_normalize_rows(matrix)
"""

from typing import Union
import numpy as np


def safe_normalize(
    arr: np.ndarray,
    axis: int = None,
    eps: float = 1e-10,
    ord: Union[int, float, str] = 2,
) -> np.ndarray:
    """
    Safely normalize array, handling zero-norm case.

    Args:
        arr: Array to normalize
        axis: Axis along which to compute norm (None = flatten)
        eps: Small epsilon to avoid division by zero
        ord: Norm order (default L2)

    Returns:
        Normalized array (same shape as input)

    Example:
        >>> vec = np.array([3.0, 4.0])
        >>> safe_normalize(vec)
        array([0.6, 0.8])

        >>> zero_vec = np.array([0.0, 0.0])
        >>> safe_normalize(zero_vec)
        array([0., 0.])
    """
    arr = np.asarray(arr)

    if axis is None:
        norm = np.linalg.norm(arr, ord=ord)
        if norm > eps:
            return arr / norm
        return arr
    else:
        norm = np.linalg.norm(arr, ord=ord, axis=axis, keepdims=True)
        # Replace zeros with 1 to avoid division by zero (result will still be zero)
        norm = np.where(norm > eps, norm, 1.0)
        return arr / norm


def safe_normalize_rows(matrix: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Normalize each row of a matrix to unit L2 norm.

    Args:
        matrix: 2D array of shape (n_samples, n_features)
        eps: Small epsilon to avoid division by zero

    Returns:
        Row-normalized matrix

    Example:
        >>> M = np.array([[3, 4], [0, 0], [1, 0]])
        >>> safe_normalize_rows(M)
        array([[0.6, 0.8],
               [0. , 0. ],
               [1. , 0. ]])
    """
    return safe_normalize(matrix, axis=1, eps=eps)


def safe_normalize_cols(matrix: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """
    Normalize each column of a matrix to unit L2 norm.

    Args:
        matrix: 2D array of shape (n_samples, n_features)
        eps: Small epsilon to avoid division by zero

    Returns:
        Column-normalized matrix
    """
    return safe_normalize(matrix, axis=0, eps=eps)


def cosine_similarity(a: np.ndarray, b: np.ndarray, eps: float = 1e-10) -> float:
    """
    Compute cosine similarity between two vectors.

    Args:
        a, b: Input vectors
        eps: Small epsilon for numerical stability

    Returns:
        Cosine similarity in [-1, 1]
    """
    a = np.asarray(a).flatten()
    b = np.asarray(b).flatten()

    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)

    if norm_a < eps or norm_b < eps:
        return 0.0

    return float(np.dot(a, b) / (norm_a * norm_b))


def standardize_features(
    features: np.ndarray,
    method: str = 'l2',
    eps: float = 1e-8
) -> np.ndarray:
    """
    Standardize features to a common scale across different architectures.

    This is CRITICAL for universal rotor training - different neural network
    architectures produce features at different scales and distributions.
    Standardization ensures the rotor sees consistent input regardless of
    the source model.

    Methods:
        - 'l2': L2 normalize each sample (unit length)
        - 'zscore': Z-score normalize (zero mean, unit variance)
        - 'minmax': Min-max normalize to [0, 1]
        - 'none': No normalization (pass-through)

    Args:
        features: Feature matrix [N, D] from any model
        method: Normalization method ('l2', 'zscore', 'minmax', 'none')
        eps: Small epsilon for numerical stability

    Returns:
        np.ndarray: Standardized features [N, D]

    Example:
        >>> resnet_features = resnet.extract(images)  # Different scale
        >>> cnn_features = cnn.extract(images)        # Different scale
        >>>
        >>> # After standardization, both are comparable
        >>> resnet_std = standardize_features(resnet_features, 'l2')
        >>> cnn_std = standardize_features(cnn_features, 'l2')

    Notes:
        - For universal rotor training, use 'l2' (default)
        - L2 normalization preserves angular relationships between samples
        - Z-score is better if you need to preserve magnitude information
    """
    features = np.asarray(features)

    if features.ndim == 1:
        features = features.reshape(1, -1)

    if method == 'l2':
        # L2 normalize each sample to unit length
        return safe_normalize_rows(features, eps=eps)

    elif method == 'zscore':
        # Z-score: (x - mean) / std
        mean = features.mean(axis=0, keepdims=True)
        std = features.std(axis=0, keepdims=True)
        return (features - mean) / (std + eps)

    elif method == 'minmax':
        # Min-max normalize to [0, 1]
        min_val = features.min(axis=0, keepdims=True)
        max_val = features.max(axis=0, keepdims=True)
        return (features - min_val) / (max_val - min_val + eps)

    elif method == 'none':
        # No normalization
        return features

    else:
        raise ValueError(f"Unknown standardization method: {method}. "
                        f"Use 'l2', 'zscore', 'minmax', or 'none'.")


__all__ = [
    "safe_normalize",
    "safe_normalize_rows",
    "safe_normalize_cols",
    "cosine_similarity",
    "standardize_features",
]
