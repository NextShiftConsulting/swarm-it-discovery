"""
Quality Discrimination Evaluator (Core Business Logic)
=======================================================

Evaluates feature extractors on quality-labeled datasets.

Architecture:
- Core logic independent of specific datasets or extractors
- Depends on ports (IQualityDataset, IFeatureExtractor)
- Returns standardized metrics for any dataset/extractor combination

Usage:
    evaluator = QualityDiscriminationEvaluator()

    results = evaluator.evaluate(
        dataset=ASAPAESDataset('data/asap-aes'),
        extractor=SimplexReadyExtractor()
    )

    print(f"R²: {results['r2_test']:.3f}")
    print(f"Spearman ρ: {results['spearman_rho']:.3f}")
"""

from typing import Dict, Any, List
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from scipy.stats import spearmanr, pearsonr
import time

from yrsn.ports.quality_dataset import IQualityDataset
from yrsn.ports.feature_extraction import IFeatureExtractor


class QualityDiscriminationEvaluator:
    """
    Evaluates feature extractors on quality discrimination tasks.

    Single Responsibility: Evaluate quality prediction performance
    Open/Closed: Works with ANY dataset/extractor that implements the ports
    Dependency Inversion: Depends on abstractions (ports), not implementations
    """

    def __init__(self, verbose: bool = True):
        """
        Args:
            verbose: Whether to print progress messages
        """
        self.verbose = verbose

    def evaluate(self,
                 dataset: IQualityDataset,
                 extractor: IFeatureExtractor,
                 test_size: float = 0.2,
                 random_state: int = 42) -> Dict[str, Any]:
        """
        Evaluate an extractor on a dataset.

        Args:
            dataset: Dataset implementing IQualityDataset
            extractor: Feature extractor implementing IFeatureExtractor
            test_size: Fraction for test set
            random_state: Random seed

        Returns:
            Dictionary of evaluation metrics:
                - r2_train: R² on training set
                - r2_test: R² on test set
                - rmse_test: RMSE on test set
                - spearman_rho: Spearman rank correlation
                - pearson_r: Pearson correlation
                - extraction_time: Time to extract features (seconds)
                - feature_dim: Dimensionality of features
                - dataset_name: Name of dataset
                - extractor_name: Name of extractor
        """
        if self.verbose:
            print(f"\nEvaluating {extractor.__class__.__name__} on {dataset.get_metadata().name}...")

        # Get train/test splits
        train_split, test_split = dataset.get_splits(test_size, random_state)

        # Extract features
        start_time = time.time()

        if self.verbose:
            print(f"  Extracting features (train: {len(train_split.texts)}, test: {len(test_split.texts)})...")

        X_train = extractor.extract(train_split.texts)
        X_test = extractor.extract(test_split.texts)

        extraction_time = time.time() - start_time

        # Handle 1D features
        if len(X_train.shape) == 1:
            X_train = X_train.reshape(-1, 1)
            X_test = X_test.reshape(-1, 1)

        feature_dim = X_train.shape[1]

        if self.verbose:
            print(f"  Feature shape: {X_train.shape}, extraction time: {extraction_time:.2f}s")

        # Train linear quality probe
        if self.verbose:
            print(f"  Training linear quality probe...")

        probe = LinearRegression()
        probe.fit(X_train, train_split.labels)

        # Predictions
        y_train_pred = probe.predict(X_train)
        y_test_pred = probe.predict(X_test)

        # Metrics
        r2_train = r2_score(train_split.labels, y_train_pred)
        r2_test = r2_score(test_split.labels, y_test_pred)
        rmse_test = np.sqrt(mean_squared_error(test_split.labels, y_test_pred))

        # Correlation metrics (rank-order)
        spearman_rho, spearman_p = spearmanr(test_split.labels, y_test_pred)
        pearson_r, pearson_p = pearsonr(test_split.labels, y_test_pred)

        if self.verbose:
            print(f"  R² (train): {r2_train:.3f}")
            print(f"  R² (test):  {r2_test:.3f}")
            print(f"  RMSE (test): {rmse_test:.3f}")
            print(f"  Spearman ρ: {spearman_rho:.3f} (p={spearman_p:.3e})")

        # Return standardized results
        return {
            'dataset_name': dataset.get_metadata().name,
            'extractor_name': extractor.__class__.__name__,
            'r2_train': float(r2_train),
            'r2_test': float(r2_test),
            'rmse_test': float(rmse_test),
            'spearman_rho': float(spearman_rho),
            'spearman_p': float(spearman_p),
            'pearson_r': float(pearson_r),
            'pearson_p': float(pearson_p),
            'extraction_time': float(extraction_time),
            'feature_dim': int(feature_dim),
            'train_samples': len(train_split.texts),
            'test_samples': len(test_split.texts)
        }

    def evaluate_multiple(self,
                         datasets: List[IQualityDataset],
                         extractors: List[IFeatureExtractor],
                         **kwargs) -> List[Dict[str, Any]]:
        """
        Evaluate multiple extractors on multiple datasets.

        Args:
            datasets: List of datasets
            extractors: List of extractors
            **kwargs: Additional arguments for evaluate()

        Returns:
            List of evaluation results (one per dataset-extractor pair)
        """
        results = []

        total = len(datasets) * len(extractors)
        current = 0

        for dataset in datasets:
            for extractor in extractors:
                current += 1

                if self.verbose:
                    print(f"\n[{current}/{total}] Evaluating {extractor.__class__.__name__} on {dataset.get_metadata().name}")

                try:
                    result = self.evaluate(dataset, extractor, **kwargs)
                    results.append(result)

                except Exception as e:
                    if self.verbose:
                        print(f"  [ERROR] {e}")

                    results.append({
                        'dataset_name': dataset.get_metadata().name,
                        'extractor_name': extractor.__class__.__name__,
                        'error': str(e)
                    })

        return results

    def compare_extractors(self,
                          results: List[Dict[str, Any]],
                          metric: str = 'spearman_rho') -> None:
        """
        Print comparison table of extractors.

        Args:
            results: List of evaluation results
            metric: Metric to sort by
        """
        # Group by dataset
        datasets = {}
        for result in results:
            if 'error' in result:
                continue

            dataset_name = result['dataset_name']
            if dataset_name not in datasets:
                datasets[dataset_name] = []

            datasets[dataset_name].append(result)

        # Print comparison for each dataset
        for dataset_name, dataset_results in datasets.items():
            print(f"\n{'='*70}")
            print(f"Dataset: {dataset_name}")
            print('='*70)

            # Sort by metric
            sorted_results = sorted(dataset_results, key=lambda x: x.get(metric, -999), reverse=True)

            # Print table
            print(f"{'Rank':<6} {'Extractor':<25} {metric:<15} {'R²':<10} {'RMSE':<10} {'Dim':<8}")
            print('-'*70)

            for i, result in enumerate(sorted_results, 1):
                print(f"{i:<6} {result['extractor_name']:<25} "
                      f"{result.get(metric, 0):<15.3f} "
                      f"{result.get('r2_test', 0):<10.3f} "
                      f"{result.get('rmse_test', 0):<10.3f} "
                      f"{result.get('feature_dim', 0):<8}")

            # Best extractor
            if sorted_results:
                best = sorted_results[0]
                print(f"\nBest: {best['extractor_name']} ({metric}={best.get(metric, 0):.3f})")
