"""
YRSN Utility Functions and Helpers.

SECURITY: All RSN computation requires explicit configuration.
No hidden defaults for critical parameters (embed_dim, rsn_dim).

Key exports:
- RSNConfig: Explicit, validated configuration (REQUIRED)
- RSNPipeline: Secure R/S/N decomposition pipeline
- compute_rsn: One-shot R/S/N computation
- extract_features: Get embeddings from any model
- Data loading: load_cifar10, load_ood_datasets, load_yrsn_components
- Evaluation: CurriculumTester, compute_ood_metrics

Usage:
    from yrsn.utils import RSNConfig, RSNPipeline, compute_rsn
    from yrsn.utils import load_cifar10, load_yrsn_components
    from yrsn.utils import CurriculumTester, compute_ood_metrics
"""

from .models import SimpleCNN, get_feature_dim

# RSN Pipeline - SECURE way to compute R/S/N
from .rsn_pipeline import (
    # Configuration (required)
    RSNConfig,
    # Pipeline
    RSNPipeline,
    RSNResult,
    # Convenience
    compute_rsn,
    # Utilities
    get_embed_dim,
    extract_features,
)

# Data Loading - Standardized data and component loading
from .data_loading import (
    # Constants
    CIFAR10_MEAN,
    CIFAR10_STD,
    CURRICULUM_STAGES,
    # Transforms
    get_cifar10_transforms,
    get_raw_transform,
    # Dataset loading
    load_cifar10,
    load_ood_datasets,
    # Component loading
    load_yrsn_components,
    # Feature extraction
    extract_features_batch,
    extract_images_batch,
    # Curriculum testing
    test_curriculum_stages,
)

# Evaluation - Metrics and testing utilities
from .evaluation import (
    # Curriculum
    CurriculumStage,
    CurriculumTester,
    STANDARD_CURRICULUM,
    # OOD metrics
    OODMetrics,
    compute_ood_metrics,
    compute_detection_rates,
    # Calibration
    compute_calibration_error,
    # Bootstrap
    bootstrap_metric,
)

__all__ = [
    # Models
    'SimpleCNN',
    'get_feature_dim',
    # RSN Configuration (required)
    'RSNConfig',
    # RSN Pipeline
    'RSNPipeline',
    'RSNResult',
    'compute_rsn',
    # Utilities
    'get_embed_dim',
    'extract_features',
    # Data Loading
    'CIFAR10_MEAN',
    'CIFAR10_STD',
    'CURRICULUM_STAGES',
    'get_cifar10_transforms',
    'get_raw_transform',
    'load_cifar10',
    'load_ood_datasets',
    'load_yrsn_components',
    'extract_features_batch',
    'extract_images_batch',
    'test_curriculum_stages',
    # Evaluation
    'CurriculumStage',
    'CurriculumTester',
    'STANDARD_CURRICULUM',
    'OODMetrics',
    'compute_ood_metrics',
    'compute_detection_rates',
    'compute_calibration_error',
    'bootstrap_metric',
]
