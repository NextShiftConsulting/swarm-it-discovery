"""
YRSN Evaluation Utilities
=========================

Standardized evaluation functions for validating YRSN claims.

Usage:
    from yrsn.utils.evaluation import (
        CurriculumTester,
        compute_ood_metrics,
        compute_calibration_metrics,
    )
"""

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve, precision_recall_curve, auc
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass


# =============================================================================
# Curriculum Testing
# =============================================================================

@dataclass
class CurriculumStage:
    """Definition of a curriculum stage."""
    name: str
    alpha_min: float
    omega_min: float
    description: str = ""


# Standard curriculum stages based on _defaults.py thresholds
STANDARD_CURRICULUM = [
    CurriculumStage(
        name='Stage 1 (Strict)',
        alpha_min=0.70,  # ALPHA_HIGH_THRESHOLD
        omega_min=0.50,
        description='High quality, high reliability required'
    ),
    CurriculumStage(
        name='Stage 2 (Normal)',
        alpha_min=0.50,
        omega_min=0.40,
        description='Medium quality acceptable'
    ),
    CurriculumStage(
        name='Stage 3 (Lenient)',
        alpha_min=0.40,  # ALPHA_LOW_THRESHOLD
        omega_min=0.30,  # OMEGA_THRESHOLD
        description='Low quality allowed with caution'
    ),
]


class CurriculumTester:
    """
    Test RSN results against curriculum stages.

    Curriculum learning applies progressively looser thresholds
    to evaluate quality/reliability requirements.

    Usage:
        tester = CurriculumTester()

        # Test against standard curriculum
        results = tester.test(rsn_results)

        # Custom curriculum
        custom_stages = [
            CurriculumStage('Strict', alpha_min=0.8, omega_min=0.6),
            CurriculumStage('Normal', alpha_min=0.5, omega_min=0.4),
        ]
        results = tester.test(rsn_results, stages=custom_stages)
    """

    def __init__(self, stages: List[CurriculumStage] = None):
        """
        Initialize with curriculum stages.

        Args:
            stages: List of CurriculumStage (default: STANDARD_CURRICULUM)
        """
        self.stages = stages or STANDARD_CURRICULUM

    def test(
        self,
        rsn_results: Dict[str, np.ndarray],
        stages: List[CurriculumStage] = None,
    ) -> Dict[str, Dict]:
        """
        Test RSN results against curriculum stages.

        Args:
            rsn_results: Dict with 'alpha' and 'omega' arrays
            stages: Optional override of stages to test

        Returns:
            Dict mapping stage name to test results
        """
        stages = stages or self.stages
        alpha = rsn_results['alpha']
        omega = rsn_results['omega']

        results = {}
        for stage in stages:
            alpha_pass = alpha >= stage.alpha_min
            omega_pass = omega >= stage.omega_min
            combined_pass = alpha_pass & omega_pass

            results[stage.name] = {
                'alpha_pass_rate': float(alpha_pass.mean()),
                'omega_pass_rate': float(omega_pass.mean()),
                'pass_rate': float(combined_pass.mean()),
                'n_passed': int(combined_pass.sum()),
                'n_total': len(alpha),
                'thresholds': {
                    'alpha_min': stage.alpha_min,
                    'omega_min': stage.omega_min,
                },
                'description': stage.description,
            }

        return results

    def print_results(self, results: Dict[str, Dict]) -> None:
        """Pretty print curriculum test results."""
        print("\n" + "=" * 60)
        print("CURRICULUM TEST RESULTS")
        print("=" * 60)

        for stage_name, info in results.items():
            print(f"\n{stage_name}:")
            print(f"  Thresholds: alpha >= {info['thresholds']['alpha_min']}, "
                  f"omega >= {info['thresholds']['omega_min']}")
            print(f"  Alpha pass rate: {info['alpha_pass_rate']:.1%}")
            print(f"  Omega pass rate: {info['omega_pass_rate']:.1%}")
            print(f"  Combined pass:   {info['pass_rate']:.1%} "
                  f"({info['n_passed']}/{info['n_total']})")


# =============================================================================
# OOD Detection Metrics
# =============================================================================

@dataclass
class OODMetrics:
    """Container for OOD detection metrics."""
    auroc: float
    aupr: float
    fpr_at_95tpr: float
    threshold_at_95tpr: float


def compute_ood_metrics(
    id_scores: np.ndarray,
    ood_scores: np.ndarray,
) -> OODMetrics:
    """
    Compute OOD detection metrics.

    Higher scores should indicate in-distribution.

    Args:
        id_scores: Scores for in-distribution samples
        ood_scores: Scores for out-of-distribution samples

    Returns:
        OODMetrics with AUROC, AUPR, FPR@95TPR

    Example:
        >>> metrics = compute_ood_metrics(id_omega, ood_omega)
        >>> print(f"AUROC: {metrics.auroc:.4f}")
    """
    # Labels: 1 = ID (positive), 0 = OOD (negative)
    labels = np.concatenate([np.ones(len(id_scores)), np.zeros(len(ood_scores))])
    scores = np.concatenate([id_scores, ood_scores])

    # AUROC
    auroc = roc_auc_score(labels, scores)

    # AUPR
    precision, recall, _ = precision_recall_curve(labels, scores)
    aupr = auc(recall, precision)

    # FPR at 95% TPR
    fpr, tpr, thresholds = roc_curve(labels, scores)
    idx_95 = np.argmax(tpr >= 0.95)
    fpr_at_95tpr = fpr[idx_95]
    threshold_at_95tpr = thresholds[idx_95] if idx_95 < len(thresholds) else 0.0

    return OODMetrics(
        auroc=float(auroc),
        aupr=float(aupr),
        fpr_at_95tpr=float(fpr_at_95tpr),
        threshold_at_95tpr=float(threshold_at_95tpr),
    )


def compute_detection_rates(
    id_scores: np.ndarray,
    ood_scores: np.ndarray,
    thresholds: List[float] = None,
) -> Dict[float, Dict[str, float]]:
    """
    Compute ID/OOD detection rates at various thresholds.

    Args:
        id_scores: Scores for in-distribution samples (higher = more ID-like)
        ood_scores: Scores for out-of-distribution samples
        thresholds: List of thresholds to test (default: 0.3, 0.4, 0.5)

    Returns:
        Dict mapping threshold to {id_pass_rate, ood_reject_rate}
    """
    if thresholds is None:
        thresholds = [0.3, 0.4, 0.5]

    results = {}
    for thresh in thresholds:
        id_pass = (id_scores >= thresh).mean()
        ood_reject = (ood_scores < thresh).mean()
        results[thresh] = {
            'id_pass_rate': float(id_pass),
            'ood_reject_rate': float(ood_reject),
        }

    return results


# =============================================================================
# Calibration Metrics
# =============================================================================

def compute_calibration_error(
    confidences: np.ndarray,
    accuracies: np.ndarray,
    n_bins: int = 10,
) -> Dict[str, float]:
    """
    Compute calibration metrics (ECE, MCE).

    Args:
        confidences: Predicted confidence scores [0, 1]
        accuracies: Binary accuracy indicators (1 = correct)
        n_bins: Number of bins for calibration

    Returns:
        Dict with 'ece' (expected calibration error) and 'mce' (max calibration error)
    """
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    bin_lowers = bin_boundaries[:-1]
    bin_uppers = bin_boundaries[1:]

    ece = 0.0
    mce = 0.0

    for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
        in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
        prop_in_bin = in_bin.mean()

        if prop_in_bin > 0:
            avg_confidence = confidences[in_bin].mean()
            avg_accuracy = accuracies[in_bin].mean()
            bin_error = abs(avg_accuracy - avg_confidence)

            ece += prop_in_bin * bin_error
            mce = max(mce, bin_error)

    return {
        'ece': float(ece),
        'mce': float(mce),
    }


# =============================================================================
# Bootstrap Confidence Intervals
# =============================================================================

def bootstrap_metric(
    metric_fn,
    *arrays,
    n_bootstrap: int = 1000,
    ci: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float, float]:
    """
    Compute bootstrap confidence interval for a metric.

    Args:
        metric_fn: Function that computes metric from arrays
        *arrays: Input arrays (will be resampled together)
        n_bootstrap: Number of bootstrap iterations
        ci: Confidence interval (default 0.95)
        seed: Random seed

    Returns:
        (mean, ci_low, ci_high) tuple

    Example:
        >>> mean, low, high = bootstrap_metric(
        ...     lambda x, y: roc_auc_score(y, x),
        ...     scores, labels
        ... )
        >>> print(f"AUROC: {mean:.4f} [{low:.4f}, {high:.4f}]")
    """
    rng = np.random.default_rng(seed)
    n_samples = len(arrays[0])

    bootstrap_values = []
    for _ in range(n_bootstrap):
        indices = rng.choice(n_samples, size=n_samples, replace=True)
        resampled = [arr[indices] for arr in arrays]
        try:
            value = metric_fn(*resampled)
            bootstrap_values.append(value)
        except Exception:
            continue

    if not bootstrap_values:
        return 0.0, 0.0, 0.0

    bootstrap_values = np.array(bootstrap_values)
    mean = np.mean(bootstrap_values)
    alpha = (1 - ci) / 2
    ci_low = np.percentile(bootstrap_values, alpha * 100)
    ci_high = np.percentile(bootstrap_values, (1 - alpha) * 100)

    return float(mean), float(ci_low), float(ci_high)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Curriculum
    'CurriculumStage',
    'CurriculumTester',
    'STANDARD_CURRICULUM',

    # OOD metrics
    'OODMetrics',
    'compute_ood_metrics',
    'compute_detection_rates',

    # Calibration
    'compute_calibration_error',

    # Bootstrap
    'bootstrap_metric',
]
