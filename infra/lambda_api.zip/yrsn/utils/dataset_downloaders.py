"""
Dataset Downloader Utilities
=============================

Utilities to download conference-grade quality benchmarks.

Separation of Concerns:
- Downloaders: Fetch and prepare data files
- Adapters: Load and normalize data
- Core: Process data agnostic of source

Usage:
    from yrsn.utils.dataset_downloaders import download_asap_aes

    data_dir = download_asap_aes(output_dir='./data')
    dataset = ASAPAESDataset(data_dir)
"""

from pathlib import Path
from typing import Optional
import requests
import zipfile
import tarfile
import shutil


class DatasetDownloader:
    """Base class for dataset downloaders"""

    def __init__(self, output_dir: str = './data'):
        """
        Args:
            output_dir: Base directory for downloaded datasets
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def download_file(self, url: str, output_path: Path) -> Path:
        """
        Download file from URL.

        Args:
            url: URL to download from
            output_path: Path to save file

        Returns:
            Path to downloaded file
        """
        print(f"Downloading from {url}...")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print(f"Downloaded to {output_path}")
        return output_path

    def extract_zip(self, zip_path: Path, extract_to: Path) -> Path:
        """Extract ZIP archive"""
        print(f"Extracting {zip_path}...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        print(f"Extracted to {extract_to}")
        return extract_to

    def extract_tar(self, tar_path: Path, extract_to: Path) -> Path:
        """Extract TAR archive"""
        print(f"Extracting {tar_path}...")
        with tarfile.open(tar_path, 'r:*') as tar_ref:
            tar_ref.extractall(extract_to)
        print(f"Extracted to {extract_to}")
        return extract_to


def download_asap_aes(output_dir: str = './data') -> Path:
    """
    Download ASAP Automated Essay Scoring dataset.

    Note: Requires Kaggle API credentials.

    Setup:
        1. Install: pip install kaggle
        2. Get API key from https://www.kaggle.com/account
        3. Place kaggle.json in ~/.kaggle/ (or %USERPROFILE%/.kaggle on Windows)

    Args:
        output_dir: Directory to save dataset

    Returns:
        Path to dataset directory
    """
    downloader = DatasetDownloader(output_dir)
    dataset_dir = downloader.output_dir / 'asap-aes'

    # Check if already downloaded
    tsv_file = dataset_dir / 'training_set_rel3.tsv'
    if tsv_file.exists():
        print(f"ASAP-AES already downloaded at {dataset_dir}")
        return dataset_dir

    print("\n" + "="*70)
    print("Downloading ASAP-AES Dataset")
    print("="*70)

    try:
        import kaggle

        # Download using Kaggle API
        print("Using Kaggle API to download...")
        kaggle.api.competition_download_files(
            'asap-aes',
            path=str(dataset_dir)
        )

        # Extract
        zip_path = dataset_dir / 'asap-aes.zip'
        if zip_path.exists():
            downloader.extract_zip(zip_path, dataset_dir)
            zip_path.unlink()  # Remove zip after extraction

        print(f"\n[OK] ASAP-AES downloaded to {dataset_dir}")
        return dataset_dir

    except ImportError:
        print("[ERROR] Kaggle API not installed.")
        print("Install with: pip install kaggle")
        print("\nAlternative: Manual download")
        print("1. Go to: https://www.kaggle.com/c/asap-aes/data")
        print("2. Download training_set_rel3.tsv")
        print(f"3. Place in: {dataset_dir}")
        raise

    except Exception as e:
        print(f"[ERROR] Failed to download: {e}")
        print("\nManual download instructions:")
        print("1. Go to: https://www.kaggle.com/c/asap-aes/data")
        print("2. Download training_set_rel3.tsv")
        print(f"3. Place in: {dataset_dir}")
        raise


def download_ibm_debater(output_dir: str = './data') -> Path:
    """
    Download IBM Debater Argument Quality dataset.

    Note: Manual download required (no direct API).

    Args:
        output_dir: Directory to save dataset

    Returns:
        Path to dataset directory
    """
    downloader = DatasetDownloader(output_dir)
    dataset_dir = downloader.output_dir / 'ibm-debater'

    print("\n" + "="*70)
    print("IBM Debater Argument Quality Dataset")
    print("="*70)

    # Check if already downloaded
    csv_file = dataset_dir / 'arg_quality_rank_30k.csv'
    if csv_file.exists():
        print(f"[OK] IBM Debater already downloaded at {dataset_dir}")
        return dataset_dir

    print("\n[MANUAL DOWNLOAD REQUIRED]")
    print("\nSteps:")
    print("1. Visit: https://research.ibm.com/haifa/dept/vst/debating_data.shtml")
    print("2. Find 'Argument Quality' dataset")
    print("3. Download arg_quality_rank_30k.csv")
    print(f"4. Place in: {dataset_dir}")
    print("\nOnce downloaded, run this script again.")

    dataset_dir.mkdir(parents=True, exist_ok=True)

    raise FileNotFoundError(
        f"IBM Debater data not found. Please download manually to {dataset_dir}"
    )


def download_gcdc(output_dir: str = './data') -> Path:
    """
    Download GCDC (Grammarly Corpus of Discourse Coherence).

    Source: GitHub repository

    Args:
        output_dir: Directory to save dataset

    Returns:
        Path to dataset directory
    """
    downloader = DatasetDownloader(output_dir)
    dataset_dir = downloader.output_dir / 'gcdc'

    print("\n" + "="*70)
    print("Downloading GCDC Dataset")
    print("="*70)

    # Check if already downloaded
    if (dataset_dir / 'Clinton').exists():
        print(f"[OK] GCDC already downloaded at {dataset_dir}")
        return dataset_dir

    # GitHub repo URL
    repo_url = "https://github.com/aylai/GCDC-corpus/archive/refs/heads/master.zip"

    try:
        # Download
        zip_path = dataset_dir / 'gcdc.zip'
        downloader.download_file(repo_url, zip_path)

        # Extract
        downloader.extract_zip(zip_path, dataset_dir)

        # Move files from extracted folder to dataset_dir
        extracted_dir = dataset_dir / 'GCDC-corpus-master'
        if extracted_dir.exists():
            for item in extracted_dir.iterdir():
                shutil.move(str(item), str(dataset_dir))
            extracted_dir.rmdir()

        zip_path.unlink()  # Remove zip

        print(f"\n[OK] GCDC downloaded to {dataset_dir}")
        return dataset_dir

    except Exception as e:
        print(f"[ERROR] Failed to download: {e}")
        print("\nManual download instructions:")
        print("1. Go to: https://github.com/aylai/GCDC-corpus")
        print("2. Download repository")
        print(f"3. Extract to: {dataset_dir}")
        raise


def download_commonlit(output_dir: str = './data') -> Path:
    """
    Download CommonLit Readability dataset.

    Note: Requires Kaggle API credentials (same as ASAP-AES).

    Args:
        output_dir: Directory to save dataset

    Returns:
        Path to dataset directory
    """
    downloader = DatasetDownloader(output_dir)
    dataset_dir = downloader.output_dir / 'commonlit'

    # Check if already downloaded
    csv_file = dataset_dir / 'train.csv'
    if csv_file.exists():
        print(f"[OK] CommonLit already downloaded at {dataset_dir}")
        return dataset_dir

    print("\n" + "="*70)
    print("Downloading CommonLit Dataset")
    print("="*70)

    try:
        import kaggle

        # Download using Kaggle API
        print("Using Kaggle API to download...")
        kaggle.api.competition_download_files(
            'commonlitreadabilityprize',
            path=str(dataset_dir)
        )

        # Extract
        zip_path = dataset_dir / 'commonlitreadabilityprize.zip'
        if zip_path.exists():
            downloader.extract_zip(zip_path, dataset_dir)
            zip_path.unlink()

        print(f"\n[OK] CommonLit downloaded to {dataset_dir}")
        return dataset_dir

    except ImportError:
        print("[ERROR] Kaggle API not installed.")
        print("Install with: pip install kaggle")
        print("\nAlternative: Manual download")
        print("1. Go to: https://www.kaggle.com/c/commonlitreadabilityprize/data")
        print("2. Download train.csv")
        print(f"3. Place in: {dataset_dir}")
        raise

    except Exception as e:
        print(f"[ERROR] Failed to download: {e}")
        print("\nManual download instructions:")
        print("1. Go to: https://www.kaggle.com/c/commonlitreadabilityprize/data")
        print("2. Download train.csv")
        print(f"3. Place in: {dataset_dir}")
        raise


def download_all_datasets(output_dir: str = './data'):
    """
    Download all quality benchmark datasets.

    Args:
        output_dir: Base directory for all datasets
    """
    print("\n" + "="*70)
    print("Downloading All Quality Benchmark Datasets")
    print("="*70)

    datasets = [
        ("ASAP-AES", download_asap_aes),
        ("CommonLit", download_commonlit),
        ("GCDC", download_gcdc),
        ("IBM Debater", download_ibm_debater),
    ]

    results = {}

    for name, download_func in datasets:
        try:
            path = download_func(output_dir)
            results[name] = {'status': 'SUCCESS', 'path': str(path)}
        except Exception as e:
            results[name] = {'status': 'FAILED', 'error': str(e)}

    # Summary
    print("\n" + "="*70)
    print("Download Summary")
    print("="*70)

    for name, result in results.items():
        status = result['status']
        if status == 'SUCCESS':
            print(f"[OK] {name}: {result['path']}")
        else:
            print(f"[FAIL] {name}: {result['error']}")

    return results


# Standalone script functionality
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Download quality benchmark datasets")
    parser.add_argument('--output-dir', default='./data', help='Output directory')
    parser.add_argument('--dataset', choices=['asap', 'commonlit', 'gcdc', 'ibm', 'all'],
                       default='all', help='Dataset to download')

    args = parser.parse_args()

    if args.dataset == 'asap':
        download_asap_aes(args.output_dir)
    elif args.dataset == 'commonlit':
        download_commonlit(args.output_dir)
    elif args.dataset == 'gcdc':
        download_gcdc(args.output_dir)
    elif args.dataset == 'ibm':
        download_ibm_debater(args.output_dir)
    else:
        download_all_datasets(args.output_dir)
