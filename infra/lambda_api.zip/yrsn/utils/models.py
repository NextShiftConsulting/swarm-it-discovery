"""
Standard model definitions for YRSN experiments.

CRITICAL: YRSN decomposes SEMANTIC EMBEDDINGS, not class logits!
Always use return_features=True or get_features() when computing R/S/N.

Example:
    from yrsn.utils.models import SimpleCNN
    
    model = SimpleCNN()
    
    # For classification:
    logits = model(x)  # [B, 10]
    
    # For YRSN decomposition:
    features = model(x, return_features=True)  # [B, 64]
    
    # Config must match feature_dim:
    config = YRSNMemristorConfig(embed_dim=model.feature_dim)  # 64
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class SimpleCNN(nn.Module):
    """
    Simple CNN for CIFAR-10 experiments with YRSN-compatible feature extraction.
    
    Attributes:
        feature_dim: Dimension of intermediate features (64). Use this for YRSN embed_dim.
        
    Example:
        model = SimpleCNN()
        features = model(x, return_features=True)  # [B, 64] for YRSN
        config = YRSNMemristorConfig(embed_dim=model.feature_dim)
    """

    def __init__(self, num_classes: int = 10):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, num_classes)

        # Feature dimension for YRSN - MUST match embed_dim in YRSNMemristorConfig
        self.feature_dim = 64

    def forward(self, x: torch.Tensor, return_features: bool = False) -> torch.Tensor:
        """
        Forward pass with optional feature extraction.
        
        Args:
            x: Input tensor [B, 3, 32, 32]
            return_features: If True, return [B, 64] features instead of [B, 10] logits
            
        Returns:
            features [B, 64] if return_features else logits [B, num_classes]
        """
        x = F.relu(self.conv1(x))
        x = self.pool(F.relu(self.conv2(x)))
        features = x.view(x.size(0), -1)  # [B, 64]
        
        if return_features:
            return features
        
        return self.fc(features)

    def get_features(self, x: torch.Tensor) -> torch.Tensor:
        """Extract intermediate features. Alias for forward(x, return_features=True)."""
        return self.forward(x, return_features=True)


def get_feature_dim(model: nn.Module) -> int:
    """
    Get the feature dimension for a model (for YRSN embed_dim).
    
    Args:
        model: PyTorch model
        
    Returns:
        Feature dimension (e.g., 64 for SimpleCNN, 512 for ResNet18)
    """
    if hasattr(model, 'feature_dim'):
        return model.feature_dim
    
    # Infer from fc layer
    if hasattr(model, 'fc'):
        return model.fc.in_features
    
    raise ValueError("Cannot determine feature dimension")
