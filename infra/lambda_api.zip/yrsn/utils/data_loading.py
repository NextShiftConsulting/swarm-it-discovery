"""
YRSN Data Loading Utilities
============================

Standardized data loading, feature extraction, and component loading
to eliminate duplication across experiments.

Usage:
    from yrsn.utils.data_loading import (
        load_cifar10,
        load_ood_datasets,
        load_yrsn_components,
        extract_features_batch,
    )

    # Load data
    train_loader, test_loader = load_cifar10(batch_size=128)
    ood_loaders = load_ood_datasets(['svhn', 'cifar100'])

    # Load model + projection
    model, projection = load_yrsn_components(device='cuda')

    # Extract features
    features, labels = extract_features_batch(model, test_loader, n_samples=1000)
"""

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms
from typing import Dict, List, Tuple, Optional, Union
from pathlib import Path

# CIFAR-10 normalization constants
CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD = (0.2023, 0.1994, 0.2010)

# Standard paths
DEFAULT_DATA_ROOT = './data'
DEFAULT_CHECKPOINT_DIR = 'checkpoints'


# =============================================================================
# Dataset Loading
# =============================================================================

def get_cifar10_transforms(train: bool = True) -> transforms.Compose:
    """Get standard CIFAR-10 transforms."""
    if train:
        return transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
        ])
    else:
        return transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
        ])


def get_raw_transform() -> transforms.Compose:
    """Get transform that returns raw [0,1] tensor (no normalization)."""
    return transforms.Compose([transforms.ToTensor()])


def load_cifar10(
    batch_size: int = 128,
    data_root: str = DEFAULT_DATA_ROOT,
    num_workers: int = 0,
    download: bool = True,
) -> Tuple[DataLoader, DataLoader]:
    """
    Load CIFAR-10 train and test loaders with standard transforms.

    Args:
        batch_size: Batch size for loaders
        data_root: Root directory for data
        num_workers: Number of data loading workers
        download: Whether to download if not present

    Returns:
        (train_loader, test_loader) tuple
    """
    train_dataset = datasets.CIFAR10(
        root=data_root, train=True, download=download,
        transform=get_cifar10_transforms(train=True)
    )
    test_dataset = datasets.CIFAR10(
        root=data_root, train=False, download=download,
        transform=get_cifar10_transforms(train=False)
    )

    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers
    )
    test_loader = DataLoader(
        test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )

    return train_loader, test_loader


def load_ood_datasets(
    ood_names: List[str],
    batch_size: int = 128,
    data_root: str = DEFAULT_DATA_ROOT,
    num_workers: int = 0,
    download: bool = True,
) -> Dict[str, DataLoader]:
    """
    Load OOD dataset loaders for evaluation.

    Args:
        ood_names: List of OOD dataset names ('svhn', 'cifar100', 'mnist')
        batch_size: Batch size for loaders
        data_root: Root directory for data
        num_workers: Number of data loading workers
        download: Whether to download if not present

    Returns:
        Dict mapping dataset name to DataLoader

    Example:
        >>> loaders = load_ood_datasets(['svhn', 'cifar100'])
        >>> for name, loader in loaders.items():
        ...     print(f"{name}: {len(loader.dataset)} samples")
    """
    # Use CIFAR-10 test transform for all (32x32, normalized)
    transform = get_cifar10_transforms(train=False)

    loaders = {}

    for name in ood_names:
        name_lower = name.lower()

        if name_lower == 'svhn':
            dataset = datasets.SVHN(
                root=data_root, split='test', download=download, transform=transform
            )
        elif name_lower == 'cifar100':
            dataset = datasets.CIFAR100(
                root=data_root, train=False, download=download, transform=transform
            )
        elif name_lower == 'mnist':
            # MNIST needs resize and channel expansion
            mnist_transform = transforms.Compose([
                transforms.Resize(32),
                transforms.Grayscale(num_output_channels=3),
                transforms.ToTensor(),
                transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
            ])
            dataset = datasets.MNIST(
                root=data_root, train=False, download=download, transform=mnist_transform
            )
        elif name_lower == 'fashionmnist':
            mnist_transform = transforms.Compose([
                transforms.Resize(32),
                transforms.Grayscale(num_output_channels=3),
                transforms.ToTensor(),
                transforms.Normalize(CIFAR10_MEAN, CIFAR10_STD),
            ])
            dataset = datasets.FashionMNIST(
                root=data_root, train=False, download=download, transform=mnist_transform
            )
        else:
            raise ValueError(f"Unknown OOD dataset: {name}. "
                           f"Supported: svhn, cifar100, mnist, fashionmnist")

        loaders[name] = DataLoader(
            dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers
        )

    return loaders


# =============================================================================
# Component Loading
# =============================================================================

def load_yrsn_components(
    model_name: str = 'resnet20',
    projection_checkpoint: str = 'checkpoints/trained_rsn_cifar64.pt',
    model_checkpoint: Optional[str] = None,
    device: str = 'cpu',
) -> Tuple[nn.Module, 'TrainedRSNProjection']:
    """
    Load model and projection components for YRSN experiments.

    Args:
        model_name: Model architecture ('resnet20', 'resnet18', etc.)
        projection_checkpoint: Path to trained RSN projection checkpoint
        model_checkpoint: Optional path to model weights (uses pretrained if None)
        device: Target device

    Returns:
        (model, projection) tuple

    Example:
        >>> model, projection = load_yrsn_components(device='cuda')
        >>> features = model(images, return_features=True)
        >>> rsn = projection.compute_rsn_batch(features.numpy())
    """
    from yrsn.core.decomposition import TrainedRSNProjection

    # Load model
    if model_name == 'resnet20':
        from yrsn.models.resnet_cifar import resnet20_cifar10
        model = resnet20_cifar10(pretrained=True, device=device)
    elif model_name == 'resnet18':
        from torchvision.models import resnet18
        model = resnet18(pretrained=True)
        model = model.to(device)
    else:
        raise ValueError(f"Unknown model: {model_name}. Supported: resnet20, resnet18")

    # Load custom model weights if provided
    if model_checkpoint and Path(model_checkpoint).exists():
        state = torch.load(model_checkpoint, map_location=device, weights_only=True)
        if 'model_state_dict' in state:
            model.load_state_dict(state['model_state_dict'])
        else:
            model.load_state_dict(state)

    model.eval()

    # Load projection
    projection = TrainedRSNProjection.from_checkpoint(
        projection_checkpoint, device=device
    )

    return model, projection


# =============================================================================
# Feature Extraction
# =============================================================================

def extract_features_batch(
    model: nn.Module,
    loader: DataLoader,
    n_samples: Optional[int] = None,
    device: str = 'cpu',
    return_images: bool = False,
    normalize: bool = True,
) -> Union[Tuple[np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray, List]]:
    """
    Extract features from a data loader using the model.

    Args:
        model: PyTorch model with return_features=True support
        loader: DataLoader to extract from
        n_samples: Max samples to extract (None = all)
        device: Target device
        return_images: Whether to also return raw images
        normalize: Whether input is already normalized

    Returns:
        If return_images=False: (features, labels) tuple
        If return_images=True: (features, labels, images) tuple

    Example:
        >>> features, labels = extract_features_batch(model, test_loader, n_samples=1000)
        >>> print(f"Features shape: {features.shape}")
    """
    model.eval()
    model = model.to(device)

    features_list = []
    labels_list = []
    images_list = [] if return_images else None

    total = 0
    with torch.no_grad():
        for batch_imgs, batch_labels in loader:
            batch_imgs = batch_imgs.to(device)

            # Extract features
            if hasattr(model, 'forward'):
                try:
                    feats = model(batch_imgs, return_features=True)
                except TypeError:
                    # Model doesn't support return_features, use hook
                    feats = _extract_with_hook(model, batch_imgs)
            else:
                feats = model(batch_imgs)

            features_list.append(feats.cpu().numpy())
            labels_list.append(batch_labels.numpy())

            if return_images:
                images_list.extend([img.cpu() for img in batch_imgs])

            total += len(batch_labels)
            if n_samples and total >= n_samples:
                break

    features = np.concatenate(features_list, axis=0)
    labels = np.concatenate(labels_list, axis=0)

    if n_samples:
        features = features[:n_samples]
        labels = labels[:n_samples]
        if return_images:
            images_list = images_list[:n_samples]

    if return_images:
        return features, labels, images_list
    return features, labels


def _extract_with_hook(model: nn.Module, data: torch.Tensor) -> torch.Tensor:
    """Extract features using forward hook (fallback method)."""
    features = None

    def hook(module, input, output):
        nonlocal features
        if isinstance(input, tuple):
            features = input[0]
        else:
            features = input

    # Find last linear layer and hook before it
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            handle = module.register_forward_pre_hook(hook)
            _ = model(data)
            handle.remove()
            if features is not None:
                return features

    raise ValueError("Could not extract features - model has no Linear layer")


def extract_images_batch(
    loader: DataLoader,
    n_samples: int,
    device: str = 'cpu',
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Extract raw images and labels from a loader.

    Args:
        loader: DataLoader to extract from
        n_samples: Number of samples to extract
        device: Target device

    Returns:
        (images, labels) tuple as tensors
    """
    images = []
    labels = []

    for batch_imgs, batch_labels in loader:
        images.append(batch_imgs)
        labels.append(batch_labels)
        if sum(len(b) for b in images) >= n_samples:
            break

    images = torch.cat(images)[:n_samples].to(device)
    labels = torch.cat(labels)[:n_samples]

    return images, labels


# =============================================================================
# Curriculum/Threshold Testing
# =============================================================================

# Standard curriculum stages (from _defaults.py thresholds)
CURRICULUM_STAGES = [
    {'name': 'Stage 1 (Strict)', 'alpha_min': 0.70, 'omega_min': 0.50},
    {'name': 'Stage 2 (Normal)', 'alpha_min': 0.50, 'omega_min': 0.40},
    {'name': 'Stage 3 (Lenient)', 'alpha_min': 0.40, 'omega_min': 0.30},
]


def test_curriculum_stages(
    rsn_results: Dict[str, np.ndarray],
    stages: List[Dict] = None,
) -> Dict[str, Dict]:
    """
    Test RSN results against curriculum stages.

    Args:
        rsn_results: Dict with 'alpha' and 'omega' arrays
        stages: List of stage dicts with 'name', 'alpha_min', 'omega_min'

    Returns:
        Dict mapping stage name to pass rates

    Example:
        >>> rsn = projection.compute_rsn_batch(features)
        >>> results = test_curriculum_stages(rsn)
        >>> for stage, info in results.items():
        ...     print(f"{stage}: {info['pass_rate']:.1%}")
    """
    if stages is None:
        stages = CURRICULUM_STAGES

    alpha = rsn_results['alpha']
    omega = rsn_results['omega']

    results = {}
    for stage in stages:
        alpha_pass = alpha >= stage['alpha_min']
        omega_pass = omega >= stage['omega_min']
        combined_pass = alpha_pass & omega_pass

        results[stage['name']] = {
            'alpha_pass_rate': float(alpha_pass.mean()),
            'omega_pass_rate': float(omega_pass.mean()),
            'pass_rate': float(combined_pass.mean()),
            'thresholds': {
                'alpha_min': stage['alpha_min'],
                'omega_min': stage['omega_min'],
            }
        }

    return results


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Constants
    'CIFAR10_MEAN',
    'CIFAR10_STD',
    'CURRICULUM_STAGES',

    # Transforms
    'get_cifar10_transforms',
    'get_raw_transform',

    # Dataset loading
    'load_cifar10',
    'load_ood_datasets',

    # Component loading
    'load_yrsn_components',

    # Feature extraction
    'extract_features_batch',
    'extract_images_batch',

    # Curriculum testing
    'test_curriculum_stages',
]
