"""
YRSN R/S/N Pipeline - Secure, validated feature extraction and decomposition.

SECURITY PRINCIPLES:
- Explicit > Implicit: No hidden defaults for critical params
- Fail Fast: Validate dimensions early, raise clear errors
- No Magic: All configuration must be explicitly specified

WRONG (causes R=S=N=0.333):
    output = model(data)  # Gets logits (10-dim), not embeddings!
    projection.forward(output)  # Dimension mismatch → uniform output

RIGHT (this module):
    from yrsn.utils import RSNConfig, RSNPipeline
    
    # Explicit configuration (secure)
    config = RSNConfig(embed_dim=64, rsn_dim=128)
    pipeline = RSNPipeline(model, config)
    result = pipeline(data)
    
    # Or with auto-detection (opt-in, with confirmation)
    config = RSNConfig.from_model(model, rsn_dim=128)
    print(f"Detected: {config}")  # Always confirm what was detected!
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Union, Any, Tuple
from dataclasses import dataclass
import warnings


# =============================================================================
# Configuration (Secure, Validated)
# =============================================================================

@dataclass
class RSNConfig:
    """
    Explicit, validated RSN configuration.
    
    SECURITY: No hidden defaults for critical parameters.
    All dimensions must be explicitly specified.
    
    Args:
        embed_dim: Input embedding dimension (REQUIRED)
        rsn_dim: R/S/N projection dimension (REQUIRED)
        device: Target device ('cuda', 'cpu', 'auto')
        validate_features: If True, raise error on dimension mismatch
        
    Example:
        # Explicit (recommended)
        config = RSNConfig(embed_dim=64, rsn_dim=128)
        
        # From model (opt-in auto-detection)
        config = RSNConfig.from_model(model, rsn_dim=128)
    """
    embed_dim: int
    rsn_dim: int
    device: str = 'auto'
    validate_features: bool = True
    
    def __post_init__(self):
        """Validate configuration at construction time."""
        # Validate embed_dim
        if not isinstance(self.embed_dim, int) or self.embed_dim <= 0:
            raise ValueError(
                f"embed_dim must be a positive integer, got {self.embed_dim} ({type(self.embed_dim).__name__})"
            )
        
        # Validate rsn_dim
        if not isinstance(self.rsn_dim, int) or self.rsn_dim <= 0:
            raise ValueError(
                f"rsn_dim must be a positive integer, got {self.rsn_dim} ({type(self.rsn_dim).__name__})"
            )
        
        # Sanity check: rsn_dim shouldn't be excessively large
        if self.rsn_dim > self.embed_dim * 4:
            warnings.warn(
                f"rsn_dim ({self.rsn_dim}) is >4x embed_dim ({self.embed_dim}). "
                "This may be intentional but is unusual.",
                UserWarning
            )
        
        # Validate device
        valid_devices = {'auto', 'cuda', 'cpu', 'mps'}
        if self.device not in valid_devices and not self.device.startswith('cuda:'):
            raise ValueError(
                f"device must be one of {valid_devices} or 'cuda:N', got '{self.device}'"
            )
    
    @classmethod
    def from_model(
        cls,
        model: nn.Module,
        rsn_dim: int,
        device: str = 'auto',
        validate_features: bool = True,
        quiet: bool = False,
    ) -> 'RSNConfig':
        """
        Create config by detecting embed_dim from model.
        
        SECURITY: This is opt-in auto-detection. Always print/log
        the detected value to confirm it's correct.
        
        Args:
            model: PyTorch model to analyze
            rsn_dim: R/S/N projection dimension (REQUIRED - no default!)
            device: Target device
            validate_features: If True, validate feature dimensions at runtime
            quiet: If False (default), print detected embed_dim
            
        Returns:
            RSNConfig with detected embed_dim
            
        Raises:
            ValueError: If embed_dim cannot be detected
        """
        embed_dim = get_embed_dim(model)
        
        if not quiet:
            print(f"[RSNConfig] Detected embed_dim={embed_dim} from {type(model).__name__}")
        
        return cls(
            embed_dim=embed_dim,
            rsn_dim=rsn_dim,
            device=device,
            validate_features=validate_features,
        )
    
    def get_device(self) -> torch.device:
        """Resolve 'auto' to actual device."""
        if self.device == 'auto':
            return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        return torch.device(self.device)
    
    def __str__(self) -> str:
        return f"RSNConfig(embed_dim={self.embed_dim}, rsn_dim={self.rsn_dim}, device='{self.device}')"


# =============================================================================
# Result Container
# =============================================================================

@dataclass
class RSNResult:
    """Result of R/S/N decomposition."""
    R: torch.Tensor  # Relevant score [batch] or scalar
    S: torch.Tensor  # Superfluous score
    N: torch.Tensor  # Noise score
    alpha: torch.Tensor  # Quality metric (= R)
    omega: torch.Tensor  # Reliability metric
    tau: torch.Tensor  # Temperature (= 1/alpha_omega)
    features: torch.Tensor  # Extracted features [batch, embed_dim]
    config: RSNConfig  # Configuration used (for transparency)
    
    @property
    def embed_dim(self) -> int:
        """Embedding dimension used."""
        return self.config.embed_dim
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (for JSON serialization)."""
        def to_float(t: torch.Tensor) -> float:
            t = t.detach()
            return float(t.mean()) if t.numel() > 1 else float(t)
        
        return {
            'R': to_float(self.R),
            'S': to_float(self.S),
            'N': to_float(self.N),
            'alpha': to_float(self.alpha),
            'omega': to_float(self.omega),
            'tau': to_float(self.tau),
            'embed_dim': self.config.embed_dim,
            'rsn_dim': self.config.rsn_dim,
        }


def get_embed_dim(model: nn.Module) -> int:
    """
    Get the embedding dimension for a model's intermediate features.
    
    Returns the dimension of features BEFORE the classification layer.
    This is what YRSN should decompose - not the final class logits.
    
    Supported architectures:
    - SimpleCNN (conv2 → 64-dim)
    - ResNet (avgpool → 512-dim for ResNet18)
    - Any model with .feature_dim attribute
    - Any model with .fc layer (uses fc.in_features)
    
    Args:
        model: PyTorch model
        
    Returns:
        int: Embedding dimension
        
    Raises:
        ValueError: If cannot determine embedding dimension
    """
    # Check for explicit feature_dim attribute
    if hasattr(model, 'feature_dim'):
        return model.feature_dim
    
    # SimpleCNN pattern: conv2 → pool → fc
    if hasattr(model, 'conv2'):
        return model.conv2.out_channels
    
    # ResNet pattern: layer4 → avgpool → fc
    if hasattr(model, 'fc') and hasattr(model.fc, 'in_features'):
        return model.fc.in_features
    
    # Try to find last linear layer
    for module in reversed(list(model.modules())):
        if isinstance(module, nn.Linear):
            return module.in_features
    
    raise ValueError(
        f"Cannot determine embedding dimension for {type(model).__name__}. "
        "Add a .feature_dim attribute to your model or use a supported architecture."
    )


def extract_features(
    model: nn.Module,
    data: torch.Tensor,
    device: Optional[torch.device] = None,
) -> torch.Tensor:
    """
    Extract intermediate features from model (BEFORE classification layer).
    
    WHY NOT USE FINAL OUTPUT?
    - Final output is class logits (e.g., 10-dim for CIFAR-10)
    - This is just the decision, not a semantic embedding
    - YRSN needs rich embeddings to decompose into R/S/N
    
    Args:
        model: PyTorch model
        data: Input tensor [B, C, H, W] for images or [B, seq_len, dim] for sequences
        device: Target device (default: model's device)
        
    Returns:
        features: [B, embed_dim] intermediate features
    """
    if device is None:
        device = next(model.parameters()).device
    
    data = data.to(device)
    model.eval()
    
    with torch.no_grad():
        # Check for return_features method
        if hasattr(model, 'forward') and 'return_features' in model.forward.__code__.co_varnames:
            return model(data, return_features=True)
        
        # SimpleCNN pattern: conv1 → conv2 → pool → (features) → fc
        if hasattr(model, 'conv1') and hasattr(model, 'conv2') and hasattr(model, 'pool'):
            x = data
            if hasattr(model, 'bn1'):
                x = F.relu(model.bn1(model.conv1(x)))
            else:
                x = F.relu(model.conv1(x))
            
            if hasattr(model, 'bn2'):
                x = model.pool(F.relu(model.bn2(model.conv2(x))))
            else:
                x = model.pool(F.relu(model.conv2(x)))
            
            # Handle additional conv layers if present
            if hasattr(model, 'conv3'):
                if hasattr(model, 'bn3'):
                    x = F.relu(model.bn3(model.conv3(x)))
                else:
                    x = F.relu(model.conv3(x))
                if hasattr(model, 'pool'):
                    x = model.pool(x)
            
            features = x.view(x.size(0), -1)
            return features
        
        # ResNet pattern: conv1 → bn1 → relu → maxpool → layers → avgpool → (features) → fc
        if hasattr(model, 'avgpool') and hasattr(model, 'layer4'):
            x = model.conv1(data)
            x = model.bn1(x)
            x = model.relu(x)
            x = model.maxpool(x)
            x = model.layer1(x)
            x = model.layer2(x)
            x = model.layer3(x)
            x = model.layer4(x)
            x = model.avgpool(x)
            features = torch.flatten(x, 1)
            return features
        
        # Fallback: try to use hooks to capture features before fc
        features = None
        
        def hook(module, input, output):
            nonlocal features
            if isinstance(input, tuple):
                features = input[0]
            else:
                features = input
        
        # Find fc layer and register hook
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                handle = module.register_forward_pre_hook(hook)
                _ = model(data)
                handle.remove()
                if features is not None:
                    return features
        
        raise ValueError(
            f"Cannot extract features from {type(model).__name__}. "
            "Supported: SimpleCNN, ResNet, or models with return_features=True in forward()."
        )


class RSNPipeline:
    """
    Secure R/S/N decomposition pipeline with explicit configuration.
    
    SECURITY: Requires explicit RSNConfig - no hidden defaults.
    
    Usage:
        # Explicit config (recommended)
        config = RSNConfig(embed_dim=64, rsn_dim=128)
        pipeline = RSNPipeline(model, config)
        result = pipeline(data)
        
        # With auto-detection (opt-in)
        config = RSNConfig.from_model(model, rsn_dim=128)
        pipeline = RSNPipeline(model, config)
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: RSNConfig,
        trained_projection_path: Optional[str] = None,
    ):
        """
        Initialize RSN pipeline with explicit configuration.
        
        Args:
            model: PyTorch model for feature extraction
            config: RSNConfig with embed_dim, rsn_dim, device (REQUIRED)
            trained_projection_path: Optional path to trained projection checkpoint
            
        Raises:
            TypeError: If config is not RSNConfig
            ValueError: If configuration is invalid
        """
        # Validate config type
        if not isinstance(config, RSNConfig):
            raise TypeError(
                f"config must be RSNConfig, got {type(config).__name__}. "
                "Use: config = RSNConfig(embed_dim=64, rsn_dim=128)"
            )
        
        self.config = config
        self.device = config.get_device()
        
        # Model setup
        self.model = model.to(self.device)
        self.model.eval()
        
        # Store dimensions explicitly
        self.embed_dim = config.embed_dim
        self.rsn_dim = config.rsn_dim
        
        # Validate model produces expected embed_dim
        detected_dim = get_embed_dim(model)
        if detected_dim != config.embed_dim:
            raise ValueError(
                f"DIMENSION MISMATCH: config.embed_dim={config.embed_dim} but "
                f"model produces {detected_dim}-dim features. "
                f"Fix: Use RSNConfig(embed_dim={detected_dim}, rsn_dim={config.rsn_dim})"
            )
        
        # Create projection with validated dimensions
        from yrsn.hardware import create_projection
        
        self.projection = create_projection(
            embed_dim=config.embed_dim,
            rsn_dim=config.rsn_dim,
            device=self.device,
        )
        
        # Load trained projection if provided
        if trained_projection_path:
            self._load_trained_projection(trained_projection_path)
        
        # Log configuration for transparency
        print(f"[RSNPipeline] Initialized: {config}")
    
    def _load_trained_projection(self, path: str) -> None:
        """Load trained projection weights."""
        import os
        if os.path.exists(path):
            checkpoint = torch.load(path, map_location=self.device)
            # Handle different checkpoint formats
            if 'projection_heads' in checkpoint:
                # TrainedRSNProjection format
                state = checkpoint['projection_heads']
                # Map to our projection arrays
                # This is a simplified mapping - may need adjustment
                pass
            print(f"[RSNPipeline] Loaded trained projection from {path}")
        else:
            raise FileNotFoundError(f"Trained projection not found: {path}")
    
    def __call__(
        self,
        data: torch.Tensor,
        return_features: bool = False,
    ) -> RSNResult:
        """
        Compute R/S/N decomposition with validation.
        
        Args:
            data: Input tensor [B, C, H, W] for images
            return_features: If True, include raw features in result
            
        Returns:
            RSNResult with R, S, N scores and metadata
            
        Raises:
            ValueError: If extracted features don't match config.embed_dim
        """
        # Extract features
        features = extract_features(self.model, data, self.device)
        
        # Validate feature dimensions (fail fast)
        if self.config.validate_features:
            actual_dim = features.shape[-1]
            if actual_dim != self.config.embed_dim:
                raise ValueError(
                    f"FEATURE DIMENSION MISMATCH: Expected {self.config.embed_dim}, "
                    f"got {actual_dim}. This indicates a bug in feature extraction "
                    f"or incorrect config.embed_dim."
                )
        
        # Project to R/S/N
        result = self.projection(features)
        
        return RSNResult(
            R=result['R'],
            S=result['S'],
            N=result['N'],
            alpha=result['alpha'],
            omega=result.get('omega', result['alpha']),  # Fallback if no omega
            tau=result['tau'],
            features=features if return_features else features.new_empty(0),
            config=self.config,
        )
    
    def compute_rsn(self, data: torch.Tensor) -> Dict[str, float]:
        """
        Compute R/S/N and return as simple dict (convenience method).
        
        Args:
            data: Input tensor
            
        Returns:
            Dict with R, S, N, alpha, omega, tau, embed_dim, rsn_dim
        """
        result = self(data)
        return result.to_dict()


def compute_rsn(
    model: nn.Module,
    data: torch.Tensor,
    config: Optional[RSNConfig] = None,
    embed_dim: Optional[int] = None,
    rsn_dim: Optional[int] = None,
    device: str = 'auto',
) -> Dict[str, float]:
    """
    One-shot R/S/N computation with explicit configuration.
    
    SECURITY: Requires explicit dimensions. Use one of:
    1. Pass RSNConfig object (recommended)
    2. Pass embed_dim and rsn_dim explicitly
    
    Args:
        model: PyTorch model
        data: Input tensor [B, C, H, W]
        config: RSNConfig object (if provided, other args ignored)
        embed_dim: Embedding dimension (required if no config)
        rsn_dim: R/S/N projection dimension (required if no config)
        device: Target device ('auto', 'cuda', 'cpu')
        
    Returns:
        Dict with R, S, N, alpha, omega, tau, embed_dim, rsn_dim
        
    Raises:
        ValueError: If neither config nor (embed_dim, rsn_dim) provided
        
    Example:
        from yrsn.utils import compute_rsn, RSNConfig
        
        # Option 1: Explicit config (recommended)
        config = RSNConfig(embed_dim=64, rsn_dim=128)
        rsn = compute_rsn(model, batch, config=config)
        
        # Option 2: Explicit dims
        rsn = compute_rsn(model, batch, embed_dim=64, rsn_dim=128)
        
        # Option 3: Auto-detect embed_dim (opt-in)
        config = RSNConfig.from_model(model, rsn_dim=128)
        rsn = compute_rsn(model, batch, config=config)
    """
    # Validate: must have explicit config or dims
    if config is None:
        if embed_dim is None or rsn_dim is None:
            raise ValueError(
                "SECURITY: Must specify dimensions explicitly. Use one of:\n"
                "  1. compute_rsn(model, data, config=RSNConfig(embed_dim=64, rsn_dim=128))\n"
                "  2. compute_rsn(model, data, embed_dim=64, rsn_dim=128)\n"
                "  3. compute_rsn(model, data, config=RSNConfig.from_model(model, rsn_dim=128))"
            )
        config = RSNConfig(embed_dim=embed_dim, rsn_dim=rsn_dim, device=device)
    
    pipeline = RSNPipeline(model, config)
    return pipeline.compute_rsn(data)


# Exports
__all__ = [
    # Configuration (required for security)
    'RSNConfig',
    # Pipeline
    'RSNPipeline',
    'RSNResult',
    # Convenience
    'compute_rsn',
    # Utilities
    'get_embed_dim',
    'extract_features',
]
