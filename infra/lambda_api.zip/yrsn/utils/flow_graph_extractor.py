"""
Flow Graph Extractor - Convert Visual SVG Diagrams to Executable Specifications

This module extracts directed graphs from SVG flow diagrams, supporting both:
1. Semantic annotation (explicit node__X, edge__X__Y IDs)
2. Visual extraction (rect + text = node, path + arrow = edge)

Philosophy: Visual diagrams become executable specifications.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Set, Optional, Any
import xml.etree.ElementTree as ET
import re
import networkx as nx

from .svg_reader import read_svg, SvgDoc


# ============================================================================
# Data Structures
# ============================================================================

@dataclass(frozen=True)
class FlowNode:
    """A node in a flow diagram."""
    id: str                      # Unique identifier (e.g., "input_data")
    label: str                   # Display label
    type: str                    # Node type: "input", "process", "output", "decision", "certificate"
    position: Tuple[float, float]  # (x, y) center coordinates
    metadata: Dict[str, Any]     # Additional attributes


@dataclass(frozen=True)
class FlowEdge:
    """A directed edge in a flow diagram."""
    source: str                  # Source node ID
    target: str                  # Target node ID
    label: Optional[str]         # Edge label (e.g., "produces", "validates")
    metadata: Dict[str, Any]     # Additional attributes


@dataclass(frozen=True)
class FlowGraph:
    """A directed flow graph extracted from SVG."""
    flow_id: str                 # e.g., "flow_a", "flow_b", "flow_c"
    title: str                   # Flow title
    nodes: List[FlowNode]
    edges: List[FlowEdge]
    source: str                  # SVG source
    is_dag: bool                 # Whether graph is acyclic
    metadata: Dict[str, Any]


# ============================================================================
# Semantic Annotation Convention (for explicit IDs)
# ============================================================================

"""
To enable semantic extraction, annotate SVG elements with IDs:

NODES:
  <rect id="node__input_data" .../>
  <rect id="node__rsn_decomposition" .../>
  <rect id="node__certificate" .../>

EDGES:
  <path id="edge__input_data__rsn_decomposition" .../>
  <path id="edge__rsn_decomposition__signals" .../>

NODE TYPES (encode in metadata or use prefixes):
  <rect id="node__input_data" data-type="input" .../>
  <rect id="node__rsn_decomposition" data-type="process" .../>
  <rect id="node__certificate" data-type="certificate" .../>

LABELS (extracted from adjacent <text> elements):
  Auto-detected from nearby text or explicit:
  <text id="label__node__input_data">Contextual Input Data</text>
"""


# ============================================================================
# Semantic Extractor (for annotated SVGs)
# ============================================================================

def extract_semantic_graph(svg_doc: SvgDoc) -> FlowGraph:
    """
    Extract flow graph from semantically annotated SVG.

    Looks for:
    - Elements with id="node__<name>"
    - Elements with id="edge__<src>__<dst>"
    - Adjacent text elements for labels

    Returns:
        FlowGraph with nodes and edges
    """
    root = ET.fromstring(svg_doc.svg_text)

    nodes = {}
    edges = []
    title = ""

    # Extract title
    for text_elem in root.findall(".//text"):
        text_content = "".join(text_elem.itertext()).strip()
        if "Flow" in text_content and ":" in text_content:
            title = text_content
            break

    # Extract nodes
    for elem in root.iter():
        elem_id = elem.attrib.get("id", "")

        if elem_id.startswith("node__"):
            node_id = elem_id.replace("node__", "")

            # Get position from rect or circle
            if elem.tag.endswith("rect"):
                x = float(elem.attrib.get("x", 0))
                y = float(elem.attrib.get("y", 0))
                width = float(elem.attrib.get("width", 0))
                height = float(elem.attrib.get("height", 0))
                pos = (x + width / 2, y + height / 2)
            elif elem.tag.endswith("circle"):
                cx = float(elem.attrib.get("cx", 0))
                cy = float(elem.attrib.get("cy", 0))
                pos = (cx, cy)
            else:
                pos = (0, 0)

            # Get type from data attribute or infer
            node_type = elem.attrib.get("data-type", "process")

            # Find label (nearby text element)
            label = node_id.replace("_", " ").title()
            # TODO: Better label extraction from nearby <text>

            nodes[node_id] = FlowNode(
                id=node_id,
                label=label,
                type=node_type,
                position=pos,
                metadata=dict(elem.attrib)
            )

    # Extract edges
    for elem in root.iter():
        elem_id = elem.attrib.get("id", "")

        if elem_id.startswith("edge__"):
            parts = elem_id.replace("edge__", "").split("__")
            if len(parts) >= 2:
                source = parts[0]
                target = parts[1]

                # Find label (nearby text)
                edge_label = None
                # TODO: Extract from nearby <text>

                edges.append(FlowEdge(
                    source=source,
                    target=target,
                    label=edge_label,
                    metadata=dict(elem.attrib)
                ))

    # Convert to networkx for DAG check
    G = nx.DiGraph()
    G.add_nodes_from(nodes.keys())
    G.add_edges_from([(e.source, e.target) for e in edges])
    is_dag = nx.is_directed_acyclic_graph(G)

    # Infer flow_id from title
    flow_id = "unknown"
    if "Flow A" in title:
        flow_id = "flow_a"
    elif "Flow B" in title:
        flow_id = "flow_b"
    elif "Flow C" in title:
        flow_id = "flow_c"

    return FlowGraph(
        flow_id=flow_id,
        title=title,
        nodes=list(nodes.values()),
        edges=edges,
        source=svg_doc.source,
        is_dag=is_dag,
        metadata={"svg_viewbox": svg_doc.viewbox}
    )


# ============================================================================
# Visual Extractor (for unannotated SVGs)
# ============================================================================

def extract_visual_graph(svg_doc: SvgDoc) -> FlowGraph:
    """
    Extract flow graph from visual SVG (no semantic annotations).

    Uses heuristics:
    - <rect> with <text> inside/nearby → Node
    - <path> with arrow marker → Edge
    - Vertical flow (top to bottom)

    Returns:
        FlowGraph with inferred nodes and edges
    """
    root = ET.fromstring(svg_doc.svg_text)

    # Handle namespaces - use standard SVG namespace
    # SVG files always use http://www.w3.org/2000/svg
    ns_prefix = "{http://www.w3.org/2000/svg}"

    nodes = []
    edges = []
    title = ""

    # Extract title
    text_elements = root.findall(f".//{ns_prefix}text")
    for text_elem in text_elements:
        text_content = "".join(text_elem.itertext()).strip()
        if "Flow" in text_content and ":" in text_content:
            title = text_content
            break

    # Extract nodes (rect with substantial size = stage box)
    node_id_counter = 0
    rect_to_node = {}  # Map rect center → node

    rect_elements = root.findall(f".//{ns_prefix}rect")
    for rect_elem in rect_elements:
        # Skip small rects (decorations, gradients)
        width = float(rect_elem.attrib.get("width", 0))
        height = float(rect_elem.attrib.get("height", 0))

        if width < 100 or height < 40:
            continue  # Too small to be a stage

        x = float(rect_elem.attrib.get("x", 0))
        y = float(rect_elem.attrib.get("y", 0))

        # Skip annotation boxes (side panels) - they're off to the left/right
        # Main flow is typically centered (e.g., x=200-250 in 800px wide canvas)
        # Annotations are at x<150 or x>550
        if x < 150 or x > 550:
            continue  # Likely an annotation box, not a flow node

        center = (x + width / 2, y + height / 2)

        # Find text label near this rect
        label = f"stage_{node_id_counter}"
        for text_elem in text_elements:  # Reuse text_elements from above
            text_x = float(text_elem.attrib.get("x", 0))
            text_y = float(text_elem.attrib.get("y", 0))

            # Check if text is inside rect
            if (x <= text_x <= x + width) and (y <= text_y <= y + height):
                text_content = "".join(text_elem.itertext()).strip()
                # Take first bold text as label
                if text_elem.attrib.get("font-weight") == "bold":
                    label = text_content
                    break

        # Infer node type from label keywords
        node_type = "process"
        label_lower = label.lower()
        if "input" in label_lower or "data" in label_lower:
            node_type = "input"
        elif "output" in label_lower or "interface" in label_lower:
            node_type = "output"
        elif "certificate" in label_lower:
            node_type = "certificate"
        elif "decision" in label_lower or "pass" in label_lower:
            node_type = "decision"
        elif "gateway" in label_lower or "validation" in label_lower:
            node_type = "validation"

        node_id = label.lower().replace(" ", "_").replace("-", "_")
        if not node_id or node_id.startswith("_"):
            node_id = f"node_{node_id_counter}"

        nodes.append(FlowNode(
            id=node_id,
            label=label,
            type=node_type,
            position=center,
            metadata={"rect_bounds": (x, y, width, height)}
        ))

        rect_to_node[center] = node_id
        node_id_counter += 1

    # Extract edges (path elements with arrows)
    path_elements = root.findall(f".//{ns_prefix}path")
    for path_elem in path_elements:
        d = path_elem.attrib.get("d", "")
        marker_end = path_elem.attrib.get("marker-end", "")

        # Only consider paths with arrow markers
        if "arrow" not in marker_end.lower():
            continue

        # Parse path to get start and end points
        # Simple pattern: "M x1 y1 L x2 y2" (straight line)
        match = re.match(r"M\s+([\d.]+)\s+([\d.]+)\s+L\s+([\d.]+)\s+([\d.]+)", d)
        if not match:
            continue

        x1, y1, x2, y2 = map(float, match.groups())
        start_point = (x1, y1)
        end_point = (x2, y2)

        # Find nearest nodes to start and end points
        def find_nearest_node(point, nodes_list):
            min_dist = float('inf')
            nearest = None
            for node in nodes_list:
                dist = ((point[0] - node.position[0])**2 + (point[1] - node.position[1])**2)**0.5
                if dist < min_dist:
                    min_dist = dist
                    nearest = node
            return nearest if min_dist < 200 else None  # Max 200px distance

        source_node = find_nearest_node(start_point, nodes)
        target_node = find_nearest_node(end_point, nodes)

        if source_node and target_node:
            edges.append(FlowEdge(
                source=source_node.id,
                target=target_node.id,
                label=None,
                metadata={"path_d": d}
            ))

    # Convert to networkx for DAG check
    node_ids = [n.id for n in nodes]
    G = nx.DiGraph()
    G.add_nodes_from(node_ids)
    G.add_edges_from([(e.source, e.target) for e in edges])
    is_dag = nx.is_directed_acyclic_graph(G)

    # Infer flow_id
    flow_id = "unknown"
    if "Flow A" in title:
        flow_id = "flow_a"
    elif "Flow B" in title:
        flow_id = "flow_b"
    elif "Flow C" in title:
        flow_id = "flow_c"

    return FlowGraph(
        flow_id=flow_id,
        title=title,
        nodes=nodes,
        edges=edges,
        source=svg_doc.source,
        is_dag=is_dag,
        metadata={"extraction_method": "visual", "svg_viewbox": svg_doc.viewbox}
    )


# ============================================================================
# Main API
# ============================================================================

def extract_flow_graph(svg_path: Path, method: str = "auto") -> FlowGraph:
    """
    Extract flow graph from SVG diagram.

    Args:
        svg_path: Path to SVG file
        method: "semantic" (requires annotations), "visual" (heuristic), or "auto"

    Returns:
        FlowGraph with nodes and edges
    """
    # Load SVG
    svg_doc = read_svg(svg_path)

    # Auto-detect method
    if method == "auto":
        # Check if SVG has semantic annotations
        if "node__" in svg_doc.svg_text or "edge__" in svg_doc.svg_text:
            method = "semantic"
        else:
            method = "visual"

    # Extract
    if method == "semantic":
        return extract_semantic_graph(svg_doc)
    elif method == "visual":
        return extract_visual_graph(svg_doc)
    else:
        raise ValueError(f"Unknown extraction method: {method}")


def validate_flow_dag(flow: FlowGraph) -> Tuple[bool, List[str]]:
    """
    Validate that flow graph is a valid DAG.

    Checks:
    1. Is directed acyclic graph
    2. Has single source node (input)
    3. Has single sink node (output) - optional
    4. All nodes reachable from source
    5. No isolated nodes

    Returns:
        (valid, error_messages)
    """
    errors = []

    # Already checked during extraction
    if not flow.is_dag:
        errors.append("Flow contains cycles (not a DAG)")

    # Build networkx graph
    G = nx.DiGraph()
    node_ids = [n.id for n in flow.nodes]
    G.add_nodes_from(node_ids)
    G.add_edges_from([(e.source, e.target) for e in flow.edges])

    # Check for source nodes (no incoming edges)
    sources = [n for n in node_ids if G.in_degree(n) == 0]
    if len(sources) == 0:
        errors.append("No source node found (all nodes have incoming edges)")
    elif len(sources) > 1:
        errors.append(f"Multiple source nodes: {sources} (expected 1)")

    # Check for sink nodes (no outgoing edges)
    sinks = [n for n in node_ids if G.out_degree(n) == 0]
    if len(sinks) == 0:
        errors.append("No sink node found (all nodes have outgoing edges)")

    # Check reachability from source
    if sources:
        source = sources[0]
        reachable = nx.descendants(G, source)
        reachable.add(source)

        unreachable = set(node_ids) - reachable
        if unreachable:
            errors.append(f"Nodes unreachable from source: {unreachable}")

    # Check for isolated nodes
    isolated = list(nx.isolates(G))
    if isolated:
        errors.append(f"Isolated nodes (no edges): {isolated}")

    return len(errors) == 0, errors


def graph_to_wiring_spec(flow: FlowGraph) -> Dict[str, Any]:
    """
    Convert flow graph to wiring specification for validation.

    Maps visual flow stages to validation check IDs.

    Example:
        Flow A node "R/S/N Decomposition" → Check A2
    """
    node_to_check = {
        # Flow A mappings
        "contextual_input_data": "A1",
        "r/s/n_decomposition": "A2",
        "signal_derivation": "A3",
        "context_quality_certificate": "A4",
        "cryptographic_binding": "A5",
        "communication_interface": "A6",

        # Flow B mappings
        "contextual_input_data_+_context_quality_certificate": "B1",
        "trust_boundary": "B2",
        "ordered_validation": "B3",
        "pre-task_semantic_enforcement": "B4",

        # Flow C mappings
        "first_consumer_(agent_a)": "C1",
        "second_consumer_(agent_b)": "C1",
        "closed-loop_semantic_control": "C2",
    }

    spec = {
        "flow_id": flow.flow_id,
        "title": flow.title,
        "nodes": len(flow.nodes),
        "edges": len(flow.edges),
        "is_dag": flow.is_dag,
        "validation_checks": []
    }

    for node in flow.nodes:
        check_id = node_to_check.get(node.id)
        if check_id:
            spec["validation_checks"].append({
                "check_id": check_id,
                "node_id": node.id,
                "label": node.label,
                "type": node.type
            })

    return spec
