"""
Safe SVG reader with validation and normalization.

Provides drop-in SVG parsing with strong error handling.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Union
import re
import xml.etree.ElementTree as ET


# -----------------------------
# Exceptions
# -----------------------------

class SvgReadError(Exception):
    """Base class for SVG read/parse errors."""


class SvgInputError(SvgReadError):
    """Bad input (missing, wrong type, empty, unreadable)."""


class SvgParseError(SvgReadError):
    """XML is not parseable / not valid SVG."""


class SvgValidationError(SvgReadError):
    """Parsed XML is valid, but doesn't look like an SVG."""


# -----------------------------
# Result type
# -----------------------------

@dataclass(frozen=True)
class SvgDoc:
    source: str                   # e.g. "path:/x/y.svg" or "bytes" or "string"
    svg_text: str                 # sanitized SVG text (UTF-8)
    root_tag: str                 # root element tag (namespace-stripped)
    width: Optional[str]
    height: Optional[str]
    viewbox: Optional[str]
    namespaces: Dict[str, str]    # prefix -> namespace URI
    root_attrib: Dict[str, str]   # root element attrib (stringified)


# -----------------------------
# Helpers
# -----------------------------

_XML_DECL_RE = re.compile(r"^\s*<\?xml[^>]*\?>\s*", re.IGNORECASE)
_DOCTYPE_RE  = re.compile(r"<!DOCTYPE[^>]*>", re.IGNORECASE)
_BOM_UTF8 = "\ufeff"


def _strip_namespace(tag: str) -> str:
    """Convert '{http://www.w3.org/2000/svg}svg' -> 'svg'."""
    if not tag:
        return tag
    if tag[0] == "{" and "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _clean_svg_text(text: str, *, remove_doctype: bool = True) -> str:
    """
    Minimal cleanup:
      - Remove UTF-8 BOM if present
      - Strip leading XML declaration (ElementTree tolerates it, but helps normalize)
      - Optionally remove DOCTYPE (avoid external entity concerns + common parser quirks)
      - Strip trailing whitespace
    """
    if text.startswith(_BOM_UTF8):
        text = text.lstrip(_BOM_UTF8)

    # Normalize newlines
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # Remove XML declaration at start (optional normalization)
    text = _XML_DECL_RE.sub("", text)

    if remove_doctype:
        text = _DOCTYPE_RE.sub("", text)

    return text.strip()


def _extract_ns_from_root(root: ET.Element) -> Dict[str, str]:
    ns: Dict[str, str] = {}
    for k, v in root.attrib.items():
        if k == "xmlns":
            ns[""] = v
        elif k.startswith("xmlns:"):
            ns[k.split(":", 1)[1]] = v
    return ns


# -----------------------------
# Main function
# -----------------------------

SvgInput = Union[str, bytes, Path]

def read_svg(
    svg_input: SvgInput,
    *,
    max_bytes: int = 5_000_000,
    remove_doctype: bool = True,
    require_svg_root: bool = True,
) -> SvgDoc:
    """
    Read + parse an SVG from:
      - Path
      - bytes
      - string (SVG markup) OR string path (auto-detected)

    Strong error handling:
      - file not found, too large, empty input
      - non-UTF8 bytes
      - invalid XML
      - not an <svg> root (optional)

    Returns:
      SvgDoc with cleaned svg_text and basic metadata.
    """

    # --- Load raw bytes/text ---
    source_label = "unknown"
    raw_bytes: Optional[bytes] = None
    svg_text: Optional[str] = None

    try:
        if isinstance(svg_input, Path):
            p = svg_input
            source_label = f"path:{p}"
            if not p.exists():
                raise SvgInputError(f"SVG path does not exist: {p}")
            if not p.is_file():
                raise SvgInputError(f"SVG path is not a file: {p}")
            size = p.stat().st_size
            if size <= 0:
                raise SvgInputError(f"SVG file is empty: {p}")
            if size > max_bytes:
                raise SvgInputError(f"SVG file too large ({size} bytes > {max_bytes}): {p}")
            raw_bytes = p.read_bytes()

        elif isinstance(svg_input, bytes):
            source_label = "bytes"
            if not svg_input:
                raise SvgInputError("SVG bytes input is empty.")
            if len(svg_input) > max_bytes:
                raise SvgInputError(f"SVG bytes too large ({len(svg_input)} bytes > {max_bytes}).")
            raw_bytes = svg_input

        elif isinstance(svg_input, str):
            # Auto-detect: treat as path if it looks like a file and exists.
            s = svg_input.strip()
            if not s:
                raise SvgInputError("SVG string input is empty.")

            maybe_path = Path(s)
            if ("\n" not in s) and (len(s) < 260) and maybe_path.suffix.lower() == ".svg" and maybe_path.exists():
                # It is a file path
                p = maybe_path
                source_label = f"path:{p}"
                if not p.is_file():
                    raise SvgInputError(f"SVG path is not a file: {p}")
                size = p.stat().st_size
                if size <= 0:
                    raise SvgInputError(f"SVG file is empty: {p}")
                if size > max_bytes:
                    raise SvgInputError(f"SVG file too large ({size} bytes > {max_bytes}): {p}")
                raw_bytes = p.read_bytes()
            else:
                # It is SVG markup (string)
                source_label = "string"
                svg_text = s

        else:
            raise SvgInputError(f"Unsupported svg_input type: {type(svg_input).__name__}")

        if svg_text is None:
            # Decode bytes to text
            assert raw_bytes is not None
            try:
                svg_text = raw_bytes.decode("utf-8")
            except UnicodeDecodeError as e:
                raise SvgInputError(f"SVG bytes are not valid UTF-8: {e}") from e

        # --- Cleanup / normalize ---
        svg_text = _clean_svg_text(svg_text, remove_doctype=remove_doctype)

        if not svg_text:
            raise SvgInputError("SVG content is empty after cleanup.")

        if len(svg_text.encode("utf-8")) > max_bytes:
            raise SvgInputError(f"SVG content too large after cleanup (> {max_bytes} bytes).")

        # --- Parse XML safely ---
        try:
            root = ET.fromstring(svg_text)
        except ET.ParseError as e:
            raise SvgParseError(f"Failed to parse SVG XML: {e}") from e

        root_tag = _strip_namespace(root.tag)

        if require_svg_root and root_tag.lower() != "svg":
            raise SvgValidationError(f"Root element is <{root_tag}>, expected <svg>.")

        # Best-effort namespace collection
        namespaces = _extract_ns_from_root(root)

        # Basic metadata
        width = root.attrib.get("width")
        height = root.attrib.get("height")
        viewbox = root.attrib.get("viewBox") or root.attrib.get("viewbox")

        # Root attrib normalized to str->str
        root_attrib = {str(k): str(v) for k, v in root.attrib.items()}

        # --- Cleanup references ---
        del root
        raw_bytes = None

        return SvgDoc(
            source=source_label,
            svg_text=svg_text,
            root_tag=root_tag,
            width=width,
            height=height,
            viewbox=viewbox,
            namespaces=namespaces,
            root_attrib=root_attrib,
        )

    except SvgReadError:
        raise
    except Exception as e:
        raise SvgReadError(f"Unexpected error while reading SVG ({source_label}): {e}") from e
