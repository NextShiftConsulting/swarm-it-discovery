"""YrsnEvent - Discrete event notifications."""

from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Optional, Any, TYPE_CHECKING
from datetime import datetime
from enum import Enum


class EventType(str, Enum):
    """Event type enumeration."""

    # Collapse events
    COLLAPSE_RISE = "COLLAPSE_RISE"
    COLLAPSE_CLEAR = "COLLAPSE_CLEAR"

    # Quality events
    ALPHA_DROP = "ALPHA_DROP"
    ALPHA_RECOVER = "ALPHA_RECOVER"

    # OOD events
    OOD_SPIKE = "OOD_SPIKE"
    OOD_CLEAR = "OOD_CLEAR"

    # Lifecycle events
    BASELINE_READY = "BASELINE_READY"
    CALIBRATION_START = "CALIBRATION_START"
    CALIBRATION_DONE = "CALIBRATION_DONE"

    # Safety events
    RECOVERY_START = "RECOVERY_START"
    RECOVERY_DONE = "RECOVERY_DONE"

    # Node lifecycle
    NODE_CONFIGURED = "NODE_CONFIGURED"
    NODE_ACTIVATED = "NODE_ACTIVATED"
    NODE_DEACTIVATED = "NODE_DEACTIVATED"
    NODE_ERROR = "NODE_ERROR"


class YRSNEvent(BaseModel):
    """
    Discrete event notification.

    Published when significant state changes occur.

    Maps to:
    - ROS2: YRSNEvent.msg (topic: /yrsn/event)
    - CrewAI: Callback trigger
    - REST: Webhook payload
    """

    timestamp: datetime = Field(default_factory=datetime.utcnow)
    event_type: EventType = Field(description="Type of event")
    severity: float = Field(ge=0, le=1, default=0.5, description="Event severity (0-1)")
    source_id: Optional[str] = Field(default=None, description="Source identifier")
    details: str = Field(default="", description="Human-readable details")

    # Optional state snapshot at event time (use Any to avoid circular import)
    state: Optional[Any] = Field(default=None, description="State snapshot (YrsnState)")

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "event_type": "COLLAPSE_RISE",
                "severity": 0.8,
                "source_id": "anomaly_detector",
                "details": "Quality collapse detected: POISONING pattern",
            }
        }
