"""
ContextBlock - Fundamental context unit with YRSN decomposition.

The ContextBlock represents a retrieved context segment with its
Y=R+S+N decomposition, quality metrics, and derived values.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

import numpy as np
import numpy.typing as npt


@dataclass
class ContextBlock:
    """
    Represents a retrieved context segment with YRSN decomposition.

    This is the fundamental unit of context in the library.

    YRSN Decomposition:
        Y_observed = R + S + N + ε

        R (Relevant): Information that directly contributes to task performance
        S (Superfluous): Information that neither helps nor hurts - neutral context
        N (Noise): Information that actively degrades performance
        ε (epsilon): Reconstruction error - unexplained signal

    Derived Metrics:
        α (alpha): Quality score = R / (R + S + N)
        α_ω (alpha_omega): Distribution-adjusted quality
        τ (tau): Temperature = 1 / α_ω

    Attributes:
        content: The text content of this context block
        source: Source identifier for this content
        R: Relevant component score (0-1)
        S: Superfluous component score (0-1)
        N: Noise component score (0-1)
        epsilon: Reconstruction error - unexplained signal (≥0)
        omega: OOD reliability score (1.0 = in-distribution), inversely correlated with ε
        precision_level: The precision level (0=coarse, 1=medium, 2=fine)
        embedding: Optional vector embedding of the content
    """

    content: str
    source: str = "unknown"

    # YRSN decomposition: Y = R + S + N + ε
    R: float = 0.5  # Relevant
    S: float = 0.3  # Superfluous
    N: float = 0.2  # Noise
    epsilon: float = 0.0  # Reconstruction error (unexplained signal)
    omega: float = 1.0  # OOD reliability (1.0 = fully in-distribution, inversely correlated with ε)

    # Metadata
    precision_level: int = 0
    embedding: Optional[npt.NDArray[np.float32]] = None

    @property
    def alpha(self) -> float:
        """Quality score α = R / (R + S + N)."""
        total = self.R + self.S + self.N
        return self.R / total if total > 0 else 0.0

    @property
    def alpha_omega(self) -> float:
        """Distribution-adjusted quality α_ω = ω·α + (1-ω)·α_prior."""
        alpha_prior = 0.5  # Conservative prior for OOD content
        return self.omega * self.alpha + (1 - self.omega) * alpha_prior

    @property
    def tau(self) -> float:
        """Temperature τ = 1 / α_ω (clamped to avoid division by zero)."""
        return 1.0 / max(self.alpha_omega, 0.01)

    # Backward compatibility aliases
    @property
    def relevance_score(self) -> float:
        """Backward compatible alias for α (quality score)."""
        return self.alpha

    @property
    def quality_score(self) -> float:
        """Backward compatible alias for α_ω (distribution-adjusted quality)."""
        return self.alpha_omega

    def __post_init__(self) -> None:
        """Validate fields after initialization."""
        for name, val in [
            ("R", self.R),
            ("S", self.S),
            ("N", self.N),
            ("omega", self.omega),
        ]:
            if not 0 <= val <= 1:
                raise ValueError(f"{name} must be in [0, 1], got {val}")
        if self.epsilon < 0:
            raise ValueError(f"epsilon must be >= 0, got {self.epsilon}")
        if self.precision_level < 0:
            raise ValueError(f"precision_level must be >= 0, got {self.precision_level}")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "content": self.content,
            "source": self.source,
            "R": self.R,
            "S": self.S,
            "N": self.N,
            "epsilon": self.epsilon,
            "omega": self.omega,
            "alpha": self.alpha,
            "alpha_omega": self.alpha_omega,
            "tau": self.tau,
            "precision_level": self.precision_level,
        }

    @classmethod
    def from_legacy(cls, content: str, relevance_score: float, **kwargs) -> "ContextBlock":
        """
        Create from legacy format (relevance_score only).

        Maps relevance_score to R/S/N:
        - High relevance -> high R, low S, low N
        - Low relevance -> low R, high S or N
        """
        R = relevance_score
        S = (1 - relevance_score) * 0.6  # Most non-relevant is superfluous
        N = (1 - relevance_score) * 0.4  # Some is noise
        return cls(content=content, R=R, S=S, N=N, **kwargs)


@dataclass
class RefinementState:
    """
    Tracks the state of iterative refinement process.

    Used by IterativeContextEngine to track convergence.

    Attributes:
        current_context: List of context blocks accumulated so far
        residual_queries: Queries for information still missing
        iteration: Current iteration number (0-indexed)
        precision_achieved: Current precision level (0-1)
        convergence_rate: Rate of precision improvement per iteration
        avg_alpha: Average alpha across current context
        avg_omega: Average omega across current context
        avg_tau: Average tau across current context
    """

    current_context: List[ContextBlock] = field(default_factory=list)
    residual_queries: List[str] = field(default_factory=list)
    iteration: int = 0
    precision_achieved: float = 0.0
    convergence_rate: float = 0.0

    @property
    def avg_alpha(self) -> float:
        """Average quality score across context."""
        if not self.current_context:
            return 0.0
        return sum(b.alpha for b in self.current_context) / len(self.current_context)

    @property
    def avg_omega(self) -> float:
        """Average OOD reliability across context."""
        if not self.current_context:
            return 1.0
        return sum(b.omega for b in self.current_context) / len(self.current_context)

    @property
    def avg_tau(self) -> float:
        """Average temperature across context."""
        if not self.current_context:
            return 1.0
        return sum(b.tau for b in self.current_context) / len(self.current_context)

    def __post_init__(self) -> None:
        """Validate fields after initialization."""
        if self.iteration < 0:
            raise ValueError(f"iteration must be >= 0, got {self.iteration}")
        if not 0 <= self.precision_achieved <= 1:
            raise ValueError(
                f"precision_achieved must be in [0, 1], got {self.precision_achieved}"
            )


__all__ = [
    "ContextBlock",
    "RefinementState",
]
