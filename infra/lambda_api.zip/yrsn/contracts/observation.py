"""Observation - Input contract for YRSN processing."""

from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime


class Observation(BaseModel):
    """
    Input observation for YRSN processing.

    Flexible: can be text, features, or structured data.

    Examples:
        # Text observation
        obs = Observation(text="Some content to analyze")

        # With query for relevance scoring
        obs = Observation(text="Document content", query="What is X?")

        # Feature vector (for OOD detection)
        obs = Observation(features=[0.1, 0.2, 0.3, ...])

        # Structured data
        obs = Observation(data={"sensor": "camera", "values": [...]})
    """

    timestamp: datetime = Field(default_factory=datetime.utcnow)
    source_id: str = Field(default="default", description="Source identifier")

    # Content (provide one of these)
    text: Optional[str] = Field(default=None, description="Text content")
    features: Optional[List[float]] = Field(default=None, description="Feature vector")
    data: Optional[Dict[str, Any]] = Field(default=None, description="Structured data")

    # Optional context
    query: Optional[str] = Field(default=None, description="Query for relevance scoring")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "examples": [
                {
                    "text": "The quick brown fox jumps over the lazy dog.",
                    "query": "What animal jumps?",
                    "source_id": "doc_001",
                },
                {
                    "features": [0.1, 0.2, 0.3, 0.4, 0.5],
                    "source_id": "sensor_001",
                },
            ]
        }
