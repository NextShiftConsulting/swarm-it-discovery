"""
YRSNState - Simplified output contract from YRSN processing.

This is the SIMPLIFIED contract for common use cases (ROS2, CrewAI, simple REST).
For full v2.0 API responses, use YRSNResponseModel from signal_spec_pydantic.py.

When to use which:
    - YRSNState: Simple/lightweight output for tools, agents, ROS2 messages
    - YRSNResponseModel: Full v2.0 API responses with all signal categories
"""

from pydantic import BaseModel, Field
from typing import List, Optional
import sys
if sys.version_info >= (3, 8):
    from typing import Literal
else:
    from typing_extensions import Literal
from datetime import datetime
from enum import Enum


class Mode(str, Enum):
    """System operating mode."""

    NORMAL = "NORMAL"  # All signals healthy
    CAUTION = "CAUTION"  # Quality below threshold
    RECOVERY = "RECOVERY"  # Recovering from error/collapse
    ERROR = "ERROR"  # Error state


# Collapse type enumeration matching CollapseSignature
CollapseType = Literal[
    "NONE",
    "POISONING", "DISTRACTION", "CONFLICT", "CLASH",
    "HALLUCINATION", "O_POISONING", "DRIFT",
    "SATURATION", "SPARSITY", "DEAD_NEURON",
    "ENTROPY_COLLAPSE", "CONFIDENCE_COLLAPSE",
    "FORGETTING", "INTERFERENCE", "REPLAY_FAILURE",
    "MODE_COLLAPSE"
]

CollapseDomain = Literal["quality", "reliability", "representation", "uncertainty", "distributional"]
CollapseSeverity = Literal["none", "low", "medium", "high", "critical"]
CollapseAction = Literal["PROCEED", "CAUTION", "RETRY", "FALLBACK", "HALT"]


class YRSNState(BaseModel):
    """
    Simplified YRSN telemetry output.

    This is the LIGHTWEIGHT output from YRSN processing, containing:
    - Quality metrics (alpha, omega, tau)
    - Collapse detection with type
    - System mode
    - Optional R/S/N/ε decomposition

    Use Cases:
        - ROS2: YRSNState.msg (compact message)
        - CrewAI: Tool return type
        - Simple REST: Lightweight JSON response
        - Internal: Quick quality checks

    For full v2.0 API responses with all signal categories (memory, uncertainty,
    calibration, etc.), use YRSNResponseModel from yrsn.core.signal_spec_pydantic.
    """

    timestamp: datetime = Field(default_factory=datetime.utcnow)

    # Core signals
    alpha: float = Field(ge=0, le=1, description="Quality ratio R/(R+S+N)")
    omega: float = Field(ge=0, le=1, default=1.0, description="Reliability (1=in-distribution)")
    tau: float = Field(ge=0, description="Temperature (1/alpha_omega)")

    # Collapse detection
    collapse: bool = Field(default=False, description="Collapse detected")
    collapse_type: CollapseType = Field(default="NONE", description="Type of collapse")
    collapse_domain: Optional[CollapseDomain] = Field(default=None, description="Collapse domain")
    collapse_severity: CollapseSeverity = Field(default="none", description="Collapse severity")
    collapse_action: CollapseAction = Field(default="PROCEED", description="Recommended action")

    # System mode
    mode: Mode = Field(default=Mode.NORMAL, description="System mode")

    # Attribution
    source_id: Optional[str] = Field(default=None, description="Source identifier")
    tags: List[str] = Field(default_factory=list, description="Tags/labels")

    # Raw decomposition (optional, Y = R + S + N + ε)
    r: Optional[float] = Field(default=None, ge=0, le=1, description="Relevant signal")
    s: Optional[float] = Field(default=None, ge=0, le=1, description="Superfluous signal")
    n: Optional[float] = Field(default=None, ge=0, le=1, description="Noise")
    epsilon: Optional[float] = Field(default=None, ge=0, description="Reconstruction error")

    @property
    def alpha_omega(self) -> float:
        """Reliability-adjusted quality."""
        return self.omega * self.alpha + (1 - self.omega) * 0.5

    @property
    def is_healthy(self) -> bool:
        """Check if state is healthy (normal mode, no collapse)."""
        return self.mode == Mode.NORMAL and not self.collapse

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "alpha": 0.85,
                "omega": 0.95,
                "tau": 1.18,
                "collapse": False,
                "collapse_type": "NONE",
                "collapse_severity": "none",
                "collapse_action": "PROCEED",
                "mode": "NORMAL",
                "source_id": "quality_monitor",
                "r": 0.7,
                "s": 0.1,
                "n": 0.03,
                "epsilon": 0.02,
            }
        }


class YRSNStateBatch(BaseModel):
    """Batch of states for multi-sensor fusion."""

    states: List[YRSNState] = Field(description="Individual sensor states")
    fused: Optional[YRSNState] = Field(default=None, description="Fused state")

    @property
    def mean_alpha(self) -> float:
        """Mean quality across all states."""
        if not self.states:
            return 0.5
        return sum(s.alpha for s in self.states) / len(self.states)

    @property
    def min_omega(self) -> float:
        """Minimum reliability (most uncertain sensor)."""
        if not self.states:
            return 1.0
        return min(s.omega for s in self.states)
