"""
YRSN Contracts - Typed I/O Schemas (Pydantic)

Core data structures that define the API boundaries.
These are the "ports" for data - all inputs and outputs use these types.

Contracts (Simplified - for tools, agents, ROS2):
    Observation     - Input to YRSN processing
    YRSNState       - Simplified output from YRSN processing
    YRSNEvent       - Discrete event notifications
    Mode            - System mode (NORMAL, CAUTION, RECOVERY, ERROR)
    EventType       - Event type enumeration
    ContextBlock    - Context segment with YRSN decomposition
    RefinementState - Iterative refinement tracking

Collapse Types:
    CollapseType     - 16 collapse types (POISONING, DISTRACTION, etc.)
    CollapseDomain   - 5 domains (quality, reliability, etc.)
    CollapseSeverity - Severity levels (none, low, medium, high, critical)
    CollapseAction   - Recommended actions (PROCEED, CAUTION, RETRY, etc.)

For full v2.0 API responses with all signal categories, use:
    yrsn.core.signal_spec_pydantic.YRSNResponseModel
"""

from yrsn.contracts.observation import Observation
from yrsn.contracts.state import (
    YRSNState,
    YRSNStateBatch,
    Mode,
    CollapseType,
    CollapseDomain,
    CollapseSeverity,
    CollapseAction,
)
from yrsn.contracts.event import YRSNEvent, EventType
from yrsn.contracts.context import ContextBlock, RefinementState

# Backward compatibility aliases
YrsnState = YRSNState
YrsnStateBatch = YRSNStateBatch
YrsnEvent = YRSNEvent

__all__ = [
    # Input
    "Observation",
    # Output (simplified)
    "YRSNState",
    "YRSNStateBatch",
    "Mode",
    # Backward compatibility
    "YrsnState",
    "YrsnStateBatch",
    "YrsnEvent",
    # Collapse types
    "CollapseType",
    "CollapseDomain",
    "CollapseSeverity",
    "CollapseAction",
    # Events
    "YRSNEvent",
    "EventType",
    # Context
    "ContextBlock",
    "RefinementState",
]
