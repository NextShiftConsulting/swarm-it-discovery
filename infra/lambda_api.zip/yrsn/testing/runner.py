"""
YRSN Test Runner

Orchestrates test suite execution and result aggregation.

Usage:
    from yrsn.testing import TestRunner

    runner = TestRunner(verbose=True)
    results = runner.run_all()
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import time


@dataclass
class TestResult:
    """Result of a single test."""
    name: str
    passed: bool
    expected: str
    actual: str
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SuiteResult:
    """Result of a test suite."""
    name: str
    passed: int
    failed: int
    total: int
    accuracy: float
    duration_ms: float
    tests: List[TestResult] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'passed': self.passed,
            'failed': self.failed,
            'total': self.total,
            'accuracy': self.accuracy,
            'duration_ms': self.duration_ms,
            'tests': [
                {
                    'name': t.name,
                    'passed': t.passed,
                    'expected': t.expected,
                    'actual': t.actual,
                }
                for t in self.tests
            ]
        }


class TestRunner:
    """
    YRSN Test Runner - orchestrates test suite execution.

    Usage:
        runner = TestRunner(verbose=True)
        results = runner.run_safety_tests()
        print(f"Passed: {results['passed']}/{results['total']}")
    """

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def run_basic_tests(self) -> Dict[str, Any]:
        """Run basic functionality tests."""
        from yrsn.testing.suites import BasicTestSuite
        suite = BasicTestSuite(verbose=self.verbose)
        return suite.run()

    def run_yrsn16_tests(self) -> Dict[str, Any]:
        """Run all 16 collapse type tests."""
        from yrsn.testing.suites import YRSN16TestSuite
        suite = YRSN16TestSuite(verbose=self.verbose)
        return suite.run()

    def run_safety_tests(self) -> Dict[str, Any]:
        """Run safety band + dual tracking tests."""
        from yrsn.testing.suites import SafetyTestSuite
        suite = SafetyTestSuite(verbose=self.verbose)
        return suite.run()

    def run_stress_tests(self, dataset: Optional[str] = None) -> Dict[str, Any]:
        """Run stress tests with optional external dataset."""
        from yrsn.testing.suites import StressTestSuite
        suite = StressTestSuite(verbose=self.verbose, dataset=dataset)
        return suite.run()

    def run_adversarial_tests(self) -> Dict[str, Any]:
        """Run adversarial boundary tests."""
        from yrsn.testing.suites import AdversarialTestSuite
        suite = AdversarialTestSuite(verbose=self.verbose)
        return suite.run()

    def run_all(self) -> Dict[str, Any]:
        """Run all test suites and aggregate results."""
        all_results = {}
        total_passed = 0
        total_tests = 0

        suites = [
            ('basic', self.run_basic_tests),
            ('yrsn16', self.run_yrsn16_tests),
            ('safety', self.run_safety_tests),
            ('adversarial', self.run_adversarial_tests),
        ]

        for name, runner in suites:
            result = runner()
            all_results[name] = result
            total_passed += result.get('passed', 0)
            total_tests += result.get('total', 0)

        all_results['summary'] = {
            'total_passed': total_passed,
            'total_tests': total_tests,
            'overall_accuracy': total_passed / total_tests if total_tests > 0 else 0,
        }

        return all_results
