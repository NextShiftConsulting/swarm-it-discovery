"""
YRSN Test Suites

Individual test suite implementations for YRSN validation.
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass
import time
import numpy as np


class BaseTestSuite:
    """Base class for test suites."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.tests: List[Dict] = []
        self.passed = 0
        self.failed = 0

    def log(self, msg: str):
        """Log message if verbose."""
        if self.verbose:
            print(msg)

    def record(self, name: str, expected: str, actual: str, passed: bool, **details):
        """Record a test result."""
        self.tests.append({
            'name': name,
            'expected': expected,
            'actual': actual,
            'passed': passed,
            **details
        })
        if passed:
            self.passed += 1
            self.log(f"  PASS: {name}")
        else:
            self.failed += 1
            self.log(f"  FAIL: {name} (expected={expected}, got={actual})")

    def results(self) -> Dict[str, Any]:
        """Return test results."""
        return {
            'passed': self.passed,
            'failed': self.failed,
            'total': self.passed + self.failed,
            'accuracy': self.passed / (self.passed + self.failed) if (self.passed + self.failed) > 0 else 0,
            'tests': self.tests,
        }


class BasicTestSuite(BaseTestSuite):
    """Basic functionality tests."""

    def run(self) -> Dict[str, Any]:
        """Run basic tests."""
        self.log("\n--- Basic Tests ---")

        # Test 1: Import core modules
        try:
            from yrsn.core.decomposition.collapse import detect_collapse, detect_collapse_full, CollapseType
            self.record("import_collapse", "success", "success", True)
        except Exception as e:
            self.record("import_collapse", "success", str(e), False)

        # Test 2: Basic collapse detection
        try:
            from yrsn.core.decomposition.collapse import detect_collapse
            result = detect_collapse(R=0.7, S=0.2, N=0.1)
            expected = "NONE"  # Healthy signal
            actual = result.collapse_type.name
            self.record("detect_healthy", expected, actual, actual == expected or actual == "HEALTHY")
        except Exception as e:
            self.record("detect_healthy", "NONE", str(e), False)

        # Test 3: Poisoning detection (high N)
        try:
            from yrsn.core.decomposition.collapse import detect_collapse
            result = detect_collapse(R=0.3, S=0.2, N=0.5)
            actual = result.collapse_type.name
            passed = actual == "POISONING"
            self.record("detect_poisoning", "POISONING", actual, passed)
        except Exception as e:
            self.record("detect_poisoning", "POISONING", str(e), False)

        # Test 4: Distraction detection (high S)
        try:
            from yrsn.core.decomposition.collapse import detect_collapse
            result = detect_collapse(R=0.3, S=0.5, N=0.2)
            actual = result.collapse_type.name
            passed = actual == "DISTRACTION"
            self.record("detect_distraction", "DISTRACTION", actual, passed)
        except Exception as e:
            self.record("detect_distraction", "DISTRACTION", str(e), False)

        # Test 5: RSN normalization
        try:
            from yrsn.core.decomposition.collapse import detect_collapse
            result = detect_collapse(R=3.0, S=2.0, N=1.0)  # Should normalize
            actual = "normalized"
            self.record("rsn_normalization", "normalized", actual, True)
        except Exception as e:
            self.record("rsn_normalization", "normalized", str(e), False)

        return self.results()


class YRSN16TestSuite(BaseTestSuite):
    """All 16 collapse type tests."""

    # YRSN-16 collapse types with test signals
    # Uses detect_collapse_full() parameters
    # Note: alpha = R/(R+S+N) is computed by detector
    COLLAPSE_TESTS = {
        # Quality Domain (basic R/S/N)
        'POISONING': {'R': 0.30, 'S': 0.20, 'N': 0.50},
        'DISTRACTION': {'R': 0.30, 'S': 0.50, 'N': 0.20},
        'CONFLICT': {'R': 0.30, 'S': 0.35, 'N': 0.35},
        'CLASH': {'R': 0.55, 'S': 0.23, 'N': 0.18, 'source_S_values': [0.01, 0.95, 0.50]},

        # Reliability Domain (omega required)
        # HALLUCINATION: alpha > 0.70 AND omega < 0.50, so need R > 0.70
        'HALLUCINATION': {'R': 0.80, 'S': 0.10, 'N': 0.10, 'omega': 0.35},
        # O_POISONING: R > 0.50 AND omega < 0.50 AND NOT healthy (N >= 0.28)
        'O_POISONING': {'R': 0.55, 'S': 0.15, 'N': 0.30, 'omega': 0.40},
        'DRIFT': {'R': 0.55, 'S': 0.25, 'N': 0.20, 'omega': 0.28},

        # Representation Domain
        'POSTERIOR_COLLAPSE': {'R': 0.70, 'S': 0.20, 'N': 0.10, 'latent_variance': 0.001},
        'MODE_COLLAPSE': {'R': 0.65, 'S': 0.25, 'N': 0.10, 'diversity': 0.05},
        # RSN_COLLAPSE: R,S,N all within 0.04 delta for priority 4 to beat CONFLICT
        # Also need N > 0.28 to avoid healthy detection
        'RSN_COLLAPSE': {'R': 0.35, 'S': 0.34, 'N': 0.31},

        # Uncertainty Domain (epistemic/aleatoric)
        # OVERCONFIDENCE: alpha < 0.40, epistemic < 0.10, was_correct=False
        'OVERCONFIDENCE': {'R': 0.30, 'S': 0.50, 'N': 0.20, 'epistemic': 0.05, 'was_correct': False},
        'EPISTEMIC_SPIKE': {'R': 0.45, 'S': 0.30, 'N': 0.25, 'epistemic': 0.85},
        # ALEATORIC_DOMINANCE: aleatoric > 2x epistemic AND NOT healthy (N >= 0.28)
        'ALEATORIC_DOMINANCE': {'R': 0.45, 'S': 0.25, 'N': 0.30, 'epistemic': 0.10, 'aleatoric': 0.50},

        # Distributional Domain (KS tests) - avoid healthy detection
        'DISTRIBUTIONAL_SHIFT': {'R': 0.40, 'S': 0.35, 'N': 0.25, 'ks_p_value': 0.01},
        'GRADUAL_DRIFT': {'R': 0.40, 'S': 0.35, 'N': 0.25, 'wasserstein_trend': 0.05},
        # CONFIRMED_DRIFT: needs BOTH drift_heuristic=True AND ks_p_value < 0.05
        'CONFIRMED_DRIFT': {'R': 0.40, 'S': 0.30, 'N': 0.30, 'drift_heuristic': True, 'ks_p_value': 0.02},
    }

    def run(self) -> Dict[str, Any]:
        """Run YRSN-16 tests."""
        self.log("\n--- YRSN-16 Tests ---")

        from yrsn.core.decomposition.collapse import detect_collapse, detect_collapse_full

        for type_name, signals in self.COLLAPSE_TESTS.items():
            try:
                # Use detect_collapse_full for extended parameters
                result = detect_collapse_full(**signals)
                actual = result.collapse_type.name
                passed = actual == type_name
                self.record(type_name, type_name, actual, passed)
            except Exception as e:
                self.record(type_name, type_name, str(e), False)

        return self.results()


class SafetyTestSuite(BaseTestSuite):
    """Safety band + dual tracking tests."""

    def run(self) -> Dict[str, Any]:
        """Run safety tests."""
        self.log("\n--- Safety Band Tests ---")
        self._run_safety_band_tests()

        self.log("\n--- Dual Tracking Tests ---")
        self._run_dual_tracking_tests()

        return self.results()

    def _run_safety_band_tests(self):
        """Test threshold +-margin detection."""
        from yrsn.core.decomposition.collapse import detect_collapse, detect_collapse_full

        # Test: Below threshold should be NONE/healthy
        # HEALTHY_R_MIN=0.45, HEALTHY_S_MAX=0.38, HEALTHY_N_MAX=0.28
        # CONFLICT: N > 0.20 AND S > 0.25
        tests = [
            # (name, signals, expected, use_full)
            # Healthy: R > 0.45, S < 0.38, N < 0.28
            ("poisoning_below", {'R': 0.55, 'S': 0.20, 'N': 0.25}, "NONE", False),
            ("poisoning_above", {'R': 0.30, 'S': 0.20, 'N': 0.50}, "POISONING", False),
            ("distraction_below", {'R': 0.55, 'S': 0.25, 'N': 0.20}, "NONE", False),
            ("distraction_above", {'R': 0.30, 'S': 0.50, 'N': 0.20}, "DISTRACTION", False),
            ("healthy_signal", {'R': 0.70, 'S': 0.18, 'N': 0.12, 'omega': 0.75}, "NONE", True),
            ("conflict_boundary", {'R': 0.30, 'S': 0.35, 'N': 0.35}, "CONFLICT", False),
            # RSN_COLLAPSE: R,S,N within 0.04 delta for priority 4 to beat CONFLICT
            ("rsn_uniform", {'R': 0.35, 'S': 0.34, 'N': 0.31}, "RSN_COLLAPSE", True),
            ("rsn_near_healthy", {'R': 0.50, 'S': 0.25, 'N': 0.25, 'omega': 0.60}, "NONE", True),
        ]

        for name, signals, expected, use_full in tests:
            try:
                if use_full:
                    result = detect_collapse_full(**signals)
                else:
                    result = detect_collapse(**signals)
                actual = result.collapse_type.name
                # Handle HEALTHY as NONE equivalent
                if expected == "NONE" and actual in ("NONE", "HEALTHY"):
                    passed = True
                else:
                    passed = actual == expected
                self.record(f"safety_{name}", expected, actual, passed)
            except Exception as e:
                self.record(f"safety_{name}", expected, str(e), False)

    def _run_dual_tracking_tests(self):
        """Test R/S/N + omega/epistemic tracking."""
        from yrsn.core.decomposition.collapse import detect_collapse_full

        tests = [
            # Good RSN but OOD -> should detect OOD issue
            ("good_rsn_ood", {'R': 0.65, 'S': 0.20, 'N': 0.15, 'omega': 0.28}, "DRIFT"),
            # High epistemic spike
            ("high_epistemic", {'R': 0.45, 'S': 0.30, 'N': 0.25, 'epistemic': 0.85}, "EPISTEMIC_SPIKE"),
            # Aleatoric dominance: aleatoric > 2x epistemic, avoid healthy
            ("aleatoric_dom", {'R': 0.40, 'S': 0.35, 'N': 0.25, 'epistemic': 0.10, 'aleatoric': 0.50}, "ALEATORIC_DOMINANCE"),
            # Healthy all signals
            ("healthy_all", {'R': 0.70, 'S': 0.18, 'N': 0.12, 'omega': 0.80, 'epistemic': 0.15, 'aleatoric': 0.10}, "NONE"),
            # Overconfident: alpha < 0.40, epistemic < 0.10 (alpha = 0.30/1.0 = 0.30)
            ("overconfident", {'R': 0.30, 'S': 0.50, 'N': 0.20, 'epistemic': 0.05, 'was_correct': False}, "OVERCONFIDENCE"),
        ]

        for name, signals, expected in tests:
            try:
                result = detect_collapse_full(**signals)
                actual = result.collapse_type.name
                if expected == "NONE" and actual in ("NONE", "HEALTHY"):
                    passed = True
                else:
                    passed = actual == expected
                self.record(f"dual_{name}", expected, actual, passed)
            except Exception as e:
                self.record(f"dual_{name}", expected, str(e), False)


class StressTestSuite(BaseTestSuite):
    """Stress tests with external datasets."""

    def __init__(self, verbose: bool = False, dataset: Optional[str] = None):
        super().__init__(verbose)
        self.dataset = dataset

    def run(self) -> Dict[str, Any]:
        """Run stress tests."""
        self.log("\n--- Stress Tests ---")

        # High volume test
        self._run_volume_test(1000)

        # Edge case test
        self._run_edge_cases()

        # Random signal test
        self._run_random_signals(100)

        return self.results()

    def _run_volume_test(self, n: int):
        """Test high volume processing."""
        from yrsn.core.decomposition.collapse import detect_collapse

        start = time.time()
        errors = 0

        for i in range(n):
            # Generate random valid RSN
            r = np.random.uniform(0.2, 0.8)
            s = np.random.uniform(0.1, 0.4)
            n_val = 1.0 - r - s
            if n_val < 0:
                n_val = 0.1
                total = r + s + n_val
                r, s, n_val = r/total, s/total, n_val/total

            try:
                result = detect_collapse(R=r, S=s, N=n_val)
            except:
                errors += 1

        duration = time.time() - start
        passed = errors == 0
        self.record(
            f"volume_{n}",
            f"0 errors",
            f"{errors} errors",
            passed,
            duration_ms=duration * 1000,
            throughput=n / duration
        )

    def _run_edge_cases(self):
        """Test edge cases."""
        from yrsn.core.decomposition.collapse import detect_collapse

        edge_cases = [
            ("all_zeros", {'R': 0.0, 'S': 0.0, 'N': 0.0}),
            ("all_ones", {'R': 1.0, 'S': 1.0, 'N': 1.0}),
            ("extreme_r", {'R': 0.99, 'S': 0.005, 'N': 0.005}),
            ("extreme_s", {'R': 0.005, 'S': 0.99, 'N': 0.005}),
            ("extreme_n", {'R': 0.005, 'S': 0.005, 'N': 0.99}),
            ("tiny_values", {'R': 0.001, 'S': 0.001, 'N': 0.001}),
        ]

        for name, signals in edge_cases:
            try:
                result = detect_collapse(**signals)
                self.record(f"edge_{name}", "no_crash", "no_crash", True)
            except Exception as e:
                self.record(f"edge_{name}", "no_crash", str(e)[:50], False)

    def _run_random_signals(self, n: int):
        """Test random signal combinations."""
        from yrsn.core.decomposition.collapse import detect_collapse

        errors = 0
        for i in range(n):
            signals = {
                'R': np.random.uniform(0, 1),
                'S': np.random.uniform(0, 1),
                'N': np.random.uniform(0, 1),
                'omega': np.random.uniform(0, 1),
                'epistemic': np.random.uniform(0, 1),
                'aleatoric': np.random.uniform(0, 1),
            }
            try:
                result = detect_collapse(**signals)
            except:
                errors += 1

        passed = errors == 0
        self.record(f"random_{n}", "0 errors", f"{errors} errors", passed)


class AdversarialTestSuite(BaseTestSuite):
    """Adversarial boundary tests."""

    def run(self) -> Dict[str, Any]:
        """Run adversarial tests."""
        self.log("\n--- Adversarial Tests ---")

        self._run_boundary_tests()
        self._run_priority_tests()
        self._run_overlap_tests()

        return self.results()

    def _run_boundary_tests(self):
        """Test exact threshold boundaries."""
        from yrsn.core.decomposition.collapse import detect_collapse

        # Test at exact thresholds
        boundaries = [
            # At POISONING threshold (N=0.30)
            ("poison_at_thresh", {'R': 0.35, 'S': 0.35, 'N': 0.30}),
            # Just below POISONING
            ("poison_below", {'R': 0.36, 'S': 0.35, 'N': 0.29}),
            # Just above POISONING
            ("poison_above", {'R': 0.34, 'S': 0.35, 'N': 0.31}),
        ]

        for name, signals in boundaries:
            try:
                result = detect_collapse(**signals)
                self.record(f"boundary_{name}", "detected", result.collapse_type.name, True)
            except Exception as e:
                self.record(f"boundary_{name}", "detected", str(e), False)

    def _run_priority_tests(self):
        """Test collapse type priorities."""
        from yrsn.core.decomposition.collapse import detect_collapse, detect_collapse_full

        # Test cases where multiple types could trigger
        priority_tests = [
            # High N + High S -> should be CONFLICT (not POISONING or DISTRACTION)
            ("conflict_priority", {'R': 0.20, 'S': 0.40, 'N': 0.40}, "CONFLICT", False),
            # Uniform RSN -> should be RSN_COLLAPSE (R,S,N within 0.04 delta for priority 4)
            ("rsn_priority", {'R': 0.35, 'S': 0.34, 'N': 0.31}, "RSN_COLLAPSE", True),
        ]

        for name, signals, expected, use_full in priority_tests:
            try:
                if use_full:
                    result = detect_collapse_full(**signals)
                else:
                    result = detect_collapse(**signals)
                actual = result.collapse_type.name
                passed = actual == expected
                self.record(f"priority_{name}", expected, actual, passed)
            except Exception as e:
                self.record(f"priority_{name}", expected, str(e), False)

    def _run_overlap_tests(self):
        """Test overlapping detection regions."""
        from yrsn.core.decomposition.collapse import detect_collapse_full

        # Test signals that fall in overlapping regions
        overlap_tests = [
            # High R + low omega: O_POISONING vs DRIFT
            ("opois_vs_drift", {'R': 0.65, 'S': 0.20, 'N': 0.15, 'omega': 0.30}),
            # Low epistemic: OVERCONFIDENCE vs ALEATORIC_DOMINANCE
            ("overconf_vs_aleat", {'R': 0.60, 'S': 0.25, 'N': 0.15, 'epistemic': 0.08, 'aleatoric': 0.30}),
        ]

        for name, signals in overlap_tests:
            try:
                result = detect_collapse_full(**signals)
                self.record(f"overlap_{name}", "consistent", result.collapse_type.name, True)
            except Exception as e:
                self.record(f"overlap_{name}", "consistent", str(e), False)
