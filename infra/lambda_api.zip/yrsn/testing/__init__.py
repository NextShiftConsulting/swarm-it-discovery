"""
YRSN Testing Module

Provides test suites for validating YRSN collapse detection:
- Basic: Core functionality tests
- YRSN-16: All 16 collapse type tests
- Safety: Safety band + dual tracking tests
- Stress: External dataset stress tests
- Adversarial: Boundary condition tests

Usage:
    from yrsn.testing import TestRunner

    runner = TestRunner(verbose=True)
    results = runner.run_safety_tests()
    print(f"Passed: {results['passed']}/{results['total']}")
"""

from yrsn.testing.runner import TestRunner
from yrsn.testing.suites import (
    BasicTestSuite,
    YRSN16TestSuite,
    SafetyTestSuite,
    StressTestSuite,
    AdversarialTestSuite,
)

__all__ = [
    'TestRunner',
    'BasicTestSuite',
    'YRSN16TestSuite',
    'SafetyTestSuite',
    'StressTestSuite',
    'AdversarialTestSuite',
]
