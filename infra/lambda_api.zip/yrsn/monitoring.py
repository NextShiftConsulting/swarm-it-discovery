"""
YRSN Monitoring - Latent State Health Monitoring for HRM Models
================================================================

This module provides a clean, unified API for all YRSN monitoring functions.
Import everything you need for monitoring from this single module.

Quick Start
-----------
>>> from yrsn.monitoring import detect_collapse
>>> analysis = detect_collapse(R=0.7, S=0.2, N=0.1)
>>> analysis.collapse_type.name
'NONE'

Collapse Detection
------------------
>>> from yrsn.monitoring import detect_collapse, CollapseType
>>>
>>> # Check for poisoning (high noise)
>>> analysis = detect_collapse(R=0.3, S=0.2, N=0.5)
>>> analysis.collapse_type == CollapseType.POISONING
True
>>> analysis.paradigm_remedy
'Paradigm 1: Iterative Refinement + EGGROLL exploration'

>>> # Check for distraction (information overload)
>>> analysis = detect_collapse(R=0.3, S=0.6, N=0.1)
>>> analysis.collapse_type == CollapseType.DISTRACTION
True

>>> # Get one-line summary
>>> from yrsn.monitoring import get_collapse_summary
>>> get_collapse_summary(R=0.8, S=0.1, N=0.1)
'OK (risk=0.25): Context healthy'

Calibration Manager
-------------------
The CalibrationManager handles drift detection and automatic recalibration:

    from yrsn.monitoring import CalibrationManager, CalibrationConfig

    config = CalibrationConfig(
        buffer_size=256,
        muddy_threshold=0.15,
        auto_recalibrate=True
    )
    manager = CalibrationManager(hidden_dim=64, config=config)
    manager.initialize_from_model(model, device)

    # During inference - auto-handles drift
    metrics = manager.compute_metrics(hidden_states)

Robust PCA Decomposition
------------------------
>>> from yrsn.monitoring import robust_pca
>>> import numpy as np
>>>
>>> # Create test matrix (low-rank + sparse + noise)
>>> np.random.seed(42)
>>> M = np.random.randn(50, 50)
>>>
>>> # Decompose to low-rank + sparse components
>>> result = robust_pca(M)
>>> result.L.shape
(50, 50)

See Also
--------
- docs/LATENT_STATE_MONITORING.md - Architecture overview
- docs/YRSN_MONITORING_ARCHITECTURE.md - Detailed design
- benchmark/evaluate_yrsn_monitoring.py - Evaluation script
"""

# =============================================================================
# Collapse Detection
# =============================================================================
from yrsn.core.decomposition.collapse import (
    detect_collapse,
    CollapseType,
    CollapseAnalysis,
    CollapseDetector,
    CollapseSignature,
    Severity,
    get_collapse_summary,
)

# =============================================================================
# Calibration Manager (Drift-Reset Mechanism)
# =============================================================================
from yrsn.core.decomposition.calibration_manager import (
    CalibrationManager,
    CalibrationConfig,
    CalibrationState,
    CalibrationMetrics,
    create_calibrated_projections,
)

# =============================================================================
# Robust PCA Decomposition
# =============================================================================
from yrsn.core.decomposition.robust_pca import (
    robust_pca,
    RobustPCA,
    RPCAResult,
    RPCAMethod,
    decompose_to_yrsn,
)

# =============================================================================
# Shared Utilities
# =============================================================================
from yrsn.models._common import (
    compute_yrsn_monitoring_metrics,
)

# =============================================================================
# Projection Heads (requires models)
# =============================================================================
try:
    from yrsn.models.hrm import YRSNProjectionHeads
    _HAS_PROJECTIONS = True
except ImportError:
    _HAS_PROJECTIONS = False
    YRSNProjectionHeads = None


__all__ = [
    # Collapse Detection
    "detect_collapse",
    "CollapseType",
    "CollapseAnalysis",
    "CollapseDetector",
    "CollapseSignature",
    "Severity",
    "get_collapse_summary",
    # Calibration
    "CalibrationManager",
    "CalibrationConfig",
    "CalibrationState",
    "CalibrationMetrics",
    "create_calibrated_projections",
    # Robust PCA
    "robust_pca",
    "RobustPCA",
    "RPCAResult",
    "RPCAMethod",
    "decompose_to_yrsn",
    # Utilities
    "compute_yrsn_monitoring_metrics",
    # Projection Heads
    "YRSNProjectionHeads",
]


# =============================================================================
# Convenience Functions
# =============================================================================

def quick_health_check(R: float, S: float, N: float) -> str:
    """
    One-line health check for R/S/N values.

    Parameters
    ----------
    R : float
        Relevant content ratio [0, 1]
    S : float
        Superfluous content ratio [0, 1]
    N : float
        Noise ratio [0, 1]

    Returns
    -------
    str
        Health status: "healthy", "warning", or "critical"

    Examples
    --------
    >>> quick_health_check(0.8, 0.1, 0.1)
    'healthy'
    >>> quick_health_check(0.68, 0.22, 0.10)
    'warning'
    >>> quick_health_check(0.2, 0.4, 0.4)
    'critical'
    """
    analysis = detect_collapse(R, S, N)

    if analysis.collapse_type == CollapseType.NONE:
        return "healthy"
    elif analysis.severity in (Severity.LOW, Severity.MEDIUM):
        return "warning"
    else:
        return "critical"


def compute_health_score(R: float, S: float, N: float) -> float:
    """
    Compute a single health score from R/S/N values.

    Higher is better. Score = R / (S + N + epsilon)

    Parameters
    ----------
    R : float
        Relevant content ratio [0, 1]
    S : float
        Superfluous content ratio [0, 1]
    N : float
        Noise ratio [0, 1]

    Returns
    -------
    float
        Health score (higher = healthier)

    Examples
    --------
    >>> round(compute_health_score(0.8, 0.1, 0.1), 1)
    4.0
    >>> round(compute_health_score(0.5, 0.25, 0.25), 1)
    1.0
    >>> round(compute_health_score(0.2, 0.4, 0.4), 2)
    0.25
    """
    return R / (S + N + 0.001)


__all__ += ["quick_health_check", "compute_health_score"]
