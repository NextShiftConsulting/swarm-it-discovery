"""Swarm-It Configuration Management."""

from .config_manager import get_config, ConfigManager

__all__ = ["get_config", "ConfigManager"]
